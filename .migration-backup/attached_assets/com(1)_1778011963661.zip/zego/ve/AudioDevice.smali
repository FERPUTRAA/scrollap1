.class public Lcom/zego/ve/AudioDevice;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/zego/ve/AudioEventMonitor$IEventNotify;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0xb
.end annotation


# static fields
.field private static final ApiAAudio:I = 0x4

.field private static final ApiAudioRecord:I = 0x1

.field private static final ApiAudioRecordLatency:I = 0x2

.field private static final ApiAudioTrack:I = 0x1

.field private static final ApiAudioTrackLatency:I = 0x2

.field private static final ApiOpensles:I = 0x3

.field private static final CAP_SR_16000:I = 0x2

.field private static final CAP_SR_32000:I = 0x1

.field private static final CAP_SR_48000:I = 0x0

.field private static final CAP_SR_8000:I = 0x3

.field private static final TAG:Ljava/lang/String; = "device"

.field public static event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;


# instance fields
.field protected _Karaoke:Lcom/zego/ve/KaraokeHelper;

.field protected _NativeOutputSampleRate:I

.field protected _audioManager:Landroid/media/AudioManager;

.field protected _audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

.field protected _audio_source:I

.field protected _capBuf:Ljava/nio/ByteBuffer;

.field protected _capDev:Landroid/media/AudioRecord;

.field protected _capProfile:I

.field protected _capSampleRate:I

.field protected _capSampleRateTable:[I

.field protected _context:Landroid/content/Context;

.field protected _devRoute:Landroid/media/AudioTrack;

.field protected final _frameSizeMs:I

.field protected _framesPerBuffer:I

.field protected volatile _pthis:J

.field protected _rndBuf:Ljava/nio/ByteBuffer;

.field protected _rndBufArray:[B

.field protected _rndDev:Landroid/media/AudioTrack;

.field protected _stream_type:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance v0, Lcom/zego/ve/AudioEventMonitor;

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/zego/ve/AudioEventMonitor;-><init>()V

    sput-object v0, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>()V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v7, 0x2

    const/4 v0, 0x0

    const/4 v7, 0x2

    shl-int/2addr v6, v0

    const/4 v7, 0x1

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_context:Landroid/content/Context;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndBuf:Ljava/nio/ByteBuffer;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_capBuf:Ljava/nio/ByteBuffer;

    const/4 v7, 0x6

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndBufArray:[B

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_devRoute:Landroid/media/AudioTrack;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v1, 0x3

    and-int/2addr v7, v1

    const/4 v6, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput v1, p0, Lcom/zego/ve/AudioDevice;->_stream_type:I

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x0

    const/4 v1, 0x1

    const/4 v7, 0x4

    iput v1, p0, Lcom/zego/ve/AudioDevice;->_audio_source:I

    const/4 v7, 0x3

    const/4 v6, 0x4

    const v2, 0xac44

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    iput v2, p0, Lcom/zego/ve/AudioDevice;->_NativeOutputSampleRate:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/16 v2, 0x14

    const/4 v7, 0x2

    iput v2, p0, Lcom/zego/ve/AudioDevice;->_frameSizeMs:I

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/16 v2, 0x7d00

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    iput v2, p0, Lcom/zego/ve/AudioDevice;->_capSampleRate:I

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/16 v3, 0x3e80

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/16 v4, 0x1f40

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    const v5, 0xbb80

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    filled-new-array {v5, v2, v3, v4}, [I

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput-object v2, p0, Lcom/zego/ve/AudioDevice;->_capSampleRateTable:[I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/16 v2, 0x100

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput v2, p0, Lcom/zego/ve/AudioDevice;->_framesPerBuffer:I

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    iput v1, p0, Lcom/zego/ve/AudioDevice;->_capProfile:I

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v7, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    iput-wide v1, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v7, 0x0

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    const/4 v7, 0x3

    const/16 v0, 0xf00

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    iput-object v1, p0, Lcom/zego/ve/AudioDevice;->_rndBuf:Ljava/nio/ByteBuffer;

    const/4 v7, 0x5

    const/4 v6, 0x2

    new-array v0, v0, [B

    const/4 v6, 0x0

    move v7, v6

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndBufArray:[B

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/16 v0, 0x780

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_capBuf:Ljava/nio/ByteBuffer;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v0, 0x7

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    iput v0, p0, Lcom/zego/ve/AudioDevice;->_audio_source:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v0, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    iput v0, p0, Lcom/zego/ve/AudioDevice;->_stream_type:I

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    return-void
.end method

.method static LogDeviceInfo()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "dis@ l@ ~rmb@ ~ / cnK@ o@~@@@~oo~t~@~~~ ~of@@~M b~~s ot  o4~@~l@uiiv-~1 @b@ @@@f@/y~ ~~a ~~ @S.~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v1, " rSmA insodD:"

    const-string v1, "D:sS di dnAro"

    const/4 v4, 0x1

    const-string v1, "Android SDK: "

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v1, "el:eo Rs,ea"

    const-string v1, "eRsmle,ae :"

    const/4 v4, 0x5

    const-string v1, ",a:lebeR es"

    const-string v1, ", Release: "

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    sget-object v1, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    move v4, v3

    const-string v1, "a: ,Bour "

    const-string v1, ",naBor:  "

    const/4 v4, 0x3

    const-string v1, ", Brand: "

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    move v4, v3

    sget-object v1, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v1, "  b:ic,pDv"

    const-string v1, "  eiDb,v:c"

    const/4 v4, 0x5

    const-string v1, "Di, cv eqe"

    const-string v1, ", Device: "

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    sget-object v1, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo v1, "u dI, "

    const-string/jumbo v1, "u dI, "

    const/4 v4, 0x1

    const-string v1, "I,s :d"

    const-string v1, ", Id: "

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    sget-object v1, Landroid/os/Build;->ID:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v1, ",a:mHeprwr  "

    const-string v1, "Hdraw:rp,  e"

    const/4 v4, 0x7

    const-string v1, " ae:oaH, rrw"

    const-string v1, ", Hardware: "

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget-object v1, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v1, "n:a,Mbau qre ctf"

    const-string/jumbo v1, "r,en  :tqaafuMcu"

    const/4 v4, 0x2

    const-string v1, ", Manufacturer: "

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget-object v1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v1, "Mso: eu,d"

    const-string/jumbo v1, "lMso ed,:"

    const/4 v4, 0x0

    const-string/jumbo v1, "l eMdo:p "

    const-string v1, ", Model: "

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const-string/jumbo v1, "ou,rd:P q t"

    const-string v1, ", Product: "

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    sget-object v1, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v1, "eesvdi"

    const-string v1, "edimev"

    const-string v1, "ecvmde"

    const-string v1, "device"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v1, v0}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string v2, "ECdroonEtio:deuffAAAc  o "

    const-string/jumbo v2, "fEAdo t ruodAC nAEficei:o"

    const/4 v4, 0x7

    const-string v2, "cueirb:nA foEtfCAid AEd d"

    const-string v2, "Android AudioEffect AEC: "

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-static {}, Landroid/media/audiofx/AcousticEchoCanceler;->isAvailable()Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v2, "GAC: ,u"

    const-string v2, ", AGC: "

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {}, Landroid/media/audiofx/AutomaticGainControl;->isAvailable()Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v2, " pN: S"

    const-string v2, "N:S  b"

    const/4 v4, 0x4

    const-string v2, ",:qN  "

    const-string v2, ", NS: "

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {}, Landroid/media/audiofx/NoiseSuppressor;->isAvailable()Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v1, v0}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method

.method private static native OnAudioDeviceInited(JIZ)V
.end method

.method private static native OnAudioFocusChange(JI)V
.end method

.method private static native OnAudioRouteChanged(JI)V
.end method

.method private static native OnInterruptionBegin(J)V
.end method

.method private static native OnInterruptionEnd(J)V
.end method


# virtual methods
.method protected AttemptToBluetoothSco()V
    .locals 7
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1f
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_context:Landroid/content/Context;

    const/4 v6, 0x0

    const-string v2, "dasuo"

    const-string v2, "duaio"

    const/4 v6, 0x5

    const-string v2, "diamu"

    const-string v2, "audio"

    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    check-cast v1, Landroid/media/AudioManager;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/16 v2, 0x1f

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-ge v0, v2, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/media/AudioManager;->stopBluetoothSco()V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/media/AudioManager;->startBluetoothSco()V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/zego/ve/e;->a(Landroid/media/AudioManager;)Ljava/util/List;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    check-cast v2, Landroid/media/AudioDeviceInfo;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v2}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v4, 0x7

    const/4 v6, 0x7

    if-ne v3, v4, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/zego/ve/f;->a(Landroid/media/AudioManager;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v1, v2}, Lcom/zego/ve/g;->a(Landroid/media/AudioManager;Landroid/media/AudioDeviceInfo;)Z

    :cond_2
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-void
.end method

.method public CheckAudioRoute(IZ)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    sget-object v0, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p2}, Lcom/zego/ve/AudioEventMonitor;->CheckAudioRoute(IZ)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return p1
.end method

.method public CheckBluetoothSCO()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/zego/ve/AudioEventMonitor;->CheckBluetoothSCO()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/zego/ve/AudioDevice;->AttemptToBluetoothSco()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public CheckPermission()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_context:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v1, "EeU.odiAioDasrOsm_pnCOon.RIRpri"

    const-string v1, "Ars_iiOpCeORnDpIndDaRimr.o.soUE"

    const/4 v3, 0x0

    const-string v1, "android.permission.RECORD_AUDIO"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/zego/ve/PermissionChecker;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    return v0
.end method

.method public CheckPhoneState()I
    .locals 3

    const/4 v2, 0x4

    sget-object v0, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/zego/ve/AudioEventMonitor;->CheckPhoneState()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public DoCap(I)I
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_capBuf:Ljava/nio/ByteBuffer;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p1}, Landroid/media/AudioRecord;->read(Ljava/nio/ByteBuffer;I)I

    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return p1

    :catch_0
    move-exception p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 p1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return p1
.end method

.method public DoRnd(I)I
    .locals 6

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndBuf:Ljava/nio/ByteBuffer;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndBuf:Ljava/nio/ByteBuffer;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_rndBufArray:[B

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/nio/Buffer;->capacity()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v3, v2}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_rndBufArray:[B

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v3, p1}, Landroid/media/AudioTrack;->write([BII)I

    move-result v3
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    return v3

    :catch_0
    move-exception p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 p1, -0x1

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    return p1
.end method

.method public DuckUnpluginHeadsetWhenVoip()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object v0, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/zego/ve/AudioEventMonitor;->DuckUnpluginHeadsetWhenVoip()V

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public EnableHWKaraoke(I)I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/zego/ve/KaraokeHelper;->EnableHWKaraoke(I)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return p1
.end method

.method public EnableVivoKaraoke(I)I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/zego/ve/KaraokeHelper;->EnableVivoKaraoke(I)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return p1
.end method

.method public EnableXiaomiKaraoke(I)I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/zego/ve/KaraokeHelper;->EnableXiaomiKaraoke(I)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return p1
.end method

.method public GetApiLevel()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public GetBluetoothInput()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_context:Landroid/content/Context;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/zego/ve/AudioDeviceHelper;->getBluetoothInput(Landroid/content/Context;)I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public GetBluetoothOutput()I
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_context:Landroid/content/Context;

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    sget-object v1, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v1}, Lcom/zego/ve/AudioEventMonitor;->GetMode()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/zego/ve/AudioDeviceHelper;->getBluetoothOutput(Landroid/content/Context;I)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return v0
.end method

.method public GetDeviceHardware()I
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/zego/ve/KaraokeHelper;->GetDeviceHardware()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public GetDeviceManufacturer()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    invoke-virtual {v0}, Lcom/zego/ve/KaraokeHelper;->GetDeviceManufacturer()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    return v0
.end method

.method public GetOutputFramePerBuffer()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/zego/ve/AudioDevice;->_framesPerBuffer:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public GetPlayoutSampleRate()I
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget v0, p0, Lcom/zego/ve/AudioDevice;->_NativeOutputSampleRate:I

    const/4 v5, 0x1

    sget-object v1, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x0

    iget v2, v1, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x4

    if-ne v3, v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget v1, v1, Lcom/zego/ve/AudioEventMonitor;->audio_route_:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v2, 0x2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eq v2, v1, :cond_0

    const/4 v5, 0x2

    const/4 v2, 0x6

    const/4 v5, 0x4

    move v4, v2

    move v4, v2

    const/4 v5, 0x6

    if-ne v2, v1, :cond_1

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/16 v0, 0x3e80

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    return v0
.end method

.method public GetRecordingSampleRate()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/zego/ve/AudioDevice;->_capSampleRate:I

    const/4 v2, 0x1

    return v0
.end method

.method public GetStreamVolume()I
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v0, -0x2

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget v1, p0, Lcom/zego/ve/AudioDevice;->_stream_type:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    int-to-float v0, v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget v2, p0, Lcom/zego/ve/AudioDevice;->_stream_type:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    int-to-float v1, v1

    const/4 v4, 0x5

    div-float/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const v1, 0x3ba3d70a    # 0.005f

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    add-float/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/high16 v1, 0x42c80000    # 100.0f

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    mul-float/2addr v0, v1

    const/4 v4, 0x3

    float-to-int v0, v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    return v0
.end method

.method public Init(JZZ)I
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_context:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v1, -0x1

    or-int/2addr v5, v1

    const/4 v4, 0x2

    and-int/2addr v5, v4

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    return v1

    :cond_0
    const/4 v5, 0x5

    iput-wide p1, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 p1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz p4, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 p2, 0x3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    move p2, p1

    move p2, p1

    const/4 v5, 0x5

    move p2, p1

    :goto_0
    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object p4, p0, Lcom/zego/ve/AudioDevice;->_context:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p4, p2}, Lcom/zego/ve/AudioDeviceHelper;->getCurrentRoute(Landroid/content/Context;I)I

    move-result p2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget-object p4, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p4, p2}, Lcom/zego/ve/AudioEventMonitor;->SetRoutInfo(I)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-wide v2, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v2, v3, p2, p1}, Lcom/zego/ve/AudioDevice;->OnAudioDeviceInited(JIZ)V

    const/4 v5, 0x0

    sget-object p2, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    invoke-virtual {p2, p0}, Lcom/zego/ve/AudioEventMonitor;->SetEeventHandler(Lcom/zego/ve/AudioEventMonitor$IEventNotify;)V

    const/4 v5, 0x6

    sget-object p2, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object p4, p0, Lcom/zego/ve/AudioDevice;->_context:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p2, p4, p3}, Lcom/zego/ve/AudioEventMonitor;->Init(Landroid/content/Context;Z)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    sget-object p2, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p2}, Lcom/zego/ve/AudioEventMonitor;->IsInited()Z

    move-result p2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez p2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return v1

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    sget-object p2, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p2}, Lcom/zego/ve/AudioEventMonitor;->GetAudioManager()Landroid/media/AudioManager;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    iput-object p2, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    sget-object p2, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p2}, Lcom/zego/ve/AudioEventMonitor;->GetRouteChangeHandle()Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    iput-object p2, p0, Lcom/zego/ve/AudioDevice;->_audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string p3, ".ArTebUoo.EipUnEMTeyaAdRaPSr_imPTptd_rLOq"

    const-string p3, "aToo_yp_qriPPTUOmA.TRUSEetAMEpirne.ddLar."

    const/4 v5, 0x4

    const-string p3, ".iTUoauiLaEArrAppMPd_SnPdroOdTURtyT.e._Ee"

    const-string p3, "android.media.property.OUTPUT_SAMPLE_RATE"

    const/4 v5, 0x1

    invoke-virtual {p2, p3}, Landroid/media/AudioManager;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz p2, :cond_3

    const/4 v5, 0x5

    invoke-static {p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p2

    const/4 v5, 0x1

    const/4 v4, 0x6

    iput p2, p0, Lcom/zego/ve/AudioDevice;->_NativeOutputSampleRate:I

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p2, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string p3, "OURarp.pEU.a.FyPrm_dioTUtn_RdFPFMdoieerTp_BRAEE"

    const-string p3, "android.media.property.OUTPUT_FRAMES_PER_BUFFER"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p2, p3}, Landroid/media/AudioManager;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz p2, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    iput p2, p0, Lcom/zego/ve/AudioDevice;->_framesPerBuffer:I

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/16 p2, 0x7d00

    const/4 v4, 0x4

    or-int/2addr v5, v4

    iput p2, p0, Lcom/zego/ve/AudioDevice;->_capSampleRate:I

    const/4 v4, 0x5

    or-int/2addr v5, v4

    new-instance p2, Lcom/zego/ve/KaraokeHelper;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object p3, p0, Lcom/zego/ve/AudioDevice;->_context:Landroid/content/Context;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object p4, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {p2, p3, p4}, Lcom/zego/ve/KaraokeHelper;-><init>(Landroid/content/Context;Landroid/media/AudioManager;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput-object p2, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/zego/ve/AudioDevice;->_context:Landroid/content/Context;

    const/4 v5, 0x7

    invoke-virtual {p2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string p3, "_wlnoylhqao.rerco.tiead.dnwdiurada"

    const-string/jumbo p3, "ohsrdite.wanolaur.ddlaenrd.aci_oyw"

    const/4 v5, 0x7

    const-string p3, "aosydet.aclaoriud_awehnao..iwnrrld"

    const-string p3, "android.hardware.audio.low_latency"

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-virtual {p2, p3}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object p3, p0, Lcom/zego/ve/AudioDevice;->_context:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string/jumbo p4, "o.rmudo.ardaaddhio.ieapnrm"

    const-string/jumbo p4, "rdamrno.oddwohua.dp.iaeari"

    const/4 v5, 0x2

    const-string/jumbo p4, "urwoooniorrpad.idedadaarh."

    const-string p4, "android.hardware.audio.pro"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p3, p4}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p3

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-static {}, Lcom/zego/ve/AudioDevice;->LogDeviceInfo()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const-string/jumbo v0, "unowtbtsheLeaaFe:roLc"

    const-string v0, "Fua:owoLrhaetaetecnLs"

    const/4 v5, 0x7

    const-string/jumbo v0, "seuFcLutayaowe:naLret"

    const-string/jumbo v0, "hasLowLatencyFeature:"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string p2, "esrPueFp: oarat,"

    const-string p2, ",Ft sb:raruaoePe"

    const-string/jumbo p2, "r,aeeuhaqrPt: Fo"

    const-string p2, ", hasProFeature:"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string p2, "AEsTRU_PMPu AU_:TTSL,"

    const-string p2, "A_POLTu:_SEAUTPMRT,U "

    const/4 v5, 0x2

    const-string p2, ", OUTPUT_SAMPLE_RATE:"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget p2, p0, Lcom/zego/ve/AudioDevice;->_NativeOutputSampleRate:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const-string p2, "R:_RE_FpES EFRFPTUUM,BTU_PA"

    const/4 v5, 0x1

    const-string p2, "RPPm__UE,EFTAOU:_RFSUBETFRM"

    const-string p2, ", OUTPUT_FRAMES_PER_BUFFER:"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    iget p2, p0, Lcom/zego/ve/AudioDevice;->_framesPerBuffer:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo p3, "vqedoc"

    const-string/jumbo p3, "evqidc"

    const/4 v5, 0x5

    const-string p3, "ceiedb"

    const-string p3, "device"

    const/4 v5, 0x0

    invoke-static {p3, p2}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x2

    const/4 v4, 0x4

    return p1
.end method

.method public InitCapDev(II)I
    .locals 13
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1a
    .end annotation

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    iget v0, p0, Lcom/zego/ve/AudioDevice;->_capProfile:I

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-gt v0, v2, :cond_1

    iget v4, p0, Lcom/zego/ve/AudioDevice;->_audio_source:I

    const/4 v5, 0x7

    if-ne v4, v5, :cond_1

    move v0, v3

    move v0, v3

    move v0, v3

    move v0, v3

    :cond_1
    if-ne p1, v3, :cond_2

    const/16 v4, 0xc

    goto :goto_0

    :cond_2
    const/16 v4, 0x10

    :goto_0
    iget-object v5, p0, Lcom/zego/ve/AudioDevice;->_capSampleRateTable:[I

    array-length v6, v5

    if-ge v0, v6, :cond_8

    aget v5, v5, v0

    iput v5, p0, Lcom/zego/ve/AudioDevice;->_capSampleRate:I

    invoke-static {v5, v4, v3}, Landroid/media/AudioRecord;->getMinBufferSize(III)I

    move-result v5

    const-string/jumbo v11, "udvecs"

    const-string/jumbo v11, "idsvce"

    const-string v11, "dpeevi"

    const-string v11, "device"

    if-gtz v5, :cond_3

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "eismrtz(qiiu ,anicb fi efpm"

    const-string/jumbo v7, "ufzmepmseii i( b  acf,tniri"

    const-string v7, " fsziirntaeu c isb i(,mnpei"

    const-string/jumbo v7, "init cap, mini buffer size("

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v7, "o) m< 0"

    const-string v7, "  0 o)<"

    const-string v7, "<0  o ="

    const-string v7, ") <= 0 "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v11, v6}, Lcom/zego/ve/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    iget v6, p0, Lcom/zego/ve/AudioDevice;->_capSampleRate:I

    mul-int v7, v6, p1

    if-ge v5, v7, :cond_4

    mul-int/2addr v6, p1

    move v10, v6

    move v10, v6

    move v10, v6

    move v10, v6

    goto :goto_1

    :cond_4
    move v10, v5

    move v10, v5

    move v10, v5

    move v10, v5

    :goto_1
    if-ne v3, p2, :cond_5

    :try_start_0
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v6, 0x1d

    if-lt v5, v6, :cond_5

    new-instance v5, Landroid/media/AudioRecord$Builder;

    invoke-direct {v5}, Landroid/media/AudioRecord$Builder;-><init>()V

    const/16 v6, 0xa

    invoke-virtual {v5, v6}, Landroid/media/AudioRecord$Builder;->setAudioSource(I)Landroid/media/AudioRecord$Builder;

    move-result-object v5

    new-instance v6, Landroid/media/AudioFormat$Builder;

    invoke-direct {v6}, Landroid/media/AudioFormat$Builder;-><init>()V

    invoke-virtual {v6, v3}, Landroid/media/AudioFormat$Builder;->setEncoding(I)Landroid/media/AudioFormat$Builder;

    move-result-object v6

    iget v7, p0, Lcom/zego/ve/AudioDevice;->_capSampleRate:I

    invoke-virtual {v6, v7}, Landroid/media/AudioFormat$Builder;->setSampleRate(I)Landroid/media/AudioFormat$Builder;

    move-result-object v6

    invoke-virtual {v6, v4}, Landroid/media/AudioFormat$Builder;->setChannelMask(I)Landroid/media/AudioFormat$Builder;

    move-result-object v6

    invoke-virtual {v6}, Landroid/media/AudioFormat$Builder;->build()Landroid/media/AudioFormat;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/media/AudioRecord$Builder;->setAudioFormat(Landroid/media/AudioFormat;)Landroid/media/AudioRecord$Builder;

    move-result-object v5

    invoke-virtual {v5, v10}, Landroid/media/AudioRecord$Builder;->setBufferSizeInBytes(I)Landroid/media/AudioRecord$Builder;

    move-result-object v5

    invoke-virtual {v5}, Landroid/media/AudioRecord$Builder;->build()Landroid/media/AudioRecord;

    move-result-object v5

    iput-object v5, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    goto :goto_2

    :cond_5
    new-instance v12, Landroid/media/AudioRecord;

    iget v6, p0, Lcom/zego/ve/AudioDevice;->_audio_source:I

    iget v7, p0, Lcom/zego/ve/AudioDevice;->_capSampleRate:I

    const/4 v9, 0x2

    move-object v5, v12

    move-object v5, v12

    move-object v5, v12

    move-object v5, v12

    move v8, v4

    move v8, v4

    move v8, v4

    invoke-direct/range {v5 .. v10}, Landroid/media/AudioRecord;-><init>(IIIII)V

    iput-object v12, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_2
    iget-object v5, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    if-eqz v5, :cond_7

    invoke-virtual {v5}, Landroid/media/AudioRecord;->getState()I

    move-result p1

    const/4 p2, 0x0

    if-ne p1, v2, :cond_6

    iget-object p1, p0, Lcom/zego/ve/AudioDevice;->_audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    if-eqz p1, :cond_9

    sget-object p1, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    invoke-virtual {p1}, Lcom/zego/ve/AudioEventMonitor;->SetWaitSocFlag()V

    iget-object p1, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    invoke-static {p1, v0, p2}, Lcom/zego/ve/d;->a(Landroid/media/AudioRecord;Landroid/media/AudioRouting$OnRoutingChangedListener;Landroid/os/Handler;)V

    goto :goto_3

    :cond_6
    const-string p1, "RdtSobIorAIRoionoINcddisZ_TT  EDnLAIuTa eA.idtuecbeE/srA"

    const-string p1, "InaiebeAIirdR AosNtooo o.TdE EDuIR/dTAiIde_suSALtrc ncTZ"

    const-string p1, "EctoIaueo ocouIi_ZrD/Se.ARtTILAn nRiEd ei sAuTNIrToAstdd"

    const-string p1, "AudioRecord state is not AudioRecord.STATE_INITIALIZED\n"

    invoke-static {v11, p1}, Lcom/zego/ve/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p1, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    invoke-virtual {p1}, Landroid/media/AudioRecord;->release()V

    iput-object p2, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    move v1, v2

    move v1, v2

    goto :goto_3

    :catch_0
    move-exception v5

    invoke-virtual {v5}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_7
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_0

    :cond_8
    const/4 v1, -0x1

    :cond_9
    :goto_3
    return v1
.end method

.method public InitRndDev(III)I
    .locals 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x18
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    return v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v0, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x3

    if-ne p2, v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/16 p2, 0xc

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/16 p2, 0x10

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p1, p2, v0}, Landroid/media/AudioTrack;->getMinBufferSize(III)I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    mul-int/2addr v2, v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, v2, p1, p2, p3}, Lcom/zego/ve/AudioDevice;->createAudioTrack(IIII)Landroid/media/AudioTrack;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v4, 0x2

    if-nez v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0, v2, p1, p2, p3}, Lcom/zego/ve/AudioDevice;->createAudioTrack(IIII)Landroid/media/AudioTrack;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-object p1, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz p1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object p2, p0, Lcom/zego/ve/AudioDevice;->_audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    const/4 v4, 0x4

    const/4 v3, 0x4

    if-eqz p2, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 p3, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1, p2, p3}, Lcom/zego/ve/c;->a(Landroid/media/AudioTrack;Landroid/media/AudioRouting$OnRoutingChangedListener;Landroid/os/Handler;)V

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    return v1

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 p1, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    return p1
.end method

.method public InitVivoKtvEnv()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, p0, Lcom/zego/ve/AudioDevice;->_NativeOutputSampleRate:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/zego/ve/KaraokeHelper;->InitVivoKtvEnv(I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v0
.end method

.method public InitXiaomiKtvEnv()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/zego/ve/KaraokeHelper;->InitXiaomiKtvEnv()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public IsHarmonyOS()Z
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string v1, "ao.euswpuyleitihBu.sc.xEm"

    const-string/jumbo v1, "o.muaeues.yxluscimhiwtBE."

    const/4 v6, 0x6

    const-string/jumbo v1, "stuByseiqodle.um.Eihmcxwa"

    const-string v1, "com.huawei.system.BuildEx"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v6, 0x3

    const-string/jumbo v2, "nBratdOpgs"

    const/4 v6, 0x2

    const-string/jumbo v2, "rOsBgnsead"

    const-string/jumbo v2, "getOsBrand"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-array v3, v0, [Ljava/lang/Class;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v1, v2, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo v3, "mhnmaro"

    const-string v3, "aqohnrm"

    const/4 v6, 0x1

    const-string/jumbo v3, "myhaoor"

    const-string/jumbo v3, "harmony"

    const/4 v6, 0x7

    new-array v4, v0, [Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v2, v1, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    return v0

    :catch_0
    move-exception v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    return v0
.end method

.method public LogRecordAudioEffect(I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x5

    return p1
.end method

.method public OnAudioFocusChange(I)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    iget-wide v0, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    cmp-long v0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-wide v0, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v4, 0x0

    move v5, v4

    invoke-static {v0, v1, p1}, Lcom/zego/ve/AudioDevice;->OnAudioFocusChange(JI)V

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void
.end method

.method public OnAudioRouteChanged(I)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-wide v0, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    iget-wide v0, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, v1, p1}, Lcom/zego/ve/AudioDevice;->OnAudioRouteChanged(JI)V

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void
.end method

.method public OnInterruptionBegin()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-wide v0, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    cmp-long v0, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-wide v0, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v0, v1}, Lcom/zego/ve/AudioDevice;->OnInterruptionBegin(J)V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-void
.end method

.method public OnInterruptionEnd()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-wide v0, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v5, 0x1

    const/4 v4, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    cmp-long v0, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-wide v0, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v0, v1}, Lcom/zego/ve/AudioDevice;->OnInterruptionEnd(J)V

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method

.method public OnRoutingChange()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-wide v0, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    cmp-long v0, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-wide v0, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/16 v2, -0x64

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0, v1, v2}, Lcom/zego/ve/AudioDevice;->OnAudioRouteChanged(JI)V

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void
.end method

.method public SetAudioSource(I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lcom/zego/ve/AudioDevice;->_audio_source:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x1

    return p1
.end method

.method public SetCapProfile(I)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p1, p0, Lcom/zego/ve/AudioDevice;->_capProfile:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p1
.end method

.method public SetCaptureDevId(I)I
    .locals 8
    .annotation build Landroid/annotation/TargetApi;
        value = 0x17
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v1, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 v2, 0x0

    const/4 v7, 0x0

    move v3, v2

    move v3, v2

    const/4 v7, 0x1

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    array-length v4, v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v5, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-ge v3, v4, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    aget-object v4, v0, v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v4}, Landroid/media/AudioDeviceInfo;->getId()I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-ne p1, v4, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_1

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    move v3, v5

    move v3, v5

    const/4 v7, 0x0

    move v3, v5

    move v3, v5

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eq v5, v3, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    aget-object p1, v0, v3

    const/4 v7, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v1, 0x7

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-ne p1, v1, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v1}, Landroid/media/AudioManager;->isBluetoothScoOn()Z

    move-result v1

    const/4 v7, 0x2

    if-eqz v1, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v1}, Landroid/media/AudioRecord;->stop()V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    aget-object v0, v0, v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v1, v0}, Landroid/media/AudioRecord;->setPreferredDevice(Landroid/media/AudioDeviceInfo;)Z

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v7, 0x4

    invoke-virtual {v0}, Landroid/media/AudioRecord;->startRecording()V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto :goto_2

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v1, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_3

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v1}, Landroid/media/AudioRecord;->stop()V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v6, 0x2

    const/4 v6, 0x3

    aget-object v0, v0, v3

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-virtual {v1, v0}, Landroid/media/AudioRecord;->setPreferredDevice(Landroid/media/AudioDeviceInfo;)Z

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v7, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/media/AudioRecord;->startRecording()V

    :goto_2
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    move v1, v2

    move v1, v2

    const/4 v7, 0x1

    move v1, v2

    :goto_3
    const/4 v7, 0x5

    const/4 v6, 0x6

    move v2, p1

    move v2, p1

    const/4 v7, 0x6

    move v2, p1

    move v2, p1

    const/4 v6, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    goto :goto_4

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object p1, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p1}, Landroid/media/AudioRecord;->stop()V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object p1, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p1, v0}, Landroid/media/AudioRecord;->setPreferredDevice(Landroid/media/AudioDeviceInfo;)Z

    const/4 v7, 0x0

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p1}, Landroid/media/AudioRecord;->startRecording()V

    :goto_4
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    shl-int/lit8 p1, v2, 0x10

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    or-int/2addr p1, v1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    return p1
.end method

.method public SetCustomMode(I)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/zego/ve/KaraokeHelper;->SetCustomMode(I)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p1
.end method

.method public SetDuckConfig(ZI)I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v0, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput p2, v0, Lcom/zego/ve/AudioEventMonitor;->duck_value_in_percent_:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-boolean p1, v0, Lcom/zego/ve/AudioEventMonitor;->duck_other_when_voip_:Z

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v1, "nfsueetScCsudgkDictk rhoo_"

    const/4 v3, 0x0

    const-string v1, "cDturbS Ceoke:os_cuighndfk"

    const-string v1, "SetDuckConfig duck_others:"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string p1, "erpncku:tmc du"

    const-string/jumbo p1, "tcrm:cuep kden"

    const/4 v3, 0x6

    const-string/jumbo p1, "nrtd: epckue_p"

    const-string p1, " duck_percent:"

    const/4 v2, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string p2, "dvqcoe"

    const-string/jumbo p2, "idvcoe"

    const/4 v3, 0x5

    const-string/jumbo p2, "icsvde"

    const-string p2, "device"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p2, p1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x2

    return p1
.end method

.method public SetHWKaraokeReverbMode(I)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-virtual {v0, p1}, Lcom/zego/ve/KaraokeHelper;->SetHWKaraokeReverbMode(I)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return p1
.end method

.method public SetHWKaraokeVolume(I)I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/zego/ve/KaraokeHelper;->SetHWKaraokeVolume(I)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p1
.end method

.method public SetMode(I)I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/zego/ve/AudioEventMonitor;->SetMode(I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    return p1
.end method

.method public SetRenderDevId(I)I
    .locals 8
    .annotation build Landroid/annotation/TargetApi;
        value = 0x17
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 v1, 0x2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    move v3, v2

    move v3, v2

    const/4 v7, 0x6

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    array-length v4, v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/4 v5, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-ge v3, v4, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    aget-object v4, v0, v3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v4}, Landroid/media/AudioDeviceInfo;->getId()I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-ne p1, v4, :cond_0

    const/4 v7, 0x5

    goto :goto_1

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    move v3, v5

    move v3, v5

    const/4 v7, 0x1

    move v3, v5

    move v3, v5

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eq v5, v3, :cond_6

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    aget-object p1, v0, v3

    const/4 v6, 0x3

    move v7, v6

    invoke-virtual {p1}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 v4, 0x7

    if-ne p1, v4, :cond_2

    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v4, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v4}, Landroid/media/AudioManager;->isBluetoothScoOn()Z

    move-result v4

    const/4 v7, 0x7

    if-eqz v4, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v7, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/media/AudioTrack;->stop()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    aget-object v0, v0, v3

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v1, v0}, Landroid/media/AudioTrack;->setPreferredDevice(Landroid/media/AudioDeviceInfo;)Z

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroid/media/AudioTrack;->play()V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_2

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/16 v1, 0x8

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-ne p1, v1, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v1}, Landroid/media/AudioManager;->isBluetoothScoOn()Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-nez v1, :cond_3

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v6, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v1}, Landroid/media/AudioTrack;->stop()V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v7, 0x5

    const/4 v6, 0x2

    aget-object v0, v0, v3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v1, v0}, Landroid/media/AudioTrack;->setPreferredDevice(Landroid/media/AudioDeviceInfo;)Z

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0}, Landroid/media/AudioTrack;->play()V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto :goto_2

    :cond_3
    const/4 v6, 0x0

    const/4 v6, 0x4

    const/4 v1, 0x3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    goto :goto_3

    :cond_4
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v1}, Landroid/media/AudioTrack;->stop()V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    aget-object v0, v0, v3

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v1, v0}, Landroid/media/AudioTrack;->setPreferredDevice(Landroid/media/AudioDeviceInfo;)Z

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v6, 0x5

    move v7, v6

    invoke-virtual {v0}, Landroid/media/AudioTrack;->play()V

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    move v1, v2

    move v1, v2

    const/4 v7, 0x3

    move v1, v2

    move v1, v2

    :cond_5
    :goto_3
    const/4 v7, 0x7

    move v2, p1

    move v2, p1

    const/4 v7, 0x5

    move v2, p1

    move v2, p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    goto :goto_4

    :cond_6
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p1}, Landroid/media/AudioTrack;->stop()V

    const/4 v6, 0x3

    shr-int/2addr v7, v6

    iget-object p1, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {p1, v0}, Landroid/media/AudioTrack;->setPreferredDevice(Landroid/media/AudioDeviceInfo;)Z

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object p1, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p1}, Landroid/media/AudioTrack;->play()V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v1, 0x1

    :goto_4
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    shl-int/lit8 p1, v2, 0x10

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    or-int/2addr p1, v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    return p1
.end method

.method public SetStreamType(I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/zego/ve/AudioDevice;->_stream_type:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x3

    return p1
.end method

.method public SetThreadUrgentPriority()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/16 v0, -0x13

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0

    :catch_0
    move-exception v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    const/4 v0, -0x5

    const/4 v0, -0x1

    const/4 v2, 0x5

    return v0
.end method

.method public SetVivoKaraokeVolume(I)I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/zego/ve/KaraokeHelper;->SetVivoKaraokeVolume(I)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1
.end method

.method public SetXiaomiKaraokeVolume(I)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/zego/ve/KaraokeHelper;->SetXiaomiKaraokeVolume(I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return p1
.end method

.method public StartCapDev()I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v3, 0x3

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v0

    :cond_0
    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/media/AudioRecord;->startRecording()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getRecordingState()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eq v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, -0x3

    const/4 v3, 0x7

    return v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getAudioSessionId()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/zego/ve/AudioDevice;->LogRecordAudioEffect(I)I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v0

    :catch_0
    move-exception v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, -0x2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    return v0
.end method

.method public StartRndDev()I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v1, -0x1

    move v3, v1

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    return v1

    :cond_0
    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/media/AudioTrack;->play()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    return v0

    :catch_0
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return v1
.end method

.method public StopCapDev()I
    .locals 3

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/media/AudioRecord;->stop()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public StopModule()I
    .locals 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x17
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-wide v0, p0, Lcom/zego/ve/AudioDevice;->_pthis:J

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    sget-object v0, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lcom/zego/ve/AudioEventMonitor;->SetEeventHandler(Lcom/zego/ve/AudioEventMonitor$IEventNotify;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v2, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v2, v0}, Lcom/zego/ve/AudioEventMonitor;->SetMode(I)I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    sget-object v2, Lcom/zego/ve/AudioDevice;->event_monitor_stc_:Lcom/zego/ve/AudioEventMonitor;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v2, v0}, Lcom/zego/ve/AudioEventMonitor;->SetBluetoothScoOn(Z)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto :goto_0

    :catch_0
    move-exception v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/zego/ve/AudioDevice;->_audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-object v1, p0, Lcom/zego/ve/AudioDevice;->_audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    return v0
.end method

.method public StopRndDev()I
    .locals 3

    :try_start_0
    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/media/AudioTrack;->stop()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public SupportHWKaraokeLowlatency()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/zego/ve/KaraokeHelper;->SupportHWKaraokeLowlatency()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public SupportVivoKaraokeLowlatency()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/zego/ve/KaraokeHelper;->SupportVivoKaraokeLowlatency()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public SupportXiaomiKaraokeLowlatency()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/zego/ve/KaraokeHelper;->SupportXiaomiKaraokeLowlatency()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public UninitCapDev()I
    .locals 4
    .annotation build Landroid/annotation/TargetApi;
        value = 0x18
    .end annotation

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v3, 0x4

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/zego/ve/i;->a(Landroid/media/AudioRecord;Landroid/media/AudioRouting$OnRoutingChangedListener;)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/media/AudioRecord;->release()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_capDev:Landroid/media/AudioRecord;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    return v0
.end method

.method public UninitHWKtvEnv()I
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/zego/ve/KaraokeHelper;->UninitHWKtvEnv()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public UninitRndDev()I
    .locals 4
    .annotation build Landroid/annotation/TargetApi;
        value = 0x18
    .end annotation

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/zego/ve/AudioDevice;->_audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/zego/ve/h;->a(Landroid/media/AudioTrack;Landroid/media/AudioRouting$OnRoutingChangedListener;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/media/AudioTrack;->release()V

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    move v2, v0

    move v2, v0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/zego/ve/AudioDevice;->_rndDev:Landroid/media/AudioTrack;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    return v0
.end method

.method public UninitVivoKtvEnv()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/zego/ve/KaraokeHelper;->UninitVivoKtvEnv()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public UninitXiaomiKtvEnv()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/zego/ve/KaraokeHelper;->UninitXiaomiKtvEnv()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method createAudioTrack(IIII)Landroid/media/AudioTrack;
    .locals 11
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1a
    .end annotation

    const/4 v10, 0x7

    const/4 v0, 0x1

    const/4 v10, 0x6

    const/4 v1, 0x2

    const/4 v10, 0x1

    const/4 v2, 0x0

    const/4 v10, 0x5

    if-ne v1, p4, :cond_2

    :try_start_0
    const/4 v10, 0x3

    sget p4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v10, 0x0

    const/16 v3, 0x1a

    if-lt p4, v3, :cond_2

    const/4 v10, 0x1

    iget p4, p0, Lcom/zego/ve/AudioDevice;->_stream_type:I

    const/4 v10, 0x4

    const/4 v3, 0x3

    const/4 v10, 0x2

    if-ne v3, p4, :cond_0

    const/4 v10, 0x4

    move p4, v0

    move p4, v0

    move p4, v0

    move p4, v0

    const/4 v10, 0x3

    move v3, v1

    move v3, v1

    move v3, v1

    move v3, v1

    const/4 v10, 0x6

    goto :goto_0

    :cond_0
    const/4 v10, 0x6

    move v3, v0

    move v3, v0

    move v3, v0

    const/4 v10, 0x3

    move p4, v1

    move p4, v1

    move p4, v1

    :goto_0
    const/4 v10, 0x2

    new-instance v4, Landroid/media/AudioTrack$Builder;

    const/4 v10, 0x0

    invoke-direct {v4}, Landroid/media/AudioTrack$Builder;-><init>()V

    const/4 v10, 0x2

    new-instance v5, Landroid/media/AudioAttributes$Builder;

    const/4 v10, 0x0

    invoke-direct {v5}, Landroid/media/AudioAttributes$Builder;-><init>()V

    const/4 v10, 0x1

    invoke-virtual {v5, p4}, Landroid/media/AudioAttributes$Builder;->setUsage(I)Landroid/media/AudioAttributes$Builder;

    move-result-object p4

    const/4 v10, 0x6

    invoke-virtual {p4, v3}, Landroid/media/AudioAttributes$Builder;->setContentType(I)Landroid/media/AudioAttributes$Builder;

    move-result-object p4

    const/4 v10, 0x4

    invoke-virtual {p4}, Landroid/media/AudioAttributes$Builder;->build()Landroid/media/AudioAttributes;

    move-result-object p4

    const/4 v10, 0x7

    invoke-virtual {v4, p4}, Landroid/media/AudioTrack$Builder;->setAudioAttributes(Landroid/media/AudioAttributes;)Landroid/media/AudioTrack$Builder;

    move-result-object p4

    const/4 v10, 0x6

    new-instance v3, Landroid/media/AudioFormat$Builder;

    const/4 v10, 0x2

    invoke-direct {v3}, Landroid/media/AudioFormat$Builder;-><init>()V

    const/4 v10, 0x0

    invoke-virtual {v3, v1}, Landroid/media/AudioFormat$Builder;->setEncoding(I)Landroid/media/AudioFormat$Builder;

    move-result-object v3

    const/4 v10, 0x7

    invoke-virtual {v3, p2}, Landroid/media/AudioFormat$Builder;->setSampleRate(I)Landroid/media/AudioFormat$Builder;

    move-result-object v3

    const/4 v10, 0x1

    invoke-virtual {v3, p3}, Landroid/media/AudioFormat$Builder;->setChannelMask(I)Landroid/media/AudioFormat$Builder;

    move-result-object v3

    const/4 v10, 0x7

    invoke-virtual {v3}, Landroid/media/AudioFormat$Builder;->build()Landroid/media/AudioFormat;

    move-result-object v3

    const/4 v10, 0x7

    invoke-virtual {p4, v3}, Landroid/media/AudioTrack$Builder;->setAudioFormat(Landroid/media/AudioFormat;)Landroid/media/AudioTrack$Builder;

    move-result-object p4

    const/4 v10, 0x2

    invoke-virtual {p4, v0}, Landroid/media/AudioTrack$Builder;->setTransferMode(I)Landroid/media/AudioTrack$Builder;

    move-result-object p4

    const/4 v10, 0x0

    invoke-virtual {p4, p1}, Landroid/media/AudioTrack$Builder;->setBufferSizeInBytes(I)Landroid/media/AudioTrack$Builder;

    move-result-object p1

    const/4 v10, 0x0

    const/4 p4, 0x0

    const/4 v10, 0x5

    invoke-virtual {p1, p4}, Landroid/media/AudioTrack$Builder;->setSessionId(I)Landroid/media/AudioTrack$Builder;

    move-result-object p1

    const/4 v10, 0x6

    invoke-static {p1, v0}, Lcom/zego/ve/a;->a(Landroid/media/AudioTrack$Builder;I)Landroid/media/AudioTrack$Builder;

    move-result-object p1

    const/4 v10, 0x1

    invoke-virtual {p1}, Landroid/media/AudioTrack$Builder;->build()Landroid/media/AudioTrack;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v10, 0x5

    const/16 p4, 0xc

    const/4 v10, 0x5

    if-ne p4, p3, :cond_1

    const/4 v10, 0x2

    move p3, v1

    move p3, v1

    const/4 v10, 0x6

    goto :goto_1

    :cond_1
    const/4 v10, 0x2

    move p3, v0

    move p3, v0

    move p3, v0

    move p3, v0

    :goto_1
    const/4 v10, 0x6

    mul-int/lit8 p2, p2, 0xa

    const/4 v10, 0x0

    mul-int/2addr p2, p3

    const/4 v10, 0x4

    mul-int/2addr p2, v1

    :try_start_1
    const/4 v10, 0x6

    div-int/lit16 p2, p2, 0x3e8

    const/4 v10, 0x3

    invoke-static {p1, p2}, Lcom/zego/ve/b;->a(Landroid/media/AudioTrack;I)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v10, 0x2

    goto :goto_2

    :cond_2
    :try_start_2
    const/4 v10, 0x3

    new-instance p4, Landroid/media/AudioTrack;

    const/4 v10, 0x7

    iget v4, p0, Lcom/zego/ve/AudioDevice;->_stream_type:I

    const/4 v10, 0x7

    const/4 v7, 0x2

    const/4 v10, 0x2

    const/4 v9, 0x1

    move-object v3, p4

    move-object v3, p4

    move-object v3, p4

    move-object v3, p4

    const/4 v10, 0x3

    move v5, p2

    move v5, p2

    move v5, p2

    move v5, p2

    move v6, p3

    move v6, p3

    move v6, p3

    move v6, p3

    const/4 v10, 0x0

    move v8, p1

    move v8, p1

    move v8, p1

    move v8, p1

    const/4 v10, 0x4

    invoke-direct/range {v3 .. v9}, Landroid/media/AudioTrack;-><init>(IIIIII)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    move-object p1, p4

    move-object p1, p4

    move-object p1, p4

    move-object p1, p4

    :goto_2
    :try_start_3
    const/4 v10, 0x3

    invoke-virtual {p1}, Landroid/media/AudioTrack;->getState()I

    move-result p2

    const/4 v10, 0x0

    if-ne p2, v0, :cond_3

    const/4 v10, 0x5

    goto :goto_4

    :cond_3
    invoke-virtual {p1}, Landroid/media/AudioTrack;->release()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    const/4 v10, 0x7

    goto :goto_5

    :catch_0
    move-exception p2

    const/4 v10, 0x0

    goto :goto_3

    :catch_1
    move-exception p2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :goto_3
    const/4 v10, 0x1

    invoke-virtual {p2}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v10, 0x5

    if-eqz p1, :cond_4

    const/4 v10, 0x3

    invoke-virtual {p1}, Landroid/media/AudioTrack;->release()V

    const/4 v10, 0x3

    goto :goto_5

    :cond_4
    :goto_4
    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    :goto_5
    const/4 v10, 0x7

    return-object v2
.end method

.method public setEQParams(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/zego/ve/KaraokeHelper;->setEQParams(I)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public setReverbParams(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioDevice;->_Karaoke:Lcom/zego/ve/KaraokeHelper;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/zego/ve/KaraokeHelper;->setReverbParams(I)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method
