.class public Lcom/zego/ve/FileMediaDataSource;
.super Ljava/lang/Object;


# static fields
.field private static final TAG:Ljava/lang/String; = "FileMediaDataSource"


# instance fields
.field private uriFd:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput v0, p0, Lcom/zego/ve/FileMediaDataSource;->uriFd:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method private getAppDataPath(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@fs~~bi S~@/ vts/  ti iu~o~~~ @lab~~~@~@l~ ~~K@.~o  o ~ @~n M@c@~@@@  dy@1  ~@rm~4~o@o@~fo @@@@-"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p1, p1, Landroid/content/pm/ApplicationInfo;->dataDir:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method private initDataSource(Landroid/content/Context;Ljava/lang/String;Z)I
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/FileNotFoundException;
        }
    .end annotation

    const/4 v6, 0x4

    const-string/jumbo v0, "n:sp le feO"

    const/4 v6, 0x4

    const-string/jumbo v0, "linm  peeOf"

    const-string v0, "Open file: "

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const-string v2, ":iueoSutori e,tmDtncaiar n "

    const-string v2, "e SmnrirtaiticnouuDet:,e a "

    const/4 v6, 0x6

    const-string/jumbo v2, "recnibD  tuiitrn Soertaa,e:"

    const-string/jumbo v2, "initDataSource enter, uri: "

    const/4 v5, 0x3

    and-int/2addr v6, v5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v2, "roedaouScilDMaaFete"

    const-string v2, "SeeuodcoFataeaMlDri"

    const-string/jumbo v2, "uMecSaDprialioteFed"

    const-string v2, "FileMediaDataSource"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v2, v1}, Lcom/zego/ve/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {p2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz p3, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo p3, "r"

    const-string/jumbo p3, "r"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string/jumbo p3, "wr"

    const-string/jumbo p3, "rw"

    const/4 v6, 0x0

    const-string/jumbo p3, "rw"

    const-string/jumbo p3, "rw"

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-nez v4, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string/jumbo v4, "tqntenc"

    const-string v4, "content"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x4

    if-nez v4, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string/jumbo v4, "ilfe"

    const-string/jumbo v4, "iefl"

    const/4 v6, 0x2

    const-string/jumbo v4, "ifle"

    const-string/jumbo v4, "file"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v3, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_1

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo p3, "vnsi aaI phdt :"

    const-string/jumbo p3, "i I:tb dpavnha "

    const/4 v6, 0x4

    const-string p3, "Invalid path:  "

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v2, p1}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 p1, -0x2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    return p1

    :cond_2
    :goto_1
    :try_start_0
    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p1, v1, p3}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->detachFd()I

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    iput p1, p0, Lcom/zego/ve/FileMediaDataSource;->uriFd:I
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string p2, "ee m  gufsult ,dfcss"

    const-string p2, " s ftsuucd l ,fuseeg"

    const/4 v6, 0x6

    const-string/jumbo p2, "f cdof, gclst uues e"

    const-string p2, " successful, get fd "

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    iget p2, p0, Lcom/zego/ve/FileMediaDataSource;->uriFd:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v2, p1}, Lcom/zego/ve/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    const/4 v5, 0x2

    iget p1, p0, Lcom/zego/ve/FileMediaDataSource;->uriFd:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    return p1

    :catch_0
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object p3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string p3, "enwhebfiel it tio:pdpc x"

    const-string p3, " iicn ip:teoxfte ehw lpd"

    const/4 v6, 0x5

    const-string/jumbo p3, "xop a utiif:wte hc ednle"

    const-string p3, " failed with exception: "

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    invoke-static {v2, p1}, Lcom/zego/ve/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 p1, -0x1

    const/4 v6, 0x2

    const/4 v5, 0x6

    return p1
.end method
