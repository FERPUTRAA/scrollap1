.class public Lcom/zego/ve/PermissionChecker;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public static checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@osm4 @@t.~Mo v/n@f@ ~t-~~~@ 1o @y~@@i@~b~ool @~ l@ /~~K@~i@u~~ @s @ ~ br~@c~a f ~@~Sd@b ~  o~i~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x0

    const/4 v0, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez p0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    return v0

    :cond_0
    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string/jumbo v1, "nnomt.etsaCetixcnnddr.o"

    const-string/jumbo v1, "o.sxet.tnotdntdenriCnca"

    const/4 v7, 0x1

    const-string v1, "dnxnoanei.tocCtntore.td"

    const-string v1, "android.content.Context"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string/jumbo v2, "ocmfSbnrhkmescselPi"

    const-string/jumbo v2, "mlomirsecnkehPSsefc"

    const/4 v7, 0x2

    const-string/jumbo v2, "riiPeeukSneohmcfscs"

    const-string v2, "checkSelfPermission"

    const/4 v7, 0x4

    const/4 v3, 0x1

    const/4 v7, 0x2

    move v6, v3

    const/4 v7, 0x7

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const/4 v7, 0x3

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const/4 v7, 0x6

    aput-object v5, v4, v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x6

    aput-object p1, v2, v0

    const/4 v6, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v1, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    check-cast p0, Ljava/lang/Integer;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-nez p0, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    move v0, v3

    move v0, v3

    const/4 v7, 0x5

    move v0, v3

    move v0, v3

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    return v0
.end method
