.class Lcom/zego/ve/HwAudioKaraokeFeatureKit;
.super Ljava/lang/Object;


# instance fields
.field private mConnection:Landroid/content/ServiceConnection;

.field private mContext:Landroid/content/Context;

.field private mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

.field private mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

.field private mIHwAudioKaraokeFeatureAidl:Lcom/zego/ve/IHwAudioKaraokeFeature;

.field private mIsServiceConnected:Z

.field private mService:Landroid/os/IBinder;


# direct methods
.method protected constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-boolean v1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIsServiceConnected:Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mService:Landroid/os/IBinder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance v0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0, p0}, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;-><init>(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mConnection:Landroid/content/ServiceConnection;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$2;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, p0}, Lcom/zego/ve/HwAudioKaraokeFeatureKit$2;-><init>(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {}, Lcom/zego/ve/FeatureKitManager;->getInstance()Lcom/zego/ve/FeatureKitManager;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mContext:Landroid/content/Context;

    const/4 v3, 0x1

    return-void
.end method

.method static synthetic access$000(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Lcom/zego/ve/IHwAudioKaraokeFeature;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIHwAudioKaraokeFeatureAidl:Lcom/zego/ve/IHwAudioKaraokeFeature;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$002(Lcom/zego/ve/HwAudioKaraokeFeatureKit;Lcom/zego/ve/IHwAudioKaraokeFeature;)Lcom/zego/ve/IHwAudioKaraokeFeature;
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIHwAudioKaraokeFeatureAidl:Lcom/zego/ve/IHwAudioKaraokeFeature;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method

.method static synthetic access$102(Lcom/zego/ve/HwAudioKaraokeFeatureKit;Z)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    iput-boolean p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIsServiceConnected:Z

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic access$200(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Landroid/content/Context;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mContext:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$300(Lcom/zego/ve/HwAudioKaraokeFeatureKit;Ljava/lang/String;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->serviceInit(Ljava/lang/String;)I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    return p0
.end method

.method static synthetic access$400(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Lcom/zego/ve/FeatureKitManager;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic access$500(Lcom/zego/ve/HwAudioKaraokeFeatureKit;Landroid/os/IBinder;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->serviceLinkToDeath(Landroid/os/IBinder;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic access$600(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Landroid/os/IBinder$DeathRecipient;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$700(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mService:Landroid/os/IBinder;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$702(Lcom/zego/ve/HwAudioKaraokeFeatureKit;Landroid/os/IBinder;)Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mService:Landroid/os/IBinder;

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-object p1
.end method

.method private bindService(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-boolean v1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIsServiceConnected:Z

    const/4 v4, 0x3

    if-nez v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mConnection:Landroid/content/ServiceConnection;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v2, "easilideieevrtmuoiuK.iaorunoAwFeHaoew.dSeeekimcgthimaaaduu.nrc"

    const-string v2, "AwsoocKicuaeuaiuSgddiianekimmraut.vwrieetueoeir.eldamon.hFeHea"

    const/4 v4, 0x1

    const-string v2, "ecdmriomn.eiotiaoeruFkehH.vSeowaier.iAenuaugmluaiuwadteaimK.cd"

    const-string v2, "com.huawei.multimedia.audioengine.HwAudioKaraokeFeatureService"

    const/4 v4, 0x7

    invoke-virtual {v0, p1, v1, v2}, Lcom/zego/ve/FeatureKitManager;->bindService(Landroid/content/Context;Landroid/content/ServiceConnection;Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void
.end method

.method private serviceInit(Ljava/lang/String;)I
    .locals 4

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIHwAudioKaraokeFeatureAidl:Lcom/zego/ve/IHwAudioKaraokeFeature;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    iget-boolean v1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIsServiceConnected:Z

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Lcom/zego/ve/IHwAudioKaraokeFeature;->init(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const-string/jumbo v1, "temIocevrns"

    const-string/jumbo v1, "nevmsciIret"

    const/4 v3, 0x2

    const-string/jumbo v1, "vneribtesiI"

    const-string/jumbo v1, "serviceInit"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v0, "ooFeiuuwtiaaKreraKdHetku"

    const-string v0, "HwAudioKaraokeFeatureKit"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0, p1}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p1, -0x1

    :goto_0
    const/4 v2, 0x0

    move v3, v2

    return p1
.end method

.method private serviceLinkToDeath(Landroid/os/IBinder;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mService:Landroid/os/IBinder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-interface {p1, v0, v1}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :catch_0
    const/4 v3, 0x0

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/16 v0, 0x3ea

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    :cond_0
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method


# virtual methods
.method public destroy()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-boolean v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIsServiceConnected:Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x3

    shl-int/2addr v3, v0

    const/4 v4, 0x3

    iput-boolean v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIsServiceConnected:Z

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mContext:Landroid/content/Context;

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mConnection:Landroid/content/ServiceConnection;

    const/4 v4, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/zego/ve/FeatureKitManager;->unbindService(Landroid/content/Context;Landroid/content/ServiceConnection;)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void
.end method

.method public enableKaraokeFeature(Z)I
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIHwAudioKaraokeFeatureAidl:Lcom/zego/ve/IHwAudioKaraokeFeature;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-boolean v1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIsServiceConnected:Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Lcom/zego/ve/IHwAudioKaraokeFeature;->enableKaraokeFeature(Z)I

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    return p1

    :catch_0
    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 p1, -0x2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p1
.end method

.method protected initialize(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/zego/ve/FeatureKitManager;->isMediaKitSupport(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->bindService(Landroid/content/Context;)V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public setParameter(Ljava/lang/String;I)I
    .locals 4

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIHwAudioKaraokeFeatureAidl:Lcom/zego/ve/IHwAudioKaraokeFeature;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-boolean v1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->mIsServiceConnected:Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, p1, p2}, Lcom/zego/ve/IHwAudioKaraokeFeature;->setParameter(Ljava/lang/String;I)I

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    return p1

    :catch_0
    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p1, -0x2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    return p1
.end method
