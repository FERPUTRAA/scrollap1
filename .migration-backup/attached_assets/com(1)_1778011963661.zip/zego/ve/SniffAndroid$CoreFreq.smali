.class Lcom/zego/ve/SniffAndroid$CoreFreq;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/SniffAndroid;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "CoreFreq"
.end annotation


# instance fields
.field cur:I

.field max:I

.field min:I

.field num:I


# direct methods
.method constructor <init>(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->min:I

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    iput v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->max:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput p1, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->num:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/zego/ve/SniffAndroid;->access$000(I)I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->min:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/zego/ve/SniffAndroid;->access$100(I)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    iput p1, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->max:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method getCurUsage()I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ s@  v@o y~/tsli   @@@4~  -@~1@@@ KS@~o@f.ubl~~oc @~ ~@/i@i~f @~a@o~~m@~Mt~~brood~~~~ ~  n~ @@b"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/zego/ve/SniffAndroid$CoreFreq;->updateCurFreq()V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->max:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v1, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->min:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    sub-int v2, v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    if-lez v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-lez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    iget v2, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->cur:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-lez v2, :cond_0

    const/4 v4, 0x1

    sub-int/2addr v2, v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    mul-int/lit8 v2, v2, 0x64

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    sub-int/2addr v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    div-int/2addr v2, v0

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    return v2
.end method

.method updateCurFreq()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->num:I

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/zego/ve/SniffAndroid;->access$200(I)I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->cur:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->min:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->num:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/zego/ve/SniffAndroid;->access$000(I)I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->min:I

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->max:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->num:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/zego/ve/SniffAndroid;->access$100(I)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput v0, p0, Lcom/zego/ve/SniffAndroid$CoreFreq;->max:I

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method
