.class public Lcom/zego/ve/LooperHelper;
.super Ljava/lang/Object;


# static fields
.field private static gInstance:Lcom/zego/ve/LooperHelper;


# instance fields
.field private mHandler:Landroid/os/Handler;

.field private mThread:Landroid/os/HandlerThread;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/zego/ve/LooperHelper;->mThread:Landroid/os/HandlerThread;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/zego/ve/LooperHelper;->mHandler:Landroid/os/Handler;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Landroid/os/HandlerThread;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, "desa-opso"

    const-string v1, "eps-doaod"

    const-string/jumbo v1, "pddmoa-ol"

    const-string v1, "dead-loop"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/zego/ve/LooperHelper;->mThread:Landroid/os/HandlerThread;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/zego/ve/LooperHelper;->mThread:Landroid/os/HandlerThread;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/zego/ve/LooperHelper;->mHandler:Landroid/os/Handler;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method static synthetic access$000(JI)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~~.oMiy@~@o@~~f ov ~@/ot~~@~oit@ ~@b~ @1i @@~~s~@@  no@~  ~ u~b-/@@l4@@ ~r  Sac  d fl@mo~ ~~~K@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lcom/zego/ve/LooperHelper;->on_run(JI)I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p0
.end method

.method public static getInstance()Lcom/zego/ve/LooperHelper;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/zego/ve/LooperHelper;->gInstance:Lcom/zego/ve/LooperHelper;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance v0, Lcom/zego/ve/LooperHelper;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/zego/ve/LooperHelper;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    sput-object v0, Lcom/zego/ve/LooperHelper;->gInstance:Lcom/zego/ve/LooperHelper;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Lcom/zego/ve/LooperHelper;->gInstance:Lcom/zego/ve/LooperHelper;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method private static native on_run(JI)I
.end method

.method public static postMsg(JI)I
    .locals 4

    const/4 v2, 0x5

    move v3, v2

    invoke-static {}, Lcom/zego/ve/LooperHelper;->getInstance()Lcom/zego/ve/LooperHelper;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, v0, Lcom/zego/ve/LooperHelper;->mHandler:Landroid/os/Handler;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v1, Lcom/zego/ve/LooperHelper$1;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v1, p0, p1, p2}, Lcom/zego/ve/LooperHelper$1;-><init>(JI)V

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    return p0
.end method
