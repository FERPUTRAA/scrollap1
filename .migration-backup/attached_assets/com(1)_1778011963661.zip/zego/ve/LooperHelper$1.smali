.class Lcom/zego/ve/LooperHelper$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/LooperHelper;->postMsg(JI)I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$msg:I

.field final synthetic val$native_ptr:J


# direct methods
.method constructor <init>(JI)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/zego/ve/LooperHelper$1;->val$native_ptr:J

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p3, p0, Lcom/zego/ve/LooperHelper$1;->val$msg:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "l@sl~@~  tc ~m~~S~ oy@Mbo @~ii ~o@@ 1 ~@@ @K/~.@@vui r~o a@~d @~~ /~~~@f~@~o b4@  -f@bt~n@s@ ~~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-wide v0, p0, Lcom/zego/ve/LooperHelper$1;->val$native_ptr:J

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v2, p0, Lcom/zego/ve/LooperHelper$1;->val$msg:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0, v1, v2}, Lcom/zego/ve/LooperHelper;->access$000(JI)I

    const/4 v4, 0x7

    const/4 v3, 0x0

    return-void
.end method
