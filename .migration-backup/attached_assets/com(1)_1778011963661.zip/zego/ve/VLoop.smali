.class public Lcom/zego/ve/VLoop;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Handler$Callback;


# static fields
.field private static final MESSAGE_DELAYED:I = 0x3

.field private static final MESSAGE_EXIT:I = 0x1

.field private static final MESSAGE_LOOP:I = 0x2

.field private static final MESSAGE_START:I = 0x0

.field private static final TAG:Ljava/lang/String; = "vloop-"


# instance fields
.field private final lock:Ljava/lang/Object;

.field private mHandler:Landroid/os/Handler;

.field private mIsRunning:Z

.field private mNativeTag:Ljava/lang/String;

.field private mThread:Landroid/os/HandlerThread;

.field private pthis:J


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    or-int/2addr v3, v2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/zego/ve/VLoop;->pthis:J

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/zego/ve/VLoop;->mThread:Landroid/os/HandlerThread;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/zego/ve/VLoop;->mHandler:Landroid/os/Handler;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/zego/ve/VLoop;->mNativeTag:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/zego/ve/VLoop;->mIsRunning:Z

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/zego/ve/VLoop;->lock:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method private static native on_end(J)I
.end method

.method private static native on_msg_delayed(JJ)I
.end method

.method private static native on_run_loop(J)I
.end method

.method private static native on_start(J)I
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)Z
    .locals 7

    :try_start_0
    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@cs~ ~@@@ ~~o @u@d@ @o@ob~@~M~@sft~r@aoo .@~~~ ~@Kb mo@n~~   f-ly ~ ~i/~/i  1@bl@t4 ~iS@v @@~~~ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/zego/ve/VLoop;->lock:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    monitor-enter v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-boolean v1, p0, Lcom/zego/ve/VLoop;->mIsRunning:Z

    const/4 v5, 0x1

    const/4 v5, 0x5

    if-eqz v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget v1, p1, Landroid/os/Message;->what:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v2, 0x2

    move v6, v2

    if-ne v1, v2, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    iget-wide v1, p0, Lcom/zego/ve/VLoop;->pthis:J

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v1, v2}, Lcom/zego/ve/VLoop;->on_run_loop(J)I

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v2, 0x3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-ne v1, v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    iget-wide v1, p0, Lcom/zego/ve/VLoop;->pthis:J

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v6, 0x4

    check-cast p1, Ljava/lang/Long;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v1, v2, v3, v4}, Lcom/zego/ve/VLoop;->on_msg_delayed(JJ)I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-nez v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-wide v1, p0, Lcom/zego/ve/VLoop;->pthis:J

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v1, v2}, Lcom/zego/ve/VLoop;->on_start(J)I

    :cond_2
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v6, 0x5

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v5, 0x5

    const/4 v6, 0x5

    throw p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 p1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    return p1
.end method

.method public postMessage()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/VLoop;->mHandler:Landroid/os/Handler;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    return v0
.end method

.method public postMessageDelayed(JJ)I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {}, Landroid/os/Message;->obtain()Landroid/os/Message;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput v1, v0, Landroid/os/Message;->what:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object p1, v0, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/zego/ve/VLoop;->mHandler:Landroid/os/Handler;

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p1, v0, p3, p4}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    return p1
.end method

.method public setThis(JLjava/lang/String;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-wide p1, p0, Lcom/zego/ve/VLoop;->pthis:J

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/zego/ve/VLoop;->mNativeTag:Ljava/lang/String;

    const/4 v0, 0x7

    move v1, v0

    const/4 p1, 0x0

    move v1, p1

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return p1
.end method

.method public startLoop()I
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v0, Landroid/os/HandlerThread;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v2, "lpvmos"

    const-string/jumbo v2, "l-svop"

    const/4 v4, 0x2

    const-string/jumbo v2, "lopoo-"

    const-string/jumbo v2, "vloop-"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/zego/ve/VLoop;->mNativeTag:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/zego/ve/VLoop;->mThread:Landroid/os/HandlerThread;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance v0, Landroid/os/Handler;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/zego/ve/VLoop;->mThread:Landroid/os/HandlerThread;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, v1, p0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/zego/ve/VLoop;->mHandler:Landroid/os/Handler;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-boolean v0, p0, Lcom/zego/ve/VLoop;->mIsRunning:Z

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    return v1
.end method

.method public stopLoop()I
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/ve/VLoop;->lock:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    monitor-enter v0

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x0

    move v4, v1

    :try_start_0
    const/4 v5, 0x6

    iput-boolean v1, p0, Lcom/zego/ve/VLoop;->mIsRunning:Z

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/zego/ve/VLoop;->mHandler:Landroid/os/Handler;

    const/4 v4, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2, p0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x3

    move v4, v2

    move v4, v2

    const/4 v5, 0x3

    iput-object v2, p0, Lcom/zego/ve/VLoop;->mHandler:Landroid/os/Handler;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/zego/ve/VLoop;->mThread:Landroid/os/HandlerThread;

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quitSafely()Z

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    iput-object v2, p0, Lcom/zego/ve/VLoop;->mThread:Landroid/os/HandlerThread;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-wide v2, p0, Lcom/zego/ve/VLoop;->pthis:J

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v2, v3}, Lcom/zego/ve/VLoop;->on_end(J)I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v1

    :catchall_0
    move-exception v1

    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    throw v1
.end method
