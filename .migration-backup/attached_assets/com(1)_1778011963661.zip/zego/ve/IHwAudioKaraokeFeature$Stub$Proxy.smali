.class Lcom/zego/ve/IHwAudioKaraokeFeature$Stub$Proxy;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/zego/ve/IHwAudioKaraokeFeature;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/IHwAudioKaraokeFeature$Stub;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "Proxy"
.end annotation


# instance fields
.field private mRemote:Landroid/os/IBinder;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/zego/ve/IHwAudioKaraokeFeature$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s  br@~@l@~f/ ~~@ v @~n@M~@ ~~~@f1sdioo~@ @ i~oob  .to~u@~ /@-y~@otS~@~ i4@~~@l~b~ @~ acm K@ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/zego/ve/IHwAudioKaraokeFeature$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v2, 0x2

    const/4 v1, 0x4

    return-object v0
.end method

.method public enableKaraokeFeature(Z)I
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v2, "teomkaieldadmewitoaohmsoHrauiaeewneu..irIeidAgKnuu.um.iF"

    const-string/jumbo v2, "etsoih.damaatii.ue.Hn.iwomriolAiFkuaddIaKumgeawerneouuee"

    const/4 v5, 0x3

    const-string/jumbo v2, "iaigoddoetiu.imeilaum.ouaindeoaIorkeHtewu.AmeFneuw.Kchra"

    const-string v2, "com.huawei.multimedia.audioengine.IHwAudioKaraokeFeature"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v4, 0x4

    move v5, v4

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz p1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 p1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    move p1, v2

    move p1, v2

    const/4 v5, 0x6

    move p1, v2

    move p1, v2

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/zego/ve/IHwAudioKaraokeFeature$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    or-int/2addr v5, v4

    invoke-interface {p1, v3, v0, v1, v2}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v5, 0x2

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    return p1

    :catchall_0
    move-exception p1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x5

    shr-int/2addr v5, v4

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    throw p1
.end method

.method public getKaraokeLatency()I
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const-string/jumbo v2, "hmeaobkuiiruardudecwFeuiileo.dtmag.nwi..untiaoaIaAKemomH"

    const-string v2, "aIgmdtdoramFe.oehukwaiea.HioauKwmoiire.ndmauel.utcuAniei"

    const/4 v6, 0x4

    const-string v2, "eiuo.wurwkrgedeoAiihioHumdeuIineoe.naaeFamma.li.utaadtuK"

    const-string v2, "com.huawei.multimedia.audioengine.IHwAudioKaraokeFeature"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/zego/ve/IHwAudioKaraokeFeature$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v3, 0x3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    return v2

    :catchall_0
    move-exception v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    throw v2
.end method

.method public init(Ljava/lang/String;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v2, "Aameroipdlimdmeueawoeoew.oi.ra.aKakhFitdaiH.uIeugcnuunit"

    const-string v2, "com.huawei.multimedia.audioengine.IHwAudioKaraokeFeature"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/zego/ve/IHwAudioKaraokeFeature$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v2, 0x5

    shr-int/2addr v5, v2

    and-int/2addr v4, v2

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {p1, v2, v0, v1, v3}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    throw p1
.end method

.method public isKaraokeFeatureSupport()Z
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string v2, ".kIoaoo.qdadeKtiiunldanauFoiaeoAemtheeguaiuwm.ericHure.m"

    const-string/jumbo v2, "geewodeakImahoumKArt.iumaulieiadai.uocr.eoFaidennwotHe.u"

    const/4 v6, 0x2

    const-string v2, "aHso.iIuemgodcdaonw.h.teFirietaKmoiieraAauwiu.ndemlkuuae"

    const-string v2, "com.huawei.multimedia.audioengine.IHwAudioKaraokeFeature"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/zego/ve/IHwAudioKaraokeFeature$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v4, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-interface {v2, v4, v0, v1, v3}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    move v3, v4

    move v3, v4

    :cond_0
    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x6

    const/4 v5, 0x1

    return v3

    :catchall_0
    move-exception v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x5

    const/4 v5, 0x3

    throw v2
.end method

.method public setParameter(Ljava/lang/String;I)I
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v2, ".orma.Ftaewdiou.rAhItaolnmeiuniKoecaiHku.augwmeeieadiemd"

    const-string v2, "com.huawei.multimedia.audioengine.IHwAudioKaraokeFeature"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/zego/ve/IHwAudioKaraokeFeature$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 p2, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {p1, p2, v0, v1, v2}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    return p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    throw p1
.end method
