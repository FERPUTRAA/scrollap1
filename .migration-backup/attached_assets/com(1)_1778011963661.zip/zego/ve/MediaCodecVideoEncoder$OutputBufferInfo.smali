.class Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/MediaCodecVideoEncoder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "OutputBufferInfo"
.end annotation


# instance fields
.field public final buffer:Ljava/nio/ByteBuffer;

.field public final index:I

.field public final isKeyFrame:Z

.field public final presentationTimestampUs:J

.field public final size:I


# direct methods
.method public constructor <init>(ILjava/nio/ByteBuffer;IZJ)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;->index:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    iput-object p2, p0, Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;->buffer:Ljava/nio/ByteBuffer;

    const/4 v0, 0x5

    move v1, v0

    iput p3, p0, Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;->size:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-boolean p4, p0, Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;->isKeyFrame:Z

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-wide p5, p0, Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;->presentationTimestampUs:J

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method
