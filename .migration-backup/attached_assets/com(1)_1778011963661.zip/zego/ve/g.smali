.class public final synthetic Lcom/zego/ve/g;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/media/AudioManager;Landroid/media/AudioDeviceInfo;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@sdb~cm@@  @y~@~~@o~ ~nl @i@@b @@@@~@o~  v  So~~ /~ioMut~/  ~1~@~K4 -.fs~a ti@b~lo~@@o~r~@  @f~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroid/media/AudioManager;->setCommunicationDevice(Landroid/media/AudioDeviceInfo;)Z

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return p0
.end method
