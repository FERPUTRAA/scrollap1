.class public Lcom/zego/ve/SniffAndroid;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/SniffAndroid$CoreFreq;,
        Lcom/zego/ve/SniffAndroid$ProcStat;
    }
.end annotation


# static fields
.field private static final CPU_FILTER:Ljava/io/FileFilter;

.field private static final CPU_TEMP_FILE_PATHS:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final DEVICEINFO_UNKNOWN:I = -0x1

.field private static TAG:Ljava/lang/String; = "SniffAndroid"

.field private static mCoresFreq:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/zego/ve/SniffAndroid$CoreFreq;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field lastProcStat:Lcom/zego/ve/SniffAndroid$ProcStat;

.field private mAppContext:Landroid/content/Context;

.field private mGpuRenderer:Ljava/lang/String;

.field private mGpuVendor:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 18

    new-instance v0, Lcom/zego/ve/SniffAndroid$1;

    invoke-direct {v0}, Lcom/zego/ve/SniffAndroid$1;-><init>()V

    sput-object v0, Lcom/zego/ve/SniffAndroid;->CPU_FILTER:Ljava/io/FileFilter;

    const-string/jumbo v1, "pussefmptmr//pes/svessqy//iu_pccs/e/uy0cdcepu"

    const-string v1, "eesyiseudu/crpm_spcu/qstf/ucc/pyesvcpm/p/se0/"

    const-string v1, "c_/mrpcucpvypyussqec/tusiepe/emf/t/0c/md/eusp"

    const-string v1, "/sys/devices/system/cpu/cpu0/cpufreq/cpu_temp"

    const-string v2, "e/uuoihem_pousyarSkccmytemmpc/0/sp_fq/cvFpdspe/toeces/u"

    const-string v2, "ce_msuasc/eksfmc/0iSqmtp//oeuspuhupedropmtpec_e/syyvcF/"

    const-string/jumbo v2, "uop/tbeismcer_ssh_//qcy///Sdoummspcpk0ecFucsuetee/yvpaf"

    const-string v2, "/sys/devices/system/cpu/cpu0/cpufreq/FakeShmoo_cpu_temp"

    const-string v3, "aam/eeuato_otessmm/0prs/hntzlrs/l/ylc"

    const-string v3, "/zl/ossttoy/earm_h0slcm/e/tamaelrspne"

    const-string v3, "/sys/class/thermal/thermal_zone0/temp"

    const-string v4, "0-mrc-0pat/4yi/p2s2/aeasu-/eeldscprar//bcsict4e"

    const-string v4, "c/yrabaudspl02re/a2/mrap4c0-t4csseesi-t//ci/e4-"

    const-string v4, "/pr/-ysdq2erl40i-tc-sc/pue4/ecca0e/4amisrt2ata/"

    const-string v4, "/sys/class/i2c-adapter/i2c-4/4-004c/temperature"

    const-string v5, "aislc0gr//soy2rm-re/ea-t2tteae4s/vf3ipm.4e/uicpds-/eutr/0c"

    const-string/jumbo v5, "sgcs/0uryof/--40sr/umacip/-piee/cv2tir/lt2dme4/ae.reeat3ct"

    const-string v5, "2trma-m-ypleertsr02e/4vise4d/sc/.ec30m-ru4e/tac/iicpf//tgo"

    const-string v5, "/sys/devices/platform/tegra-i2c.3/i2c-4/4-004c/temperature"

    const-string/jumbo v6, "ymssom/erepvepe0o/a_nrappr_smm/l.piuart/c/etmsostaefd/teo"

    const-string v6, ".rplse_psat/o/ttcra/mpeesratn/mesoom/pm_mrseydepv/efu0aoi"

    const-string/jumbo v6, "omeaabirt/tcnto/_/omypepsmps/vepedafla//e0ersssr_.oepmtrm"

    const-string v6, "/sys/devices/platform/omap/omap_temp_sensor.0/temperature"

    const-string/jumbo v7, "trqn/tu/ulepomegfeiytai/_pdaenvtco//ssspm_m1"

    const-string/jumbo v7, "gieaf/mmqrpt_1ospctn/nysrtsiout//m/dpleeea_v"

    const-string/jumbo v7, "lteesp/pyid1tpvs/tipnte/mmg/ma_roetu_csarfno"

    const-string v7, "/sys/devices/platform/tegra_tmon/temp1_input"

    const-string/jumbo v8, "u///aldeqsps/tegleretn_bjergh_yakr/mest"

    const-string v8, "amse_gkbrtpe/lrde/taejytueh///n_ltsregs"

    const-string v8, "eps/luegkramt_mrsa//l_jehseyet/n/trdget"

    const-string v8, "/sys/kernel/debug/tegra_thermal/temp_tj"

    const-string/jumbo v9, "uy/mcfpe-du/mltmste/sr/ttsppveimeeaosa5rr"

    const-string v9, "-emm/pevtsatteyostuip/ml/pde/ears5rmrcs/f"

    const-string v9, "/sys/devices/platform/s5p-tmu/temperature"

    const-string/jumbo v10, "ser1ohlh_e/laplost/m/mn/mc/tseaetrayz"

    const-string v10, "amsmo_/z/p/smhoctaee/hlslrrtel1ytas/n"

    const-string v10, "/sys/class/thermal/thermal_zone1/temp"

    const-string/jumbo v11, "mp/mob/yuc0i/he_hotsw/dwv/sibeecpsnn1stnal"

    const-string/jumbo v11, "mpswebeowivmnnsol/se/ynhutmat0h1/pc/cs/_di"

    const-string v11, "/t//ehunwepslin/wcssn_scpoiteam0dovy1m/u/m"

    const-string v11, "/sys/class/hwmon/hwmon0/device/temp1_input"

    const-string/jumbo v12, "tct/ltupdhleueearalr_e/tmizs/yr/vmis/e1/psomahe"

    const-string/jumbo v12, "s/eecmuarsul/ditzseth/eht/ye/np_alitovrel1r/mam"

    const-string v12, "e1he/emtqeshs/od/tmar/e/vailalvts/cturemlpn_yir"

    const-string v12, "/sys/devices/virtual/thermal/thermal_zone1/temp"

    const-string/jumbo v13, "rzsumhte/tvvi/aees/mtdoelhc_pp/rlyatn/mlisese0r"

    const-string v13, "_tlhzsepcuptm/tavrhon/ae0l//irise/etelsmayrmedv"

    const-string v13, "/uimihe/rzemat/t/am0e//snrtdasspymvelctlvheoe_r"

    const-string v13, "/sys/devices/virtual/thermal/thermal_zone0/temp"

    const-string/jumbo v14, "l_leosnrstas/m/aqe/eylr3z/tshcepmohma"

    const-string/jumbo v14, "hlcn/sarqsmzo/tpy_emhmtestl/sal/ar3ee"

    const-string v14, "/sys/class/thermal/thermal_zone3/temp"

    const-string/jumbo v15, "hls/em_4atarnleterpc/otmm/zyslhss/ae/"

    const-string/jumbo v15, "s/alpbho/mmetlahet/s/eea/ss_4cnzltmrr"

    const-string v15, "/sys/class/thermal/thermal_zone4/temp"

    const-string/jumbo v16, "ho1m_mu/smXstwoin/pu//ystpl/wanmhce"

    const-string/jumbo v16, "wiump/h_p/a/y/lmhsnomctXno/newtm1ss"

    const-string/jumbo v16, "hs/st/mpes/pXyw/wml/_onnhmiopsac1tu"

    const-string v16, "/sys/class/hwmon/hwmonX/temp1_input"

    const-string/jumbo v17, "vrcume/yq/urml_f-t/s/orc5edpsmsotptiep/"

    const-string/jumbo v17, "sltro/er/5usts/pcei-cotrymudaevpmf/pm/_"

    const-string v17, "_asmmyodsrtm/fpe-icrte/pc//stpsur5sl/ve"

    const-string v17, "/sys/devices/platform/s5p-tmu/curr_temp"

    filled-new-array/range {v1 .. v17}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sput-object v0, Lcom/zego/ve/SniffAndroid;->CPU_TEMP_FILE_PATHS:Ljava/util/List;

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/zego/ve/SniffAndroid;->mAppContext:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string/jumbo v0, "nubmon"

    const-string/jumbo v0, "ounknb"

    const/4 v2, 0x7

    const-string/jumbo v0, "kwnnoo"

    const-string/jumbo v0, "unkown"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/zego/ve/SniffAndroid;->mGpuVendor:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    iput-object v0, p0, Lcom/zego/ve/SniffAndroid;->mGpuRenderer:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method private static ExecuteTop()Ljava/lang/String;
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x2

    const-string/jumbo v0, "lionnbtc puyo tgr inrgo dsd prarsc orisneos"

    const-string/jumbo v0, "rs gpsuocinelinrrrocpos noa  grsi oeydtndt "

    const/4 v9, 0x3

    const-string/jumbo v0, "snpedruredtaosir l niyst pi cro  gorcenoogn"

    const-string v0, "error in closing and destroying top process"

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string/jumbo v1, "pxetTeppcu"

    const-string/jumbo v1, "xTeuetppce"

    const/4 v9, 0x6

    const-string v1, "cuxeTeteqp"

    const-string/jumbo v1, "executeTop"

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/4 v2, 0x0

    :try_start_0
    const/4 v9, 0x5

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    const-string v4, "  s-t1qn"

    const-string/jumbo v4, "q-1t p n"

    const/4 v9, 0x1

    const-string/jumbo v4, "n  mopt-"

    const-string/jumbo v4, "top -n 1"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object v3
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto :goto_0

    :catchall_0
    move-exception v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v3, v2

    move-object v3, v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    goto/16 :goto_6

    :catch_0
    move-exception v3

    :try_start_1
    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v3}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_4
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :goto_0
    :try_start_2
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-instance v4, Ljava/io/BufferedReader;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    new-instance v5, Ljava/io/InputStreamReader;

    const/4 v8, 0x6

    move v9, v8

    invoke-virtual {v3}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct {v5, v6}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    invoke-direct {v4, v5}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_3
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-eqz v2, :cond_1

    :try_start_3
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string v5, ""

    const-string v5, ""

    const/4 v9, 0x4

    const-string v5, ""

    const-string v5, ""

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v2, v5}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v5
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v9, 0x0

    const/4 v8, 0x2

    if-eqz v5, :cond_0

    const/4 v8, 0x1

    move v9, v8

    goto :goto_2

    :cond_0
    :try_start_4
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {v4}, Ljava/io/BufferedReader;->close()V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v3}, Ljava/lang/Process;->destroy()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    goto/16 :goto_5

    :catch_1
    move-exception v3

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v3}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    goto :goto_5

    :cond_1
    :goto_2
    :try_start_5
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v4}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_2
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    goto :goto_1

    :catchall_1
    move-exception v2

    move-object v7, v4

    move-object v7, v4

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    goto :goto_6

    :catch_2
    move-exception v5

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    goto :goto_3

    :catchall_2
    move-exception v4

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    goto :goto_6

    :catch_3
    move-exception v5

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    const/4 v9, 0x2

    const/4 v8, 0x0

    goto :goto_3

    :catch_4
    move-exception v5

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :goto_3
    :try_start_6
    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    const-string v6, " ntnornf   ro glpstig eertoftisoir"

    const-string/jumbo v6, "rrssgl troien   fptneir nftio gote"

    const/4 v9, 0x1

    const-string/jumbo v6, "oorstb roeiltg n tpnr fgfieni  eti"

    const-string v6, "error in getting first line of top"

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v1, v6}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v5}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :try_start_7
    const/4 v8, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v3}, Ljava/lang/Process;->destroy()V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_5

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    goto :goto_4

    :catch_5
    move-exception v2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_4
    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    :goto_5
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    return-object v2

    :goto_6
    :try_start_8
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v3}, Ljava/lang/Process;->destroy()V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_6

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    goto :goto_7

    :catch_6
    move-exception v2

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_7
    const/4 v9, 0x2

    throw v4
.end method

.method private static ExtractValue([BI)I
    .locals 5

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    array-length v0, p0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-ge p1, v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    aget-byte v0, p0, p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/16 v1, 0xa

    const/4 v3, 0x0

    move v4, v3

    if-eq v0, v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v0}, Ljava/lang/Character;->isDigit(I)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x1

    add-int/lit8 v0, p1, 0x1

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    array-length v1, p0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-ge v0, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    aget-byte v1, p0, v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-static {v1}, Ljava/lang/Character;->isDigit(I)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    move v4, v3

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto :goto_1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    sub-int/2addr v0, p1

    const/4 v4, 0x1

    invoke-direct {v1, p0, v2, p1, v0}, Ljava/lang/String;-><init>([BIII)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    return p0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    add-int/lit8 p1, p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 p0, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    return p0
.end method

.method private GatherGlInfo()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 v0, 0x1f00

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-static {v0}, Landroid/opengl/GLES20;->glGetString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/zego/ve/SniffAndroid;->mGpuVendor:Ljava/lang/String;

    const/4 v1, 0x5

    move v2, v1

    const/16 v0, 0x1f01

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-static {v0}, Landroid/opengl/GLES20;->glGetString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/zego/ve/SniffAndroid;->mGpuRenderer:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method private GetBatteryLevel()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/ve/SniffAndroid;->mAppContext:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const-string v1, "bytemruraganme"

    const-string v1, "aemmrnerbgytaa"

    const/4 v3, 0x6

    const-string v1, "atyaeebprtarng"

    const-string v1, "batterymanager"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast v0, Landroid/os/BatteryManager;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/os/BatteryManager;->getIntProperty(I)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return v0
.end method

.method private static GetCPUMaxFreqKHz()I
    .locals 12

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v0, -0x1

    xor-int/2addr v11, v0

    :try_start_0
    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {}, Lcom/zego/ve/SniffAndroid;->GetNumberOfCPUCores()I

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    const/4 v2, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x3

    move v4, v0

    move v4, v0

    const/4 v11, 0x6

    move v4, v0

    move v4, v0

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    move v3, v2

    move v3, v2

    const/4 v11, 0x1

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-ge v3, v1, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    const-string/jumbo v6, "sv/smspeq/yiuce//tcueoscyds"

    const-string/jumbo v6, "vtyeoc/usyiucps/ssemdces///"

    const/4 v11, 0x5

    const-string v6, "/csypuesessiy/vtdcumsce///p"

    const-string v6, "/sys/devices/system/cpu/cpu"

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const-string/jumbo v6, "fuxmcb_cpier/ufm_rqq/fepa"

    const-string/jumbo v6, "rqrpobexpfcf_ui/u_/afecmq"

    const/4 v11, 0x6

    const-string/jumbo v6, "mrfioarfefcu/qoqc_p/uenxp"

    const-string v6, "/cpufreq/cpuinfo_max_freq"

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    new-instance v6, Ljava/io/File;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-direct {v6, v5}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    move-result v5

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    if-eqz v5, :cond_2

    const/4 v10, 0x2

    move v11, v10

    invoke-virtual {v6}, Ljava/io/File;->canRead()Z

    move-result v5

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-eqz v5, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    const/16 v5, 0x80

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    new-array v7, v5, [B

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-instance v8, Ljava/io/FileInputStream;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-direct {v8, v6}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    const/4 v11, 0x6

    const/4 v10, 0x6

    invoke-virtual {v8, v7}, Ljava/io/FileInputStream;->read([B)I

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    move v6, v2

    const/4 v11, 0x0

    move v6, v2

    move v6, v2

    :goto_1
    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    aget-byte v9, v7, v6

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static {v9}, Ljava/lang/Character;->isDigit(I)Z

    move-result v9

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    if-eqz v9, :cond_0

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-ge v6, v5, :cond_0

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    add-int/lit8 v6, v6, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x4

    goto :goto_1

    :cond_0
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    new-instance v5, Ljava/lang/String;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-direct {v5, v7, v2, v6}, Ljava/lang/String;-><init>([BII)V

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v6

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-le v6, v4, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x0

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v4
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    :cond_1
    :try_start_2
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {v8}, Ljava/io/FileInputStream;->close()V

    const/4 v11, 0x6

    goto :goto_2

    :catchall_0
    move-exception v1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v8}, Ljava/io/FileInputStream;->close()V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x2

    throw v1

    :cond_2
    :goto_2
    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    goto/16 :goto_0

    :cond_3
    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-ne v4, v0, :cond_5

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x6

    new-instance v1, Ljava/io/FileInputStream;

    const/4 v11, 0x5

    const-string v2, "cfnp/b/uiporo"

    const-string v2, "cop/cnuoprf/i"

    const/4 v11, 0x7

    const-string/jumbo v2, "ofc/pcurupion"

    const-string v2, "/proc/cpuinfo"

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-direct {v1, v2}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    :try_start_3
    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-string/jumbo v2, "ppcMH u"

    const-string v2, "cpu MHz"

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {v2, v1}, Lcom/zego/ve/SniffAndroid;->ParseFileForValue(Ljava/lang/String;Ljava/io/FileInputStream;)I

    move-result v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    mul-int/lit16 v2, v2, 0x3e8

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    if-le v2, v4, :cond_4

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    move v4, v2

    move v4, v2

    const/4 v11, 0x2

    move v4, v2

    :cond_4
    :try_start_4
    const/4 v10, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V

    const/4 v11, 0x7

    goto :goto_3

    :catchall_1
    move-exception v2

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V

    const/4 v10, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    throw v2
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1

    :cond_5
    :goto_3
    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    move v0, v4

    move v0, v4

    const/4 v11, 0x1

    move v0, v4

    move v0, v4

    :catch_1
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    sget-object v1, Lcom/zego/ve/SniffAndroid;->TAG:Ljava/lang/String;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    const-string v3, " xpmeq:rq"

    const-string v3, "eqr a:xpm"

    const/4 v11, 0x1

    const-string/jumbo v3, "r:sfma xq"

    const-string/jumbo v3, "max freq:"

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-static {v1, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    return v0
.end method

.method private static GetCoresFromCPUFileList()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Ljava/io/File;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo v1, "ssempsmiv//eusydtyc/sc//"

    const-string v1, "/sys/devices/system/cpu/"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    sget-object v1, Lcom/zego/ve/SniffAndroid;->CPU_FILTER:Ljava/io/FileFilter;

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    array-length v0, v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return v0
.end method

.method private static GetCoresFromFileInfo(Ljava/lang/String;)I
    .locals 4

    const/4 v3, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v1, Ljava/io/FileInputStream;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Ljava/io/FileInputStream;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance p0, Ljava/io/BufferedReader;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Ljava/io/InputStreamReader;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/io/BufferedReader;->close()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/zego/ve/SniffAndroid;->GetCoresFromFileString(Ljava/lang/String;)I

    move-result p0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return p0

    :catchall_0
    move-exception p0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :catch_1
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_1

    :catchall_1
    move-exception p0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    :try_start_3
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_2

    :catch_2
    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    throw p0

    :catch_3
    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    :try_start_4
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/io/InputStream;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_4

    :catch_4
    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 p0, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return p0
.end method

.method private static GetCoresFromFileString(Ljava/lang/String;)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz p0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string v0, "d[]0oq-+/"

    const-string v0, "+0]$-/[dq"

    const/4 v2, 0x5

    const-string v0, "d0-//b+$["

    const-string v0, "0-[\\d]+$"

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    add-int/lit8 p0, p0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p0

    :cond_1
    :goto_0
    const/4 v1, 0x6

    move v2, v1

    const/4 p0, -0x3

    const/4 p0, -0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    return p0
.end method

.method public static GetCpuUsage([I)I
    .locals 6

    const/4 v4, 0x1

    move v5, v4

    array-length v0, p0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v1, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-ge v0, v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    return v2

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    array-length v3, p0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-ge v1, v3, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    aget v3, p0, v1

    const/4 v5, 0x7

    if-lez v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    add-int/2addr v2, v3

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v5, 0x1

    array-length p0, p0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    sub-int/2addr p0, v0

    const/4 v5, 0x1

    div-int/2addr v2, p0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    return v2
.end method

.method public static GetCpuUsageBaseTop()I
    .locals 10

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/4 v0, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/4 v1, 0x3

    :try_start_0
    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    new-array v2, v1, [I

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    move v3, v0

    move v3, v0

    const/4 v9, 0x1

    move v3, v0

    move v3, v0

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x0

    if-ge v3, v1, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x6

    invoke-static {}, Lcom/zego/ve/SniffAndroid;->GetCpuUsageStatistic()[I

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    move v5, v0

    move v5, v0

    const/4 v9, 0x5

    move v5, v0

    move v5, v0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    move v6, v5

    move v6, v5

    const/4 v9, 0x3

    move v6, v5

    move v6, v5

    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    array-length v7, v4

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-ge v5, v7, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    aget v7, v4, v5

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    add-int/2addr v6, v7

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    add-int/lit8 v5, v5, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto :goto_1

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    aput v6, v2, v3

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    goto :goto_0

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x0

    move v3, v0

    move v3, v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    move v4, v3

    move v4, v3

    const/4 v9, 0x5

    move v4, v3

    :goto_2
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-ge v3, v1, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x2

    aget v5, v2, v3

    const/4 v8, 0x1

    const/4 v9, 0x2

    add-int/2addr v4, v5

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    goto :goto_2

    :cond_2
    const/4 v9, 0x2

    div-int/2addr v4, v1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    return v4

    :catch_0
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    return v0
.end method

.method private static GetCpuUsageStatistic()[I
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {}, Lcom/zego/ve/SniffAndroid;->ExecuteTop()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string v1, ","

    const-string v1, ","

    const/4 v6, 0x6

    const-string v1, ","

    const-string v1, ","

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x7

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string v1, "eUrs"

    const-string/jumbo v1, "sUer"

    const/4 v6, 0x3

    const-string v1, "Urse"

    const-string v1, "User"

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string/jumbo v1, "uesmsS"

    const-string/jumbo v1, "myssSe"

    const/4 v6, 0x5

    const-string v1, "System"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string v1, "IOW"

    const-string v1, "WOI"

    const/4 v6, 0x4

    const-string v1, "IOW"

    const-string v1, "IOW"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v1, "RQI"

    const-string v1, "RQI"

    const/4 v6, 0x3

    const-string v1, "IQR"

    const-string v1, "IRQ"

    const/4 v6, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string v1, "%"

    const-string v1, "%"

    const/4 v6, 0x4

    const-string v1, "%"

    const-string v1, "%"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v1, 0x0

    const/4 v6, 0x1

    move v2, v1

    move v2, v1

    const/4 v6, 0x2

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/16 v3, 0xa

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string v4, " "

    const/4 v6, 0x1

    const-string v4, " "

    const-string v4, " "

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-ge v2, v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v3, "  "

    const-string v3, "  "

    const/4 v6, 0x6

    const-string v3, "  "

    const-string v3, "  "

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0, v3, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    array-length v2, v0

    new-array v2, v2, [I

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    array-length v3, v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-ge v1, v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    aget-object v3, v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    aput-object v3, v0, v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    aput v3, v2, v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    return-object v2
.end method

.method public static GetNbCores()I
    .locals 4

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Ljava/io/File;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v1, "i//syvppdmem/cus//ycesst"

    const-string v1, "/uemccsdysi/t/mepe/v/yss"

    const/4 v3, 0x6

    const-string/jumbo v1, "y/tdms/yqiecscs/evp/seu/"

    const-string v1, "/sys/devices/system/cpu/"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v1, Lcom/zego/ve/SniffAndroid$1CpuFilter;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v1}, Lcom/zego/ve/SniffAndroid$1CpuFilter;-><init>()V

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    array-length v0, v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return v0

    :catch_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    return v0
.end method

.method private static GetNumberOfCPUCores()I
    .locals 6

    const/4 v4, 0x3

    move v5, v4

    const/4 v0, -0x1

    move v5, v0

    :try_start_0
    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v1, "/po/o//eseyisedcsyssbpvsclti/eus"

    const/4 v5, 0x6

    const-string/jumbo v1, "sisycetes/lvys/sssop/biue//spedc"

    const-string v1, "/sys/devices/system/cpu/possible"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/zego/ve/SniffAndroid;->GetCoresFromFileInfo(Ljava/lang/String;)I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-ne v1, v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo v1, "uvtmcs/yee/rsmbn/sedspcy/ses/ei"

    const-string/jumbo v1, "ssrpeb/pts/ecsescmdy//uvesen/yi"

    const/4 v5, 0x7

    const-string v1, "/sys/devices/system/cpu/present"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/zego/ve/SniffAndroid;->GetCoresFromFileInfo(Ljava/lang/String;)I

    move-result v1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ne v1, v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {}, Lcom/zego/ve/SniffAndroid;->GetCoresFromCPUFileList()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x5

    move v0, v1

    move v0, v1

    const/4 v5, 0x4

    move v0, v1

    :catch_0
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    sget-object v1, Lcom/zego/ve/SniffAndroid;->TAG:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v3, "ruo:oe"

    const-string/jumbo v3, "u:ecor"

    const-string/jumbo v3, "r:secb"

    const-string v3, "cores:"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v1, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    return v0
.end method

.method private static GetTotalMemory(Landroid/content/Context;)J
    .locals 6

    const/4 v5, 0x7

    new-instance v0, Landroid/app/ActivityManager$MemoryInfo;

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-direct {v0}, Landroid/app/ActivityManager$MemoryInfo;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v1, "tativpuy"

    const-string v1, "aytctvip"

    const/4 v5, 0x5

    const-string/jumbo v1, "titycivp"

    const-string v1, "activity"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0, v0}, Landroid/app/ActivityManager;->getMemoryInfo(Landroid/app/ActivityManager$MemoryInfo;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget-object p0, Lcom/zego/ve/SniffAndroid;->TAG:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    move v5, v4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v2, " otlq:etqa"

    const-string v2, "aet l:tmqo"

    const/4 v5, 0x1

    const-string/jumbo v2, "o:samme tt"

    const-string/jumbo v2, "total mem:"

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-wide v2, v0, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-wide v0, v0, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-wide v0
.end method

.method public static InitCoresFreq()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget-object v0, Lcom/zego/ve/SniffAndroid;->mCoresFreq:Ljava/util/ArrayList;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {}, Lcom/zego/ve/SniffAndroid;->GetNbCores()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    new-instance v1, Ljava/util/ArrayList;

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    sput-object v1, Lcom/zego/ve/SniffAndroid;->mCoresFreq:Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-ge v1, v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object v2, Lcom/zego/ve/SniffAndroid;->mCoresFreq:Ljava/util/ArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance v3, Lcom/zego/ve/SniffAndroid$CoreFreq;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v3, v1}, Lcom/zego/ve/SniffAndroid$CoreFreq;-><init>(I)V

    const/4 v4, 0x1

    shr-int/2addr v5, v4

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    int-to-byte v1, v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-void
.end method

.method private static ParseFileForValue(Ljava/lang/String;Ljava/io/FileInputStream;)I
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/16 v0, 0x400

    const/4 v7, 0x6

    new-array v0, v0, [B

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p1, v0}, Ljava/io/FileInputStream;->read([B)I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    if-ge v1, p1, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    aget-byte v2, v0, v1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/16 v3, 0xa

    if-eq v2, v3, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-nez v1, :cond_4

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-ne v2, v3, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x3

    add-int/lit8 v1, v1, 0x1

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    move v2, v1

    move v2, v1

    const/4 v7, 0x4

    move v2, v1

    move v2, v1

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x4

    if-ge v2, p1, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    sub-int v3, v2, v1

    const/4 v7, 0x7

    aget-byte v4, v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eq v4, v5, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    goto :goto_2

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x0

    add-int/lit8 v4, v4, -0x1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-ne v3, v4, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {v0, v2}, Lcom/zego/ve/SniffAndroid;->ExtractValue([BI)I

    move-result p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    return p0

    :cond_3
    const/4 v7, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto :goto_1

    :cond_4
    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :catch_0
    :cond_5
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 p0, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    return p0
.end method

.method private ReadIdleAndRunTime()Lcom/zego/ve/SniffAndroid$ProcStat;
    .locals 16

    const/4 v1, 0x0

    :try_start_0
    new-instance v2, Ljava/io/FileReader;

    const-string/jumbo v0, "rtamc/sost"

    const-string/jumbo v0, "ptsac/ostr"

    const-string/jumbo v0, "so/cotrpt/"

    const-string v0, "/proc/stat"

    invoke-direct {v2, v0}, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    new-instance v0, Ljava/io/BufferedReader;

    invoke-direct {v0, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    new-instance v3, Ljava/util/Scanner;

    invoke-direct {v3, v0}, Ljava/util/Scanner;-><init>(Ljava/lang/Readable;)V

    invoke-virtual {v3}, Ljava/util/Scanner;->next()Ljava/lang/String;

    invoke-virtual {v3}, Ljava/util/Scanner;->nextLong()J

    move-result-wide v4

    invoke-virtual {v3}, Ljava/util/Scanner;->nextLong()J

    move-result-wide v6

    invoke-virtual {v3}, Ljava/util/Scanner;->nextLong()J

    move-result-wide v8

    add-long/2addr v4, v6

    add-long v12, v4, v8

    invoke-virtual {v3}, Ljava/util/Scanner;->nextLong()J

    move-result-wide v14

    invoke-virtual {v3}, Ljava/util/Scanner;->close()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v2}, Ljava/io/Reader;->close()V
    :try_end_2
    .catch Ljava/io/FileNotFoundException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1

    new-instance v0, Lcom/zego/ve/SniffAndroid$ProcStat;

    move-object v10, v0

    move-object v10, v0

    move-object v10, v0

    move-object v10, v0

    move-object/from16 v11, p0

    move-object/from16 v11, p0

    move-object/from16 v11, p0

    move-object/from16 v11, p0

    invoke-direct/range {v10 .. v15}, Lcom/zego/ve/SniffAndroid$ProcStat;-><init>(Lcom/zego/ve/SniffAndroid;JJ)V

    return-object v0

    :catchall_0
    move-exception v0

    goto :goto_0

    :catch_0
    :try_start_3
    sget-object v0, Lcom/zego/ve/SniffAndroid;->TAG:Ljava/lang/String;

    const-string v3, " rppsbmbmP/nrl iagetca/toos"

    const-string/jumbo v3, "trom/p g mcisbnPesar/parolt"

    const-string v3, "c/isgpuaalnPtos/ sr tmeporr"

    const-string v3, "Problems parsing /proc/stat"

    invoke-static {v0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    invoke-virtual {v2}, Ljava/io/Reader;->close()V

    return-object v1

    :goto_0
    invoke-virtual {v2}, Ljava/io/Reader;->close()V

    throw v0
    :try_end_4
    .catch Ljava/io/FileNotFoundException; {:try_start_4 .. :try_end_4} :catch_2
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1

    :catch_1
    sget-object v0, Lcom/zego/ve/SniffAndroid;->TAG:Ljava/lang/String;

    const-string v2, "eodsotsroP/ aba rletmni/rgp"

    const-string v2, "a /ioreposb/tmdptalPnr cesg"

    const-string v2, "Problems reading /proc/stat"

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1

    :catch_2
    sget-object v0, Lcom/zego/ve/SniffAndroid;->TAG:Ljava/lang/String;

    const-string/jumbo v2, "isbo orrqnpgatfc/ntCdan o /terep n"

    const-string v2, "d rn btotonCfo/rg/tanp  icraposeen"

    const-string/jumbo v2, "nosa /a igsfoappon/trtrendtC nerco"

    const-string v2, "Cannot open /proc/stat for reading"

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-object v1
.end method

.method private static ReadIntegerFile(Ljava/lang/String;)I
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v1, Ljava/io/RandomAccessFile;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v2, "r"

    const-string/jumbo v2, "r"

    const/4 v4, 0x4

    const-string/jumbo v2, "r"

    const-string/jumbo v2, "r"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v1, p0, v2}, Ljava/io/RandomAccessFile;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/io/RandomAccessFile;->readLine()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/io/RandomAccessFile;->close()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/io/RandomAccessFile;->close()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    throw p0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    return v0
.end method

.method private ReadOneLine(Ljava/io/File;)D
    .locals 7

    const/4 v6, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-wide v2, -0x3f07960000000000L    # -100000.0

    const-wide v2, -0x3f07960000000000L    # -100000.0

    const/4 v6, 0x7

    const-wide v2, -0x3f07960000000000L    # -100000.0

    const-wide v2, -0x3f07960000000000L    # -100000.0

    const/4 v6, 0x3

    const/4 v5, 0x6

    if-eqz v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/io/File;->canRead()Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_1

    :cond_0
    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance v1, Ljava/io/FileInputStream;

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {v1, p1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    new-instance p1, Ljava/io/InputStreamReader;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {p1, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v4, Ljava/io/BufferedReader;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {v4, p1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v4}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/io/InputStreamReader;->close()V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v4}, Ljava/io/BufferedReader;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    :try_start_1
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v0}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v2
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :cond_1
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-wide v2
.end method

.method static synthetic access$000(I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/zego/ve/SniffAndroid;->getMinCpuFreq(I)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic access$100(I)I
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/zego/ve/SniffAndroid;->getMaxCpuFreq(I)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    return p0
.end method

.method static synthetic access$200(I)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/zego/ve/SniffAndroid;->getCurCpuFreq(I)I

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p0
.end method

.method public static declared-synchronized getCoresUsageGuessFromFreq()[I
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x0

    const-class v0, Lcom/zego/ve/SniffAndroid;

    const-class v0, Lcom/zego/ve/SniffAndroid;

    const/4 v7, 0x1

    const-class v0, Lcom/zego/ve/SniffAndroid;

    const-class v0, Lcom/zego/ve/SniffAndroid;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x1

    invoke-static {}, Lcom/zego/ve/SniffAndroid;->InitCoresFreq()V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    sget-object v1, Lcom/zego/ve/SniffAndroid;->mCoresFreq:Ljava/util/ArrayList;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-array v1, v1, [I

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 v2, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    aput v2, v1, v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    move v3, v2

    move v3, v2

    const/4 v7, 0x0

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    sget-object v4, Lcom/zego/ve/SniffAndroid;->mCoresFreq:Ljava/util/ArrayList;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x0

    if-ge v3, v4, :cond_0

    const/4 v7, 0x3

    add-int/lit8 v4, v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x0

    sget-object v5, Lcom/zego/ve/SniffAndroid;->mCoresFreq:Ljava/util/ArrayList;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    check-cast v3, Lcom/zego/ve/SniffAndroid$CoreFreq;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v3}, Lcom/zego/ve/SniffAndroid$CoreFreq;->getCurUsage()I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    aput v3, v1, v4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    aget v5, v1, v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    add-int/2addr v5, v3

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    aput v5, v1, v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    int-to-byte v3, v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    sget-object v3, Lcom/zego/ve/SniffAndroid;->mCoresFreq:Ljava/util/ArrayList;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-lez v3, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    aget v3, v1, v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    sget-object v4, Lcom/zego/ve/SniffAndroid;->mCoresFreq:Ljava/util/ArrayList;

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    div-int/2addr v3, v4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    aput v3, v1, v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    monitor-exit v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    monitor-exit v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    throw v1
.end method

.method private static getCurCpuFreq(I)I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v1, "/cpmeue/v/pymus//tcsesiudcs"

    const-string v1, "/sspveusutyc/ccd/mesi/sp/eu"

    const/4 v3, 0x2

    const-string v1, "/cesocempp/ceuiy/tsdysuv/ss"

    const-string v1, "/sys/devices/system/cpu/cpu"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const-string/jumbo p0, "spuilbr_u/cnq/rgcqferpe_c"

    const-string/jumbo p0, "qf/ur_epqr/regfcnpcscilu_"

    const/4 v3, 0x0

    const-string/jumbo p0, "fqfuaruegc_s_leurrnpcqi//"

    const-string p0, "/cpufreq/scaling_cur_freq"

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/zego/ve/SniffAndroid;->ReadIntegerFile(Ljava/lang/String;)I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return p0
.end method

.method private static getMaxCpuFreq(I)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "is/pcespusec/cdmyty/v/ssuqe"

    const-string v1, "es//yesuqcm/ucye/disscvtsp/"

    const/4 v3, 0x0

    const-string/jumbo v1, "ps/suipcq/vc//smytscsye/ude"

    const-string v1, "/sys/devices/system/cpu/cpu"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const-string/jumbo p0, "mcsn_cqieuapof/_ser/rqfuf"

    const-string/jumbo p0, "q/sprrupqfcianff_/uec_moe"

    const/4 v3, 0x3

    const-string/jumbo p0, "opam_pxnm_ifrfu/qequfcec/"

    const-string p0, "/cpufreq/cpuinfo_max_freq"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/zego/ve/SniffAndroid;->ReadIntegerFile(Ljava/lang/String;)I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return p0
.end method

.method private static getMinCpuFreq(I)I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string v1, "/yspo/e/esccu/imetcysv/upms"

    const-string/jumbo v1, "uyvm/ms//sc/ceiepytecup/sds"

    const-string/jumbo v1, "mys/eb/espysutccsd/vui/ecs/"

    const-string v1, "/sys/devices/system/cpu/cpu"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string p0, "ef/c_cunofpremqiui/or_qfu"

    const-string/jumbo p0, "ncico//nefoqrmq_if_uerufp"

    const/4 v3, 0x0

    const-string/jumbo p0, "ufuoieqp/pnrff_qr_pcnimc/"

    const-string p0, "/cpufreq/cpuinfo_min_freq"

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/zego/ve/SniffAndroid;->ReadIntegerFile(Ljava/lang/String;)I

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    return p0
.end method

.method private isEGL14SupportedHere()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method private isTemperatureValid(D)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-wide/high16 v0, -0x3fc2000000000000L    # -30.0

    const-wide/high16 v0, -0x3fc2000000000000L    # -30.0

    const/4 v3, 0x4

    const-wide/high16 v0, -0x3fc2000000000000L    # -30.0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    cmpl-double v0, p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ltz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-wide v0, 0x406f400000000000L    # 250.0

    const-wide v0, 0x406f400000000000L    # 250.0

    const/4 v3, 0x1

    const-wide v0, 0x406f400000000000L    # 250.0

    const-wide v0, 0x406f400000000000L    # 250.0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    cmpg-double p1, p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-gtz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v3, 0x3

    return p1
.end method


# virtual methods
.method public CheckBackground()Z
    .locals 4

    new-instance v0, Landroid/app/ActivityManager$RunningAppProcessInfo;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0}, Landroid/app/ActivityManager$RunningAppProcessInfo;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0}, Landroid/app/ActivityManager;->getMyMemoryState(Landroid/app/ActivityManager$RunningAppProcessInfo;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v0, v0, Landroid/app/ActivityManager$RunningAppProcessInfo;->importance:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/16 v1, 0x64

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eq v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/16 v1, 0xc8

    const/4 v3, 0x4

    if-eq v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v0
.end method

.method public GetBattery()I
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/zego/ve/SniffAndroid;->GetBatteryLevel()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public GetCPUClock()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {}, Lcom/zego/ve/SniffAndroid;->GetCPUMaxFreqKHz()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public GetCPUKernel()I
    .locals 3

    const/4 v2, 0x6

    invoke-static {}, Lcom/zego/ve/SniffAndroid;->GetNumberOfCPUCores()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public GetCPUTemperature()I
    .locals 11

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v0, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    sget-object v1, Lcom/zego/ve/SniffAndroid;->CPU_TEMP_FILE_PATHS:Ljava/util/List;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v2

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-wide v3, 0x408f400000000000L    # 1000.0

    const-wide v3, 0x408f400000000000L    # 1000.0

    const/4 v10, 0x5

    const-wide v3, 0x408f400000000000L    # 1000.0

    const-wide v3, 0x408f400000000000L    # 1000.0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-ge v0, v2, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v10, 0x4

    new-instance v2, Ljava/io/File;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-direct {v2, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-direct {p0, v2}, Lcom/zego/ve/SniffAndroid;->ReadOneLine(Ljava/io/File;)D

    move-result-wide v5

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v5

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-direct {p0, v5, v6}, Lcom/zego/ve/SniffAndroid;->isTemperatureValid(D)Z

    move-result v5

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-string v6, "atiupvgbqClate dputrTrae: eep"

    const-string v6, "Cg rtbprmaupltip:aeTdetaeve u"

    const/4 v10, 0x7

    const-string/jumbo v6, "tgsdu:e vpuhieTlte eraamrCapt"

    const-string/jumbo v6, "getCpuTemperature valid path:"

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-eqz v5, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v7

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    sget-object v0, Lcom/zego/ve/SniffAndroid;->TAG:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    and-int/2addr v10, v9

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    goto :goto_1

    :cond_0
    const/4 v10, 0x1

    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v7

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    div-double/2addr v7, v3

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-direct {p0, v7, v8}, Lcom/zego/ve/SniffAndroid;->isTemperatureValid(D)Z

    move-result v5

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-eqz v5, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v7

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    div-double/2addr v7, v3

    const/4 v9, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    sget-object v0, Lcom/zego/ve/SniffAndroid;->TAG:Ljava/lang/String;

    const/4 v9, 0x5

    shr-int/2addr v10, v9

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    goto :goto_1

    :cond_1
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    goto/16 :goto_0

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    :goto_1
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    mul-double/2addr v7, v3

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    double-to-int v0, v7

    const/4 v10, 0x0

    const/4 v9, 0x1

    return v0
.end method

.method public GetCPUVendor()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    sget-object v0, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public GetCPUsage()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/16 v1, 0x1a

    if-ge v0, v1, :cond_0

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {p0}, Lcom/zego/ve/SniffAndroid;->SampleCpuUtilization()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    return v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {}, Lcom/zego/ve/SniffAndroid;->getCoresUsageGuessFromFreq()[I

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/zego/ve/SniffAndroid;->GetCpuUsage([I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    return v0
.end method

.method public GetDeviceName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public GetGPURenderer()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/zego/ve/SniffAndroid;->mGpuRenderer:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public GetGPUVendor()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/ve/SniffAndroid;->mGpuVendor:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public GetOsVersion()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public GetRAM()I
    .locals 6

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/ve/SniffAndroid;->mAppContext:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/zego/ve/SniffAndroid;->GetTotalMemory(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-wide/16 v2, 0x400

    const-wide/16 v2, 0x400

    const/4 v5, 0x4

    const-wide/16 v2, 0x400

    const-wide/16 v2, 0x400

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    div-long/2addr v0, v2

    long-to-int v0, v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v0
.end method

.method public SampleCpuUtilization()I
    .locals 11

    const/4 v10, 0x0

    invoke-direct {p0}, Lcom/zego/ve/SniffAndroid;->ReadIdleAndRunTime()Lcom/zego/ve/SniffAndroid$ProcStat;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/4 v1, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-nez v0, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    return v1

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-wide v2, v0, Lcom/zego/ve/SniffAndroid$ProcStat;->runTime:J

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v4, p0, Lcom/zego/ve/SniffAndroid;->lastProcStat:Lcom/zego/ve/SniffAndroid$ProcStat;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-wide v5, v4, Lcom/zego/ve/SniffAndroid$ProcStat;->runTime:J

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    sub-long/2addr v2, v5

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget-wide v5, v0, Lcom/zego/ve/SniffAndroid$ProcStat;->idleTime:J

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget-wide v7, v4, Lcom/zego/ve/SniffAndroid$ProcStat;->idleTime:J

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    sub-long/2addr v5, v7

    const/4 v10, 0x3

    iput-object v0, p0, Lcom/zego/ve/SniffAndroid;->lastProcStat:Lcom/zego/ve/SniffAndroid$ProcStat;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    add-long/2addr v5, v2

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x2

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    cmp-long v0, v5, v7

    const/4 v10, 0x6

    const/4 v9, 0x0

    if-nez v0, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    move v0, v1

    move v0, v1

    const/4 v10, 0x2

    move v0, v1

    move v0, v1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    goto :goto_0

    :cond_1
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    const-wide/16 v7, 0x64

    const-wide/16 v7, 0x64

    const-wide/16 v7, 0x64

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    mul-long/2addr v2, v7

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    div-long/2addr v2, v5

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    long-to-float v0, v2

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/16 v2, 0x64

    const/4 v10, 0x6

    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    return v0
.end method

.method public getCPUScore()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public initSniff(Landroid/content/Context;)Z
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    iput-object p1, p0, Lcom/zego/ve/SniffAndroid;->mAppContext:Landroid/content/Context;

    const/4 v7, 0x1

    new-instance p1, Lcom/zego/ve/SniffAndroid$ProcStat;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x6

    const-wide/16 v2, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct/range {v0 .. v5}, Lcom/zego/ve/SniffAndroid$ProcStat;-><init>(Lcom/zego/ve/SniffAndroid;JJ)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    iput-object p1, p0, Lcom/zego/ve/SniffAndroid;->lastProcStat:Lcom/zego/ve/SniffAndroid$ProcStat;

    const/4 v7, 0x4

    const/4 p1, 0x6

    const/4 p1, 0x1

    move v7, p1

    const/4 v6, 0x2

    move v7, v6

    return p1
.end method
