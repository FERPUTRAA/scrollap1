.class public Lcom/zego/ve/KaraokeHelper;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/KaraokeHelper$SilentPlayer;
    }
.end annotation


# static fields
.field private static final EQCustomGain:[[I

.field public static final MODE_CUSTOM_3DDRAEMY:I = 0x6

.field public static final MODE_CUSTOM_AIRY:I = 0x4

.field public static final MODE_CUSTOM_ATTRACTIVE:I = 0x3

.field public static final MODE_CUSTOM_DISTANT:I = 0x5

.field public static final MODE_CUSTOM_GRAMOPHONE:I = 0x7

.field public static final MODE_CUSTOM_KTV:I = 0x1

.field public static final MODE_CUSTOM_NOEFFECT:I = 0x8

.field public static final MODE_CUSTOM_RECSTUDIO:I = 0x0

.field public static final MODE_CUSTOM_WARM:I = 0x2

.field private static final ReverbCustomParams:[[I

.field private static final TAG:Ljava/lang/String; = "device"

.field private static final TAG_ECHO_ENABLE:Ljava/lang/String; = "vivo_ktv_echo_enable"

.field private static final TAG_MEQ_BAND_1:Ljava/lang/String; = "vivo_ktv_miceq_band1"

.field private static final TAG_MEQ_BAND_2:Ljava/lang/String; = "vivo_ktv_miceq_band2"

.field private static final TAG_MEQ_BAND_3:Ljava/lang/String; = "vivo_ktv_miceq_band3"

.field private static final TAG_MEQ_BAND_4:Ljava/lang/String; = "vivo_ktv_miceq_band4"

.field private static final TAG_MEQ_BAND_5:Ljava/lang/String; = "vivo_ktv_miceq_band5"

.field private static final TAG_RB_DAMP:Ljava/lang/String; = "vivo_ktv_rb_damp"

.field private static final TAG_RB_DRY:Ljava/lang/String; = "vivo_ktv_rb_dry"

.field private static final TAG_RB_GAIN:Ljava/lang/String; = "vivo_ktv_rb_gain"

.field private static final TAG_RB_ROOMSIZE:Ljava/lang/String; = "vivo_ktv_rb_roomsize"

.field private static final TAG_RB_WET:Ljava/lang/String; = "vivo_ktv_rb_wet"

.field private static final TAG_RB_WIDTH:Ljava/lang/String; = "vivo_ktv_rb_width"


# instance fields
.field protected _audioManager:Landroid/media/AudioManager;

.field protected _context:Landroid/content/Context;

.field protected _deviceHardware:I

.field protected _deviceManufacturer:I

.field protected _hwAudioKit:Lcom/zego/ve/HwAudioKit;

.field protected _initVivoKtv:Z

.field protected _initXiaomiKtv:Z

.field protected _silentPlayer:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

.field protected _volume:I


# direct methods
.method static constructor <clinit>()V
    .locals 14

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x2

    const/16 v0, 0x9

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x2

    new-array v1, v0, [[I

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x7

    const/4 v2, 0x6

    new-array v3, v2, [I

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x0

    fill-array-data v3, :array_0

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x5

    const/4 v4, 0x0

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x6

    aput-object v3, v1, v4

    const/4 v13, 0x5

    new-array v3, v2, [I

    const/4 v13, 0x5

    const/4 v12, 0x3

    fill-array-data v3, :array_1

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x4

    const/4 v5, 0x1

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x5

    aput-object v3, v1, v5

    const/4 v13, 0x7

    new-array v3, v2, [I

    const/4 v13, 0x0

    fill-array-data v3, :array_2

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x0

    const/4 v6, 0x2

    const/4 v12, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x4

    aput-object v3, v1, v6

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x0

    new-array v3, v2, [I

    const/4 v13, 0x0

    const/4 v12, 0x7

    fill-array-data v3, :array_3

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x3

    const/4 v7, 0x3

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x0

    aput-object v3, v1, v7

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x5

    new-array v3, v2, [I

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x4

    fill-array-data v3, :array_4

    const/4 v13, 0x3

    const/4 v8, 0x4

    const/4 v13, 0x2

    xor-int/2addr v12, v8

    const/4 v13, 0x5

    aput-object v3, v1, v8

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x1

    new-array v3, v2, [I

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x3

    fill-array-data v3, :array_5

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x4

    const/4 v9, 0x5

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x4

    aput-object v3, v1, v9

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x3

    new-array v3, v2, [I

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x6

    fill-array-data v3, :array_6

    const/4 v13, 0x2

    aput-object v3, v1, v2

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x7

    new-array v3, v2, [I

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x7

    fill-array-data v3, :array_7

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x1

    const/4 v10, 0x7

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x0

    aput-object v3, v1, v10

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x5

    new-array v3, v2, [I

    const/4 v12, 0x3

    xor-int/2addr v13, v12

    fill-array-data v3, :array_8

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x2

    const/16 v11, 0x8

    const/4 v12, 0x4

    or-int/2addr v13, v12

    aput-object v3, v1, v11

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x0

    sput-object v1, Lcom/zego/ve/KaraokeHelper;->ReverbCustomParams:[[I

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x4

    new-array v0, v0, [[I

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x4

    filled-new-array {v4, v4, v4, v6, v6}, [I

    move-result-object v1

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x7

    aput-object v1, v0, v4

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x5

    filled-new-array {v4, v4, v4, v4, v4}, [I

    move-result-object v1

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x5

    aput-object v1, v0, v5

    const/4 v13, 0x0

    const/4 v1, -0x3

    const/4 v13, 0x7

    or-int/2addr v12, v1

    const/4 v13, 0x1

    filled-new-array {v7, v8, v6, v4, v1}, [I

    move-result-object v3

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x1

    aput-object v3, v0, v6

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x3

    filled-new-array {v7, v6, v4, v4, v6}, [I

    move-result-object v3

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x7

    aput-object v3, v0, v7

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x5

    const/4 v3, -0x1

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x7

    filled-new-array {v7, v6, v4, v3, v1}, [I

    move-result-object v1

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x4

    aput-object v1, v0, v8

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x4

    filled-new-array {v6, v6, v6, v4, v4}, [I

    move-result-object v1

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x4

    aput-object v1, v0, v9

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x3

    const/4 v1, -0x2

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x3

    filled-new-array {v9, v6, v1, v5, v7}, [I

    move-result-object v3

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x0

    aput-object v3, v0, v2

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x2

    filled-new-array {v1, v4, v5, v6, v5}, [I

    move-result-object v1

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x3

    aput-object v1, v0, v10

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x4

    filled-new-array {v4, v4, v4, v4, v4}, [I

    move-result-object v1

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x5

    aput-object v1, v0, v11

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x1

    sput-object v0, Lcom/zego/ve/KaraokeHelper;->EQCustomGain:[[I

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x7

    return-void

    nop

    :array_0
    .array-data 4
        0xc8
        0x3e8
        0x1f4
        0x1194
        0x3e8
        0x5dc
    .end array-data

    :array_1
    .array-data 4
        0x1388
        0x1194
        0x4b0
        0x1194
        0x1964
        0x4b0
    .end array-data

    :array_2
    .array-data 4
        0x1194
        0x1f40
        0x3e8
        0xfa0
        0x1964
        0x5dc
    .end array-data

    :array_3
    .array-data 4
        0x9c4
        0xbb8
        0x5dc
        0xfa0
        0x1388
        0x5dc
    .end array-data

    :array_4
    .array-data 4
        0xdac
        0x157c
        0x5dc
        0x1388
        0x157c
        0x5dc
    .end array-data

    :array_5
    .array-data 4
        0xfa0
        0xbb8
        0x3e8
        0x9c4
        0x157c
        0x4b0
    .end array-data

    :array_6
    .array-data 4
        0x1f4
        0x1388
        0x320
        0x1194
        0xbb8
        0x4b0
    .end array-data

    :array_7
    .array-data 4
        0x14
        0x1f4
        0x3c
        0x1194
        0x1388
        0x5dc
    .end array-data

    :array_8
    .array-data 4
        0x0
        0x0
        0x0
        0xfa0
        0x0
        0x4b0
    .end array-data
.end method

.method constructor <init>(Landroid/content/Context;Landroid/media/AudioManager;)V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x2

    iput v0, p0, Lcom/zego/ve/KaraokeHelper;->_deviceManufacturer:I

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    iput v0, p0, Lcom/zego/ve/KaraokeHelper;->_deviceHardware:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput-object v1, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    iput-object v1, p0, Lcom/zego/ve/KaraokeHelper;->_silentPlayer:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    iput-boolean v0, p0, Lcom/zego/ve/KaraokeHelper;->_initVivoKtv:Z

    const/4 v6, 0x4

    iput-boolean v0, p0, Lcom/zego/ve/KaraokeHelper;->_initXiaomiKtv:Z

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    iput v0, p0, Lcom/zego/ve/KaraokeHelper;->_volume:I

    const/4 v5, 0x0

    move v6, v5

    iput-object p1, p0, Lcom/zego/ve/KaraokeHelper;->_context:Landroid/content/Context;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    iput-object p2, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x0

    sget-object p1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string p2, "HssEAI"

    const-string p2, "IHsWAE"

    const/4 v6, 0x7

    const-string p2, "IHWmUE"

    const-string p2, "HUAWEI"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v0, 0x4

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v1, 0x3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v2, 0x2

    and-int/2addr v6, v2

    const/4 v5, 0x6

    move v6, v5

    const/4 v3, 0x1

    const/4 v6, 0x3

    if-eqz p2, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput v3, p0, Lcom/zego/ve/KaraokeHelper;->_deviceManufacturer:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string/jumbo v4, "vivo"

    const-string/jumbo v4, "vivo"

    const/4 v6, 0x2

    const-string/jumbo v4, "vovi"

    const-string/jumbo v4, "vivo"

    const/4 v6, 0x5

    invoke-virtual {p2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz p2, :cond_1

    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    iput v2, p0, Lcom/zego/ve/KaraokeHelper;->_deviceManufacturer:I

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v4, "OPOP"

    const-string v4, "PPOO"

    const/4 v6, 0x1

    const-string v4, "OOPP"

    const-string v4, "OPPO"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v6, 0x4

    if-eqz p2, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    iput v1, p0, Lcom/zego/ve/KaraokeHelper;->_deviceManufacturer:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string/jumbo v4, "mXamio"

    const-string v4, "Xmaooi"

    const-string v4, "Xiaomi"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz p2, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    iput v0, p0, Lcom/zego/ve/KaraokeHelper;->_deviceManufacturer:I

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_0

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string p2, "Golgeb"

    const-string/jumbo p2, "olGeog"

    const/4 v6, 0x6

    const-string/jumbo p2, "uloeoG"

    const-string p2, "Google"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz p1, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 p1, 0x5

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    iput p1, p0, Lcom/zego/ve/KaraokeHelper;->_deviceManufacturer:I

    :cond_4
    :goto_0
    const/4 v6, 0x4

    sget-object p1, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v4, "oqmc"

    const-string/jumbo v4, "moqc"

    const-string/jumbo v4, "qcom"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz p2, :cond_5

    const/4 v6, 0x7

    iput v3, p0, Lcom/zego/ve/KaraokeHelper;->_deviceHardware:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto :goto_1

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-string/jumbo v3, "mt"

    const-string/jumbo v3, "tm"

    const/4 v6, 0x3

    const-string/jumbo v3, "mt"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz p2, :cond_6

    const/4 v5, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    iput v2, p0, Lcom/zego/ve/KaraokeHelper;->_deviceHardware:I

    const/4 v6, 0x2

    goto :goto_1

    :cond_6
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo v2, "iipkb"

    const-string v2, "biikn"

    const/4 v6, 0x5

    const-string/jumbo v2, "rniqk"

    const-string/jumbo v2, "kirin"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p2, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz p2, :cond_7

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput v1, p0, Lcom/zego/ve/KaraokeHelper;->_deviceHardware:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto :goto_1

    :cond_7
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo p2, "xssueo"

    const-string/jumbo p2, "usoxye"

    const/4 v6, 0x7

    const-string/jumbo p2, "xnsmyo"

    const-string/jumbo p2, "exynos"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz p1, :cond_8

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput v0, p0, Lcom/zego/ve/KaraokeHelper;->_deviceHardware:I

    :cond_8
    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    return-void
.end method


# virtual methods
.method public EnableHWKaraoke(I)I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "f @4o~~s o @@~ rS -o/ot f@~u@i@i~ @K@@l~at@.~~o~  @~ ~d@@~ @/ ~~Mc~@m~by n@ oi@@~ lb1~v@~~~@ ~bo"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x5

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/zego/ve/HwAudioKit;->isFeatureKaraokeOn()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/zego/ve/HwAudioKit;->destroy()V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x5

    move v4, v3

    new-instance v0, Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/zego/ve/KaraokeHelper;->_context:Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {v0, v1}, Lcom/zego/ve/HwAudioKit;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/zego/ve/HwAudioKit;->initialize()Z

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/zego/ve/HwAudioKit;->createFeatureKaraoke()Z

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-ne p1, v1, :cond_1

    const/4 v3, 0x6

    or-int/2addr v4, v3

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/zego/ve/HwAudioKit;->enableKaraokeFeature(Z)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v2, "paHenbb:aeoKEkar"

    const-string v2, "aeWHka:panKEobre"

    const/4 v4, 0x1

    const-string v2, "aaernkulWK:bEHea"

    const-string v2, "EnableHWKaraoke:"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo p1, "qlte sru"

    const/4 v4, 0x3

    const-string p1, " ulet:rp"

    const-string p1, " result:"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v1, "veqsie"

    const-string/jumbo v1, "icsvee"

    const/4 v4, 0x7

    const-string v1, "device"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v1, p1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v0, -0x1

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    return v0
.end method

.method public EnableVivoKaraoke(I)I
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-boolean v0, p0, Lcom/zego/ve/KaraokeHelper;->_initVivoKtv:Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x3

    const/4 v3, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v3, 0x7

    const-string/jumbo v2, "vvsaei=t_ks_o_mucrvoy"

    const-string/jumbo v2, "ya_mv_o_ctovukv=ripes"

    const/4 v4, 0x4

    const-string v2, "elomrtu_pvyavk=ovc_is"

    const-string/jumbo v2, "vivo_ktv_play_source="

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string p1, "0"

    const-string p1, "0"

    const/4 v4, 0x4

    const-string p1, "0"

    const-string p1, "0"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string p1, "1"

    const-string p1, "1"

    const/4 v4, 0x2

    const-string p1, "1"

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 p1, 0x0

    move v4, p1

    const/4 v3, 0x3

    move v4, v3

    return p1

    :cond_1
    const/4 v4, 0x0

    const/4 p1, -0x5

    const/4 p1, -0x1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    return p1
.end method

.method public EnableXiaomiKaraoke(I)I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-boolean v0, p0, Lcom/zego/ve/KaraokeHelper;->_initXiaomiKtv:Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v2, "oeulo_krnedaboeaok_ai"

    const-string v2, "ake_obneadai_ruaoeolk"

    const/4 v4, 0x1

    const-string/jumbo v2, "raanobo_lke_=aekdebia"

    const-string v2, "audio_karaoke_enable="

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    if-ne p1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const-string/jumbo v1, "vmikdeuu=urbok_aa_oao"

    const-string/jumbo v1, "l_edabkvorak_aiou=uom"

    const/4 v4, 0x1

    const-string v1, "audio_karaoke_volume="

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v1, p0, Lcom/zego/ve/KaraokeHelper;->_volume:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x3

    const-string v0, "aoQ_Ekapa0uiuo_der"

    const-string v0, "akraeiua0doQo=E_u_"

    const/4 v4, 0x1

    const-string/jumbo v0, "orEaaieoqadQ0uk__="

    const-string v0, "audio_karaoke_EQ=0"

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {p1, v0}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v0, "e_seavboueadr_i0kaprRk"

    const-string v0, "e0ieavRpe=ukr_oa_brkda"

    const/4 v4, 0x1

    const-string v0, "d0kmkaevR_eboaueri_aro"

    const-string v0, "audio_karaoke_Reverb=0"

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    invoke-virtual {p1, v0}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 p1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    return p1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 p1, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    return p1
.end method

.method public GetDeviceHardware()I
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    iget v0, p0, Lcom/zego/ve/KaraokeHelper;->_deviceHardware:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public GetDeviceManufacturer()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget v0, p0, Lcom/zego/ve/KaraokeHelper;->_deviceManufacturer:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    return v0
.end method

.method public InitVivoKtvEnv(I)I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string/jumbo v1, "iyvlope=1_o_vto_avuscr"

    const-string/jumbo v1, "vivo_ktv_play_source=1"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v1, "m_otebq1v_vvdi="

    const-string/jumbo v1, "o=_tvvdvq_k1mei"

    const/4 v3, 0x7

    const-string/jumbo v1, "mik_dvuve=_o1ov"

    const-string/jumbo v1, "vivo_ktv_mode=1"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo v1, "vr0=svspccu__evtook_i"

    const-string v1, "_es_v=ccevko_otivus0r"

    const/4 v3, 0x5

    const-string v1, "ecos0e_rq_t_cvuvvir=k"

    const-string/jumbo v1, "vivo_ktv_rec_source=0"

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_silentPlayer:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    new-instance v0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0, p0, p1}, Lcom/zego/ve/KaraokeHelper$SilentPlayer;-><init>(Lcom/zego/ve/KaraokeHelper;I)V

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_silentPlayer:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/zego/ve/KaraokeHelper;->_silentPlayer:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz p1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->isPlaying()Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/zego/ve/KaraokeHelper;->_silentPlayer:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->play()V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-boolean p1, p0, Lcom/zego/ve/KaraokeHelper;->_initVivoKtv:Z

    const/4 v2, 0x5

    move v3, v2

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return p1
.end method

.method public InitXiaomiKtvEnv()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x7

    const-string v1, "emseikvtaaan_eokrelmoda=kbud"

    const-string v1, "eammoia=lkdatev_kurdbeo_kaen"

    const/4 v3, 0x1

    const-string v1, "audio_karaoke_ktvmode=enable"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v1, "=duml8oookamaeou_ia_ke"

    const-string v1, "_ouuo8o=ldmkaoe_riaeak"

    const/4 v3, 0x3

    const-string/jumbo v1, "rkkaoovu_8mdloeiaoaeu_"

    const-string v1, "audio_karaoke_volume=8"

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x6

    const-string v1, "_iau_b=keEdroa0kQo"

    const-string v1, "audio_karaoke_EQ=0"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v1, "=uoib_uerdrkeebak_R0ao"

    const-string v1, "_uearb0=eda_Roboieakrk"

    const/4 v3, 0x1

    const-string v1, "d_eokrrpReoa_ibua=avek"

    const-string v1, "audio_karaoke_Reverb=0"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v1, "eaa__anlqkuadikb=eeru1"

    const-string/jumbo v1, "uaabo_u=dn1_eaeeikklra"

    const/4 v3, 0x0

    const-string v1, "_esk1nkb=aoa_ieeuordla"

    const-string v1, "audio_karaoke_enable=1"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/zego/ve/KaraokeHelper;->_initXiaomiKtv:Z

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/16 v0, 0x8

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput v0, p0, Lcom/zego/ve/KaraokeHelper;->_volume:I

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x4

    move v2, v0

    move v2, v0

    const/4 v3, 0x1

    return v0
.end method

.method public SetCustomMode(I)I
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    invoke-virtual {p0, p1}, Lcom/zego/ve/KaraokeHelper;->setReverbParams(I)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/zego/ve/KaraokeHelper;->setEQParams(I)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p1
.end method

.method public SetHWKaraokeReverbMode(I)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/zego/ve/HwAudioKit;->setKaraokeReverbMode(I)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 p1, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p1
.end method

.method public SetHWKaraokeVolume(I)I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/zego/ve/HwAudioKit;->setKaraokeVolume(I)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return p1
.end method

.method public SetVivoKaraokeVolume(I)I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-boolean v0, p0, Lcom/zego/ve/KaraokeHelper;->_initVivoKtv:Z

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    div-int/lit8 p1, p1, 0x6

    const/4 v4, 0x6

    const/16 v0, 0xf

    const/4 v4, 0x3

    if-le p1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    move p1, v0

    move p1, v0

    const/4 v4, 0x5

    move p1, v0

    move p1, v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v2, "vk_mvvm_uoemtc=v_iol"

    const-string/jumbo v2, "vivo_ktv_volume_mic="

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    return p1
.end method

.method public SetXiaomiKaraokeVolume(I)I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-boolean v0, p0, Lcom/zego/ve/KaraokeHelper;->_initXiaomiKtv:Z

    const/4 v3, 0x4

    move v4, v3

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    div-int/lit8 p1, p1, 0x6

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/16 v0, 0xf

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-le p1, v0, :cond_0

    const/4 v4, 0x5

    move p1, v0

    move p1, v0

    const/4 v4, 0x6

    move p1, v0

    move p1, v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x6

    const/4 v3, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v2, "ol_=oaveukpormdu_iaoe"

    const-string v2, "a_meldepauaooiour_=vk"

    const/4 v4, 0x2

    const-string v2, "audio_karaoke_volume="

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput p1, p0, Lcom/zego/ve/KaraokeHelper;->_volume:I

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    return p1
.end method

.method public SupportHWKaraokeLowlatency()I
    .locals 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x11
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/16 v1, 0x1d

    const/4 v4, 0x1

    const/4 v2, -0x1

    const/4 v4, 0x6

    const/4 v2, -0x1

    const/4 v4, 0x6

    if-lt v0, v1, :cond_1

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v0, Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/zego/ve/KaraokeHelper;->_context:Landroid/content/Context;

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Lcom/zego/ve/HwAudioKit;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/zego/ve/HwAudioKit;->initialize()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/zego/ve/HwAudioKit;->destroy()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    return v2

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/zego/ve/HwAudioKit;->createFeatureKaraoke()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/zego/ve/HwAudioKit;->destroy()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    return v2

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/zego/ve/HwAudioKit;->isFeatureKaraokeOn()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v1, "qRtECbe.rAmoTT_dPHKOr_edAOFnrWEiERaS.dio.UKpaFP"

    const-string/jumbo v1, "oH.SiO.nqRrAtEaPKdRy_epTErOWorEFKU._CdFmeiPaATd"

    const/4 v4, 0x5

    const-string/jumbo v1, "nFAraKuRodyreTCA.W.dOm_eEodP_i.OFTEippRSaHtKUPr"

    const-string v1, "android.media.property.SUPPORT_HWKARAOKE_EFFECT"

    const/4 v3, 0x3

    and-int/2addr v4, v3

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v1, "erut"

    const-string/jumbo v1, "urte"

    const/4 v4, 0x5

    const-string/jumbo v1, "utre"

    const-string/jumbo v1, "true"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_context:Landroid/content/Context;

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const-string/jumbo v1, "teardlopin_aohrwdianwouc..leayasr."

    const-string v1, ".ws.iardntdlawori_deaeuhoolyan.car"

    const/4 v4, 0x7

    const-string/jumbo v1, "lhcird.lqe.eu.ano_wadoarniwryddtao"

    const-string v1, "android.hardware.audio.low_latency"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    return v0

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    return v2
.end method

.method public SupportVivoKaraokeLowlatency()I
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v1, "cksttiev_pm_mvivo"

    const-string/jumbo v1, "petmko__t_vvvciim"

    const/4 v6, 0x6

    const-string/jumbo v1, "vvimvt___ioceypmk"

    const-string/jumbo v1, "vivo_ktv_mic_type"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getParameters(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-instance v2, Ljava/util/StringTokenizer;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v3, "="

    const-string v3, "="

    const/4 v6, 0x3

    const-string v3, "="

    const-string v3, "="

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {v2, v0, v3}, Ljava/util/StringTokenizer;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/util/StringTokenizer;->countTokens()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 v4, -0x1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eq v0, v3, :cond_0

    const/4 v6, 0x3

    return v4

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/util/StringTokenizer;->nextToken()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/util/StringTokenizer;->nextToken()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eq v0, v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-nez v0, :cond_3

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/16 v2, 0x1b

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-lt v0, v2, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v0, 0x0

    xor-int/2addr v6, v0

    const/4 v5, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    return v0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    return v1

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    return v4
.end method

.method public SupportXiaomiKaraokeLowlatency()I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x0

    const-string/jumbo v1, "prauokirpso_a_uedotak"

    const-string/jumbo v1, "iaoaors_kupeadtou_pkr"

    const/4 v3, 0x3

    const-string/jumbo v1, "rokpibaetarpou_uaod_s"

    const-string v1, "audio_karaoke_support"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getParameters(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "rteu"

    const-string/jumbo v1, "ture"

    const/4 v3, 0x2

    const-string/jumbo v1, "true"

    const-string/jumbo v1, "true"

    const/4 v2, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return v0
.end method

.method public UninitHWKtvEnv()I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget v0, p0, Lcom/zego/ve/KaraokeHelper;->_deviceManufacturer:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-ne v0, v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x6

    move v4, v3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v0, v2}, Lcom/zego/ve/HwAudioKit;->enableKaraokeFeature(Z)I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/zego/ve/HwAudioKit;->destroy()V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_hwAudioKit:Lcom/zego/ve/HwAudioKit;

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    return v2
.end method

.method public UninitVivoKtvEnv()I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-boolean v0, p0, Lcom/zego/ve/KaraokeHelper;->_initVivoKtv:Z

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    move v4, v1

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_silentPlayer:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->stop()V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_silentPlayer:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-boolean v1, p0, Lcom/zego/ve/KaraokeHelper;->_initVivoKtv:Z

    const/4 v4, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x3

    and-int/2addr v4, v3

    const-string v2, "d=iv_euotv0bmvk"

    const-string/jumbo v2, "omoetbvk_vdv=0i"

    const/4 v4, 0x7

    const-string/jumbo v2, "kvo_vo_pi0emvt="

    const-string/jumbo v2, "vivo_ktv_mode=0"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    return v1
.end method

.method public UninitXiaomiKtvEnv()I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-boolean v0, p0, Lcom/zego/ve/KaraokeHelper;->_initXiaomiKtv:Z

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-boolean v1, p0, Lcom/zego/ve/KaraokeHelper;->_initXiaomiKtv:Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string v2, "eddiablsq=ikavkomakaooutde_r_"

    const-string/jumbo v2, "soarktu__oiedmk=avdeoadalikeb"

    const/4 v4, 0x7

    const-string/jumbo v2, "olso=asrtbedoeukkddievmaki_aa"

    const-string v2, "audio_karaoke_ktvmode=disable"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v2}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    return v1
.end method

.method public setEQParams(I)V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string v2, "aitmo_vi1mq_en_bk=cvv"

    const-string/jumbo v2, "vivo_ktv_miceq_band1="

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    sget-object v2, Lcom/zego/ve/KaraokeHelper;->EQCustomGain:[[I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    aget-object v3, v2, p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    aget v3, v3, v4

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    add-int/lit8 v3, v3, 0x8

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v3, "o2vqomvi=edi__kpnvcba"

    const-string/jumbo v3, "obkv_aipc_mqv2id=nev_"

    const/4 v6, 0x6

    const-string v3, "_qa_ibvbnm2cvvdeot_k="

    const-string/jumbo v3, "vivo_ktv_miceq_band2="

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    aget-object v3, v2, p1

    const/4 v5, 0x7

    xor-int/2addr v6, v5

    const/4 v4, 0x1

    move v6, v4

    const/4 v5, 0x0

    move v6, v5

    aget v3, v3, v4

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    add-int/lit8 v3, v3, 0x8

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    shr-int/2addr v6, v5

    const-string v3, "3b_ovdu_a_mi=ikvtncvq"

    const-string/jumbo v3, "nio_kdbaq_evcvvi=3_mt"

    const/4 v6, 0x6

    const-string/jumbo v3, "vvk=_t_pqnb_dicoa3imv"

    const-string/jumbo v3, "vivo_ktv_miceq_band3="

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    aget-object v3, v2, p1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v4, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    aget v3, v3, v4

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    add-int/lit8 v3, v3, 0x8

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v3, "_dt_nosvq_e4iia=cvqvb"

    const-string/jumbo v3, "v_s=k_tvaiocnq4idb_ve"

    const/4 v6, 0x6

    const-string v3, "cvsd4m_evtavknii=ob__"

    const-string/jumbo v3, "vivo_ktv_miceq_band4="

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    aget-object v3, v2, p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v4, 0x3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    aget v3, v3, v4

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    add-int/lit8 v3, v3, 0x8

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string/jumbo v3, "v=mmqoie_bkim_dnv5vc_"

    const-string/jumbo v3, "qeim5vo=n_c__abvimdkv"

    const/4 v6, 0x3

    const-string/jumbo v3, "qdm5onvboc__tak=veiiv"

    const-string/jumbo v3, "vivo_ktv_miceq_band5="

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    aget-object p1, v2, p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 v2, 0x4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    aget p1, p1, v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    add-int/lit8 p1, p1, 0x8

    const/4 v6, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0, p1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-void
.end method

.method public setReverbParams(I)V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v2, "bs=m_bvvo__otkzeviirr"

    const-string/jumbo v2, "vivo_ktv_rb_roomsize="

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    sget-object v2, Lcom/zego/ve/KaraokeHelper;->ReverbCustomParams:[[I

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    aget-object v3, v2, p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x7

    aget v3, v3, v4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const-string v3, "=vv_a_udvmrkitp_b"

    const-string/jumbo v3, "vivo_ktv_rb_damp="

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    aget-object v3, v2, p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v4, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    aget v3, v3, v4

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const-string/jumbo v3, "iwtovo_pvbr=e_vt"

    const-string/jumbo v3, "etitov_v_=wkvorb"

    const/4 v6, 0x1

    const-string/jumbo v3, "vrt=iwvtqvb__k_o"

    const-string/jumbo v3, "vivo_ktv_rb_wet="

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    aget-object v3, v2, p1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v4, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    aget v3, v3, v4

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v5, 0x5

    shl-int/2addr v6, v5

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string/jumbo v3, "o_t_rbbkyv_vvir="

    const/4 v6, 0x7

    const-string/jumbo v3, "kystdvo_=_vv_bri"

    const-string/jumbo v3, "vivo_ktv_rb_dry="

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    aget-object v3, v2, p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v4, 0x3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    aget v3, v3, v4

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    move v6, v5

    const-string/jumbo v3, "ohtmv=druviiv_kw_t"

    const-string/jumbo v3, "k_vv=iubvwrhio_tdt"

    const/4 v6, 0x2

    const-string/jumbo v3, "t_oio_=vkwdrv_ivbt"

    const-string/jumbo v3, "vivo_ktv_rb_width="

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    aget-object v3, v2, p1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v4, 0x4

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    aget v3, v3, v4

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo v3, "kv_r_bvn_bitpa=vg"

    const-string/jumbo v3, "k=v_gbiprv_inv_ta"

    const/4 v6, 0x7

    const-string/jumbo v3, "rngivaui_kv_v=ot_"

    const-string/jumbo v3, "vivo_ktv_rb_gain="

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    aget-object p1, v2, p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v2, 0x5

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    aget p1, p1, v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/zego/ve/KaraokeHelper;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string/jumbo v0, "evb=v_hplqe_vnkoci0_et"

    const-string v0, "_neb_i=_qvceeloohv0kvt"

    const/4 v6, 0x3

    const-string/jumbo v0, "v=cevo_iqa_eolkbetn_vh"

    const-string/jumbo v0, "vivo_ktv_echo_enable=0"

    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {p1, v0}, Landroid/media/AudioManager;->setParameters(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-void
.end method
