.class public Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;
.super Landroid/media/AudioDeviceCallback;

# interfaces
.implements Landroid/media/AudioRouting$OnRoutingChangedListener;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x18
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/AudioEventMonitor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "AudioRoutChange"
.end annotation


# instance fields
.field private _getAddress:Ljava/lang/reflect/Method;

.field invoke_times:I

.field final synthetic this$0:Lcom/zego/ve/AudioEventMonitor;


# direct methods
.method public constructor <init>(Lcom/zego/ve/AudioEventMonitor;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Landroid/media/AudioDeviceCallback;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p1, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->invoke_times:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->_getAddress:Ljava/lang/reflect/Method;

    const/4 v1, 0x5

    const/4 v0, 0x0

    return-void
.end method

.method private getDirection(Landroid/media/AudioDeviceInfo;)Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s~f~  ~/i ~id~@~@ - ol@ yn@o~tSs~~~o @ib @~@4a@ ~f Kc ~@ u~o@b@  1 @@ol~t@~Mvm @~ob@/ ~~~.~@r@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/media/AudioDeviceInfo;->isSource()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string/jumbo p1, "iutms"

    const-string/jumbo p1, "tusni"

    const/4 v2, 0x3

    const-string/jumbo p1, "tnipo"

    const-string/jumbo p1, "input"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/media/AudioDeviceInfo;->isSink()Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo p1, "uutpmb"

    const-string/jumbo p1, "tpumut"

    const/4 v2, 0x5

    const-string/jumbo p1, "utoput"

    const-string/jumbo p1, "output"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x1

    const-string p1, ""

    const-string p1, ""

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p1
.end method


# virtual methods
.method public onAudioDevicesAdded([Landroid/media/AudioDeviceInfo;)V
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string/jumbo v0, "|"

    const-string/jumbo v0, "|"

    const/4 v11, 0x2

    const-string/jumbo v0, "|"

    const-string/jumbo v0, "|"

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    const-string v1, "dpoecv"

    const-string v1, "dvceoi"

    const/4 v11, 0x3

    const-string v1, "edqcei"

    const-string v1, "device"

    :try_start_0
    const/4 v10, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    iget-object v2, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->_getAddress:Ljava/lang/reflect/Method;

    const/4 v10, 0x1

    const/4 v11, 0x2

    const/4 v3, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    if-nez v2, :cond_0

    const/4 v10, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    const-class v2, Landroid/media/AudioDeviceInfo;

    const-class v2, Landroid/media/AudioDeviceInfo;

    const/4 v11, 0x5

    const-class v2, Landroid/media/AudioDeviceInfo;

    const-class v2, Landroid/media/AudioDeviceInfo;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const-string/jumbo v4, "srssedegtA"

    const-string/jumbo v4, "etegrbdssA"

    const/4 v11, 0x5

    const-string/jumbo v4, "gdtmeAssed"

    const-string/jumbo v4, "getAddress"

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    new-array v5, v3, [Ljava/lang/Class;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {v2, v4, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v11, 0x4

    const/4 v10, 0x7

    iput-object v2, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->_getAddress:Ljava/lang/reflect/Method;

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    iget v2, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->invoke_times:I

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x5

    const/4 v4, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    if-lez v2, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    iget-object v2, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x1

    iput-boolean v4, v2, Lcom/zego/ve/AudioEventMonitor;->audio_route_change_valid_:Z

    :cond_1
    const/4 v11, 0x7

    const/4 v10, 0x1

    array-length v2, p1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    move v5, v3

    move v5, v3

    const/4 v11, 0x7

    move v5, v3

    move v5, v3

    :goto_0
    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    if-ge v5, v2, :cond_6

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    aget-object v6, p1, v5

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x4

    const-string v8, "daivo eu:ec"

    const-string v8, "eaivedu d:c"

    const/4 v11, 0x6

    const-string v8, "advdeb:i dc"

    const-string v8, "add device:"

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v6}, Landroid/media/AudioDeviceInfo;->getId()I

    move-result v8

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string v8, ", "

    const-string v8, ", "

    const/4 v11, 0x0

    const-string v8, ", "

    const-string v8, ", "

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v6}, Landroid/media/AudioDeviceInfo;->getProductName()Ljava/lang/CharSequence;

    move-result-object v8

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v6}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v8

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-static {v8}, Lcom/zego/ve/AudioDeviceHelper;->getDeviceTypeStr(I)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x0

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    invoke-direct {p0, v6}, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->getDirection(Landroid/media/AudioDeviceInfo;)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x3

    iget-object v8, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->_getAddress:Ljava/lang/reflect/Method;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x3

    new-array v9, v3, [Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v8, v6, v9}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    check-cast v8, Ljava/lang/String;

    const/4 v11, 0x7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {v1, v7}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v6}, Landroid/media/AudioDeviceInfo;->isSink()Z

    move-result v7

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-eqz v7, :cond_5

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    iget v7, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->invoke_times:I

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x0

    if-lez v7, :cond_5

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v6}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v6

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-static {v6}, Lcom/zego/ve/AudioDeviceHelper;->getRouteType(I)I

    move-result v6

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    const/4 v7, -0x1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-ne v7, v6, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    goto :goto_2

    :cond_2
    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    const/4 v7, 0x6

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-ne v7, v6, :cond_4

    const/4 v10, 0x6

    shr-int/2addr v11, v10

    iget-object v7, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v11, 0x3

    iget-object v7, v7, Lcom/zego/ve/AudioEventMonitor;->_context:Landroid/content/Context;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-static {v7}, Lcom/zego/ve/AudioDeviceHelper;->scoConnect(Landroid/content/Context;)Z

    move-result v7

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-eqz v7, :cond_3

    const/4 v10, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x3

    const/4 v6, 0x2

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    goto :goto_1

    :cond_3
    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget-object v7, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x1

    iget v7, v7, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v8, 0x3

    xor-int/2addr v11, v8

    const/4 v10, 0x2

    move v11, v10

    if-ne v8, v7, :cond_4

    const/4 v11, 0x2

    const-string/jumbo v6, "p dDoiuPViO2nne AAA oeIddresdi ecuingPo"

    const-string v6, "2oPdec peA  enOrsneoiAIgi nDAoidDdPdiVu"

    const/4 v11, 0x2

    const-string/jumbo v6, "onAudioDevicesAdded ignore A2DP in VOIP"

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-static {v1, v6}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    goto :goto_2

    :cond_4
    :goto_1
    const/4 v10, 0x4

    const/4 v10, 0x5

    iget-object v7, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v11, 0x2

    invoke-virtual {v7, v6}, Lcom/zego/ve/AudioEventMonitor;->ChangeAudioRoute(I)V

    :cond_5
    :goto_2
    const/4 v11, 0x2

    add-int/lit8 v5, v5, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    goto/16 :goto_0

    :cond_6
    const/4 v11, 0x3

    const/4 v10, 0x2

    iget p1, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->invoke_times:I

    const/4 v10, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    add-int/2addr p1, v4

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x4

    iput p1, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->invoke_times:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    goto :goto_3

    :catch_0
    move-exception p1

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-string v2, "cqedeDApduvni dAsodo"

    const-string/jumbo v2, "uDAeeodiqicds vdAond"

    const-string/jumbo v2, "seedoDciqAneuod dvAd"

    const-string/jumbo v2, "onAudioDevicesAdded "

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-static {v1, p1}, Lcom/zego/ve/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :goto_3
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    return-void
.end method

.method public onAudioDevicesRemoved([Landroid/media/AudioDeviceInfo;)V
    .locals 9

    const/4 v8, 0x1

    const-string/jumbo v0, "|"

    const-string/jumbo v0, "|"

    const/4 v8, 0x5

    const-string/jumbo v0, "|"

    const-string/jumbo v0, "|"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string/jumbo v1, "ivsdcs"

    const-string v1, "cisdve"

    const/4 v8, 0x4

    const-string v1, "eidmve"

    const-string v1, "device"

    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object v2, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    iput-boolean v3, v2, Lcom/zego/ve/AudioEventMonitor;->audio_route_change_valid_:Z

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    array-length v2, p1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x7

    move v8, v7

    if-ge v3, v2, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x1

    aget-object v4, p1, v3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string v6, "emroo:cme vdev"

    const-string v6, "devmmreo:e cev"

    const/4 v8, 0x6

    const-string/jumbo v6, "om erbvei:evcd"

    const-string/jumbo v6, "remove device:"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v4}, Landroid/media/AudioDeviceInfo;->getId()I

    move-result v6

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string v6, ", "

    const-string v6, ", "

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v4}, Landroid/media/AudioDeviceInfo;->getProductName()Ljava/lang/CharSequence;

    move-result-object v6

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-virtual {v4}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v6

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {v6}, Lcom/zego/ve/AudioDeviceHelper;->getDeviceTypeStr(I)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-direct {p0, v4}, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->getDirection(Landroid/media/AudioDeviceInfo;)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x3

    invoke-static {v1, v5}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v4}, Landroid/media/AudioDeviceInfo;->isSink()Z

    move-result v5

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-eqz v5, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v4}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-static {v4}, Lcom/zego/ve/AudioDeviceHelper;->getRouteType(I)I

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v5, -0x1

    const/4 v7, 0x7

    move v8, v7

    if-eq v5, v4, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object v4, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {v4}, Lcom/zego/ve/AudioEventMonitor;->access$500(Lcom/zego/ve/AudioEventMonitor;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    goto/16 :goto_0

    :catch_0
    move-exception p1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string v2, "AuseeouvdioRivnDdmeoc "

    const-string/jumbo v2, "vvo oDceesmedduiiRAeon"

    const/4 v8, 0x1

    const-string v2, "eodnmiRpeei cudsoeoADv"

    const-string/jumbo v2, "onAudioDevicesRemoved "

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v1, p1}, Lcom/zego/ve/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    return-void
.end method

.method public onRoutingChanged(Landroid/media/AudioRouting;)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/zego/ve/o;->a(Landroid/media/AudioRouting;)Landroid/media/AudioDeviceInfo;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v1, "ivqdbe"

    const-string/jumbo v1, "vedeib"

    const/4 v4, 0x2

    const-string/jumbo v1, "vcsdie"

    const-string v1, "device"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const-string p1, "e: me cic ngghdtravuunod"

    const-string p1, "ecahdduneiu etrv:gn oc g"

    const/4 v4, 0x4

    const-string/jumbo p1, "ure ogheodcdgvn niaeict "

    const-string p1, " routing changed device:"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/media/AudioDeviceInfo;->getId()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo p1, "pp:ey, "

    const-string/jumbo p1, "pp:ey, "

    const/4 v4, 0x6

    const-string p1, ",:p ybt"

    const-string p1, ", type:"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string p1, "("

    const-string p1, "("

    const/4 v4, 0x3

    const-string p1, "("

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/zego/ve/AudioDeviceHelper;->getDeviceTypeStr(I)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string p1, ")"

    const-string p1, ")"

    const/4 v4, 0x6

    const-string p1, ")"

    const-string p1, ")"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v1, p1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/media/AudioDeviceInfo;->isSource()Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    move v4, v3

    iget-object p1, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/zego/ve/AudioDeviceHelper;->getRouteType(I)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v0, p1, Lcom/zego/ve/AudioEventMonitor;->cap_original_route_:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget v0, p1, Lcom/zego/ve/AudioEventMonitor;->audio_route_:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-ne v1, v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget v0, p1, Lcom/zego/ve/AudioEventMonitor;->cap_original_route_:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eq v1, v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-boolean v0, p1, Lcom/zego/ve/AudioEventMonitor;->wait_check_sco_:Z

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/zego/ve/AudioEventMonitor;->access$100(Lcom/zego/ve/AudioEventMonitor;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    monitor-enter p1

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/zego/ve/AudioEventMonitor;->event_notify_:Lcom/zego/ve/AudioEventMonitor$IEventNotify;

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0}, Lcom/zego/ve/AudioEventMonitor$IEventNotify;->OnRoutingChange()V

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    monitor-exit p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    throw v0

    :cond_1
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void
.end method
