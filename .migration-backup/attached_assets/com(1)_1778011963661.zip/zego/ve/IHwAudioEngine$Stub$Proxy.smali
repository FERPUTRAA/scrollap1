.class Lcom/zego/ve/IHwAudioEngine$Stub$Proxy;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/zego/ve/IHwAudioEngine;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/IHwAudioEngine$Stub;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "Proxy"
.end annotation


# instance fields
.field private mRemote:Landroid/os/IBinder;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/zego/ve/IHwAudioEngine$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "-ysi~@K ln   b ~ ~ @o/~a@~ tf@u@m@c~~~@~@i /o@@~ d ~~~@ o ~r~b~li@~@ @fo@~@~~. b~@@~Mo4Ss@ o1tv@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/ve/IHwAudioEngine$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public getSupportedFeatures()Ljava/util/List;
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v2, "I.amawmogaudwiEcmoetinden.s.iueHeo.gudAiinlniihu"

    const-string/jumbo v2, "uisAeuiwhgaieeio.wmEodeiat.ndoud.enluIc.nHigamni"

    const-string/jumbo v2, "u.eiowdcuunno.nnim.mEAHiduegiiede.ahotieIimowagl"

    const-string v2, "com.huawei.multimedia.audioengine.IHwAudioEngine"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/zego/ve/IHwAudioEngine$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 v3, 0x1

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x2

    invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Landroid/os/Parcel;->readArrayList(Ljava/lang/ClassLoader;)Ljava/util/ArrayList;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x2

    const/4 v5, 0x0

    return-object v2

    :catchall_0
    move-exception v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    throw v2
.end method

.method public init(Ljava/lang/String;Ljava/lang/String;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo v2, "twnmiu.eecaAnm.Iu.aiinemouionddieimEghHagiwdul.e"

    const-string v2, "com.huawei.multimedia.audioengine.IHwAudioEngine"

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/zego/ve/IHwAudioEngine$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 p2, 0x3

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x1

    invoke-interface {p1, p2, v0, v1, v2}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    throw p1
.end method

.method public isFeatureSupported(I)Z
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v5, 0x2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo v2, "mAdeobcHoidtmnueiiiegEn.wiiaednnueluiawu..a.ghoI"

    const-string v2, "com.huawei.multimedia.audioengine.IHwAudioEngine"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/zego/ve/IHwAudioEngine$Stub$Proxy;->mRemote:Landroid/os/IBinder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x1

    shr-int/2addr v4, v3

    const/4 v5, 0x3

    invoke-interface {p1, v2, v0, v1, v3}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->readInt()I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v3, 0x1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    return v3

    :catchall_0
    move-exception p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    throw p1
.end method
