.class public Lcom/zego/ve/CameraAvailabilityCallback;
.super Landroid/hardware/camera2/CameraManager$AvailabilityCallback;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x15
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/CameraAvailabilityCallback$Listener;
    }
.end annotation


# instance fields
.field private mCameraId:Ljava/lang/String;

.field private mIsFirstTime:Z

.field private mListener:Lcom/zego/ve/CameraAvailabilityCallback$Listener;

.field private final mThis:Ljava/util/concurrent/atomic/AtomicLong;


# direct methods
.method public constructor <init>(JILcom/zego/ve/CameraAvailabilityCallback$Listener;)V
    .locals 4

    const/4 v3, 0x5

    invoke-direct {p0}, Landroid/hardware/camera2/CameraManager$AvailabilityCallback;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mThis:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mCameraId:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-boolean v1, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mIsFirstTime:Z

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object p4, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mListener:Lcom/zego/ve/CameraAvailabilityCallback$Listener;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p3}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mCameraId:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-boolean p1, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mIsFirstTime:Z

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public onCameraAvailable(Ljava/lang/String;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@sscf4~@~ t1i ~y~t ~ ~~@~@  ~ @ ~~~ @~@r  vbmo@@l  a@~ @@@@~@ui@ /~b b-@ooKo@oSn@~~@~~lif~./d~ o"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mThis:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    move v5, v4

    cmp-long v2, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mCameraId:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v2, :cond_1

    const/4 v5, 0x6

    iget-boolean v2, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mIsFirstTime:Z

    const/4 v5, 0x3

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput-boolean p1, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mIsFirstTime:Z

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mListener:Lcom/zego/ve/CameraAvailabilityCallback$Listener;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-interface {v2, v0, v1, p1}, Lcom/zego/ve/CameraAvailabilityCallback$Listener;->onCameraAvailable(JLjava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    return-void
.end method

.method public onCameraUnavailable(Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mThis:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    cmp-long v2, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mCameraId:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-boolean v2, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mIsFirstTime:Z

    const/4 v4, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    const/4 p1, 0x0

    shr-int/2addr v5, p1

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-boolean p1, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mIsFirstTime:Z

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mListener:Lcom/zego/ve/CameraAvailabilityCallback$Listener;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {v2, v0, v1, p1}, Lcom/zego/ve/CameraAvailabilityCallback$Listener;->onCameraUnavailable(JLjava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void
.end method

.method public uninit()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/zego/ve/CameraAvailabilityCallback;->mThis:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void
.end method
