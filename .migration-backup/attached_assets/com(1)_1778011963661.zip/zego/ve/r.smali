.class public final synthetic Lcom/zego/ve/r;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a(Ljava/io/FileDescriptor;)Landroid/media/ExifInterface;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s@~@~~~ b~~bo   @c@ot@@b@@@ /l@@ Si~@mno  t~~~@M~@o@oi@y~@ Kv~f~~l ~uo4   s@af ~~~/~. -@dr1 @i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    new-instance v0, Landroid/media/ExifInterface;

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-direct {v0, p0}, Landroid/media/ExifInterface;-><init>(Ljava/io/FileDescriptor;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method
