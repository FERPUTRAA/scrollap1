.class Lcom/zego/ve/HwAudioKit$3;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/zego/ve/IAudioKitCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/HwAudioKit;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/HwAudioKit;


# direct methods
.method constructor <init>(Lcom/zego/ve/HwAudioKit;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/zego/ve/HwAudioKit$3;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onResult(I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s@na~~~~@~~~/@.b o@@oiMbt Kc ~1  ys~o@i@v~m  ~l~~Sf@lo    o-~~i@b@ ~@@~@d@4/t@ ~ufo @@@@  ~~~r"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v1, "kclmoida a atbsuck"

    const-string/jumbo v1, "kds aalctauo lkicb"

    const/4 v3, 0x4

    const-string v1, "cialoaklb i ctkduo"

    const-string v1, "audiokit callback "

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v1, "wwutob.diodKKAtAiHHii"

    const-string v1, "HwAudioKit.HwAudioKit"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eq p1, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eq p1, v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x5

    const/4 v3, 0x1

    const/4 v2, 0x7

    if-eq p1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x6

    const/4 v3, 0x0

    const/4 v2, 0x2

    if-eq p1, v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    packed-switch p1, :pswitch_data_0

    const/4 v3, 0x4

    goto :goto_0

    :pswitch_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$3;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v0, Lcom/zego/ve/HwAudioKit$state;->state_karaoke_failed:Lcom/zego/ve/HwAudioKit$state;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p1, Lcom/zego/ve/HwAudioKit;->_state:Lcom/zego/ve/HwAudioKit$state;

    const/4 v3, 0x4

    goto :goto_0

    :pswitch_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$3;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    sget-object v0, Lcom/zego/ve/HwAudioKit$state;->state_karaoke_success:Lcom/zego/ve/HwAudioKit$state;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p1, Lcom/zego/ve/HwAudioKit;->_state:Lcom/zego/ve/HwAudioKit$state;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$3;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Lcom/zego/ve/HwAudioKit$state;->state_audiokit_failed:Lcom/zego/ve/HwAudioKit$state;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p1, Lcom/zego/ve/HwAudioKit;->_state:Lcom/zego/ve/HwAudioKit$state;

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$3;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/zego/ve/HwAudioKit$state;->state_audiokit_success:Lcom/zego/ve/HwAudioKit$state;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p1, Lcom/zego/ve/HwAudioKit;->_state:Lcom/zego/ve/HwAudioKit$state;

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$3;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x3

    iget-object p1, p1, Lcom/zego/ve/HwAudioKit;->barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v3, 0x6

    const/4 v2, 0x3

    if-eqz p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x3e8
        :pswitch_1
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method
