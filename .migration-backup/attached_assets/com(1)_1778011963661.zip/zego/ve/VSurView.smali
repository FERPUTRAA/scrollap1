.class public Lcom/zego/ve/VSurView;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/SurfaceHolder$Callback;


# instance fields
.field private final lock:Ljava/lang/Object;

.field private mSurView:Landroid/view/SurfaceView;

.field private pthis:J


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    iput-wide v0, p0, Lcom/zego/ve/VSurView;->pthis:J

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/zego/ve/VSurView;->mSurView:Landroid/view/SurfaceView;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/zego/ve/VSurView;->lock:Ljava/lang/Object;

    const/4 v3, 0x1

    return-void
.end method

.method private static native on_surface_changed(JLandroid/view/SurfaceHolder;III)I
.end method

.method private static native on_surface_created(JLandroid/view/SurfaceHolder;)I
.end method

.method private static native on_surface_destroyed(JLandroid/view/SurfaceHolder;)I
.end method


# virtual methods
.method public removeView()I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s@~@Mvo ~ @ lSdu~  @~y~~~b~K@ miti@~@-~cr~ ~ @~ ~~@~o~aso/o   o~/b@ @4~f~@@@@1l ob@~~ @@if  n."

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/zego/ve/VSurView;->lock:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/zego/ve/VSurView;->mSurView:Landroid/view/SurfaceView;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v1, p0}, Landroid/view/SurfaceHolder;->removeCallback(Landroid/view/SurfaceHolder$Callback;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/zego/ve/VSurView;->mSurView:Landroid/view/SurfaceView;

    :cond_1
    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    return v0

    :catchall_0
    move-exception v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    throw v1
.end method

.method public setThis(J)I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/zego/ve/VSurView;->lock:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x5

    iput-wide p1, p0, Lcom/zego/ve/VSurView;->pthis:J

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    monitor-exit v0

    const/4 v2, 0x7

    const/4 p1, 0x4

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    throw p1
.end method

.method public setView(Landroid/view/SurfaceView;)I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/ve/VSurView;->lock:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v1, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/zego/ve/VSurView;->removeView()I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/zego/ve/VSurView;->mSurView:Landroid/view/SurfaceView;

    const/4 v2, 0x7

    const/4 v1, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {p1, p0}, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    monitor-exit v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    throw p1
.end method

.method public surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/zego/ve/VSurView;->lock:Ljava/lang/Object;

    const/4 v7, 0x6

    xor-int/2addr v8, v7

    monitor-enter v0

    :try_start_0
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget-wide v1, p0, Lcom/zego/ve/VSurView;->pthis:J

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    cmp-long v3, v1, v3

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-eqz v3, :cond_0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    move v4, p2

    move v4, p2

    const/4 v8, 0x5

    move v4, p2

    move v4, p2

    const/4 v7, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    move v5, p3

    move v5, p3

    const/4 v8, 0x0

    move v5, p3

    move v5, p3

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    move v6, p4

    move v6, p4

    const/4 v8, 0x0

    move v6, p4

    move v6, p4

    const/4 v8, 0x5

    const/4 v7, 0x3

    invoke-static/range {v1 .. v6}, Lcom/zego/ve/VSurView;->on_surface_changed(JLandroid/view/SurfaceHolder;III)I

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    monitor-exit v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method

.method public surfaceCreated(Landroid/view/SurfaceHolder;)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/zego/ve/VSurView;->lock:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-wide v1, p0, Lcom/zego/ve/VSurView;->pthis:J

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x6

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    cmp-long v3, v1, v3

    const/4 v6, 0x6

    if-eqz v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v1, v2, p1}, Lcom/zego/ve/VSurView;->on_surface_created(JLandroid/view/SurfaceHolder;)I

    :cond_0
    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    throw p1
.end method

.method public surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .locals 7

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/zego/ve/VSurView;->lock:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-wide v1, p0, Lcom/zego/ve/VSurView;->pthis:J

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x4

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x0

    cmp-long v3, v1, v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz v3, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v1, v2, p1}, Lcom/zego/ve/VSurView;->on_surface_destroyed(JLandroid/view/SurfaceHolder;)I

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    throw p1
.end method
