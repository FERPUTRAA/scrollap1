.class Lcom/zego/ve/AudioEventMonitor$7;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/media/AudioManager$OnAudioFocusChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/AudioEventMonitor;->InitAudioFocusChangeListener()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/AudioEventMonitor;


# direct methods
.method constructor <init>(Lcom/zego/ve/AudioEventMonitor;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor$7;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v1, 0x5

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onAudioFocusChange(I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "i@s@oKor~4~1 ~a @@uf ovo @~~t@  @@~ c@/@l /@~d@~ .~@ib omf~~~s@~ - ~ MtS@~@o~i@ ~ ~n@~l@ b~~y@~b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor$7;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/zego/ve/AudioEventMonitor;->access$100(Lcom/zego/ve/AudioEventMonitor;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor$7;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, v1, Lcom/zego/ve/AudioEventMonitor;->event_notify_:Lcom/zego/ve/AudioEventMonitor$IEventNotify;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {v1, p1}, Lcom/zego/ve/AudioEventMonitor$IEventNotify;->OnAudioFocusChange(I)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    throw p1
.end method
