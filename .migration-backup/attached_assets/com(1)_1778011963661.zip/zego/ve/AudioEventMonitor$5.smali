.class Lcom/zego/ve/AudioEventMonitor$5;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/AudioEventMonitor;->UninitPhoneStateListener()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/AudioEventMonitor;


# direct methods
.method constructor <init>(Lcom/zego/ve/AudioEventMonitor;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor$5;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    shl-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "4@s~@@@@ ~ @@  rt@ nob~i~i ooS~b~ ~ml@~@ ~@ @~tl 1f/@oK@ ~@yf~boa ~ c-~/~. @ ~@@M~~v~@  @~~s~odu"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    const-string v0, "dcemvi"

    const-string/jumbo v0, "icsdve"

    const/4 v5, 0x6

    const-string v0, "devcoi"

    const-string v0, "device"

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor$5;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, v1, Lcom/zego/ve/AudioEventMonitor;->_phoneStateListener:Landroid/telephony/PhoneStateListener;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v1, "e cesbclsn i onrtu em riapstttatpnotltali"

    const-string/jumbo v1, "tcimn eliielutt aon opttrt cl ansrarpesst"

    const/4 v5, 0x2

    const-string/jumbo v1, "lcecoeuns tniittleati rtast roustl pneapr"

    const-string/jumbo v1, "trace interruption stop call state listen"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v0, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor$5;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/zego/ve/AudioEventMonitor;->_context:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v2, "hnpoo"

    const-string/jumbo v2, "henoo"

    const/4 v5, 0x6

    const-string/jumbo v2, "hopqe"

    const-string/jumbo v2, "phone"

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    check-cast v1, Landroid/telephony/TelephonyManager;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/zego/ve/AudioEventMonitor$5;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v2, v2, Lcom/zego/ve/AudioEventMonitor;->_phoneStateListener:Landroid/telephony/PhoneStateListener;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v1, v2, v3}, Landroid/telephony/TelephonyManager;->listen(Landroid/telephony/PhoneStateListener;I)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor$5;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v4, 0x2

    const/4 v2, 0x0

    move v5, v2

    const/4 v4, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    iput-object v2, v1, Lcom/zego/ve/AudioEventMonitor;->_phoneStateListener:Landroid/telephony/PhoneStateListener;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v3, "UninitPhoneStateListener failed, "

    const-string v3, "UninitPhoneStateListener failed, "

    const/4 v5, 0x0

    const-string v3, "UninitPhoneStateListener failed, "

    const-string v3, "UninitPhoneStateListener failed, "

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    :goto_0
    const/4 v5, 0x1

    return-void
.end method
