.class public Lcom/zego/ve/VClk;
.super Ljava/lang/Object;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x10
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/VClk$EventHandler;
    }
.end annotation


# static fields
.field private static final MESSAGE_RESTART:I = 0x2

.field private static final MESSAGE_START:I = 0x0

.field private static final MESSAGE_STOP:I = 0x1

.field private static final TAG:Ljava/lang/String; = "VClk"

.field private static sInstance:Lcom/zego/ve/VClk;


# instance fields
.field private mCallback:Lcom/zego/ve/VClk$EventHandler;

.field private mHandler:Landroid/os/Handler;

.field private mThread:Landroid/os/HandlerThread;

.field private pThis:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Lcom/zego/ve/VClk;

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/zego/ve/VClk;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    sput-object v0, Lcom/zego/ve/VClk;->sInstance:Lcom/zego/ve/VClk;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method constructor <init>()V
    .locals 5

    const/4 v4, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/zego/ve/VClk;->mThread:Landroid/os/HandlerThread;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/zego/ve/VClk;->mCallback:Lcom/zego/ve/VClk$EventHandler;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/zego/ve/VClk;->mHandler:Landroid/os/Handler;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-wide v1, p0, Lcom/zego/ve/VClk;->pThis:J

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance v1, Landroid/os/HandlerThread;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string v2, "VCkl"

    const-string/jumbo v2, "lVkC"

    const/4 v4, 0x6

    const-string v2, "VClk"

    const/4 v4, 0x7

    invoke-direct {v1, v2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-object v1, p0, Lcom/zego/ve/VClk;->mThread:Landroid/os/HandlerThread;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v1, Lcom/zego/ve/VClk$EventHandler;

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    invoke-direct {v1, v0}, Lcom/zego/ve/VClk$EventHandler;-><init>(Lcom/zego/ve/VClk$1;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/zego/ve/VClk;->mCallback:Lcom/zego/ve/VClk$EventHandler;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v0, Landroid/os/Handler;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/zego/ve/VClk;->mThread:Landroid/os/HandlerThread;

    const/4 v4, 0x3

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/zego/ve/VClk;->mCallback:Lcom/zego/ve/VClk$EventHandler;

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/zego/ve/VClk;->mHandler:Landroid/os/Handler;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-void
.end method

.method static synthetic access$100(J)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "tbs~b/@  @~o  S@i~r ~M  ~y sn ~~@l @@@@~ m@of~io~~/ ~~~  l~o~.f@o~o ~@1@@i~~bt@@va ~@@-c@ ~u@dK4"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {p0, p1}, Lcom/zego/ve/VClk;->on_error(J)I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic access$200(JJ)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, p1, p2, p3}, Lcom/zego/ve/VClk;->on_video_tick(JJ)I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p0
.end method

.method private static getInstance()Lcom/zego/ve/VClk;
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/zego/ve/VClk;->sInstance:Lcom/zego/ve/VClk;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method private static native on_error(J)I
.end method

.method private static native on_video_tick(JJ)I
.end method


# virtual methods
.method public restartClock()I
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-wide v0, p0, Lcom/zego/ve/VClk;->pThis:J

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/ve/VClk;->mHandler:Landroid/os/Handler;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v1, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x4

    return v0
.end method

.method public start(J)I
    .locals 2

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/zego/ve/VClk;->pThis:J

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p1
.end method

.method public startClock()I
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-wide v0, p0, Lcom/zego/ve/VClk;->pThis:J

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    cmp-long v2, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v2, :cond_0

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/zego/ve/VClk;->mCallback:Lcom/zego/ve/VClk$EventHandler;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v2, v0, v1}, Lcom/zego/ve/VClk$EventHandler;->init(J)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/ve/VClk;->mHandler:Landroid/os/Handler;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v3}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    return v3
.end method

.method public stop(J)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/zego/ve/VClk;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    const/4 p2, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v1, 0x5

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-wide p1, p0, Lcom/zego/ve/VClk;->pThis:J

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p1
.end method

.method public stopClock()I
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-wide v0, p0, Lcom/zego/ve/VClk;->pThis:J

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x1

    const-wide/16 v2, 0x0

    const/4 v4, 0x1

    move v5, v4

    cmp-long v0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    move v5, v4

    iget-object v0, p0, Lcom/zego/ve/VClk;->mHandler:Landroid/os/Handler;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendEmptyMessage(I)Z

    const/4 v5, 0x3

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/zego/ve/VClk;->mCallback:Lcom/zego/ve/VClk$EventHandler;

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    invoke-virtual {v0}, Lcom/zego/ve/VClk$EventHandler;->uninit()V

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v0
.end method
