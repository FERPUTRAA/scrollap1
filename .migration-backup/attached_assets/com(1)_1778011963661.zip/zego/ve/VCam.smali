.class public Lcom/zego/ve/VCam;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/VCam$Cam2Device;,
        Lcom/zego/ve/VCam$CamDevice;,
        Lcom/zego/ve/VCam$CameraDev;
    }
.end annotation


# static fields
.field private static final EXPOSURE_MODE_AUTO:I = 0x0

.field private static final EXPOSURE_MODE_AUTO_EXPOSURE:I = 0x4

.field private static final EXPOSURE_MODE_CONTINUOUS_AUTO_EXPOSURE:I = 0x5

.field private static final EXPOSURE_MODE_CUSTOM:I = 0x1

.field private static final FOCUS_MODE_AUTO:I = 0x0

.field private static final FOCUS_MODE_AUTO_FOCUS:I = 0x8

.field private static final FOCUS_MODE_CONTINUOUS_AUTO_FOCUS:I = 0x9

.field private static final FOCUS_MODE_CONTINUOUS_PICTURE:I = 0x6

.field private static final FOCUS_MODE_CONTINUOUS_VIDEO:I = 0x5

.field private static final FOCUS_MODE_EDOF:I = 0x4

.field private static final FOCUS_MODE_FIXED:I = 0x3

.field private static final FOCUS_MODE_INFINITY:I = 0x1

.field private static final FOCUS_MODE_MACRO:I = 0x2

.field private static final MESSAGE_EXPOSURE_LOCK:I = 0x0

.field private static final NUMBER_OF_CAPTURE_BUFFERS:I = 0x3

.field private static final SCENE_MODE_ACTION:I = 0x3

.field private static final SCENE_MODE_LOW_LIGHT:I = 0x1

.field private static final SCENE_MODE_NIGHT:I = 0x2

.field private static final SCENE_MODE_NONE:I = 0x0

.field private static final SCENE_MODE_PORTRAIT:I = 0x4

.field private static final TAG:Ljava/lang/String; = "vcap"


# instance fields
.field mAreaSize:I

.field mBackCameraId:I

.field private mCamDevice:Lcom/zego/ve/VCam$CameraDev;

.field private mCamera2Error:Z

.field private mCameraAvailabilityCallback:Lcom/zego/ve/CameraAvailabilityCallback;

.field private mCameraIDList:[Ljava/lang/String;

.field private mContext:Landroid/content/Context;

.field mExposureCompensation:F

.field private mExposureGeneration:I

.field mExposureMode:I

.field mExposurePointX:F

.field mExposurePointY:F

.field mFPSMode:I

.field mFocusMode:I

.field mFocusPointX:F

.field mFocusPointY:F

.field mFpsMax:I

.field mFpsMin:I

.field mFrameRate:I

.field private mFrameSize:I

.field mFrontCameraId:I

.field private mHandler:Landroid/os/Handler;

.field mHeight:I

.field mIsFocusing:Z

.field mLowLightBoost:Z

.field mNeedHack:Z

.field mSceneMode:I

.field private mThis:J

.field private mTryDefault:Z

.field mUseCameraId:I

.field mUseFaceDetection:Z

.field mWidth:I

.field private matrix:Landroid/graphics/Matrix;

.field private final queuedBuffers:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "[B>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput-wide v0, p0, Lcom/zego/ve/VCam;->mThis:J

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput-object v0, p0, Lcom/zego/ve/VCam;->mContext:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/zego/ve/VCam;->mCameraAvailabilityCallback:Lcom/zego/ve/CameraAvailabilityCallback;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/16 v1, 0x280

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput v1, p0, Lcom/zego/ve/VCam;->mWidth:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/16 v1, 0x1e0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    iput v1, p0, Lcom/zego/ve/VCam;->mHeight:I

    const/4 v4, 0x0

    move v5, v4

    const/16 v1, 0xf

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    iput v1, p0, Lcom/zego/ve/VCam;->mFrameRate:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x2

    iput-boolean v1, p0, Lcom/zego/ve/VCam;->mNeedHack:Z

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v2, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    iput v2, p0, Lcom/zego/ve/VCam;->mFocusMode:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput v2, p0, Lcom/zego/ve/VCam;->mExposureMode:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput v3, p0, Lcom/zego/ve/VCam;->mExposureCompensation:F

    const/4 v5, 0x0

    iput v3, p0, Lcom/zego/ve/VCam;->mFocusPointX:F

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput v3, p0, Lcom/zego/ve/VCam;->mFocusPointY:F

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput v3, p0, Lcom/zego/ve/VCam;->mExposurePointX:F

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput v3, p0, Lcom/zego/ve/VCam;->mExposurePointY:F

    const/4 v5, 0x6

    const/4 v4, 0x7

    iput v2, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput v2, p0, Lcom/zego/ve/VCam;->mBackCameraId:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    iput v2, p0, Lcom/zego/ve/VCam;->mUseCameraId:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput v1, p0, Lcom/zego/ve/VCam;->mFPSMode:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput-boolean v1, p0, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    iput-boolean v1, p0, Lcom/zego/ve/VCam;->mIsFocusing:Z

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput v1, p0, Lcom/zego/ve/VCam;->mAreaSize:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v2, Landroid/graphics/Matrix;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v2}, Landroid/graphics/Matrix;-><init>()V

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput-object v2, p0, Lcom/zego/ve/VCam;->matrix:Landroid/graphics/Matrix;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput v1, p0, Lcom/zego/ve/VCam;->mSceneMode:I

    const/4 v2, 0x3

    move v5, v2

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    iput-boolean v2, p0, Lcom/zego/ve/VCam;->mTryDefault:Z

    const/4 v5, 0x0

    iput-boolean v1, p0, Lcom/zego/ve/VCam;->mCamera2Error:Z

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    iput-boolean v1, p0, Lcom/zego/ve/VCam;->mLowLightBoost:Z

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/zego/ve/VCam;->mHandler:Landroid/os/Handler;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput v1, p0, Lcom/zego/ve/VCam;->mExposureGeneration:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/16 v2, -0x3e8

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput v2, p0, Lcom/zego/ve/VCam;->mFpsMin:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput v2, p0, Lcom/zego/ve/VCam;->mFpsMax:I

    const/4 v5, 0x7

    new-instance v2, Ljava/util/HashSet;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput-object v2, p0, Lcom/zego/ve/VCam;->queuedBuffers:Ljava/util/Set;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput v1, p0, Lcom/zego/ve/VCam;->mFrameSize:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput-object v0, p0, Lcom/zego/ve/VCam;->mCameraIDList:[Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method

.method private GetCameraString(I)Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~/sf@@ucb~K~ ~@ @@@@~~~t@~-bS@r@M@@ o@@~ @~  ~mi   /ot~n4~oi~y @iovb ~~l 1~.@ ~@~  ~ la@o dof~s~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget v0, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-ne p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string p1, "cnomtmsrfa r"

    const-string/jumbo p1, "frsao metnrc"

    const/4 v2, 0x5

    const-string/jumbo p1, "front camera"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const-string/jumbo p1, "macmoarkcbe"

    const-string p1, "acamrkemcba"

    const/4 v2, 0x6

    const-string p1, "back camera"

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p1
.end method

.method static synthetic access$000(Lcom/zego/ve/VCam;Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/zego/ve/VCam;->isNumericString(Ljava/lang/String;)Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic access$100(JI)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lcom/zego/ve/VCam;->onCameraAvailable(JI)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$1000(Lcom/zego/ve/VCam;)Ljava/util/Set;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/zego/ve/VCam;->queuedBuffers:Ljava/util/Set;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$1100(Lcom/zego/ve/VCam;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    iget p0, p0, Lcom/zego/ve/VCam;->mFrameSize:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic access$1102(Lcom/zego/ve/VCam;I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/zego/ve/VCam;->mFrameSize:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    return p1
.end method

.method static synthetic access$1200(Lcom/zego/ve/VCam;)J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/zego/ve/VCam;->mThis:J

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-wide v0
.end method

.method static synthetic access$1300(J[BI)V
    .locals 2

    const/4 v1, 0x1

    invoke-static {p0, p1, p2, p3}, Lcom/zego/ve/VCam;->onBufferAvailable(J[BI)V

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic access$1602(Lcom/zego/ve/VCam;Z)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/zego/ve/VCam;->mCamera2Error:Z

    const/4 v1, 0x7

    return p1
.end method

.method static synthetic access$1900(Lcom/zego/ve/VCam;)Landroid/content/Context;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/zego/ve/VCam;->mContext:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$200(JI)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lcom/zego/ve/VCam;->onCameraUnavailable(JI)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    return-void
.end method

.method static synthetic access$2000(Lcom/zego/ve/VCam;)[Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/zego/ve/VCam;->mCameraIDList:[Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic access$300(Lcom/zego/ve/VCam;I)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/zego/ve/VCam;->GetCameraString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic access$400(Lcom/zego/ve/VCam;)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget-boolean p0, p0, Lcom/zego/ve/VCam;->mTryDefault:Z

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic access$500(Lcom/zego/ve/VCam;)Z
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/zego/ve/VCam;->isSupportCamera2()Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic access$600(Lcom/zego/ve/VCam;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/zego/ve/VCam;->registerCameraAvailabilityCallback(I)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$700(Lcom/zego/ve/VCam;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget p0, p0, Lcom/zego/ve/VCam;->mExposureGeneration:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic access$708(Lcom/zego/ve/VCam;)I
    .locals 4

    iget v0, p0, Lcom/zego/ve/VCam;->mExposureGeneration:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    add-int/lit8 v1, v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput v1, p0, Lcom/zego/ve/VCam;->mExposureGeneration:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v0
.end method

.method static synthetic access$900(Lcom/zego/ve/VCam;)Landroid/os/Handler;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/zego/ve/VCam;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method static clamp(III)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    if-le p0, p2, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p2

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-ge p0, p1, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p1

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return p0
.end method

.method static clamp2(FFF)F
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    cmpl-float v0, p0, p2

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-lez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return p2

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    cmpg-float p2, p0, p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    if-gez p2, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return p1

    :cond_1
    const/4 v1, 0x7

    const/4 v2, 0x2

    return p0
.end method

.method private isNumericString(Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x7

    move v1, v0

    move v1, v0

    const/4 v4, 0x0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-ge v1, v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v2}, Ljava/lang/Character;->isDigit(C)Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 p1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    return p1
.end method

.method private isSupportCamera2()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    return v0
.end method

.method private static native onBufferAvailable(J[BI)V
.end method

.method private static native onCameraAvailable(JI)V
.end method

.method private static native onCameraUnavailable(JI)V
.end method

.method private registerCameraAvailabilityCallback(I)V
    .locals 7
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam;->mContext:Landroid/content/Context;

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string v1, "eamcob"

    const-string/jumbo v1, "maecoa"

    const/4 v6, 0x3

    const-string/jumbo v1, "umeaca"

    const-string v1, "camera"

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    check-cast v0, Landroid/hardware/camera2/CameraManager;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance v1, Lcom/zego/ve/CameraAvailabilityCallback;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-wide v2, p0, Lcom/zego/ve/VCam;->mThis:J

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance v4, Lcom/zego/ve/VCam$1;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {v4, p0}, Lcom/zego/ve/VCam$1;-><init>(Lcom/zego/ve/VCam;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v1, v2, v3, p1, v4}, Lcom/zego/ve/CameraAvailabilityCallback;-><init>(JILcom/zego/ve/CameraAvailabilityCallback$Listener;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    iput-object v1, p0, Lcom/zego/ve/VCam;->mCameraAvailabilityCallback:Lcom/zego/ve/CameraAvailabilityCallback;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 p1, 0x0

    const/4 v5, 0x5

    or-int/2addr v6, v5

    invoke-virtual {v0, v1, p1}, Landroid/hardware/camera2/CameraManager;->registerAvailabilityCallback(Landroid/hardware/camera2/CameraManager$AvailabilityCallback;Landroid/os/Handler;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const-string/jumbo v1, "registerCameraAvailabilityCallback failed, "

    const-string/jumbo v1, "registerCameraAvailabilityCallback failed, "

    const/4 v6, 0x4

    const-string/jumbo v1, "registerCameraAvailabilityCallback failed, "

    const-string/jumbo v1, "registerCameraAvailabilityCallback failed, "

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const-string v0, "apcv"

    const-string/jumbo v0, "vcap"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v0, p1}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    return-void
.end method

.method private unregisterCameraAvailabilityCallback()V
    .locals 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam;->mContext:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCameraAvailabilityCallback:Lcom/zego/ve/CameraAvailabilityCallback;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {v0}, Lcom/zego/ve/CameraAvailabilityCallback;->uninit()V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam;->mContext:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v1, "cpabem"

    const-string v1, "acaemb"

    const/4 v4, 0x4

    const-string v1, "eaqrac"

    const-string v1, "camera"

    const/4 v3, 0x7

    move v4, v3

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    check-cast v0, Landroid/hardware/camera2/CameraManager;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/zego/ve/VCam;->mCameraAvailabilityCallback:Lcom/zego/ve/CameraAvailabilityCallback;

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CameraManager;->unregisterAvailabilityCallback(Landroid/hardware/camera2/CameraManager$AvailabilityCallback;)V

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/zego/ve/VCam;->mCameraAvailabilityCallback:Lcom/zego/ve/CameraAvailabilityCallback;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    and-int/2addr v4, v3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string/jumbo v2, "unregisterCameraAvailabilityCallback failed, "

    const-string/jumbo v2, "unregisterCameraAvailabilityCallback failed, "

    const/4 v4, 0x7

    const-string/jumbo v2, "unregisterCameraAvailabilityCallback failed, "

    const-string/jumbo v2, "unregisterCameraAvailabilityCallback failed, "

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v1, "pacv"

    const-string v1, "cavp"

    const/4 v4, 0x0

    const-string/jumbo v1, "vcap"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v1, v0}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void
.end method


# virtual methods
.method checkPermission()Z
    .locals 4

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/zego/ve/VCam;->mContext:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v1, "MasdERurd.spioer.oinsnAAC"

    const-string/jumbo v1, "oieioausEsnrCAAind..MRpdr"

    const/4 v3, 0x1

    const-string v1, "EasmdriMdrneioCm.R.nipAAo"

    const-string v1, "android.permission.CAMERA"

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/zego/ve/PermissionChecker;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    return v0
.end method

.method closeTorch()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x6

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/zego/ve/VCam$CameraDev;->closeTorch()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method createCam(IIZZ)I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const-string v0, "capv"

    const-string v0, "avpc"

    const/4 v3, 0x6

    const-string v0, "cvpa"

    const-string/jumbo v0, "vcap"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    if-ne p1, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo p1, "raeiopvlnd :icdp mica v"

    const-string p1, "aa  cmvp edniciapvldi:r"

    const/4 v3, 0x3

    const-string/jumbo p1, "vcap: invalid camera id"

    const/4 v3, 0x6

    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput p2, p0, Lcom/zego/ve/VCam;->mSceneMode:I

    const/4 v3, 0x3

    iput-boolean p3, p0, Lcom/zego/ve/VCam;->mLowLightBoost:Z

    const/4 v3, 0x6

    if-eqz p4, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/zego/ve/VCam;->isSupportCamera2()Z

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz p2, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-boolean p2, p0, Lcom/zego/ve/VCam;->mCamera2Error:Z

    const/4 v2, 0x4

    move v3, v2

    if-nez p2, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance p2, Lcom/zego/ve/VCam$Cam2Device;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p2, p0}, Lcom/zego/ve/VCam$Cam2Device;-><init>(Lcom/zego/ve/VCam;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object p2, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p2, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance p2, Lcom/zego/ve/VCam$CamDevice;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p2, p0}, Lcom/zego/ve/VCam$CamDevice;-><init>(Lcom/zego/ve/VCam;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-object p2, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 p2, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string p4, "atmacbrec:aqrie "

    const-string p4, "aed:aitcq cemrra"

    const/4 v3, 0x2

    const-string p4, " reaaruecce:atdi"

    const-string p4, "create cameraid:"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string p4, "amcsar:p "

    const-string/jumbo p4, "mcs aera:"

    const/4 v3, 0x5

    const-string p4, "2m acaerq"

    const-string p4, " camera2:"

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0, p3}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v1, "-rsb: dpa -ocv "

    const-string v1, " :dm- c-bar pvo"

    const-string/jumbo v1, "rp ma-oa  dv:b-"

    const-string/jumbo v1, "vcap -- board: "

    const/4 v3, 0x4

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v1, Landroid/os/Build;->BOARD:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v1, " e iocodv"

    const-string v1, "  dvoic:e"

    const/4 v3, 0x7

    const-string v1, "dev ebc: "

    const-string v1, " device: "

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    sget-object v1, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string/jumbo v1, "feruumurat  n:c"

    const-string v1, " manufacturer: "

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    sget-object v1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const-string v1, "d:b nrbp"

    const-string/jumbo v1, "n :dbbr "

    const/4 v3, 0x6

    const-string/jumbo v1, "qn:dr a "

    const-string v1, " brand: "

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    sget-object v1, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v3, 0x1

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    move v3, v2

    const-string v1, ":esumldo"

    const-string v1, " :dleoum"

    const/4 v3, 0x4

    const-string/jumbo v1, "oldm em "

    const-string v1, " model: "

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v1, "pudoo pt c"

    const-string v1, "d octrpp u"

    const/4 v3, 0x0

    const-string/jumbo v1, "td :ubrco "

    const-string v1, " product: "

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    sget-object v1, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    const-string v1, "  qsk:"

    const/4 v3, 0x5

    const-string/jumbo v1, "u: sd "

    const-string v1, " sdk: "

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v1, "i ar:ecpad"

    const-string v1, "easdai r:c"

    const/4 v3, 0x5

    const-string/jumbo v1, "iaedcrm:q "

    const-string v1, " cameraid:"

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object p2, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p2, p1}, Lcom/zego/ve/VCam$CameraDev;->createCam(I)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return p1
.end method

.method enumerateCamera(Z)V
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v0, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/4 v1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz p1, :cond_0

    const/4 v7, 0x7

    invoke-direct {p0}, Lcom/zego/ve/VCam;->isSupportCamera2()Z

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eqz p1, :cond_0

    const/4 v7, 0x4

    iget-boolean p1, p0, Lcom/zego/ve/VCam;->mCamera2Error:Z

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-nez p1, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/zego/ve/VCam;->enumerateCamera2()V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    move p1, v0

    move p1, v0

    const/4 v7, 0x0

    move p1, v0

    move p1, v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    move p1, v1

    move p1, v1

    const/4 v7, 0x7

    move p1, v1

    move p1, v1

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-eqz p1, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-boolean p1, p0, Lcom/zego/ve/VCam;->mCamera2Error:Z

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eqz p1, :cond_4

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance p1, Landroid/hardware/Camera$CameraInfo;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {p1}, Landroid/hardware/Camera$CameraInfo;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {}, Landroid/hardware/Camera;->getNumberOfCameras()I

    move-result v2

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-ge v1, v2, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {v1, p1}, Landroid/hardware/Camera;->getCameraInfo(ILandroid/hardware/Camera$CameraInfo;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget v3, p1, Landroid/hardware/Camera$CameraInfo;->facing:I

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v4, -0x1

    const/4 v7, 0x5

    const/4 v6, 0x3

    if-nez v3, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget v5, p0, Lcom/zego/ve/VCam;->mBackCameraId:I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-ne v5, v4, :cond_2

    iput v1, p0, Lcom/zego/ve/VCam;->mBackCameraId:I

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-ne v3, v0, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x3

    iget v3, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    const/4 v7, 0x6

    if-ne v3, v4, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    iput v1, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_1

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string v0, "eesnpCmariaerraeeacmr totiiutmsur  e httn"

    const-string/jumbo v0, "reemr msrtutie aetu eeomrri:ctnCnpia ahat"

    const/4 v7, 0x0

    const-string/jumbo v0, "nrrmummttitacp  eCinee:ea r rtseaoahutnei"

    const-string/jumbo v0, "trace interruption enumerateCamera this: "

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string/jumbo v0, "m:Irodmonaora F,Ct"

    const-string v0, ": troFamrIo ndCam,"

    const/4 v7, 0x1

    const-string/jumbo v0, "rr tabFm d,en:ImCo"

    const-string v0, ", mFrontCameraId: "

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    iget v0, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-string v0, "ea, ICumrca:k adm"

    const-string v0, "C,armback :maI de"

    const/4 v7, 0x3

    const-string v0, " BdaIa paC:ck,rem"

    const-string v0, ", mBackCameraId: "

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget v0, p0, Lcom/zego/ve/VCam;->mBackCameraId:I

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string/jumbo v0, "vcpa"

    const-string/jumbo v0, "pavc"

    const/4 v7, 0x3

    const-string v0, "apvc"

    const-string/jumbo v0, "vcap"

    const/4 v7, 0x3

    invoke-static {v0, p1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-void
.end method

.method enumerateCamera2()V
    .locals 15
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v14, 0x0

    const-string v0, "acvp"

    const-string/jumbo v0, "pavc"

    const-string/jumbo v0, "vacp"

    const-string/jumbo v0, "vcap"

    const/4 v14, 0x3

    const/4 v1, 0x2

    const/4 v14, 0x4

    new-array v2, v1, [Ljava/lang/String;

    const/4 v14, 0x5

    iput-object v2, p0, Lcom/zego/ve/VCam;->mCameraIDList:[Ljava/lang/String;

    iget-object v2, p0, Lcom/zego/ve/VCam;->mContext:Landroid/content/Context;

    const/4 v14, 0x2

    const-string v3, "eaqmcr"

    const-string/jumbo v3, "umarec"

    const-string v3, "arseca"

    const-string v3, "camera"

    const/4 v14, 0x1

    invoke-virtual {v2, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v14, 0x7

    check-cast v2, Landroid/hardware/camera2/CameraManager;

    const/4 v14, 0x5

    const/4 v3, 0x1

    :try_start_0
    const/4 v14, 0x0

    invoke-virtual {v2}, Landroid/hardware/camera2/CameraManager;->getCameraIdList()[Ljava/lang/String;

    move-result-object v4

    const/4 v14, 0x6

    array-length v5, v4

    const/4 v14, 0x3

    const/4 v6, 0x0

    const/4 v14, 0x1

    move v7, v6

    move v7, v6

    move v7, v6

    move v7, v6

    const/4 v14, 0x4

    move v8, v7

    move v8, v7

    move v8, v7

    move v8, v7

    :goto_0
    const/4 v14, 0x4

    const/4 v9, -0x1

    const/4 v14, 0x5

    if-ge v7, v5, :cond_2

    const/4 v14, 0x7

    aget-object v10, v4, v7

    const/4 v14, 0x3

    invoke-virtual {v2, v10}, Landroid/hardware/camera2/CameraManager;->getCameraCharacteristics(Ljava/lang/String;)Landroid/hardware/camera2/CameraCharacteristics;

    move-result-object v11

    const/4 v14, 0x4

    sget-object v12, Landroid/hardware/camera2/CameraCharacteristics;->LENS_FACING:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v14, 0x1

    invoke-virtual {v11, v12}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v12

    const/4 v14, 0x1

    check-cast v12, Ljava/lang/Integer;

    const/4 v14, 0x3

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    const/4 v14, 0x2

    if-nez v12, :cond_0

    const/4 v14, 0x2

    iget v12, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    const/4 v14, 0x5

    if-ne v12, v9, :cond_0

    add-int/lit8 v12, v8, 0x1

    const/4 v14, 0x0

    iput v8, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    const/4 v14, 0x6

    iget-object v13, p0, Lcom/zego/ve/VCam;->mCameraIDList:[Ljava/lang/String;

    aput-object v10, v13, v8

    const/4 v14, 0x0

    move v8, v12

    move v8, v12

    move v8, v12

    move v8, v12

    :cond_0
    const/4 v14, 0x2

    sget-object v12, Landroid/hardware/camera2/CameraCharacteristics;->LENS_FACING:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v14, 0x5

    invoke-virtual {v11, v12}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v11

    const/4 v14, 0x5

    check-cast v11, Ljava/lang/Integer;

    const/4 v14, 0x6

    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    move-result v11

    const/4 v14, 0x7

    if-ne v11, v3, :cond_1

    const/4 v14, 0x3

    iget v11, p0, Lcom/zego/ve/VCam;->mBackCameraId:I

    const/4 v14, 0x7

    if-ne v11, v9, :cond_1

    const/4 v14, 0x7

    add-int/lit8 v9, v8, 0x1

    const/4 v14, 0x1

    iput v8, p0, Lcom/zego/ve/VCam;->mBackCameraId:I

    const/4 v14, 0x1

    iget-object v11, p0, Lcom/zego/ve/VCam;->mCameraIDList:[Ljava/lang/String;

    const/4 v14, 0x2

    aput-object v10, v11, v8

    const/4 v14, 0x5

    move v8, v9

    move v8, v9

    move v8, v9

    move v8, v9

    :cond_1
    const/4 v14, 0x7

    add-int/lit8 v7, v7, 0x1

    const/4 v14, 0x0

    goto :goto_0

    :cond_2
    const/4 v14, 0x6

    iget v4, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    const/4 v14, 0x7

    if-eq v4, v9, :cond_3

    const/4 v14, 0x6

    iget v4, p0, Lcom/zego/ve/VCam;->mBackCameraId:I

    if-ne v4, v9, :cond_6

    :cond_3
    const/4 v14, 0x7

    iget-object v4, p0, Lcom/zego/ve/VCam;->mContext:Landroid/content/Context;

    const/4 v14, 0x7

    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    const/4 v14, 0x4

    const-string/jumbo v5, "rrameod..laeehamxcndidrewaatarrn"

    const-string v5, "android.hardware.camera.external"

    const/4 v14, 0x0

    invoke-virtual {v4, v5}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v4

    const/4 v14, 0x3

    if-eqz v4, :cond_6

    const/4 v14, 0x5

    invoke-virtual {v2}, Landroid/hardware/camera2/CameraManager;->getCameraIdList()[Ljava/lang/String;

    move-result-object v4

    const/4 v14, 0x2

    array-length v5, v4

    :goto_1
    const/4 v14, 0x3

    if-ge v6, v5, :cond_6

    const/4 v14, 0x6

    aget-object v7, v4, v6

    const/4 v14, 0x6

    invoke-virtual {v2, v7}, Landroid/hardware/camera2/CameraManager;->getCameraCharacteristics(Ljava/lang/String;)Landroid/hardware/camera2/CameraCharacteristics;

    move-result-object v10

    const/4 v14, 0x5

    sget-object v11, Landroid/hardware/camera2/CameraCharacteristics;->LENS_FACING:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v14, 0x3

    invoke-virtual {v10, v11}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v11

    const/4 v14, 0x1

    check-cast v11, Ljava/lang/Integer;

    const/4 v14, 0x6

    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    move-result v11

    const/4 v14, 0x7

    if-ne v11, v1, :cond_4

    iget v11, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    const/4 v14, 0x1

    if-ne v11, v9, :cond_4

    add-int/lit8 v10, v8, 0x1

    const/4 v14, 0x6

    iput v8, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    const/4 v14, 0x0

    iget-object v11, p0, Lcom/zego/ve/VCam;->mCameraIDList:[Ljava/lang/String;

    const/4 v14, 0x1

    aput-object v7, v11, v8

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x4

    const-string v11, " mfxo:tecaetnaol nr"

    const-string v11, " nr:mfepxl ectntaao"

    const-string/jumbo v11, "lntr bmotanxa:c fee"

    const-string v11, "cam external front:"

    const/4 v14, 0x0

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v14, 0x4

    invoke-static {v0, v7}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :goto_2
    const/4 v14, 0x0

    move v8, v10

    move v8, v10

    move v8, v10

    move v8, v10

    goto :goto_3

    :cond_4
    sget-object v11, Landroid/hardware/camera2/CameraCharacteristics;->LENS_FACING:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v14, 0x0

    invoke-virtual {v10, v11}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Integer;

    const/4 v14, 0x4

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    const/4 v14, 0x4

    if-ne v10, v1, :cond_5

    const/4 v14, 0x6

    iget v10, p0, Lcom/zego/ve/VCam;->mBackCameraId:I

    const/4 v14, 0x6

    if-ne v10, v9, :cond_5

    const/4 v14, 0x3

    add-int/lit8 v10, v8, 0x1

    const/4 v14, 0x2

    iput v8, p0, Lcom/zego/ve/VCam;->mBackCameraId:I

    const/4 v14, 0x6

    iget-object v11, p0, Lcom/zego/ve/VCam;->mCameraIDList:[Ljava/lang/String;

    const/4 v14, 0x1

    aput-object v7, v11, v8

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x7

    const-string/jumbo v11, "keaxmluncre abc t"

    const-string v11, "eatrclbcqn xmek a"

    const-string/jumbo v11, "n carx pkbaamletc"

    const-string v11, "cam external back"

    const/4 v14, 0x5

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v14, 0x1

    invoke-static {v0, v7}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_2

    :cond_5
    :goto_3
    const/4 v14, 0x1

    add-int/lit8 v6, v6, 0x1

    const/4 v14, 0x7

    goto/16 :goto_1

    :catch_0
    move-exception v1

    const/4 v14, 0x1

    const-string/jumbo v2, "minde arqpsree:lccaa2faemtaeu "

    const-string v2, "aasecaurle2pd earacf mev:tiemn"

    const-string v2, "dpsaea  a2eimtualc raeefnrcmve"

    const-string/jumbo v2, "vcap: enumerate camera2 failed"

    const/4 v14, 0x2

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v14, 0x3

    iput-boolean v3, p0, Lcom/zego/ve/VCam;->mCamera2Error:Z

    const/4 v14, 0x2

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_6
    const/4 v14, 0x2

    return-void
.end method

.method getBackCameraId()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/zego/ve/VCam;->mBackCameraId:I

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method getFramerate()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/zego/ve/VCam;->mFrameRate:I

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method getFront()I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x2

    shr-int/2addr v3, v1

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    iget v0, p0, Lcom/zego/ve/VCam;->mUseCameraId:I

    const/4 v4, 0x6

    iget v2, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-ne v0, v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v1, 0x1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    return v1
.end method

.method getFrontCameraId()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget v0, p0, Lcom/zego/ve/VCam;->mFrontCameraId:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method getHeight()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/zego/ve/VCam;->mHeight:I

    const/4 v2, 0x7

    return v0
.end method

.method getMaxZoomRatio()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/zego/ve/VCam$CameraDev;->getMaxZoomRatio()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/16 v0, 0x64

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method getOrientation()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/zego/ve/VCam$CameraDev;->getOrientation()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method getWidth()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/zego/ve/VCam;->mWidth:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public handleMessage(Landroid/os/Message;)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    check-cast p1, Ljava/lang/Integer;

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v0, p0, Lcom/zego/ve/VCam;->mExposureGeneration:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne p1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1, v1}, Lcom/zego/ve/VCam$CameraDev;->handleExposureMode(I)I

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    return v1
.end method

.method init()V
    .locals 4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam;->mHandler:Landroid/os/Handler;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0, v1, p0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/zego/ve/VCam;->mHandler:Landroid/os/Handler;

    :cond_0
    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method

.method isFocusSupported()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/zego/ve/VCam$CameraDev;->isFocusSupported()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x0

    move v2, v1

    return v0
.end method

.method isSamsung()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string/jumbo v1, "msammus"

    const-string/jumbo v1, "msamsgu"

    const/4 v3, 0x0

    const-string v1, "asugons"

    const-string/jumbo v1, "samsung"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    return v0
.end method

.method openTorch()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/zego/ve/VCam$CameraDev;->openTorch()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method releaseCam()I
    .locals 3

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/zego/ve/VCam;->isSupportCamera2()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/zego/ve/VCam;->unregisterCameraAvailabilityCallback()V

    :cond_0
    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-virtual {v0}, Lcom/zego/ve/VCam$CameraDev;->releaseCam()I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput v0, p0, Lcom/zego/ve/VCam;->mUseCameraId:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public setContext(JLandroid/content/Context;Z)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    iput-wide p1, p0, Lcom/zego/ve/VCam;->mThis:J

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/zego/ve/VCam;->mContext:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-boolean p4, p0, Lcom/zego/ve/VCam;->mTryDefault:Z

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p1
.end method

.method setExposureCompensation(F)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput p1, p0, Lcom/zego/ve/VCam;->mExposureCompensation:F

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/zego/ve/VCam$CameraDev;->setExposureCompensation(F)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return p1
.end method

.method setExposureMode(I)I
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-ne p1, v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    move v0, v1

    move v0, v1

    move v0, v1

    move v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    move v0, p1

    move v0, p1

    move v0, p1

    move v0, p1

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput v0, p0, Lcom/zego/ve/VCam;->mExposureMode:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lcom/zego/ve/VCam$CameraDev;->setExposureMode(I)I

    move-result v1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v1
.end method

.method setExposurePoint(FF)I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput p1, p0, Lcom/zego/ve/VCam;->mExposurePointX:F

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput p2, p0, Lcom/zego/ve/VCam;->mExposurePointY:F

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2}, Lcom/zego/ve/VCam$CameraDev;->setExposurePoint(FF)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return p1
.end method

.method setFPSRange(II)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    mul-int/lit16 p1, p1, 0x3e8

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lcom/zego/ve/VCam;->mFpsMin:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    mul-int/lit16 p2, p2, 0x3e8

    const/4 v1, 0x2

    const/4 v0, 0x7

    iput p2, p0, Lcom/zego/ve/VCam;->mFpsMax:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    return p1
.end method

.method setFocusMode(I)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput p1, p0, Lcom/zego/ve/VCam;->mFocusMode:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/zego/ve/VCam$CameraDev;->setFocusMode(I)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p1
.end method

.method setFocusPoint(FF)I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput p1, p0, Lcom/zego/ve/VCam;->mFocusPointX:F

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput p2, p0, Lcom/zego/ve/VCam;->mFocusPointY:F

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1, p2}, Lcom/zego/ve/VCam$CameraDev;->setFocusPoint(FF)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    return p1
.end method

.method setImageReader(Landroid/media/ImageReader;)I
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Lcom/zego/ve/VCam$CameraDev;->setImageReader(Landroid/media/ImageReader;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p1
.end method

.method setRate(II)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput p2, p0, Lcom/zego/ve/VCam;->mFPSMode:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez p2, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-ne p2, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/16 p1, 0x1e

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput p1, p0, Lcom/zego/ve/VCam;->mFrameRate:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz p2, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p2, p1}, Lcom/zego/ve/VCam$CameraDev;->setRate(I)I

    move-result v0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return v0
.end method

.method setSize(II)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    if-ge p1, p2, :cond_0

    const/4 v1, 0x4

    iput p2, p0, Lcom/zego/ve/VCam;->mWidth:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p1, p0, Lcom/zego/ve/VCam;->mHeight:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/zego/ve/VCam;->mWidth:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p2, p0, Lcom/zego/ve/VCam;->mHeight:I

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/zego/ve/VCam;->mNeedHack:Z

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p1
.end method

.method setSurfaceTexture(Landroid/graphics/SurfaceTexture;)I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/zego/ve/VCam$CameraDev;->setSurfaceTexture(Landroid/graphics/SurfaceTexture;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return p1
.end method

.method setZoomFactor(F)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/zego/ve/VCam$CameraDev;->setZoomFactor(F)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method startCam(Z)I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/zego/ve/VCam$CameraDev;->startCam(Z)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return p1
.end method

.method stopCam()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam;->mCamDevice:Lcom/zego/ve/VCam$CameraDev;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/zego/ve/VCam$CameraDev;->stopCam()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method uninit()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam;->mHandler:Landroid/os/Handler;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-virtual {v0, p0}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/zego/ve/VCam;->mHandler:Landroid/os/Handler;

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method
