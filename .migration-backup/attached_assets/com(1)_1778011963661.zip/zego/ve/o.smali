.class public final synthetic Lcom/zego/ve/o;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/media/AudioRouting;)Landroid/media/AudioDeviceInfo;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b sM@o@@~@~asc@d bfot ~mo4~/ ~o@  b~ ~  vy@ @ ~@ o~.i~1~~@~l@@S @@ Kilf~~~o~ri~n~  ~u~@-@/ @@@@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-interface {p0}, Landroid/media/AudioRouting;->getRoutedDevice()Landroid/media/AudioDeviceInfo;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method
