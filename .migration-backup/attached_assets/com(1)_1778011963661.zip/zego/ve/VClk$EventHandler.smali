.class Lcom/zego/ve/VClk$EventHandler;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Handler$Callback;
.implements Landroid/view/Choreographer$FrameCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/VClk;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "EventHandler"
.end annotation


# instance fields
.field private mAtomicThis:Ljava/util/concurrent/atomic/AtomicLong;

.field private mRunning:Z


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/zego/ve/VClk$EventHandler;->mAtomicThis:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/zego/ve/VClk$EventHandler;->mRunning:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/zego/ve/VClk$1;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/zego/ve/VClk$EventHandler;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public doFrame(J)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    iget-boolean v0, p0, Lcom/zego/ve/VClk$EventHandler;->mRunning:Z

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/ve/VClk$EventHandler;->mAtomicThis:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    cmp-long v2, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-nez v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-void

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v0, v1, p1, p2}, Lcom/zego/ve/VClk;->access$200(JJ)I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1, p0}, Landroid/view/Choreographer;->postFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-void
.end method

.method public handleMessage(Landroid/os/Message;)Z
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget p1, p1, Landroid/os/Message;->what:I

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v0, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-nez p1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-boolean p1, p0, Lcom/zego/ve/VClk$EventHandler;->mRunning:Z

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-nez p1, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput-boolean v0, p0, Lcom/zego/ve/VClk$EventHandler;->mRunning:Z

    :try_start_0
    const/4 v7, 0x0

    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p1, p0}, Landroid/view/Choreographer;->postFrameCallback(Landroid/view/Choreographer$FrameCallback;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto/16 :goto_0

    :catch_0
    move-exception p1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object p1, p0, Lcom/zego/ve/VClk$EventHandler;->mAtomicThis:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    cmp-long p1, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eqz p1, :cond_3

    const/4 v7, 0x6

    invoke-static {v2, v3}, Lcom/zego/ve/VClk;->access$100(J)I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    goto/16 :goto_0

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    if-ne p1, v0, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-boolean p1, p0, Lcom/zego/ve/VClk$EventHandler;->mRunning:Z

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eqz p1, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    iput-boolean v1, p0, Lcom/zego/ve/VClk$EventHandler;->mRunning:Z

    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object p1

    const/4 v7, 0x6

    invoke-virtual {p1, p0}, Landroid/view/Choreographer;->removeFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/16 v0, 0x1c

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-lt p1, v0, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/16 v0, 0x18

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-lt p1, v0, :cond_3

    :try_start_2
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-class p1, Landroid/view/Choreographer;

    const-class p1, Landroid/view/Choreographer;

    const/4 v7, 0x4

    const-class p1, Landroid/view/Choreographer;

    const-class p1, Landroid/view/Choreographer;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string/jumbo v0, "etsancsesanerse"

    const-string v0, "aesnsrneectaesI"

    const/4 v7, 0x7

    const-string v0, "eIrmeasclsetann"

    const-string/jumbo v0, "releaseInstance"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    new-array v2, v1, [Ljava/lang/Class;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p1, v0, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-array v0, v1, [Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p1, v2, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_2 .. :try_end_2} :catch_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    goto :goto_0

    :catch_1
    move-exception p1

    :try_start_3
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto :goto_0

    :catch_2
    move-exception p1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v7, 0x6

    goto :goto_0

    :catch_3
    move-exception p1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    goto :goto_0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/4 v0, 0x2

    const/4 v6, 0x0

    const/4 v6, 0x5

    if-ne p1, v0, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p1, p0}, Landroid/view/Choreographer;->removeFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {}, Landroid/view/Choreographer;->getInstance()Landroid/view/Choreographer;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p1, p0}, Landroid/view/Choreographer;->postFrameCallback(Landroid/view/Choreographer$FrameCallback;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_4

    :catch_4
    :cond_3
    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    return v1
.end method

.method public init(J)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/ve/VClk$EventHandler;->mAtomicThis:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public uninit()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/zego/ve/VClk$EventHandler;->mAtomicThis:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicLong;->set(J)V

    const/4 v4, 0x3

    return-void
.end method
