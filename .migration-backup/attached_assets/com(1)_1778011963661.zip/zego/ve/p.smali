.class public final synthetic Lcom/zego/ve/p;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a(Ljava/io/InputStream;)Landroid/media/ExifInterface;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  suo@~M~~ o@@@n~b~  l   ~  @@@d lcb@@S~b@aom@~of~~/ o@1~v fi @@y~~~s@~@~~~r-~ .@@4t @it~@ iK~o~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    new-instance v0, Landroid/media/ExifInterface;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Landroid/media/ExifInterface;-><init>(Ljava/io/InputStream;)V

    const/4 v2, 0x3

    return-object v0
.end method
