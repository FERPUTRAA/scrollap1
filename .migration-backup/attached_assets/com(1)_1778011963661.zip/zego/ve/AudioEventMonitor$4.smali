.class Lcom/zego/ve/AudioEventMonitor$4;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/AudioEventMonitor;->InitPhoneStateListener()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/AudioEventMonitor;


# direct methods
.method constructor <init>(Lcom/zego/ve/AudioEventMonitor;)V
    .locals 2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor$4;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "M s f ~@~@@~@~c-@lb~o ui ~@ i o~@~@s i@t.@~ d @ ~@ ~S@~@/~ b bl~@~@~@aK~@~~@yf~too1 ~ vo/4nom@ ~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    const-string/jumbo v0, "ieemdv"

    const-string/jumbo v0, "vesied"

    const/4 v6, 0x0

    const-string v0, "devioe"

    const-string v0, "device"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor$4;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput-boolean v2, v1, Lcom/zego/ve/AudioEventMonitor;->_isCalling:Z

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance v2, Lcom/zego/ve/AudioEventMonitor$4$1;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v2, p0}, Lcom/zego/ve/AudioEventMonitor$4$1;-><init>(Lcom/zego/ve/AudioEventMonitor$4;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    iput-object v2, v1, Lcom/zego/ve/AudioEventMonitor;->_phoneStateListener:Landroid/telephony/PhoneStateListener;

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor$4;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, v1, Lcom/zego/ve/AudioEventMonitor;->_context:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string/jumbo v2, "ohpmn"

    const/4 v6, 0x4

    const-string v2, "bnhep"

    const-string/jumbo v2, "phone"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    check-cast v1, Landroid/telephony/TelephonyManager;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/telephony/TelephonyManager;->getCallState()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v3, p0, Lcom/zego/ve/AudioEventMonitor$4;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v3, v3, Lcom/zego/ve/AudioEventMonitor;->_phoneStateListener:Landroid/telephony/PhoneStateListener;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/16 v4, 0x20

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1, v3, v4}, Landroid/telephony/TelephonyManager;->listen(Landroid/telephony/PhoneStateListener;I)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v3, " a srnu t icetitelalt:c"

    const-string/jumbo v3, "trace init call state: "

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string v3, "InitPhoneStateListener failed, "

    const-string v3, "InitPhoneStateListener failed, "

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v0, v1}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor$4;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    iput-object v1, v0, Lcom/zego/ve/AudioEventMonitor;->_phoneStateListener:Landroid/telephony/PhoneStateListener;

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-void
.end method
