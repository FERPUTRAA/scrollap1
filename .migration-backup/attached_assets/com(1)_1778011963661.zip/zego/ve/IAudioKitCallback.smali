.class interface abstract Lcom/zego/ve/IAudioKitCallback;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onResult(I)V
.end method
