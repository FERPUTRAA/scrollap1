.class Lcom/zego/ve/MediaCodecVideoDecoder$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/MediaCodecVideoDecoder;->release()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/MediaCodecVideoDecoder;

.field final synthetic val$releaseDone:Ljava/util/concurrent/CountDownLatch;


# direct methods
.method constructor <init>(Lcom/zego/ve/MediaCodecVideoDecoder;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->val$releaseDone:Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~~svo@if b@@f ~oi~~1nl@~~u@ r~yS~t/ a@@b@b~@i~4@~ t@   @~@/~ @ .~m c~ od~M~o~~@-so ~@@ K @~ o l@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    const-string/jumbo v0, "o rmJehrales  etsdc eonnedd aearaeoeDlsree"

    const-string/jumbo v0, "sssJnaorndrtce he eeoreaeela edlDaeardo  e"

    const/4 v6, 0x4

    const-string v0, "a rroacaorveeJet elandenhss  eododeeae Dlr"

    const-string v0, "Java releaseDecoder on release thread done"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v1, "dVroebcMemaoedeDediidC"

    const-string v1, "MaimdedeeoercdVoceCidD"

    const/4 v6, 0x2

    const-string v1, "DdciMduCeoVoeeadcdeoie"

    const-string v1, "MediaCodecVideoDecoder"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v2, 0x0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v3, "oanraehp Daerelvtraceea re ed ssdJelo"

    const-string v3, "Java releaseDecoder on release thread"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v1, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x4

    move v6, v5

    iget-object v3, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v3}, Lcom/zego/ve/MediaCodecVideoDecoder;->access$000(Lcom/zego/ve/MediaCodecVideoDecoder;)Landroid/media/MediaCodec;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v3}, Landroid/media/MediaCodec;->stop()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_0

    :catchall_0
    move-exception v3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto/16 :goto_1

    :catch_0
    move-exception v3

    :try_start_1
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v4, "spoodod qecitl defaMe ier"

    const-string v4, "ao lodefdespi reodaicM et"

    const/4 v6, 0x5

    const-string v4, " tsdipoa  Mefcerdlsaeiodd"

    const-string v4, "Media decoder stop failed"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v1, v4, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v3}, Lcom/zego/ve/MediaCodecVideoDecoder;->access$000(Lcom/zego/ve/MediaCodecVideoDecoder;)Landroid/media/MediaCodec;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v3}, Landroid/media/MediaCodec;->release()V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v3, v2}, Lcom/zego/ve/MediaCodecVideoDecoder;->access$002(Lcom/zego/ve/MediaCodecVideoDecoder;Landroid/media/MediaCodec;)Landroid/media/MediaCodec;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/zego/ve/MediaCodecVideoDecoder;->access$100(Lcom/zego/ve/MediaCodecVideoDecoder;)Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez v0, :cond_0

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/zego/ve/MediaCodecVideoDecoder;->access$200(Lcom/zego/ve/MediaCodecVideoDecoder;)Landroid/view/Surface;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    move v6, v5

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v5, 0x1

    move v6, v5

    invoke-static {v0}, Lcom/zego/ve/MediaCodecVideoDecoder;->access$200(Lcom/zego/ve/MediaCodecVideoDecoder;)Landroid/view/Surface;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroid/view/Surface;->release()V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v0, v2}, Lcom/zego/ve/MediaCodecVideoDecoder;->access$202(Lcom/zego/ve/MediaCodecVideoDecoder;Landroid/view/Surface;)Landroid/view/Surface;

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->val$releaseDone:Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-void

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v4, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v4}, Lcom/zego/ve/MediaCodecVideoDecoder;->access$000(Lcom/zego/ve/MediaCodecVideoDecoder;)Landroid/media/MediaCodec;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v4}, Landroid/media/MediaCodec;->release()V

    const/4 v6, 0x1

    iget-object v4, p0, Lcom/zego/ve/MediaCodecVideoDecoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v4, v2}, Lcom/zego/ve/MediaCodecVideoDecoder;->access$002(Lcom/zego/ve/MediaCodecVideoDecoder;Landroid/media/MediaCodec;)Landroid/media/MediaCodec;

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    throw v3
.end method
