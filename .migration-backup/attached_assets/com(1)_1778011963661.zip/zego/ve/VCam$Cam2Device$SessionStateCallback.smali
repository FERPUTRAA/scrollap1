.class Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;
.super Landroid/hardware/camera2/CameraCaptureSession$StateCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/VCam$Cam2Device;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "SessionStateCallback"
.end annotation


# instance fields
.field final synthetic this$1:Lcom/zego/ve/VCam$Cam2Device;


# direct methods
.method constructor <init>(Lcom/zego/ve/VCam$Cam2Device;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/hardware/camera2/CameraCaptureSession$StateCallback;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onConfigureFailed(Landroid/hardware/camera2/CameraCaptureSession;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b@soi ~S @  ~~~  n~ r@@m~Kd@b@@u@ ~t @i@@@/~o~~@ 4@~~l~@@sv@f~~oMli@1-bf~o.t~ ~~c~~@  o  a /y@o "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object p1, p1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v2, 0x0

    const/4 v0, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lcom/zego/ve/VCam;->access$1602(Lcom/zego/ve/VCam;Z)Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string/jumbo p1, "pcav"

    const-string/jumbo p1, "pvac"

    const/4 v2, 0x7

    const-string/jumbo p1, "pvac"

    const-string/jumbo p1, "vcap"

    const/4 v2, 0x1

    const-string/jumbo v0, "pnvmaidlgcfda u orosCieen"

    const-string/jumbo v0, "lgsrdv nfaioaincef dpCuoe"

    const/4 v2, 0x2

    const-string v0, "alnioeoodgpfr  diecnC:afv"

    const-string/jumbo v0, "vcap: onConfigured failed"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public onConfigured(Landroid/hardware/camera2/CameraCaptureSession;)V
    .locals 5

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/zego/ve/VCam$Cam2Device;->access$1700(Lcom/zego/ve/VCam$Cam2Device;)Landroid/hardware/camera2/CaptureRequest$Builder;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object v1, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AF_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v2, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, p1}, Lcom/zego/ve/VCam$Cam2Device;->access$1802(Lcom/zego/ve/VCam$Cam2Device;Landroid/hardware/camera2/CameraCaptureSession;)Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/zego/ve/VCam$Cam2Device;->access$1800(Lcom/zego/ve/VCam$Cam2Device;)Landroid/hardware/camera2/CameraCaptureSession;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/zego/ve/VCam$Cam2Device;->access$1700(Lcom/zego/ve/VCam$Cam2Device;)Landroid/hardware/camera2/CaptureRequest$Builder;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/hardware/camera2/CaptureRequest$Builder;->build()Landroid/hardware/camera2/CaptureRequest;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1, v1}, Landroid/hardware/camera2/CameraCaptureSession;->setRepeatingRequest(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroid/os/Handler;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v4, 0x0

    iget-object v0, v0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lcom/zego/ve/VCam;->access$1602(Lcom/zego/ve/VCam;Z)Z

    const/4 v3, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v0, "pavc"

    const-string/jumbo v0, "vapc"

    const/4 v4, 0x1

    const-string/jumbo v0, "vcap"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v1, " fasabsedm c:ipvielsa co"

    const-string v1, "dipmieoaplccvsas  e:a fs"

    const/4 v4, 0x6

    const-string/jumbo v1, "vcap: cap session failed"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void
.end method
