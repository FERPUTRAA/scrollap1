.class Lcom/zego/ve/ThreadUtils$4;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/ThreadUtils;->invokeUninterruptibly(Landroid/os/Handler;Ljava/lang/Runnable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$barrier:Ljava/util/concurrent/CountDownLatch;

.field final synthetic val$runner:Ljava/lang/Runnable;


# direct methods
.method constructor <init>(Ljava/lang/Runnable;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/zego/ve/ThreadUtils$4;->val$runner:Ljava/lang/Runnable;

    const/4 v1, 0x2

    const/4 v0, 0x1

    iput-object p2, p0, Lcom/zego/ve/ThreadUtils$4;->val$barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bMs @f @~s@b@1i@~Sr~~@v  ~~ ~~ai@ @@ ~ c.~nio@~@ ~~~   f /@to~Ku@-lb ~@~@~ modt@4 ~l@/oo@~ @y~@o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/ve/ThreadUtils$4;->val$runner:Ljava/lang/Runnable;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/zego/ve/ThreadUtils$4;->val$barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method
