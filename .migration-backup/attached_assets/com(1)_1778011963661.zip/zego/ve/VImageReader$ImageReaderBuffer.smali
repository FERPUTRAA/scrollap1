.class Lcom/zego/ve/VImageReader$ImageReaderBuffer;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/VImageReader;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ImageReaderBuffer"
.end annotation


# instance fields
.field private nTimeStamp:J

.field private uBuffer:Ljava/nio/ByteBuffer;

.field private vBuffer:Ljava/nio/ByteBuffer;

.field private yBuffer:Ljava/nio/ByteBuffer;


# direct methods
.method public constructor <init>([Landroid/media/Image$Plane;J)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    aget-object v0, p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/zego/ve/VImageReader$ImageReaderBuffer;->yBuffer:Ljava/nio/ByteBuffer;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    aget-object v0, p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/zego/ve/VImageReader$ImageReaderBuffer;->uBuffer:Ljava/nio/ByteBuffer;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x0

    aget-object p1, p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/zego/ve/VImageReader$ImageReaderBuffer;->vBuffer:Ljava/nio/ByteBuffer;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-wide p2, p0, Lcom/zego/ve/VImageReader$ImageReaderBuffer;->nTimeStamp:J

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method
