.class public Lcom/zego/ve/AudioEventMonitor;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x18
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;,
        Lcom/zego/ve/AudioEventMonitor$IEventNotify;
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String; = "device"


# instance fields
.field protected _audioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

.field protected _audioManager:Landroid/media/AudioManager;

.field protected _audioPlayListener:Landroid/media/AudioManager$AudioPlaybackCallback;

.field protected _audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

.field private _bluetoothOpSeq:I

.field protected _context:Landroid/content/Context;

.field protected _handler:Landroid/os/Handler;

.field protected _isCalling:Z

.field protected _mode:I

.field protected _once_call_come_in:Z

.field protected _phoneStateListener:Landroid/telephony/PhoneStateListener;

.field protected audio_route_:I

.field protected audio_route_change_valid_:Z

.field protected cap_original_route_:I

.field private duck_lock_:Ljava/lang/Object;

.field public duck_other_when_voip_:Z

.field public duck_value_in_percent_:I

.field private event_lock_:Ljava/lang/Object;

.field protected event_notify_:Lcom/zego/ve/AudioEventMonitor$IEventNotify;

.field protected has_inited_:Z

.field protected on_receiver_first_arrive_:Z

.field protected play_active_in_voip_:Z

.field protected volume_before_duck_:I

.field protected wait_check_sco_:Z


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_context:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v1, 0x0

    move v5, v1

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput v1, p0, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-boolean v1, p0, Lcom/zego/ve/AudioEventMonitor;->duck_other_when_voip_:Z

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/16 v2, 0x14

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput v2, p0, Lcom/zego/ve/AudioEventMonitor;->duck_value_in_percent_:I

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v2, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    iput v2, p0, Lcom/zego/ve/AudioEventMonitor;->volume_before_duck_:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput-boolean v1, p0, Lcom/zego/ve/AudioEventMonitor;->audio_route_change_valid_:Z

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x0

    move v4, v2

    const/4 v5, 0x1

    iput-boolean v2, p0, Lcom/zego/ve/AudioEventMonitor;->on_receiver_first_arrive_:Z

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-boolean v1, p0, Lcom/zego/ve/AudioEventMonitor;->wait_check_sco_:Z

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    iput v1, p0, Lcom/zego/ve/AudioEventMonitor;->audio_route_:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/16 v2, 0xf

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput v2, p0, Lcom/zego/ve/AudioEventMonitor;->cap_original_route_:I

    const/4 v5, 0x3

    iput v1, p0, Lcom/zego/ve/AudioEventMonitor;->_bluetoothOpSeq:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    new-instance v2, Landroid/os/Handler;

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-object v2, p0, Lcom/zego/ve/AudioEventMonitor;->_handler:Landroid/os/Handler;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_phoneStateListener:Landroid/telephony/PhoneStateListener;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioPlayListener:Landroid/media/AudioManager$AudioPlaybackCallback;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-boolean v1, p0, Lcom/zego/ve/AudioEventMonitor;->play_active_in_voip_:Z

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-boolean v1, p0, Lcom/zego/ve/AudioEventMonitor;->_isCalling:Z

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput-boolean v1, p0, Lcom/zego/ve/AudioEventMonitor;->_once_call_come_in:Z

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    iput-boolean v1, p0, Lcom/zego/ve/AudioEventMonitor;->has_inited_:Z

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->event_notify_:Lcom/zego/ve/AudioEventMonitor$IEventNotify;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->event_lock_:Ljava/lang/Object;

    const/4 v5, 0x1

    new-instance v0, Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->duck_lock_:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void
.end method

.method private DuckActivePlayWhenVoip()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/4 v1, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget-object v2, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    const/4 v3, 0x3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v2, v3}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v2

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-object v4, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v4, v1}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v4

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    int-to-float v4, v4

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget v5, p0, Lcom/zego/ve/AudioEventMonitor;->duck_value_in_percent_:I

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    int-to-float v5, v5

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    mul-float/2addr v5, v4

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    float-to-double v5, v5

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    const-wide/high16 v7, 0x4059000000000000L    # 100.0

    const-wide/high16 v7, 0x4059000000000000L    # 100.0

    const/4 v10, 0x0

    const-wide/high16 v7, 0x4059000000000000L    # 100.0

    const-wide/high16 v7, 0x4059000000000000L    # 100.0

    const/4 v10, 0x6

    const/4 v9, 0x3

    div-double/2addr v5, v7

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x5

    double-to-int v5, v5

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-nez v5, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/4 v5, 0x1

    :cond_0
    const/4 v10, 0x0

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    const-string v7, "Duck other app play starting(api>=29), voip curr:"

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const-string v7, "e:sst"

    const-string v7, "e:st "

    const/4 v10, 0x0

    const-string/jumbo v7, "etsm:"

    const-string v7, " set:"

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string v7, " xamo"

    const-string v7, " :xma"

    const/4 v10, 0x7

    const-string v7, "b xm:"

    const-string v7, " max:"

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x5

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string/jumbo v6, "uoicev"

    const-string/jumbo v6, "vceioe"

    const/4 v10, 0x6

    const-string v6, "dpivec"

    const-string v6, "device"

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {v6, v4}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    iget-object v4, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {v4, v1, v5, v1}, Landroid/media/AudioManager;->setStreamVolume(III)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    iget-object v4, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v4, v3, v1, v1}, Landroid/media/AudioManager;->setStreamVolume(III)V

    const/4 v10, 0x0

    iget-object v4, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x3

    invoke-virtual {v4, v3, v2, v1}, Landroid/media/AudioManager;->setStreamVolume(III)V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object v2, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v2, v1, v0, v1}, Landroid/media/AudioManager;->setStreamVolume(III)V

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    return-void
.end method

.method private InitAudioFocusChangeListener()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string v0, "eeqbic"

    const-string v0, "decieb"

    const/4 v6, 0x2

    const-string v0, "cvsedi"

    const-string v0, "device"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v1, Lcom/zego/ve/AudioEventMonitor$7;

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-direct {v1, p0}, Lcom/zego/ve/AudioEventMonitor$7;-><init>(Lcom/zego/ve/AudioEventMonitor;)V

    iput-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v3, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v4, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v2, v1, v3, v4}, Landroid/media/AudioManager;->requestAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;II)I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eq v1, v4, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v2, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eq v1, v2, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string v2, "WNOmuNN"

    const-string v2, "ONWNNUu"

    const/4 v6, 0x7

    const-string v2, "ONWNoKN"

    const-string v2, "UNKNOWN"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const-string v2, "EYADEbL"

    const-string v2, "DELAYED"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string v2, "NGRDATu"

    const-string/jumbo v2, "pRAGNTD"

    const/4 v6, 0x6

    const-string/jumbo v2, "pGEDRTN"

    const-string v2, "GRANTED"

    const/4 v6, 0x1

    const/4 v5, 0x5

    goto :goto_0

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v2, "FAqLqE"

    const-string v2, "IAqLEF"

    const/4 v6, 0x0

    const-string v2, "ILsAFE"

    const-string v2, "FAILED"

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo v4, "uscmqdtae rauesucstto ift:ro saseu"

    const-string v4, ":tssoiu useorautcsatartfscd  eeuq "

    const-string v4, "c aeosu usrose uerqutoaaftc : ttsd"

    const-string/jumbo v4, "trace request audio focus status: "

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string v1, "("

    const-string v1, "("

    const/4 v6, 0x4

    const-string v1, "("

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v1, ")"

    const-string v1, ")"

    const/4 v6, 0x5

    const-string v1, ")"

    const-string v1, ")"

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v0, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_1

    :catchall_0
    move-exception v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string/jumbo v3, "trace request audio focus failed, "

    const-string/jumbo v3, "trace request audio focus failed, "

    const/4 v6, 0x0

    const-string/jumbo v3, "trace request audio focus failed, "

    const-string/jumbo v3, "trace request audio focus failed, "

    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v0, v1}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->abandonAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;)I

    const/4 v5, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v0, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-void
.end method

.method private InitAudioPlaybackListener()V
    .locals 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1a
    .end annotation

    const/4 v3, 0x1

    move v4, v3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/16 v1, 0x1d

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-ge v0, v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    new-instance v0, Lcom/zego/ve/AudioEventMonitor$6;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v0, p0}, Lcom/zego/ve/AudioEventMonitor$6;-><init>(Lcom/zego/ve/AudioEventMonitor;)V

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioPlayListener:Landroid/media/AudioManager$AudioPlaybackCallback;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v1, v0, v2}, Lcom/zego/ve/k;->a(Landroid/media/AudioManager;Landroid/media/AudioManager$AudioPlaybackCallback;Landroid/os/Handler;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void
.end method

.method private InitPhoneStateListener()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_handler:Landroid/os/Handler;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v1, Lcom/zego/ve/AudioEventMonitor$4;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/zego/ve/AudioEventMonitor$4;-><init>(Lcom/zego/ve/AudioEventMonitor;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x1

    return-void
.end method

.method private RegisterAudioRouteListen()I
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iput-boolean v0, p0, Lcom/zego/ve/AudioEventMonitor;->on_receiver_first_arrive_:Z

    const/4 v5, 0x3

    const/4 v0, 0x5

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x2

    iput-boolean v0, p0, Lcom/zego/ve/AudioEventMonitor;->audio_route_change_valid_:Z

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/16 v2, 0x18

    const/4 v4, 0x6

    or-int/2addr v5, v4

    if-lt v1, v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance v1, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    const/4 v5, 0x0

    const/4 v4, 0x6

    invoke-direct {v1, p0}, Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;-><init>(Lcom/zego/ve/AudioEventMonitor;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v2, v1, v3}, Landroid/media/AudioManager;->registerAudioDeviceCallback(Landroid/media/AudioDeviceCallback;Landroid/os/Handler;)V

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v1, Landroid/content/IntentFilter;

    const/4 v4, 0x3

    xor-int/2addr v5, v4

    invoke-direct {v1}, Landroid/content/IntentFilter;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const-string v2, "adtcnbiGLn.aeEoH_toPA.SdDEUrinnTi."

    const-string v2, "ELtmn_.DdSoAintr.decHo.GaTniaiUnEP"

    const/4 v5, 0x4

    const-string v2, "PoinESua_DteTEndUnrAHitt.doLia..Gc"

    const-string v2, "android.intent.action.HEADSET_PLUG"

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string v2, "._NrHtapelt.TontocEi.iooAhodaaGCr.TtuSpeAEDnad"

    const-string/jumbo v2, "trCpoitdtThu..ooDbo.rloHnad.cntNaAEi_TeAEeGSaa"

    const/4 v5, 0x3

    const-string/jumbo v2, "i_pDaa.tqGrTEC.d.HtbAatcudThonriAoteo.NodelanS"

    const-string v2, "android.bluetooth.adapter.action.STATE_CHANGED"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string v2, "eNsaO.siI_rTtEaltNNulTnCoepDooh.o.rCbdbSi.c.tdAeiGHTtndC_AafhEoeO"

    const-string v2, "e_lOobocnEdtNENHbTrTO.daoofCrEaC._.hDGinNeStitAeI.u.ohtidATaspelC"

    const/4 v5, 0x6

    const-string v2, "TremnEnlOtS.irNsdo.iThdNAha.CoOfoedHIteu.eNcNtaiG_CC.pbooAt_DETaE"

    const-string v2, "android.bluetooth.headset.profile.action.CONNECTION_STATE_CHANGED"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string v2, "EDado.VDdarair.S.wun.nACTA_uUCTocrtEaihsoebBd_H"

    const-string v2, "DC.abCuiATHtrDTodBadS.o_aAhUEEa_Erdsu.nc.nwerVi"

    const/4 v5, 0x6

    const-string v2, "android.hardware.usb.action.USB_DEVICE_ATTACHED"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v4, 0x2

    const-string v2, "cuUi.bDEoaH_dih_rIn.EBAa.EowVsr.pnDDtbTdCeEardS"

    const-string v2, "dEuIbaDpUirroscwESddaTVCDr..Danh_Hn.eiAEB_Ct.Eo"

    const/4 v5, 0x2

    const-string v2, "BaDaECuVocDHEr._inbrsaSAD.at.d.idhTUdoeI_EwnEuC"

    const-string v2, "android.hardware.usb.action.USB_DEVICE_DETACHED"

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/zego/ve/AudioEventMonitor;->_context:Landroid/content/Context;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v2, p0, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    return v0
.end method

.method private RemoveAudioRoute()V
    .locals 4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_context:Landroid/content/Context;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget v1, p0, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/zego/ve/AudioDeviceHelper;->getCurrentRoute(Landroid/content/Context;I)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lcom/zego/ve/AudioEventMonitor;->ChangeAudioRoute(I)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method private SetModeWithDucking()V
    .locals 11

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget v0, p0, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    const/16 v1, 0x1d

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/4 v2, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/4 v3, 0x3

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-ne v3, v0, :cond_6

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v0, v3}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget v4, p0, Lcom/zego/ve/AudioEventMonitor;->volume_before_duck_:I

    const/4 v9, 0x4

    move v10, v9

    if-gez v4, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    iput v0, p0, Lcom/zego/ve/AudioEventMonitor;->volume_before_duck_:I

    :cond_0
    const/4 v9, 0x3

    const/4 v10, 0x7

    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v9, 0x3

    and-int/2addr v10, v9

    const-wide/high16 v5, 0x4059000000000000L    # 100.0

    const-wide/high16 v5, 0x4059000000000000L    # 100.0

    const/4 v10, 0x6

    const-wide/high16 v5, 0x4059000000000000L    # 100.0

    const-wide/high16 v5, 0x4059000000000000L    # 100.0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-ge v4, v1, :cond_2

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v1, v3}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    int-to-float v1, v1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget v4, p0, Lcom/zego/ve/AudioEventMonitor;->duck_value_in_percent_:I

    const/4 v10, 0x3

    int-to-float v4, v4

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    mul-float/2addr v4, v1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    float-to-double v7, v4

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    div-double/2addr v7, v5

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    double-to-int v4, v7

    const/4 v10, 0x0

    const-string v5, "ceqevi"

    const/4 v10, 0x2

    const-string/jumbo v5, "vpeedi"

    const-string v5, "device"

    const/4 v10, 0x7

    const/4 v9, 0x3

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    const-string v7, "2thokr eqar paup9<(p cdaDrs um) c, ei"

    const-string v7, "cas)u,up(r9  r eci pm t<pakrdh:oD ea2"

    const/4 v10, 0x4

    const-string v7, "Duck other app(api < 29), media curr:"

    const/4 v10, 0x7

    const/4 v9, 0x2

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const-string/jumbo v7, "m ss:"

    const-string/jumbo v7, "s: me"

    const/4 v10, 0x1

    const-string/jumbo v7, "ts:me"

    const-string v7, " set:"

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    const-string v7, ":maoo"

    const-string v7, ":amxo"

    const/4 v10, 0x7

    const-string v7, " max:"

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {v5, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-ge v4, v0, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {v0, v3, v4, v2}, Landroid/media/AudioManager;->setStreamVolume(III)V

    :cond_1
    const/4 v10, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    iget v1, p0, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setMode(I)V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    goto/16 :goto_1

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {v0, v2}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v1, v2}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v1

    const/4 v10, 0x2

    int-to-float v1, v1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget v3, p0, Lcom/zego/ve/AudioEventMonitor;->duck_value_in_percent_:I

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    int-to-float v3, v3

    const/4 v9, 0x0

    move v10, v9

    mul-float/2addr v3, v1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    float-to-double v3, v3

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    div-double/2addr v3, v5

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    double-to-int v3, v3

    const/4 v9, 0x7

    move v10, v9

    if-nez v3, :cond_3

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/4 v3, 0x1

    :cond_3
    const/4 v9, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string v4, "cevdib"

    const/4 v10, 0x5

    const-string/jumbo v4, "ievdcb"

    const-string v4, "device"

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string/jumbo v6, "ivoau up rua) >(cphe2cip p=Dk:orut r"

    const-string v6, "9(a kruppchpr=euc tpo :r>oDv i2iua )"

    const/4 v10, 0x4

    const-string v6, " =uDp cpk pthaur> c9oap iv2,ip)eo(r:"

    const-string v6, "Duck other app(api>= 29), voip curr:"

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const-string v6, " :pqe"

    const-string v6, ":tp e"

    const/4 v10, 0x3

    const-string v6, " sste"

    const-string v6, " set:"

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-string v6, "aqxm "

    const-string v6, ":x qa"

    const/4 v10, 0x2

    const-string v6, "ax :o"

    const-string v6, " max:"

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x7

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {v4, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-ge v3, v0, :cond_4

    const/4 v9, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v1, v2, v3, v2}, Landroid/media/AudioManager;->setStreamVolume(III)V

    :cond_4
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget v4, p0, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v10, 0x6

    const/4 v9, 0x3

    invoke-virtual {v1, v4}, Landroid/media/AudioManager;->setMode(I)V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-ge v3, v0, :cond_5

    const/4 v10, 0x3

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v1, v2, v0, v2}, Landroid/media/AudioManager;->setStreamVolume(III)V

    :cond_5
    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->duck_lock_:Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->getMediaActiveStatusInVOIP()Z

    move-result v1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    iput-boolean v1, p0, Lcom/zego/ve/AudioEventMonitor;->play_active_in_voip_:Z

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    monitor-exit v0

    const/4 v10, 0x3

    goto :goto_1

    :catchall_0
    move-exception v1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    throw v1

    :cond_6
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget v0, p0, Lcom/zego/ve/AudioEventMonitor;->volume_before_duck_:I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-lez v0, :cond_8

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-ge v4, v1, :cond_7

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v1, v3, v0, v2}, Landroid/media/AudioManager;->setStreamVolume(III)V

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    goto :goto_0

    :cond_7
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v0, v3}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v1, v3, v0, v2}, Landroid/media/AudioManager;->setStreamVolume(III)V

    :cond_8
    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v0, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    iput v0, p0, Lcom/zego/ve/AudioEventMonitor;->volume_before_duck_:I

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget v1, p0, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setMode(I)V

    :goto_1
    const/4 v9, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    return-void
.end method

.method private UninitAudioFocusChangeListener()V
    .locals 4

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    invoke-virtual {v1, v0}, Landroid/media/AudioManager;->abandonAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;)I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method private UninitAudioPlaybackListener()V
    .locals 4
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1a
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    const/16 v1, 0x1d

    const/4 v3, 0x1

    if-ge v0, v1, :cond_0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioPlayListener:Landroid/media/AudioManager$AudioPlaybackCallback;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/zego/ve/j;->a(Landroid/media/AudioManager;Landroid/media/AudioManager$AudioPlaybackCallback;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioPlayListener:Landroid/media/AudioManager$AudioPlaybackCallback;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method private UninitPhoneStateListener()V
    .locals 4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_handler:Landroid/os/Handler;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v1, Lcom/zego/ve/AudioEventMonitor$5;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/zego/ve/AudioEventMonitor$5;-><init>(Lcom/zego/ve/AudioEventMonitor;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method static synthetic access$000(Lcom/zego/ve/AudioEventMonitor;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    iget p0, p0, Lcom/zego/ve/AudioEventMonitor;->_bluetoothOpSeq:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic access$100(Lcom/zego/ve/AudioEventMonitor;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/zego/ve/AudioEventMonitor;->event_lock_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$200(Lcom/zego/ve/AudioEventMonitor;)Z
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->getMediaActiveStatusInVOIP()Z

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic access$300(Lcom/zego/ve/AudioEventMonitor;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/zego/ve/AudioEventMonitor;->duck_lock_:Ljava/lang/Object;

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$400(Lcom/zego/ve/AudioEventMonitor;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->DuckActivePlayWhenVoip()V

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method

.method static synthetic access$500(Lcom/zego/ve/AudioEventMonitor;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->RemoveAudioRoute()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void
.end method

.method private getMediaActiveStatusInVOIP()Z
    .locals 7
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1a
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x2

    const/16 v1, 0x1a

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x7

    move v5, v2

    move v5, v2

    const/4 v6, 0x3

    if-ge v0, v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    return v2

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v0}, Lcom/zego/ve/l;->a(Landroid/media/AudioManager;)Ljava/util/List;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v1}, Lcom/zego/ve/m;->a(Ljava/lang/Object;)Landroid/media/AudioPlaybackConfiguration;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v1}, Lcom/zego/ve/n;->a(Landroid/media/AudioPlaybackConfiguration;)Landroid/media/AudioAttributes;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v1}, Landroid/media/AudioAttributes;->getUsage()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eq v1, v3, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/16 v4, 0xe

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-ne v1, v4, :cond_1

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    return v3

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    return v2
.end method


# virtual methods
.method public ChangeAudioRoute(I)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v0, p0, Lcom/zego/ve/AudioEventMonitor;->audio_route_:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eq p1, v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ne v0, p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/zego/ve/AudioEventMonitor;->wait_check_sco_:Z

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput p1, p0, Lcom/zego/ve/AudioEventMonitor;->audio_route_:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->event_lock_:Ljava/lang/Object;

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->event_notify_:Lcom/zego/ve/AudioEventMonitor$IEventNotify;

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    invoke-interface {v1, p1}, Lcom/zego/ve/AudioEventMonitor$IEventNotify;->OnAudioRouteChanged(I)V

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v2, 0x1

    or-int/2addr v3, v2

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    throw p1

    :cond_2
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method public CheckAudioRoute(IZ)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v0, 0x6

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v1, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eq v0, p1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-ne v1, p1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/media/AudioManager;->isBluetoothScoOn()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    and-int/2addr v5, v4

    invoke-virtual {p0, v3}, Lcom/zego/ve/AudioEventMonitor;->SetBluetoothScoOn(Z)I

    :cond_1
    const/4 v5, 0x4

    if-eqz p2, :cond_6

    const/4 v5, 0x3

    if-nez p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    move v2, v3

    move v2, v3

    const/4 v5, 0x7

    move v2, v3

    move v2, v3

    :goto_0
    const/4 v5, 0x0

    iget-object p1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p1, v2}, Landroid/media/AudioManager;->setSpeakerphoneOn(Z)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string/jumbo p2, "resohtOpekanne:sSe"

    const-string p2, "e:SeebhsrneapOtpok"

    const-string/jumbo p2, "setSpeakerphoneOn:"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string/jumbo p2, "uecmde"

    const-string p2, "ecemdi"

    const/4 v5, 0x0

    const-string p2, "epvied"

    const-string p2, "device"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p2, p1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x4

    const/4 v4, 0x3

    goto :goto_3

    :cond_3
    :goto_1
    const/4 v5, 0x2

    if-ne v1, p1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget p1, p0, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 p2, 0x5

    const/4 p2, 0x3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-ne p1, p2, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    move p1, v2

    move p1, v2

    move p1, v2

    move p1, v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_2

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    move p1, v3

    move p1, v3

    const/4 v5, 0x7

    move p1, v3

    move p1, v3

    :goto_2
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p2, v3}, Landroid/media/AudioManager;->setSpeakerphoneOn(Z)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-boolean p2, p0, Lcom/zego/ve/AudioEventMonitor;->_once_call_come_in:Z

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz p2, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput-boolean v3, p0, Lcom/zego/ve/AudioEventMonitor;->_once_call_come_in:Z

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0, v3}, Lcom/zego/ve/AudioEventMonitor;->SetBluetoothScoOn(Z)I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz p1, :cond_6

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0, v2}, Lcom/zego/ve/AudioEventMonitor;->SetBluetoothScoOn(Z)I

    const/4 v5, 0x1

    goto :goto_3

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0, p1}, Lcom/zego/ve/AudioEventMonitor;->SetBluetoothScoOn(Z)I

    :cond_6
    :goto_3
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void
.end method

.method public CheckBluetoothSCO()Z
    .locals 5

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x3

    move v3, v0

    move v3, v0

    const/4 v4, 0x4

    iput-boolean v0, p0, Lcom/zego/ve/AudioEventMonitor;->wait_check_sco_:Z

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v1, p0, Lcom/zego/ve/AudioEventMonitor;->audio_route_:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v2, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-ne v1, v2, :cond_0

    const/4 v4, 0x6

    iget v1, p0, Lcom/zego/ve/AudioEventMonitor;->cap_original_route_:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eq v1, v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    return v0
.end method

.method public CheckPhoneState()I
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_handler:Landroid/os/Handler;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance v1, Lcom/zego/ve/AudioEventMonitor$3;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v1, p0}, Lcom/zego/ve/AudioEventMonitor$3;-><init>(Lcom/zego/ve/AudioEventMonitor;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-wide/16 v2, 0x1f4

    const-wide/16 v2, 0x1f4

    const/4 v5, 0x3

    const-wide/16 v2, 0x1f4

    const-wide/16 v2, 0x1f4

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v0
.end method

.method public DuckUnpluginHeadsetWhenVoip()V
    .locals 13

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x6

    iget v0, p0, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    const/4 v1, 0x3

    const/4 v11, 0x5

    xor-int/2addr v12, v11

    if-eq v1, v0, :cond_0

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x7

    return-void

    :cond_0
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x1

    const/16 v2, 0x1d

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x5

    const-string/jumbo v3, "moxq "

    const-string v3, " m:xo"

    const/4 v12, 0x3

    const-string/jumbo v3, "xms :"

    const-string v3, " max:"

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    const-string v4, " set:"

    const/4 v11, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x3

    const-string v5, "eecmiv"

    const-string v5, "device"

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x1

    const-wide/high16 v6, 0x4059000000000000L    # 100.0

    const-wide/high16 v6, 0x4059000000000000L    # 100.0

    const-wide/high16 v6, 0x4059000000000000L    # 100.0

    const-wide/high16 v6, 0x4059000000000000L    # 100.0

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v8, 0x0

    and-int/2addr v12, v8

    const/4 v11, 0x6

    shr-int/2addr v12, v11

    if-ge v0, v2, :cond_2

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v0, v8}, Landroid/media/AudioManager;->setMode(I)V

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x2

    iget-object v2, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v11, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-virtual {v2, v1}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v2

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    int-to-float v2, v2

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget v9, p0, Lcom/zego/ve/AudioEventMonitor;->duck_value_in_percent_:I

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x5

    int-to-float v9, v9

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x7

    mul-float/2addr v9, v2

    const/4 v12, 0x6

    const/4 v11, 0x3

    float-to-double v9, v9

    const/4 v12, 0x2

    div-double/2addr v9, v6

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    double-to-int v6, v9

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x7

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    xor-int/2addr v12, v11

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    const-string/jumbo v9, "uemeoruu kbttedp p)g9<innesirtaD(c2 scuilu: hsr ,a "

    const-string v9, "ee (dbtcknl<a)D:t ceppsi9nu riag2u ahri ,eumtruu ss"

    const/4 v12, 0x1

    const-string/jumbo v9, "uct(,b ahrrnpualuecc<isr D t2gi9pdi) mu  aeksnset:u"

    const-string v9, "Duck reset at headset unplugin(api<29), music curr:"

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-static {v5, v2}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x0

    if-ge v6, v0, :cond_1

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v11, 0x4

    and-int/2addr v12, v11

    invoke-virtual {v0, v1, v6, v8}, Landroid/media/AudioManager;->setStreamVolume(III)V

    :cond_1
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setMode(I)V

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v12, 0x4

    invoke-virtual {v0, v8}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x2

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {v1, v8}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v1

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x1

    int-to-float v1, v1

    const/4 v12, 0x3

    const/4 v11, 0x5

    iget v2, p0, Lcom/zego/ve/AudioEventMonitor;->duck_value_in_percent_:I

    const/4 v11, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    int-to-float v2, v2

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x0

    mul-float/2addr v2, v1

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x3

    float-to-double v9, v2

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x0

    div-double/2addr v9, v6

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    double-to-int v2, v9

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-nez v2, :cond_3

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x2

    const/4 v2, 0x1

    :cond_3
    const/4 v11, 0x5

    const/4 v12, 0x2

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x3

    const-string/jumbo v7, "r p)(vu2ec, htp Dlece:ntkugsu =uat auiirs npio a 9ud>"

    const-string/jumbo v7, "nr)i uur  icuDark9l ae eg(=tt eosh,uptd:vnia up 2pc>s"

    const/4 v12, 0x1

    const-string v7, "(t)2nr parv9cugpo:piD>u l,nauehiearit k   u tsep=cd e"

    const-string v7, "Duck reset at headset unplugin(api >= 29), voip curr:"

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-static {v5, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-virtual {v1, v8, v2, v8}, Landroid/media/AudioManager;->setStreamVolume(III)V

    const/4 v12, 0x0

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v12, 0x1

    const/4 v11, 0x6

    invoke-virtual {v1, v8, v0, v8}, Landroid/media/AudioManager;->setStreamVolume(III)V

    :goto_0
    const/4 v12, 0x3

    const/4 v11, 0x0

    return-void
.end method

.method public GetAudioManager()Landroid/media/AudioManager;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v1, 0x0

    move v2, v1

    return-object v0
.end method

.method public GetAudioRoute()I
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Lcom/zego/ve/AudioEventMonitor;->audio_route_:I

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public GetCaptrueRoute()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Lcom/zego/ve/AudioEventMonitor;->cap_original_route_:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public GetMode()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    iget v0, p0, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public GetRouteChangeHandle()Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioRouteChange:Lcom/zego/ve/AudioEventMonitor$AudioRoutChange;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public Init(Landroid/content/Context;Z)V
    .locals 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1a
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->event_lock_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-boolean v1, p0, Lcom/zego/ve/AudioEventMonitor;->has_inited_:Z

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor;->_context:Landroid/content/Context;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v4, 0x4

    const-string/jumbo v1, "iopqu"

    const-string v1, "dupio"

    const/4 v4, 0x3

    const-string/jumbo v1, "ousdi"

    const-string v1, "audio"

    const/4 v3, 0x5

    and-int/2addr v4, v3

    invoke-virtual {p1, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    check-cast p1, Landroid/media/AudioManager;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x0

    const/4 p1, 0x3

    const/4 v4, 0x2

    const/4 p1, 0x1

    :try_start_2
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput-boolean p1, p0, Lcom/zego/ve/AudioEventMonitor;->has_inited_:Z

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->RegisterAudioRouteListen()I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->InitPhoneStateListener()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz p2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->InitAudioFocusChangeListener()V

    :cond_0
    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->InitAudioPlaybackListener()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo p2, "ieqmcd"

    const-string/jumbo p2, "idqcve"

    const/4 v4, 0x2

    const-string/jumbo p2, "iceeod"

    const-string p2, "device"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v2, "getSystemService failed, "

    const-string/jumbo v2, "getSystemService failed, "

    const/4 v4, 0x0

    const-string/jumbo v2, "getSystemService failed, "

    const-string/jumbo v2, "getSystemService failed, "

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p2, p1}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x1

    return-void

    :cond_1
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void

    :catchall_1
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    throw p1
.end method

.method public IsInited()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/zego/ve/AudioEventMonitor;->has_inited_:Z

    const/4 v2, 0x2

    return v0
.end method

.method public SetBluetoothScoOn(Z)I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/media/AudioManager;->startBluetoothSco()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Landroid/media/AudioManager;->setBluetoothScoOn(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Landroid/media/AudioManager;->setBluetoothScoOn(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/media/AudioManager;->stopBluetoothSco()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v1

    :catch_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string/jumbo v1, "setBluetoothScoOn failed, "

    const-string/jumbo v1, "setBluetoothScoOn failed, "

    const/4 v3, 0x7

    const-string/jumbo v1, "setBluetoothScoOn failed, "

    const-string/jumbo v1, "setBluetoothScoOn failed, "

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v0, "sceidb"

    const-string v0, "cisevd"

    const/4 v3, 0x2

    const-string/jumbo v0, "ueicde"

    const-string v0, "device"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 p1, -0x1

    or-int/2addr v3, p1

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return p1
.end method

.method public SetEeventHandler(Lcom/zego/ve/AudioEventMonitor$IEventNotify;)V
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->event_lock_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor;->event_notify_:Lcom/zego/ve/AudioEventMonitor$IEventNotify;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    monitor-exit v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    throw p1
.end method

.method public SetMode(I)I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput p1, p0, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v2, 0x5

    move v3, v2

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->_audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    move v3, v2

    iget-boolean v1, p0, Lcom/zego/ve/AudioEventMonitor;->duck_other_when_voip_:Z

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/media/AudioManager;->setMode(I)V

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->SetModeWithDucking()V

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x1

    return p1
.end method

.method public SetRoutInfo(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-ne v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/zego/ve/AudioEventMonitor;->wait_check_sco_:Z

    :cond_0
    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor;->event_lock_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v1, 0x7

    const/4 v2, 0x7

    iput p1, p0, Lcom/zego/ve/AudioEventMonitor;->audio_route_:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    monitor-exit v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    throw p1
.end method

.method public SetWaitSocFlag()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x1

    iget v1, p0, Lcom/zego/ve/AudioEventMonitor;->audio_route_:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/zego/ve/AudioEventMonitor;->wait_check_sco_:Z

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-boolean p1, p0, Lcom/zego/ve/AudioEventMonitor;->audio_route_change_valid_:Z

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-nez p1, :cond_a

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-boolean p1, p0, Lcom/zego/ve/AudioEventMonitor;->on_receiver_first_arrive_:Z

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz p1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto/16 :goto_2

    :cond_0
    const/4 v6, 0x1

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v3, "c:naomip"

    const-string/jumbo v3, "o:cmatni"

    const/4 v6, 0x3

    const-string/jumbo v3, "qoa inct"

    const-string v3, "action: "

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/os/BaseBundle;->size()I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-lez v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string v4, ", "

    const-string v4, ", "

    const/4 v6, 0x2

    const-string v4, ", "

    const-string v4, ", "

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/os/Bundle;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x3

    const-string v1, ""

    const-string v1, ""

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const-string v3, "eosieeoRcn"

    const-string v3, "eenRoivoec"

    const/4 v6, 0x2

    const-string/jumbo v3, "n emeRcove"

    const-string/jumbo v3, "onReceive "

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string/jumbo v2, "ibecoe"

    const-string v2, "cieevb"

    const/4 v6, 0x1

    const-string/jumbo v2, "vedicb"

    const-string v2, "device"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v2, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v1, "ienPi.uatSrnDEo.Hnctd_dGnELa.oATtu"

    const-string v1, "ciAr_.uEdno.tDPonLnUGiadT.nettESaH"

    const-string v1, "D.SA_U.pPtinLiGttdneHodiarEnonc.TE"

    const-string v1, "android.intent.action.HEADSET_PLUG"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz v1, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string p1, "aesqt"

    const-string p1, "aepts"

    const-string/jumbo p1, "saset"

    const-string/jumbo p1, "state"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p2, p1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v1, :cond_9

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p2, p1, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-ne p1, v2, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0, v2}, Lcom/zego/ve/AudioEventMonitor;->ChangeAudioRoute(I)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto/16 :goto_1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->RemoveAudioRoute()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    goto/16 :goto_1

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string v0, "eHEm.Gaa.Tttde_proi.AodAECbunTal.qrinooNactDth"

    const-string v0, ".aNidEdtqAtaoH..AtlooETabtciGC.ureeahSonpnTrD_"

    const-string/jumbo v0, "tA.EoediAcet_itabTNu.p.aS.oaHDdlotrTonECondhra"

    const-string v0, "android.bluetooth.adapter.action.STATE_CHANGED"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-wide/16 v3, 0x5dc

    const-wide/16 v3, 0x5dc

    const-wide/16 v3, 0x5dc

    const-wide/16 v3, 0x5dc

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/high16 v1, -0x80000000

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v0, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string/jumbo p1, "otbr.botda.paSorEdt.ele.tnTAaTdaxhriu"

    const-string p1, "android.bluetooth.adapter.extra.STATE"

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {p2, p1, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/16 p2, 0xa

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ne p1, p2, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget p1, p0, Lcom/zego/ve/AudioEventMonitor;->_bluetoothOpSeq:I

    add-int/2addr p1, v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    iput p1, p0, Lcom/zego/ve/AudioEventMonitor;->_bluetoothOpSeq:I

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->RemoveAudioRoute()V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto/16 :goto_1

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/16 p2, 0xc

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ne p1, p2, :cond_9

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget p1, p0, Lcom/zego/ve/AudioEventMonitor;->_bluetoothOpSeq:I

    const/4 v6, 0x6

    add-int/2addr p1, v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    iput p1, p0, Lcom/zego/ve/AudioEventMonitor;->_bluetoothOpSeq:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance p2, Landroid/os/Handler;

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {p2, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v6, 0x3

    new-instance v0, Lcom/zego/ve/AudioEventMonitor$1;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {v0, p0, p1}, Lcom/zego/ve/AudioEventMonitor$1;-><init>(Lcom/zego/ve/AudioEventMonitor;I)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-virtual {p2, v0, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto/16 :goto_1

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo v0, "htes.ouecEGbr.idSndlooNANtlnte.hTaCN_.oTDNoaOs_auEeHiC.dCEOipfrAt"

    const-string v0, "OhsefiCc..tAtCs_bEodeeS.iit_olru.EhpHGrdNoetOnlTaEoANdo.DNaaNTnCT"

    const/4 v6, 0x4

    const-string v0, "ACedETNpieHaSIcethdaAeODoOhfotitarEtnE.CNpn.oolT_ids_u..NNl.bTorG"

    const-string v0, "android.bluetooth.headset.profile.action.CONNECTION_STATE_CHANGED"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v0, :cond_7

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string p1, ".aepTrt.qoTrf.otmdAatniSl.ehoElrubxoi"

    const-string/jumbo p1, "roEmS.lterdTeatfinh.xpAaodbT.ru.oiolt"

    const/4 v6, 0x0

    const-string/jumbo p1, "xtsuloeiStheaAfrdio.lTorrpoan..tEe.Td"

    const-string p1, "android.bluetooth.profile.extra.STATE"

    const/4 v5, 0x6

    move v6, v5

    invoke-virtual {p2, p1, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 p2, 0x2

    shl-int/2addr v6, p2

    const/4 v5, 0x4

    move v6, v5

    if-ne p1, p2, :cond_6

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget p1, p0, Lcom/zego/ve/AudioEventMonitor;->_bluetoothOpSeq:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    add-int/2addr p1, v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput p1, p0, Lcom/zego/ve/AudioEventMonitor;->_bluetoothOpSeq:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    new-instance p2, Landroid/os/Handler;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {p2, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance v0, Lcom/zego/ve/AudioEventMonitor$2;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {v0, p0, p1}, Lcom/zego/ve/AudioEventMonitor$2;-><init>(Lcom/zego/ve/AudioEventMonitor;I)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p2, v0, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_1

    :cond_6
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez p1, :cond_9

    const/4 v6, 0x3

    iget p1, p0, Lcom/zego/ve/AudioEventMonitor;->_bluetoothOpSeq:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    add-int/2addr p1, v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput p1, p0, Lcom/zego/ve/AudioEventMonitor;->_bluetoothOpSeq:I

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->RemoveAudioRoute()V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_1

    :cond_7
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string v0, "dn.m_T.nDIiSAatacEET.e_oD.VdBswHirhaUoudoCEbarA"

    const-string v0, ".e_oorTTt.iciA_.BUoEE.VCCHnhndSrAawaDudabEaIDsd"

    const/4 v6, 0x3

    const-string v0, ".ACCorVdBuTaEU.atn_DHaboed_DEnIdhawSi.EcrirTso."

    const-string v0, "android.hardware.usb.action.USB_DEVICE_ATTACHED"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    if-eqz v0, :cond_8

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p2}, Lcom/zego/ve/AudioDeviceHelper;->HasUsbAudioDevice(Landroid/content/Intent;)Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz p1, :cond_9

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 p1, 0x4

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Lcom/zego/ve/AudioEventMonitor;->ChangeAudioRoute(I)V

    const/4 v5, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_1

    :cond_8
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string p2, "Eni_dbCt.ahAcCb.an.ESTbwBodUIaioDEHrr_EDsdVDeua"

    const-string/jumbo p2, "oidabbABeros.SEhDtauEaDCEdHIr_r_aEd.UncDnwiCTV."

    const/4 v6, 0x0

    const-string/jumbo p2, "odIn.wuErBaaCu_TdnecSadDboi_.DAVEihts.Hr.raEUDC"

    const-string p2, "android.hardware.usb.action.USB_DEVICE_DETACHED"

    const/4 v6, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz p1, :cond_9

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-direct {p0}, Lcom/zego/ve/AudioEventMonitor;->RemoveAudioRoute()V

    :cond_9
    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    return-void

    :cond_a
    :goto_2
    const/4 v6, 0x1

    const/4 v5, 0x2

    iput-boolean v0, p0, Lcom/zego/ve/AudioEventMonitor;->on_receiver_first_arrive_:Z

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    return-void
.end method
