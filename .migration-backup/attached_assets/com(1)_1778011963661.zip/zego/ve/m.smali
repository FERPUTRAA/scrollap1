.class public final synthetic Lcom/zego/ve/m;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Landroid/media/AudioPlaybackConfiguration;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s@~@@~@1a~@@u~ b /ti@~i@o~ rvof .~t~@o~c/Kom b@~  ~@b ~s~@ l~  oo M~@~ @  ~ @@l @@@-i4n~~d@yfS"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p0, Landroid/media/AudioPlaybackConfiguration;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method
