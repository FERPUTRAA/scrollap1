.class Lcom/zego/ve/SniffAndroid$ProcStat;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/SniffAndroid;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "ProcStat"
.end annotation


# instance fields
.field final idleTime:J

.field final runTime:J

.field final synthetic this$0:Lcom/zego/ve/SniffAndroid;


# direct methods
.method constructor <init>(Lcom/zego/ve/SniffAndroid;JJ)V
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/zego/ve/SniffAndroid$ProcStat;->this$0:Lcom/zego/ve/SniffAndroid;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-wide p2, p0, Lcom/zego/ve/SniffAndroid$ProcStat;->runTime:J

    const/4 v1, 0x4

    const/4 v0, 0x6

    iput-wide p4, p0, Lcom/zego/ve/SniffAndroid$ProcStat;->idleTime:J

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method
