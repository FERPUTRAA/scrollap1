.class public final enum Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/MediaCodecVideoEncoder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "VideoCodecType"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

.field public static final enum VIDEO_CODEC_H264_AVC:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

.field public static final enum VIDEO_CODEC_H264_AVC_MULTILAYER:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

.field public static final enum VIDEO_CODEC_H265:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

.field public static final enum VIDEO_CODEC_VP8:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    new-instance v0, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-string v1, "4CsD_CAE2EIV_HOCD_sO"

    const-string v1, "4OsDDEIHV__A2CCCE_OV"

    const-string v1, "D4EmVCC_OVA_26EDOIHC"

    const-string v1, "VIDEO_CODEC_H264_AVC"

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    const/4 v2, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-direct {v0, v1, v2}, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;-><init>(Ljava/lang/String;I)V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    sput-object v0, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;->VIDEO_CODEC_H264_AVC:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    new-instance v1, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-string v3, "VRHmI_AOLE2C_CDOE_V4LDCUEIY6_AM"

    const-string v3, "OEREoAT_LCV_OL_AUEYDCI_4M6HD2IV"

    const-string v3, "VIDEO_CODEC_H264_AVC_MULTILAYER"

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v4, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-direct {v1, v3, v4}, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;-><init>(Ljava/lang/String;I)V

    const/4 v9, 0x6

    move v10, v9

    sput-object v1, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;->VIDEO_CODEC_H264_AVC_MULTILAYER:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    new-instance v3, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const-string v5, "COoV_bC2EDODEH5I"

    const-string v5, "HO_EoC_5C2DEOVID"

    const/4 v10, 0x5

    const-string v5, "DIE_HOuV5EOC6D_C"

    const-string v5, "VIDEO_CODEC_H265"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v6, 0x2

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-direct {v3, v5, v6}, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;-><init>(Ljava/lang/String;I)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    sput-object v3, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;->VIDEO_CODEC_H265:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    new-instance v5, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-string v7, "OPCDVE_pVEO_DbC"

    const-string v7, "_EOOCbDCD_EVVPI"

    const/4 v10, 0x1

    const-string v7, "E_CD_CEIq8PVVDO"

    const-string v7, "VIDEO_CODEC_VP8"

    const/4 v9, 0x1

    shr-int/2addr v10, v9

    const/4 v8, 0x3

    const/4 v8, 0x3

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-direct {v5, v7, v8}, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;-><init>(Ljava/lang/String;I)V

    const/4 v10, 0x1

    sput-object v5, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;->VIDEO_CODEC_VP8:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/4 v7, 0x4

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    new-array v7, v7, [Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    aput-object v0, v7, v2

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    aput-object v1, v7, v4

    const/4 v9, 0x5

    const/4 v10, 0x5

    aput-object v3, v7, v6

    const/4 v10, 0x6

    aput-object v5, v7, v8

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    sput-object v7, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;->$VALUES:[Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "uls~bfb @@yl@~~~@/ooti  @~@@~~~ ~~-@@.  @@risf@o~ @~~ ~n @o4@i t a~ mo1~@/K@~ ~~~@d Mbv ~ ~ @cS@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const-class v0, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v2, 0x6

    const-class v0, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const-class v0, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    check-cast p0, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public static values()[Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;->$VALUES:[Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, [Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast v0, [Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    const/4 v1, 0x6

    move v2, v1

    return-object v0
.end method
