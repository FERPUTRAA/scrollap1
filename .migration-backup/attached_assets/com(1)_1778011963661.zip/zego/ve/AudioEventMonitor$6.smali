.class Lcom/zego/ve/AudioEventMonitor$6;
.super Landroid/media/AudioManager$AudioPlaybackCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/AudioEventMonitor;->InitAudioPlaybackListener()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/AudioEventMonitor;


# direct methods
.method constructor <init>(Lcom/zego/ve/AudioEventMonitor;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor$6;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/media/AudioManager$AudioPlaybackCallback;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onPlaybackConfigChanged(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/media/AudioPlaybackConfiguration;",
            ">;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "b@so~~  ~a i/@ ~v i@1/u@~  ~noit ofr @ -~~~@s@ @~ ~f.~d~4@t ~~~~Mbo~@@@@ S@@~@Kylo~m@c ~@o@  ~l@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/zego/ve/AudioEventMonitor$6;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget v0, p1, Lcom/zego/ve/AudioEventMonitor;->_mode:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v1, 0x3

    const/4 v4, 0x2

    if-ne v1, v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-boolean v0, p1, Lcom/zego/ve/AudioEventMonitor;->duck_other_when_voip_:Z

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/zego/ve/AudioEventMonitor;->access$200(Lcom/zego/ve/AudioEventMonitor;)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor$6;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/zego/ve/AudioEventMonitor;->access$300(Lcom/zego/ve/AudioEventMonitor;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor$6;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v4, 0x2

    const/4 v3, 0x7

    iget-boolean v2, v1, Lcom/zego/ve/AudioEventMonitor;->play_active_in_voip_:Z

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eq p1, v2, :cond_1

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-boolean p1, v1, Lcom/zego/ve/AudioEventMonitor;->play_active_in_voip_:Z

    const/4 v3, 0x3

    move v4, v3

    if-eqz p1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v1}, Lcom/zego/ve/AudioEventMonitor;->access$400(Lcom/zego/ve/AudioEventMonitor;)V

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    throw p1

    :cond_2
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void
.end method
