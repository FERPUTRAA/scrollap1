.class public Lcom/zego/ve/AudioDeviceHelper;
.super Ljava/lang/Object;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x18
.end annotation


# static fields
.field public static final AUDIO_ROUTE_AIR_PLAY:I = 0x5

.field public static final AUDIO_ROUTE_BLUETOOTH:I = 0x2

.field public static final AUDIO_ROUTE_BLUETOOTH_A2DP:I = 0x6

.field public static final AUDIO_ROUTE_CHECK_SCO:I = -0x64

.field public static final AUDIO_ROUTE_HEADSET:I = 0x1

.field public static final AUDIO_ROUTE_INVALID:I = -0x1

.field public static final AUDIO_ROUTE_RECEIVER:I = 0x3

.field public static final AUDIO_ROUTE_SPEAKER:I = 0x0

.field public static final AUDIO_ROUTE_USB_AUDIO:I = 0x4

.field public static final AUDIO_ROUTE_USB_HEADSET:I = 0x7


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    return-void
.end method

.method public static DetectUsbDeviceState(Landroid/content/Context;)Z
    .locals 10
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, " -srm@ cso.~y~ d~@@/Mi~~o ~@@o~bt~ ~fl~@v ~4 @~@@@ K@Sn1~ ~/ ib@b @~li~~  @~f@~ @@ a@~ t ~@o@u~o"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v8, 0x2

    const-string v1, "bsu"

    const-string/jumbo v1, "ubs"

    const/4 v9, 0x1

    const-string/jumbo v1, "usb"

    const-string/jumbo v1, "usb"

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    check-cast p0, Landroid/hardware/usb/UsbManager;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p0}, Landroid/hardware/usb/UsbManager;->getDeviceList()Ljava/util/HashMap;

    move-result-object p0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    move v1, v0

    move v1, v0

    const/4 v9, 0x6

    move v1, v0

    move v1, v0

    :cond_0
    :goto_0
    :try_start_1
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x4

    if-eqz v2, :cond_6

    const/4 v8, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    check-cast v2, Landroid/hardware/usb/UsbDevice;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-nez v2, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto :goto_0

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    move v3, v0

    move v3, v0

    const/4 v9, 0x6

    move v3, v0

    move v3, v0

    :goto_1
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-nez v1, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v2}, Landroid/hardware/usb/UsbDevice;->getConfigurationCount()I

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-ge v3, v4, :cond_0

    const/4 v9, 0x5

    invoke-virtual {v2, v3}, Landroid/hardware/usb/UsbDevice;->getConfiguration(I)Landroid/hardware/usb/UsbConfiguration;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-nez v4, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    goto :goto_4

    :cond_2
    const/4 v8, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    move v5, v0

    move v5, v0

    const/4 v9, 0x6

    move v5, v0

    move v5, v0

    :goto_2
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v4}, Landroid/hardware/usb/UsbConfiguration;->getInterfaceCount()I

    move-result v6

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-ge v5, v6, :cond_5

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v4, v5}, Landroid/hardware/usb/UsbConfiguration;->getInterface(I)Landroid/hardware/usb/UsbInterface;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-nez v6, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto :goto_3

    :cond_3
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v6}, Landroid/hardware/usb/UsbInterface;->getInterfaceClass()I

    move-result v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/4 v7, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-ne v7, v6, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    move v1, v7

    move v1, v7

    const/4 v9, 0x2

    move v1, v7

    move v1, v7

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    goto :goto_4

    :cond_4
    :goto_3
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    add-int/lit8 v5, v5, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    goto :goto_2

    :cond_5
    :goto_4
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    move v0, v1

    move v0, v1

    const/4 v9, 0x1

    move v0, v1

    move v0, v1

    const/4 v9, 0x0

    const/4 v8, 0x7

    goto :goto_5

    :catchall_1
    move-exception p0

    :goto_5
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    move v1, v0

    move v1, v0

    const/4 v9, 0x4

    move v1, v0

    move v1, v0

    :cond_6
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    return v1
.end method

.method public static HasUsbAudioDevice(Landroid/content/Intent;)Z
    .locals 11
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    const-string/jumbo v0, "vesdce"

    const/4 v10, 0x7

    const-string/jumbo v0, "veemci"

    const-string v0, "device"

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p0

    const/4 v10, 0x7

    const/4 v9, 0x0

    check-cast p0, Landroid/hardware/usb/UsbDevice;

    const/4 v0, 0x2

    move v10, v0

    const/4 v0, 0x0

    move v10, v0

    const/4 v9, 0x7

    move v10, v9

    if-eqz p0, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/hardware/usb/UsbDevice;->getConfigurationCount()I

    move-result v1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    move v2, v0

    move v2, v0

    const/4 v10, 0x4

    move v2, v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    move v3, v2

    const/4 v10, 0x0

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-nez v2, :cond_3

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-ge v3, v1, :cond_3

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {p0, v3}, Landroid/hardware/usb/UsbDevice;->getConfiguration(I)Landroid/hardware/usb/UsbConfiguration;

    move-result-object v4

    const/4 v10, 0x1

    if-nez v4, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    goto :goto_2

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {v4}, Landroid/hardware/usb/UsbConfiguration;->getInterfaceCount()I

    move-result v5

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    move v6, v0

    move v6, v0

    const/4 v10, 0x3

    move v6, v0

    move v6, v0

    :goto_1
    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    if-ge v6, v5, :cond_2

    const/4 v9, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v4, v6}, Landroid/hardware/usb/UsbConfiguration;->getInterface(I)Landroid/hardware/usb/UsbInterface;

    move-result-object v7

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-eqz v7, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v7}, Landroid/hardware/usb/UsbInterface;->getInterfaceClass()I

    move-result v7

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v8, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-ne v7, v8, :cond_1

    const/4 v10, 0x6

    move v2, v8

    move v2, v8

    const/4 v10, 0x6

    move v2, v8

    move v2, v8

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    goto :goto_2

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    add-int/lit8 v6, v6, 0x1

    const/4 v9, 0x1

    shl-int/2addr v10, v9

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    goto :goto_0

    :cond_3
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    move v0, v2

    move v0, v2

    const/4 v10, 0x7

    move v0, v2

    :cond_4
    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    return v0
.end method

.method public static RoutType2String(I)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    if-eqz p0, :cond_6

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq p0, v0, :cond_5

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eq p0, v0, :cond_4

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eq p0, v0, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eq p0, v0, :cond_2

    const/4 v2, 0x4

    const/4 v0, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x6

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eq p0, v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x7

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eq p0, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string p0, "UOWm_VDNNNK"

    const/4 v2, 0x4

    const-string p0, "DEV_UNKNOWN"

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string p0, "EASEoBoT_US"

    const-string p0, "EDSEoATSUB_"

    const-string p0, "DUA_SbEEBTS"

    const-string p0, "USB_HEADSET"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string p0, "2ODPHTuOA_BTUE"

    const-string p0, "BLUETOOTH_A2DP"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string p0, "UOUS_bIpB"

    const-string p0, "OBSUIbD_U"

    const/4 v2, 0x4

    const-string p0, "SI_BDUOAq"

    const-string p0, "USB_AUDIO"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :cond_3
    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string/jumbo p0, "uEsERCRV"

    const-string p0, "IVREERuC"

    const/4 v2, 0x6

    const-string p0, "REEmVICR"

    const-string p0, "RECEIVER"

    const/4 v2, 0x6

    const/4 v1, 0x0

    goto :goto_0

    :cond_4
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string p0, "LEOBoCOOUTSTp"

    const-string p0, "CEUSOLOp_OTTB"

    const/4 v2, 0x5

    const-string p0, "_TTHBbOUCOLOS"

    const-string p0, "BLUETOOTH_SCO"

    const/4 v2, 0x4

    goto :goto_0

    :cond_5
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string p0, "WREEDSuEIHTAq"

    const-string p0, "EWHRIETDqSAED"

    const/4 v2, 0x4

    const-string p0, "I_DEAHDpETSER"

    const-string p0, "WIRED_HEADSET"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_6
    const/4 v2, 0x2

    const/4 v1, 0x6

    const-string p0, "EqsEPAS"

    const-string p0, "EEsSPKA"

    const/4 v2, 0x5

    const-string p0, "ERsAKSE"

    const-string p0, "SPEAKER"

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0
.end method

.method public static getBluetoothInput(Landroid/content/Context;)I
    .locals 8
    .annotation build Landroid/annotation/TargetApi;
        value = 0x17
    .end annotation

    const/4 v6, 0x6

    move v7, v6

    const-string/jumbo v0, "omima"

    const-string/jumbo v0, "iadmo"

    const/4 v7, 0x4

    const-string/jumbo v0, "uaoio"

    const-string v0, "audio"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    check-cast p0, Landroid/media/AudioManager;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p0, v0}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    array-length v0, p0

    const/4 v6, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    move v2, v1

    move v2, v1

    const/4 v7, 0x5

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    if-ge v2, v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    aget-object v3, p0, v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v3}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    invoke-static {v4}, Lcom/zego/ve/AudioDeviceHelper;->getRouteType(I)I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 v5, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-ne v5, v4, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v3}, Landroid/media/AudioDeviceInfo;->getId()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_1

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    return v1
.end method

.method public static getBluetoothOutput(Landroid/content/Context;I)I
    .locals 9
    .annotation build Landroid/annotation/TargetApi;
        value = 0x17
    .end annotation

    const/4 v8, 0x2

    const-string v0, "boiuo"

    const-string v0, "diouo"

    const/4 v8, 0x7

    const-string/jumbo v0, "uudia"

    const-string v0, "audio"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    check-cast p0, Landroid/media/AudioManager;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v0, 0x2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p0, v0}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    array-length v1, p0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v2, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    move v3, v2

    move v3, v2

    const/4 v8, 0x4

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x5

    if-ge v3, v1, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    aget-object v4, p0, v3

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v4}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v5

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v5}, Lcom/zego/ve/AudioDeviceHelper;->getRouteType(I)I

    move-result v5

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v6, 0x3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-ne v6, p1, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-ne v0, v5, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v4}, Landroid/media/AudioDeviceInfo;->getId()I

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    goto :goto_1

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-ne v6, v5, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v4}, Landroid/media/AudioDeviceInfo;->getId()I

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    goto :goto_1

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    return v2
.end method

.method public static getCurrentRoute(Landroid/content/Context;I)I
    .locals 18
    .annotation build Landroid/annotation/TargetApi;
        value = 0x17
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v1, p1

    move/from16 v1, p1

    move/from16 v1, p1

    const-string/jumbo v2, "iopud"

    const-string v2, "buido"

    const-string/jumbo v2, "oduqa"

    const-string v2, "audio"

    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/media/AudioManager;

    invoke-virtual {v2}, Landroid/media/AudioManager;->isSpeakerphoneOn()Z

    move-result v3

    const-string/jumbo v4, "iosuatud_erm"

    const-string v4, "_raemouidrtu"

    const-string v4, "do_mireameru"

    const-string/jumbo v4, "media_router"

    invoke-virtual {v0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/MediaRouter;

    const/4 v4, 0x1

    invoke-virtual {v0, v4}, Landroid/media/MediaRouter;->getSelectedRoute(I)Landroid/media/MediaRouter$RouteInfo;

    move-result-object v0

    invoke-virtual {v0}, Landroid/media/MediaRouter$RouteInfo;->getName()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    invoke-virtual {v2, v5}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object v2

    array-length v6, v2

    const/4 v9, 0x0

    const/4 v10, -0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    :goto_0
    const/4 v15, 0x7

    const/4 v7, 0x6

    if-ge v9, v6, :cond_5

    aget-object v16, v2, v9

    invoke-virtual/range {v16 .. v16}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v17

    invoke-static/range {v17 .. v17}, Lcom/zego/ve/AudioDeviceHelper;->getRouteType(I)I

    move-result v8

    if-ne v4, v8, :cond_0

    move v13, v4

    move v13, v4

    move v13, v4

    move v13, v4

    goto :goto_1

    :cond_0
    if-ne v5, v8, :cond_1

    move v11, v4

    move v11, v4

    goto :goto_1

    :cond_1
    if-ne v7, v8, :cond_2

    move v14, v4

    move v14, v4

    move v14, v4

    goto :goto_1

    :cond_2
    if-ne v15, v8, :cond_3

    move v12, v4

    move v12, v4

    move v12, v4

    move v12, v4

    :cond_3
    :goto_1
    invoke-virtual/range {v16 .. v16}, Landroid/media/AudioDeviceInfo;->getProductName()Ljava/lang/CharSequence;

    move-result-object v7

    invoke-interface {v7}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v0, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4

    move v10, v8

    move v10, v8

    move v10, v8

    :cond_4
    add-int/lit8 v9, v9, 0x1

    goto :goto_0

    :cond_5
    const/4 v2, 0x3

    const/4 v6, -0x1

    if-ne v6, v10, :cond_14

    const-string v6, "BSU"

    const-string v6, "UBS"

    const-string v6, "SBU"

    const-string v6, "USB"

    invoke-virtual {v0, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_7

    if-eqz v12, :cond_6

    :goto_2
    move v4, v15

    move v4, v15

    move v4, v15

    move v4, v15

    goto/16 :goto_6

    :cond_6
    const/4 v4, 0x4

    goto/16 :goto_6

    :cond_7
    const-string/jumbo v6, "ipPohe"

    const-string/jumbo v6, "ionPoe"

    const-string/jumbo v6, "iPhone"

    invoke-virtual {v0, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_f

    const-string v6, "2/6b4bu73ua6"

    const-string/jumbo v6, "\u624b\u673a"

    invoke-virtual {v0, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_8

    goto :goto_4

    :cond_8
    if-eqz v11, :cond_9

    goto :goto_5

    :cond_9
    if-eqz v14, :cond_c

    if-ne v2, v1, :cond_b

    if-eqz v3, :cond_a

    :goto_3
    const/4 v4, 0x0

    goto :goto_6

    :cond_a
    move v4, v2

    move v4, v2

    move v4, v2

    goto :goto_6

    :cond_b
    move v4, v7

    move v4, v7

    move v4, v7

    move v4, v7

    goto :goto_6

    :cond_c
    if-eqz v12, :cond_d

    goto :goto_2

    :cond_d
    if-eqz v13, :cond_e

    goto :goto_6

    :cond_e
    if-eqz v3, :cond_a

    goto :goto_3

    :cond_f
    :goto_4
    if-eqz v12, :cond_10

    goto :goto_2

    :cond_10
    if-eqz v13, :cond_11

    goto :goto_6

    :cond_11
    if-eqz v11, :cond_12

    goto :goto_5

    :cond_12
    if-eqz v14, :cond_13

    if-ne v2, v1, :cond_b

    if-eqz v3, :cond_a

    goto :goto_3

    :cond_13
    if-eqz v3, :cond_a

    goto :goto_3

    :cond_14
    if-ne v10, v7, :cond_17

    if-eqz v11, :cond_15

    :goto_5
    move v4, v5

    move v4, v5

    move v4, v5

    move v4, v5

    goto :goto_6

    :cond_15
    if-ne v2, v1, :cond_17

    if-eqz v13, :cond_16

    goto :goto_6

    :cond_16
    if-eqz v3, :cond_a

    goto :goto_3

    :cond_17
    move v4, v10

    move v4, v10

    move v4, v10

    move v4, v10

    :goto_6
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "aimueeu: ord"

    const-string v2, "aeieduo q:rm"

    const-string v2, "e:umeodpa tr"

    const-string/jumbo v2, "media route:"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " select route type:"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v4}, Lcom/zego/ve/AudioDeviceHelper;->RoutType2String(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v1, "ieqevs"

    const-string/jumbo v1, "vcseie"

    const-string v1, "edsice"

    const-string v1, "device"

    invoke-static {v1, v0}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return v4
.end method

.method public static getDeviceTypeStr(I)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    packed-switch p0, :pswitch_data_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "N(NmNOmU"

    const-string v1, "UNNmN(WO"

    const/4 v3, 0x6

    const-string v1, "ONN(oUKW"

    const-string v1, "UNKNOWN("

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string p0, ")"

    const-string p0, ")"

    const/4 v3, 0x1

    const-string p0, ")"

    const-string p0, ")"

    const/4 v3, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto/16 :goto_0

    :pswitch_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string p0, "EoEBEbHDLT_"

    const-string p0, "EH_EoAEBTDL"

    const/4 v3, 0x6

    const-string p0, "EBEHLEuATDS"

    const-string p0, "BLE_HEADSET"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto/16 :goto_0

    :pswitch_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string p0, "_SMEBRXpbOMIU"

    const-string p0, "_MEXEbIMUBSOR"

    const-string p0, "SMROT_IBqMUEX"

    const-string p0, "REMOTE_SUBMIX"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto/16 :goto_0

    :pswitch_2
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string p0, "PEsFSKRAE_Au"

    const-string p0, "S_EFSEuAPKRA"

    const/4 v3, 0x0

    const-string p0, "EFSmAKE_AERS"

    const-string p0, "SPEAKER_SAFE"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto/16 :goto_0

    :pswitch_3
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string p0, "HpGEoAII_DN"

    const-string p0, "IDRHI_ApEGN"

    const/4 v3, 0x4

    const-string p0, "NDARIbHAIE_"

    const-string p0, "HEARING_AID"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto/16 :goto_0

    :pswitch_4
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string p0, "_AUqESuBDET"

    const-string p0, "_EAEHBSTqUD"

    const/4 v3, 0x4

    const-string p0, "ATE_EBSpUSH"

    const-string p0, "USB_HEADSET"

    const/4 v2, 0x0

    move v3, v2

    goto/16 :goto_0

    :pswitch_5
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string p0, "SUB"

    const-string p0, "USB"

    const/4 v3, 0x7

    const-string p0, "BUS"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto/16 :goto_0

    :pswitch_6
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string p0, "PI"

    const-string p0, "IP"

    const/4 v3, 0x4

    const-string p0, "IP"

    const-string p0, "IP"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto/16 :goto_0

    :pswitch_7
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo p0, "qXUsL_NA"

    const-string p0, "_LsAXUEN"

    const/4 v3, 0x0

    const-string p0, "INs_EUXA"

    const-string p0, "AUX_LINE"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto/16 :goto_0

    :pswitch_8
    const/4 v3, 0x6

    const-string p0, "PELmNETmO"

    const-string p0, "HETmELNPO"

    const/4 v3, 0x3

    const-string p0, "PHYNoETLO"

    const-string p0, "TELEPHONY"

    const/4 v3, 0x2

    const/4 v2, 0x3

    goto/16 :goto_0

    :pswitch_9
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string p0, "RE_VoNUT"

    const/4 v3, 0x3

    const-string p0, "_VNEUbTT"

    const-string p0, "TV_TUNER"

    const/4 v3, 0x1

    const/4 v2, 0x2

    goto/16 :goto_0

    :pswitch_a
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string p0, "MTRFb_uN"

    const-string p0, "NFT_MbRU"

    const/4 v3, 0x2

    const-string p0, "_FNMUTEp"

    const-string p0, "FM_TUNER"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto/16 :goto_0

    :pswitch_b
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string p0, "BIUuTNICqIL"

    const-string p0, "LBICINuU_TI"

    const/4 v3, 0x6

    const-string p0, "MLsUI_NCIIB"

    const-string p0, "BUILTIN_MIC"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto/16 :goto_0

    :pswitch_c
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string p0, "FM"

    const-string p0, "MF"

    const/4 v3, 0x6

    const-string p0, "MF"

    const-string p0, "FM"

    const/4 v3, 0x7

    const/4 v2, 0x3

    goto/16 :goto_0

    :pswitch_d
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string p0, "DCOK"

    const-string p0, "CODK"

    const/4 v3, 0x3

    const-string p0, "KOCD"

    const-string p0, "DOCK"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto/16 :goto_0

    :pswitch_e
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string p0, "_pSmSCUAORBES"

    const-string p0, "USBCASSpOCER_"

    const/4 v3, 0x7

    const-string p0, "USB_ACCESSORY"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto/16 :goto_0

    :pswitch_f
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string p0, "CD_EoUBqIS"

    const-string p0, "CUEISB_DqE"

    const/4 v3, 0x7

    const-string p0, "ECEVIbUD_B"

    const-string p0, "USB_DEVICE"

    const/4 v3, 0x1

    goto/16 :goto_0

    :pswitch_10
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string p0, "C_sMARID"

    const/4 v3, 0x0

    const-string p0, "RCID_HuA"

    const-string p0, "HDMI_ARC"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto/16 :goto_0

    :pswitch_11
    const/4 v3, 0x3

    const/4 v2, 0x5

    const-string p0, "MDIH"

    const-string p0, "IDHM"

    const/4 v3, 0x3

    const-string p0, "HMID"

    const-string p0, "HDMI"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :pswitch_12
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string p0, "_DP2BOUpEAmLOT"

    const-string p0, "A_PmTLDH2UEOOB"

    const/4 v3, 0x3

    const-string p0, "U_PBHTALqT2ODO"

    const-string p0, "BLUETOOTH_A2DP"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :pswitch_13
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string p0, "ELs_SOHUCBOTO"

    const-string p0, "SL_BoOHCOTOUE"

    const/4 v3, 0x0

    const-string p0, "STLmUCO_BOOET"

    const-string p0, "BLUETOOTH_SCO"

    const/4 v3, 0x4

    goto :goto_0

    :pswitch_14
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string p0, "b_IGoDNELTAI"

    const-string p0, "IALNIbDGETI_"

    const/4 v3, 0x2

    const-string p0, "IA_LEbDTGLNI"

    const-string p0, "LINE_DIGITAL"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :pswitch_15
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string p0, "NLAAOGuEuLN"

    const-string p0, "ALO_LNuANEG"

    const/4 v3, 0x4

    const-string p0, "EOAG_LLpINN"

    const-string p0, "LINE_ANALOG"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :pswitch_16
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string p0, "IE_WOAHHqEDPESpD"

    const-string p0, "EEOE_HHpDRSPAWID"

    const-string p0, "ENsDIHHESWRD_APO"

    const-string p0, "WIRED_HEADPHONES"

    const/4 v2, 0x0

    move v3, v2

    goto :goto_0

    :pswitch_17
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string p0, "IDEmqRETWEHSA"

    const-string p0, "AWE_RTHDqEESI"

    const/4 v3, 0x1

    const-string p0, "EIDRoSTHADE_E"

    const-string p0, "WIRED_HEADSET"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :pswitch_18
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string p0, "EL_RIbAKSPIBTNs"

    const-string p0, "SKsLNBEPTIIAE_R"

    const/4 v3, 0x4

    const-string p0, "TEBR_KuUNISAIEL"

    const-string p0, "BUILTIN_SPEAKER"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :pswitch_19
    const/4 v3, 0x4

    const-string p0, "_UTmIBApLCIPEIER"

    const-string p0, "_BAmLUEEIIEPCTRI"

    const/4 v3, 0x2

    const-string p0, "EAREE_LTqCIIUBPI"

    const-string p0, "BUILTIN_EARPIECE"

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static getRouteType(I)I
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v0, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v1, 0x1

    const/4 v5, 0x7

    or-int/2addr v6, v5

    if-eq p0, v1, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v2, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x1

    if-eq p0, v2, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eq p0, v0, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v0, 0x4

    const/4 v6, 0x1

    if-eq p0, v0, :cond_3

    const/4 v5, 0x5

    xor-int/2addr v6, v5

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eq p0, v1, :cond_2

    const/4 v5, 0x1

    move v6, v5

    const/16 v4, 0x8

    const/4 v6, 0x5

    const/4 v5, 0x3

    if-eq p0, v4, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/16 v4, 0xb

    const/4 v5, 0x0

    move v6, v5

    if-eq p0, v4, :cond_4

    const/4 v6, 0x5

    const/16 v4, 0xc

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eq p0, v4, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/16 v0, 0x16

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eq p0, v0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    packed-switch p0, :pswitch_data_0

    :cond_0
    :pswitch_0
    const/4 v5, 0x3

    move v6, v5

    move v0, v3

    move v0, v3

    const/4 v6, 0x0

    move v0, v3

    move v0, v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_0

    :pswitch_1
    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v0, -0x1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v0, 0x6

    const/4 v6, 0x5

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    :pswitch_2
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    move v0, v2

    move v0, v2

    const/4 v6, 0x4

    move v0, v2

    move v0, v2

    const/4 v6, 0x7

    goto :goto_0

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    const/4 v6, 0x7

    move v0, v1

    move v0, v1

    :cond_4
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x18
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method

.method public static scoConnect(Landroid/content/Context;)Z
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo v0, "oisau"

    const-string/jumbo v0, "uioao"

    const/4 v6, 0x7

    const-string v0, "duomi"

    const-string v0, "audio"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    check-cast p0, Landroid/media/AudioManager;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v0, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p0, v0}, Landroid/media/AudioManager;->getDevices(I)[Landroid/media/AudioDeviceInfo;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    array-length v1, p0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    move v3, v2

    move v3, v2

    const/4 v6, 0x0

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-ge v3, v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    aget-object v4, p0, v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v4}, Landroid/media/AudioDeviceInfo;->getType()I

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v4}, Lcom/zego/ve/AudioDeviceHelper;->getRouteType(I)I

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-ne v0, v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 p0, 0x3

    const/4 p0, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    return p0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    return v2
.end method
