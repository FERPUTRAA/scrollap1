.class Lcom/zego/ve/VCam$CamDevice;
.super Lcom/zego/ve/VCam$CameraDev;

# interfaces
.implements Landroid/hardware/Camera$PreviewCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/VCam;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "CamDevice"
.end annotation


# instance fields
.field private mCam:Landroid/hardware/Camera;

.field private mCamInfo:Landroid/hardware/Camera$CameraInfo;

.field private mParams:Landroid/hardware/Camera$Parameters;

.field final synthetic this$0:Lcom/zego/ve/VCam;


# direct methods
.method constructor <init>(Lcom/zego/ve/VCam;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-direct {p0, p1}, Lcom/zego/ve/VCam$CameraDev;-><init>(Lcom/zego/ve/VCam;)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCamInfo:Landroid/hardware/Camera$CameraInfo;

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$800(Lcom/zego/ve/VCam$CamDevice;)Landroid/hardware/Camera;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ s4 ~cfsn~~i@@~@~~@~o @i~K@@d /of lb/~@-~ @~~@ @lMi o@@  ~ vbou~at.~yo 1 ~~@ S~@~m~@@@tr~ @ ~b "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v1, 0x6

    return-object p0
.end method

.method private calculateArea(FF)Landroid/graphics/Rect;
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v9, 0x4

    const/4 v8, 0x0

    iget v1, v0, Lcom/zego/ve/VCam;->mAreaSize:I

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    int-to-float v2, v1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget v3, v0, Lcom/zego/ve/VCam;->mWidth:I

    const/4 v9, 0x1

    const/4 v8, 0x7

    int-to-float v3, v3

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    div-float/2addr v2, v3

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/high16 v3, 0x40000000    # 2.0f

    const/4 v8, 0x0

    const/4 v9, 0x1

    mul-float/2addr v2, v3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    int-to-float v1, v1

    const/4 v9, 0x1

    const/4 v8, 0x2

    iget v0, v0, Lcom/zego/ve/VCam;->mHeight:I

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    int-to-float v0, v0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    div-float/2addr v1, v0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    mul-float/2addr v1, v3

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    div-float v0, v2, v3

    const/4 v9, 0x4

    const/4 v8, 0x4

    sub-float/2addr p1, v0

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    sub-float v4, v0, v2

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/high16 v5, -0x40800000    # -1.0f

    const/4 v9, 0x4

    const/4 v8, 0x3

    invoke-static {p1, v5, v4}, Lcom/zego/ve/VCam;->clamp2(FFF)F

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    div-float v3, v1, v3

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    sub-float/2addr p2, v3

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    sub-float/2addr v0, v1

    const/4 v9, 0x4

    invoke-static {p2, v5, v0}, Lcom/zego/ve/VCam;->clamp2(FFF)F

    move-result p2

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    new-instance v0, Landroid/graphics/Rect;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/high16 v3, 0x447a0000    # 1000.0f

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    mul-float v4, p1, v3

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    float-to-int v4, v4

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    const/16 v5, -0x3e8

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    const/16 v6, 0x3e8

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v4, v5, v6}, Lcom/zego/ve/VCam;->clamp(III)I

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    mul-float v7, p2, v3

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    float-to-int v7, v7

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {v7, v5, v6}, Lcom/zego/ve/VCam;->clamp(III)I

    move-result v7

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    add-float/2addr p1, v2

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    mul-float/2addr p1, v3

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    float-to-int p1, p1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {p1, v5, v6}, Lcom/zego/ve/VCam;->clamp(III)I

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    add-float/2addr p2, v1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    mul-float/2addr p2, v3

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    float-to-int p2, p2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {p2, v5, v6}, Lcom/zego/ve/VCam;->clamp(III)I

    move-result p2

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-direct {v0, v4, v7, p1, p2}, Landroid/graphics/Rect;-><init>(IIII)V

    const/4 v8, 0x6

    move v9, v8

    return-object v0
.end method

.method private createPool()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/zego/ve/VCam;->access$1000(Lcom/zego/ve/VCam;)Ljava/util/Set;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget v1, v0, Lcom/zego/ve/VCam;->mWidth:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget v2, v0, Lcom/zego/ve/VCam;->mHeight:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    mul-int/2addr v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v2, 0x3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    mul-int/2addr v1, v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    div-int/lit8 v1, v1, 0x2

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/zego/ve/VCam;->access$1102(Lcom/zego/ve/VCam;I)I

    const/4 v0, 0x0

    xor-int/2addr v5, v0

    xor-int/2addr v4, v0

    :goto_0
    if-ge v0, v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-static {v1}, Lcom/zego/ve/VCam;->access$1100(Lcom/zego/ve/VCam;)I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v1}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v3, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v3}, Lcom/zego/ve/VCam;->access$1000(Lcom/zego/ve/VCam;)Ljava/util/Set;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {v3, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v3, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {v3, v1}, Landroid/hardware/Camera;->addCallbackBuffer([B)V

    const/4 v4, 0x6

    const/4 v4, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void
.end method


# virtual methods
.method closeTorch()I
    .locals 7

    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v0, -0x1

    move v6, v0

    const/4 v5, 0x2

    move v6, v5

    return v0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->getFlashMode()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/hardware/Camera$Parameters;->getSupportedFlashModes()Ljava/util/List;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string/jumbo v2, "off"

    const-string/jumbo v2, "fof"

    const/4 v6, 0x4

    const-string/jumbo v2, "ffo"

    const-string/jumbo v2, "off"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {v1, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const-string v3, "cpav"

    const-string/jumbo v3, "pcav"

    const/4 v6, 0x4

    const-string v3, "cavp"

    const-string/jumbo v3, "vcap"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x2

    if-eqz v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    if-nez v0, :cond_1

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, v2}, Landroid/hardware/Camera$Parameters;->setFlashMode(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x1

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v1, "eahmidmlfafpd:tesslve sao c"

    const-string/jumbo v1, "pss  lmeveo dfdliaa:saefhct"

    const/4 v6, 0x2

    const-string v1, "ee:fodseapc hmidl vs  atofl"

    const-string/jumbo v1, "vcap: set flash mode failed"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    goto :goto_1

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    move v0, v4

    move v0, v4

    const/4 v6, 0x1

    move v0, v4

    move v0, v4

    :goto_1
    const/4 v5, 0x0

    move v6, v5

    if-nez v0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string/jumbo v0, "tvfmabh  ndcaeoumf pe let:s"

    const-string v0, " fam:otecavh pes n ldtmsufe"

    const/4 v6, 0x2

    const-string v0, " eatfuulo nlasd meehvs:cp f"

    const-string/jumbo v0, "vcap: flash mode left unset"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    return v4

    :cond_2
    :try_start_1
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v5, 0x5

    and-int/2addr v6, v5

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v5, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v6, 0x0

    goto :goto_2

    :catch_1
    move-exception v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string v1, "epamdh prcmlaea:t  pttxsneer-himrofsesweeoorrc-pvoari e st ec  ta "

    const-string/jumbo v1, "o-icosrsnph epraht p  ev  r or:tc ratrawleessee mm-xfai eeodtmetac"

    const/4 v6, 0x0

    const-string/jumbo v1, "toatste qah feism tr  da av rrpreie xer-s reamchnwlecp-esa:ocopmt "

    const-string/jumbo v1, "vcap: set flash mode -- set camera parameters error with exception"

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_2
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    return v4
.end method

.method public createCam(I)I
    .locals 16

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move/from16 v2, p1

    move/from16 v2, p1

    move/from16 v2, p1

    move/from16 v2, p1

    const-string v3, " failed, "

    const-string v3, " failed, "

    const-string v3, " failed, "

    const-string v3, " failed, "

    const-string/jumbo v4, "taspeoeprci onrnrebtun  "

    const-string/jumbo v4, "uirteboro rep ninacpe tn"

    const-string/jumbo v4, "io mrrrnpuateteoe ipt cn"

    const-string/jumbo v4, "trace interruption open "

    const-string v5, "capv"

    const-string/jumbo v5, "vcap"

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    return v6

    :cond_0
    new-instance v0, Landroid/hardware/Camera$CameraInfo;

    invoke-direct {v0}, Landroid/hardware/Camera$CameraInfo;-><init>()V

    iput-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mCamInfo:Landroid/hardware/Camera$CameraInfo;

    const/4 v7, 0x0

    :try_start_0
    invoke-static/range {p1 .. p1}, Landroid/hardware/Camera;->open(I)Landroid/hardware/Camera;

    move-result-object v0

    iput-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mCamInfo:Landroid/hardware/Camera$CameraInfo;

    invoke-static {v2, v0}, Landroid/hardware/Camera;->getCameraInfo(ILandroid/hardware/Camera$CameraInfo;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v9, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    invoke-static {v9, v2}, Lcom/zego/ve/VCam;->access$300(Lcom/zego/ve/VCam;I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    iput-object v7, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    :goto_0
    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iput v2, v0, Lcom/zego/ve/VCam;->mUseCameraId:I

    iget-object v8, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v9, -0x1

    if-nez v8, :cond_3

    invoke-static {v0}, Lcom/zego/ve/VCam;->access$400(Lcom/zego/ve/VCam;)Z

    move-result v0

    const-string/jumbo v8, "ufoaoca vrun cdo:aenm"

    const-string/jumbo v8, "racv:fucomp  andneauo"

    const-string v8, "ceaonbvdoaafu  c:np r"

    const-string/jumbo v8, "vcap: no camera found"

    if-nez v0, :cond_1

    invoke-static {v5, v8}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return v9

    :cond_1
    const-string/jumbo v0, "o nat:uuoppr delana ,umf rdccf vty"

    const-string v0, "dt, aarpacn   :ruaftev ncyofpodmul"

    const-string/jumbo v0, "onplud p: crcaaetm efo narvafydu,t"

    const-string/jumbo v0, "vcap: no camera found, try default"

    invoke-static {v5, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :try_start_1
    invoke-static {}, Landroid/hardware/Camera;->open()Landroid/hardware/Camera;

    move-result-object v0

    iput-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    goto :goto_1

    :catch_1
    move-exception v0

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v11, v4, Lcom/zego/ve/VCam;->mBackCameraId:I

    invoke-static {v4, v11}, Lcom/zego/ve/VCam;->access$300(Lcom/zego/ve/VCam;I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    iput-object v7, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    :goto_1
    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    if-nez v0, :cond_2

    invoke-static {v5, v8}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return v9

    :cond_2
    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v0, v0, Lcom/zego/ve/VCam;->mBackCameraId:I

    iget-object v3, v1, Lcom/zego/ve/VCam$CamDevice;->mCamInfo:Landroid/hardware/Camera$CameraInfo;

    invoke-static {v0, v3}, Landroid/hardware/Camera;->getCameraInfo(ILandroid/hardware/Camera$CameraInfo;)V

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v3, v0, Lcom/zego/ve/VCam;->mBackCameraId:I

    iput v3, v0, Lcom/zego/ve/VCam;->mUseCameraId:I

    :cond_3
    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    invoke-virtual {v0}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v0

    iput-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->getPreferredPreviewSizeForVideo()Landroid/hardware/Camera$Size;

    move-result-object v0

    iget-object v3, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v4, v3, Lcom/zego/ve/VCam;->mWidth:I

    const/16 v8, 0x2d0

    if-lt v4, v8, :cond_4

    iget v3, v3, Lcom/zego/ve/VCam;->mSceneMode:I

    if-eqz v3, :cond_4

    const/4 v3, 0x1

    goto :goto_2

    :cond_4
    move v3, v6

    move v3, v6

    move v3, v6

    move v3, v6

    :goto_2
    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    invoke-virtual {v4}, Landroid/hardware/Camera$Parameters;->getSupportedVideoSizes()Ljava/util/List;

    move-result-object v4

    if-nez v4, :cond_5

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    invoke-virtual {v4}, Landroid/hardware/Camera$Parameters;->getSupportedPreviewSizes()Ljava/util/List;

    move-result-object v4

    :cond_5
    const-string/jumbo v11, "x"

    const-string/jumbo v11, "x"

    const-string/jumbo v11, "x"

    const-string/jumbo v11, "x"

    if-eqz v4, :cond_16

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v12

    move v13, v6

    move v13, v6

    move v13, v6

    move v13, v6

    move v14, v13

    move v14, v13

    move v14, v13

    :goto_3
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_8

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Landroid/hardware/Camera$Size;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v9, "r pssp:zqtvio  -eq -cu"

    const-string v9, "-i -urptqcvspe:az so  "

    const-string/jumbo v9, "pzseavr s pu-:otc ips-"

    const-string/jumbo v9, "vcap: support size -- "

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v9, v15, Landroid/hardware/Camera$Size;->width:I

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v9, v15, Landroid/hardware/Camera$Size;->height:I

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v5, v9}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iget v9, v15, Landroid/hardware/Camera$Size;->width:I

    iget v10, v15, Landroid/hardware/Camera$Size;->height:I

    mul-int v15, v9, v10

    mul-int v7, v13, v14

    if-le v15, v7, :cond_7

    mul-int/lit8 v7, v9, 0x3

    mul-int/lit8 v15, v10, 0x4

    if-eq v7, v15, :cond_6

    mul-int/lit8 v7, v9, 0x9

    mul-int/lit8 v15, v10, 0x10

    if-ne v7, v15, :cond_7

    :cond_6
    move v13, v9

    move v13, v9

    move v13, v9

    move v13, v9

    move v14, v10

    move v14, v10

    move v14, v10

    move v14, v10

    :cond_7
    const/4 v7, 0x0

    const/4 v9, -0x1

    goto :goto_3

    :cond_8
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    move v7, v6

    move v7, v6

    move v7, v6

    move v7, v6

    move v9, v7

    move v9, v7

    move v9, v7

    move v9, v7

    :goto_4
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_17

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/hardware/Camera$Size;

    iget v12, v10, Landroid/hardware/Camera$Size;->width:I

    rem-int/lit8 v15, v12, 0x10

    if-nez v15, :cond_15

    iget v10, v10, Landroid/hardware/Camera$Size;->height:I

    rem-int/lit8 v15, v10, 0x10

    if-eqz v15, :cond_9

    goto/16 :goto_6

    :cond_9
    if-eqz v3, :cond_a

    iget v15, v0, Landroid/hardware/Camera$Size;->height:I

    mul-int/2addr v15, v12

    iget v6, v0, Landroid/hardware/Camera$Size;->width:I

    mul-int/2addr v6, v10

    if-eq v15, v6, :cond_a

    goto :goto_6

    :cond_a
    iget-object v6, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v15, v6, Lcom/zego/ve/VCam;->mWidth:I

    if-lt v12, v15, :cond_d

    iget v8, v6, Lcom/zego/ve/VCam;->mHeight:I

    if-lt v10, v8, :cond_d

    if-lt v7, v15, :cond_c

    if-ge v9, v8, :cond_b

    goto :goto_5

    :cond_b
    mul-int v6, v12, v10

    mul-int v8, v7, v9

    if-ge v6, v8, :cond_15

    :cond_c
    :goto_5
    move v9, v10

    move v9, v10

    move v7, v12

    move v7, v12

    move v7, v12

    move v7, v12

    goto :goto_6

    :cond_d
    if-lt v12, v15, :cond_11

    if-lt v7, v15, :cond_e

    iget v8, v6, Lcom/zego/ve/VCam;->mHeight:I

    if-lt v9, v8, :cond_e

    goto :goto_6

    :cond_e
    if-ge v7, v15, :cond_f

    iget v6, v6, Lcom/zego/ve/VCam;->mHeight:I

    if-ge v9, v6, :cond_f

    goto :goto_5

    :cond_f
    if-lt v7, v15, :cond_10

    if-le v10, v9, :cond_10

    goto :goto_5

    :cond_10
    mul-int v6, v12, v10

    mul-int v8, v7, v9

    if-le v6, v8, :cond_15

    goto :goto_5

    :cond_11
    iget v6, v6, Lcom/zego/ve/VCam;->mHeight:I

    if-lt v10, v6, :cond_15

    if-lt v7, v15, :cond_12

    if-lt v9, v6, :cond_12

    goto :goto_6

    :cond_12
    if-ge v7, v15, :cond_13

    if-ge v9, v6, :cond_13

    goto :goto_5

    :cond_13
    if-lt v9, v6, :cond_14

    if-le v12, v7, :cond_14

    goto :goto_5

    :cond_14
    mul-int v6, v12, v10

    mul-int v8, v7, v9

    if-le v6, v8, :cond_15

    goto :goto_5

    :cond_15
    :goto_6
    const/4 v6, 0x0

    const/16 v8, 0x2d0

    goto :goto_4

    :cond_16
    const/4 v7, 0x0

    const/4 v9, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    :cond_17
    mul-int v4, v7, v9

    if-eqz v4, :cond_18

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    invoke-virtual {v4, v7, v9}, Landroid/hardware/Camera$Parameters;->setPreviewSize(II)V

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iput v7, v4, Lcom/zego/ve/VCam;->mWidth:I

    iput v9, v4, Lcom/zego/ve/VCam;->mHeight:I

    goto :goto_7

    :cond_18
    mul-int v4, v13, v14

    if-eqz v4, :cond_19

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    invoke-virtual {v4, v13, v14}, Landroid/hardware/Camera$Parameters;->setPreviewSize(II)V

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iput v13, v4, Lcom/zego/ve/VCam;->mWidth:I

    iput v14, v4, Lcom/zego/ve/VCam;->mHeight:I

    goto :goto_7

    :cond_19
    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/16 v6, 0x140

    const/16 v8, 0xf0

    invoke-virtual {v4, v6, v8}, Landroid/hardware/Camera$Parameters;->setPreviewSize(II)V

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iput v6, v4, Lcom/zego/ve/VCam;->mWidth:I

    iput v8, v4, Lcom/zego/ve/VCam;->mHeight:I

    :goto_7
    sget-object v4, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const-string/jumbo v6, "iammis"

    const-string/jumbo v6, "iismoa"

    const-string v6, "aiiooX"

    const-string v6, "Xiaomi"

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_1a

    sget-object v6, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const-string v8, "T4MILbE"

    const-string v8, "MI 4LTE"

    invoke-virtual {v6, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    :cond_1a
    iget-object v6, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget-boolean v6, v6, Lcom/zego/ve/VCam;->mNeedHack:Z

    if-eqz v6, :cond_1b

    const-string/jumbo v6, "rrv   umfppese:eevarwesz ipcu"

    const-string/jumbo v6, "ur meeppp :vezi vrsfrseiweac "

    const-string v6, "ec:pierp  sp riespe fvrvuwaze"

    const-string/jumbo v6, "vcap: use prefer preview size"

    invoke-static {v5, v6}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x0

    goto :goto_8

    :cond_1b
    const/4 v6, 0x1

    :goto_8
    const-string v8, "APCT"

    const-string v8, "CPAT"

    const-string v8, "TPAC"

    const-string v8, "PTAC"

    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1c

    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const-string/jumbo v8, "qI0BFoO0"

    const-string v8, "I0DOoB0F"

    const-string v8, "FBsD0-0O"

    const-string v8, "FIO-BD00"

    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1c

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v8, v4, Lcom/zego/ve/VCam;->mWidth:I

    iget v4, v4, Lcom/zego/ve/VCam;->mHeight:I

    mul-int/2addr v8, v4

    const v4, 0xe1000

    if-ge v8, v4, :cond_1c

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/16 v6, 0x500

    const/16 v8, 0x2d0

    invoke-virtual {v4, v6, v8}, Landroid/hardware/Camera$Parameters;->setPreviewSize(II)V

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iput v6, v4, Lcom/zego/ve/VCam;->mWidth:I

    iput v8, v4, Lcom/zego/ve/VCam;->mHeight:I

    const/4 v6, 0x1

    :cond_1c
    if-nez v6, :cond_1d

    if-eqz v0, :cond_1d

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    iget v6, v0, Landroid/hardware/Camera$Size;->width:I

    iget v8, v0, Landroid/hardware/Camera$Size;->height:I

    invoke-virtual {v4, v6, v8}, Landroid/hardware/Camera$Parameters;->setPreviewSize(II)V

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v6, v0, Landroid/hardware/Camera$Size;->width:I

    iput v6, v4, Lcom/zego/ve/VCam;->mWidth:I

    iget v6, v0, Landroid/hardware/Camera$Size;->height:I

    iput v6, v4, Lcom/zego/ve/VCam;->mHeight:I

    :cond_1d
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "efpmp- eaw  evic:szpeererr:i-dvr"

    const-string/jumbo v6, "vcap: preview size -- perferred:"

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-nez v0, :cond_1e

    const/4 v6, 0x0

    goto :goto_9

    :cond_1e
    iget v6, v0, Landroid/hardware/Camera$Size;->width:I

    :goto_9
    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-nez v0, :cond_1f

    const/4 v0, 0x0

    goto :goto_a

    :cond_1f
    iget v0, v0, Landroid/hardware/Camera$Size;->height:I

    :goto_a
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ",a:co tnebdd"

    const-string v0, ", cnabdi:edt"

    const-string/jumbo v0, "itcndb:aad e"

    const-string v0, ", candidate:"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, ",ve:riupuw"

    const-string/jumbo v0, "ie,: wupvr"

    const-string v0, "e iveprp:w"

    const-string v0, ", preview:"

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v0, v0, Lcom/zego/ve/VCam;->mWidth:I

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v0, v0, Lcom/zego/ve/VCam;->mHeight:I

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v4, v0, Lcom/zego/ve/VCam;->mFPSMode:I

    if-eqz v4, :cond_20

    iget v0, v0, Lcom/zego/ve/VCam;->mFrameRate:I

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    invoke-virtual {v1, v0, v4}, Lcom/zego/ve/VCam$CamDevice;->updateRate(ILandroid/hardware/Camera$Parameters;)I

    :cond_20
    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    invoke-virtual {v0, v3}, Landroid/hardware/Camera$Parameters;->setRecordingHint(Z)V

    :try_start_2
    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    iget-object v3, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    invoke-virtual {v0, v3}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    invoke-virtual {v0}, Landroid/hardware/Camera;->getParameters()Landroid/hardware/Camera$Parameters;

    move-result-object v0

    iput-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    iget-object v3, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->getPreviewSize()Landroid/hardware/Camera$Size;

    move-result-object v0

    iget v0, v0, Landroid/hardware/Camera$Size;->width:I

    iput v0, v3, Lcom/zego/ve/VCam;->mWidth:I

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget-object v3, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    invoke-virtual {v3}, Landroid/hardware/Camera$Parameters;->getPreviewSize()Landroid/hardware/Camera$Size;

    move-result-object v3

    iget v3, v3, Landroid/hardware/Camera$Size;->height:I

    iput v3, v0, Lcom/zego/ve/VCam;->mHeight:I

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v3, v0, Lcom/zego/ve/VCam;->mWidth:I

    div-int/lit8 v3, v3, 0xa

    iput v3, v0, Lcom/zego/ve/VCam;->mAreaSize:I

    invoke-direct/range {p0 .. p0}, Lcom/zego/ve/VCam$CamDevice;->createPool()V

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    invoke-static {v0}, Lcom/zego/ve/VCam;->access$500(Lcom/zego/ve/VCam;)Z

    move-result v0

    if-eqz v0, :cond_21

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    invoke-static {v0, v2}, Lcom/zego/ve/VCam;->access$600(Lcom/zego/ve/VCam;I)V

    :cond_21
    const/4 v2, 0x0

    return v2

    :catch_2
    move-exception v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "pdvo creqsrshreteiwtnrmatexeepriwit hrc  e: p:comaaap a"

    const-string/jumbo v4, "rmpehrapi:stm:ca e chtvie rwoa p wdptcerterereasi anox "

    const-string/jumbo v4, "msse eo  w tp  smrrx rthadaracatcrierioptwevntepehi:ec:"

    const-string/jumbo v4, "vcap: set camera parameters error with exception width:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    invoke-virtual {v4}, Landroid/hardware/Camera$Parameters;->getPreviewSize()Landroid/hardware/Camera$Size;

    move-result-object v4

    iget v4, v4, Landroid/hardware/Camera$Size;->width:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, ":eqmhgit"

    const-string/jumbo v4, "qte ihg:"

    const-string/jumbo v4, "hheiog t"

    const-string v4, " height:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v1, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    invoke-virtual {v4}, Landroid/hardware/Camera$Parameters;->getPreviewSize()Landroid/hardware/Camera$Size;

    move-result-object v4

    iget v4, v4, Landroid/hardware/Camera$Size;->height:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "."

    const-string v4, "."

    const-string v4, "."

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    invoke-virtual {v0}, Landroid/hardware/Camera;->release()V

    const/4 v3, 0x0

    iput-object v3, v1, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    iget-object v0, v1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget-boolean v3, v0, Lcom/zego/ve/VCam;->mNeedHack:Z

    if-eqz v3, :cond_22

    const/4 v3, -0x1

    return v3

    :cond_22
    const/4 v3, 0x1

    iput-boolean v3, v0, Lcom/zego/ve/VCam;->mNeedHack:Z

    invoke-virtual/range {p0 .. p1}, Lcom/zego/ve/VCam$CamDevice;->createCam(I)I

    move-result v0

    return v0
.end method

.method doSetExposureCompensation(FLandroid/hardware/Camera$Parameters;)I
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v0, "cpav"

    const-string v0, "cpav"

    const-string/jumbo v0, "vcap"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p2}, Landroid/hardware/Camera$Parameters;->getMinExposureCompensation()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v2, -0x1

    mul-int/2addr v1, v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p2}, Landroid/hardware/Camera$Parameters;->getMaxExposureCompensation()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    cmpg-float v4, p1, v4

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-gez v4, :cond_0

    int-to-float v1, v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    int-to-float v1, v3

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    mul-float/2addr v1, p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    float-to-int p1, v1

    :try_start_0
    const/4 v6, 0x6

    invoke-virtual {p2, p1}, Landroid/hardware/Camera$Parameters;->setExposureCompensation(I)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo v1, "tc aobeverps:iomnps euxt cnpssoe"

    const-string/jumbo v1, "rsspooeve pp  ctcixnua noets:mes"

    const/4 v6, 0x1

    const-string/jumbo v1, "nccepeupm: nouttees ioxasv  saor"

    const-string/jumbo v1, "vcap: set exposure compensation "

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 p1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    return p1

    :catch_0
    move-exception p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string p2, "aooecespe xtpuaeaipeonpcdnmt lsvfsi:r "

    const-string/jumbo p2, "vcap: set exposure compensation failed"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v0, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    return v2
.end method

.method doSetExposureMode(ILandroid/hardware/Camera$Parameters;)I
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v1, -0x1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-ne p1, v1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    return v0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p2}, Landroid/hardware/Camera$Parameters;->isAutoExposureLockSupported()Z

    move-result v2

    const/4 v7, 0x1

    const-string/jumbo v3, "pcva"

    const-string v3, "acvp"

    const/4 v7, 0x3

    const-string/jumbo v3, "vcap"

    const-string/jumbo v3, "vcap"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-nez v2, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string p1, " sotoltsqcevckaodm ouoxp enep t:urr ua"

    const-string/jumbo p1, "kepmso os:utaux  cnrcpd pt revaeouoolt"

    const/4 v7, 0x0

    const-string/jumbo p1, "vcap: auto exposure lock not supported"

    const/4 v6, 0x5

    shr-int/2addr v7, v6

    invoke-static {v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    return v1

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {v1}, Lcom/zego/ve/VCam;->access$708(Lcom/zego/ve/VCam;)I

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v1, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x6

    if-eqz p1, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v2, 0x5

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eq p1, v2, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-ne p1, v1, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    goto :goto_0

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v2, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-ne p1, v2, :cond_4

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p2, v2}, Landroid/hardware/Camera$Parameters;->setAutoExposureLock(Z)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    goto :goto_1

    :cond_3
    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-virtual {p2, v0}, Landroid/hardware/Camera$Parameters;->setAutoExposureLock(Z)V

    :cond_4
    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const-string v4, "eespm eeto:r ocsdsuop vx"

    const-string/jumbo v4, "peuro:vtdce x osmaes oep"

    const/4 v7, 0x1

    const-string/jumbo v4, "vcap: set exposure mode "

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v3, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x1

    if-ne p1, v1, :cond_5

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {}, Landroid/os/Message;->obtain()Landroid/os/Message;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    iput v0, p1, Landroid/os/Message;->what:I

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v1}, Lcom/zego/ve/VCam;->access$700(Lcom/zego/ve/VCam;)I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    iput-object v1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v1}, Lcom/zego/ve/VCam;->access$900(Lcom/zego/ve/VCam;)Landroid/os/Handler;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-wide/16 v4, 0xc8

    const-wide/16 v4, 0xc8

    const/4 v7, 0x3

    const-wide/16 v4, 0xc8

    const-wide/16 v4, 0xc8

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v1, p1, v4, v5}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_2

    :catch_0
    move-exception p1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v1, "epomdexcie:fv  absduot rpleaem"

    const-string v1, "aeuvebaexe ls:roo d cpdsetifpm"

    const/4 v7, 0x2

    const-string v1, "aamsovese fo e: cretx doilppdu"

    const-string/jumbo v1, "vcap: set exposure mode failed"

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_5
    :goto_2
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget p1, p1, Lcom/zego/ve/VCam;->mExposureCompensation:F

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/zego/ve/VCam$CamDevice;->doSetExposureCompensation(FLandroid/hardware/Camera$Parameters;)I

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    return v0
.end method

.method doSetExposurePoint(FFLandroid/hardware/Camera$Parameters;)I
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p3}, Landroid/hardware/Camera$Parameters;->getMaxNumMeteringAreas()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v1, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v2, "cvpa"

    const-string/jumbo v2, "pvca"

    const/4 v5, 0x5

    const-string/jumbo v2, "vacp"

    const-string/jumbo v2, "vcap"

    const/4 v5, 0x4

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string p1, "an aeruspp atess teeppoo:red tuxrovs c"

    const/4 v5, 0x6

    const-string p1, "erspsboanttced  xvu pr:pastpro eouae s"

    const-string/jumbo p1, "vcap: set exposure areas not supported"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x3

    return v1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {p0, p1, p2}, Lcom/zego/ve/VCam$CamDevice;->calculateArea(FF)Landroid/graphics/Rect;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance p2, Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance v0, Landroid/hardware/Camera$Area;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/16 v3, 0x320

    const/4 v5, 0x5

    const/4 v4, 0x0

    invoke-direct {v0, p1, v3}, Landroid/hardware/Camera$Area;-><init>(Landroid/graphics/Rect;I)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-interface {p2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p3, p2}, Landroid/hardware/Camera$Parameters;->setMeteringAreas(Ljava/util/List;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const-string/jumbo p3, "paparruovee:e  caupxe ss"

    const-string p3, " rxao ppes  uce:earapsve"

    const/4 v5, 0x0

    const-string p3, "  eopeaperexstaupa v rsc"

    const-string/jumbo p3, "vcap: set exposure area "

    const/4 v5, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/graphics/Rect;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x4

    const/4 p1, 0x3

    const/4 v5, 0x1

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    return p1

    :catch_0
    move-exception p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo p2, "ovaee:saqxsurcaea qp etelidfpr "

    const-string p2, "a: e airqs laeetspcfovrpxuesade"

    const/4 v5, 0x3

    const-string/jumbo p2, "odsreafctaa  eu:lpve saixs eerp"

    const-string/jumbo p2, "vcap: set exposure areas failed"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v2, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v1
.end method

.method doSetFocusMode(ILandroid/hardware/Camera$Parameters;)I
    .locals 10

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string v0, "crmms"

    const-string/jumbo v0, "mrsco"

    const/4 v9, 0x4

    const-string v0, "aomro"

    const-string/jumbo v0, "macro"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string/jumbo v1, "otua"

    const-string/jumbo v1, "otau"

    const/4 v9, 0x5

    const-string/jumbo v1, "oatu"

    const-string v1, "auto"

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 v2, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eqz p1, :cond_5

    const/4 v9, 0x3

    if-eq p1, v2, :cond_4

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v3, 0x2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eq p1, v3, :cond_3

    const/4 v8, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v3, 0x3

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eq p1, v3, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    const/4 v3, 0x4

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-eq p1, v3, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v3, 0x5

    shr-int/2addr v9, v3

    const/4 v8, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-eq p1, v3, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/16 v3, 0x8

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eq p1, v3, :cond_5

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string p1, "-oumnriecucsptntou"

    const/4 v9, 0x5

    const-string p1, "continuous-picture"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    goto :goto_0

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-string/jumbo p1, "tuouobosicn-nedo"

    const-string p1, "cneoooudiuins-to"

    const-string/jumbo p1, "vtunosue-incooui"

    const-string p1, "continuous-video"

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    goto :goto_0

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-string p1, "deof"

    const-string/jumbo p1, "fode"

    const-string p1, "edof"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    goto :goto_0

    :cond_2
    const/4 v9, 0x5

    const-string p1, "ebpix"

    const-string p1, "bedxi"

    const/4 v9, 0x5

    const-string/jumbo p1, "xieqf"

    const-string/jumbo p1, "fixed"

    const/4 v9, 0x2

    const/4 v8, 0x6

    goto :goto_0

    :cond_3
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_0

    :cond_4
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string/jumbo p1, "yisntuni"

    const-string/jumbo p1, "itininuy"

    const/4 v9, 0x7

    const-string/jumbo p1, "iitmifny"

    const-string/jumbo p1, "infinity"

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    goto :goto_0

    :cond_5
    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {p2}, Landroid/hardware/Camera$Parameters;->getSupportedFocusModes()Ljava/util/List;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v4, 0x0

    const/4 v8, 0x2

    move v9, v8

    const-string v5, "apvc"

    const-string v5, "apvc"

    const/4 v9, 0x0

    const-string v5, "acpv"

    const-string/jumbo v5, "vcap"

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz v3, :cond_7

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-interface {v3, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v6

    const/4 v9, 0x0

    const/4 v8, 0x6

    if-eqz v6, :cond_6

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p2, p1}, Landroid/hardware/Camera$Parameters;->setFocusMode(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string v7, "cc eo  uaos:pmfodtv e"

    const-string v7, " uodc:epfatmo   spvce"

    const/4 v9, 0x5

    const-string v7, "ceptub:s ocesv  o mad"

    const-string/jumbo v7, "vcap: set focus mode "

    const/4 v8, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {v5, v6}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x2

    move v9, v8

    goto :goto_1

    :catch_0
    move-exception v6

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string v7, "ealeuff:qdmvpice osct soda "

    const/4 v9, 0x7

    const-string/jumbo v7, "metivfuleusc :o  deaodfpac "

    const-string/jumbo v7, "vcap: set focus mode failed"

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {v5, v7}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v6}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    move v6, v2

    move v6, v2

    const/4 v9, 0x7

    move v6, v2

    move v6, v2

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    goto :goto_2

    :cond_6
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    move v6, v4

    move v6, v4

    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x1

    if-nez v6, :cond_8

    const/4 v9, 0x6

    const/4 v8, 0x1

    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    check-cast p1, Ljava/lang/String;

    :try_start_1
    const/4 v9, 0x6

    const/4 v8, 0x7

    invoke-virtual {p2, p1}, Landroid/hardware/Camera$Parameters;->setFocusMode(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-string v3, "ccfo vlplp ca:e m asuaokfd"

    const-string/jumbo v3, "vcap: fallback focus mode "

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-static {v5, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    goto :goto_3

    :catch_1
    move-exception p2

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string v3, "afeipc aqascoc sl: fodvfb lldekm"

    const-string v3, "alscuic oscad  ffeka :llbpomdefv"

    const/4 v9, 0x2

    const-string/jumbo v3, "vcap: fallback focus mode failed"

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {v5, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {p2}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_3
    const/4 v8, 0x3

    move v9, v8

    move v6, v2

    move v6, v2

    const/4 v9, 0x0

    move v6, v2

    move v6, v2

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    goto :goto_4

    :cond_7
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    move v6, v4

    move v6, v4

    :cond_8
    :goto_4
    const/4 v9, 0x0

    if-nez v6, :cond_9

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    const-string/jumbo p1, "u smc aet seftlvesdfmp:n oc"

    const-string/jumbo p1, "mcsm neudveoct s lutaf: pfe"

    const/4 v9, 0x7

    const-string p1, "  um:e ucapfs tnmsdolfeceov"

    const-string/jumbo p1, "vcap: focus mode left unset"

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {v5, p1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 p1, -0x1

    const/4 v8, 0x7

    or-int/2addr v9, v8

    return p1

    :cond_9
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-eq p1, v1, :cond_b

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-ne p1, v0, :cond_a

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    goto :goto_5

    :cond_a
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    move v2, v4

    const/4 v9, 0x7

    move v2, v4

    move v2, v4

    :cond_b
    :goto_5
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    return v2
.end method

.method doSetFocusPoint(FFLandroid/hardware/Camera$Parameters;)I
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p3}, Landroid/hardware/Camera$Parameters;->getMaxNumFocusAreas()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v1, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v2, "pvca"

    const-string/jumbo v2, "vacp"

    const/4 v5, 0x7

    const-string v2, "cvap"

    const-string/jumbo v2, "vcap"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo p1, "ospsod nteeopseo  ausro a:tcfrvt au"

    const-string p1, "a:opocstdsau sneesreupfoo  a prt vt"

    const/4 v5, 0x5

    const-string/jumbo p1, "tdpspb  ofeessorv craau:eutn atopc "

    const-string/jumbo p1, "vcap: set focus areas not supported"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {p0, p1, p2}, Lcom/zego/ve/VCam$CamDevice;->calculateArea(FF)Landroid/graphics/Rect;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance p2, Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v0, Landroid/hardware/Camera$Area;

    const/4 v5, 0x0

    const/16 v3, 0x320

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v0, p1, v3}, Landroid/hardware/Camera$Area;-><init>(Landroid/graphics/Rect;I)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {p2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p3, p2}, Landroid/hardware/Camera$Parameters;->setFocusAreas(Ljava/util/List;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string p3, "aapb eu :fcaoss cutv "

    const-string/jumbo p3, "sc uabpa rca:oe fst v"

    const/4 v5, 0x3

    const-string p3, "  afec:pastpcvur  ase"

    const-string/jumbo p3, "vcap: set focus area "

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/graphics/Rect;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 p1, 0x0

    move v5, p1

    move v4, p1

    move v4, p1

    const/4 v5, 0x5

    return p1

    :catch_0
    move-exception p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo p2, "uavdiftaqe oprae  cfsuel:sa "

    const-string p2, " us vfua:tsoaa cepeielsrfad "

    const/4 v5, 0x5

    const-string/jumbo p2, "rlsuf:s vssea caeo pfi atcda"

    const-string/jumbo p2, "vcap: set focus areas failed"

    const/4 v5, 0x4

    invoke-static {v2, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v1
.end method

.method getMaxZoomRatio()I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v4, 0x2

    const/16 v1, 0x64

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    return v1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->isZoomSupported()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-nez v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->getZoomRatios()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    return v1

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-virtual {v1}, Landroid/hardware/Camera$Parameters;->getMaxZoom()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    check-cast v0, Ljava/lang/Integer;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    return v0
.end method

.method getOrientation()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCamInfo:Landroid/hardware/Camera$CameraInfo;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, v0, Landroid/hardware/Camera$CameraInfo;->orientation:I

    const/4 v2, 0x2

    return v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method handleExposureMode(I)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget p1, p1, Lcom/zego/ve/VCam;->mExposureMode:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/zego/ve/VCam$CamDevice;->doSetExposureMode(ILandroid/hardware/Camera$Parameters;)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p1
.end method

.method isFocusSupported()Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->getSupportedFocusModes()Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string v3, "aout"

    const-string/jumbo v3, "otau"

    const/4 v5, 0x0

    const-string/jumbo v3, "toau"

    const-string v3, "auto"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-interface {v0, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x5

    if-nez v3, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v3, "dcpm-utsiouvonni"

    const-string v3, "dvcsuitpon-onieu"

    const/4 v5, 0x4

    const-string/jumbo v3, "snt-oinovueciouo"

    const-string v3, "continuous-video"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {v0, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x1

    if-nez v3, :cond_1

    const/4 v4, 0x5

    move v5, v4

    const-string v3, "-oconbstitecuriqpu"

    const-string v3, "cpooutn-qiuitecsru"

    const/4 v5, 0x4

    const-string v3, "continuous-picture"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {v0, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v0, :cond_2

    :cond_1
    const/4 v5, 0x3

    move v0, v2

    move v0, v2

    const/4 v5, 0x2

    move v0, v2

    move v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    move v0, v1

    move v0, v1

    const/4 v5, 0x7

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-nez v0, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    return v0

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->getMaxNumFocusAreas()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-lez v0, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    move v1, v2

    const/4 v5, 0x7

    move v1, v2

    move v1, v2

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v1
.end method

.method public onPreviewFrame([BLandroid/hardware/Camera;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/zego/ve/VCam;->access$1000(Lcom/zego/ve/VCam;)Ljava/util/Set;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/zego/ve/VCam;->access$1200(Lcom/zego/ve/VCam;)J

    move-result-wide v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v2, v2, Lcom/zego/ve/VCam;->mFrameRate:I

    const/4 v4, 0x5

    invoke-static {v0, v1, p1, v2}, Lcom/zego/ve/VCam;->access$1300(J[BI)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Landroid/hardware/Camera;->addCallbackBuffer([B)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-void
.end method

.method openTorch()I
    .locals 7

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-nez v0, :cond_0

    const/4 v6, 0x6

    const/4 v0, 0x0

    const/4 v6, 0x0

    const/4 v0, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    return v0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->getFlashMode()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/hardware/Camera$Parameters;->getSupportedFlashModes()Ljava/util/List;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v2, "rusoh"

    const-string/jumbo v2, "ocsrh"

    const/4 v6, 0x6

    const-string/jumbo v2, "hcprt"

    const-string/jumbo v2, "torch"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {v1, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string v3, "cpav"

    const-string/jumbo v3, "vapc"

    const/4 v6, 0x1

    const-string/jumbo v3, "pvca"

    const-string/jumbo v3, "vcap"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-nez v0, :cond_1

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, v2}, Landroid/hardware/Camera$Parameters;->setFlashMode(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v1, "almi tesqda: flfmdsch ea eo"

    const-string v1, " temvcef ls:laa  ohfsdimaed"

    const/4 v6, 0x4

    const-string/jumbo v1, "fes:ea isdtf dh amov alleps"

    const-string/jumbo v1, "vcap: set flash mode failed"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v0, 0x1

    const/4 v5, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    goto :goto_1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    move v0, v4

    move v0, v4

    const/4 v6, 0x4

    move v0, v4

    move v0, v4

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez v0, :cond_2

    const/4 v6, 0x3

    const-string/jumbo v0, "ot m:mtl nacedcuhv  pp:aeve lfoas"

    const-string v0, "aph oevmcnltlp ou  aedas fe:ctvs:"

    const/4 v6, 0x2

    const-string/jumbo v0, "uocfon ap:c ttes  lf aadm:evpeshv"

    const-string/jumbo v0, "vcap: vcap: flash mode left unset"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    return v4

    :cond_2
    :try_start_1
    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v6, 0x3

    const/4 v5, 0x0

    goto :goto_2

    :catch_1
    move-exception v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const-string/jumbo v1, "rdtnobrhiaepeaa or tms rerasa: x-et-c tcsewmrea seifpo pelmeh t bv"

    const-string/jumbo v1, "sos- b :t exlv pftedie m sommr arceaa-a ctatn secohahieetprerrrpew"

    const/4 v6, 0x7

    const-string v1, " :pveouttedt e t mam crarmlcp o  preasnrroehri-teiee faecsx-hwaass"

    const-string/jumbo v1, "vcap: set flash mode -- set camera parameters error with exception"

    const/4 v5, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_2
    const/4 v5, 0x1

    move v6, v5

    return v4
.end method

.method releaseCam()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/hardware/Camera;->release()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    iput-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mCamInfo:Landroid/hardware/Camera$CameraInfo;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    return v0
.end method

.method setExposureCompensation(F)I
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    return v1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/zego/ve/VCam$CamDevice;->doSetExposureCompensation(FLandroid/hardware/Camera$Parameters;)I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz p1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    return v1

    :cond_1
    :try_start_0
    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v4, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 p1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    return p1

    :catch_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v0, "avpc"

    const-string/jumbo v0, "pacv"

    const/4 v4, 0x4

    const-string/jumbo v0, "vacp"

    const-string/jumbo v0, "vcap"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v2, "mxe r:ephtc saseet oasprecpeerpst w npvetiuoona excrtr cmr-tniimu- oepasoaar "

    const-string/jumbo v2, "seretwueoitapevotntemr nrsa mc-eraotp sesrceexaex  r-pntipuio a m phc:oesrac "

    const/4 v4, 0x6

    const-string v2, "aroao pcqeae pnst tseurtmrreoi-wsxer eo emo rhtrte ta :xppaim-n asvccnsciee p"

    const-string/jumbo v2, "vcap: set exposure compensation -- set camera parameters error with exception"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    return v1
.end method

.method setExposureMode(I)I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v0, -0x1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    return v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget p1, p1, Lcom/zego/ve/VCam;->mExposureMode:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0, p1, v1}, Lcom/zego/ve/VCam$CamDevice;->doSetExposureMode(ILandroid/hardware/Camera$Parameters;)I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz p1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    return v0

    :cond_1
    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1, v1}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    return p1

    :catch_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const-string/jumbo v1, "pcva"

    const-string/jumbo v1, "vcap"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v2, "p-suae rrmexpae rtr -er mm oeteo ncchortsetipiedaaewoep  sr vt:es xas"

    const-string/jumbo v2, "vcap: set exposure mode -- set camera parameters error with exception"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    return v0
.end method

.method setExposurePoint(FF)I
    .locals 5

    const/4 v3, 0x7

    move v4, v3

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const-string v2, "avcp"

    const-string/jumbo v2, "vcap"

    const/4 v4, 0x7

    const-string v2, "apvc"

    const-string/jumbo v2, "vcap"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-boolean v0, v0, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0, p1, p2, v0}, Lcom/zego/ve/VCam$CamDevice;->doSetExposurePoint(FFLandroid/hardware/Camera$Parameters;)I

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object p2, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1, p2}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    return p1

    :catch_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo p2, "mtemrosc t ait- paspehreceraxaoe er  pn oecpreepm-o t :e wxiarnsptivus"

    const-string p2, "-ee phep otmsetaare o crpwma-ierc uspteseisnx ro  torcnativap tee r:xp"

    const-string/jumbo p2, "icntoape o ior xcteem ai oru e-ttt eeeacpesapxsam-hprrsrws :nrot p evr"

    const-string/jumbo p2, "vcap: set exposure point -- set camera parameters error with exception"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v2, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    return v1

    :cond_1
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo p1, "xsnr bqo se piitp-kcot eespu-v:p"

    const-string/jumbo p1, "tueopsksqet:p-r -v sei ipncpox  "

    const/4 v4, 0x6

    const-string/jumbo p1, "vcap: set exposure point -- skip"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    return v1
.end method

.method setFocusMode(I)I
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v0, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-nez p1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    return v0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/hardware/Camera;->cancelAutoFocus()V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget p1, p1, Lcom/zego/ve/VCam;->mFocusMode:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0, p1, v1}, Lcom/zego/ve/VCam$CamDevice;->doSetFocusMode(ILandroid/hardware/Camera$Parameters;)I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-ltz p1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-boolean v2, v1, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v2, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget v2, v1, Lcom/zego/ve/VCam;->mFocusPointX:F

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget v1, v1, Lcom/zego/ve/VCam;->mFocusPointY:F

    const/4 v5, 0x0

    const/4 v4, 0x3

    iget-object v3, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0, v2, v1, v3}, Lcom/zego/ve/VCam$CamDevice;->doSetFocusPoint(FFLandroid/hardware/Camera$Parameters;)I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1}, Landroid/hardware/Camera$Parameters;->getMaxNumFocusAreas()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-lez v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Landroid/hardware/Camera$Parameters;->setFocusAreas(Ljava/util/List;)V

    :cond_2
    :goto_0
    :try_start_0
    const/4 v5, 0x2

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    if-lez p1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput-boolean v0, p1, Lcom/zego/ve/VCam;->mIsFocusing:Z

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance v0, Lcom/zego/ve/VCam$CamDevice$3;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {v0, p0}, Lcom/zego/ve/VCam$CamDevice$3;-><init>(Lcom/zego/ve/VCam$CamDevice;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Landroid/hardware/Camera;->autoFocus(Landroid/hardware/Camera$AutoFocusCallback;)V

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    return p1

    :catch_0
    move-exception p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v1, "vacp"

    const-string/jumbo v1, "pacv"

    const-string/jumbo v1, "vcap"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v2, "spexrmutis nemaeesoct sarr-: -eotut cpeeerarwefhav  riopcscatdm o "

    const-string/jumbo v2, "r seca:urietcmfstvtwrcitxd aoa -h     om percaser-eooampterenespse"

    const/4 v5, 0x1

    const-string/jumbo v2, "vcap: set focus mode -- set camera parameters error with exception"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    return v0
.end method

.method setFocusPoint(FF)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    if-eqz p1, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    iget-boolean p2, p1, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    if-nez p2, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    iget-boolean p2, p1, Lcom/zego/ve/VCam;->mIsFocusing:Z

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    if-eqz p2, :cond_0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    iget p1, p1, Lcom/zego/ve/VCam;->mFocusMode:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/zego/ve/VCam$CamDevice;->setFocusMode(I)I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p1

    :cond_1
    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p1, -0x1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p1
.end method

.method setImageReader(Landroid/media/ImageReader;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return p1
.end method

.method setRate(I)I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/zego/ve/VCam$CamDevice;->updateRate(ILandroid/hardware/Camera$Parameters;)I

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v0, "vcap"

    const-string/jumbo v0, "pvac"

    const/4 v3, 0x0

    const-string/jumbo v0, "pacv"

    const-string/jumbo v0, "vcap"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string/jumbo v1, "h cts rp-cemtucn ropempeaprpeax-t r arwes teisrp im:ede voaafa"

    const-string v1, "erdmrespv-erxoic ptcpctetaeaarauneriat m rp fpts- :owmseh e  a"

    const/4 v3, 0x0

    const-string/jumbo v1, "vcap: update fps -- set camera parameters error with exception"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return p1
.end method

.method setSurfaceTexture(Landroid/graphics/SurfaceTexture;)I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return v1

    :cond_0
    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Landroid/hardware/Camera;->setPreviewTexture(Landroid/graphics/SurfaceTexture;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    return p1

    :catch_0
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    return v1
.end method

.method setZoomFactor(F)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v4, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->isZoomSupported()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-nez v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x5

    move v4, v3

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->getZoomRatios()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-nez v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/high16 v1, 0x42c80000    # 100.0f

    const/4 v4, 0x3

    mul-float/2addr p1, v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    float-to-int p1, p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/16 v1, 0x64

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eq p1, v1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x1

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-ge v1, v2, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    check-cast v2, Ljava/lang/Integer;

    const/4 v4, 0x5

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-lt v2, p1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_1

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x0

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1, v1}, Landroid/hardware/Camera$Parameters;->setZoom(I)V

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_2

    :catch_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const-string v0, "apcv"

    const-string v0, "capv"

    const/4 v4, 0x3

    const-string/jumbo v0, "vapc"

    const-string/jumbo v0, "vcap"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo v1, "se feip:qoac  dtolovz"

    const-string v1, "e  so:fzooiatlmvedpc "

    const/4 v4, 0x6

    const-string v1, "afscive mdtploa :ezos"

    const-string/jumbo v1, "vcap: set zoom failed"

    const/4 v4, 0x6

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_2
    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void
.end method

.method startCam(Z)I
    .locals 12

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string v0, " oemcmseedn stvca :eb"

    const-string v0, "coesnbc:tvese  pea dm"

    const/4 v11, 0x0

    const-string v0, "assvoopedme ete:cc   "

    const-string/jumbo v0, "vcap: set scene mode "

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string/jumbo v1, "tafuabe cid odmec: ep senel"

    const-string v1, " apaieune:ccl ofeets dm sed"

    const/4 v11, 0x7

    const-string v1, "ensls u oepmiteeaae :dcdvfc"

    const-string/jumbo v1, "vcap: set scene mode failed"

    const/4 v10, 0x4

    const/4 v11, 0x5

    iget-object v2, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v2}, Lcom/zego/ve/VCam;->getFront()I

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x5

    const/4 v3, 0x1

    const/4 v10, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    const/4 v4, 0x0

    const/4 v11, 0x1

    if-lez v2, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x6

    move v2, v3

    move v2, v3

    const/4 v11, 0x1

    move v2, v3

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    goto :goto_0

    :cond_0
    const/4 v11, 0x2

    const/4 v10, 0x3

    move v2, v4

    const/4 v11, 0x7

    move v2, v4

    move v2, v4

    :goto_0
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget-object v5, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v11, 0x5

    if-eqz v2, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x4

    if-eqz p1, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {p1}, Landroid/hardware/Camera$Parameters;->getMaxNumDetectedFaces()I

    move-result p1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    if-lez p1, :cond_1

    const/4 v11, 0x3

    const/4 v10, 0x0

    move p1, v3

    move p1, v3

    move p1, v3

    move p1, v3

    const/4 v10, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    goto :goto_1

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    move p1, v4

    move p1, v4

    const/4 v11, 0x4

    move p1, v4

    move p1, v4

    :goto_1
    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    iput-boolean p1, v5, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    iget p1, p1, Lcom/zego/ve/VCam;->mSceneMode:I

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    const-string/jumbo v5, "pvca"

    const-string/jumbo v5, "pacv"

    const/4 v11, 0x5

    const-string/jumbo v5, "pvac"

    const-string/jumbo v5, "vcap"

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x4

    if-eqz p1, :cond_8

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v11, 0x5

    invoke-virtual {p1}, Landroid/hardware/Camera$Parameters;->getSupportedSceneModes()Ljava/util/List;

    move-result-object p1

    const/4 v11, 0x3

    const/4 v10, 0x6

    if-eqz p1, :cond_8

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    iget-object v6, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    iget v6, v6, Lcom/zego/ve/VCam;->mSceneMode:I

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    const-string/jumbo v7, "otau"

    const-string/jumbo v7, "utoa"

    const/4 v11, 0x5

    const-string/jumbo v7, "utoa"

    const-string v7, "auto"

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-string/jumbo v8, "ptpgn"

    const-string/jumbo v8, "ngpit"

    const/4 v11, 0x5

    const-string/jumbo v8, "hgtqn"

    const-string/jumbo v8, "night"

    const/4 v11, 0x4

    const/4 v10, 0x7

    if-ne v3, v6, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    const-string v2, "arpqy"

    const/4 v11, 0x5

    const-string v2, "atsyr"

    const-string/jumbo v2, "party"

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-interface {p1, v2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v6

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-eqz v6, :cond_2

    move-object v8, v2

    move-object v8, v2

    move-object v8, v2

    move-object v8, v2

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x2

    goto/16 :goto_2

    :cond_2
    const/4 v11, 0x3

    invoke-interface {p1, v8}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    if-eqz v2, :cond_7

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x0

    goto/16 :goto_2

    :cond_3
    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v9, 0x2

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-ne v9, v6, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-interface {p1, v8}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v11, 0x4

    const/4 v10, 0x5

    if-eqz v2, :cond_7

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x2

    goto :goto_2

    :cond_4
    if-eqz v2, :cond_5

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v8, 0x4

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x6

    if-ne v8, v6, :cond_5

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string/jumbo v8, "toamprsi"

    const-string v8, "apsirtro"

    const-string v8, "atrtoiop"

    const-string/jumbo v8, "portrait"

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-interface {p1, v8}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-eqz v2, :cond_7

    const/4 v11, 0x0

    const/4 v10, 0x6

    goto :goto_2

    :cond_5
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    if-nez v2, :cond_7

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    const/4 v2, 0x3

    const/4 v11, 0x1

    const/4 v10, 0x0

    if-ne v2, v6, :cond_7

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string/jumbo v8, "ontiab"

    const-string/jumbo v8, "ntamoi"

    const/4 v11, 0x3

    const-string/jumbo v8, "uoatni"

    const-string v8, "action"

    const/4 v11, 0x4

    const/4 v10, 0x3

    invoke-interface {p1, v8}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-eqz v2, :cond_6

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    goto :goto_2

    :cond_6
    const/4 v11, 0x3

    const-string/jumbo v8, "rptoso"

    const-string/jumbo v8, "postor"

    const/4 v11, 0x0

    const-string/jumbo v8, "srqops"

    const-string/jumbo v8, "sports"

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-interface {p1, v8}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-eqz v2, :cond_7

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    goto :goto_2

    :cond_7
    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    :goto_2
    :try_start_0
    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    iget-object v2, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v2, v8}, Landroid/hardware/Camera$Parameters;->setSceneMode(Ljava/lang/String;)V

    const/4 v11, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static {v5, v2}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x2

    move v2, v3

    move v2, v3

    const/4 v11, 0x4

    move v2, v3

    move v2, v3

    move-object v7, v8

    move-object v7, v8

    move-object v7, v8

    move-object v7, v8

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    goto :goto_3

    :catch_0
    move-exception v2

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {v5, v1}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x3

    move v2, v4

    move v2, v4

    const/4 v11, 0x7

    move v2, v4

    move v2, v4

    :goto_3
    const/4 v10, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-nez v2, :cond_8

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-interface {p1, v7}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x0

    if-eqz p1, :cond_8

    :try_start_1
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {p1, v7}, Landroid/hardware/Camera$Parameters;->setSceneMode(Ljava/lang/String;)V

    const/4 v11, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {p1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {v5, p1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    goto :goto_4

    :catch_1
    move-exception p1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-static {v5, v1}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_8
    :goto_4
    const/4 v11, 0x0

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    iput-boolean v4, p1, Lcom/zego/ve/VCam;->mIsFocusing:Z

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {p1, p0}, Landroid/hardware/Camera;->setPreviewCallbackWithBuffer(Landroid/hardware/Camera$PreviewCallback;)V

    :try_start_2
    const/4 v11, 0x0

    const/4 v10, 0x1

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {p1}, Landroid/hardware/Camera;->startPreview()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {p1}, Landroid/hardware/Camera;->cancelAutoFocus()V

    const/4 v11, 0x5

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget-boolean p1, p1, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-eqz p1, :cond_9

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {p1}, Landroid/hardware/Camera;->startFaceDetection()V

    :cond_9
    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v11, 0x1

    const/4 v10, 0x4

    iget p1, p1, Lcom/zego/ve/VCam;->mFocusMode:I

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x2

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {p0, p1, v0}, Lcom/zego/ve/VCam$CamDevice;->doSetFocusMode(ILandroid/hardware/Camera$Parameters;)I

    move-result p1

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-ltz p1, :cond_a

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x3

    iget-boolean v1, v0, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-nez v1, :cond_b

    const/4 v11, 0x6

    iget v1, v0, Lcom/zego/ve/VCam;->mFocusPointX:F

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    iget v0, v0, Lcom/zego/ve/VCam;->mFocusPointY:F

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    iget-object v2, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {p0, v1, v0, v2}, Lcom/zego/ve/VCam$CamDevice;->doSetFocusPoint(FFLandroid/hardware/Camera$Parameters;)I

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x6

    goto :goto_5

    :cond_a
    const/4 v11, 0x5

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v0}, Landroid/hardware/Camera$Parameters;->getMaxNumFocusAreas()I

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-lez v0, :cond_b

    const/4 v10, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    const/4 v1, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v0, v1}, Landroid/hardware/Camera$Parameters;->setFocusAreas(Ljava/util/List;)V

    :cond_b
    :goto_5
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v10, 0x1

    xor-int/2addr v11, v10

    iget v0, v0, Lcom/zego/ve/VCam;->mExposureMode:I

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p0, v0, v1}, Lcom/zego/ve/VCam$CamDevice;->doSetExposureMode(ILandroid/hardware/Camera$Parameters;)I

    move-result v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    if-nez v0, :cond_c

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget-boolean v1, v0, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v11, 0x6

    if-nez v1, :cond_c

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x6

    iget v1, v0, Lcom/zego/ve/VCam;->mExposurePointX:F

    iget v0, v0, Lcom/zego/ve/VCam;->mExposurePointY:F

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    iget-object v2, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {p0, v1, v0, v2}, Lcom/zego/ve/VCam$CamDevice;->doSetExposurePoint(FFLandroid/hardware/Camera$Parameters;)I

    :cond_c
    :try_start_3
    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v11, 0x3

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->mParams:Landroid/hardware/Camera$Parameters;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v0, v1}, Landroid/hardware/Camera;->setParameters(Landroid/hardware/Camera$Parameters;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x6

    goto :goto_6

    :catch_2
    move-exception v0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    const-string v1, "cssopxfo&d s cbe lrfe tsaa: epuui"

    const-string/jumbo v1, "o p ebxcolps:de e frafuiutssec& a"

    const/4 v11, 0x5

    const-string/jumbo v1, "se m:ec uxsc&ioelfoa pup v easdtr"

    const-string/jumbo v1, "vcap: set focus & exposure failed"

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {v5, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_6
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    if-lez p1, :cond_d

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x4

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x1

    iput-boolean v3, p1, Lcom/zego/ve/VCam;->mIsFocusing:Z

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v11, 0x7

    new-instance v0, Lcom/zego/ve/VCam$CamDevice$1;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-direct {v0, p0}, Lcom/zego/ve/VCam$CamDevice$1;-><init>(Lcom/zego/ve/VCam$CamDevice;)V

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p1, v0}, Landroid/hardware/Camera;->autoFocus(Landroid/hardware/Camera$AutoFocusCallback;)V

    :cond_d
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    return v4

    :catchall_0
    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 p1, -0x1

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    return p1
.end method

.method stopCam()I
    .locals 5

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/zego/ve/VCam;->access$708(Lcom/zego/ve/VCam;)I

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-boolean v1, v1, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/hardware/Camera;->stopFaceDetection()V

    :cond_0
    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/hardware/Camera;->setPreviewCallbackWithBuffer(Landroid/hardware/Camera$PreviewCallback;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice;->mCam:Landroid/hardware/Camera;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/hardware/Camera;->setPreviewTexture(Landroid/graphics/SurfaceTexture;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v1, Lcom/zego/ve/VCam$CamDevice$2;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v1, p0, v0}, Lcom/zego/ve/VCam$CamDevice$2;-><init>(Lcom/zego/ve/VCam$CamDevice;Ljava/util/concurrent/CountDownLatch;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance v2, Ljava/lang/Thread;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v2, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-wide/16 v1, 0x1f4

    const-wide/16 v1, 0x1f4

    const/4 v4, 0x3

    const-wide/16 v1, 0x1f4

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-static {v0, v1, v2}, Lcom/zego/ve/ThreadUtils;->awaitUninterruptibly(Ljava/util/concurrent/CountDownLatch;J)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v0, "vpca"

    const-string/jumbo v0, "vpca"

    const/4 v4, 0x4

    const-string/jumbo v0, "pvca"

    const-string/jumbo v0, "vcap"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v1, " poeotuere t evsimeiort:ucvalesaw"

    const-string/jumbo v1, "urorvmuwep:teetipo iceea tl evssa"

    const/4 v4, 0x5

    const-string/jumbo v1, "roscebelsro:atievaep e p wPvtutmi"

    const-string/jumbo v1, "vcap: stopPreview release timeout"

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v0, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v0, 0x0

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    return v0
.end method

.method updateRate(ILandroid/hardware/Camera$Parameters;)I
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    invoke-virtual/range {p2 .. p2}, Landroid/hardware/Camera$Parameters;->getSupportedPreviewFpsRange()Ljava/util/List;

    move-result-object v2

    const-string/jumbo v3, "vpca"

    const-string v3, "cvap"

    const-string/jumbo v3, "pcav"

    const-string/jumbo v3, "vcap"

    const-string/jumbo v4, "|"

    const-string/jumbo v4, "|"

    const-string/jumbo v4, "|"

    const-string/jumbo v4, "|"

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v2, :cond_12

    iget-object v7, v0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v8, v7, Lcom/zego/ve/VCam;->mFpsMin:I

    const/16 v9, -0x3e8

    if-eq v8, v9, :cond_6

    iget v8, v7, Lcom/zego/ve/VCam;->mFpsMax:I

    if-eq v8, v9, :cond_6

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    move v7, v6

    move v7, v6

    move v7, v6

    move v7, v6

    move v8, v7

    move v8, v7

    move v8, v7

    move v8, v7

    move v9, v8

    move v9, v8

    move v9, v8

    move v9, v8

    move v10, v9

    move v10, v9

    move v10, v9

    move v10, v9

    move v11, v10

    move v11, v10

    move v11, v10

    move v11, v10

    move v12, v11

    move v12, v11

    move v12, v11

    :goto_0
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_10

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, [I

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const-string v15, " capf:usp"

    const-string/jumbo v15, "fps a:mpc"

    const-string/jumbo v15, "fc|p a:ps"

    const-string v15, "cam fps:|"

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v15, v13, v6

    div-int/lit16 v15, v15, 0x3e8

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v15, v13, v5

    div-int/lit16 v15, v15, 0x3e8

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-static {v3, v14}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    aget v14, v13, v6

    iget-object v15, v0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v15, v15, Lcom/zego/ve/VCam;->mFpsMin:I

    sub-int/2addr v14, v15

    invoke-static {v14}, Ljava/lang/Math;->abs(I)I

    move-result v14

    aget v15, v13, v5

    iget-object v5, v0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    iget v5, v5, Lcom/zego/ve/VCam;->mFpsMax:I

    if-lt v15, v5, :cond_2

    if-eqz v7, :cond_1

    if-lt v15, v7, :cond_1

    if-ne v15, v7, :cond_0

    if-lt v14, v12, :cond_1

    :cond_0
    if-ne v15, v7, :cond_5

    if-ne v14, v12, :cond_5

    aget v5, v13, v6

    if-le v5, v9, :cond_5

    :cond_1
    aget v9, v13, v6

    move v12, v14

    move v12, v14

    move v12, v14

    move v12, v14

    move v7, v15

    move v7, v15

    move v7, v15

    move v7, v15

    goto :goto_1

    :cond_2
    if-eqz v8, :cond_4

    if-gt v15, v8, :cond_4

    if-ne v15, v8, :cond_3

    if-lt v14, v11, :cond_4

    :cond_3
    if-ne v15, v8, :cond_5

    if-ne v14, v11, :cond_5

    aget v5, v13, v6

    if-le v5, v10, :cond_5

    :cond_4
    aget v10, v13, v6

    move v11, v14

    move v11, v14

    move v11, v14

    move v11, v14

    move v8, v15

    move v8, v15

    move v8, v15

    move v8, v15

    :cond_5
    :goto_1
    const/4 v5, 0x1

    goto/16 :goto_0

    :cond_6
    iget v5, v7, Lcom/zego/ve/VCam;->mFrameRate:I

    mul-int/lit16 v5, v5, 0x3e8

    iget-boolean v7, v7, Lcom/zego/ve/VCam;->mLowLightBoost:Z

    if-eqz v7, :cond_b

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    move v7, v6

    move v7, v6

    move v7, v6

    move v7, v6

    move v8, v7

    move v8, v7

    move v8, v7

    move v8, v7

    move v9, v8

    move v9, v8

    move v9, v8

    move v10, v9

    move v10, v9

    move v10, v9

    move v10, v9

    :cond_7
    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_10

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, [I

    const/4 v12, 0x1

    aget v13, v11, v12

    if-lt v13, v5, :cond_9

    if-eqz v7, :cond_8

    if-lt v13, v7, :cond_8

    if-ne v13, v7, :cond_7

    aget v12, v11, v6

    if-ge v12, v9, :cond_7

    :cond_8
    aget v9, v11, v6

    move v7, v13

    move v7, v13

    move v7, v13

    move v7, v13

    goto :goto_2

    :cond_9
    if-eqz v8, :cond_a

    if-gt v13, v8, :cond_a

    if-ne v13, v8, :cond_7

    aget v12, v11, v6

    if-ge v12, v10, :cond_7

    :cond_a
    aget v10, v11, v6

    move v8, v13

    move v8, v13

    move v8, v13

    goto :goto_2

    :cond_b
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    move v7, v6

    move v7, v6

    move v7, v6

    move v7, v6

    move v8, v7

    move v8, v7

    move v8, v7

    move v8, v7

    move v9, v8

    move v9, v8

    move v9, v8

    move v9, v8

    move v10, v9

    move v10, v9

    move v10, v9

    move v10, v9

    :cond_c
    :goto_3
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_10

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, [I

    const/4 v12, 0x1

    aget v13, v11, v12

    if-lt v13, v5, :cond_e

    if-eqz v7, :cond_d

    if-lt v13, v7, :cond_d

    if-ne v13, v7, :cond_c

    aget v12, v11, v6

    if-le v12, v9, :cond_c

    :cond_d
    aget v9, v11, v6

    move v7, v13

    move v7, v13

    move v7, v13

    move v7, v13

    goto :goto_3

    :cond_e
    if-eqz v8, :cond_f

    if-gt v13, v8, :cond_f

    if-ne v13, v8, :cond_c

    aget v12, v11, v6

    if-le v12, v10, :cond_c

    :cond_f
    aget v10, v11, v6

    move v8, v13

    move v8, v13

    move v8, v13

    move v8, v13

    goto :goto_3

    :cond_10
    if-eqz v7, :cond_11

    invoke-virtual {v1, v9, v7}, Landroid/hardware/Camera$Parameters;->setPreviewFpsRange(II)V

    goto :goto_4

    :cond_11
    if-eqz v8, :cond_12

    invoke-virtual {v1, v10, v8}, Landroid/hardware/Camera$Parameters;->setPreviewFpsRange(II)V

    :cond_12
    :goto_4
    const/4 v2, 0x2

    new-array v5, v2, [I

    invoke-virtual {v1, v5}, Landroid/hardware/Camera$Parameters;->getPreviewFpsRange([I)V

    aget v1, v5, v6

    const/4 v7, 0x1

    aget v8, v5, v7

    if-ne v1, v8, :cond_13

    iget-object v2, v0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    div-int/lit16 v1, v1, 0x3e8

    iput v1, v2, Lcom/zego/ve/VCam;->mFrameRate:I

    goto :goto_5

    :cond_13
    iget-object v1, v0, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    div-int/2addr v8, v2

    div-int/lit16 v8, v8, 0x3e8

    iput v8, v1, Lcom/zego/ve/VCam;->mFrameRate:I

    :goto_5
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " :prqae|qf"

    const-string/jumbo v2, "l|epa f:qr"

    const-string v2, "aes:prsf |"

    const-string/jumbo v2, "real fps:|"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    aget v2, v5, v6

    div-int/lit16 v2, v2, 0x3e8

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    aget v2, v5, v2

    div-int/lit16 v2, v2, 0x3e8

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return v6
.end method
