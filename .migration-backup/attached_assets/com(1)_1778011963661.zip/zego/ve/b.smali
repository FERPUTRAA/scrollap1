.class public final synthetic Lcom/zego/ve/b;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/media/AudioTrack;I)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~Ms/i@~~@~  s~S~~ u@n.~4riv@@Ky~@~~@b~@@~~~bo ~ l~~@@ @~~~ oo  /f @@  f imod- ~1atl@t@@@o @c b@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Landroid/media/AudioTrack;->setBufferSizeInFrames(I)I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return p0
.end method
