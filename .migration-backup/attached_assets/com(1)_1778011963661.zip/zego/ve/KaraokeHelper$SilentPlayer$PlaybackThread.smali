.class Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;
.super Ljava/lang/Thread;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/KaraokeHelper$SilentPlayer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "PlaybackThread"
.end annotation


# instance fields
.field private isStop:Z

.field final synthetic this$1:Lcom/zego/ve/KaraokeHelper$SilentPlayer;


# direct methods
.method constructor <init>(Lcom/zego/ve/KaraokeHelper$SilentPlayer;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;->this$1:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;->isStop:Z

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public declared-synchronized closeThread()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "y.so@~b@m~4 l@~~ ib@~~~@~ r  oM~@~ n@~ @~ @@@@bi@ /~@@1fK  s@~@v~f~~  -Sa  itdo~t@  /o@u~lo~o~@c"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    monitor-enter p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;->isStop:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    throw v0
.end method

.method public run()V
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;->this$1:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {v0}, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->access$000(Lcom/zego/ve/KaraokeHelper$SilentPlayer;)I

    move-result v0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    iget-object v1, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;->this$1:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-static {v1}, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->access$100(Lcom/zego/ve/KaraokeHelper$SilentPlayer;)I

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x3

    iget-object v2, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;->this$1:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v10, 0x3

    shr-int/2addr v11, v10

    invoke-static {v2}, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->access$200(Lcom/zego/ve/KaraokeHelper$SilentPlayer;)I

    move-result v2

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {v0, v1, v2}, Landroid/media/AudioTrack;->getMinBufferSize(III)I

    move-result v0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-instance v1, Landroid/media/AudioTrack;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    const/4 v4, 0x3

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    iget-object v2, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;->this$1:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-static {v2}, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->access$000(Lcom/zego/ve/KaraokeHelper$SilentPlayer;)I

    move-result v5

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    iget-object v2, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;->this$1:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {v2}, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->access$100(Lcom/zego/ve/KaraokeHelper$SilentPlayer;)I

    move-result v6

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget-object v2, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;->this$1:Lcom/zego/ve/KaraokeHelper$SilentPlayer;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {v2}, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->access$200(Lcom/zego/ve/KaraokeHelper$SilentPlayer;)I

    move-result v7

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    const/4 v9, 0x1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    move v8, v0

    move v8, v0

    const/4 v11, 0x6

    move v8, v0

    move v8, v0

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-direct/range {v3 .. v9}, Landroid/media/AudioTrack;-><init>(IIIIII)V

    const/4 v11, 0x4

    invoke-virtual {v1}, Landroid/media/AudioTrack;->getState()I

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    if-ne v2, v3, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v1}, Landroid/media/AudioTrack;->play()V

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-array v2, v0, [B

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v3, 0x0

    xor-int/2addr v11, v3

    const/4 v10, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    move v4, v3

    move v4, v3

    const/4 v11, 0x1

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    if-ge v4, v0, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    aput-byte v3, v2, v4

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    goto :goto_0

    :cond_0
    :goto_1
    const/4 v11, 0x4

    const/4 v10, 0x3

    iget-boolean v4, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;->isStop:Z

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-nez v4, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {p0}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v4

    const/4 v11, 0x4

    const/4 v10, 0x1

    if-nez v4, :cond_1

    :try_start_0
    const/4 v11, 0x1

    invoke-virtual {v1, v2, v3, v0}, Landroid/media/AudioTrack;->write([BII)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    goto :goto_1

    :catch_0
    move-exception v0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {v1}, Landroid/media/AudioTrack;->stop()V

    const/4 v10, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v1}, Landroid/media/AudioTrack;->flush()V

    :cond_2
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v1}, Landroid/media/AudioTrack;->release()V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    return-void
.end method
