.class Lcom/zego/ve/MediaCodecVideoEncoder$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/MediaCodecVideoEncoder;->release()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/MediaCodecVideoEncoder;

.field final synthetic val$releaseDone:Ljava/util/concurrent/CountDownLatch;


# direct methods
.method constructor <init>(Lcom/zego/ve/MediaCodecVideoEncoder;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoEncoder;

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/zego/ve/MediaCodecVideoEncoder$1;->val$releaseDone:Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ls@@@ab @-dit/@f~K~  @~@ @~~~S@@@~bm u~o  ~~@~tl~~~ /c@~@~fvi~i  b~o oo o~ n~ 4@ @oy@@@1~ .rM@s"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    const-string v0, "dsemEcCrVeedidMaeooodi"

    const-string v0, "desdrdCcMVoneEiiaoeode"

    const/4 v4, 0x2

    const-string v0, "VnicoMeECeoodddeiaorcd"

    const-string v0, "MediaCodecVideoEncoder"

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const-string v1, "enrarbdEavc eeesrJomlnd e aoeslreaah "

    const-string v1, "eeemo  ea anlnesrceaJdvro ltsahdraEre"

    const/4 v4, 0x2

    const-string v1, "eell sunraasheevere EdaJorrdo cateena"

    const-string v1, "Java releaseEncoder on release thread"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoEncoder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/zego/ve/MediaCodecVideoEncoder;->access$100(Lcom/zego/ve/MediaCodecVideoEncoder;)Landroid/media/MediaCodec;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/media/MediaCodec;->stop()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoEncoder;

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/zego/ve/MediaCodecVideoEncoder;->access$100(Lcom/zego/ve/MediaCodecVideoEncoder;)Landroid/media/MediaCodec;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-virtual {v1}, Landroid/media/MediaCodec;->release()V

    const/4 v4, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$1;->this$0:Lcom/zego/ve/MediaCodecVideoEncoder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v1, v2}, Lcom/zego/ve/MediaCodecVideoEncoder;->access$102(Lcom/zego/ve/MediaCodecVideoEncoder;Landroid/media/MediaCodec;)Landroid/media/MediaCodec;

    const-string/jumbo v1, "hleaaenpeedoaenEee tars  dorsronJal o cvee"

    const-string/jumbo v1, "olaroenJe  aneea aeaEselt  evnddosocerhrer"

    const/4 v4, 0x4

    const-string/jumbo v1, "saedEdd qvcseoee e nenarehotalJr lrae rona"

    const-string v1, "Java releaseEncoder on release thread done"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string v2, "easisdni oe eMeldfbelre ecaa"

    const-string v2, "aselebde ee anioerildfe Mdac"

    const/4 v4, 0x6

    const-string v2, "danmdl eeederecarfl i eMioas"

    const-string v2, "Media encoder release failed"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0, v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder$1;->val$releaseDone:Ljava/util/concurrent/CountDownLatch;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method
