.class public Lcom/zego/ve/VTextureViewListener;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/TextureView$SurfaceTextureListener;


# static fields
.field private static final TAG:Ljava/lang/String; = "VTextureViewListener"


# instance fields
.field private final lock:Ljava/lang/Object;

.field private mView:Landroid/view/TextureView;

.field private pthis:J


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/zego/ve/VTextureViewListener;->pthis:J

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/zego/ve/VTextureViewListener;->mView:Landroid/view/TextureView;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/zego/ve/VTextureViewListener;->lock:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method private static native on_surface_texture_changed(JLandroid/graphics/SurfaceTexture;II)I
.end method

.method private static native on_surface_texture_created(JLandroid/graphics/SurfaceTexture;II)I
.end method

.method private static native on_surface_texture_destroyed(JLandroid/graphics/SurfaceTexture;)I
.end method


# virtual methods
.method public isAvailable()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " cs o ~@o@4~o~/ @~ ~sK@o/@ a~~ ~~ ~@@@@mv@ ~o@t@1@~~nfy  @@@l@lbbi~r~~~ ~.~@- iMtdib o  S@f~u~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/ve/VTextureViewListener;->mView:Landroid/view/TextureView;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/view/TextureView;->isAvailable()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public onSurfaceTextureAvailable(Landroid/graphics/SurfaceTexture;II)V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/zego/ve/VTextureViewListener;->lock:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-wide v1, p0, Lcom/zego/ve/VTextureViewListener;->pthis:J

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x6

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    cmp-long v1, v1, v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p1, p2, p3}, Landroid/graphics/SurfaceTexture;->setDefaultBufferSize(II)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-wide v1, p0, Lcom/zego/ve/VTextureViewListener;->pthis:J

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v1, v2, p1, p2, p3}, Lcom/zego/ve/VTextureViewListener;->on_surface_texture_created(JLandroid/graphics/SurfaceTexture;II)I

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    throw p1
.end method

.method public onSurfaceTextureDestroyed(Landroid/graphics/SurfaceTexture;)Z
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/zego/ve/VTextureViewListener;->lock:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-wide v1, p0, Lcom/zego/ve/VTextureViewListener;->pthis:J

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    cmp-long v3, v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v3, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v1, v2, p1}, Lcom/zego/ve/VTextureViewListener;->on_surface_texture_destroyed(JLandroid/graphics/SurfaceTexture;)I

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 p1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    return p1

    :catchall_0
    move-exception p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    throw p1
.end method

.method public onSurfaceTextureSizeChanged(Landroid/graphics/SurfaceTexture;II)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/ve/VTextureViewListener;->lock:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-wide v1, p0, Lcom/zego/ve/VTextureViewListener;->pthis:J

    const/4 v6, 0x7

    const/4 v5, 0x7

    const-wide/16 v3, 0x0

    const/4 v6, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    cmp-long v3, v1, v3

    const/4 v5, 0x1

    move v6, v5

    if-eqz v3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v1, v2, p1, p2, p3}, Lcom/zego/ve/VTextureViewListener;->on_surface_texture_changed(JLandroid/graphics/SurfaceTexture;II)I

    :cond_0
    const/4 v6, 0x5

    monitor-exit v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    throw p1
.end method

.method public onSurfaceTextureUpdated(Landroid/graphics/SurfaceTexture;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public setThis(JLandroid/view/TextureView;)I
    .locals 5

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/zego/ve/VTextureViewListener;->lock:Ljava/lang/Object;

    const/4 v4, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/zego/ve/VTextureViewListener;->mView:Landroid/view/TextureView;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    invoke-virtual {v1}, Landroid/view/TextureView;->getSurfaceTextureListener()Landroid/view/TextureView$SurfaceTextureListener;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/zego/ve/VTextureViewListener;->mView:Landroid/view/TextureView;

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Landroid/view/TextureView;->setSurfaceTextureListener(Landroid/view/TextureView$SurfaceTextureListener;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz p3, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {p3, p0}, Landroid/view/TextureView;->setSurfaceTextureListener(Landroid/view/TextureView$SurfaceTextureListener;)V

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    iput-wide p1, p0, Lcom/zego/ve/VTextureViewListener;->pthis:J

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object p3, p0, Lcom/zego/ve/VTextureViewListener;->mView:Landroid/view/TextureView;

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    return p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    throw p1
.end method
