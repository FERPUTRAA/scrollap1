.class Lcom/zego/ve/MediaCodecVideoEncoder$VImage;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/MediaCodecVideoEncoder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "VImage"
.end annotation


# instance fields
.field private isI420:Z

.field private uBuffer:Ljava/nio/ByteBuffer;

.field private uStride:I

.field private vBuffer:Ljava/nio/ByteBuffer;

.field private vStride:I

.field private yBuffer:Ljava/nio/ByteBuffer;

.field private yStride:I


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/zego/ve/MediaCodecVideoEncoder$1;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-void
.end method

.method static synthetic access$202(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ s@bo@boc@~o @ o@M~ ls~f@~~@ 1@ ~ ot/~ @b@K~ .~ ~ yoi@~  ~@n~af@~4~@ ~~/ir @-l~~mS@ di~@vut @@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->yBuffer:Ljava/nio/ByteBuffer;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$302(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;I)I
    .locals 2

    const/4 v1, 0x6

    iput p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->yStride:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p1
.end method

.method static synthetic access$402(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->uBuffer:Ljava/nio/ByteBuffer;

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-object p1
.end method

.method static synthetic access$502(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->uStride:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic access$602(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->vBuffer:Ljava/nio/ByteBuffer;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic access$702(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;I)I
    .locals 2

    const/4 v1, 0x1

    iput p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->vStride:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p1
.end method

.method static synthetic access$802(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;Z)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->isI420:Z

    const/4 v1, 0x7

    return p1
.end method
