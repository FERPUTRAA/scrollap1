.class final enum Lcom/zego/ve/HwAudioKit$state;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/HwAudioKit;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "state"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/zego/ve/HwAudioKit$state;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/zego/ve/HwAudioKit$state;

.field public static final enum state_audiokit_failed:Lcom/zego/ve/HwAudioKit$state;

.field public static final enum state_audiokit_success:Lcom/zego/ve/HwAudioKit$state;

.field public static final enum state_karaoke_failed:Lcom/zego/ve/HwAudioKit$state;

.field public static final enum state_karaoke_success:Lcom/zego/ve/HwAudioKit$state;

.field public static final enum state_none:Lcom/zego/ve/HwAudioKit$state;


# direct methods
.method static constructor <clinit>()V
    .locals 13

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x2

    new-instance v0, Lcom/zego/ve/HwAudioKit$state;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x2

    const-string/jumbo v1, "t_sonnstae"

    const-string/jumbo v1, "tosaent_en"

    const/4 v12, 0x5

    const-string/jumbo v1, "ot_mntnase"

    const-string/jumbo v1, "state_none"

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x1

    const/4 v2, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-direct {v0, v1, v2}, Lcom/zego/ve/HwAudioKit$state;-><init>(Ljava/lang/String;I)V

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x6

    sput-object v0, Lcom/zego/ve/HwAudioKit$state;->state_none:Lcom/zego/ve/HwAudioKit$state;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x1

    new-instance v1, Lcom/zego/ve/HwAudioKit$state;

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string v3, "deacoiottt_suieamsk_cs"

    const-string v3, "dusmiceco_tias_atsstke"

    const/4 v12, 0x2

    const-string/jumbo v3, "ssiacbads__esteticuokt"

    const-string/jumbo v3, "state_audiokit_success"

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x4

    const/4 v4, 0x1

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-direct {v1, v3, v4}, Lcom/zego/ve/HwAudioKit$state;-><init>(Ljava/lang/String;I)V

    const/4 v11, 0x3

    move v12, v11

    sput-object v1, Lcom/zego/ve/HwAudioKit$state;->state_audiokit_success:Lcom/zego/ve/HwAudioKit$state;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x0

    new-instance v3, Lcom/zego/ve/HwAudioKit$state;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x1

    const-string/jumbo v5, "itddouatkaisiot_elae_"

    const-string v5, "aaefdiu__kuatotdtsiil"

    const-string/jumbo v5, "state_audiokit_failed"

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x2

    const/4 v6, 0x2

    const/4 v11, 0x1

    move v12, v11

    invoke-direct {v3, v5, v6}, Lcom/zego/ve/HwAudioKit$state;-><init>(Ljava/lang/String;I)V

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x6

    sput-object v3, Lcom/zego/ve/HwAudioKit$state;->state_audiokit_failed:Lcom/zego/ve/HwAudioKit$state;

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x7

    new-instance v5, Lcom/zego/ve/HwAudioKit$state;

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x7

    const-string/jumbo v7, "ktcebkapu_ercstessaos"

    const-string v7, "esceabtrkssatseukoca_"

    const/4 v12, 0x4

    const-string v7, "aaorcsasq_uk_stkceees"

    const-string/jumbo v7, "state_karaoke_success"

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    const/4 v8, 0x3

    const/4 v12, 0x6

    const/4 v11, 0x1

    invoke-direct {v5, v7, v8}, Lcom/zego/ve/HwAudioKit$state;-><init>(Ljava/lang/String;I)V

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x3

    sput-object v5, Lcom/zego/ve/HwAudioKit$state;->state_karaoke_success:Lcom/zego/ve/HwAudioKit$state;

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x5

    new-instance v7, Lcom/zego/ve/HwAudioKit$state;

    const/4 v11, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    const-string v9, "_asklietu_eosfatkaed"

    const-string v9, "_klfeouaearits_kdeat"

    const/4 v12, 0x2

    const-string/jumbo v9, "state_karaoke_failed"

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    const/4 v10, 0x4

    const/4 v12, 0x5

    invoke-direct {v7, v9, v10}, Lcom/zego/ve/HwAudioKit$state;-><init>(Ljava/lang/String;I)V

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x7

    sput-object v7, Lcom/zego/ve/HwAudioKit$state;->state_karaoke_failed:Lcom/zego/ve/HwAudioKit$state;

    const/4 v11, 0x3

    const/4 v11, 0x1

    const/4 v9, 0x0

    const/4 v9, 0x5

    new-array v9, v9, [Lcom/zego/ve/HwAudioKit$state;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    aput-object v0, v9, v2

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x6

    aput-object v1, v9, v4

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x4

    aput-object v3, v9, v6

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    aput-object v5, v9, v8

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    aput-object v7, v9, v10

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x3

    sput-object v9, Lcom/zego/ve/HwAudioKit$state;->$VALUES:[Lcom/zego/ve/HwAudioKit$state;

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/zego/ve/HwAudioKit$state;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const-class v0, Lcom/zego/ve/HwAudioKit$state;

    const-class v0, Lcom/zego/ve/HwAudioKit$state;

    const/4 v2, 0x0

    const-class v0, Lcom/zego/ve/HwAudioKit$state;

    const-class v0, Lcom/zego/ve/HwAudioKit$state;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    check-cast p0, Lcom/zego/ve/HwAudioKit$state;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public static values()[Lcom/zego/ve/HwAudioKit$state;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/zego/ve/HwAudioKit$state;->$VALUES:[Lcom/zego/ve/HwAudioKit$state;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, [Lcom/zego/ve/HwAudioKit$state;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast v0, [Lcom/zego/ve/HwAudioKit$state;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method
