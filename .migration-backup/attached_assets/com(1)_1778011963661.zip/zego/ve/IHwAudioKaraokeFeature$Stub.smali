.class public abstract Lcom/zego/ve/IHwAudioKaraokeFeature$Stub;
.super Landroid/os/Binder;

# interfaces
.implements Lcom/zego/ve/IHwAudioKaraokeFeature;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/IHwAudioKaraokeFeature;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/IHwAudioKaraokeFeature$Stub$Proxy;
    }
.end annotation


# static fields
.field private static final DESCRIPTOR:Ljava/lang/String; = "com.huawei.multimedia.audioengine.IHwAudioKaraokeFeature"

.field static final TRANSACTION_enableKaraokeFeature:I = 0x2

.field static final TRANSACTION_getKaraokeLatency:I = 0x3

.field static final TRANSACTION_init:I = 0x5

.field static final TRANSACTION_isKaraokeFeatureSupport:I = 0x1

.field static final TRANSACTION_setParameter:I = 0x4


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const/4 v2, 0x3

    const-string v0, "aasemteomFIreeiikso.adaiid.uAcgo.l.dtmHeuKnhurueiwaaeuow"

    const-string v0, ".asodumicFiKekaAmeuwew.uieodgruelHon.amoai.edIeruatiathi"

    const/4 v2, 0x6

    const-string/jumbo v0, "wk.mHcFInagain.oKmAiammeereeideiati.udouoa.thloduwiuerau"

    const-string v0, "com.huawei.multimedia.audioengine.IHwAudioKaraokeFeature"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Lcom/zego/ve/IHwAudioKaraokeFeature;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ @~o@uS@@~ ~ @o.@K1c@~~ @@~d@~@4@bb ~~M  ~o~io liff   @y@~ ~im~@~n@t~~@t/o a los@ ~~ -r/bv@o@ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, "coameritiFeatIw.lihwueiouaenaourui..eommegmAHdkaKne.dida"

    const/4 v3, 0x4

    const-string v0, "aiadIbmumkwtnKen.HuremaFe.oeluiaow.oteiArdhaeeugiu.odiic"

    const-string v0, "com.huawei.multimedia.audioengine.IHwAudioKaraokeFeature"

    const/4 v2, 0x0

    const/4 v2, 0x0

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    instance-of v1, v0, Lcom/zego/ve/IHwAudioKaraokeFeature;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    check-cast v0, Lcom/zego/ve/IHwAudioKaraokeFeature;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Lcom/zego/ve/IHwAudioKaraokeFeature$Stub$Proxy;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0, p0}, Lcom/zego/ve/IHwAudioKaraokeFeature$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x2

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v4, 0x4

    const-string/jumbo v0, "mkHchau.eowiFeteuoweuiA.itiaaiIa.oeadmKadurnim.oeulodgun"

    const-string v0, "awuloiKA.ieoin.eiwigaim.dIhmuareoeeFouoenueda.kcduatmtHa"

    const/4 v4, 0x5

    const-string v0, ".aaeicmpiAwmadioethHlenKguuitkoeoduaIiamiru.eaFeroud.n.w"

    const-string v0, "com.huawei.multimedia.audioengine.IHwAudioKaraokeFeature"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eq p1, v1, :cond_6

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eq p1, v2, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x3

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eq p1, v2, :cond_3

    const/4 v3, 0x5

    move v4, v3

    const/4 v2, 0x4

    move v4, v2

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eq p1, v2, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v2, 0x5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eq p1, v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const v2, 0x5f4e5446

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eq p1, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    return p1

    :cond_0
    const/4 v4, 0x2

    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    return v1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x6

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-interface {p0, p1}, Lcom/zego/ve/IHwAudioKaraokeFeature;->init(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    return v1

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {p0, p1, p2}, Lcom/zego/ve/IHwAudioKaraokeFeature;->setParameter(Ljava/lang/String;I)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    return v1

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {p0}, Lcom/zego/ve/IHwAudioKaraokeFeature;->getKaraokeLatency()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    return v1

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz p1, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x1

    move p1, v1

    move p1, v1

    const/4 v4, 0x5

    move p1, v1

    move p1, v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :cond_5
    const/4 v3, 0x2

    move v4, v3

    const/4 p1, 0x0

    move v4, p1

    :goto_0
    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {p0, p1}, Lcom/zego/ve/IHwAudioKaraokeFeature;->enableKaraokeFeature(Z)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    return v1

    :cond_6
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {p0}, Lcom/zego/ve/IHwAudioKaraokeFeature;->isKaraokeFeatureSupport()Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    return v1
.end method
