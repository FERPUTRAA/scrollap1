.class Lcom/zego/ve/VCam$Cam2Device;
.super Lcom/zego/ve/VCam$CameraDev;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x15
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/VCam;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "Cam2Device"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;,
        Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;
    }
.end annotation


# instance fields
.field private mCam2Handler:Landroid/os/Handler;

.field private mCam2Thread:Landroid/os/HandlerThread;

.field private mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

.field private mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

.field public mCamDevice:Landroid/hardware/camera2/CameraDevice;

.field private mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

.field private mDevStateCallback:Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;

.field private mImageReader:Landroid/media/ImageReader;

.field private mOpenSem:Ljava/util/concurrent/Semaphore;

.field private mOpened:Z

.field private mSessionStateCallback:Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;

.field private mSurfaceTexture:Landroid/graphics/SurfaceTexture;

.field final synthetic this$0:Lcom/zego/ve/VCam;


# direct methods
.method constructor <init>(Lcom/zego/ve/VCam;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Lcom/zego/ve/VCam$CameraDev;-><init>(Lcom/zego/ve/VCam;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamDevice:Landroid/hardware/camera2/CameraDevice;

    const/4 v3, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v3, 0x1

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Ljava/util/concurrent/Semaphore;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/util/concurrent/Semaphore;-><init>(I)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mOpenSem:Ljava/util/concurrent/Semaphore;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-boolean v1, p0, Lcom/zego/ve/VCam$Cam2Device;->mOpened:Z

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCam2Thread:Landroid/os/HandlerThread;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCam2Handler:Landroid/os/Handler;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mImageReader:Landroid/media/ImageReader;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance p1, Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p1, p0}, Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;-><init>(Lcom/zego/ve/VCam$Cam2Device;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mDevStateCallback:Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;

    const/4 v3, 0x3

    new-instance p1, Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p1, p0}, Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;-><init>(Lcom/zego/ve/VCam$Cam2Device;)V

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mSessionStateCallback:Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method static synthetic access$1402(Lcom/zego/ve/VCam$Cam2Device;Z)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s~~av~@~@.@/f/~~~ ~fl~@oo  ~~~@ ~@b n@@~~~i b@u oSd@  4@c ior ~  M@y t1~ -@oKo~~~@bt@@sm@ i@l~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mOpened:Z

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    return p1
.end method

.method static synthetic access$1500(Lcom/zego/ve/VCam$Cam2Device;)Ljava/util/concurrent/Semaphore;
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/zego/ve/VCam$Cam2Device;->mOpenSem:Ljava/util/concurrent/Semaphore;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$1700(Lcom/zego/ve/VCam$Cam2Device;)Landroid/hardware/camera2/CaptureRequest$Builder;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$1800(Lcom/zego/ve/VCam$Cam2Device;)Landroid/hardware/camera2/CameraCaptureSession;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v1, 0x7

    const/4 v0, 0x2

    return-object p0
.end method

.method static synthetic access$1802(Lcom/zego/ve/VCam$Cam2Device;Landroid/hardware/camera2/CameraCaptureSession;)Landroid/hardware/camera2/CameraCaptureSession;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method private calculateArea2(FF)Landroid/graphics/Rect;
    .locals 11

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v9, 0x6

    shr-int/2addr v10, v9

    add-float/2addr p1, v0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/high16 v1, 0x40000000    # 2.0f

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    div-float/2addr p1, v1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    add-float/2addr p2, v0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    div-float/2addr p2, v1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->SENSOR_INFO_ACTIVE_ARRAY_SIZE:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    check-cast v0, Landroid/graphics/Rect;

    const/4 v10, 0x0

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v1

    const/4 v10, 0x6

    const/4 v9, 0x2

    int-to-float v1, v1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    mul-float/2addr p1, v1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    float-to-int p1, p1

    const/4 v10, 0x2

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    int-to-float v1, v1

    const/4 v9, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    mul-float/2addr p2, v1

    const/4 v10, 0x3

    const/4 v9, 0x2

    float-to-int p2, p2

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    div-int/lit8 v1, v1, 0xa

    const/4 v10, 0x4

    iget-object v2, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    iget v3, v2, Lcom/zego/ve/VCam;->mWidth:I

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    mul-int/2addr v3, v1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    iget v2, v2, Lcom/zego/ve/VCam;->mHeight:I

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    div-int/2addr v3, v2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    new-instance v2, Landroid/graphics/Rect;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    div-int/lit8 v4, v1, 0x2

    const/4 v9, 0x6

    and-int/2addr v10, v9

    sub-int v5, p1, v4

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v6

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    sub-int/2addr v6, v1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/4 v1, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static {v5, v1, v6}, Lcom/zego/ve/VCam;->clamp(III)I

    move-result v5

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    div-int/lit8 v6, v3, 0x2

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    sub-int v7, p2, v6

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v8

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    sub-int/2addr v8, v3

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {v7, v1, v8}, Lcom/zego/ve/VCam;->clamp(III)I

    move-result v3

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    add-int/2addr p1, v4

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v4

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-static {p1, v1, v4}, Lcom/zego/ve/VCam;->clamp(III)I

    move-result p1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    add-int/2addr p2, v6

    const/4 v9, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {p2, v1, v0}, Lcom/zego/ve/VCam;->clamp(III)I

    move-result p2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-direct {v2, v5, v3, p1, p2}, Landroid/graphics/Rect;-><init>(IIII)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    return-object v2
.end method


# virtual methods
.method closeTorch()I
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string/jumbo v0, "vpac"

    const-string/jumbo v0, "pvac"

    const/4 v6, 0x3

    const-string/jumbo v0, "vcap"

    const-string/jumbo v0, "vcap"

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v2, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-nez v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    return v2

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    sget-object v3, Landroid/hardware/camera2/CameraCharacteristics;->FLASH_INFO_AVAILABLE:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v1, v3}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    check-cast v1, Ljava/lang/Boolean;

    const/4 v5, 0x5

    shl-int/2addr v6, v5

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-nez v1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x3

    return v2

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v1, 0x0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    sget-object v3, Landroid/hardware/camera2/CaptureRequest;->FLASH_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v2, v3, v4}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    iget-object v2, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v3}, Landroid/hardware/camera2/CaptureRequest$Builder;->build()Landroid/hardware/camera2/CaptureRequest;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v2, v3, v4, v4}, Landroid/hardware/camera2/CameraCaptureSession;->setRepeatingRequest(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroid/os/Handler;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_0

    :catch_0
    move-exception v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v3, "d tmp vhisms:fea lecf adaso"

    const-string/jumbo v3, "vfsca:ea lts edpoihm f alds"

    const/4 v6, 0x2

    const-string v3, "a eao:vl iedsflm ecoht fpsa"

    const-string/jumbo v3, "vcap: set flash mode failed"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v5, 0x5

    move v6, v5

    move v2, v1

    const/4 v6, 0x7

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-nez v2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string/jumbo v2, "maomhafppfu:vv dee:sll  ec santc "

    const/4 v6, 0x0

    const-string/jumbo v2, "pvldsb:cnfuh t e:soa t  maevlapcf"

    const-string/jumbo v2, "vcap: vcap: flash mode left unset"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x3

    return v1
.end method

.method createCam(I)I
    .locals 9

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamDevice:Landroid/hardware/camera2/CameraDevice;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    if-eqz v0, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    return v1

    :cond_0
    const/4 v8, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCam2Thread:Landroid/os/HandlerThread;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-nez v0, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    new-instance v0, Landroid/os/HandlerThread;

    const/4 v8, 0x2

    const-string/jumbo v2, "rd2actue_om"

    const-string v2, "2eaaotdr_cm"

    const/4 v8, 0x5

    const-string/jumbo v2, "m_arhtape2c"

    const-string v2, "cam2_thread"

    const/4 v8, 0x1

    invoke-direct {v0, v2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCam2Thread:Landroid/os/HandlerThread;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-instance v0, Landroid/os/Handler;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object v2, p0, Lcom/zego/ve/VCam$Cam2Device;->mCam2Thread:Landroid/os/HandlerThread;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v2}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v3, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-direct {v0, v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCam2Handler:Landroid/os/Handler;

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/zego/ve/VCam;->checkPermission()Z

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 v2, -0x1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    const/4 v3, 0x1

    const/4 v8, 0x4

    if-eq v0, v3, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    return v2

    :cond_2
    const/4 v8, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {v0}, Lcom/zego/ve/VCam;->access$1900(Lcom/zego/ve/VCam;)Landroid/content/Context;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string/jumbo v4, "rcqamb"

    const-string v4, "cmearb"

    const/4 v8, 0x1

    const-string/jumbo v4, "mescar"

    const-string v4, "camera"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    check-cast v0, Landroid/hardware/camera2/CameraManager;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    iput-boolean v1, p0, Lcom/zego/ve/VCam$Cam2Device;->mOpened:Z

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-object v4, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v4}, Lcom/zego/ve/VCam;->access$2000(Lcom/zego/ve/VCam;)[Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    aget-object v4, v4, p1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v5, p0, Lcom/zego/ve/VCam$Cam2Device;->mDevStateCallback:Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;

    const/4 v8, 0x3

    const/4 v7, 0x6

    iget-object v6, p0, Lcom/zego/ve/VCam$Cam2Device;->mCam2Handler:Landroid/os/Handler;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v0, v4, v5, v6}, Landroid/hardware/camera2/CameraManager;->openCamera(Ljava/lang/String;Landroid/hardware/camera2/CameraDevice$StateCallback;Landroid/os/Handler;)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    iget-object v4, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {v4}, Lcom/zego/ve/VCam;->access$2000(Lcom/zego/ve/VCam;)[Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    aget-object v4, v4, p1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v0, v4}, Landroid/hardware/camera2/CameraManager;->getCameraCharacteristics(Ljava/lang/String;)Landroid/hardware/camera2/CameraCharacteristics;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/hardware/camera2/CameraAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v0}, Lcom/zego/ve/VCam;->access$500(Lcom/zego/ve/VCam;)Z

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-eqz v0, :cond_3

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {v0, p1}, Lcom/zego/ve/VCam;->access$600(Lcom/zego/ve/VCam;I)V

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v8, 0x2

    const/4 v7, 0x5

    iput p1, v0, Lcom/zego/ve/VCam;->mUseCameraId:I

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    return v1

    :catch_0
    move-exception v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    goto :goto_0

    :catch_1
    move-exception v0

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    move v8, v7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v4, "e rmnnrtppuoir nteoe itu"

    const-string/jumbo v4, "tinn rurceoupp ter tnoie"

    const/4 v8, 0x2

    const-string/jumbo v4, "rtnioi onoacpenee rpu tt"

    const-string/jumbo v4, "trace interruption open "

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-object v4, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {v4, p1}, Lcom/zego/ve/VCam;->access$300(Lcom/zego/ve/VCam;I)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string p1, " failed, "

    const-string p1, " failed, "

    const/4 v8, 0x3

    const-string p1, " failed, "

    const-string p1, " failed, "

    const/4 v8, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string/jumbo v0, "vcap"

    const-string v0, "avpc"

    const/4 v8, 0x1

    const-string v0, "apvc"

    const-string/jumbo v0, "vcap"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {v0, p1}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {p1, v3}, Lcom/zego/ve/VCam;->access$1602(Lcom/zego/ve/VCam;Z)Z

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    return v2
.end method

.method doSetExposureCompensation(F)I
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string/jumbo v0, "vpca"

    const/4 v6, 0x1

    const-string v0, "cavp"

    const-string/jumbo v0, "vcap"

    const/4 v6, 0x3

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    sget-object v2, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_AE_COMPENSATION_RANGE:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    check-cast v1, Landroid/util/Range;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v1}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    check-cast v2, Ljava/lang/Integer;

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    check-cast v1, Ljava/lang/Integer;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v3, -0x1

    const/4 v5, 0x5

    or-int/2addr v6, v5

    if-nez v2, :cond_0

    const/4 v5, 0x1

    shl-int/2addr v6, v5

    if-nez v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    return v3

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    cmpg-float v4, p1, v4

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-gez v4, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    neg-int v1, v2

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    int-to-float v1, v1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    mul-float/2addr v1, p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    float-to-int p1, v1

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    sget-object v2, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AE_EXPOSURE_COMPENSATION:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1, v2, v4}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string/jumbo v2, "rpeoebovoctippxcnsu eans t  paem"

    const-string v2, "ecnpsiaptupse epotsom  cenvx roa"

    const/4 v6, 0x4

    const-string/jumbo v2, "poiasvucptnx ocamue pnt:rses ee "

    const-string/jumbo v2, "vcap: set exposure compensation "

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 p1, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    return p1

    :catch_0
    move-exception p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string v1, "dlta serqpn  cevcmiafuoiss:xtoeoa ppen"

    const/4 v6, 0x1

    const-string/jumbo v1, "sn x:aspmptuceifat preilo oedaneopc vs"

    const-string/jumbo v1, "vcap: set exposure compensation failed"

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    return v3
.end method

.method doSetExposureMode(I)I
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v0, -0x1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-ne p1, v0, :cond_0

    const/4 v7, 0x3

    return v1

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v0}, Lcom/zego/ve/VCam;->access$708(Lcom/zego/ve/VCam;)I

    const/4 v6, 0x4

    xor-int/2addr v7, v6

    const-string v0, "acpv"

    const-string v0, "apcv"

    const/4 v7, 0x6

    const-string v0, "avpc"

    const-string/jumbo v0, "vcap"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v2, 0x4

    const/4 v6, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz p1, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v3, 0x5

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eq p1, v3, :cond_2

    const/4 v6, 0x0

    shl-int/2addr v7, v6

    if-ne p1, v2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    goto :goto_0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-ne p1, v3, :cond_3

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v3, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    sget-object v4, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AE_LOCK:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v3, v4, v5}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget-object v4, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AE_LOCK:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v3, v4, v5}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    :cond_3
    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string v4, " e :aocoqetspru  demsesv"

    const-string v4, " osp mesa:ees vucord tpe"

    const/4 v7, 0x2

    const-string/jumbo v4, "oesc a ps:drvupeomtees x"

    const-string/jumbo v4, "vcap: set exposure mode "

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v0, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x2

    const/4 v6, 0x3

    if-ne p1, v2, :cond_4

    const/4 v6, 0x5

    xor-int/2addr v7, v6

    invoke-static {}, Landroid/os/Message;->obtain()Landroid/os/Message;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    iput v1, p1, Landroid/os/Message;->what:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v2}, Lcom/zego/ve/VCam;->access$700(Lcom/zego/ve/VCam;)I

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    iput-object v2, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v2}, Lcom/zego/ve/VCam;->access$900(Lcom/zego/ve/VCam;)Landroid/os/Handler;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-wide/16 v3, 0xc8

    const-wide/16 v3, 0xc8

    const/4 v7, 0x6

    const-wide/16 v3, 0xc8

    const-wide/16 v3, 0xc8

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v2, p1, v3, v4}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_2

    :catch_0
    move-exception p1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string/jumbo v2, "oe mddrm fispl uvxs poeetmcaea"

    const-string/jumbo v2, "lxampv smerfuae i:odcde  spteo"

    const/4 v7, 0x2

    const-string v2, " e  ofee:ausadxmcr eosotdpveli"

    const-string/jumbo v2, "vcap: set exposure mode failed"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_4
    :goto_2
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget p1, p1, Lcom/zego/ve/VCam;->mExposureCompensation:F

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p0, p1}, Lcom/zego/ve/VCam$Cam2Device;->doSetExposureCompensation(F)I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    return v1
.end method

.method doSetExposurePoint(FF)I
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v1, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo v2, "pcva"

    const-string v2, "avpc"

    const/4 v6, 0x4

    const-string v2, "avcp"

    const-string/jumbo v2, "vcap"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x2

    sget-object v3, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_MAX_REGIONS_AE:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v0, v3}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    check-cast v0, Ljava/lang/Integer;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-nez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_0
    const/4 v5, 0x5

    move v6, v5

    invoke-direct {p0, p1, p2}, Lcom/zego/ve/VCam$Cam2Device;->calculateArea2(FF)Landroid/graphics/Rect;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 p2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-array p2, p2, [Landroid/hardware/camera2/params/MeteringRectangle;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v0, Landroid/hardware/camera2/params/MeteringRectangle;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/16 v3, 0x320

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v0, p1, v3}, Landroid/hardware/camera2/params/MeteringRectangle;-><init>(Landroid/graphics/Rect;I)V

    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    aput-object v0, p2, v3

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    sget-object v4, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AE_REGIONS:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v6, 0x0

    invoke-virtual {v0, v4, p2}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v0, "at:evbsoespac uero pa  e"

    const-string/jumbo v0, "opx:o aav se eetscer upa"

    const/4 v6, 0x1

    const-string/jumbo v0, "trx reu  s: epesapeuvoac"

    const-string/jumbo v0, "vcap: set exposure area "

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Landroid/graphics/Rect;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    return v3

    :catch_0
    move-exception p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const-string p2, " eufpa psasesivr ecxleea:patdr "

    const-string/jumbo p2, "vcap: set exposure areas failed"

    const/4 v6, 0x4

    const/4 v5, 0x2

    invoke-static {v2, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    return v1

    :cond_1
    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string p1, " tuc:tooqoaparssebru psenetera evdpx s"

    const-string/jumbo p1, "evppsbsett:us c  axadooer reruptpaoens"

    const-string p1, " rseaauorpepedo:attstesrp usnvx  epcos"

    const-string/jumbo p1, "vcap: set exposure areas not supported"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    return v1
.end method

.method doSetFocusMode(I)I
    .locals 13

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    const/4 v0, 0x2

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x0

    const/4 v1, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    if-eqz p1, :cond_2

    const/4 v11, 0x2

    move v12, v11

    if-eq p1, v0, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    const/16 v2, 0x8

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x3

    if-eq p1, v2, :cond_2

    const/4 v11, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x0

    const/4 v2, 0x5

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    const/4 v3, 0x4

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x7

    if-eq p1, v3, :cond_3

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x0

    if-eq p1, v2, :cond_0

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x0

    move v2, v3

    move v2, v3

    const/4 v12, 0x1

    move v2, v3

    const/4 v11, 0x4

    and-int/2addr v12, v11

    goto :goto_0

    :cond_0
    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    const/4 v11, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x4

    move v2, v0

    move v2, v0

    const/4 v12, 0x6

    move v2, v0

    move v2, v0

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x7

    goto :goto_0

    :cond_2
    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    move v2, v1

    move v2, v1

    const/4 v12, 0x4

    move v2, v1

    move v2, v1

    :cond_3
    :goto_0
    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    sget-object v3, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_AF_AVAILABLE_MODES:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-virtual {p1, v3}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x3

    check-cast p1, [I

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    array-length v3, p1

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x6

    const/4 v4, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    const-string v5, "cpva"

    const-string/jumbo v5, "vapc"

    const/4 v12, 0x6

    const-string/jumbo v5, "pcav"

    const-string/jumbo v5, "vcap"

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x1

    if-eqz v3, :cond_6

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x4

    array-length v3, p1

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    move v6, v4

    move v6, v4

    const/4 v12, 0x0

    move v6, v4

    move v6, v4

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x6

    move v7, v6

    const/4 v12, 0x6

    move v7, v6

    move v7, v6

    :goto_1
    const/4 v12, 0x0

    const/4 v11, 0x5

    if-ge v6, v3, :cond_5

    const/4 v11, 0x2

    aget v8, p1, v6

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x7

    if-ne v8, v2, :cond_4

    :try_start_0
    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget-object v7, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x7

    sget-object v9, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AF_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v10

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-virtual {v7, v9, v10}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    const/4 v11, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x4

    const-string/jumbo v9, "t mm:psfue a dcceoovs"

    const-string/jumbo v9, "vcap: set focus mode "

    const/4 v11, 0x0

    move v12, v11

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-static {v5, v7}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v12, 0x1

    goto :goto_2

    :catch_0
    move-exception v7

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    const-string v8, ":visoamef  eosfdeulad poc t"

    const-string/jumbo v8, "vcap: set focus mode failed"

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-static {v5, v8}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x3

    const/4 v11, 0x1

    invoke-virtual {v7}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_2
    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x2

    move v7, v1

    move v7, v1

    const/4 v12, 0x5

    move v7, v1

    move v7, v1

    :cond_4
    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x5

    add-int/lit8 v6, v6, 0x1

    const/4 v11, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    goto :goto_1

    :cond_5
    const/4 v12, 0x2

    const/4 v11, 0x7

    if-nez v7, :cond_7

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x6

    aget v2, p1, v4

    :try_start_1
    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    sget-object v3, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AF_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v12, 0x1

    const/4 v11, 0x1

    invoke-virtual {p1, v3, v6}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x1

    const-string/jumbo v3, "f o lbdfvaecakaumobpcul: c"

    const-string v3, " kaf  ufavupl :meccabodocl"

    const/4 v12, 0x7

    const-string/jumbo v3, "vcap: fallback focus mode "

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-static {v5, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x1

    goto :goto_3

    :catch_1
    move-exception p1

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x4

    const-string v3, " lalu:ui bdpf dcekaoavso mefclac"

    const-string/jumbo v3, "vcap: fallback focus mode failed"

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-static {v5, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x4

    const/4 v11, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_3
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x7

    move v7, v1

    move v7, v1

    const/4 v12, 0x1

    move v7, v1

    move v7, v1

    const/4 v12, 0x1

    const/4 v11, 0x1

    goto :goto_4

    :cond_6
    const/4 v12, 0x3

    const/4 v11, 0x7

    move v7, v4

    move v7, v4

    const/4 v12, 0x4

    move v7, v4

    move v7, v4

    :cond_7
    :goto_4
    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-nez v7, :cond_8

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    const-string/jumbo p1, "u:mctenps aloopetfdcu  f ev"

    const/4 v12, 0x4

    const-string/jumbo p1, "vcap: focus mode left unset"

    const/4 v12, 0x0

    const/4 v11, 0x3

    invoke-static {v5, p1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x7

    const/4 p1, -0x1

    const/4 v12, 0x7

    return p1

    :cond_8
    const/4 v11, 0x3

    const/4 v12, 0x0

    if-eq v2, v1, :cond_a

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    if-ne v2, v0, :cond_9

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    goto :goto_5

    :cond_9
    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x6

    move v1, v4

    move v1, v4

    move v1, v4

    move v1, v4

    :cond_a
    :goto_5
    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x3

    return v1
.end method

.method doSetFocusPoint(FF)I
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v1, -0x1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string/jumbo v2, "pavc"

    const-string v2, "cpva"

    const/4 v6, 0x1

    const-string/jumbo v2, "pavc"

    const-string/jumbo v2, "vcap"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    sget-object v3, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_MAX_REGIONS_AF:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0, v3}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    check-cast v0, Ljava/lang/Integer;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {p0, p1, p2}, Lcom/zego/ve/VCam$Cam2Device;->calculateArea2(FF)Landroid/graphics/Rect;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 p2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-array p2, p2, [Landroid/hardware/camera2/params/MeteringRectangle;

    const/4 v6, 0x1

    new-instance v0, Landroid/hardware/camera2/params/MeteringRectangle;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/16 v3, 0x320

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v0, p1, v3}, Landroid/hardware/camera2/params/MeteringRectangle;-><init>(Landroid/graphics/Rect;I)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x4

    aput-object v0, p2, v3

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    sget-object v4, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AF_REGIONS:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, v4, p2}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string v0, "cpotu ap: vssa ceqrae"

    const-string/jumbo v0, "vsa treuqpc a:o caes "

    const/4 v6, 0x6

    const-string/jumbo v0, "ra sv ecquco tf pa:se"

    const-string/jumbo v0, "vcap: set focus area "

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/graphics/Rect;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    return v3

    :catch_0
    move-exception p1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string p2, "apsirovlef u a:efdesas t scs"

    const-string p2, " ascipescva ff : eetalsdosru"

    const/4 v6, 0x2

    const-string p2, "cr msa ae p dufaosefvcest:la"

    const-string/jumbo p2, "vcap: set focus areas failed"

    const/4 v6, 0x5

    const/4 v5, 0x3

    invoke-static {v2, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    return v1

    :cond_1
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo p1, "poemta a edur tpvea sopsf souc:stnc"

    const/4 v6, 0x2

    const-string p1, " p:aoupssenootrveotds pr  a usetfca"

    const-string/jumbo p1, "vcap: set focus areas not supported"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    return v1
.end method

.method getFrontCam()I
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    sget-object v2, Landroid/hardware/camera2/CameraCharacteristics;->LENS_FACING:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    check-cast v0, Ljava/lang/Integer;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v1, 0x1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    return v1
.end method

.method getMaxZoomRatio()I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamDevice:Landroid/hardware/camera2/CameraDevice;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/16 v0, 0x64

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->SCALER_AVAILABLE_MAX_DIGITAL_ZOOM:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/Float;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/high16 v1, 0x42c80000    # 100.0f

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    mul-float/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    float-to-int v0, v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v0
.end method

.method getOrientation()I
    .locals 4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->SENSOR_ORIENTATION:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return v0
.end method

.method handleExposureMode(I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/zego/ve/VCam$Cam2Device;->doSetExposureMode(I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return p1
.end method

.method isFocusSupported()Z
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    const/4 v1, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-nez v0, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    return v1

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    sget-object v2, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_AF_AVAILABLE_MODES:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v8, 0x5

    invoke-virtual {v0, v2}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    check-cast v0, [I

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    array-length v2, v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    move v3, v1

    move v3, v1

    const/4 v8, 0x4

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v7, 0x3

    move v8, v7

    const/4 v4, 0x1

    move v8, v4

    const/4 v7, 0x4

    move v8, v7

    if-ge v3, v2, :cond_3

    const/4 v8, 0x3

    aget v5, v0, v3

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-eq v5, v4, :cond_2

    const/4 v7, 0x5

    move v8, v7

    const/4 v6, 0x3

    move v8, v6

    const/4 v7, 0x3

    move v8, v7

    if-eq v5, v6, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v6, 0x4

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-ne v5, v6, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto :goto_1

    :cond_1
    const/4 v7, 0x6

    const/4 v8, 0x3

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    move v0, v4

    move v0, v4

    move v0, v4

    move v0, v4

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    goto :goto_2

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    move v0, v1

    move v0, v1

    const/4 v8, 0x3

    move v0, v1

    move v0, v1

    :goto_2
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-nez v0, :cond_4

    const/4 v8, 0x7

    return v0

    :cond_4
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    sget-object v2, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_MAX_REGIONS_AF:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v8, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, v2}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    check-cast v0, Ljava/lang/Integer;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    if-lez v0, :cond_5

    const/4 v8, 0x7

    const/4 v7, 0x0

    move v1, v4

    move v1, v4

    const/4 v8, 0x5

    move v1, v4

    move v1, v4

    :cond_5
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    return v1
.end method

.method openTorch()I
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string v0, "apvc"

    const/4 v6, 0x7

    const-string/jumbo v0, "vpca"

    const-string/jumbo v0, "vcap"

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v6, 0x2

    const/4 v2, -0x1

    const/4 v6, 0x5

    move v5, v2

    move v5, v2

    const/4 v6, 0x5

    if-nez v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    return v2

    :cond_0
    const/4 v6, 0x2

    iget-object v1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v6, 0x2

    sget-object v3, Landroid/hardware/camera2/CameraCharacteristics;->FLASH_INFO_AVAILABLE:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1, v3}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x1

    check-cast v1, Ljava/lang/Boolean;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-nez v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    return v2

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v1, 0x0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    sget-object v3, Landroid/hardware/camera2/CaptureRequest;->FLASH_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    move v6, v5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2, v3, v4}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v3}, Landroid/hardware/camera2/CaptureRequest$Builder;->build()Landroid/hardware/camera2/CaptureRequest;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v4, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v2, v3, v4, v4}, Landroid/hardware/camera2/CameraCaptureSession;->setRepeatingRequest(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroid/os/Handler;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto :goto_0

    :catch_0
    move-exception v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo v3, "sla:dbosi e mtehoa fcdalve "

    const-string v3, "asf:olasphe  ldtmoce dai ve"

    const/4 v6, 0x6

    const-string/jumbo v3, "moae auhctvd aeld ffes:spil"

    const-string/jumbo v3, "vcap: set flash mode failed"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    move v2, v1

    move v2, v1

    const/4 v6, 0x6

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x6

    if-nez v2, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v2, "cadce tp tbe f:shupvpoame lsn a:l"

    const-string v2, " tledb oasa e: cvu htplan:sevcfmp"

    const/4 v6, 0x4

    const-string v2, "em dfaacqloavev cshttn: p elf su:"

    const-string/jumbo v2, "vcap: vcap: flash mode left unset"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v0, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    return v1
.end method

.method releaseCam()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamDevice:Landroid/hardware/camera2/CameraDevice;

    const/4 v3, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_2

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v3, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/hardware/camera2/CameraCaptureSession;->close()V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamDevice:Landroid/hardware/camera2/CameraDevice;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/hardware/camera2/CameraDevice;->close()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamDevice:Landroid/hardware/camera2/CameraDevice;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCam2Thread:Landroid/os/HandlerThread;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v1}, Landroid/os/HandlerThread;->quit()Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCam2Thread:Landroid/os/HandlerThread;

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCam2Handler:Landroid/os/Handler;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mImageReader:Landroid/media/ImageReader;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_2
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    return v0
.end method

.method setExposureCompensation(F)I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    return v1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0, p1}, Lcom/zego/ve/VCam$Cam2Device;->doSetExposureCompensation(F)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz p1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    return v1

    :cond_1
    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/hardware/camera2/CaptureRequest$Builder;->build()Landroid/hardware/camera2/CaptureRequest;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v2, v2}, Landroid/hardware/camera2/CameraCaptureSession;->setRepeatingRequest(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroid/os/Handler;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    return p1

    :catch_0
    move-exception p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v0, "vcap"

    const-string/jumbo v0, "pcva"

    const/4 v4, 0x0

    const-string v0, "acvp"

    const-string/jumbo v0, "vcap"

    const/4 v3, 0x3

    xor-int/2addr v4, v3

    const-string/jumbo v2, "ossinhs eexioa otpspsnpeavrtre rr :tmrexa prmeesa-couaipccet u -nc eaw emore "

    const-string/jumbo v2, "ns eoxuitpeeionmrectspas  reoe-s -e rosw e:urcxpapr acvmeattoni  herp etmrcaa"

    const/4 v4, 0x6

    const-string/jumbo v2, "vcap: set exposure compensation -- set camera parameters error with exception"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    return v1
.end method

.method setExposureMode(I)I
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v4, 0x3

    const/4 v0, -0x1

    const/4 v4, 0x7

    move v3, v0

    const/4 v4, 0x3

    if-nez p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    return v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget p1, p1, Lcom/zego/ve/VCam;->mExposureMode:I

    invoke-virtual {p0, p1}, Lcom/zego/ve/VCam$Cam2Device;->doSetExposureMode(I)I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    return v0

    :cond_1
    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1}, Landroid/hardware/camera2/CaptureRequest$Builder;->build()Landroid/hardware/camera2/CaptureRequest;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-virtual {p1, v1, v2, v2}, Landroid/hardware/camera2/CameraCaptureSession;->setRepeatingRequest(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroid/os/Handler;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x7

    return p1

    :catch_0
    move-exception p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v1, "pavc"

    const-string v1, "capv"

    const/4 v4, 0x2

    const-string v1, "capv"

    const-string/jumbo v1, "vcap"

    const/4 v4, 0x6

    const-string v2, " pcmnmrxeer meeretmtt arc -sdttcowpeahusss iaa o- exe p rrvae: repoie"

    const-string/jumbo v2, "vcap: set exposure mode -- set camera parameters error with exception"

    const/4 v4, 0x2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    return v0
.end method

.method setExposurePoint(FF)I
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v1, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v2, "apvc"

    const-string v2, "cpva"

    const/4 v4, 0x6

    const-string v2, "avcp"

    const-string/jumbo v2, "vcap"

    const/4 v3, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-boolean v0, v0, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/zego/ve/VCam$Cam2Device;->doSetExposurePoint(FF)I

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object p2, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroid/hardware/camera2/CaptureRequest$Builder;->build()Landroid/hardware/camera2/CaptureRequest;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1, p2, v0, v0}, Landroid/hardware/camera2/CameraCaptureSession;->setRepeatingRequest(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroid/os/Handler;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 p1, 0x0

    const/4 v4, 0x1

    return p1

    :catch_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const-string/jumbo p2, "raar orpwest: ce-temoo oh seuaci - rx epcr nr aveppixpenreet ipmtatste"

    const/4 v4, 0x3

    const-string/jumbo p2, "etcnoph  utrw -i tacsre:epxnper o i evpre-acept rteetesaooarixra m oss"

    const-string/jumbo p2, "vcap: set exposure point -- set camera parameters error with exception"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v2, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    return v1

    :cond_1
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string p1, ":vi  bekune sscspq--epxpa ipotot"

    const-string p1, "cveeon tqspapoxrp euks-:i p-tsi "

    const/4 v4, 0x5

    const-string/jumbo p1, "u-pe tu tckss seip-:aivrpeno xop"

    const-string/jumbo p1, "vcap: set exposure point -- skip"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    return v1
.end method

.method setFocusMode(I)I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v0, -0x4

    const/4 v0, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    sget-object v1, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AF_TRIGGER:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1, v1, v2}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget p1, p1, Lcom/zego/ve/VCam;->mFocusMode:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0, p1}, Lcom/zego/ve/VCam$Cam2Device;->doSetFocusMode(I)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x0

    if-ltz p1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-boolean v2, p1, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v4, 0x3

    const/4 v3, 0x6

    if-nez v2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v2, p1, Lcom/zego/ve/VCam;->mFocusPointX:F

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget p1, p1, Lcom/zego/ve/VCam;->mFocusPointY:F

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0, v2, p1}, Lcom/zego/ve/VCam$Cam2Device;->doSetFocusPoint(FF)I

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v4, 0x5

    const/4 v3, 0x2

    sget-object v2, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_MAX_REGIONS_AF:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1, v2}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast p1, Ljava/lang/Integer;

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    if-lez p1, :cond_2

    const/4 v3, 0x5

    move v4, v3

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object v2, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AF_REGIONS:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, v2, v1}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    :cond_2
    :goto_0
    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v2}, Landroid/hardware/camera2/CaptureRequest$Builder;->build()Landroid/hardware/camera2/CaptureRequest;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, v2, v1, v1}, Landroid/hardware/camera2/CameraCaptureSession;->setRepeatingRequest(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroid/os/Handler;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 p1, 0x2

    const/4 p1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    return p1

    :catch_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v1, "vpac"

    const/4 v4, 0x0

    const-string v1, "acvp"

    const-string/jumbo v1, "vcap"

    const/4 v4, 0x7

    const-string/jumbo v2, "ppuiartpdep:f teo-mcnraowotmhtsv s  ci e  rers-cr  etsa mesoraxeae"

    const-string v2, "-usw exp aehvsod ratmtttpe s:cersi-roc   ooeeaa e pnrefmceamrts ir"

    const/4 v4, 0x4

    const-string/jumbo v2, "tpco-ae q sriacrseeccreaeox ps   -taemer:wermdtpsniu m orh ofettav"

    const-string/jumbo v2, "vcap: set focus mode -- set camera parameters error with exception"

    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v0
.end method

.method setFocusPoint(FF)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget-boolean p2, p1, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    const/4 v0, 0x7

    move v1, v0

    if-nez p2, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget-boolean p2, p1, Lcom/zego/ve/VCam;->mIsFocusing:Z

    const/4 v0, 0x4

    move v1, v0

    if-eqz p2, :cond_0

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iget p1, p1, Lcom/zego/ve/VCam;->mFocusMode:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/zego/ve/VCam$Cam2Device;->setFocusMode(I)I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return p1

    :cond_1
    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    const/4 p1, -0x1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p1
.end method

.method setImageReader(Landroid/media/ImageReader;)I
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mImageReader:Landroid/media/ImageReader;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x2

    return p1
.end method

.method setRate(I)I
    .locals 5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    return v1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, p1}, Lcom/zego/ve/VCam$Cam2Device;->updateRate(I)I

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Landroid/hardware/camera2/CaptureRequest$Builder;->build()Landroid/hardware/camera2/CaptureRequest;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v2, v2}, Landroid/hardware/camera2/CameraCaptureSession;->setRepeatingRequest(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroid/os/Handler;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo v0, "pvca"

    const-string/jumbo v0, "vcpa"

    const/4 v4, 0x1

    const-string/jumbo v0, "vapc"

    const-string/jumbo v0, "vcap"

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo v2, "r s  peesr:amf orhpx twne rpm evasraed -tictcsmap-rctuaeeitpae"

    const-string/jumbo v2, "srmmnwa  a tpsf rsoaee ctrrcevopcdu -ip eeptr:aateh mxpri-aeet"

    const/4 v4, 0x1

    const-string/jumbo v2, "urimedamfetapinostece-tr srp x wpep  e: t rohctpse a ra-ecamrv"

    const-string/jumbo v2, "vcap: update fps -- set camera parameters error with exception"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    return v1
.end method

.method setSurfaceTexture(Landroid/graphics/SurfaceTexture;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p1
.end method

.method setZoomFactor(F)V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-nez v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-void

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->SCALER_AVAILABLE_MAX_DIGITAL_ZOOM:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    check-cast v0, Ljava/lang/Float;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    cmpl-float v1, p1, v1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-lez v1, :cond_1

    const/4 v6, 0x5

    xor-int/2addr v7, v6

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result p1

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    cmpg-float v1, p1, v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-gez v1, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    move p1, v0

    move p1, v0

    const/4 v7, 0x6

    move p1, v0

    move p1, v0

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    const/4 v7, 0x3

    sget-object v1, Landroid/hardware/camera2/CameraCharacteristics;->SENSOR_INFO_ACTIVE_ARRAY_SIZE:Landroid/hardware/camera2/CameraCharacteristics$Key;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    check-cast v0, Landroid/graphics/Rect;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    div-int/lit8 v1, v1, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    div-int/lit8 v2, v2, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    int-to-float v3, v3

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/high16 v4, 0x3f000000    # 0.5f

    const/4 v7, 0x6

    mul-float/2addr v3, v4

    div-float/2addr v3, p1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    float-to-int v3, v3

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    int-to-float v0, v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    mul-float/2addr v0, v4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    div-float/2addr v0, p1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    float-to-int p1, v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-instance v0, Landroid/graphics/Rect;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v7, 0x7

    sub-int v4, v1, v3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    sub-int v5, v2, p1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    add-int/2addr v1, v3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    add-int/2addr v2, p1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0, v4, v5, v1, v2}, Landroid/graphics/Rect;->set(IIII)V

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    sget-object v1, Landroid/hardware/camera2/CaptureRequest;->SCALER_CROP_REGION:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p1, v1, v0}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0}, Landroid/hardware/camera2/CaptureRequest$Builder;->build()Landroid/hardware/camera2/CaptureRequest;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x4

    xor-int/2addr v7, v6

    invoke-virtual {p1, v0, v1, v1}, Landroid/hardware/camera2/CameraCaptureSession;->setRepeatingRequest(Landroid/hardware/camera2/CaptureRequest;Landroid/hardware/camera2/CameraCaptureSession$CaptureCallback;Landroid/os/Handler;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x6

    move v7, v6

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string/jumbo v0, "vcap"

    const-string v0, "avpc"

    const-string/jumbo v0, "vpac"

    const-string/jumbo v0, "vcap"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string/jumbo v1, "sclvodoeo :mz oiea ap"

    const-string v1, ":iedozfsmaolecao  p v"

    const/4 v7, 0x2

    const-string/jumbo v1, "vcap: set zoom failed"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    shr-int/2addr v7, v6

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    return-void
.end method

.method startCam(Z)I
    .locals 16

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    const-string/jumbo v2, "vcap"

    const-string/jumbo v2, "pvac"

    const-string/jumbo v2, "vcap"

    const/4 v3, -0x1

    :try_start_0
    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->mOpenSem:Ljava/util/concurrent/Semaphore;

    sget-object v4, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    invoke-virtual {v0, v5, v6, v4}, Ljava/util/concurrent/Semaphore;->tryAcquire(JLjava/util/concurrent/TimeUnit;)Z

    move-result v0

    if-nez v0, :cond_0

    return v3

    :cond_0
    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    invoke-static {v0}, Lcom/zego/ve/VCam;->access$1900(Lcom/zego/ve/VCam;)Landroid/content/Context;

    move-result-object v0

    const-string v4, "ecbrab"

    const-string v4, "eaarcb"

    const-string/jumbo v4, "uracea"

    const-string v4, "camera"

    invoke-virtual {v0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/camera2/CameraManager;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    const-string v0, "cnep vmp OSedau:file"

    const-string v0, "ecf:iSuae l dmOenvap"

    const-string v0, ":mpdie nqp caaOelSev"

    const-string/jumbo v0, "vcap: OpenSem failed"

    invoke-static {v2, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    iget-boolean v0, v1, Lcom/zego/ve/VCam$Cam2Device;->mOpened:Z

    const/4 v4, 0x1

    if-nez v0, :cond_1

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    invoke-static {v0, v4}, Lcom/zego/ve/VCam;->access$1602(Lcom/zego/ve/VCam;Z)Z

    const-string v0, "C sriOcapmvndfaepaepa l "

    const-string v0, "ea pm: pCapvdacnf lriaeO"

    const-string v0, "elfmOaa picempaner d vCa"

    const-string/jumbo v0, "vcap: Open Camera failed"

    invoke-static {v2, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return v3

    :cond_1
    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    invoke-virtual {v0}, Lcom/zego/ve/VCam;->getFront()I

    move-result v0

    const/4 v5, 0x0

    if-lez v0, :cond_2

    move v0, v4

    move v0, v4

    move v0, v4

    move v0, v4

    goto :goto_1

    :cond_2
    move v0, v5

    move v0, v5

    move v0, v5

    move v0, v5

    :goto_1
    iget-object v6, v1, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    sget-object v7, Landroid/hardware/camera2/CameraCharacteristics;->STATISTICS_INFO_MAX_FACE_COUNT:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v6, v7}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Integer;

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    iget-object v7, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    if-eqz v0, :cond_3

    if-eqz p1, :cond_3

    if-lez v6, :cond_3

    move v0, v4

    move v0, v4

    move v0, v4

    move v0, v4

    goto :goto_2

    :cond_3
    move v0, v5

    move v0, v5

    move v0, v5

    move v0, v5

    :goto_2
    iput-boolean v0, v7, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    sget-object v6, Landroid/hardware/camera2/CameraCharacteristics;->SCALER_STREAM_CONFIGURATION_MAP:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v0, v6}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/camera2/params/StreamConfigurationMap;

    const/16 v6, 0x23

    invoke-virtual {v0, v6}, Landroid/hardware/camera2/params/StreamConfigurationMap;->getOutputSizes(I)[Landroid/util/Size;

    move-result-object v0

    const-string/jumbo v6, "x"

    const-string/jumbo v6, "x"

    const-string/jumbo v6, "x"

    const-string/jumbo v6, "x"

    if-eqz v0, :cond_13

    array-length v7, v0

    move v8, v5

    move v8, v5

    move v8, v5

    move v8, v5

    move v9, v8

    move v9, v8

    move v9, v8

    move v9, v8

    move v10, v9

    move v10, v9

    move v10, v9

    move v10, v9

    :goto_3
    if-ge v8, v7, :cond_6

    aget-object v11, v0, v8

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v13, "izp oepvpqs o trsa:- u"

    const-string v13, " iozps: qae-v pp srctu"

    const-string v13, "-u prbo vaszp: si etc-"

    const-string/jumbo v13, "vcap: support size -- "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Landroid/util/Size;->getWidth()I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Landroid/util/Size;->getHeight()I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v2, v12}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v11}, Landroid/util/Size;->getWidth()I

    move-result v12

    invoke-virtual {v11}, Landroid/util/Size;->getHeight()I

    move-result v13

    mul-int/2addr v12, v13

    mul-int v13, v9, v10

    if-le v12, v13, :cond_5

    invoke-virtual {v11}, Landroid/util/Size;->getWidth()I

    move-result v12

    mul-int/lit8 v12, v12, 0x3

    invoke-virtual {v11}, Landroid/util/Size;->getHeight()I

    move-result v13

    mul-int/lit8 v13, v13, 0x4

    if-eq v12, v13, :cond_4

    invoke-virtual {v11}, Landroid/util/Size;->getWidth()I

    move-result v12

    mul-int/lit8 v12, v12, 0x9

    invoke-virtual {v11}, Landroid/util/Size;->getHeight()I

    move-result v13

    mul-int/lit8 v13, v13, 0x10

    if-ne v12, v13, :cond_5

    :cond_4
    invoke-virtual {v11}, Landroid/util/Size;->getWidth()I

    move-result v9

    invoke-virtual {v11}, Landroid/util/Size;->getHeight()I

    move-result v10

    :cond_5
    add-int/lit8 v8, v8, 0x1

    goto :goto_3

    :cond_6
    array-length v7, v0

    move v8, v5

    move v8, v5

    move v8, v5

    move v8, v5

    move v11, v8

    move v11, v8

    move v11, v8

    move v11, v8

    move v12, v11

    move v12, v11

    move v12, v11

    :goto_4
    if-ge v8, v7, :cond_14

    aget-object v13, v0, v8

    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v14

    rem-int/lit8 v14, v14, 0x10

    if-nez v14, :cond_12

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v14

    rem-int/lit8 v14, v14, 0x10

    if-eqz v14, :cond_7

    goto/16 :goto_6

    :cond_7
    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v14

    iget-object v15, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v15, v15, Lcom/zego/ve/VCam;->mWidth:I

    if-lt v14, v15, :cond_a

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v14

    iget-object v15, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v3, v15, Lcom/zego/ve/VCam;->mHeight:I

    if-lt v14, v3, :cond_a

    iget v14, v15, Lcom/zego/ve/VCam;->mWidth:I

    if-lt v11, v14, :cond_9

    if-ge v12, v3, :cond_8

    goto :goto_5

    :cond_8
    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v3

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v14

    mul-int/2addr v3, v14

    mul-int v14, v11, v12

    if-ge v3, v14, :cond_12

    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v11

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v12

    goto/16 :goto_6

    :cond_9
    :goto_5
    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v11

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v12

    goto/16 :goto_6

    :cond_a
    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v3

    iget-object v14, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v15, v14, Lcom/zego/ve/VCam;->mWidth:I

    if-lt v3, v15, :cond_e

    if-lt v11, v15, :cond_b

    iget v3, v14, Lcom/zego/ve/VCam;->mHeight:I

    if-lt v12, v3, :cond_b

    goto/16 :goto_6

    :cond_b
    if-ge v11, v15, :cond_c

    iget v3, v14, Lcom/zego/ve/VCam;->mHeight:I

    if-ge v12, v3, :cond_c

    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v11

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v12

    goto/16 :goto_6

    :cond_c
    if-lt v11, v15, :cond_d

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v3

    if-le v3, v12, :cond_d

    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v11

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v12

    goto :goto_6

    :cond_d
    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v3

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v14

    mul-int/2addr v3, v14

    mul-int v14, v11, v12

    if-le v3, v14, :cond_12

    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v11

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v12

    goto :goto_6

    :cond_e
    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v3

    iget-object v14, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v15, v14, Lcom/zego/ve/VCam;->mHeight:I

    if-lt v3, v15, :cond_12

    iget v3, v14, Lcom/zego/ve/VCam;->mWidth:I

    if-lt v11, v3, :cond_f

    if-lt v12, v15, :cond_f

    goto :goto_6

    :cond_f
    if-ge v11, v3, :cond_10

    if-ge v12, v15, :cond_10

    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v11

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v12

    goto :goto_6

    :cond_10
    if-lt v12, v15, :cond_11

    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v3

    if-le v3, v11, :cond_11

    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v11

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v12

    goto :goto_6

    :cond_11
    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v3

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v14

    mul-int/2addr v3, v14

    mul-int v14, v11, v12

    if-le v3, v14, :cond_12

    invoke-virtual {v13}, Landroid/util/Size;->getWidth()I

    move-result v11

    invoke-virtual {v13}, Landroid/util/Size;->getHeight()I

    move-result v12

    :cond_12
    :goto_6
    add-int/lit8 v8, v8, 0x1

    const/4 v3, -0x1

    goto/16 :goto_4

    :cond_13
    move v9, v5

    move v9, v5

    move v9, v5

    move v9, v5

    move v10, v9

    move v10, v9

    move v10, v9

    move v11, v10

    move v11, v10

    move v11, v10

    move v12, v11

    move v12, v11

    move v12, v11

    move v12, v11

    :cond_14
    mul-int v0, v11, v12

    if-eqz v0, :cond_15

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iput v11, v0, Lcom/zego/ve/VCam;->mWidth:I

    iput v12, v0, Lcom/zego/ve/VCam;->mHeight:I

    goto :goto_7

    :cond_15
    mul-int v0, v9, v10

    if-eqz v0, :cond_16

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iput v9, v0, Lcom/zego/ve/VCam;->mWidth:I

    iput v10, v0, Lcom/zego/ve/VCam;->mHeight:I

    goto :goto_7

    :cond_16
    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/16 v3, 0x140

    iput v3, v0, Lcom/zego/ve/VCam;->mWidth:I

    const/16 v3, 0xf0

    iput v3, v0, Lcom/zego/ve/VCam;->mHeight:I

    :goto_7
    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const-string v3, "CAPT"

    const-string v3, "PTAC"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_17

    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const-string v3, "OI0DB-uF"

    const-string v3, "OIs-BF0D"

    const-string v3, "00IBF-Dp"

    const-string v3, "FIO-BD00"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_17

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v3, v0, Lcom/zego/ve/VCam;->mWidth:I

    iget v7, v0, Lcom/zego/ve/VCam;->mHeight:I

    mul-int/2addr v3, v7

    const v7, 0xe1000

    if-ge v3, v7, :cond_17

    const/16 v3, 0x500

    iput v3, v0, Lcom/zego/ve/VCam;->mWidth:I

    const/16 v3, 0x2d0

    iput v3, v0, Lcom/zego/ve/VCam;->mHeight:I

    :cond_17
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "- e:wdeaq :eiptmcavps i,nvercad  i"

    const-string/jumbo v3, "w emtz, :eie:idnpv eacip v ar-scad"

    const-string v3, "casi-i:pste  aee i,dnce-wp: vdarz "

    const-string/jumbo v3, "vcap: preview size -- , candidate:"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v3, "trsmge:o l"

    const-string/jumbo v3, "s gtoe:,rl"

    const-string/jumbo v3, "g sao,etrl"

    const-string v3, ", largest:"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, "erbw,bep :"

    const-string/jumbo v3, "rwe,pb ie:"

    const-string/jumbo v3, "evp, eui:r"

    const-string v3, ", preview:"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v3, v3, Lcom/zego/ve/VCam;->mWidth:I

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v3, v3, Lcom/zego/ve/VCam;->mHeight:I

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iput-boolean v5, v0, Lcom/zego/ve/VCam;->mIsFocusing:Z

    :try_start_1
    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->mCamDevice:Landroid/hardware/camera2/CameraDevice;

    invoke-virtual {v0, v4}, Landroid/hardware/camera2/CameraDevice;->createCaptureRequest(I)Landroid/hardware/camera2/CaptureRequest$Builder;

    move-result-object v0

    iput-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    sget-object v3, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AF_TRIGGER:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v6, 0x2

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v0, v3, v7}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget-boolean v0, v0, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    if-eqz v0, :cond_1a

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    sget-object v3, Landroid/hardware/camera2/CameraCharacteristics;->STATISTICS_INFO_AVAILABLE_FACE_DETECT_MODES:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v0, v3}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    array-length v3, v0

    move v7, v5

    move v7, v5

    move v8, v7

    move v8, v7

    move v8, v7

    move v8, v7

    :goto_8
    if-ge v7, v3, :cond_19

    aget v9, v0, v7

    if-le v9, v8, :cond_18

    move v8, v9

    move v8, v9

    move v8, v9

    move v8, v9

    :cond_18
    add-int/lit8 v7, v7, 0x1

    goto :goto_8

    :cond_19
    if-lez v8, :cond_1a

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    sget-object v3, Landroid/hardware/camera2/CaptureRequest;->STATISTICS_FACE_DETECT_MODE:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v0, v3, v7}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    :cond_1a
    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v0, v0, Lcom/zego/ve/VCam;->mFocusMode:I

    invoke-virtual {v1, v0}, Lcom/zego/ve/VCam$Cam2Device;->doSetFocusMode(I)I

    move-result v0

    if-ltz v0, :cond_1b

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget-boolean v3, v0, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    if-nez v3, :cond_1c

    iget v3, v0, Lcom/zego/ve/VCam;->mFocusPointX:F

    iget v0, v0, Lcom/zego/ve/VCam;->mFocusPointY:F

    invoke-virtual {v1, v3, v0}, Lcom/zego/ve/VCam$Cam2Device;->doSetFocusPoint(FF)I

    goto :goto_9

    :cond_1b
    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    sget-object v3, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_MAX_REGIONS_AF:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v0, v3}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    if-lez v0, :cond_1c

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    sget-object v3, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AF_REGIONS:Landroid/hardware/camera2/CaptureRequest$Key;

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v7}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    :cond_1c
    :goto_9
    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v0, v0, Lcom/zego/ve/VCam;->mExposureMode:I

    invoke-virtual {v1, v0}, Lcom/zego/ve/VCam$Cam2Device;->doSetExposureMode(I)I

    move-result v0

    if-nez v0, :cond_1d

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget-boolean v3, v0, Lcom/zego/ve/VCam;->mUseFaceDetection:Z

    if-nez v3, :cond_1d

    iget v3, v0, Lcom/zego/ve/VCam;->mExposurePointX:F

    iget v0, v0, Lcom/zego/ve/VCam;->mExposurePointY:F

    invoke-virtual {v1, v3, v0}, Lcom/zego/ve/VCam$Cam2Device;->doSetExposurePoint(FF)I

    :cond_1d
    :try_start_2
    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->mSurfaceTexture:Landroid/graphics/SurfaceTexture;

    iget-object v3, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v7, v3, Lcom/zego/ve/VCam;->mWidth:I

    iget v3, v3, Lcom/zego/ve/VCam;->mHeight:I

    invoke-virtual {v0, v7, v3}, Landroid/graphics/SurfaceTexture;->setDefaultBufferSize(II)V

    new-instance v0, Landroid/view/Surface;

    iget-object v3, v1, Lcom/zego/ve/VCam$Cam2Device;->mSurfaceTexture:Landroid/graphics/SurfaceTexture;

    invoke-direct {v0, v3}, Landroid/view/Surface;-><init>(Landroid/graphics/SurfaceTexture;)V

    iget-object v3, v1, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    invoke-virtual {v3, v0}, Landroid/hardware/camera2/CaptureRequest$Builder;->addTarget(Landroid/view/Surface;)V

    iget-object v3, v1, Lcom/zego/ve/VCam$Cam2Device;->mImageReader:Landroid/media/ImageReader;

    if-eqz v3, :cond_1e

    iget-object v7, v1, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    invoke-virtual {v3}, Landroid/media/ImageReader;->getSurface()Landroid/view/Surface;

    move-result-object v3

    invoke-virtual {v7, v3}, Landroid/hardware/camera2/CaptureRequest$Builder;->addTarget(Landroid/view/Surface;)V

    new-array v3, v6, [Landroid/view/Surface;

    aput-object v0, v3, v5

    iget-object v0, v1, Lcom/zego/ve/VCam$Cam2Device;->mImageReader:Landroid/media/ImageReader;

    invoke-virtual {v0}, Landroid/media/ImageReader;->getSurface()Landroid/view/Surface;

    move-result-object v0

    aput-object v0, v3, v4

    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    goto :goto_a

    :cond_1e
    new-array v3, v4, [Landroid/view/Surface;

    aput-object v0, v3, v5

    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    :goto_a
    iget-object v3, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v6, v3, Lcom/zego/ve/VCam;->mFPSMode:I

    if-eqz v6, :cond_1f

    iget v3, v3, Lcom/zego/ve/VCam;->mFrameRate:I

    invoke-virtual {v1, v3}, Lcom/zego/ve/VCam$Cam2Device;->updateRate(I)I

    :cond_1f
    iget-object v3, v1, Lcom/zego/ve/VCam$Cam2Device;->mCamDevice:Landroid/hardware/camera2/CameraDevice;

    iget-object v6, v1, Lcom/zego/ve/VCam$Cam2Device;->mSessionStateCallback:Lcom/zego/ve/VCam$Cam2Device$SessionStateCallback;

    iget-object v7, v1, Lcom/zego/ve/VCam$Cam2Device;->mCam2Handler:Landroid/os/Handler;

    invoke-virtual {v3, v0, v6, v7}, Landroid/hardware/camera2/CameraDevice;->createCaptureSession(Ljava/util/List;Landroid/hardware/camera2/CameraCaptureSession$StateCallback;Landroid/os/Handler;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    return v5

    :catch_1
    move-exception v0

    iget-object v3, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    invoke-static {v3, v4}, Lcom/zego/ve/VCam;->access$1602(Lcom/zego/ve/VCam;Z)Z

    const-string/jumbo v3, "p einSep:ailscprCauaetseofaurvetc"

    const-string/jumbo v3, "etecdiuaSsaopeairstne aCeufcprvl:"

    const-string/jumbo v3, "vcap: createCaptureSession failed"

    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_b
    const/4 v2, -0x1

    return v2

    :catch_2
    move-exception v0

    iget-object v3, v1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    invoke-static {v3, v4}, Lcom/zego/ve/VCam;->access$1602(Lcom/zego/ve/VCam;Z)Z

    const-string/jumbo v3, "fReeeasaquelcct  rieprqp:tdvpCate"

    const-string v3, "afeaqrapeelueretdvscpRta pci tC:e"

    const-string v3, "Cfsclvpaepauecqsta ueret:dtiae rR"

    const-string/jumbo v3, "vcap: createCaptureRequest failed"

    invoke-static {v2, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_b
.end method

.method stopCam()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamDevice:Landroid/hardware/camera2/CameraDevice;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device;->mCamCapSession:Landroid/hardware/camera2/CameraCaptureSession;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    invoke-virtual {v0}, Landroid/hardware/camera2/CameraCaptureSession;->stopRepeating()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x3

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x5

    move v2, v1

    return v0
.end method

.method updateRate(I)I
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    iget-object v1, v0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v1, v1, Lcom/zego/ve/VCam;->mFrameRate:I

    iget-object v2, v0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    sget-object v3, Landroid/hardware/camera2/CameraCharacteristics;->CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v2, v3}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Landroid/util/Range;

    const-string/jumbo v3, "vcap"

    const-string/jumbo v3, "vacp"

    const-string v3, "capv"

    const-string/jumbo v3, "vcap"

    const-string/jumbo v4, "|"

    const-string/jumbo v4, "|"

    const-string/jumbo v4, "|"

    const-string/jumbo v4, "|"

    if-eqz v2, :cond_13

    array-length v6, v2

    if-eqz v6, :cond_13

    iget-object v6, v0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v7, v6, Lcom/zego/ve/VCam;->mFpsMin:I

    const/16 v8, -0x3e8

    if-eq v7, v8, :cond_7

    iget v7, v6, Lcom/zego/ve/VCam;->mFpsMax:I

    if-eq v7, v8, :cond_7

    array-length v6, v2

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    :goto_0
    if-ge v7, v6, :cond_6

    aget-object v14, v2, v7

    new-instance v15, Ljava/lang/StringBuilder;

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "pfmmc|:q "

    const-string v5, ":p|fcma q"

    const-string/jumbo v5, "sf: opmc|"

    const-string v5, "cam fps:|"

    invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    div-int/lit16 v5, v5, 0x3e8

    invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    div-int/lit16 v5, v5, 0x3e8

    invoke-virtual {v15, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v15, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v5}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v14}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    iget-object v15, v0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v15, v15, Lcom/zego/ve/VCam;->mFpsMin:I

    sub-int/2addr v5, v15

    invoke-static {v5}, Ljava/lang/Math;->abs(I)I

    move-result v5

    invoke-virtual {v14}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v15

    check-cast v15, Ljava/lang/Integer;

    invoke-virtual {v15}, Ljava/lang/Integer;->intValue()I

    move-result v15

    move/from16 v16, v1

    move/from16 v16, v1

    move/from16 v16, v1

    iget-object v1, v0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v1, v1, Lcom/zego/ve/VCam;->mFpsMax:I

    if-lt v15, v1, :cond_2

    if-eqz v8, :cond_1

    invoke-virtual {v14}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-lt v1, v8, :cond_1

    invoke-virtual {v14}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-ne v1, v8, :cond_0

    if-lt v5, v13, :cond_1

    :cond_0
    invoke-virtual {v14}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-ne v1, v8, :cond_5

    if-ne v5, v13, :cond_5

    invoke-virtual {v14}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-le v1, v10, :cond_5

    :cond_1
    invoke-virtual {v14}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v10

    invoke-virtual {v14}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v8

    move v13, v5

    move v13, v5

    move v13, v5

    move v13, v5

    goto :goto_1

    :cond_2
    if-eqz v9, :cond_4

    invoke-virtual {v14}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-gt v1, v9, :cond_4

    invoke-virtual {v14}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-ne v1, v9, :cond_3

    if-lt v5, v12, :cond_4

    :cond_3
    invoke-virtual {v14}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-ne v1, v9, :cond_5

    if-ne v5, v12, :cond_5

    invoke-virtual {v14}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-le v1, v11, :cond_5

    :cond_4
    invoke-virtual {v14}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v11

    invoke-virtual {v14}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v9

    move v12, v5

    move v12, v5

    move v12, v5

    :cond_5
    :goto_1
    add-int/lit8 v7, v7, 0x1

    move/from16 v1, v16

    move/from16 v1, v16

    move/from16 v1, v16

    goto/16 :goto_0

    :cond_6
    move/from16 v16, v1

    move/from16 v16, v1

    move/from16 v16, v1

    move/from16 v16, v1

    goto/16 :goto_6

    :cond_7
    move/from16 v16, v1

    move/from16 v16, v1

    move/from16 v16, v1

    move/from16 v16, v1

    iget v1, v6, Lcom/zego/ve/VCam;->mFrameRate:I

    iget-boolean v5, v6, Lcom/zego/ve/VCam;->mLowLightBoost:Z

    if-eqz v5, :cond_c

    array-length v5, v2

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    :goto_2
    if-ge v6, v5, :cond_11

    aget-object v7, v2, v6

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-lt v12, v1, :cond_9

    if-eqz v8, :cond_8

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-lt v12, v8, :cond_8

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-ne v12, v8, :cond_b

    invoke-virtual {v7}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-ge v12, v10, :cond_b

    :cond_8
    invoke-virtual {v7}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v8

    check-cast v8, Ljava/lang/Integer;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v10

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v7

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v8

    goto :goto_3

    :cond_9
    if-eqz v9, :cond_a

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-gt v12, v9, :cond_a

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-ne v12, v9, :cond_b

    invoke-virtual {v7}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-ge v12, v11, :cond_b

    :cond_a
    invoke-virtual {v7}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v9

    check-cast v9, Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v11

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v7

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v9

    :cond_b
    :goto_3
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_2

    :cond_c
    array-length v5, v2

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    :goto_4
    if-ge v6, v5, :cond_11

    aget-object v7, v2, v6

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-lt v12, v1, :cond_e

    if-eqz v8, :cond_d

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-lt v12, v8, :cond_d

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-ne v12, v8, :cond_10

    invoke-virtual {v7}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-le v12, v10, :cond_10

    :cond_d
    invoke-virtual {v7}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v8

    check-cast v8, Ljava/lang/Integer;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v10

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v7

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v8

    goto :goto_5

    :cond_e
    if-eqz v9, :cond_f

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-gt v12, v9, :cond_f

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-ne v12, v9, :cond_10

    invoke-virtual {v7}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-le v12, v11, :cond_10

    :cond_f
    invoke-virtual {v7}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v9

    check-cast v9, Ljava/lang/Integer;

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v11

    invoke-virtual {v7}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v7

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v9

    :cond_10
    :goto_5
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_4

    :cond_11
    :goto_6
    if-eqz v8, :cond_12

    move v1, v10

    move v1, v10

    move v1, v10

    goto :goto_7

    :cond_12
    if-eqz v9, :cond_14

    move v8, v9

    move v8, v9

    move v8, v9

    move v8, v9

    move v1, v11

    move v1, v11

    move v1, v11

    move v1, v11

    goto :goto_7

    :cond_13
    move/from16 v16, v1

    move/from16 v16, v1

    move/from16 v16, v1

    move/from16 v16, v1

    :cond_14
    move/from16 v1, v16

    move/from16 v1, v16

    move/from16 v1, v16

    move/from16 v1, v16

    move v8, v1

    move v8, v1

    move v8, v1

    move v8, v1

    :goto_7
    new-instance v2, Landroid/util/Size;

    iget-object v5, v0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    iget v6, v5, Lcom/zego/ve/VCam;->mWidth:I

    iget v5, v5, Lcom/zego/ve/VCam;->mHeight:I

    invoke-direct {v2, v6, v5}, Landroid/util/Size;-><init>(II)V

    iget-object v5, v0, Lcom/zego/ve/VCam$Cam2Device;->mCamCharacteristics:Landroid/hardware/camera2/CameraCharacteristics;

    sget-object v6, Landroid/hardware/camera2/CameraCharacteristics;->SCALER_STREAM_CONFIGURATION_MAP:Landroid/hardware/camera2/CameraCharacteristics$Key;

    invoke-virtual {v5, v6}, Landroid/hardware/camera2/CameraCharacteristics;->get(Landroid/hardware/camera2/CameraCharacteristics$Key;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/hardware/camera2/params/StreamConfigurationMap;

    const/16 v6, 0x23

    invoke-virtual {v5, v6, v2}, Landroid/hardware/camera2/params/StreamConfigurationMap;->getOutputMinFrameDuration(ILandroid/util/Size;)J

    move-result-wide v5

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    cmp-long v2, v5, v9

    if-eqz v2, :cond_16

    const-wide/32 v9, 0x3b9aca00

    const-wide/32 v9, 0x3b9aca00

    const-wide/32 v9, 0x3b9aca00

    const-wide/32 v9, 0x3b9aca00

    div-long/2addr v9, v5

    int-to-long v5, v1

    cmp-long v2, v5, v9

    if-lez v2, :cond_15

    long-to-int v1, v9

    :cond_15
    int-to-long v5, v8

    cmp-long v2, v5, v9

    if-lez v2, :cond_16

    long-to-int v8, v9

    :cond_16
    new-instance v2, Landroid/util/Range;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-direct {v2, v1, v5}, Landroid/util/Range;-><init>(Ljava/lang/Comparable;Ljava/lang/Comparable;)V

    iget-object v1, v0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    sget-object v5, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AE_TARGET_FPS_RANGE:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-virtual {v1, v5, v2}, Landroid/hardware/camera2/CaptureRequest$Builder;->set(Landroid/hardware/camera2/CaptureRequest$Key;Ljava/lang/Object;)V

    iget-object v1, v0, Lcom/zego/ve/VCam$Cam2Device;->mCapRequestBuilder:Landroid/hardware/camera2/CaptureRequest$Builder;

    sget-object v2, Landroid/hardware/camera2/CaptureRequest;->CONTROL_AE_TARGET_FPS_RANGE:Landroid/hardware/camera2/CaptureRequest$Key;

    invoke-virtual {v1, v2}, Landroid/hardware/camera2/CaptureRequest$Builder;->get(Landroid/hardware/camera2/CaptureRequest$Key;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/util/Range;

    invoke-virtual {v1}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v2

    invoke-virtual {v1}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v5

    if-ne v2, v5, :cond_17

    iget-object v2, v0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    invoke-virtual {v1}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    iput v5, v2, Lcom/zego/ve/VCam;->mFrameRate:I

    goto :goto_8

    :cond_17
    iget-object v2, v0, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    invoke-virtual {v1}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    div-int/lit8 v5, v5, 0x2

    iput v5, v2, Lcom/zego/ve/VCam;->mFrameRate:I

    :goto_8
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "s:s|lbra pe"

    const-string/jumbo v5, "p:sl  r|eas"

    const-string v5, " lpf:su| ar"

    const-string/jumbo v5, "real fps:| "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Landroid/util/Range;->getLower()Ljava/lang/Comparable;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Landroid/util/Range;->getUpper()Ljava/lang/Comparable;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v3, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x0

    return v1
.end method
