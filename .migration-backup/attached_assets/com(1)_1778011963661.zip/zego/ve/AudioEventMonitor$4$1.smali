.class Lcom/zego/ve/AudioEventMonitor$4$1;
.super Landroid/telephony/PhoneStateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/AudioEventMonitor$4;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/zego/ve/AudioEventMonitor$4;


# direct methods
.method constructor <init>(Lcom/zego/ve/AudioEventMonitor$4;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor$4$1;->this$1:Lcom/zego/ve/AudioEventMonitor$4;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/telephony/PhoneStateListener;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onCallStateChanged(ILjava/lang/String;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "-bsi@~ @  ~o~~ ~l~ ~di@~@@o@~n@~acb/ ~ ~b~ t@ yf~/r o~m. Kf@ ~@@ ~1l @~@~~s@MoSo@~@@4 @vi@out~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    invoke-super {p0, p1, p2}, Landroid/telephony/PhoneStateListener;->onCallStateChanged(ILjava/lang/String;)V

    const/4 v4, 0x4

    move v5, v4

    iget-object p2, p0, Lcom/zego/ve/AudioEventMonitor$4$1;->this$1:Lcom/zego/ve/AudioEventMonitor$4;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object p2, p2, Lcom/zego/ve/AudioEventMonitor$4;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v4, 0x5

    move v5, v4

    invoke-static {p2}, Lcom/zego/ve/AudioEventMonitor;->access$100(Lcom/zego/ve/AudioEventMonitor;)Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    monitor-enter p2

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor$4$1;->this$1:Lcom/zego/ve/AudioEventMonitor$4;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, v0, Lcom/zego/ve/AudioEventMonitor$4;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v1, v0, Lcom/zego/ve/AudioEventMonitor;->event_notify_:Lcom/zego/ve/AudioEventMonitor$IEventNotify;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_3

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    if-eq p1, v2, :cond_1

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v3, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eq p1, v3, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput-boolean v2, v0, Lcom/zego/ve/AudioEventMonitor;->_isCalling:Z

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {v1}, Lcom/zego/ve/AudioEventMonitor$IEventNotify;->OnInterruptionBegin()V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput-boolean v2, v0, Lcom/zego/ve/AudioEventMonitor;->_isCalling:Z

    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-interface {v1}, Lcom/zego/ve/AudioEventMonitor$IEventNotify;->OnInterruptionBegin()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x0

    iget-boolean p1, v0, Lcom/zego/ve/AudioEventMonitor;->_isCalling:Z

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz p1, :cond_3

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iput-boolean v2, v0, Lcom/zego/ve/AudioEventMonitor;->_once_call_come_in:Z

    const/4 v5, 0x6

    const/4 p1, 0x3

    const/4 v5, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x2

    iput-boolean p1, v0, Lcom/zego/ve/AudioEventMonitor;->_isCalling:Z

    const/4 v5, 0x2

    invoke-interface {v1}, Lcom/zego/ve/AudioEventMonitor$IEventNotify;->OnInterruptionEnd()V

    :cond_3
    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    monitor-exit p2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    throw p1
.end method
