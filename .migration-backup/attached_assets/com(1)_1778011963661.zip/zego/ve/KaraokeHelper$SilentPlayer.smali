.class public Lcom/zego/ve/KaraokeHelper$SilentPlayer;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/KaraokeHelper;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "SilentPlayer"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;
    }
.end annotation


# instance fields
.field private mAudioFormat:I

.field private mChannelConfig:I

.field private mIsPlaying:Z

.field private mPlaybackThread:Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;

.field private mSampleRate:I

.field final synthetic this$0:Lcom/zego/ve/KaraokeHelper;


# direct methods
.method public constructor <init>(Lcom/zego/ve/KaraokeHelper;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->this$0:Lcom/zego/ve/KaraokeHelper;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    const/16 p1, 0xc

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mChannelConfig:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 p1, 0x0

    const/4 p1, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput p1, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mAudioFormat:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mIsPlaying:Z

    const/4 v1, 0x0

    iput p2, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mSampleRate:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic access$000(Lcom/zego/ve/KaraokeHelper$SilentPlayer;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  s~so~@~ /~~MoaK~@~@  ~~ i@@Soco~rlo-fm ~b~in@~  @1@ @4@@yuit@l ~@d ~b.~to@@~ @ @~b@~ ~v/f  @@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget p0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mSampleRate:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic access$100(Lcom/zego/ve/KaraokeHelper$SilentPlayer;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget p0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mChannelConfig:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic access$200(Lcom/zego/ve/KaraokeHelper$SilentPlayer;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget p0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mAudioFormat:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p0
.end method


# virtual methods
.method public isPlaying()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-boolean v0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mIsPlaying:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public play()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mIsPlaying:Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mPlaybackThread:Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mIsPlaying:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;-><init>(Lcom/zego/ve/KaraokeHelper$SilentPlayer;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mPlaybackThread:Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public stop()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mPlaybackThread:Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    iput-boolean v1, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mIsPlaying:Z

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;->closeThread()V

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mPlaybackThread:Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-wide/16 v1, 0xc8

    const-wide/16 v1, 0xc8

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/lang/Thread;->join(J)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/zego/ve/KaraokeHelper$SilentPlayer;->mPlaybackThread:Lcom/zego/ve/KaraokeHelper$SilentPlayer$PlaybackThread;

    :cond_0
    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method
