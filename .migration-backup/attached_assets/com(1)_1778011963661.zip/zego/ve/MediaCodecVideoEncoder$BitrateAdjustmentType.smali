.class public final enum Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/MediaCodecVideoEncoder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "BitrateAdjustmentType"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

.field public static final enum DYNAMIC_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

.field public static final enum FRAMERATE_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

.field public static final enum NO_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v0, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string v1, "TTsE_ANSDJsMN"

    const-string v1, "NDs_OJSTMENAT"

    const/4 v8, 0x6

    const-string v1, "METmSAUDN_TNJ"

    const-string v1, "NO_ADJUSTMENT"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v2, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-direct {v0, v1, v2}, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    sput-object v0, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->NO_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v1, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v7, 0x0

    or-int/2addr v8, v7

    const-string v3, "MRFToAEDTMJNSE_TAmAR"

    const-string v3, "TAEmTARSMR_EDAFJTNMU"

    const/4 v8, 0x5

    const-string v3, "RMEAEbTDJTURFASNAEMT"

    const-string v3, "FRAMERATE_ADJUSTMENT"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v4, 0x1

    const/4 v8, 0x5

    invoke-direct {v1, v3, v4}, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    sput-object v1, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->FRAMERATE_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-instance v3, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string v5, "YUNMoMuEDAN_ACDITS"

    const-string v5, "ANEAoTI_YDUSMDTNCM"

    const/4 v8, 0x2

    const-string v5, "AUNASCTpDJENTIYD_M"

    const-string v5, "DYNAMIC_ADJUSTMENT"

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/4 v6, 0x2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {v3, v5, v6}, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    sput-object v3, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->DYNAMIC_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v5, 0x3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-array v5, v5, [Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v7, 0x6

    move v8, v7

    aput-object v0, v5, v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    aput-object v1, v5, v4

    const/4 v8, 0x6

    aput-object v3, v5, v6

    const/4 v8, 0x7

    const/4 v7, 0x4

    sput-object v5, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->$VALUES:[Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const-class v0, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const-class v0, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v2, 0x5

    const-class v0, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p0, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v1, 0x0

    move v2, v1

    return-object p0
.end method

.method public static values()[Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->$VALUES:[Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, [Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast v0, [Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method
