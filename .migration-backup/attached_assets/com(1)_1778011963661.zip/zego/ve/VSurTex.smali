.class public Lcom/zego/ve/VSurTex;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;


# static fields
.field private static final TAG:Ljava/lang/String; = "VSurTex"


# instance fields
.field private mLock:Ljava/lang/Object;

.field private mSt:Landroid/graphics/SurfaceTexture;

.field private pthis:J


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/zego/ve/VSurTex;->pthis:J

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/zego/ve/VSurTex;->mSt:Landroid/graphics/SurfaceTexture;

    const/4 v2, 0x3

    move v3, v2

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/zego/ve/VSurTex;->mLock:Ljava/lang/Object;

    const/4 v2, 0x3

    or-int/2addr v3, v2

    return-void
.end method

.method private static native on_frame(JI)I
.end method


# virtual methods
.method public create(JI)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " os@ofK~o uf @@~~c@asd~ / i@.@@t~4~@~y1@~~b b~~ Sb@ M m@@ o~@-t~~~l~@ i@ ~~~/i @n@ v~~r@  lo@~o@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iput-wide p1, p0, Lcom/zego/ve/VSurTex;->pthis:J

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    new-instance p1, Landroid/graphics/SurfaceTexture;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p1, p3}, Landroid/graphics/SurfaceTexture;-><init>(I)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/zego/ve/VSurTex;->mSt:Landroid/graphics/SurfaceTexture;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p1, p0}, Landroid/graphics/SurfaceTexture;->setOnFrameAvailableListener(Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/zego/ve/VSurTex;->mSt:Landroid/graphics/SurfaceTexture;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return p1
.end method

.method public destroy()V
    .locals 5

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/VSurTex;->mLock:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    monitor-enter v0

    const/4 v4, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-wide v1, p0, Lcom/zego/ve/VSurTex;->pthis:J

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/ve/VSurTex;->mSt:Landroid/graphics/SurfaceTexture;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Landroid/graphics/SurfaceTexture;->setOnFrameAvailableListener(Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/VSurTex;->mSt:Landroid/graphics/SurfaceTexture;

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/graphics/SurfaceTexture;->release()V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput-object v1, p0, Lcom/zego/ve/VSurTex;->mSt:Landroid/graphics/SurfaceTexture;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void

    :catchall_0
    move-exception v1

    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    throw v1
.end method

.method public get()Landroid/graphics/SurfaceTexture;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/ve/VSurTex;->mSt:Landroid/graphics/SurfaceTexture;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public onFrameAvailable(Landroid/graphics/SurfaceTexture;)V
    .locals 7

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/zego/ve/VSurTex;->mLock:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    monitor-enter v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-wide v1, p0, Lcom/zego/ve/VSurTex;->pthis:J

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    cmp-long v3, v1, v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v1, v2, p1}, Lcom/zego/ve/VSurTex;->on_frame(JI)I

    const/4 v5, 0x7

    move v6, v5

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string/jumbo p1, "rSsmeTu"

    const-string/jumbo p1, "uTsrSxe"

    const/4 v6, 0x6

    const-string/jumbo p1, "uSrVoex"

    const-string p1, "VSurTex"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string/jumbo v1, "rle abonblmcc:gk"

    const-string v1, "aoem gnrkl:lcbca"

    const/4 v6, 0x0

    const-string v1, "a:orceuckba glln"

    const-string/jumbo v1, "ignore callback:"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p1, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    monitor-exit v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v5, 0x5

    move v6, v5

    throw p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    return-void
.end method
