.class public Lcom/zego/ve/VImageReader;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/media/ImageReader$OnImageAvailableListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/VImageReader$ImageReaderBuffer;,
        Lcom/zego/ve/VImageReader$ImageReaderFormat;
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String; = "VImageReader"


# instance fields
.field private mImg:Landroid/media/Image;

.field private mImgRdr:Landroid/media/ImageReader;

.field private mLock:Ljava/lang/Object;

.field private pthis:J


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const/4 v2, 0x2

    move v3, v2

    iput-wide v0, p0, Lcom/zego/ve/VImageReader;->pthis:J

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/zego/ve/VImageReader;->mImgRdr:Landroid/media/ImageReader;

    const/4 v3, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/zego/ve/VImageReader;->mImg:Landroid/media/Image;

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/zego/ve/VImageReader;->mLock:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method private closeImage()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "M~s1 ~-~@ y@ /~i @@~Sn@o@@av~f~  @~f~l~orK~ o~~t~@o@@ o l  u~~t~ ./4i@@@@@@b~~   ~~si~@bbco dm@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/zego/ve/VImageReader;->mImg:Landroid/media/Image;

    const/4 v1, 0x6

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/media/Image;->close()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method private getImageReaderBuffer()Lcom/zego/ve/VImageReader$ImageReaderBuffer;
    .locals 8

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/zego/ve/VImageReader;->mImgRdr:Landroid/media/ImageReader;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroid/media/ImageReader;->acquireLatestImage()Landroid/media/Image;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    iput-object v0, p0, Lcom/zego/ve/VImageReader;->mImg:Landroid/media/Image;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string/jumbo v1, "gmsmRVedIree"

    const-string v1, "emsVgReeIadr"

    const/4 v7, 0x4

    const-string v1, "aeeroVRgadeI"

    const-string v1, "VImageReader"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v0, :cond_1

    :try_start_1
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/zego/ve/VImageReader;->mImg:Landroid/media/Image;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v2}, Landroid/media/Image;->getTimestamp()J

    move-result-wide v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    array-length v4, v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v5, 0x1

    const/4 v7, 0x4

    if-le v4, v5, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    new-instance v1, Lcom/zego/ve/VImageReader$ImageReaderBuffer;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {v1, v0, v2, v3}, Lcom/zego/ve/VImageReader$ImageReaderBuffer;-><init>([Landroid/media/Image$Plane;J)V

    const/4 v7, 0x7

    return-object v1

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string/jumbo v0, "ige lbsoetabic nsmmcsae"

    const-string/jumbo v0, "maimteeglscs nisbaoce  "

    const/4 v7, 0x0

    const-string/jumbo v0, "saiomiuastcaeelbsg e  c"

    const-string/jumbo v0, "image is not accessable"

    const/4 v7, 0x0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const-string v0, " cme irpe ioer anefguimulrgqaamo lade"

    const-string v0, "damlofolm re ci  rdrmeiieneaqueua gga"

    const/4 v7, 0x7

    const-string/jumbo v0, "u e dagrqidqiearlfanmemr rg aoeiul ec"

    const-string v0, "acquired null image from image reader"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    return-object v0
.end method

.method private getImageReaderFormat()Lcom/zego/ve/VImageReader$ImageReaderFormat;
    .locals 6

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/VImageReader;->mImgRdr:Landroid/media/ImageReader;

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/media/ImageReader;->acquireLatestImage()Landroid/media/Image;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/zego/ve/VImageReader;->mImg:Landroid/media/Image;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v1, "easedbRVIema"

    const-string/jumbo v1, "geIambeeaVdR"

    const/4 v5, 0x4

    const-string/jumbo v1, "mdRmeaVereIg"

    const-string v1, "VImageReader"

    const/4 v4, 0x2

    move v5, v4

    if-eqz v0, :cond_1

    :try_start_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    array-length v2, v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-le v2, v3, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v1, Lcom/zego/ve/VImageReader$ImageReaderFormat;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/zego/ve/VImageReader;->mImg:Landroid/media/Image;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v2}, Landroid/media/Image;->getWidth()I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/zego/ve/VImageReader;->mImg:Landroid/media/Image;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v3}, Landroid/media/Image;->getHeight()I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v1, v2, v3, v0}, Lcom/zego/ve/VImageReader$ImageReaderFormat;-><init>(II[Landroid/media/Image$Plane;)V

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-object v1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v0, "eonco mig st bsaseiuace"

    const-string v0, "ec seauet cmiasona sbig"

    const/4 v5, 0x1

    const-string/jumbo v0, "image is not accessable"

    const/4 v5, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const-string/jumbo v0, "mauicfopaiediranrrmgeal   gd me uqeel"

    const/4 v5, 0x1

    const-string/jumbo v0, "mmaedbal dron eariueger lgicquiemra f"

    const-string v0, "acquired null image from image reader"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-object v0
.end method

.method private static native on_image(JI)I
.end method


# virtual methods
.method public create(JII)I
    .locals 2

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/zego/ve/VImageReader;->pthis:J

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/16 p1, 0x23

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 p2, 0x2

    :try_start_0
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p3, p4, p1, p2}, Landroid/media/ImageReader;->newInstance(IIII)Landroid/media/ImageReader;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/zego/ve/VImageReader;->mImgRdr:Landroid/media/ImageReader;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    const/4 p2, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1, p0, p2}, Landroid/media/ImageReader;->setOnImageAvailableListener(Landroid/media/ImageReader$OnImageAvailableListener;Landroid/os/Handler;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v1, 0x6

    iget-object p1, p0, Lcom/zego/ve/VImageReader;->mImgRdr:Landroid/media/ImageReader;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-nez p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p1, -0x1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    goto :goto_1

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    :goto_1
    const/4 v1, 0x3

    const/4 v0, 0x7

    return p1
.end method

.method public destroy()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/VImageReader;->mLock:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    monitor-enter v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    :try_start_0
    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-wide v1, p0, Lcom/zego/ve/VImageReader;->pthis:J

    const/4 v3, 0x5

    move v4, v3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/ve/VImageReader;->mImg:Landroid/media/Image;

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x1

    move v3, v1

    move v3, v1

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/media/Image;->close()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/zego/ve/VImageReader;->mImg:Landroid/media/Image;

    :cond_0
    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/VImageReader;->mImgRdr:Landroid/media/ImageReader;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v1}, Landroid/media/ImageReader;->setOnImageAvailableListener(Landroid/media/ImageReader$OnImageAvailableListener;Landroid/os/Handler;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/VImageReader;->mImgRdr:Landroid/media/ImageReader;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/media/ImageReader;->close()V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/zego/ve/VImageReader;->mImgRdr:Landroid/media/ImageReader;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void

    :catchall_0
    move-exception v1

    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    throw v1
.end method

.method public get()Landroid/media/ImageReader;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/ve/VImageReader;->mImgRdr:Landroid/media/ImageReader;

    const/4 v2, 0x3

    return-object v0
.end method

.method public onImageAvailable(Landroid/media/ImageReader;)V
    .locals 7

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/zego/ve/VImageReader;->mLock:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    monitor-enter v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-wide v1, p0, Lcom/zego/ve/VImageReader;->pthis:J

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x5

    const-wide/16 v3, 0x0

    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    cmp-long v3, v1, v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v1, v2, p1}, Lcom/zego/ve/VImageReader;->on_image(JI)I

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string p1, "egRareuIqmVa"

    const-string/jumbo p1, "megIrRVdqaae"

    const-string p1, "aegmeadprIVR"

    const-string p1, "VImageReader"

    const/4 v5, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v1, "lera ns:qlcakbio"

    const-string v1, "clsaabec:lrkion "

    const/4 v6, 0x1

    const-string v1, "ebslcarcola:gki "

    const-string/jumbo v1, "ignore callback:"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {p1, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    const/4 v6, 0x1

    monitor-exit v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    throw p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    move-exception p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-void
.end method
