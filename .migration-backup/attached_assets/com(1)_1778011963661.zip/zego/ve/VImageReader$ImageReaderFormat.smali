.class Lcom/zego/ve/VImageReader$ImageReaderFormat;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/VImageReader;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ImageReaderFormat"
.end annotation


# instance fields
.field height:I

.field uvPixelStride:I

.field uvStride:I

.field width:I

.field yStride:I


# direct methods
.method public constructor <init>(II[Landroid/media/Image$Plane;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lcom/zego/ve/VImageReader$ImageReaderFormat;->width:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput p2, p0, Lcom/zego/ve/VImageReader$ImageReaderFormat;->height:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    aget-object p1, p3, p1

    const/4 v1, 0x1

    invoke-virtual {p1}, Landroid/media/Image$Plane;->getRowStride()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p1, p0, Lcom/zego/ve/VImageReader$ImageReaderFormat;->yStride:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    aget-object p2, p3, p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p2}, Landroid/media/Image$Plane;->getRowStride()I

    move-result p2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p2, p0, Lcom/zego/ve/VImageReader$ImageReaderFormat;->uvStride:I

    const/4 v0, 0x4

    xor-int/2addr v1, v0

    aget-object p1, p3, p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroid/media/Image$Plane;->getPixelStride()I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p1, p0, Lcom/zego/ve/VImageReader$ImageReaderFormat;->uvPixelStride:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method
