.class Lcom/zego/ve/FeatureKitManager;
.super Ljava/lang/Object;


# static fields
.field private static final BIND_SERVICE_LOCK:Ljava/lang/Object;

.field private static final NEW_FEATUREMANAGER_LOCK:Ljava/lang/Object;

.field private static final SET_CALL_BACK_LOCK:Ljava/lang/Object;

.field private static final UNBIND_SERVICE_LOCK:Ljava/lang/Object;

.field private static sInstance:Lcom/zego/ve/FeatureKitManager;


# instance fields
.field private mCallBack:Lcom/zego/ve/IAudioKitCallback;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    sput-object v0, Lcom/zego/ve/FeatureKitManager;->SET_CALL_BACK_LOCK:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    sput-object v0, Lcom/zego/ve/FeatureKitManager;->NEW_FEATUREMANAGER_LOCK:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    sput-object v0, Lcom/zego/ve/FeatureKitManager;->BIND_SERVICE_LOCK:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x7

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    sput-object v0, Lcom/zego/ve/FeatureKitManager;->UNBIND_SERVICE_LOCK:Ljava/lang/Object;

    const/4 v1, 0x0

    or-int/2addr v2, v1

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/zego/ve/FeatureKitManager;->mCallBack:Lcom/zego/ve/IAudioKitCallback;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method protected static getInstance()Lcom/zego/ve/FeatureKitManager;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s@@m @~rt o  u@l@t  ~~@@4cs~@ ~o@b@ SoMif~n~o/ ~ @db~y1@@@i~ @~. ~@~~  ~ @i~@b~@a@o~l/-~oK ~~v"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lcom/zego/ve/FeatureKitManager;->NEW_FEATUREMANAGER_LOCK:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object v1, Lcom/zego/ve/FeatureKitManager;->sInstance:Lcom/zego/ve/FeatureKitManager;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v1, Lcom/zego/ve/FeatureKitManager;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v1}, Lcom/zego/ve/FeatureKitManager;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    sput-object v1, Lcom/zego/ve/FeatureKitManager;->sInstance:Lcom/zego/ve/FeatureKitManager;

    :cond_0
    const/4 v3, 0x5

    sget-object v1, Lcom/zego/ve/FeatureKitManager;->sInstance:Lcom/zego/ve/FeatureKitManager;

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    throw v1
.end method


# virtual methods
.method protected bindService(Landroid/content/Context;Landroid/content/ServiceConnection;Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    sget-object v0, Lcom/zego/ve/FeatureKitManager;->BIND_SERVICE_LOCK:Ljava/lang/Object;

    const/4 v3, 0x5

    shr-int/2addr v4, v3

    monitor-enter v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v2, "eiemaidwlionida.uoimg.mcmuhts.nae"

    const-string/jumbo v2, "owsgdimm.duancumol.uiaiahee.nieit"

    const/4 v4, 0x6

    const-string/jumbo v2, "imi.ogld.ooehceieaimna.udtuauniwe"

    const-string v2, "com.huawei.multimedia.audioengine"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1, v2, p3}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 p3, 0x1

    xor-int/2addr v4, p3

    :try_start_1
    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {p1, v1, p2, p3}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    :try_end_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    :cond_0
    :try_start_2
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    throw p1
.end method

.method protected createFeatureKit(ILandroid/content/Context;)Lcom/zego/ve/HwAudioKaraokeFeatureKit;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eq p1, v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x5

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance p1, Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p1, p2}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->initialize(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p1
.end method

.method protected getCallBack()Lcom/zego/ve/IAudioKitCallback;
    .locals 3

    iget-object v0, p0, Lcom/zego/ve/FeatureKitManager;->mCallBack:Lcom/zego/ve/IAudioKitCallback;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method protected isMediaKitSupport(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz p1, :cond_1

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v1, "dmanobhiwmauieeinil.eouiagd.mcum."

    const-string/jumbo v1, "i.gmeiueoatu.mncilaodiuwnma.mehid"

    const/4 v3, 0x0

    const-string v1, "aeaeniunumweicmuemddl.g.houiioa.i"

    const-string v1, "com.huawei.multimedia.audioengine"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1, v1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez p1, :cond_1

    :catch_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v0

    :cond_1
    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v3, 0x2

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    return p1
.end method

.method protected onCallBack(I)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v0, Lcom/zego/ve/FeatureKitManager;->SET_CALL_BACK_LOCK:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/zego/ve/FeatureKitManager;->getCallBack()Lcom/zego/ve/IAudioKitCallback;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/zego/ve/FeatureKitManager;->getCallBack()Lcom/zego/ve/IAudioKitCallback;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {v1, p1}, Lcom/zego/ve/IAudioKitCallback;->onResult(I)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    throw p1
.end method

.method protected setCallBack(Lcom/zego/ve/IAudioKitCallback;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/zego/ve/FeatureKitManager;->mCallBack:Lcom/zego/ve/IAudioKitCallback;

    const/4 v1, 0x3

    const/4 v0, 0x3

    return-void
.end method

.method protected unbindService(Landroid/content/Context;Landroid/content/ServiceConnection;)V
    .locals 3

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/zego/ve/FeatureKitManager;->UNBIND_SERVICE_LOCK:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    monitor-enter v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    monitor-exit v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    throw p1
.end method
