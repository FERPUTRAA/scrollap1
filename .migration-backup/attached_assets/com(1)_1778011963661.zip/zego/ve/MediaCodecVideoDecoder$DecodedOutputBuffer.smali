.class Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/MediaCodecVideoDecoder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "DecodedOutputBuffer"
.end annotation


# instance fields
.field private buffer:Ljava/nio/ByteBuffer;

.field private final eos:Z

.field public final formatChanged:Z

.field private final index:I

.field private isI420:Z

.field private final presentationTimeStampUs:J

.field private uBuffer:Ljava/nio/ByteBuffer;

.field private uStride:I

.field private vBuffer:Ljava/nio/ByteBuffer;

.field private vStride:I

.field private yBuffer:Ljava/nio/ByteBuffer;

.field private yStride:I


# direct methods
.method public constructor <init>(ILjava/nio/ByteBuffer;JZZ)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->index:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->buffer:Ljava/nio/ByteBuffer;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-wide p3, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->presentationTimeStampUs:J

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-boolean p5, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->formatChanged:Z

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-boolean p6, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->eos:Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(ILjava/nio/ByteBuffer;Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;IIIZJZZ)V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    iput p1, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->index:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->yBuffer:Ljava/nio/ByteBuffer;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->uBuffer:Ljava/nio/ByteBuffer;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p4, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->vBuffer:Ljava/nio/ByteBuffer;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p5, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->yStride:I

    const/4 v1, 0x4

    iput p6, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->uStride:I

    const/4 v0, 0x3

    move v1, v0

    iput p7, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->vStride:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-wide p9, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->presentationTimeStampUs:J

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p11, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->formatChanged:Z

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-boolean p12, p0, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;->eos:Z

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method
