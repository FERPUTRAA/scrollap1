.class Lcom/zego/zegoavkit2/receiver/Background$Listeners;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/zegoavkit2/receiver/Background;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "Listeners"
.end annotation


# instance fields
.field private listeners:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/ref/WeakReference<",
            "Lcom/zego/zegoavkit2/receiver/Background$Listener;",
            ">;>;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->listeners:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method synthetic constructor <init>(Lcom/zego/zegoavkit2/receiver/Background$1;)V
    .locals 2

    const/4 v0, 0x4

    move v1, v0

    invoke-direct {p0}, Lcom/zego/zegoavkit2/receiver/Background$Listeners;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lcom/zego/zegoavkit2/receiver/Background$Listeners;)Ljava/util/List;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o s@f @@~~~n~K  l f@b@a dt@@  ~ ~-b ~~.s@iy lirc~@@~o @~o@~~ @v~ ~@/~4u@~1m@i@@/ S@o@o~b ~~~to M"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->listeners:Ljava/util/List;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method


# virtual methods
.method public add(Lcom/zego/zegoavkit2/receiver/Background$Listener;)Lcom/zego/zegoavkit2/receiver/Background$Binding;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "listener"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->listeners:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance p1, Lcom/zego/zegoavkit2/receiver/Background$Listeners$1;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p1, p0, v0}, Lcom/zego/zegoavkit2/receiver/Background$Listeners$1;-><init>(Lcom/zego/zegoavkit2/receiver/Background$Listeners;Ljava/lang/ref/WeakReference;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p1
.end method

.method public each(Lcom/zego/zegoavkit2/receiver/Background$Callback;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "callback"
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->listeners:Ljava/util/List;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v2, :cond_1

    :try_start_0
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    check-cast v2, Ljava/lang/ref/WeakReference;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast v3, Lcom/zego/zegoavkit2/receiver/Background$Listener;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {p1, v3}, Lcom/zego/zegoavkit2/receiver/Background$Callback;->invoke(Lcom/zego/zegoavkit2/receiver/Background$Listener;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto :goto_0

    :catch_0
    move-exception v2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v3, "nrumrictoodMgakon"

    const-string v3, "BackgroundMonitor"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo v4, "poreot!n siiterwLe nhsece"

    const-string v4, "eisreLntphex!nieor cswet "

    const/4 v6, 0x0

    const-string v4, "cwrL!benetneeeoii  htstrp"

    const-string v4, "Listener threw exception!"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v3, v4, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-nez p1, :cond_2

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->listeners:Ljava/util/List;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {p1, v0}, Ljava/util/List;->removeAll(Ljava/util/Collection;)Z

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    return-void
.end method
