.class Lcom/zego/zegoavkit2/receiver/Background;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/zegoavkit2/receiver/Background$Listeners;,
        Lcom/zego/zegoavkit2/receiver/Background$Callback;,
        Lcom/zego/zegoavkit2/receiver/Background$Binding;,
        Lcom/zego/zegoavkit2/receiver/Background$Listener;
    }
.end annotation


# static fields
.field private static final CHECK_DELAY:J = 0xaL

.field public static final TAG:Ljava/lang/String; = "BackgroundMonitor"

.field private static becameBackground:Lcom/zego/zegoavkit2/receiver/Background$Callback;

.field private static becameForeground:Lcom/zego/zegoavkit2/receiver/Background$Callback;

.field private static instance:Lcom/zego/zegoavkit2/receiver/Background;


# instance fields
.field private application:Landroid/app/Application;

.field private background:Z

.field private isInit:Z

.field private listeners:Lcom/zego/zegoavkit2/receiver/Background$Listeners;

.field private lock:Ljava/util/concurrent/locks/Lock;

.field private pageList:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private pagePauseList:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Lcom/zego/zegoavkit2/receiver/Background$1;

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/zego/zegoavkit2/receiver/Background$1;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    sput-object v0, Lcom/zego/zegoavkit2/receiver/Background;->becameForeground:Lcom/zego/zegoavkit2/receiver/Background$Callback;

    const/4 v2, 0x3

    new-instance v0, Lcom/zego/zegoavkit2/receiver/Background$2;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/zego/zegoavkit2/receiver/Background$2;-><init>()V

    const/4 v2, 0x5

    sput-object v0, Lcom/zego/zegoavkit2/receiver/Background;->becameBackground:Lcom/zego/zegoavkit2/receiver/Background$Callback;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance v0, Lcom/zego/zegoavkit2/receiver/Background;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/zego/zegoavkit2/receiver/Background;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    sput-object v0, Lcom/zego/zegoavkit2/receiver/Background;->instance:Lcom/zego/zegoavkit2/receiver/Background;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Lcom/zego/zegoavkit2/receiver/Background$Listeners;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/zego/zegoavkit2/receiver/Background$Listeners;-><init>(Lcom/zego/zegoavkit2/receiver/Background$1;)V

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->listeners:Lcom/zego/zegoavkit2/receiver/Background$Listeners;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x3

    move v3, v2

    iput-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->isInit:Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Ljava/util/HashSet;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pageList:Ljava/util/Set;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Ljava/util/HashSet;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pagePauseList:Ljava/util/Set;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    const/4 v2, 0x7

    xor-int/2addr v3, v2

    iput-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x0

    return-void
.end method

.method private checkBackground()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "fms@Ko @ ~@~n~-si/l@bd S1~~o ~@~@~y@bf @@~@  @4@t~  r~ ~~@~o@ /oo~~otc v~b @@l .   ~a~iiMu~@@@~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->application:Landroid/app/Application;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->application:Landroid/app/Application;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v1, "tsvmitci"

    const-string/jumbo v1, "tiscitav"

    const/4 v3, 0x1

    const-string/jumbo v1, "iatcoitv"

    const-string v1, "activity"

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast v0, Landroid/app/ActivityManager;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Landroid/app/ActivityManager$RunningAppProcessInfo;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0}, Landroid/app/ActivityManager$RunningAppProcessInfo;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0}, Landroid/app/ActivityManager;->getMyMemoryState(Landroid/app/ActivityManager$RunningAppProcessInfo;)V

    const/4 v3, 0x0

    iget v0, v0, Landroid/app/ActivityManager$RunningAppProcessInfo;->importance:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/16 v1, 0x64

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eq v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/16 v1, 0xc8

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v0

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public static get()Lcom/zego/zegoavkit2/receiver/Background;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lcom/zego/zegoavkit2/receiver/Background;->instance:Lcom/zego/zegoavkit2/receiver/Background;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method private handleActivityOpen(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "hashCode"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pageList:Ljava/util/Set;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pageList:Ljava/util/Set;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-boolean p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-boolean p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    iget-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->listeners:Lcom/zego/zegoavkit2/receiver/Background$Listeners;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lcom/zego/zegoavkit2/receiver/Background;->becameForeground:Lcom/zego/zegoavkit2/receiver/Background$Callback;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->each(Lcom/zego/zegoavkit2/receiver/Background$Callback;)V

    :cond_0
    const/4 v3, 0x4

    return-void
.end method

.method private handleActivityPause(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "hashCode"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pagePauseList:Ljava/util/Set;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pagePauseList:Ljava/util/Set;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method private handleActivityStop(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "hashCode"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pageList:Ljava/util/Set;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pageList:Ljava/util/Set;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {v0, v3}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pageList:Ljava/util/Set;

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v5, 0x3

    if-nez v0, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput-boolean v1, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->listeners:Lcom/zego/zegoavkit2/receiver/Background$Listeners;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    sget-object v1, Lcom/zego/zegoavkit2/receiver/Background;->becameBackground:Lcom/zego/zegoavkit2/receiver/Background$Callback;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->each(Lcom/zego/zegoavkit2/receiver/Background$Callback;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v5, 0x2

    if-eqz v0, :cond_3

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput-boolean v2, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v5, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->listeners:Lcom/zego/zegoavkit2/receiver/Background$Listeners;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget-object v1, Lcom/zego/zegoavkit2/receiver/Background;->becameForeground:Lcom/zego/zegoavkit2/receiver/Background$Callback;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->each(Lcom/zego/zegoavkit2/receiver/Background$Callback;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pageList:Ljava/util/Set;

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pagePauseList:Ljava/util/Set;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v0, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v5, 0x7

    if-nez v0, :cond_3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-boolean v1, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->listeners:Lcom/zego/zegoavkit2/receiver/Background$Listeners;

    const/4 v5, 0x4

    sget-object v1, Lcom/zego/zegoavkit2/receiver/Background;->becameBackground:Lcom/zego/zegoavkit2/receiver/Background$Callback;

    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {v0, v1}, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->each(Lcom/zego/zegoavkit2/receiver/Background$Callback;)V

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v0, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput-boolean v2, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->listeners:Lcom/zego/zegoavkit2/receiver/Background$Listeners;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v1, Lcom/zego/zegoavkit2/receiver/Background;->becameForeground:Lcom/zego/zegoavkit2/receiver/Background$Callback;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->each(Lcom/zego/zegoavkit2/receiver/Background$Callback;)V

    :cond_3
    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pagePauseList:Ljava/util/Set;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void
.end method


# virtual methods
.method public addListener(Lcom/zego/zegoavkit2/receiver/Background$Listener;)Lcom/zego/zegoavkit2/receiver/Background$Binding;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "listener"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->listeners:Lcom/zego/zegoavkit2/receiver/Background$Listeners;

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->add(Lcom/zego/zegoavkit2/receiver/Background$Listener;)Lcom/zego/zegoavkit2/receiver/Background$Binding;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p1
.end method

.method public init(Landroid/app/Application;)Lcom/zego/zegoavkit2/receiver/Background;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "app"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/zego/zegoavkit2/receiver/Background;->uninit()Lcom/zego/zegoavkit2/receiver/Background;

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->application:Landroid/app/Application;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p1, p0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/zego/zegoavkit2/receiver/Background;->checkBackground()Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-boolean p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-boolean p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->isInit:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x3

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0

    :catchall_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    throw p1
.end method

.method public isBackground()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public isForeground()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->background:Z

    const/4 v2, 0x2

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    return v0
.end method

.method public isInited()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->isInit:Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "activity",
            "savedInstanceState"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    iget-object p2, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v1, 0x2

    const/4 v0, 0x4

    invoke-interface {p2}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-boolean p2, p0, Lcom/zego/zegoavkit2/receiver/Background;->isInit:Z

    const/4 v0, 0x2

    move v1, v0

    if-eqz p2, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/zego/zegoavkit2/receiver/Background;->handleActivityOpen(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-interface {p2}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    throw p1
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "activity"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->isInit:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Lcom/zego/zegoavkit2/receiver/Background;->handleActivityStop(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v1, 0x1

    and-int/2addr v2, v1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    throw p1
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "activity"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->isInit:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    invoke-direct {p0, p1}, Lcom/zego/zegoavkit2/receiver/Background;->handleActivityPause(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    throw p1
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "activity"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->isInit:Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/zego/zegoavkit2/receiver/Background;->handleActivityOpen(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    throw p1
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "activity",
            "outState"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "activity"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->isInit:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    move v2, v1

    invoke-direct {p0, p1}, Lcom/zego/zegoavkit2/receiver/Background;->handleActivityOpen(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    throw p1
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "activity"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->isInit:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Lcom/zego/zegoavkit2/receiver/Background;->handleActivityStop(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    throw p1
.end method

.method public uninit()Lcom/zego/zegoavkit2/receiver/Background;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->application:Landroid/app/Application;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->application:Landroid/app/Application;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pageList:Ljava/util/Set;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->pagePauseList:Ljava/util/Set;

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-boolean v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->isInit:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p0

    :catchall_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/zego/zegoavkit2/receiver/Background;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw v0
.end method
