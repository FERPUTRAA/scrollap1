.class Lcom/zego/zegoavkit2/receiver/Background$Listeners$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/zego/zegoavkit2/receiver/Background$Binding;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/zegoavkit2/receiver/Background$Listeners;->add(Lcom/zego/zegoavkit2/receiver/Background$Listener;)Lcom/zego/zegoavkit2/receiver/Background$Binding;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/zegoavkit2/receiver/Background$Listeners;

.field final synthetic val$wr:Ljava/lang/ref/WeakReference;


# direct methods
.method constructor <init>(Lcom/zego/zegoavkit2/receiver/Background$Listeners;Ljava/lang/ref/WeakReference;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            "this$0",
            "val$wr"
        }
    .end annotation

    iput-object p1, p0, Lcom/zego/zegoavkit2/receiver/Background$Listeners$1;->this$0:Lcom/zego/zegoavkit2/receiver/Background$Listeners;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/zego/zegoavkit2/receiver/Background$Listeners$1;->val$wr:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public unbind()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@sv~l~~b @rtyf~@ o ~@n~@@@~  ~l ~~~@@S~~@f./@i1@   ~~ d@ cb ~M@Ka  @o@oo~~~4@~uoi~m -ts/o @ b@i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/Background$Listeners$1;->this$0:Lcom/zego/zegoavkit2/receiver/Background$Listeners;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/zego/zegoavkit2/receiver/Background$Listeners;->access$000(Lcom/zego/zegoavkit2/receiver/Background$Listeners;)Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/zego/zegoavkit2/receiver/Background$Listeners$1;->val$wr:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method
