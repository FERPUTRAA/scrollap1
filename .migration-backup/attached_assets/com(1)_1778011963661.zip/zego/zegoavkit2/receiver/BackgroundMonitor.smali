.class public final Lcom/zego/zegoavkit2/receiver/BackgroundMonitor;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/zego/zegoavkit2/receiver/Background$Listener;


# static fields
.field public static final TAG:Ljava/lang/String; = "BackgroundMonitor"


# instance fields
.field private mListenerBinding:Lcom/zego/zegoavkit2/receiver/Background$Binding;

.field private mThis:J


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method

.method static native onBackgroundStatusChanged(JZ)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "pThis",
            "isBackground"
        }
    .end annotation
.end method


# virtual methods
.method public init(Landroid/content/Context;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "context"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s~ ~~o/m~@o~  oK.sf @ ~y~~@-M~~b~4Sltt  ~  /n@ @if~@ v~@~ ir d~@~@@a@ocbi@  ~@@1uo~@ @l~~@@ ~o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    const/4 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v0

    :cond_0
    const/4 v2, 0x5

    instance-of v1, p1, Landroid/app/Application;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {}, Lcom/zego/zegoavkit2/receiver/Background;->get()Lcom/zego/zegoavkit2/receiver/Background;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast p1, Landroid/app/Application;

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lcom/zego/zegoavkit2/receiver/Background;->init(Landroid/app/Application;)Lcom/zego/zegoavkit2/receiver/Background;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, p0}, Lcom/zego/zegoavkit2/receiver/Background;->addListener(Lcom/zego/zegoavkit2/receiver/Background$Listener;)Lcom/zego/zegoavkit2/receiver/Background$Binding;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/zego/zegoavkit2/receiver/BackgroundMonitor;->mListenerBinding:Lcom/zego/zegoavkit2/receiver/Background$Binding;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    return p1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    return v0
.end method

.method public isBackground()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {}, Lcom/zego/zegoavkit2/receiver/Background;->get()Lcom/zego/zegoavkit2/receiver/Background;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/receiver/Background;->isBackground()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public isInited()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/BackgroundMonitor;->mListenerBinding:Lcom/zego/zegoavkit2/receiver/Background$Binding;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-static {}, Lcom/zego/zegoavkit2/receiver/Background;->get()Lcom/zego/zegoavkit2/receiver/Background;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/receiver/Background;->isInited()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public onBecameBackground()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/zego/zegoavkit2/receiver/BackgroundMonitor;->mThis:J

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v0, v1, v2}, Lcom/zego/zegoavkit2/receiver/BackgroundMonitor;->onBackgroundStatusChanged(JZ)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void
.end method

.method public onBecameForeground()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-wide v0, p0, Lcom/zego/zegoavkit2/receiver/BackgroundMonitor;->mThis:J

    const/4 v2, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v0, v1, v2}, Lcom/zego/zegoavkit2/receiver/BackgroundMonitor;->onBackgroundStatusChanged(JZ)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void
.end method

.method public setThis(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "pThis"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-wide p1, p0, Lcom/zego/zegoavkit2/receiver/BackgroundMonitor;->mThis:J

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public uninit()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/receiver/BackgroundMonitor;->mListenerBinding:Lcom/zego/zegoavkit2/receiver/Background$Binding;

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0}, Lcom/zego/zegoavkit2/receiver/Background$Binding;->unbind()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {}, Lcom/zego/zegoavkit2/receiver/Background;->get()Lcom/zego/zegoavkit2/receiver/Background;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/receiver/Background;->uninit()Lcom/zego/zegoavkit2/receiver/Background;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method
