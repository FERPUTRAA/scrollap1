.class public Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$VideoCodecConfig;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "VideoCodecConfig"
.end annotation


# instance fields
.field public codec_type:I

.field public height:I

.field public rotation:I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput v0, p0, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$VideoCodecConfig;->width:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput v0, p0, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$VideoCodecConfig;->height:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput v0, p0, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$VideoCodecConfig;->codec_type:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput v0, p0, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$VideoCodecConfig;->rotation:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method
