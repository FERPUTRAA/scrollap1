.class public Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$ZegoVideoCodecType;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ZegoVideoCodecType"
.end annotation


# static fields
.field public static final ZegoVideoCodecTypeAVCANNEXB:I = 0x1

.field public static final ZegoVideoCodecTypeAVCAVCC:I = 0x0

.field public static final ZegoVideoCodecTypeHEVCANNEXB:I = 0x4

.field public static final ZegoVideoCodecTypeHEVCAVCC:I = 0x3

.field public static final ZegoVideoCodecTypeVP8:I = 0x2


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method
