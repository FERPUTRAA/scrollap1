.class public Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$ZegoVideoFlipMode;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ZegoVideoFlipMode"
.end annotation


# static fields
.field public static final Horizontal:I = 0x1

.field public static final None:I = 0x0

.field public static final Vertical:I = 0x2


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-void
.end method
