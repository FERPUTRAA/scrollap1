.class public Lcom/zego/zegoavkit2/hardwaremonitor/ZegoMEMUtils;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static getAppUsedMemory(Landroid/content/Context;I)D
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "context",
            "pid"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s~@~m~   .-tia@f@~ @@~ ~@ion@~~~/~l@~@1t~ ob ~or@~~lu~@cy   @ @o@s~S~ @bfd @@ ~4~@o ~M Ko biv@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/16 v1, 0x1c

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-ge v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p0, p1}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoMEMUtils;->getPSSFromActivityManager(Landroid/content/Context;I)D

    move-result-wide p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoMEMUtils;->getPSSFromDebug()D

    move-result-wide p0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-wide p0
.end method

.method private static getPSSFromActivityManager(Landroid/content/Context;I)D
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "context",
            "pid"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-ltz p1, :cond_0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    filled-new-array {p1}, [I

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v2, "vttmaiic"

    const-string/jumbo v2, "tasivtci"

    const/4 v4, 0x6

    const-string v2, "aviiotyt"

    const-string v2, "activity"

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0, p1}, Landroid/app/ActivityManager;->getProcessMemoryInfo([I)[Landroid/os/Debug$MemoryInfo;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    aget-object p0, p0, p1

    const/4 v3, 0x5

    shl-int/2addr v4, v3

    invoke-virtual {p0}, Landroid/os/Debug$MemoryInfo;->getTotalPss()I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    int-to-double p0, p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-wide/high16 v0, 0x4090000000000000L    # 1024.0

    const-wide/high16 v0, 0x4090000000000000L    # 1024.0

    const/4 v4, 0x6

    const-wide/high16 v0, 0x4090000000000000L    # 1024.0

    const-wide/high16 v0, 0x4090000000000000L    # 1024.0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    div-double/2addr p0, v0

    move-wide v0, p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-wide v0
.end method

.method private static getPSSFromDebug()D
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    new-instance v0, Landroid/os/Debug$MemoryInfo;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v0}, Landroid/os/Debug$MemoryInfo;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v0}, Landroid/os/Debug;->getMemoryInfo(Landroid/os/Debug$MemoryInfo;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/os/Debug$MemoryInfo;->getTotalPss()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    int-to-double v0, v0

    const/4 v5, 0x2

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const/4 v5, 0x4

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const/4 v5, 0x1

    const/4 v4, 0x7

    div-double/2addr v0, v2

    const/4 v4, 0x0

    move v5, v4

    return-wide v0
.end method

.method public static getTotalMemory(Landroid/content/Context;)D
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "context"
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x2

    const-string/jumbo v0, "tcvaybti"

    const-string v0, "aytmvict"

    const/4 v5, 0x2

    const-string/jumbo v0, "tytaviui"

    const-string v0, "activity"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance v0, Landroid/app/ActivityManager$MemoryInfo;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v0}, Landroid/app/ActivityManager$MemoryInfo;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0, v0}, Landroid/app/ActivityManager;->getMemoryInfo(Landroid/app/ActivityManager$MemoryInfo;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-wide v0, v0, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x1

    long-to-double v0, v0

    const/4 v5, 0x0

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const/4 v5, 0x6

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    div-double/2addr v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    div-double/2addr v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-wide v0
.end method

.method public static getUsedMemory(Landroid/content/Context;)D
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "context"
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v0, "cvtiaiyp"

    const-string v0, "activity"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v6, 0x5

    new-instance v0, Landroid/app/ActivityManager$MemoryInfo;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v0}, Landroid/app/ActivityManager$MemoryInfo;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p0, v0}, Landroid/app/ActivityManager;->getMemoryInfo(Landroid/app/ActivityManager$MemoryInfo;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-wide v1, v0, Landroid/app/ActivityManager$MemoryInfo;->totalMem:J

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-wide v3, v0, Landroid/app/ActivityManager$MemoryInfo;->availMem:J
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    sub-long/2addr v1, v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    long-to-double v0, v1

    const/4 v5, 0x3

    move v6, v5

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const/4 v6, 0x6

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const-wide/high16 v2, 0x4090000000000000L    # 1024.0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    div-double/2addr v0, v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    div-double/2addr v0, v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-wide v0
.end method
