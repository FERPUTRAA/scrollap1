.class public Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;
.super Ljava/lang/Object;


# instance fields
.field private appCpuUsage:F

.field private appCpuUseTimeLast:F

.field private appProcStatFile:Ljava/io/RandomAccessFile;

.field private final cpuCount:I

.field private sysCpuIdelTimeLast:J

.field private sysCpuTotalTimeLast:J

.field private sysCpuUsage:F

.field private sysProcStatFile:Ljava/io/RandomAccessFile;

.field private final tickInHz:J


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v0, "r"

    const-string/jumbo v0, "r"

    const/4 v4, 0x0

    xor-int/2addr v5, v4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoTimeUtilJNI;->getTimeTick()J

    move-result-wide v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-wide v1, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->tickInHz:J

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/Runtime;->availableProcessors()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    iput v1, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->cpuCount:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    iput v1, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->appCpuUseTimeLast:F

    iput v1, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->appCpuUsage:F

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-wide v2, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->sysCpuTotalTimeLast:J

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput-wide v2, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->sysCpuIdelTimeLast:J

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput v1, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->sysCpuUsage:F

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x7

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    aput-object v2, v1, v3

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v2, "/ss/rtto/dsc%"

    const-string/jumbo v2, "pts//t/sdorc%"

    const/4 v5, 0x4

    const-string/jumbo v2, "sttm/d/c%ao/r"

    const-string v2, "/proc/%d/stat"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v2, Ljava/io/RandomAccessFile;

    const/4 v5, 0x7

    invoke-direct {v2, v1, v0}, Ljava/io/RandomAccessFile;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    iput-object v2, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->appProcStatFile:Ljava/io/RandomAccessFile;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance v1, Ljava/io/RandomAccessFile;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo v2, "trpto/cos"

    const-string/jumbo v2, "rstm/cotp"

    const/4 v5, 0x6

    const-string v2, "/tcotbspr"

    const-string/jumbo v2, "proc/stat"

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {v1, v2, v0}, Ljava/io/RandomAccessFile;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput-object v1, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->sysProcStatFile:Ljava/io/RandomAccessFile;
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void
.end method

.method private static getStrsFromFile(Ljava/io/RandomAccessFile;)[Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "randomAccessFile"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0, v1, v2}, Ljava/io/RandomAccessFile;->seek(J)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/io/RandomAccessFile;->readLine()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto :goto_0

    :catch_0
    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto :goto_1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v0, "/s+/"

    const-string v0, "+//s"

    const/4 v4, 0x3

    const-string v0, "/+s/"

    const-string v0, "\\s+"

    const/4 v4, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object v0
.end method

.method private updateCpuUsage()V
    .locals 13

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->appProcStatFile:Ljava/io/RandomAccessFile;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-static {v0}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->getStrsFromFile(Ljava/io/RandomAccessFile;)[Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x3

    if-eqz v0, :cond_2

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x6

    array-length v1, v0

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x1

    const/16 v2, 0x34

    const/4 v12, 0x3

    if-lt v1, v2, :cond_2

    const/4 v12, 0x0

    const/16 v1, 0xd

    const/4 v11, 0x2

    or-int/2addr v12, v11

    aget-object v1, v0, v1

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v1

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x1

    const/16 v3, 0xe

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    aget-object v3, v0, v3

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-static {v3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v3

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x3

    add-long/2addr v1, v3

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/16 v3, 0xf

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    aget-object v3, v0, v3

    const/4 v12, 0x1

    invoke-static {v3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v3

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x7

    add-long/2addr v1, v3

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x3

    const/16 v3, 0x10

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x0

    aget-object v0, v0, v3

    const/4 v11, 0x2

    shr-int/2addr v12, v11

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v3

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x7

    add-long/2addr v1, v3

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x0

    long-to-float v0, v1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    const/high16 v1, 0x447a0000    # 1000.0f

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    mul-float/2addr v0, v1

    const/4 v11, 0x5

    move v12, v11

    iget-wide v2, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->tickInHz:J

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    long-to-float v2, v2

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x6

    div-float/2addr v0, v2

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    float-to-long v2, v0

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->sysProcStatFile:Ljava/io/RandomAccessFile;

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-static {v0}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->getStrsFromFile(Ljava/io/RandomAccessFile;)[Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x2

    if-eqz v0, :cond_0

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    array-length v4, v0

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x0

    const/16 v5, 0x8

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    if-lt v4, v5, :cond_0

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x3

    const/4 v4, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    aget-object v4, v0, v4

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    const/4 v6, 0x2

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x5

    aget-object v6, v0, v6

    const/4 v12, 0x2

    invoke-static {v6}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v6

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x7

    add-long/2addr v4, v6

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    const/4 v6, 0x3

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x5

    aget-object v6, v0, v6

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-static {v6}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v6

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x6

    add-long/2addr v4, v6

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x6

    const/4 v6, 0x4

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x1

    aget-object v7, v0, v6

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-static {v7}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v7

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    add-long/2addr v4, v7

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x5

    const/4 v7, 0x5

    const/4 v11, 0x0

    shr-int/2addr v12, v11

    aget-object v8, v0, v7

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-static {v8}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v8

    const/4 v12, 0x6

    const/4 v11, 0x2

    add-long/2addr v4, v8

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x5

    const/4 v8, 0x6

    const/4 v11, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x7

    aget-object v8, v0, v8

    const/4 v12, 0x1

    const/4 v11, 0x3

    invoke-static {v8}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v8

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    add-long/2addr v4, v8

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x3

    const/4 v8, 0x7

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x1

    aget-object v8, v0, v8

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-static {v8}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v8

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x2

    add-long/2addr v4, v8

    const/4 v12, 0x5

    const/4 v11, 0x2

    aget-object v6, v0, v6

    const/4 v12, 0x7

    invoke-static {v6}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v8

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x7

    aget-object v0, v0, v7

    const/4 v12, 0x4

    const/4 v11, 0x3

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v6

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x1

    add-long/2addr v8, v6

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x4

    long-to-float v0, v4

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x4

    mul-float/2addr v0, v1

    const/4 v12, 0x3

    iget-wide v4, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->tickInHz:J

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x4

    long-to-float v6, v4

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x6

    div-float/2addr v0, v6

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    float-to-long v6, v0

    const/4 v12, 0x1

    const/4 v11, 0x4

    long-to-float v0, v8

    const/4 v12, 0x1

    const/4 v11, 0x6

    mul-float/2addr v0, v1

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x4

    long-to-float v1, v4

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x6

    div-float/2addr v0, v1

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x1

    float-to-long v0, v0

    const/4 v12, 0x6

    goto :goto_0

    :cond_0
    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x4

    iget v4, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->cpuCount:I

    const/4 v12, 0x1

    const/4 v11, 0x6

    int-to-long v4, v4

    const/4 v11, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x1

    mul-long v6, v0, v4

    move-wide v0, v6

    :goto_0
    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-wide v4, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->sysCpuIdelTimeLast:J

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    cmp-long v8, v0, v4

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x6

    if-gez v8, :cond_1

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x3

    return-void

    :cond_1
    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x3

    iget-wide v8, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->sysCpuTotalTimeLast:J

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x4

    sub-long v8, v6, v8

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    long-to-float v2, v2

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    iget v3, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->appCpuUseTimeLast:F

    const/4 v12, 0x1

    const/4 v11, 0x5

    sub-float v3, v2, v3

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x2

    const/high16 v10, 0x42c80000    # 100.0f

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x7

    mul-float/2addr v3, v10

    const/4 v12, 0x0

    const/4 v11, 0x1

    long-to-float v8, v8

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x3

    div-float/2addr v3, v8

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x5

    iput v3, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->appCpuUsage:F

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x5

    sub-long v3, v0, v4

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x6

    long-to-float v3, v3

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x6

    sub-float v3, v8, v3

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x1

    mul-float/2addr v3, v10

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x2

    div-float/2addr v3, v8

    const/4 v12, 0x0

    iput v3, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->sysCpuUsage:F

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x3

    iput v2, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->appCpuUseTimeLast:F

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    iput-wide v0, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->sysCpuIdelTimeLast:J

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x6

    iput-wide v6, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->sysCpuTotalTimeLast:J

    :cond_2
    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x0

    return-void
.end method


# virtual methods
.method public getCpuUsage()[D
    .locals 8

    monitor-enter p0

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->updateCpuUsage()V

    const/4 v7, 0x6

    const/4 v0, 0x0

    const/4 v7, 0x1

    const/4 v0, 0x2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    new-array v0, v0, [D

    const/4 v6, 0x6

    move v7, v6

    iget v1, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->appCpuUsage:F

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    float-to-double v2, v1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    cmpl-double v2, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-lez v2, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    float-to-double v1, v1

    const/4 v6, 0x3

    move v7, v6

    goto :goto_0

    :cond_0
    move-wide v1, v4

    :goto_0
    const/4 v7, 0x7

    const/4 v3, 0x0

    const/4 v7, 0x0

    move v6, v3

    move v6, v3

    const/4 v7, 0x7

    aput-wide v1, v0, v3

    const/4 v7, 0x0

    const/4 v6, 0x0

    iget v1, p0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->sysCpuUsage:F

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    float-to-double v2, v1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    cmpl-double v2, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-lez v2, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    float-to-double v4, v1

    :cond_1
    const/4 v7, 0x2

    const/4 v1, 0x6

    const/4 v7, 0x3

    const/4 v1, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    aput-wide v4, v0, v1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    monitor-exit p0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    throw v0
.end method
