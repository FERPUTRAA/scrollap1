.class public Lcom/zego/zegoavkit2/hardwaremonitor/ZegoTimeUtilJNI;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    return-void
.end method

.method public static native getTimeTick()J
.end method
