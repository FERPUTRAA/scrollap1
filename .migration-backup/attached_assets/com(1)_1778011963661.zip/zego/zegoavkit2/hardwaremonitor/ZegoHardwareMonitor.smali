.class public final Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;
.super Ljava/lang/Object;


# static fields
.field private static cpuUsage:[D

.field private static isFirst:Z

.field private static zegoCPUUtils:Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    move v2, v1

    new-array v0, v0, [D

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    fill-array-data v0, :array_0

    const/4 v2, 0x0

    sput-object v0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;->cpuUsage:[D

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    sput-boolean v0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;->isFirst:Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    sput-object v0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;->zegoCPUUtils:Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void

    nop

    :array_0
    .array-data 8
        0x0
        0x0
    .end array-data
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public static getCpuUsage()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "Mos@~/.@f~~f~~@dKn@~~b@  @@~~ 1i~ l@i~l4b~t@~@~~b~ @o ~@@ ~i~  - so So o~ uv ~@y~@c/@@ a@@@ trmo"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-boolean v0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;->isFirst:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    move v2, v1

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    sput-boolean v0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;->isFirst:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;

    const/4 v1, 0x3

    move v2, v1

    invoke-direct {v0}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    sput-object v0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;->zegoCPUUtils:Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->getCpuUsage()[D

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;->zegoCPUUtils:Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoCPUUtils;->getCpuUsage()[D

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput-object v0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;->cpuUsage:[D

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public static getMEMTotal(Landroid/content/Context;)D
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "context"
        }
    .end annotation

    const/4 v2, 0x4

    move v3, v2

    invoke-static {p0}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoMEMUtils;->getTotalMemory(Landroid/content/Context;)D

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-wide v0
.end method

.method public static getMEMUsage(Landroid/content/Context;)D
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "context"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0, v0}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoMEMUtils;->getAppUsedMemory(Landroid/content/Context;I)D

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-wide v0
.end method

.method public static getProcessCPUUsage()D
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget-object v0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;->cpuUsage:[D

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    aget-wide v1, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-wide v1
.end method

.method public static getSystemCPUUsage()D
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    sget-object v0, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;->cpuUsage:[D

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    aget-wide v1, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-wide v1
.end method

.method public static getSystemMEMUsage(Landroid/content/Context;)D
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "context"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoMEMUtils;->getUsedMemory(Landroid/content/Context;)D

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-wide v0
.end method

.method public static updateCpuUsage()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {}, Lcom/zego/zegoavkit2/hardwaremonitor/ZegoHardwareMonitor;->getCpuUsage()V

    const/4 v1, 0x1

    return-void
.end method
