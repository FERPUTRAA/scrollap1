.class public Lcom/zego/zegoavkit2/videocapture/TrafficControlQuality;
.super Ljava/lang/Object;


# instance fields
.field private videoBitrate:I

.field private videoFrameRate:I

.field private videoHeight:I

.field private videoWidth:I


# direct methods
.method constructor <init>(IIII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "bitrate",
            "frameRate",
            "width",
            "height"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    shr-int/2addr v1, v0

    iput p1, p0, Lcom/zego/zegoavkit2/videocapture/TrafficControlQuality;->videoBitrate:I

    const/4 v0, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p2, p0, Lcom/zego/zegoavkit2/videocapture/TrafficControlQuality;->videoFrameRate:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p3, p0, Lcom/zego/zegoavkit2/videocapture/TrafficControlQuality;->videoWidth:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p4, p0, Lcom/zego/zegoavkit2/videocapture/TrafficControlQuality;->videoHeight:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public getVideoBitrate()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "c~s@u @~sv@~@i4b ~~~~-    ff  d~@ @i/a@~oo~@~ @~b M@K t@o~~ @o/ @~@~@@~~~~@nml~1~t  y@o@ Slior@."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget v0, p0, Lcom/zego/zegoavkit2/videocapture/TrafficControlQuality;->videoBitrate:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public getVideoFrameRate()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/zego/zegoavkit2/videocapture/TrafficControlQuality;->videoFrameRate:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public getVideoHeight()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/zego/zegoavkit2/videocapture/TrafficControlQuality;->videoHeight:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    return v0
.end method

.method public getVideoWidth()I
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/zego/zegoavkit2/videocapture/TrafficControlQuality;->videoWidth:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method
