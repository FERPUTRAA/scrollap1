.class public Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;
.super Lcom/zego/zegoavkit2/ZegoVideoCaptureFactory;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x15
.end annotation


# static fields
.field public static final SCREEN_CAPTURE_SIZE_DEFAULT:I


# instance fields
.field private volatile mCaptureHeight:I

.field private volatile mCaptureWidth:I

.field private mContext:Landroid/content/Context;

.field private volatile mDevice:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

.field private volatile mMediaProjection:Landroid/media/projection/MediaProjection;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "context"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/zego/zegoavkit2/ZegoVideoCaptureFactory;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mDevice:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mMediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mCaptureWidth:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mCaptureHeight:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mContext:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public create(Ljava/lang/String;)Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "device_id"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~~s~4ab@~@n/@M@ c~@vt@~@.@mb~~ 1~f~ ~~@o~~~b@@t~@s~ @@f @uy  Sl-/~oo~lK ir id@ @  ~o~ i  ~ o o@@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mDevice:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-nez p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance p1, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mContext:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mMediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mCaptureWidth:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v3, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mCaptureHeight:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {p1, v0, v1, v2, v3}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;-><init>(Landroid/content/Context;Landroid/media/projection/MediaProjection;II)V

    const/4 v4, 0x4

    and-int/2addr v5, v4

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mDevice:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    :cond_0
    const/4 v5, 0x3

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mDevice:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    return-object p1
.end method

.method public destroy(Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "vc"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mDevice:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-ne p1, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mMediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v2, 0x7

    const/4 v0, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mMediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/media/projection/MediaProjection;->stop()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mMediaProjection:Landroid/media/projection/MediaProjection;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mDevice:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public setCaptureResolution(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "captureWidth",
            "captureHeight"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz p2, :cond_1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-gtz p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-lez p2, :cond_2

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mCaptureWidth:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput p2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mCaptureHeight:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mDevice:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p2}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->setCaptureResolution(II)V

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public setMediaProjection(Landroid/media/projection/MediaProjection;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mediaProjection"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mMediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->mDevice:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->setMediaProjection(Landroid/media/projection/MediaProjection;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
