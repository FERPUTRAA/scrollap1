.class Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->releaseEGLSurface()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

.field final synthetic val$barrier:Ljava/util/concurrent/CountDownLatch;


# direct methods
.method constructor <init>(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            "this$0",
            "val$barrier"
        }
    .end annotation

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->val$barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v0, 0x4

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@s@f~~@~@@ @~@M ~i~ //~s~mvb b~~@ya@@ou~1 d o@t@o~@@@~   4-n~i~~l~ @K oS o@~ r.i~ ~ b~tl@  o@cf"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1700(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/os/Handler;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1700(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/os/Handler;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1500(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$DrawRunnable;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_0
    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$500(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/graphics/SurfaceTexture;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$500(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/graphics/SurfaceTexture;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/SurfaceTexture;->setOnFrameAvailableListener(Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$500(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/graphics/SurfaceTexture;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/graphics/SurfaceTexture;->release()V

    const/4 v5, 0x4

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$502(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Landroid/graphics/SurfaceTexture;)Landroid/graphics/SurfaceTexture;

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v0, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->hasSurface()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->makeCurrent()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1400(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1400(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->release()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1402(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->releaseSurface()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->detachCurrent()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->release()V

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$902(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v0, :cond_8

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->hasSurface()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz v0, :cond_8

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->makeCurrent()V

    const/4 v4, 0x7

    and-int/2addr v5, v4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1800(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v0, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1800(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v2, v0, v3}, Landroid/opengl/GLES20;->glDeleteFramebuffers(I[II)V

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    invoke-static {v0, v3}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1802(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;I)I

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v2, v0, v3}, Landroid/opengl/GLES20;->glDeleteTextures(I[II)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0, v3}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1902(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;I)I

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$400(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v0, :cond_6

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$400(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v2, v0, v3}, Landroid/opengl/GLES20;->glDeleteTextures(I[II)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0, v3}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$402(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;I)I

    :cond_6
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$200(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v0, :cond_7

    const/4 v4, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$200(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->release()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$202(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    :cond_7
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->releaseSurface()V

    const/4 v5, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->detachCurrent()V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->release()V

    const/4 v4, 0x0

    move v5, v4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$102(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    :cond_8
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$800(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/view/Surface;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_9

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$800(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/view/Surface;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/view/Surface;->release()V

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$802(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Landroid/view/Surface;)Landroid/view/Surface;

    :cond_9
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;->val$barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-void
.end method
