.class Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;
.super Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice;

# interfaces
.implements Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x15
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$DrawRunnable;
    }
.end annotation


# instance fields
.field private volatile isCapturing:Z

.field private volatile isStartCapture:Z

.field private volatile isStartPreview:Z

.field private mCaptureHeight:I

.field private mCaptureWidth:I

.field private volatile mClient:Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;

.field private mDrawRunnable:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$DrawRunnable;

.field private volatile mDrawToSDKInterval:I

.field private mEgl14Supported:Z

.field private mEglSysToVideoMemory:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

.field private mEglVideoMemoryToSDK:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

.field private mFrameBufferId:I

.field private mHandler:Landroid/os/Handler;

.field private mHandlerThread:Landroid/os/HandlerThread;

.field private mInputMatrix:[F

.field private volatile mMediaProjection:Landroid/media/projection/MediaProjection;

.field private mOutMetrics:Landroid/util/DisplayMetrics;

.field private mSDKTextureId:I

.field private mSdkSurfaceBufferHeight:I

.field private mSdkSurfaceBufferWidth:I

.field private mSdkSurfaceTexture:Landroid/graphics/SurfaceTexture;

.field private mSetCaptureHeight:I

.field private mSetCaptureWidth:I

.field private volatile mSurface:Landroid/view/Surface;

.field private mSysSurfaceTexture:Landroid/graphics/SurfaceTexture;

.field private mSysTextureId:I

.field private mSysToVideoMemoryDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

.field private mVideoMemoryToSDKDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

.field private volatile mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

.field private mWindowManager:Landroid/view/WindowManager;

.field private transformationMatrix:[F


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/media/projection/MediaProjection;II)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "context",
            "mediaProjection",
            "captureWidth",
            "captureHeight"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice;-><init>()V

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mClient:Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandlerThread:Landroid/os/HandlerThread;

    const/4 v4, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandler:Landroid/os/Handler;

    const/4 v4, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferWidth:I

    const/4 v3, 0x3

    move v4, v3

    iput v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferHeight:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    iput-boolean v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isStartPreview:Z

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-boolean v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isStartCapture:Z

    const/4 v4, 0x3

    const/4 v3, 0x4

    iput-boolean v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isCapturing:Z

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSurface:Landroid/view/Surface;

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/16 v1, 0x10

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-array v2, v1, [F

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    fill-array-data v2, :array_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->transformationMatrix:[F

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-array v1, v1, [F

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mInputMatrix:[F

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/16 v1, 0x42

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mDrawToSDKInterval:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v1, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$DrawRunnable;

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-direct {v1, p0, v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$DrawRunnable;-><init>(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mDrawRunnable:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$DrawRunnable;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v0, "ndsowi"

    const-string/jumbo v0, "window"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    check-cast p1, Landroid/view/WindowManager;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mWindowManager:Landroid/view/WindowManager;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance p1, Landroid/util/DisplayMetrics;

    const/4 v4, 0x7

    invoke-direct {p1}, Landroid/util/DisplayMetrics;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mOutMetrics:Landroid/util/DisplayMetrics;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object p2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mMediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput p3, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSetCaptureWidth:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput p4, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSetCaptureHeight:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-void

    nop

    :array_0
    .array-data 4
        0x3f800000    # 1.0f
        0x0
        0x0
        0x0
        0x0
        0x3f800000    # 1.0f
        0x0
        0x0
        0x0
        0x0
        0x3f800000    # 1.0f
        0x0
        0x0
        0x0
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method static synthetic access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "t@~m@ @@a@co1io~S/v~~~~ ~~~@r@~b~  /s ~f~@~b4-  o~@l omdK@~ ~y @@~ .i b@ ~@ftu@oni@~~~@ @ l@M  @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglSysToVideoMemory:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-object p0
.end method

.method static synthetic access$1000(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/graphics/SurfaceTexture;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$1002(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Landroid/graphics/SurfaceTexture;)Landroid/graphics/SurfaceTexture;
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic access$102(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglSysToVideoMemory:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p1
.end method

.method static synthetic access$1100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mClient:Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;

    const/4 v1, 0x2

    const/4 v0, 0x7

    return-object p0
.end method

.method static synthetic access$1200(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    iget p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferWidth:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic access$1300(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferHeight:I

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic access$1400(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVideoMemoryToSDKDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$1402(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVideoMemoryToSDKDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method static synthetic access$1500(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$DrawRunnable;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mDrawRunnable:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$DrawRunnable;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$1600(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mDrawToSDKInterval:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic access$1700(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/os/Handler;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandler:Landroid/os/Handler;

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$1800(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mFrameBufferId:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    return p0
.end method

.method static synthetic access$1802(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    iput p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mFrameBufferId:I

    const/4 v0, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p1
.end method

.method static synthetic access$1900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    iget p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSDKTextureId:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic access$1902(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSDKTextureId:I

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p1
.end method

.method static synthetic access$200(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysToVideoMemoryDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic access$2000(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;II)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->resizeSdkSurface(II)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$202(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysToVideoMemoryDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$2100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/hardware/display/VirtualDisplay;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$2200(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->resizeVirtualDisplayInNeed()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$2300(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->drawRGBTextureToSDK()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic access$302(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Z)Z
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    iput-boolean p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEgl14Supported:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    return p1
.end method

.method static synthetic access$400(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    iget p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysTextureId:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic access$402(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;I)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysTextureId:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p1
.end method

.method static synthetic access$500(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/graphics/SurfaceTexture;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$502(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Landroid/graphics/SurfaceTexture;)Landroid/graphics/SurfaceTexture;
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$600(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic access$700(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic access$800(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/view/Surface;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSurface:Landroid/view/Surface;

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic access$802(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Landroid/view/Surface;)Landroid/view/Surface;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSurface:Landroid/view/Surface;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method

.method static synthetic access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglVideoMemoryToSDK:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$902(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglVideoMemoryToSDK:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method private declared-synchronized drawOESTexture()V
    .locals 13

    const/4 v11, 0x4

    move v12, v11

    monitor-enter p0

    :try_start_0
    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglSysToVideoMemory:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->hasSurface()Z

    move-result v0

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x2

    if-nez v0, :cond_0

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglSysToVideoMemory:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->createDummyPbufferSurface()V

    :cond_0
    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglSysToVideoMemory:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v12, 0x7

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->makeCurrent()V

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysToVideoMemoryDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x4

    if-nez v0, :cond_1

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x3

    new-instance v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-direct {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;-><init>()V

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysToVideoMemoryDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    :cond_1
    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    if-eqz v0, :cond_2

    const/4 v12, 0x3

    invoke-virtual {v0}, Landroid/graphics/SurfaceTexture;->updateTexImage()V

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mInputMatrix:[F

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {v0, v1}, Landroid/graphics/SurfaceTexture;->getTransformMatrix([F)V

    :cond_2
    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x4

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSDKTextureId:I

    const/4 v12, 0x1

    const v1, 0x8d40

    const/4 v11, 0x1

    or-int/2addr v12, v11

    if-nez v0, :cond_3

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x6

    const v0, 0x84c0

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-static {v0}, Landroid/opengl/GLES20;->glActiveTexture(I)V

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/16 v0, 0xde1

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->generateTexture(I)I

    move-result v0

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x5

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSDKTextureId:I

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x7

    const/16 v2, 0xde1

    const/4 v11, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 v3, 0x0

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    const/16 v4, 0x1908

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget v5, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x0

    iget v6, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    const/4 v7, 0x0

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x7

    const/16 v8, 0x1908

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x7

    const/16 v9, 0x1401

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    const/4 v10, 0x0

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-static/range {v2 .. v10}, Landroid/opengl/GLES20;->glTexImage2D(IIIIIIIILjava/nio/Buffer;)V

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x2

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSDKTextureId:I

    const/4 v12, 0x3

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->generateFrameBuffer(I)I

    move-result v0

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mFrameBufferId:I

    const/4 v12, 0x6

    goto :goto_0

    :cond_3
    const/4 v11, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x5

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mFrameBufferId:I

    const/4 v11, 0x4

    shr-int/2addr v12, v11

    invoke-static {v1, v0}, Landroid/opengl/GLES20;->glBindFramebuffer(II)V

    :goto_0
    const/4 v12, 0x4

    const/16 v0, 0x4000

    const/4 v12, 0x7

    invoke-static {v0}, Landroid/opengl/GLES20;->glClear(I)V

    const/4 v12, 0x3

    const/4 v11, 0x1

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysToVideoMemoryDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget v3, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysTextureId:I

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget-object v4, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mInputMatrix:[F

    const/4 v11, 0x0

    const/4 v12, 0x7

    iget v9, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    const/4 v12, 0x0

    const/4 v11, 0x4

    iget v10, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    const/4 v7, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x2

    const/4 v8, 0x0

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x5

    move v5, v9

    move v5, v9

    const/4 v12, 0x5

    move v5, v9

    move v5, v9

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x6

    move v6, v10

    move v6, v10

    const/4 v12, 0x1

    move v6, v10

    move v6, v10

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-virtual/range {v2 .. v10}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->drawOes(I[FIIIIII)V

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x5

    const/4 v0, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x7

    invoke-static {v1, v0}, Landroid/opengl/GLES20;->glBindFramebuffer(II)V

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglSysToVideoMemory:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->detachCurrent()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x3

    monitor-exit p0

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    return-void

    :catchall_0
    move-exception v0

    const/4 v12, 0x1

    const/4 v11, 0x7

    monitor-exit p0

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x4

    throw v0
.end method

.method private declared-synchronized drawRGBTextureToSDK()V
    .locals 14

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglVideoMemoryToSDK:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->hasSurface()Z

    move-result v0

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x3

    if-nez v0, :cond_0

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x4

    if-eqz v0, :cond_0

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x6

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglVideoMemoryToSDK:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x5

    invoke-virtual {v1, v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->createSurface(Landroid/graphics/SurfaceTexture;)V

    :cond_0
    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglVideoMemoryToSDK:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x1

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->makeCurrent()V

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVideoMemoryToSDKDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x5

    if-nez v0, :cond_1

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x6

    new-instance v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x4

    invoke-direct {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;-><init>()V

    const/4 v12, 0x3

    const/4 v13, 0x7

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVideoMemoryToSDKDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    :cond_1
    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x2

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x5

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v1

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v0

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x1

    const/16 v2, 0x4000

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x0

    invoke-static {v2}, Landroid/opengl/GLES20;->glClear(I)V

    const/4 v13, 0x2

    const/4 v12, 0x7

    iget-object v3, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVideoMemoryToSDKDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x0

    iget v4, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSDKTextureId:I

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x1

    iget-object v5, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->transformationMatrix:[F

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x5

    iget v6, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x4

    iget v7, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x2

    const/4 v8, 0x0

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x4

    const/4 v9, 0x0

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x1

    iget v10, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferWidth:I

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x3

    iget v11, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferHeight:I

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x3

    invoke-virtual/range {v3 .. v11}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->drawRgb(I[FIIIIII)V

    const/4 v13, 0x6

    const/4 v12, 0x1

    iget-boolean v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEgl14Supported:Z

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x6

    if-eqz v2, :cond_2

    const/4 v12, 0x2

    shr-int/2addr v13, v12

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglVideoMemoryToSDK:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x7

    check-cast v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x7

    invoke-virtual {v2, v0, v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->swapBuffers(J)V

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x6

    goto :goto_0

    :cond_2
    const/4 v12, 0x1

    const/4 v13, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglVideoMemoryToSDK:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->swapBuffers()V

    :goto_0
    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglVideoMemoryToSDK:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v13, 0x0

    const/4 v12, 0x1

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->detachCurrent()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x0

    goto :goto_1

    :catchall_0
    move-exception v0

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x7

    goto :goto_2

    :catch_0
    move-exception v0

    :try_start_1
    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_1
    const/4 v13, 0x7

    const/4 v12, 0x7

    monitor-exit p0

    const/4 v12, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x4

    return-void

    :goto_2
    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x1

    monitor-exit p0

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x6

    throw v0
.end method

.method private getSurface()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandler:Landroid/os/Handler;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v2, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v2, p0, v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;-><init>(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Ljava/util/concurrent/CountDownLatch;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->await()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void
.end method

.method private initCaptureSize()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isDefaultCaptureSize()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mWindowManager:Landroid/view/WindowManager;

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mOutMetrics:Landroid/util/DisplayMetrics;

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v0, v1}, Landroid/view/Display;->getRealMetrics(Landroid/util/DisplayMetrics;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mOutMetrics:Landroid/util/DisplayMetrics;

    const/4 v2, 0x6

    move v3, v2

    iget v1, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    iget v0, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSetCaptureWidth:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSetCaptureHeight:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferWidth:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferHeight:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferWidth:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferHeight:I

    :cond_1
    const/4 v2, 0x6

    move v3, v2

    return-void
.end method

.method private isDefaultCaptureSize()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSetCaptureWidth:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSetCaptureHeight:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x1

    :goto_1
    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method private releaseEGLSurface()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandler:Landroid/os/Handler;

    const/4 v4, 0x1

    const/4 v3, 0x2

    new-instance v2, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-direct {v2, p0, v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$2;-><init>(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Ljava/util/concurrent/CountDownLatch;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->await()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method private resizeSdkSurface(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "width",
            "height"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferWidth:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-ne v0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferHeight:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-ne v0, p2, :cond_0

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferWidth:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput p2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferHeight:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglVideoMemoryToSDK:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->makeCurrent()V

    :cond_1
    const/4 v2, 0x3

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVideoMemoryToSDKDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v2, 0x2

    if-eqz p1, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->release()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVideoMemoryToSDKDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p1, :cond_3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget p2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferWidth:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSdkSurfaceBufferHeight:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1, p2, v0}, Landroid/graphics/SurfaceTexture;->setDefaultBufferSize(II)V

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglVideoMemoryToSDK:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p1, :cond_4

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->detachCurrent()V

    :cond_4
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method private resizeVirtualDisplayInNeed()V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSetCaptureWidth:I

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSetCaptureHeight:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isDefaultCaptureSize()Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mWindowManager:Landroid/view/WindowManager;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mOutMetrics:Landroid/util/DisplayMetrics;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Landroid/view/Display;->getRealMetrics(Landroid/util/DisplayMetrics;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mOutMetrics:Landroid/util/DisplayMetrics;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget v1, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget v0, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v5, 0x5

    move v6, v5

    move v4, v1

    move v4, v1

    const/4 v6, 0x3

    move v4, v1

    move v4, v1

    const/4 v6, 0x1

    move v1, v0

    move v1, v0

    const/4 v6, 0x0

    move v1, v0

    move v1, v0

    const/4 v6, 0x6

    move v0, v4

    move v0, v4

    const/4 v6, 0x4

    move v0, v4

    move v0, v4

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-ne v2, v0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-ne v2, v1, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-void

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x6

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglSysToVideoMemory:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v0, :cond_2

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->makeCurrent()V

    :cond_2
    const/4 v5, 0x1

    move v6, v5

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mFrameBufferId:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz v0, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v1, v0, v2}, Landroid/opengl/GLES20;->glDeleteFramebuffers(I[II)V

    const/4 v5, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mFrameBufferId:I

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSDKTextureId:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    if-eqz v0, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {v1, v0, v2}, Landroid/opengl/GLES20;->glDeleteTextures(I[II)V

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSDKTextureId:I

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysToVideoMemoryDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v0, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->release()V

    const/4 v6, 0x1

    const/4 v5, 0x1

    iput-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysToVideoMemoryDrawer:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    :cond_5
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v0, :cond_6

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0, v2}, Landroid/graphics/SurfaceTexture;->setOnFrameAvailableListener(Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/graphics/SurfaceTexture;->release()V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    iput-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysSurfaceTexture:Landroid/graphics/SurfaceTexture;

    :cond_6
    const/4 v6, 0x2

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mEglSysToVideoMemory:Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v0, :cond_7

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->detachCurrent()V

    :cond_7
    const/4 v5, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance v0, Landroid/graphics/SurfaceTexture;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysTextureId:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {v0, v2}, Landroid/graphics/SurfaceTexture;-><init>(I)V

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget v3, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0, v2, v3}, Landroid/graphics/SurfaceTexture;->setDefaultBufferSize(II)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0, p0}, Landroid/graphics/SurfaceTexture;->setOnFrameAvailableListener(Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance v0, Landroid/view/Surface;

    const/4 v5, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSysSurfaceTexture:Landroid/graphics/SurfaceTexture;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v0, v2}, Landroid/view/Surface;-><init>(Landroid/graphics/SurfaceTexture;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSurface:Landroid/view/Surface;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v0, :cond_8

    const/4 v6, 0x1

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    const/4 v6, 0x2

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSurface:Landroid/view/Surface;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0, v2}, Landroid/hardware/display/VirtualDisplay;->setSurface(Landroid/view/Surface;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget v3, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v3, v1}, Landroid/hardware/display/VirtualDisplay;->resize(III)V

    :cond_8
    const/4 v6, 0x0

    const/4 v5, 0x1

    return-void
.end method

.method private startScreenCapture()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isCapturing:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isStartPreview:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isStartCapture:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isCapturing:Z

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->initCaptureSize()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->getSurface()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mMediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->setMediaProjection(Landroid/media/projection/MediaProjection;)V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method private stopScreenCaptureInNeed()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isCapturing:Z

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isStartPreview:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isStartCapture:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isCapturing:Z

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/hardware/display/VirtualDisplay;->release()V

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->releaseEGLSurface()V

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method protected allocateAndStart(Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "client"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mClient:Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance p1, Landroid/os/HandlerThread;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string v0, "ZecooreseeaCguprn"

    const-string v0, "eCsZaceotreugnepr"

    const/4 v2, 0x3

    const-string v0, "cCegnboeatuereSZr"

    const-string v0, "ZegoScreenCapture"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandlerThread:Landroid/os/HandlerThread;

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance p1, Landroid/os/Handler;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandlerThread:Landroid/os/HandlerThread;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandler:Landroid/os/Handler;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method protected enableTorch(Z)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "b"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return p1
.end method

.method public onFrameAvailable(Landroid/graphics/SurfaceTexture;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "surfaceTexture"
        }
    .end annotation

    const/4 v1, 0x2

    iget-boolean p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isCapturing:Z

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->drawOESTexture()V

    :cond_0
    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method setCaptureResolution(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "captureWidth",
            "captureHeight"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSetCaptureWidth:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSetCaptureHeight:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method protected setCaptureRotation(I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return p1
.end method

.method protected setFrameRate(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fps"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/16 v0, 0x3e8

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    div-int/2addr v0, p1

    const/4 v1, 0x7

    const/4 v1, 0x1

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mDrawToSDKInterval:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return p1
.end method

.method protected setFrontCam(I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return p1
.end method

.method public setMediaProjection(Landroid/media/projection/MediaProjection;)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mediaProjection"
        }
    .end annotation

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mMediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz p1, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    const/4 v9, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {p1}, Landroid/hardware/display/VirtualDisplay;->release()V

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    const/4 p1, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mClient:Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;

    const/4 v10, 0x6

    const/4 v9, 0x2

    if-eqz p1, :cond_1

    const/4 v9, 0x1

    shl-int/2addr v10, v9

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mMediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-eqz p1, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSurface:Landroid/view/Surface;

    const/4 v10, 0x7

    if-eqz p1, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mMediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    const-string v1, "aenpteueSruCm"

    const-string v1, "CatmneuSpeecr"

    const/4 v10, 0x0

    const-string/jumbo v1, "nepeerrpCutca"

    const-string v1, "ScreenCapture"

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureWidth:I

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    iget v3, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mCaptureHeight:I

    const/4 v10, 0x1

    const/4 v4, 0x1

    const/4 v10, 0x1

    or-int/2addr v9, v4

    const/4 v10, 0x0

    const/4 v5, 0x2

    const/4 v10, 0x7

    const/4 v5, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object v6, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mSurface:Landroid/view/Surface;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v7, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-object v8, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandler:Landroid/os/Handler;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual/range {v0 .. v8}, Landroid/media/projection/MediaProjection;->createVirtualDisplay(Ljava/lang/String;IIIILandroid/view/Surface;Landroid/hardware/display/VirtualDisplay$Callback;Landroid/os/Handler;)Landroid/hardware/display/VirtualDisplay;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mVirtualDisplay:Landroid/hardware/display/VirtualDisplay;

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    return-void
.end method

.method protected setPowerlineFreq(I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p1
.end method

.method protected setResolution(II)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "width",
            "height"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandler:Landroid/os/Handler;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v1, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$3;

    const/4 v3, 0x6

    invoke-direct {v1, p0, p1, p2}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$3;-><init>(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;II)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    return p1
.end method

.method protected setView(Landroid/view/View;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "view"
        }
    .end annotation

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return p1
.end method

.method protected setViewMode(I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p1
.end method

.method protected setViewRotation(I)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "i"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x7

    return p1
.end method

.method protected startCapture()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isStartCapture:Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->startScreenCapture()V

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method protected startPreview()I
    .locals 3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isStartPreview:Z

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->startScreenCapture()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method protected stopAndDeAllocate()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mClient:Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mClient:Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {v0}, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;->destroy()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mClient:Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandlerThread:Landroid/os/HandlerThread;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/os/HandlerThread;->quit()Z

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandlerThread:Landroid/os/HandlerThread;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->mHandler:Landroid/os/Handler;

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method protected stopCapture()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isStartCapture:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->stopScreenCaptureInNeed()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method protected stopPreview()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->isStartPreview:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->stopScreenCaptureInNeed()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method protected supportBufferType()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method protected takeSnapshot()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v0, 0x0

    move v2, v0

    return v0
.end method
