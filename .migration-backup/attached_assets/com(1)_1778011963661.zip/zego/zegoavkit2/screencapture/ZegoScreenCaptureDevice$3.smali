.class Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->setResolution(II)I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

.field final synthetic val$height:I

.field final synthetic val$width:I


# direct methods
.method constructor <init>(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010,
            0x1010
        }
        names = {
            "this$0",
            "val$width",
            "val$height"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$3;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$3;->val$width:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput p3, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$3;->val$height:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "c@s @@~ibi~~@@~my ~@M@~ ~~ .  @ fdr~~ lo4bos@~i  ~/~v@@ b@ol~@ou- 1~ otSf@n a@o@K ~~/ ~~@@~t@~~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$3;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    iget v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$3;->val$width:I

    const/4 v4, 0x1

    iget v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$3;->val$height:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v0, v1, v2}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$2000(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;II)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void
.end method
