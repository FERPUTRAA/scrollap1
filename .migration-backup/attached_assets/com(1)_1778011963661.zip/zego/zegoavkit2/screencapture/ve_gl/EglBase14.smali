.class public final Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;
.super Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x12
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;
    }
.end annotation


# static fields
.field private static final CURRENT_SDK_VERSION:I

.field private static final EGLExt_SDK_VERSION:I = 0x12

.field private static final TAG:Ljava/lang/String; = "EglBase14"


# instance fields
.field private eglConfig:Landroid/opengl/EGLConfig;

.field private eglContext:Landroid/opengl/EGLContext;

.field private eglDisplay:Landroid/opengl/EGLDisplay;

.field private eglSurface:Landroid/opengl/EGLSurface;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x0

    sput v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->CURRENT_SDK_VERSION:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;[I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "sharedContext",
            "configAttributes"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    invoke-static {}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->getEglDisplay()Landroid/opengl/EGLDisplay;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v2, 0x7

    invoke-static {v0, p2}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->getEglConfig(Landroid/opengl/EGLDisplay;[I)Landroid/opengl/EGLConfig;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglConfig:Landroid/opengl/EGLConfig;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p1, v0, p2}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->createEglContext(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;)Landroid/opengl/EGLContext;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglContext:Landroid/opengl/EGLContext;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method private checkIsNotReleased()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "l@sst@o1@~~f~ @d~if o/ imt  @rvb@@@~@@~ i~ @ ~~ ~@~M~oK@@ a@~~~c~ ~~l~/@4o  by~uSn~ @ . - @@o@o~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_DISPLAY:Landroid/opengl/EGLDisplay;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eq v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglContext:Landroid/opengl/EGLContext;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eq v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglConfig:Landroid/opengl/EGLConfig;

    const/4 v3, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string v1, "eesmranl hhodiee caTtbs sjee "

    const-string v1, "Tes ebehsaei hn tedalercsbj o"

    const/4 v3, 0x5

    const-string v1, "bsa oeaechjsteose ireb nl hTd"

    const-string v1, "This object has been released"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    throw v0
.end method

.method private static createEglContext(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;)Landroid/opengl/EGLContext;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "sharedContext",
            "eglDisplay",
            "eglConfig"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz p0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;->access$000(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;)Landroid/opengl/EGLContext;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eq v0, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo p1, "meltvbdoannxitraIehs "

    const-string/jumbo p1, "rsvmoexnaIh daenitltC"

    const/4 v4, 0x1

    const-string/jumbo p1, "xiI seuvlatnddrnhCoet"

    const-string p1, "Invalid sharedContext"

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    throw p0

    :cond_1
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v0, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/16 v1, 0x3038

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/16 v2, 0x3098

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    filled-new-array {v2, v0, v1}, [I

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez p0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x6

    sget-object p0, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    const/4 v3, 0x0

    or-int/2addr v4, v3

    goto :goto_1

    :cond_2
    const/4 v3, 0x3

    move v4, v3

    invoke-static {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;->access$000(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;)Landroid/opengl/EGLContext;

    move-result-object p0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->lock:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    monitor-enter v1

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x6

    shl-int/2addr v3, v2

    :try_start_0
    const/4 v4, 0x5

    invoke-static {p1, p2, p0, v0, v2}, Landroid/opengl/EGL14;->eglCreateContext(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;Landroid/opengl/EGLContext;[II)Landroid/opengl/EGLContext;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object p1, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eq p0, p1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x5

    return-object p0

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string p2, "ee oxinpdttLeE Gleo xt0a Fcoc t:"

    const-string/jumbo p2, "teGootdE 0Ln t lFaciexecr:xto  e"

    const/4 v4, 0x1

    const-string/jumbo p2, "tctxtcFeqaela:L G  re 0io xndtoE"

    const-string p2, "Failed to create EGL context: 0x"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {}, Landroid/opengl/EGL14;->eglGetError()I

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    throw p0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    throw p0
.end method

.method private createSurfaceInternal(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "surface"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    instance-of v0, p1, Landroid/view/Surface;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-nez v0, :cond_1

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    instance-of v0, p1, Landroid/graphics/SurfaceTexture;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v0, "ets  euTtShbbara pecue t ee ioutusrSar rnrxmuIff"

    const-string v0, "eSx tbm fuetsorucaSuruierTI t eefc  aaphurertn b"

    const/4 v5, 0x6

    const-string/jumbo v0, "oS mt ecrehmre retSrunu usupf areTxaeIitbet acuf"

    const-string v0, "Input must be either a Surface or SurfaceTexture"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    throw p1

    :cond_1
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->checkIsNotReleased()V

    const/4 v4, 0x6

    move v5, v4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-ne v0, v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/16 v0, 0x3038

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v4, 0x0

    move v5, v4

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglConfig:Landroid/opengl/EGLConfig;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    invoke-static {v1, v2, p1, v0, v3}, Landroid/opengl/EGL14;->eglCreateWindowSurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;Ljava/lang/Object;[II)Landroid/opengl/EGLSurface;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    invoke-static {}, Landroid/opengl/EGL14;->eglGetError()I

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v5, 0x5

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eq v0, v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/16 v0, 0x3000

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-ne p1, v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-void

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v4, 0x3

    or-int/2addr v5, v4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const-string/jumbo v2, "l d oeeuai tt0e roiundwoweFr:cfa sc"

    const-string v2, "0dwueluoo tiairtedfa an rec:Fces w "

    const-string/jumbo v2, "xowenb0ftuirit lc adeae: dwcer Fsa "

    const-string v2, "Failed to create window surface: 0x"

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    throw v0

    :cond_3
    const/4 v5, 0x6

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string v0, "AyLG ruhepSl sdfnurEa aaa"

    const-string v0, " auaaG pedrA EhSrsLnyflae"

    const/4 v5, 0x5

    const-string v0, "GanrEa pArceya sdl ShLeua"

    const-string v0, "Already has an EGLSurface"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    throw p1
.end method

.method private static getEglConfig(Landroid/opengl/EGLDisplay;[I)Landroid/opengl/EGLConfig;
    .locals 12
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "eglDisplay",
            "configAttributes"
        }
    .end annotation

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x6

    const/4 v0, 0x1

    const/4 v11, 0x2

    new-array v9, v0, [Landroid/opengl/EGLConfig;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    new-array v0, v0, [I

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    const/4 v3, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    const/4 v5, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    const/4 v8, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    const/4 v6, 0x1

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v4, v9

    move-object v4, v9

    move-object v4, v9

    move-object v4, v9

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-static/range {v1 .. v8}, Landroid/opengl/EGL14;->eglChooseConfig(Landroid/opengl/EGLDisplay;[II[Landroid/opengl/EGLConfig;II[II)Z

    move-result p0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-eqz p0, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    const/4 p0, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    aget p1, v0, p0

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x4

    if-lez p1, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    aget-object p0, v9, p0

    const/4 v11, 0x2

    const/4 v10, 0x2

    if-eqz p0, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x2

    return-object p0

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string/jumbo p1, "selthgnCqonun rugrleoeoeCldq "

    const-string/jumbo p1, "rnhnleutqrolodn lgeeoiuCs Ceg"

    const/4 v11, 0x4

    const-string p1, "ClsntCl donerngi lurohoeesgeu"

    const-string p1, "eglChooseConfig returned null"

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x1

    throw p0

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-string/jumbo p1, "fnmmi LygEd  ctanGthnioeUgbain lc  fno"

    const-string p1, "Unable to find any matching EGL config"

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    throw p0

    :cond_2
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    const-string v0, "e:eooes s0Cahxg doioglnifl"

    const-string/jumbo v0, "lisxshe oegegfa lofn0iodC:"

    const/4 v11, 0x4

    const-string/jumbo v0, "neoglbhaesC 0fgi:flioodC e"

    const-string v0, "eglChooseConfig failed: 0x"

    const/4 v11, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x0

    invoke-static {}, Landroid/opengl/EGL14;->eglGetError()I

    move-result v0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    throw p0
.end method

.method private static getEglDisplay()Landroid/opengl/EGLDisplay;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0}, Landroid/opengl/EGL14;->eglGetDisplay(I)Landroid/opengl/EGLDisplay;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget-object v2, Landroid/opengl/EGL14;->EGL_NO_DISPLAY:Landroid/opengl/EGLDisplay;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eq v1, v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v2, 0x2

    const/4 v5, 0x5

    new-array v2, v2, [I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v3, 0x1

    const/4 v5, 0x1

    invoke-static {v1, v2, v0, v2, v3}, Landroid/opengl/EGL14;->eglInitialize(Landroid/opengl/EGLDisplay;[II[II)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    return-object v1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v2, "1lGa iuot: i aLE04 zetmnnixlei"

    const-string v2, "e1 mtn tiiaL0Eiezx:ba4Gl inl o"

    const/4 v5, 0x6

    const-string/jumbo v2, "lna4etzpi 0Uboia eltE:iGLi n1 "

    const-string v2, "Unable to initialize EGL14: 0x"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {}, Landroid/opengl/EGL14;->eglGetError()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    throw v0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v5, 0x5

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    move v5, v4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const-string/jumbo v2, "s ead1tiqo0 a bllneg:t4y LExpo "

    const-string v2, " 4dEoa tLela 1tyi0nxUle obgp s:"

    const/4 v5, 0x3

    const-string/jumbo v2, "pLsEie1U0:latx  G4ed sng ytlo b"

    const-string v2, "Unable to get EGL14 display: 0x"

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {}, Landroid/opengl/EGL14;->eglGetError()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    throw v0
.end method

.method public static isEGL14Supported()Z
    .locals 8

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string/jumbo v1, "v emosnSDbrKi"

    const-string v1, "SiD:nbrsevKo "

    const/4 v7, 0x0

    const-string v1, "DSivorn:so  K"

    const-string v1, "SDK version: "

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    sget v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->CURRENT_SDK_VERSION:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const-string v2, "Gru:Eb et4pi1Sp. ous"

    const-string/jumbo v2, "prdp1GuEou s4eitS: ."

    const/4 v7, 0x3

    const-string v2, "G.oed1uut E:4ir pSps"

    const-string v2, ". isEGL14Supported: "

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v2, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v3, 0x0

    const/4 v7, 0x1

    const/16 v4, 0x12

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-lt v1, v4, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    move v5, v2

    move v5, v2

    const/4 v7, 0x4

    move v5, v2

    move v5, v2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    move v5, v3

    move v5, v3

    const/4 v7, 0x4

    move v5, v3

    move v5, v3

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string/jumbo v5, "le1Egs4pB"

    const/4 v7, 0x3

    const-string v5, "e14glaEpB"

    const-string v5, "EglBase14"

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {v5, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-lt v1, v4, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    goto :goto_1

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    move v2, v3

    move v2, v3

    const/4 v7, 0x3

    move v2, v3

    move v2, v3

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    return v2
.end method


# virtual methods
.method public createDummyPbufferSurface()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, v0, v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->createPbufferSurface(II)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public createPbufferSurface(II)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "width",
            "height"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->checkIsNotReleased()V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-ne v0, v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/16 v0, 0x3056

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/16 v1, 0x3038

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/16 v2, 0x3057

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    filled-new-array {v2, p1, v0, p2, v1}, [I

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglConfig:Landroid/opengl/EGLConfig;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x0

    or-int/2addr v5, v3

    const/4 v4, 0x3

    move v5, v4

    invoke-static {v1, v2, v0, v3}, Landroid/opengl/EGL14;->eglCreatePbufferSurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLConfig;[II)Landroid/opengl/EGLSurface;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v4, 0x0

    move v5, v4

    invoke-static {}, Landroid/opengl/EGL14;->eglGetError()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object v2, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eq v1, v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/16 v1, 0x3000

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-ne v0, v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v4, 0x0

    and-int/2addr v5, v4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo v3, "siieefh q  rrotlewaiubu tctcz  aexdslf Freiepa f"

    const/4 v5, 0x3

    const-string/jumbo v3, "la  ietiqdboaeft rfz eexufe  irFhsreltcw uias ce"

    const-string v3, "Failed to create pixel buffer surface with size "

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const-string/jumbo p1, "x"

    const-string/jumbo p1, "x"

    const/4 v5, 0x4

    const-string/jumbo p1, "x"

    const-string/jumbo p1, "x"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo p1, "x:0 "

    const-string/jumbo p1, "x 0:"

    const/4 v5, 0x7

    const-string p1, " x0:"

    const-string p1, ": 0x"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v1, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    throw v1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string p2, "casylhun Sds aArrLE aGase"

    const-string p2, "SasAaEGu crynLleerasah d "

    const/4 v5, 0x5

    const-string p2, "Already has an EGLSurface"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    throw p1
.end method

.method public createSurface(Landroid/graphics/SurfaceTexture;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "surfaceTexture"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->createSurfaceInternal(Ljava/lang/Object;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public createSurface(Landroid/view/Surface;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "surface"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->createSurfaceInternal(Ljava/lang/Object;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public detachCurrent()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->lock:Ljava/lang/Object;

    const/4 v4, 0x4

    move v5, v4

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-object v2, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    sget-object v3, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-static {v1, v2, v2, v3}, Landroid/opengl/EGL14;->eglMakeCurrent(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;Landroid/opengl/EGLSurface;Landroid/opengl/EGLContext;)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v3, "tm mteeDxacieedag 0fllrh:Cn"

    const-string/jumbo v3, "hagmDanC0exeluttceer :flid "

    const/4 v5, 0x2

    const-string v3, "edlaoin:ufrctDeegxlC0ahr te"

    const-string v3, "eglDetachCurrent failed: 0x"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {}, Landroid/opengl/EGL14;->eglGetError()I

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    throw v1

    :catchall_0
    move-exception v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    throw v1
.end method

.method public bridge synthetic getEglBaseContext()Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->getEglBaseContext()Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public getEglBaseContext()Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;

    const/4 v3, 0x3

    const/4 v2, 0x7

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglContext:Landroid/opengl/EGLContext;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;-><init>(Landroid/opengl/EGLContext;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0
.end method

.method public hasSurface()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v3, 0x2

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v3, 0x1

    if-eq v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v0
.end method

.method public makeCurrent()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->checkIsNotReleased()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v4, 0x3

    shl-int/2addr v5, v4

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eq v0, v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->lock:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {}, Landroid/opengl/EGL14;->eglGetCurrentContext()Landroid/opengl/EGLContext;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/16 v2, 0x3059

    invoke-static {v2}, Landroid/opengl/EGL14;->eglGetCurrentSurface(I)Landroid/opengl/EGLSurface;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglContext:Landroid/opengl/EGLContext;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v3, v1}, Landroid/opengl/EGLContext;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Landroid/opengl/EGLSurface;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    monitor-exit v0

    const/4 v4, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v5, 0x4

    iget-object v3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglContext:Landroid/opengl/EGLContext;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v1, v2, v2, v3}, Landroid/opengl/EGL14;->eglMakeCurrent(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;Landroid/opengl/EGLSurface;Landroid/opengl/EGLContext;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-void

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v3, "MteClbrk0g:oneaidl  eaufx"

    const-string/jumbo v3, "ld:aofeatMgikxurerln0Ce  "

    const/4 v5, 0x4

    const-string/jumbo v3, "rledaruflikau eM0enegxC :"

    const-string v3, "eglMakeCurrent failed: 0x"

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {}, Landroid/opengl/EGL14;->eglGetError()I

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    shr-int/2addr v5, v4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    throw v1

    :catchall_0
    move-exception v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    throw v1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v5, 0x0

    const-string/jumbo v1, "nNc// ap cerucmrSatk Lftnreo-Gb aeu"

    const-string v1, "crceabLkuaf /cnreeG m -arSu noNtEt/"

    const/4 v5, 0x0

    const-string v1, "eeuntracqo -/aLekr cc N uEGStfn/ ar"

    const-string v1, "No EGLSurface - can\'t make current"

    const/4 v4, 0x4

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    throw v0
.end method

.method public release()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->checkIsNotReleased()V

    invoke-virtual {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->detachCurrent()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->releaseSurface()V

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglContext:Landroid/opengl/EGLContext;

    invoke-static {v0, v1}, Landroid/opengl/EGL14;->eglDestroyContext(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLContext;)Z

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {}, Landroid/opengl/EGL14;->eglReleaseThread()Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0}, Landroid/opengl/EGL14;->eglTerminate(Landroid/opengl/EGLDisplay;)Z

    const/4 v3, 0x5

    sget-object v0, Landroid/opengl/EGL14;->EGL_NO_CONTEXT:Landroid/opengl/EGLContext;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglContext:Landroid/opengl/EGLContext;

    const/4 v2, 0x0

    move v3, v2

    sget-object v0, Landroid/opengl/EGL14;->EGL_NO_DISPLAY:Landroid/opengl/EGLDisplay;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglConfig:Landroid/opengl/EGLConfig;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method public releaseSurface()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v3, 0x3

    const/4 v2, 0x4

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eq v0, v1, :cond_0

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v1, v0}, Landroid/opengl/EGL14;->eglDestroySurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;)Z

    const/4 v2, 0x2

    or-int/2addr v3, v2

    sget-object v0, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method public surfaceHeight()I
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v0, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-array v0, v0, [I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/16 v3, 0x3056

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v1, v2, v3, v0, v4}, Landroid/opengl/EGL14;->eglQuerySurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;I[II)Z

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    aget v0, v0, v4

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    return v0
.end method

.method public surfaceWidth()I
    .locals 7

    const/4 v6, 0x7

    const/4 v0, 0x5

    const/4 v0, 0x1

    xor-int/2addr v6, v0

    const/4 v5, 0x1

    or-int/2addr v6, v5

    new-array v0, v0, [I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/16 v3, 0x3057

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v1, v2, v3, v0, v4}, Landroid/opengl/EGL14;->eglQuerySurface(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;I[II)Z

    const/4 v5, 0x7

    move v6, v5

    aget v0, v0, v4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    return v0
.end method

.method public swapBuffers()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->checkIsNotReleased()V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eq v0, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    sget-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->lock:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v1, v2}, Landroid/opengl/EGL14;->eglSwapBuffers(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;)Z

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v4, 0x3

    throw v1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string v1, " /scnLecsusow-af u tfpSuEN reabG ar"

    const-string/jumbo v1, "o w aSu/cafa e-re/fub tnspsrEc NGLu"

    const/4 v4, 0x3

    const-string v1, "/frmb/SN uL s E o-caecrwGsu etanpff"

    const-string v1, "No EGLSurface - can\'t swap buffers"

    const/4 v4, 0x7

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw v0
.end method

.method public swapBuffers(J)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "timeStampNs"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->checkIsNotReleased()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    sget-object v1, Landroid/opengl/EGL14;->EGL_NO_SURFACE:Landroid/opengl/EGLSurface;

    const/4 v4, 0x5

    const/4 v3, 0x3

    if-eq v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    sget-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->lock:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v1, v2, p1, p2}, Landroid/opengl/EGLExt;->eglPresentationTimeANDROID(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;J)Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglDisplay:Landroid/opengl/EGLDisplay;

    const/4 v4, 0x4

    iget-object p2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->eglSurface:Landroid/opengl/EGLSurface;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1, p2}, Landroid/opengl/EGL14;->eglSwapBuffers(Landroid/opengl/EGLDisplay;Landroid/opengl/EGLSurface;)Z

    const/4 v4, 0x7

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    throw p1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string p2, "cba/o  ssSpoefua LNfpar Getnuf-r/cE"

    const-string p2, "aSeta/-ps Ga e/nLcwfufNo  srprEbufc"

    const/4 v4, 0x6

    const-string p2, " /a SbN/ ruwGaprt-bssfEnaecceL fuo "

    const-string p2, "No EGLSurface - can\'t swap buffers"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    throw p1
.end method
