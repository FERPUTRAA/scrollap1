.class public Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;
.super Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Context"
.end annotation


# instance fields
.field private final eglContext:Ljavax/microedition/khronos/egl/EGLContext;


# direct methods
.method public constructor <init>(Ljavax/microedition/khronos/egl/EGLContext;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "eglContext"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;->eglContext:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$000(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;)Ljavax/microedition/khronos/egl/EGLContext;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~lsb oi~os@~~b~-M@~~1 m@~@ ~oy  ~o@@~f~@dSc@~@~@@@@@@ ~i@@~ol ~K ofr/ @@u/~ a t  4~~  ~n.ibtv ~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;->eglContext:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v1, 0x3

    return-object p0
.end method
