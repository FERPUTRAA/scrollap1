.class public Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;
    }
.end annotation


# static fields
.field private static final OES_FRAGMENT_SHADER_STRING:Ljava/lang/String; = "#extension GL_OES_EGL_image_external : require\nprecision mediump float;\nvarying vec2 interp_tc;\n\nuniform samplerExternalOES oes_tex;\n\nvoid main() {\n  gl_FragColor = texture2D(oes_tex, interp_tc);\n}\n"

.field private static final RGB_FRAGMENT_SHADER_STRING:Ljava/lang/String; = "precision mediump float;\nvarying vec2 interp_tc;\n\nuniform sampler2D rgb_tex;\n\nvoid main() {\n  gl_FragColor = texture2D(rgb_tex, interp_tc);\n}\n"

.field private static final VERTEX_SHADER_STRING:Ljava/lang/String; = "varying vec2 interp_tc;\nattribute vec4 in_pos;\nattribute vec4 in_tc;\n\nuniform mat4 texMatrix;\n\nvoid main() {\n    gl_Position = in_pos;\n    interp_tc = (texMatrix * in_tc).xy;\n}\n"

.field private static final YUV_FRAGMENT_SHADER_STRING:Ljava/lang/String; = "precision mediump float;\nvarying vec2 interp_tc;\n\nuniform sampler2D y_tex;\nuniform sampler2D u_tex;\nuniform sampler2D v_tex;\n\nvoid main() {\n  float y = texture2D(y_tex, interp_tc).r * 1.16438;\n  float u = texture2D(u_tex, interp_tc).r;\n  float v = texture2D(v_tex, interp_tc).r;\n  gl_FragColor = vec4(y + 1.59603 * v - 0.874202,                       y - 0.391762 * u - 0.812968 * v + 0.531668,                       y + 2.01723 * u - 1.08563, 1);\n}\n"

.field private static final mTexcoords:Ljava/nio/FloatBuffer;

.field private static mVertices:Ljava/nio/FloatBuffer;


# instance fields
.field private mFrameHeight:I

.field private mFrameWidth:I

.field private final shaders:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/16 v0, 0x8

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-array v1, v0, [F

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    fill-array-data v1, :array_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->createFloatBuffer([F)Ljava/nio/FloatBuffer;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    sput-object v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mVertices:Ljava/nio/FloatBuffer;

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    new-array v0, v0, [F

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    fill-array-data v0, :array_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->createFloatBuffer([F)Ljava/nio/FloatBuffer;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    sput-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mTexcoords:Ljava/nio/FloatBuffer;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void

    :array_0
    .array-data 4
        -0x40800000    # -1.0f
        -0x40800000    # -1.0f
        0x3f800000    # 1.0f
        -0x40800000    # -1.0f
        -0x40800000    # -1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x0
        0x3f800000    # 1.0f
        0x0
        0x0
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
        0x3f800000    # 1.0f
    .end array-data
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mFrameWidth:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mFrameHeight:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Ljava/util/IdentityHashMap;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/IdentityHashMap;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->shaders:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method private configCanvas(IIII)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "srcWidth",
            "srcHeight",
            "viewWidth",
            "viewHeight"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s-c l@~oo ~@@~~~@@~ /nK@MaSyv @ ~1~ @~ ~lo@t ~s~@~~/@f@f~ 4@i .~ @@i ~~@~ brmtoo@ @u@b d~b~ oi"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    int-to-float p1, p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    int-to-float p2, p2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    div-float/2addr p1, p2

    const/4 v2, 0x0

    or-int/2addr v3, v2

    int-to-float p2, p3

    const/4 v3, 0x5

    const/4 v2, 0x3

    int-to-float p3, p4

    const/4 v3, 0x4

    div-float/2addr p2, p3

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    cmpl-float p3, p1, p2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/high16 p4, 0x3f800000    # 1.0f

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-lez p3, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    div-float/2addr p2, p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    div-float/2addr p1, p2

    const/4 v2, 0x7

    or-int/2addr v3, v2

    move p2, p4

    move p2, p4

    const/4 v3, 0x1

    move p2, p4

    move p2, p4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    move p4, p1

    move p4, p1

    const/4 v3, 0x2

    move p4, p1

    move p4, p1

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object p1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mVertices:Ljava/nio/FloatBuffer;

    const/4 v2, 0x7

    move v3, v2

    neg-float p3, p4

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    const/4 v0, 0x0

    shr-int/2addr v3, v0

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1, v0, p3}, Ljava/nio/FloatBuffer;->put(IF)Ljava/nio/FloatBuffer;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    sget-object p1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mVertices:Ljava/nio/FloatBuffer;

    const/4 v3, 0x7

    const/4 v2, 0x2

    neg-float v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, v1, v0}, Ljava/nio/FloatBuffer;->put(IF)Ljava/nio/FloatBuffer;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object p1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mVertices:Ljava/nio/FloatBuffer;

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v3, 0x6

    and-int/2addr v2, v1

    const/4 v3, 0x0

    invoke-virtual {p1, v1, p4}, Ljava/nio/FloatBuffer;->put(IF)Ljava/nio/FloatBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object p1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mVertices:Ljava/nio/FloatBuffer;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v1, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1, v1, v0}, Ljava/nio/FloatBuffer;->put(IF)Ljava/nio/FloatBuffer;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-object p1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mVertices:Ljava/nio/FloatBuffer;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x4

    shl-int/2addr v3, v0

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p1, v0, p3}, Ljava/nio/FloatBuffer;->put(IF)Ljava/nio/FloatBuffer;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object p1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mVertices:Ljava/nio/FloatBuffer;

    const/4 v3, 0x3

    const/4 p3, 0x5

    const/4 v3, 0x3

    xor-int/2addr v2, p3

    const/4 v3, 0x2

    invoke-virtual {p1, p3, p2}, Ljava/nio/FloatBuffer;->put(IF)Ljava/nio/FloatBuffer;

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget-object p1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mVertices:Ljava/nio/FloatBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p3, 0x6

    const/4 v2, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1, p3, p4}, Ljava/nio/FloatBuffer;->put(IF)Ljava/nio/FloatBuffer;

    const/4 v3, 0x0

    const/4 v2, 0x3

    sget-object p1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mVertices:Ljava/nio/FloatBuffer;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 p3, 0x7

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, p3, p2}, Ljava/nio/FloatBuffer;->put(IF)Ljava/nio/FloatBuffer;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method private drawRectangle(IIII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "x",
            "y",
            "width",
            "height"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p1, p2, p3, p4}, Landroid/opengl/GLES20;->glViewport(IIII)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 p2, 0x4

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p3, 0x5

    const/4 v1, 0x5

    const/4 v0, 0x5

    invoke-static {p3, p1, p2}, Landroid/opengl/GLES20;->glDrawArrays(III)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method private prepareShader(Ljava/lang/String;[F)V
    .locals 18
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fragmentShader",
            "texMatrix"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    iget-object v2, v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->shaders:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    iget-object v2, v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->shaders:Ljava/util/Map;

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;

    goto/16 :goto_1

    :cond_0
    new-instance v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;

    invoke-direct {v2, v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;-><init>(Ljava/lang/String;)V

    iget-object v3, v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->shaders:Ljava/util/Map;

    invoke-interface {v3, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v3, v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->glShader:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;

    invoke-virtual {v3}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->useProgram()V

    const-string/jumbo v3, "r 1m _/2v .uu  3m7n _ ); eax n3 re ey; rrm  f;err r6p0sci e    ia;9an n ,t fm/t=C 03t 1_;o)_ 50 v t/t2 yDg2xnp p +tfn9 1ot /mm=0/2m8nDpx/no _8l} *tm i-u le.o8 nn*  1o  ua f6,_sao;d6puvD(tul2etf -7raF i8ta e= t .cnept8f6n yr7   t v24  x ix,(ctt  6y. 1x-; ros t=ru/*l- ocox4( .ln /a uc9 vn,1  4.(n Ds2 lu/nnr_ ee)o  ixn2n3f 2 pp8/ae xen un2reilD.0er_1;tg g m *n . 0)vi/;u 02r. r50eit+ yeul ( 3r Dcepet ie   yna,t_1 cd ti 6ei.+r)r,  _yrol5v3s/*2  v ev62 i {t _t/e 1m"

    const-string v3, "e/sn ,v1e2{ t27 u*er1( _) rnex;secl 6.; nm_mr0/i( fp=r1u*n8u.gfeli0* uu.rp}7n8  -  62+pnesae=/snev  Drp)//-5rv te u-in  o  2t /em)o.0m ea(i       v r 2nx9_  t6it v .mvpn lC f *.4( aort_tp9tp  t+5vl/8xn,.  /=x anc x rr30c st u  eo/ 1 re ;,tiu   xplt,tr DFn_p y 9r78ii1;ooy.._nuelrei  t  2ttry3D 2g  i *5ta  m  3  o ta= 1/82f,xtDvn 4yxt 0n cga+m0 cen1  tnt);3)3ifD; .ynn2ot 6 0tll  e/xem e/l  ar2_ e8e- c  nyr2iu;f6 ;/u4_ aevm,1a1(uon;_3  dni02 Dr6_6fy o_2c r   d o"

    const-string v3, " o(foDn6 .65 o={3y .   rxe_   oxi1l tanvto; 2mC02*t/1 yalD ;  _  vtpnn7nc7i2n o_ortDu5f/ ni(o 2..er,)ve  *empnn) . e 2d, ye/t at rey0 /il  42F-gn+u  1t i;e D_unt 1frea*so2tfc_ r9o; ury rp  n vv;t51tcasl rid 8u1;l e3.g 01x ip.  9 n28 0vp o23)gx8e.u 0..   rpn-pt e8 ere, x 6/(et 14xf2tuc*r/rm  2v t -  =n yt  7 y/foe6*D  u   fnc0;e1 a +lm u 2u t/(cv / Drn _  c9v,_n  p6rnex u3nnem, m= u  m0_e4 m) t8/;+ 6pi_,rexa tlt3s _8nm.3l=/x rr}s/(; e lt2irea6 i 0/_tat ia-i)ir"

    const-string/jumbo v3, "precision mediump float;\nvarying vec2 interp_tc;\n\nuniform sampler2D y_tex;\nuniform sampler2D u_tex;\nuniform sampler2D v_tex;\n\nvoid main() {\n  float y = texture2D(y_tex, interp_tc).r * 1.16438;\n  float u = texture2D(u_tex, interp_tc).r;\n  float v = texture2D(v_tex, interp_tc).r;\n  gl_FragColor = vec4(y + 1.59603 * v - 0.874202,                       y - 0.391762 * u - 0.812968 * v + 0.531668,                       y + 2.01723 * u - 1.08563, 1);\n}\n"

    if-ne v1, v3, :cond_1

    iget-object v1, v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->glShader:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;

    const-string v3, "_eymx"

    const-string v3, "bt_ey"

    const-string/jumbo v3, "y_tex"

    invoke-virtual {v1, v3}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->getUniformLocation(Ljava/lang/String;)I

    move-result v1

    iput v1, v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tex0Location:I

    iget-object v1, v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->glShader:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;

    const-string v3, "_etuo"

    const-string/jumbo v3, "u_tex"

    invoke-virtual {v1, v3}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->getUniformLocation(Ljava/lang/String;)I

    move-result v1

    iput v1, v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tex1Location:I

    iget-object v1, v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->glShader:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;

    const-string/jumbo v3, "xubet"

    const-string v3, "bx_te"

    const-string/jumbo v3, "xvpet"

    const-string/jumbo v3, "v_tex"

    invoke-virtual {v1, v3}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->getUniformLocation(Ljava/lang/String;)I

    move-result v1

    iput v1, v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tex2Location:I

    goto :goto_0

    :cond_1
    const-string/jumbo v3, "r/ vtpplqirDlf g / ( )r genmia__s/ugcx cloDunrm,te e /n(nFv/eeo=ooen ne{yr/rntnmtcama}_;r)ttarb;;ritmenadideopgp_l2snnn rcixui2birigfnn/t_i;xpe2o C/v "

    const-string/jumbo v3, "ii D ru2fpn cottisrae vufdc)nisrnr elrral/tm;en(xauln; /}g_mnnog /e_p)ntnaictDpCr_x xl_y rncgv2pgr/em///rn =mb;te,aeibme(dgop  /tnti{nnF_oru;o 2eoivei"

    const-string/jumbo v3, "nnsgc)_r{iprncgv_oseu cvnisglt ei,x_ ttlemom nixxrirCgng  _mF=eapid;ft;ordaetn t2lnp npnm/e/at;//r (tiDrc/tveneu/ofye(/u;a/brn)2rm}oD bpr _n nl2ei oar"

    const-string/jumbo v3, "precision mediump float;\nvarying vec2 interp_tc;\n\nuniform sampler2D rgb_tex;\n\nvoid main() {\n  gl_FragColor = texture2D(rgb_tex, interp_tc);\n}\n"

    if-ne v1, v3, :cond_2

    iget-object v1, v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->glShader:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;

    const-string/jumbo v3, "rtgmpbx"

    const-string/jumbo v3, "pbt_xgr"

    const-string v3, "bgreo_t"

    const-string/jumbo v3, "rgb_tex"

    invoke-virtual {v1, v3}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->getUniformLocation(Ljava/lang/String;)I

    move-result v1

    iput v1, v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tex0Location:I

    goto :goto_0

    :cond_2
    const-string v3, "eacn,brcftq)atigla(oveeant rnr eotuin/rgr#u_aSlv/ensnD;nGerm:p_sotitnrmryu eiu e xL=r/tpeogt_/fnnxSGmx}eO ;2tnnp/2nr(Ea iid /s )Eex/nECel ie_ t/ c_{l_eexoi _Ltmovnotnle_esn;aeeiiqlEcmpoOona;/de sr _iprFgirxn"

    const-string/jumbo v3, "rar);noiqm s;ldcnmcntrair neCt/f_aamox{);=pOn(ieE o/orp ettanrnl:, _nt  Eerx;cSx_xd( /nxrsEtoqerrSn__}eioeienp2gpte / _nmx efu n2eeetyEepn/amarravg /g_#eOnnunicGgitLleeooiv_e/LlllDovstG/in ni/e stt u_Fuiseri"

    const-string/jumbo v3, "unL/=,u;i rtts_dL oxnrep/D r/eEppatrere eirpx tnEn)SxriaG_d t_tre vgl ogc)ep_gniren_ginae2rnoe/_n;/cffovnuii;nanva}min_mxec niG/ ln rs;:cmCl#oai_meeOen_eS/ intoetEqlus moxl{/Ft(2n xtsrsneOm(yuoeaae l/rot itE"

    const-string v3, "#extension GL_OES_EGL_image_external : require\nprecision mediump float;\nvarying vec2 interp_tc;\n\nuniform samplerExternalOES oes_tex;\n\nvoid main() {\n  gl_FragColor = texture2D(oes_tex, interp_tc);\n}\n"

    if-ne v1, v3, :cond_6

    iget-object v1, v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->glShader:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;

    const-string/jumbo v3, "pe_oset"

    const-string/jumbo v3, "oes_tex"

    invoke-virtual {v1, v3}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->getUniformLocation(Ljava/lang/String;)I

    move-result v1

    iput v1, v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tex0Location:I

    :goto_0
    const-string/jumbo v1, "rnsviaemli nruhitnua relostfsedaIgmf . eaz"

    const-string/jumbo v1, "ieehuea qrn msv intl rfneiaalrosgafzi.mIdu"

    const-string v1, "Initialize fragment shader uniform values."

    invoke-static {v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->checkNoGLES2Error(Ljava/lang/String;)V

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    :goto_1
    iget-object v2, v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->glShader:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;

    invoke-virtual {v2}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->useProgram()V

    iget v2, v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tex0Location:I

    const/4 v3, 0x0

    const/4 v4, -0x1

    if-eq v2, v4, :cond_3

    invoke-static {v2, v3}, Landroid/opengl/GLES20;->glUniform1i(II)V

    :cond_3
    iget v2, v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tex1Location:I

    const/4 v5, 0x1

    if-eq v2, v4, :cond_4

    invoke-static {v2, v5}, Landroid/opengl/GLES20;->glUniform1i(II)V

    :cond_4
    iget v2, v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tex2Location:I

    if-eq v2, v4, :cond_5

    const/4 v4, 0x2

    invoke-static {v2, v4}, Landroid/opengl/GLES20;->glUniform1i(II)V

    :cond_5
    iget v2, v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->posLocation:I

    invoke-static {v2}, Landroid/opengl/GLES20;->glEnableVertexAttribArray(I)V

    iget v2, v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tcLocation:I

    invoke-static {v2}, Landroid/opengl/GLES20;->glEnableVertexAttribArray(I)V

    iget v6, v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->posLocation:I

    const/4 v7, 0x2

    const/16 v8, 0x1406

    const/4 v9, 0x0

    const/4 v10, 0x0

    sget-object v11, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mVertices:Ljava/nio/FloatBuffer;

    invoke-static/range {v6 .. v11}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    iget v12, v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tcLocation:I

    const/4 v13, 0x2

    const/16 v14, 0x1406

    const/4 v15, 0x0

    const/16 v16, 0x0

    sget-object v17, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mTexcoords:Ljava/nio/FloatBuffer;

    invoke-static/range {v12 .. v17}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    iget v1, v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->texMatrixLocation:I

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    invoke-static {v1, v5, v3, v2, v3}, Landroid/opengl/GLES20;->glUniformMatrix4fv(IIZ[FI)V

    return-void

    :cond_6
    new-instance v2, Ljava/lang/IllegalStateException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, ":os mrgawhmsdnfnnekr an e"

    const-string/jumbo v4, "honmgrw  nmrtn kaaefdn:es"

    const-string/jumbo v4, "th mUnenwrnodf sg rmeaank"

    const-string v4, "Unknown fragment shader: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v2
.end method


# virtual methods
.method public drawOes(I[FIIIIII)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "oesTextureId",
            "texMatrix",
            "frameWidth",
            "frameHeight",
            "viewportX",
            "viewportY",
            "viewportWidth",
            "viewportHeight"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo v0, "gt conuFSotpSEr:( on/Cr/ie nr ep /eatte/iiixo)t_ant}lGEml)ssxx urDeoemx_eoa;u ietxL im;nef=nr ena2;aar_meG io/nnt_/tno e#(t/gcimtdLe {_coenan  yiomOnsirenvvqre_l/xrofg;l_pn_ilE,caiprnOe2E persd /nelreg_tnuns"

    const-string/jumbo v0, "yttmo/Gns)eipetiln_pe;ee,rctoeupm}oi/t in(dScorrDxSiunEd  tvFse;r/elrnesv/Entatq ceiOo;nlg=au#gsto_/  /(gG oel_ax_L;raiLxt_vCloreoogi/nmeeunctn_fi{i _prnmnt:lr  rrf nr_x2n)paimxnea inm/ asOxea/nenneee 2E E _"

    const/4 v2, 0x1

    const-string/jumbo v0, "o u2 bie ii_tuDe_ipoeEErl;ctOl ,eq/ e2i;mOr_rGnS (rLvEnfre aoGtne Faximysein_dmr_ren/=lrvnnonircxs _n v;aig nfxspsonpncna_lio:t ;gsE})ttxnm_e_#x/rCtm{tt eod xLacntlrreae/i)pieoptgnaegnete/m o/Sue/rnu(eanl/e "

    const-string v0, "#extension GL_OES_EGL_image_external : require\nprecision mediump float;\nvarying vec2 interp_tc;\n\nuniform samplerExternalOES oes_tex;\n\nvoid main() {\n  gl_FragColor = texture2D(oes_tex, interp_tc);\n}\n"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0, v0, p2}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->prepareShader(Ljava/lang/String;[F)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    const p2, 0x84c0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p2}, Landroid/opengl/GLES20;->glActiveTexture(I)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget p2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mFrameWidth:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-ne p2, p3, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    iget p2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mFrameHeight:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eq p2, p4, :cond_1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0, p3, p4, p7, p8}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->configCanvas(IIII)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    iput p3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mFrameWidth:I

    const/4 v2, 0x2

    iput p4, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->mFrameHeight:I

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const p2, 0x8d65

    const/4 v2, 0x4

    invoke-static {p2, p1}, Landroid/opengl/GLES20;->glBindTexture(II)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, p5, p6, p7, p8}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->drawRectangle(IIII)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p2, p1}, Landroid/opengl/GLES20;->glBindTexture(II)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public drawRgb(I[FIIIIII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "textureId",
            "texMatrix",
            "frameWidth",
            "frameHeight",
            "viewportX",
            "viewportY",
            "viewportWidth",
            "viewportHeight"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const-string/jumbo p3, "xpefmou b imnrs  cxdnrlxirennte_;tt/2i/ (_;ui cmegatbovn ttv{li_gno;n i)lod_}) _Diov,eyg=Frpfre npmre/e/b;D n2gCi/tlt crnaarnu(s2tm orern/caen/u/praip"

    const-string/jumbo p3, "s irbblrnm(/nrt 2/n pefelidla;so{ocgndgre;opn(Dpeort) /fxa 2 xnpl_ /yCcmn  unn/eu_ge}xD/omrt=ri_br2eeitm/tpF_gtna_,ucvveam)iiai;;t/r cinv o ntn rritne"

    const/4 v1, 0x3

    const-string/jumbo p3, "linlv/ppe;oe/ on  rna2atr(oc{;;tcrp=i _//een/ie ;dgr_etia gn xm  xbiir,c x)_}tmrF(dnmeee/Dn_fnctbn2ilDngti_ )gn/rtonCrum2evl imf/ptts yaguurnvrpaposnr"

    const-string/jumbo p3, "precision mediump float;\nvarying vec2 interp_tc;\n\nuniform sampler2D rgb_tex;\n\nvoid main() {\n  gl_FragColor = texture2D(rgb_tex, interp_tc);\n}\n"

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0, p3, p2}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->prepareShader(Ljava/lang/String;[F)V

    const/4 v0, 0x3

    const/4 v1, 0x0

    const p2, 0x84c0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p2}, Landroid/opengl/GLES20;->glActiveTexture(I)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/16 p2, 0xde1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {p2, p1}, Landroid/opengl/GLES20;->glBindTexture(II)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0, p5, p6, p7, p8}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->drawRectangle(IIII)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p2, p1}, Landroid/opengl/GLES20;->glBindTexture(II)V

    const/4 v0, 0x5

    move v1, v0

    return-void
.end method

.method public drawYuv([I[FIIIIII)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "yuvTextures",
            "texMatrix",
            "frameWidth",
            "frameHeight",
            "viewportX",
            "viewportY",
            "viewportWidth",
            "viewportHeight"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string p3, "_e2nrt__q v,  o 0 fx8t03f8x 0  ftveD uf  y(ae4trreen D22 /n_9 g6 svD. au r0 t{  e  0riuc-e //5 p c(mu  etl1e,  l m30r; o1-nnr2/r2(y Dn4*e.  xe i.)i;dma* ;D7 y).in66t o ,r l.8un  u  ri8  5gvo 1 2r pt n ;e3  =e9 gn3y e vtrrvmtt/ 2pf+l c  t/_/a/ tm=9,6pml,, y ao/1aa 6.t*-teCt8- n =}y;. 6+i2/;3pa  4en 1s(l* oep cnor nrisrct; 0/ )n_pyut    eta)n 7m6t  nonvr oml reiivfl )_se;u(r +ipx8e  xre2t .n o 1uxie. 2t2n  *.u23 0ncx tm u t_ .i co5;_ 7xud=Fx_ pn/f/1a2D lin _ u1"

    const-string/jumbo p3, "eu.v ,umst/v(ui12n _r F ut    un2n .e ernr_2/tteu9 / x_a/ f=rlo2t o fl26/a_ r/3fe+iai )t2 r8ut5;/8 t8 6l rng =fe 0 l.  c De 7;nx.pm) myn1n1 ,3-5rvDi8c*+;  e n2 g 2 t=y6av_2o0Ccte7o 1em  iay p/ y   D   yt 4D,e  . _ ne0(st-  /enttel.D4t*x.r7;  o p;.( _4 1v t/,0 nplv(a u.39/ 109-ncp)6r ra _t_  6af5l  1m6o  vru3m;pue*  y1rx  8ymm  n}a_pi 2u;o2x/n er aun(f3oc eele 32v6iecst tp,8 niereet r))go.r-_r*  nnl0o,n{n;0  n rx+ v    i . rt0/tiox  D mcd ti=2 d;nuf s* i xxitp"

    const/4 v3, 0x3

    const-string/jumbo p3, "r s i t;o__1/p(rua y6ennalD nlx _=/nunx  0  c -  sonu 4 , i0it t  m,/ie0tfs. __r -tyt)  r nun 2fc(n_aio2r er er a;o.u2  m {= s/g) t r=e 8 nfe tv  gt  e6 xrv, .mnx.l8o9m 211 *;vi;ra*n;/ xd t53vo c; 1a+ueo20nnc    C) ef  frpvo_,-6s1imDl  3*4e2y2 /3ltt_9tiyu  tu6D2t- /aa =.;*;* ,n men  xi;u/u.o3m 71.ext 8F gc rv 2  etu21t 0 p8e/e1o(0pnixc..0 fict5 v _t(x y.a )er(t  l6.l0 2e t/3  m6nnr3o2p+,nf8   mrtnrpe pi    lp e19 lv2 err5eyunyD }D8e_ 4 er7Dt)iv7r p  //dn6a_+ "

    const-string/jumbo p3, "precision mediump float;\nvarying vec2 interp_tc;\n\nuniform sampler2D y_tex;\nuniform sampler2D u_tex;\nuniform sampler2D v_tex;\n\nvoid main() {\n  float y = texture2D(y_tex, interp_tc).r * 1.16438;\n  float u = texture2D(u_tex, interp_tc).r;\n  float v = texture2D(v_tex, interp_tc).r;\n  gl_FragColor = vec4(y + 1.59603 * v - 0.874202,                       y - 0.391762 * u - 0.812968 * v + 0.531668,                       y + 2.01723 * u - 1.08563, 1);\n}\n"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p0, p3, p2}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->prepareShader(Ljava/lang/String;[F)V

    const/4 v3, 0x5

    const/4 p2, 0x0

    const/4 v3, 0x0

    move v2, p2

    move v2, p2

    const/4 v3, 0x3

    move p3, p2

    move p3, p2

    const/4 v3, 0x4

    move p3, p2

    move p3, p2

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/16 p4, 0xde1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const v0, 0x84c0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-ge p3, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    add-int/2addr v0, p3

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0}, Landroid/opengl/GLES20;->glActiveTexture(I)V

    const/4 v3, 0x2

    aget v0, p1, p3

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p4, v0}, Landroid/opengl/GLES20;->glBindTexture(II)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/lit8 p3, p3, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    invoke-direct {p0, p5, p6, p7, p8}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->drawRectangle(IIII)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    move p1, p2

    move p1, p2

    const/4 v3, 0x2

    move p1, p2

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-ge p1, v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    add-int p3, p1, v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-static {p3}, Landroid/opengl/GLES20;->glActiveTexture(I)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p4, p2}, Landroid/opengl/GLES20;->glBindTexture(II)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/lit8 p1, p1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_1

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method

.method public release()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->shaders:Ljava/util/Map;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->glShader:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->release()V

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;->shaders:Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method
