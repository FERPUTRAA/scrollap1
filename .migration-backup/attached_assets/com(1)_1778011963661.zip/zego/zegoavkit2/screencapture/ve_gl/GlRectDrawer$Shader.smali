.class Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "Shader"
.end annotation


# instance fields
.field public final glShader:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;

.field public final posLocation:I

.field public final tcLocation:I

.field public tex0Location:I

.field public tex1Location:I

.field public tex2Location:I

.field public final texMatrixLocation:I


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fragmentShader"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v1, "fiseitninut  _sae ni/nocm4gn  tiy;c n=v*stdMn4aiecrcam cncoenrtim xcan=eepp ( nvatt i)ty;p ;ttnr /x _u;osi/x l/gb(a nn/rntvea /n/ ;i__/xtx innr)_;tt /te/bnit  i_n}r Ptv{os4rep iu2ot_oiMri"

    const-string/jumbo v1, "tcstm;t2m _n_n/)ntr;t}o  /y) i vx (e syaiit _Meen=n{enbn;Ptnrrpcula pnpaanineitrrt/untxx  tpmnois;(nitv4excna rot_t gb4i;ne/  n _u */n.cgrx v Mi 4voda int /at_i_//icentctoiri;fci/  =iose/"

    const/4 v3, 0x2

    const-string/jumbo v1, "y/imt{txn ts   ilo4i*)m ns_fr;tno)t /meptiP atenrpep=/ngaxban/;ncmt;/oit uncciMar v /_2 _ nn/vnv.i ini  ay_viM/o  _pcannense;unt /xtttxnir r4t(/ieii=e4tn;}    _outrivxntbcn_cerreat oi(;dc"

    const-string/jumbo v1, "varying vec2 interp_tc;\nattribute vec4 in_pos;\nattribute vec4 in_tc;\n\nuniform mat4 texMatrix;\n\nvoid main() {\n    gl_Position = in_pos;\n    interp_tc = (texMatrix * in_tc).xy;\n}\n"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1, p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->glShader:Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo p1, "xexmoatrM"

    const-string/jumbo p1, "txemMxrta"

    const/4 v3, 0x2

    const-string/jumbo p1, "xaetibtrM"

    const-string/jumbo p1, "texMatrix"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->getUniformLocation(Ljava/lang/String;)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    iput p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->texMatrixLocation:I

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo p1, "uipoos"

    const-string/jumbo p1, "nsopoi"

    const/4 v3, 0x0

    const-string/jumbo p1, "ipops_"

    const-string/jumbo p1, "in_pos"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->getAttribLocation(Ljava/lang/String;)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->posLocation:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v1, "cniq_"

    const-string v1, "bi_nc"

    const/4 v3, 0x7

    const-string v1, "cnsi_"

    const-string/jumbo v1, "in_tc"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->getAttribLocation(Ljava/lang/String;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tcLocation:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1}, Landroid/opengl/GLES20;->glEnableVertexAttribArray(I)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0}, Landroid/opengl/GLES20;->glEnableVertexAttribArray(I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p1, -0x1

    const/4 v2, 0x0

    move v3, v2

    iput p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tex2Location:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tex1Location:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer$Shader;->tex0Location:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method
