.class public Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    return-void
.end method

.method public static checkNoGLES2Error(Ljava/lang/String;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "msg"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " @sm~l~v ~n ~i@SM@@@ ~rlb~ a o@1~~/  ~~@.~@ sfo~4@f@ucdo@i~b@@o/~ o-~b@~  ~t~i@~tK ~ o@@~ @y @~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    invoke-static {}, Landroid/opengl/GLES20;->glGetError()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v4, 0x4

    const/4 v3, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const-string/jumbo p0, "sLomE 2r:rr0GS: "

    const-string p0, "GSs2 orE::r0 rL "

    const/4 v4, 0x1

    const-string/jumbo p0, "rLe o2oSr:E:  0r"

    const-string p0, ": GLES20 error: "

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {v1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    throw v1
.end method

.method public static createFloatBuffer([F)Ljava/nio/FloatBuffer;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "coords"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    array-length v0, p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    mul-int/lit8 v0, v0, 0x4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {}, Ljava/nio/ByteOrder;->nativeOrder()Ljava/nio/ByteOrder;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->asFloatBuffer()Ljava/nio/FloatBuffer;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Ljava/nio/FloatBuffer;->put([F)Ljava/nio/FloatBuffer;

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x4

    or-int/2addr v2, p0

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Ljava/nio/FloatBuffer;->position(I)Ljava/nio/Buffer;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0
.end method

.method public static generateFrameBuffer(I)I
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "textureId"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v0, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-array v1, v0, [I

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v1, v2}, Landroid/opengl/GLES20;->glGenFramebuffers(I[II)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    aget v0, v1, v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const v1, 0x8d40

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v1, v0}, Landroid/opengl/GLES20;->glBindFramebuffer(II)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    const v3, 0x8ce0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/16 v4, 0xde1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v1, v3, v4, p0, v2}, Landroid/opengl/GLES20;->glFramebufferTexture2D(IIIII)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v1}, Landroid/opengl/GLES20;->glCheckFramebufferStatus(I)I

    move-result p0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    const v1, 0x8cd5

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eq p0, v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 p0, -0x1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    return p0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string/jumbo p0, "rtaeBbfgefFeuermmne"

    const-string/jumbo p0, "gBemneFefmrreeatruf"

    const/4 v6, 0x4

    const-string p0, "afenreueueergamFBfr"

    const-string/jumbo p0, "generateFrameBuffer"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->checkNoGLES2Error(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    return v0
.end method

.method public static generateTexture(I)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-array v1, v0, [I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x3

    invoke-static {v0, v1, v2}, Landroid/opengl/GLES20;->glGenTextures(I[II)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    aget v0, v1, v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-static {p0, v0}, Landroid/opengl/GLES20;->glBindTexture(II)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/16 v1, 0x2801

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const v2, 0x46180400    # 9729.0f

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {p0, v1, v2}, Landroid/opengl/GLES20;->glTexParameterf(IIF)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/16 v1, 0x2800

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {p0, v1, v2}, Landroid/opengl/GLES20;->glTexParameterf(IIF)V

    const/4 v4, 0x2

    const/16 v1, 0x2802

    const/4 v4, 0x3

    const/4 v3, 0x3

    const v2, 0x47012f00    # 33071.0f

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p0, v1, v2}, Landroid/opengl/GLES20;->glTexParameterf(IIF)V

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/16 v1, 0x2803

    const/4 v4, 0x3

    invoke-static {p0, v1, v2}, Landroid/opengl/GLES20;->glTexParameterf(IIF)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo p0, "oregerxpTeteaen"

    const-string/jumbo p0, "retuoerxegeeTan"

    const/4 v4, 0x2

    const-string p0, "eenrxrTeqteuage"

    const-string/jumbo p0, "generateTexture"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->checkNoGLES2Error(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    return v0
.end method
