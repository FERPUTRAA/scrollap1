.class public final Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;
.super Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;
    }
.end annotation


# static fields
.field private static final EGL_CONTEXT_CLIENT_VERSION:I = 0x3098


# instance fields
.field private final egl:Ljavax/microedition/khronos/egl/EGL10;

.field private eglConfig:Ljavax/microedition/khronos/egl/EGLConfig;

.field private eglContext:Ljavax/microedition/khronos/egl/EGLContext;

.field private eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

.field private eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;


# direct methods
.method public constructor <init>(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;[I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "sharedContext",
            "configAttributes"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {}, Ljavax/microedition/khronos/egl/EGLContext;->getEGL()Ljavax/microedition/khronos/egl/EGL;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast v0, Ljavax/microedition/khronos/egl/EGL10;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->getEglDisplay()Ljavax/microedition/khronos/egl/EGLDisplay;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, v0, p2}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->getEglConfig(Ljavax/microedition/khronos/egl/EGLDisplay;[I)Ljavax/microedition/khronos/egl/EGLConfig;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object p2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglConfig:Ljavax/microedition/khronos/egl/EGLConfig;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0, p1, v0, p2}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->createEglContext(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;)Ljavax/microedition/khronos/egl/EGLContext;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglContext:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method private checkIsNotReleased()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_DISPLAY:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eq v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglContext:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_CONTEXT:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eq v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglConfig:Ljavax/microedition/khronos/egl/EGLConfig;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x5

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "cssbnjeohh e  eaTedissrl satb"

    const-string v1, "essabhnhee cee ra oij ltsTdbs"

    const/4 v3, 0x7

    const-string v1, " blmh eeTordasec ibehtsesanj "

    const-string v1, "This object has been released"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v2, 0x2

    throw v0
.end method

.method private createEglContext(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;)Ljavax/microedition/khronos/egl/EGLContext;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "sharedContext",
            "eglDisplay",
            "eglConfig"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz p1, :cond_1

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;->access$000(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;)Ljavax/microedition/khronos/egl/EGLContext;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_CONTEXT:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eq v0, v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v4, 0x5

    const-string/jumbo p2, "lanxoevoCditnI trsmdh"

    const-string p2, "Cnxmitvdad thersIeonl"

    const/4 v4, 0x7

    const-string/jumbo p2, "nhledbCsoxtiIedtrvaan"

    const-string p2, "Invalid sharedContext"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    throw p1

    :cond_1
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v0, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/16 v1, 0x3038

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/16 v2, 0x3098

    const/4 v4, 0x2

    const/4 v3, 0x4

    filled-new-array {v2, v0, v1}, [I

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez p1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    sget-object p1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_CONTEXT:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;->access$000(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;)Ljavax/microedition/khronos/egl/EGLContext;

    move-result-object p1

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-object v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->lock:Ljava/lang/Object;

    const/4 v3, 0x1

    move v4, v3

    monitor-enter v1

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v4, 0x7

    const/4 v3, 0x6

    invoke-interface {v2, p2, p3, p1, v0}, Ljavax/microedition/khronos/egl/EGL10;->eglCreateContext(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;Ljavax/microedition/khronos/egl/EGLContext;[I)Ljavax/microedition/khronos/egl/EGLContext;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    sget-object p2, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_CONTEXT:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eq p1, p2, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object p1

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo p3, "tGiertu oaotenle:d  cEceL  ta0xF"

    const-string/jumbo p3, "totEo et c l0nc eGLoaeFea x:tidr"

    const/4 v4, 0x2

    const-string/jumbo p3, "iceLeeGpclt a :ooex   xttEnFt0da"

    const-string p3, "Failed to create EGL context: 0x"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object p3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {p3}, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I

    move-result p3

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    throw p1

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw p1
.end method

.method private createSurfaceInternal(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "nativeWindow"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    instance-of v0, p1, Landroid/view/SurfaceHolder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    instance-of v0, p1, Landroid/graphics/SurfaceTexture;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v0, "r d erTaqfcbIshf ourulea ete ubreitax tuHpreSr Stecmeo"

    const-string/jumbo v0, "tfretbeerieube oc    sfdTHuapehrou rarnaerIuSmSttcelx "

    const/4 v5, 0x6

    const-string/jumbo v0, "r soHtfi nexrue aSbdrtu  etoeepcretaecsreuulSafmhITr  "

    const-string v0, "Input must be either a SurfaceHolder or SurfaceTexture"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    throw p1

    :cond_1
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->checkIsNotReleased()V

    const/4 v5, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-ne v0, v1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/16 v0, 0x3038

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglConfig:Ljavax/microedition/khronos/egl/EGLConfig;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {v1, v2, v3, p1, v0}, Ljavax/microedition/khronos/egl/EGL10;->eglCreateWindowSurface(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;Ljava/lang/Object;[I)Ljavax/microedition/khronos/egl/EGLSurface;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    iget-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {p1}, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v5, 0x5

    const/4 v4, 0x1

    if-eq v0, v1, :cond_2

    const/4 v5, 0x0

    const/16 v0, 0x3000

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-ne p1, v0, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-void

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v4, 0x3

    move v5, v4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo v2, "uuemowwrd:nlcrfx c 0ade etF eioaai "

    const-string v2, "e Fofduaa e:u ewwireadin xo 0trlctc"

    const/4 v5, 0x5

    const-string v2, " f:sorieoliuFecwcd n de etr twoaax0"

    const-string v2, "Failed to create window surface: 0x"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    throw v0

    :cond_3
    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v0, "d rSfbleancphAseyrLE aa G"

    const-string v0, "LrAancSpGdeaa r feEhlays "

    const/4 v5, 0x2

    const-string v0, "caasAeu lyfuEed haSr nrLG"

    const-string v0, "Already has an EGLSurface"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    throw p1
.end method

.method private getEglConfig(Ljavax/microedition/khronos/egl/EGLDisplay;[I)Ljavax/microedition/khronos/egl/EGLConfig;
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "eglDisplay",
            "configAttributes"
        }
    .end annotation

    const/4 v9, 0x4

    const/4 v0, 0x1

    const/4 v9, 0x6

    move v8, v0

    move v8, v0

    const/4 v9, 0x7

    new-array v7, v0, [Ljavax/microedition/khronos/egl/EGLConfig;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    new-array v0, v0, [I

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    const/4 v5, 0x1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, v7

    move-object v4, v7

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-interface/range {v1 .. v6}, Ljavax/microedition/khronos/egl/EGL10;->eglChooseConfig(Ljavax/microedition/khronos/egl/EGLDisplay;[I[Ljavax/microedition/khronos/egl/EGLConfig;I[I)Z

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x2

    if-eqz p1, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 p1, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    aget p2, v0, p1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-lez p2, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    aget-object p1, v7, p1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-eqz p1, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    return-object p1

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string/jumbo p2, "rgnrsehpgoiloeeoueC qtndlnClf"

    const-string p2, "dn fuCerqsliotgnguhelonCeelro"

    const/4 v9, 0x6

    const-string/jumbo p2, "iluehnnrqdCuo ofgCtsee logeln"

    const-string p2, "eglChooseConfig returned null"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    throw p1

    :cond_1
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v9, 0x3

    const-string p2, "cisodnog  ftnfnchn nbEl UatL aiasyig e"

    const-string p2, "a syUfiind on Lingoc tangbt aEmne lhcf"

    const/4 v9, 0x2

    const-string/jumbo p2, "om ma bleinyinfcoEnnicLdUaGthftg  agn "

    const-string p2, "Unable to find any matching EGL config"

    const/4 v9, 0x5

    const/4 v8, 0x0

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    throw p1

    :cond_2
    const/4 v9, 0x2

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v9, 0x6

    const/4 v8, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string/jumbo v0, "ggCoo fela:nlfdCm0sx oeihe"

    const-string/jumbo v0, "nChmfCelesfggia:0oxe  ilod"

    const/4 v9, 0x0

    const-string/jumbo v0, "igo:Cboa0f lignflxCosedee "

    const-string v0, "eglChooseConfig failed: 0x"

    const/4 v9, 0x0

    const/4 v8, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-interface {v0}, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    throw p1
.end method

.method private getEglDisplay()Ljavax/microedition/khronos/egl/EGLDisplay;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_DEFAULT_DISPLAY:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0, v1}, Ljavax/microedition/khronos/egl/EGL10;->eglGetDisplay(Ljava/lang/Object;)Ljavax/microedition/khronos/egl/EGLDisplay;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_DISPLAY:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eq v0, v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-array v1, v1, [I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v4, 0x5

    const/4 v3, 0x5

    invoke-interface {v2, v0, v1}, Ljavax/microedition/khronos/egl/EGL10;->eglInitialize(Ljavax/microedition/khronos/egl/EGLDisplay;[I)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    move v4, v3

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v4, 0x6

    const/4 v3, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v2, "ielLlaunna ibo0E  GtUot:ie1zx0"

    const-string/jumbo v2, "lanboe lizt U 0tL0aoixnE1:eiGi"

    const/4 v4, 0x3

    const-string/jumbo v2, "i i ztipao0lLeti ex G0UbnnlE:1"

    const-string v2, "Unable to initialize EGL10: 0x"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {v2}, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    throw v0

    :cond_1
    const/4 v3, 0x4

    move v4, v3

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v2, "Ea yil bqgeGU:bpLl ntsd10a0oxte"

    const-string/jumbo v2, "oUx0 bt yL sglbep0nGaid1 Ealet:"

    const-string/jumbo v2, "t1sEGapa0gdel Lbt:yxse  nU 0ilo"

    const-string v2, "Unable to get EGL10 display: 0x"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {v2}, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    throw v0
.end method


# virtual methods
.method public createDummyPbufferSurface()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, v0, v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->createPbufferSurface(II)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public createPbufferSurface(II)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "width",
            "height"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->checkIsNotReleased()V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-ne v0, v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/16 v0, 0x3056

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/16 v1, 0x3038

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/16 v2, 0x3057

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    filled-new-array {v2, p1, v0, p2, v1}, [I

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglConfig:Ljavax/microedition/khronos/egl/EGLConfig;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {v1, v2, v3, v0}, Ljavax/microedition/khronos/egl/EGL10;->eglCreatePbufferSurface(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;[I)Ljavax/microedition/khronos/egl/EGLSurface;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v5, 0x3

    invoke-interface {v0}, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-object v2, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eq v1, v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/16 v1, 0x3000

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-ne v0, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string v3, "Feim rxosfluatr i eaf hbif i  deetucpes tlwuraez"

    const-string/jumbo v3, "fia lbutfur p feictuxz  teFseli e eei orwaashdcr"

    const/4 v5, 0x5

    const-string v3, "ehiaoureeezts e f uefxl o icdtsfaairblFte p i rw"

    const-string v3, "Failed to create pixel buffer surface with size "

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string/jumbo p1, "x"

    const-string/jumbo p1, "x"

    const/4 v5, 0x2

    const-string/jumbo p1, "x"

    const-string/jumbo p1, "x"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string p1, ":x0 "

    const-string/jumbo p1, "x: 0"

    const/4 v5, 0x6

    const-string/jumbo p1, "x :0"

    const-string p1, ": 0x"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {v1, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    throw v1

    :cond_1
    const/4 v5, 0x0

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string p2, "cyeaGb Ahu nSrasEf Lrdpla"

    const-string/jumbo p2, "rarLA ap aldyGuEse nfeShc"

    const/4 v5, 0x3

    const-string p2, "aaaruEul Ge daScLnfsyrhe "

    const-string p2, "Already has an EGLSurface"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    throw p1
.end method

.method public createSurface(Landroid/graphics/SurfaceTexture;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "surfaceTexture"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->createSurfaceInternal(Ljava/lang/Object;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public createSurface(Landroid/view/Surface;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "surface"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$1FakeSurfaceHolder;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {v0, p0, p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$1FakeSurfaceHolder;-><init>(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;Landroid/view/Surface;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->createSurfaceInternal(Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public detachCurrent()V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    sget-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->lock:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    sget-object v3, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    sget-object v4, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_CONTEXT:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {v1, v2, v3, v3, v4}, Ljavax/microedition/khronos/egl/EGL10;->eglMakeCurrent(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLSurface;Ljavax/microedition/khronos/egl/EGLSurface;Ljavax/microedition/khronos/egl/EGLContext;)Z

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    return-void

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string v3, " h eetDpllaCnudtxer:cirg0qe"

    const-string/jumbo v3, "uiregelrq:chl  atdanx0teCDe"

    const/4 v6, 0x2

    const-string/jumbo v3, "lenrar0dqtlDui:c Cge txefeh"

    const-string v3, "eglDetachCurrent failed: 0x"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    iget-object v3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {v3}, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    throw v1

    :catchall_0
    move-exception v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    throw v1
.end method

.method public getEglBaseContext()Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglContext:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;-><init>(Ljavax/microedition/khronos/egl/EGLContext;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0
.end method

.method public hasSurface()Z
    .locals 4

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eq v0, v1, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return v0
.end method

.method public makeCurrent()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->checkIsNotReleased()V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eq v0, v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    sget-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->lock:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-interface {v1}, Ljavax/microedition/khronos/egl/EGL10;->eglGetCurrentContext()Ljavax/microedition/khronos/egl/EGLContext;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/16 v3, 0x3059

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v2, v3}, Ljavax/microedition/khronos/egl/EGL10;->eglGetCurrentSurface(I)Ljavax/microedition/khronos/egl/EGLSurface;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglContext:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v6, 0x6

    if-ne v1, v3, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v5, 0x2

    move v6, v5

    if-ne v2, v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-void

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v4, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v1, v2, v4, v4, v3}, Ljavax/microedition/khronos/egl/EGL10;->eglMakeCurrent(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLSurface;Ljavax/microedition/khronos/egl/EGLSurface;Ljavax/microedition/khronos/egl/EGLContext;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    return-void

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string v3, "aus0eekr:a  lnMlCftsirxde"

    const-string/jumbo v3, "lxs:kCndrg i0aaelfte eurM"

    const/4 v6, 0x1

    const-string v3, "alrmerfgua:0MedieC kxenl "

    const-string v3, "eglMakeCurrent failed: 0x"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    iget-object v3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-interface {v3}, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    throw v1

    :catchall_0
    move-exception v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    throw v1

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v6, 0x2

    const-string v1, " maEoSNfantrnca ucomc-ktGr/  / erLu"

    const-string v1, "aNkmL S acouat/ne r ruc/rtmf -cGEne"

    const/4 v6, 0x1

    const-string v1, "emcE-brL/ cSrkun  eeou N/rcGanf taa"

    const-string v1, "No EGLSurface - can\'t make current"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    move v6, v5

    throw v0
.end method

.method public release()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->checkIsNotReleased()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->releaseSurface()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->detachCurrent()V

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglContext:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v0, v1, v2}, Ljavax/microedition/khronos/egl/EGL10;->eglDestroyContext(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLContext;)Z

    const/4 v3, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {v0, v1}, Ljavax/microedition/khronos/egl/EGL10;->eglTerminate(Ljavax/microedition/khronos/egl/EGLDisplay;)Z

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v0, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_CONTEXT:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v4, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglContext:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget-object v0, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_DISPLAY:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglConfig:Ljavax/microedition/khronos/egl/EGLConfig;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void
.end method

.method public releaseSurface()V
    .locals 5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eq v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v4, 0x3

    const/4 v3, 0x0

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {v1, v2, v0}, Ljavax/microedition/khronos/egl/EGL10;->eglDestroySurface(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLSurface;)Z

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v0, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-void
.end method

.method public surfaceHeight()I
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v0, 0x1

    move v6, v0

    const/4 v5, 0x4

    and-int/2addr v6, v5

    new-array v0, v0, [I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/16 v4, 0x3056

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {v1, v2, v3, v4, v0}, Ljavax/microedition/khronos/egl/EGL10;->eglQuerySurface(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLSurface;I[I)Z

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    aget v0, v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    return v0
.end method

.method public surfaceWidth()I
    .locals 7

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-array v0, v0, [I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/16 v4, 0x3057

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v1, v2, v3, v4, v0}, Ljavax/microedition/khronos/egl/EGL10;->eglQuerySurface(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLSurface;I[I)Z

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    aget v0, v0, v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    return v0
.end method

.method public swapBuffers()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->checkIsNotReleased()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_SURFACE:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v5, 0x5

    if-eq v0, v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->lock:Ljava/lang/Object;

    const/4 v5, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->egl:Ljavax/microedition/khronos/egl/EGL10;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglDisplay:Ljavax/microedition/khronos/egl/EGLDisplay;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v3, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;->eglSurface:Ljavax/microedition/khronos/egl/EGLSurface;

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v1, v2, v3}, Ljavax/microedition/khronos/egl/EGL10;->eglSwapBuffers(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLSurface;)Z

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-void

    :catchall_0
    move-exception v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    throw v1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const-string/jumbo v1, "scScreurfLEwsuoeat-G   fan//pob u f"

    const-string v1, " oswoea f/rs/tSuGaruaLfncEebf-   pc"

    const/4 v5, 0x6

    const-string v1, "ce ubwapaG rstnaefN S fofcu/ EL/rsp"

    const-string v1, "No EGLSurface - can\'t swap buffers"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    and-int/2addr v5, v4

    throw v0
.end method
