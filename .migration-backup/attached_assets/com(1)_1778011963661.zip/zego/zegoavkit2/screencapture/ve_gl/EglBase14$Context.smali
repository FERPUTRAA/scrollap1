.class public Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;
.super Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Context"
.end annotation


# instance fields
.field private final egl14Context:Landroid/opengl/EGLContext;


# direct methods
.method public constructor <init>(Landroid/opengl/EGLContext;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "eglContext"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;->egl14Context:Landroid/opengl/EGLContext;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$000(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;)Landroid/opengl/EGLContext;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ms@@d~ 1~@~4~no@fb@    MoK@b/ rl~a ~~cob~@ v@@~  @@@ ~i~.o/~ @So@i~@~~~~~t  ~@lf@u~yt -s~o @ @~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;->egl14Context:Landroid/opengl/EGLContext;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method
