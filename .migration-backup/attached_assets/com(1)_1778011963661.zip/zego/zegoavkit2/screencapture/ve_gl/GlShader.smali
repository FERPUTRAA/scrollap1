.class public Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;
.super Ljava/lang/Object;


# static fields
.field private static final TAG:Ljava/lang/String; = "GlShader"


# instance fields
.field private program:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "vertexSource",
            "fragmentSource"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    const v0, 0x8b31

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0, p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->compileShader(ILjava/lang/String;)I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    const v0, 0x8b30

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, p2}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->compileShader(ILjava/lang/String;)I

    move-result p2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {}, Landroid/opengl/GLES20;->glCreateProgram()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v0, p1}, Landroid/opengl/GLES20;->glAttachShader(II)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-static {v0, p2}, Landroid/opengl/GLES20;->glAttachShader(II)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v0}, Landroid/opengl/GLES20;->glLinkProgram(I)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    filled-new-array {v0}, [I

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    iget v2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    const v3, 0x8b82

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v2, v3, v1, v0}, Landroid/opengl/GLES20;->glGetProgramiv(II[II)V

    const/4 v5, 0x7

    aget v0, v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-ne v0, v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p1}, Landroid/opengl/GLES20;->glDeleteShader(I)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {p2}, Landroid/opengl/GLES20;->glDeleteShader(I)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string p1, "CgsGlSirathradee "

    const-string p1, "Creating GlShader"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->checkNoGLES2Error(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string p2, "Colmilmg snp  trk:ra oud"

    const-string/jumbo p2, "l sn  kt rooiCrpalmnu:dg"

    const/4 v5, 0x7

    const-string/jumbo p2, "uog o: tr okn palorndClm"

    const-string p2, "Could not link program: "

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    iget p2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p2}, Landroid/opengl/GLES20;->glGetProgramInfoLog(I)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string p2, "edSmaGlh"

    const-string p2, "eSalrbhd"

    const-string p2, "GlShader"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x3

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget p2, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p2}, Landroid/opengl/GLES20;->glGetProgramInfoLog(I)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    throw p1

    :cond_1
    const/4 v5, 0x3

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v0, "go.d euarrE ParoL )taGe2fo0Siregrl(Crel "

    const-string v0, "Gr0moedal2ga.Peerf l r oigoEar(rLCS)e tr"

    const/4 v5, 0x4

    const-string v0, "LS:er. peGPe)milfaorCgetlaErrag do2( 0 r"

    const-string/jumbo v0, "glCreateProgram() failed. GLES20 error: "

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-static {}, Landroid/opengl/GLES20;->glGetError()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    throw p1
.end method

.method private static compileShader(ILjava/lang/String;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "shaderType",
            "source"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    invoke-static {p0}, Landroid/opengl/GLES20;->glCreateShader(I)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0, p1}, Landroid/opengl/GLES20;->glShaderSource(ILjava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0}, Landroid/opengl/GLES20;->glCompileShader(I)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    filled-new-array {p1}, [I

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const v2, 0x8b81

    const/4 v4, 0x5

    invoke-static {v0, v2, v1, p1}, Landroid/opengl/GLES20;->glGetShaderiv(II[II)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    aget p1, v1, p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-ne p1, v1, :cond_0

    const/4 v3, 0x6

    move v4, v3

    const-string p0, "dScbimerqleha"

    const-string p0, "Slciebeaohdrm"

    const/4 v4, 0x4

    const-string p0, "compileShader"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->checkNoGLES2Error(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    return v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v1, "e souleinra dhompltCd s u"

    const-string/jumbo v1, "p Cil uhoode sandmeut olr"

    const/4 v4, 0x3

    const-string v1, "de mlCsopu lehmndictooa  "

    const-string v1, "Could not compile shader "

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string p0, ":"

    const-string p0, ":"

    const/4 v4, 0x7

    const-string p0, ":"

    const-string p0, ":"

    const/4 v3, 0x4

    and-int/2addr v4, v3

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    move v4, v3

    invoke-static {v0}, Landroid/opengl/GLES20;->glGetShaderInfoLog(I)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string p1, "SGrholpd"

    const-string p1, "dGSrlehp"

    const/4 v4, 0x2

    const-string p1, "erdlGbaS"

    const-string p1, "GlShader"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {p1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v0}, Landroid/opengl/GLES20;->glGetShaderInfoLog(I)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    throw p0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x3

    move v4, v3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const-string/jumbo v0, "lEa.2Lurrlq (rdtC aer0ier )Ga hefeoeSg:"

    const-string/jumbo v0, "re:CE02 q She.daerSl iGoaLlg(rfae rter)"

    const/4 v4, 0x5

    const-string v0, "Ser  rrpt:eeai(Ea)gddl Caoh2rL reS.Gf0l"

    const-string/jumbo v0, "glCreateShader() failed. GLES20 error: "

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {}, Landroid/opengl/GLES20;->glGetError()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    throw p0
.end method


# virtual methods
.method public getAttribLocation(Ljava/lang/String;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "label"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eq v0, v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v0, p1}, Landroid/opengl/GLES20;->glGetAttribLocation(ILjava/lang/String;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-ltz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    return v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const-string v2, "eoult/nlqsodC a/  o"

    const-string/jumbo v2, "lasoot/celdu/   oCn"

    const/4 v4, 0x5

    const-string/jumbo v2, "olsad/ct/o oltCe n "

    const-string v2, "Could not locate \'"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo p1, "gnpm/ /airm o"

    const/4 v4, 0x1

    const-string/jumbo p1, "rgamomr i/ n/"

    const-string p1, "\' in program"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    throw v0

    :cond_1
    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v0, "parboe hsene oTa rolmhrgee ea"

    const-string/jumbo v0, "mahho ae e srlernebeTsogpare "

    const/4 v4, 0x5

    const-string/jumbo v0, "sealsbeh a emneor aT grehebrp"

    const-string v0, "The program has been released"

    const/4 v4, 0x0

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    throw p1
.end method

.method public getUniformLocation(Ljava/lang/String;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "label"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x0

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, -0x1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eq v0, v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v0, p1}, Landroid/opengl/GLES20;->glGetUniformLocation(ILjava/lang/String;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-ltz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    return v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string v2, "c  Cooutf/ lnioont/ mdurlua"

    const-string v2, "Could not locate uniform \'"

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo p1, "orrn/ bpgi pa"

    const-string/jumbo p1, "na mrbgiop /r"

    const/4 v4, 0x3

    const-string/jumbo p1, "rgpm o/aqi/r "

    const-string p1, "\' in program"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    throw v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v0, "absuoeaeenma rpelrr e edh shs"

    const-string/jumbo v0, "ldrr eu oaa neehaebeTh mesprs"

    const/4 v4, 0x5

    const-string/jumbo v0, "l omamrdeeeeehshaTge srp rab "

    const-string v0, "The program has been released"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    throw p1
.end method

.method public release()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v0, "Gapeolhd"

    const-string/jumbo v0, "hadlGeSp"

    const/4 v3, 0x3

    const-string/jumbo v0, "rdGelbha"

    const-string v0, "GlShader"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string/jumbo v1, "inDsleurhdaee.qg"

    const-string/jumbo v1, "hrlsieaeqnegD .d"

    const/4 v3, 0x0

    const-string v1, "eDdrilapg eh.nes"

    const-string v1, "Deleting shader."

    const/4 v3, 0x4

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eq v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0}, Landroid/opengl/GLES20;->glDeleteProgram(I)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput v1, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    :cond_0
    const/4 v3, 0x6

    return-void
.end method

.method public setVertexAttribArray(Ljava/lang/String;ILjava/nio/FloatBuffer;)V
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "label",
            "dimension",
            "buffer"
        }
    .end annotation

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    const/4 v8, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/4 v1, -0x1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-eq v0, v1, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p0, p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->getAttribLocation(Ljava/lang/String;)I

    move-result v2

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v2}, Landroid/opengl/GLES20;->glEnableVertexAttribArray(I)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    const/16 v4, 0x1406

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/4 v5, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v6, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x3

    move v3, p2

    move v3, p2

    const/4 v9, 0x4

    move v3, p2

    move v3, p2

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static/range {v2 .. v7}, Landroid/opengl/GLES20;->glVertexAttribPointer(IIIZILjava/nio/Buffer;)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string p1, "eAsxVeetrsrryrAtiatb"

    const/4 v9, 0x7

    const-string/jumbo p1, "sieryrtxqeAeVatttAbr"

    const-string/jumbo p1, "setVertexAttribArray"

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->checkNoGLES2Error(Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    return-void

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string p2, " rs ranlsepmdehemsg aabh eeTr"

    const-string p2, "eTpmah e ree nbra raeehdlgmss"

    const/4 v9, 0x2

    const-string/jumbo p2, "s rm Temesr gn aeplhdhobaeeae"

    const-string p2, "The program has been released"

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    throw p1
.end method

.method public useProgram()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlShader;->program:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    if-eq v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0}, Landroid/opengl/GLES20;->glUseProgram(I)V

    const/4 v3, 0x3

    const-string/jumbo v0, "laPooomerrgU"

    const-string v0, "emPloargUors"

    const/4 v3, 0x7

    const-string/jumbo v0, "sregrboPmlgU"

    const-string/jumbo v0, "glUseProgram"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->checkNoGLES2Error(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "meh bsueoa nshbread Tlaper eg"

    const-string v1, " a  rbepbo ehlegmhseenesTaadr"

    const/4 v3, 0x5

    const-string v1, " rrpe epeessnhade  eabgmaohTr"

    const-string v1, "The program has been released"

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    throw v0
.end method
