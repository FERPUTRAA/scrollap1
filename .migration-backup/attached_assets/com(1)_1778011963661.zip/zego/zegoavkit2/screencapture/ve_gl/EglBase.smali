.class public abstract Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;
    }
.end annotation


# static fields
.field public static final CONFIG_PIXEL_BUFFER:[I

.field public static final CONFIG_PIXEL_RGBA_BUFFER:[I

.field public static final CONFIG_PLAIN:[I

.field public static final CONFIG_RECORDABLE:[I

.field public static final CONFIG_RGBA:[I

.field private static final EGL_OPENGL_ES2_BIT:I = 0x4

.field private static final EGL_RECORDABLE_ANDROID:I = 0x3142

.field public static final lock:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    move v3, v2

    sput-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->lock:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/16 v0, 0x9

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-array v0, v0, [I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    fill-array-data v0, :array_0

    const/4 v2, 0x7

    or-int/2addr v3, v2

    sput-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->CONFIG_PLAIN:[I

    const/4 v3, 0x1

    const/16 v0, 0xb

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-array v1, v0, [I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    fill-array-data v1, :array_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    sput-object v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->CONFIG_RGBA:[I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-array v1, v0, [I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    fill-array-data v1, :array_2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    sput-object v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->CONFIG_PIXEL_BUFFER:[I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/16 v1, 0xd

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-array v1, v1, [I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    fill-array-data v1, :array_3

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    sput-object v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->CONFIG_PIXEL_RGBA_BUFFER:[I

    const/4 v3, 0x7

    new-array v0, v0, [I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    fill-array-data v0, :array_4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    sput-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->CONFIG_RECORDABLE:[I

    const/4 v2, 0x4

    const/4 v2, 0x6

    return-void

    nop

    :array_0
    .array-data 4
        0x3024
        0x8
        0x3023
        0x8
        0x3022
        0x8
        0x3040
        0x4
        0x3038
    .end array-data

    :array_1
    .array-data 4
        0x3024
        0x8
        0x3023
        0x8
        0x3022
        0x8
        0x3021
        0x8
        0x3040
        0x4
        0x3038
    .end array-data

    :array_2
    .array-data 4
        0x3024
        0x8
        0x3023
        0x8
        0x3022
        0x8
        0x3040
        0x4
        0x3033
        0x1
        0x3038
    .end array-data

    :array_3
    .array-data 4
        0x3024
        0x8
        0x3023
        0x8
        0x3022
        0x8
        0x3021
        0x8
        0x3040
        0x4
        0x3033
        0x1
        0x3038
    .end array-data

    :array_4
    .array-data 4
        0x3024
        0x8
        0x3023
        0x8
        0x3022
        0x8
        0x3040
        0x4
        0x3142
        0x1
        0x3038
    .end array-data
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static create()Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "oMso~~~t@ @m~ b~ @  ~@v~/ d/~~@oy~~r 14~~ b~l aff~~Stio@ @@i @  c@-l @~o~s @@ o@@~~K@b@i@ n@.~u@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->CONFIG_PLAIN:[I

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->create(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;[I)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    return-object v0
.end method

.method public static create(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sharedContext"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->CONFIG_PLAIN:[I

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->create(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;[I)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public static create(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;[I)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "sharedContext",
            "configAttributes"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->isEGL14Supported()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    instance-of v0, p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;

    const/4 v2, 0x0

    const/4 v1, 0x5

    if-eqz v0, :cond_1

    :cond_0
    new-instance v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;-><init>(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14$Context;[I)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance v0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;

    const/4 v2, 0x1

    const/4 v1, 0x3

    check-cast p0, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10;-><init>(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase10$Context;[I)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    return-object v0
.end method


# virtual methods
.method public abstract createDummyPbufferSurface()V
.end method

.method public abstract createPbufferSurface(II)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "width",
            "height"
        }
    .end annotation
.end method

.method public abstract createSurface(Landroid/graphics/SurfaceTexture;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "surfaceTexture"
        }
    .end annotation
.end method

.method public abstract createSurface(Landroid/view/Surface;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "surface"
        }
    .end annotation
.end method

.method public abstract detachCurrent()V
.end method

.method public abstract getEglBaseContext()Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;
.end method

.method public abstract hasSurface()Z
.end method

.method public abstract makeCurrent()V
.end method

.method public abstract release()V
.end method

.method public abstract releaseSurface()V
.end method

.method public abstract surfaceHeight()I
.end method

.method public abstract surfaceWidth()I
.end method

.method public abstract swapBuffers()V
.end method
