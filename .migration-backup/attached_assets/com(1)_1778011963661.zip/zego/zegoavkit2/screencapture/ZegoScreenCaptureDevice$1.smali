.class Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->getSurface()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

.field final synthetic val$barrier:Ljava/util/concurrent/CountDownLatch;


# direct methods
.method constructor <init>(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            "this$0",
            "val$barrier"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->val$barrier:Ljava/util/concurrent/CountDownLatch;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~os~@S@a~@  ~i @~ s4l@~u~  t@ ob~ @~@o~t.ivon@@@~~M1 bK  ~@ ~~@cl~~~fo~r @-~dfbo~/@@i  @@ m@@y~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    sget-object v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->CONFIG_PIXEL_BUFFER:[I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v1, v2}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->create(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;[I)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$102(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->hasSurface()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v0, :cond_1

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->createDummyPbufferSurface()V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->makeCurrent()V

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$202(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->releaseSurface()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    throw v0

    :cond_1
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-static {}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase14;->isEGL14Supported()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$302(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Z)Z

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const v1, 0x8d65

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlUtil;->generateTexture(I)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$402(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;I)I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v1, Landroid/graphics/SurfaceTexture;

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v2}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$400(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v2

    const/4 v5, 0x1

    invoke-direct {v1, v2}, Landroid/graphics/SurfaceTexture;-><init>(I)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$502(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Landroid/graphics/SurfaceTexture;)Landroid/graphics/SurfaceTexture;

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$500(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/graphics/SurfaceTexture;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$600(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v2}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$700(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/graphics/SurfaceTexture;->setDefaultBufferSize(II)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance v1, Landroid/view/Surface;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v2}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$500(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/graphics/SurfaceTexture;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Landroid/view/Surface;-><init>(Landroid/graphics/SurfaceTexture;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$802(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Landroid/view/Surface;)Landroid/view/Surface;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$500(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/graphics/SurfaceTexture;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {v0, v1}, Landroid/graphics/SurfaceTexture;->setOnFrameAvailableListener(Landroid/graphics/SurfaceTexture$OnFrameAvailableListener;)V

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-nez v0, :cond_2

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->getEglBaseContext()Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    sget-object v2, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->CONFIG_RECORDABLE:[I

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v1, v2}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->create(Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase$Context;[I)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$902(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->hasSurface()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-nez v0, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1100(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-interface {v1}, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$Client;->getSurfaceTexture()Landroid/graphics/SurfaceTexture;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1002(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Landroid/graphics/SurfaceTexture;)Landroid/graphics/SurfaceTexture;

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1000(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/graphics/SurfaceTexture;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1200(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v2}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1300(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/graphics/SurfaceTexture;->setDefaultBufferSize(II)V

    :try_start_1
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1000(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/graphics/SurfaceTexture;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->createSurface(Landroid/graphics/SurfaceTexture;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->makeCurrent()V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x4

    new-instance v1, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {v1}, Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1402(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;)Lcom/zego/zegoavkit2/screencapture/ve_gl/GlRectDrawer;
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_1

    :catch_1
    move-exception v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$900(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/screencapture/ve_gl/EglBase;->releaseSurface()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void

    :cond_3
    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1700(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Landroid/os/Handler;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1500(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$DrawRunnable;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->this$0:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;

    const/4 v5, 0x5

    invoke-static {v2}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;->access$1600(Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice;)I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    int-to-long v2, v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureDevice$1;->val$barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void
.end method
