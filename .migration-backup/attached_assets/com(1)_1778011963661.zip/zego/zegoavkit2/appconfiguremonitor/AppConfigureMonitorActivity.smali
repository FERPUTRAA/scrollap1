.class Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;
.super Ljava/lang/Object;


# instance fields
.field private display_listener_:Landroid/hardware/display/DisplayManager$DisplayListener;

.field private mContext:Landroid/content/Context;

.field private mThis:J

.field private mUIHandler:Landroid/os/Handler;

.field private task_delay_internal_:I


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 v0, 0x64

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput v0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->task_delay_internal_:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mUIHandler:Landroid/os/Handler;

    const/4 v2, 0x2

    move v3, v2

    return-void
.end method

.method static synthetic access$000(Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "r@s@ @  @@Sbi@o~cua/ @vn~K~~odo~ ~@~@  o ~ ~@  ~  @sf~i@~ o1~@@~@@M/~~t.  b@4~~m@yl-fb~i@o ~~@lt"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget p0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->task_delay_internal_:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic access$100(Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;)Landroid/os/Handler;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mUIHandler:Landroid/os/Handler;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method static native onAppOrientationChanged(JI)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "pThis",
            "orientation"
        }
    .end annotation
.end method


# virtual methods
.method public StartDisplayListener()V
    .locals 5

    const/4 v4, 0x6

    new-instance v0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity$1;

    const/4 v4, 0x6

    invoke-direct {v0, p0}, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity$1;-><init>(Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->display_listener_:Landroid/hardware/display/DisplayManager$DisplayListener;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mContext:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v1, "sldmpiy"

    const-string v1, "display"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    check-cast v0, Landroid/hardware/display/DisplayManager;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->display_listener_:Landroid/hardware/display/DisplayManager$DisplayListener;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mUIHandler:Landroid/os/Handler;

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/hardware/display/DisplayManager;->registerDisplayListener(Landroid/hardware/display/DisplayManager$DisplayListener;Landroid/os/Handler;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method

.method public StopDisplayListener()V
    .locals 4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mContext:Landroid/content/Context;

    const/4 v3, 0x3

    const-string/jumbo v1, "slydoia"

    const-string/jumbo v1, "iysadlp"

    const/4 v3, 0x7

    const-string/jumbo v1, "ldsyibp"

    const-string v1, "display"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v0, Landroid/hardware/display/DisplayManager;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->display_listener_:Landroid/hardware/display/DisplayManager$DisplayListener;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/hardware/display/DisplayManager;->unregisterDisplayListener(Landroid/hardware/display/DisplayManager$DisplayListener;)V

    const/4 v3, 0x4

    const/4 v0, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->display_listener_:Landroid/hardware/display/DisplayManager$DisplayListener;

    const/4 v3, 0x3

    return-void
.end method

.method public declared-synchronized UpdateOrientationManual()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mContext:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v0, Landroid/app/ActivityManager$RunningAppProcessInfo;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0}, Landroid/app/ActivityManager$RunningAppProcessInfo;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mContext:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v2, "yiavctum"

    const-string v2, "aivmciyt"

    const/4 v4, 0x0

    const-string/jumbo v2, "yivcitap"

    const-string v2, "activity"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    check-cast v1, Landroid/app/ActivityManager;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v0}, Landroid/app/ActivityManager;->getMyMemoryState(Landroid/app/ActivityManager$RunningAppProcessInfo;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget v0, v0, Landroid/app/ActivityManager$RunningAppProcessInfo;->importance:I

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/16 v1, 0x64

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eq v0, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/16 v1, 0xc8

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-ne v0, v1, :cond_1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mContext:Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v1, "dqoypia"

    const-string v1, "dlapoiy"

    const/4 v4, 0x0

    const-string v1, "display"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    check-cast v0, Landroid/hardware/display/DisplayManager;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/hardware/display/DisplayManager;->getDisplay(I)Landroid/view/Display;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/view/Display;->getRotation()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-wide v1, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mThis:J

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v1, v2, v0}, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->onAppOrientationChanged(JI)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    monitor-exit p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    throw v0
.end method

.method public declared-synchronized init(Landroid/content/Context;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "ctx"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mContext:Landroid/content/Context;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    if-nez p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    monitor-exit p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 p1, -0x1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return p1

    :cond_0
    :try_start_1
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->StartDisplayListener()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    monitor-exit p0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p1

    :catchall_0
    move-exception p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    monitor-exit p0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    throw p1
.end method

.method public setThis(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "pThis"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mThis:J

    const/4 v1, 0x6

    return-void
.end method

.method public declared-synchronized uninit()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mContext:Landroid/content/Context;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v0, -0x3

    const/4 v0, -0x3

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0

    :cond_0
    :try_start_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->StopDisplayListener()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->mContext:Landroid/content/Context;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    throw v0
.end method
