.class Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity$1$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity$1;->onDisplayChanged(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity$1;


# direct methods
.method constructor <init>(Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity$1;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$1"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity$1$1;->this$1:Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity$1;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l sro/l4M@c~t~@@ @~ ~Kbf@ i~o~~@~@1i  ~o@~ovt@ y@~@ ~~~ba@ ~s/n~@f@o~~So  m@b @ @  ~i  ~@@.~~du@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity$1$1;->this$1:Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity$1;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, v0, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity$1;->this$0:Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/zego/zegoavkit2/appconfiguremonitor/AppConfigureMonitorActivity;->UpdateOrientationManual()V

    const/4 v1, 0x1

    and-int/2addr v2, v1

    return-void
.end method
