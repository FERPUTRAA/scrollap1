.class public final Lcom/zego/zegoavkit2/utils/ZegoLogUtil;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static getLogPath(Landroid/content/Context;)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "context"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~is@v~s .~S@Km~@~ul~ol~@@@b/~ @@tfn~@@1@bo~@~o it@~@ ia/ ~~   d@   @M~@@~~bf ~ 4r ~~ @o@~~ o-yco"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object v0

    :cond_0
    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {}, Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v2, "osdmute"

    const-string v2, "dusoten"

    const/4 v4, 0x0

    const-string v2, "emduotn"

    const-string/jumbo v2, "mounted"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-nez v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v2, Ljava/io/File;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v2, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_1

    :cond_1
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez v2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p0

    const/4 v3, 0x6

    xor-int/2addr v4, v3

    if-eqz p0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-nez v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v2, Ljava/io/File;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v2, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-nez v2, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object v0

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez p0, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-nez p0, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object v0

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object p0
.end method

.method public static getTemporaryFolder(Landroid/content/Context;)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "context"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v0

    :cond_0
    const/4 v4, 0x0

    invoke-static {}, Landroid/os/Environment;->getExternalStorageState()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v2, "oummnbe"

    const-string/jumbo v2, "uodmnem"

    const/4 v4, 0x6

    const-string/jumbo v2, "notmdeu"

    const-string/jumbo v2, "mounted"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getExternalCacheDir()Ljava/io/File;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-nez v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v2, Ljava/io/File;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v2, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-nez v2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    if-eqz p0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-nez v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v2, Ljava/io/File;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v2, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    :cond_2
    const/4 v4, 0x3

    if-nez v2, :cond_3

    const/4 v4, 0x7

    return-object v0

    :cond_3
    const/4 v4, 0x5

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez p0, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x7

    if-nez p0, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object v0

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object p0
.end method
