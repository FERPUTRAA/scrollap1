.class public final Lcom/zego/zegoavkit2/utils/SysUtil;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method private static closeReader(Ljava/io/Reader;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "br"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "i s@o@o @u-~  ~nM ~~@o @~c~@bK@~s~vff~@  @ @~i~@4b~@/.@o d ~~  b@@ r@t~~i ~1~~~@t ol @y/@~a~ol@m"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v1, 0x6

    const/4 v0, 0x3

    invoke-virtual {p0}, Ljava/io/Reader;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public static getOsInfo()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    sget-object v1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const-string v1, ":"

    const/4 v4, 0x6

    const-string v1, ":"

    const-string v1, ":"

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    sget-object v2, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    sget-object v1, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v1, ","

    const-string v1, ","

    const/4 v4, 0x5

    const-string v1, ","

    const-string v1, ","

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string v2, "."

    const-string v2, "."

    const/4 v4, 0x1

    const-string v2, "."

    const-string v2, "."

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object v0
.end method

.method public static getSoCModel()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {}, Lcom/zego/zegoavkit2/utils/SysUtil;->getSoCModelFromCPUInfo()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/zego/zegoavkit2/utils/SysUtil;->isValidSoCModel(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const-string v1, " "

    const-string v1, " "

    const/4 v3, 0x6

    const-string v1, " "

    const-string v1, " "

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    aget-object v0, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v0, "dlpm.stmroabf.oao"

    const-string/jumbo v0, "rlsdt.foo.rpaobam"

    const/4 v3, 0x7

    const-string/jumbo v0, "prtlo.mboadraofro"

    const-string/jumbo v0, "ro.board.platform"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/zego/zegoavkit2/utils/SysUtil;->readProp(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/zego/zegoavkit2/utils/SysUtil;->isValidSoCModel(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/zego/zegoavkit2/utils/SysUtil;->isValidSoCModel(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :cond_2
    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v0, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    :cond_3
    :goto_0
    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method static getSoCModelFromCPUInfo()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    new-instance v0, Ljava/io/File;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v1, "/pmcnbu/rcpif"

    const-string/jumbo v1, "oc/mn/crppuif"

    const-string v1, "/proc/cpuinfo"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v7, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v1, :cond_c

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/io/File;->canRead()Z

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-nez v1, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto/16 :goto_4

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v1, 0x0

    :try_start_0
    new-instance v3, Ljava/io/BufferedReader;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-instance v4, Ljava/io/FileReader;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v4, v0}, Ljava/io/FileReader;-><init>(Ljava/io/File;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/16 v0, 0x2000

    const/4 v6, 0x6

    move v7, v6

    invoke-direct {v3, v4, v0}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    const/4 v6, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v3}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v0, :cond_b

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string/jumbo v1, "wHoadaue"

    const-string v1, "awHaoerd"

    const/4 v7, 0x3

    const-string v1, "aweraHrp"

    const-string v1, "Hardware"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v1, :cond_a

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v1, "q/md/b.+"

    const-string v1, "+*.m/b/d"

    const/4 v7, 0x6

    const-string/jumbo v1, "m/sd.*/+"

    const-string/jumbo v1, "sm\\d+.*"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v1, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v5, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v4, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->toMatchResult()Ljava/util/regex/MatchResult;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-interface {v0, v5}, Ljava/util/regex/MatchResult;->group(I)Ljava/lang/String;

    move-result-object v0

    :goto_1
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    goto/16 :goto_3

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x3

    const-string/jumbo v1, "sm/m*+u./"

    const-string v1, ".m/d*/u+s"

    const/4 v7, 0x7

    const-string v1, "dsm+o/d*."

    const-string/jumbo v1, "sdm\\d+.*"

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v1, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x2

    if-eqz v4, :cond_2

    const/4 v6, 0x1

    and-int/2addr v7, v6

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->toMatchResult()Ljava/util/regex/MatchResult;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-interface {v0, v5}, Ljava/util/regex/MatchResult;->group(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    goto :goto_1

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v1, ".p/dmbs*/"

    const-string v1, ".m/d/msp*"

    const/4 v7, 0x3

    const-string v1, "//*dm+u.m"

    const-string/jumbo v1, "msm\\d+.*"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v1, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz v4, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->toMatchResult()Ljava/util/regex/MatchResult;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-interface {v0, v5}, Ljava/util/regex/MatchResult;->group(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    goto/16 :goto_1

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string/jumbo v1, "pq.qd/*p+"

    const-string/jumbo v1, "q+*//dp.q"

    const/4 v7, 0x4

    const-string v1, "/+.q*/adq"

    const-string v1, "apq\\d+.*"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v1, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v4, :cond_4

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->toMatchResult()Ljava/util/regex/MatchResult;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-interface {v0, v5}, Ljava/util/regex/MatchResult;->group(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto/16 :goto_1

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string/jumbo v1, "khsa(()s)aob))oiaan)a)()|)|lnw|plnaai|l)ig|aonokn)(nat(a(an)e|rcotpiiihual)|(ltina(|(ar||lert(("

    const-string v1, "(ws|)nno))|i)ln(itnhr)ahaa|o|one)a|)lra|gt((o)ra()k|e(iiaii((lkla)l(pap)(abaoa|ntauit|c(n)ln|(a"

    const/4 v7, 0x7

    const-string v1, "((waipio)|(lahaina)|(kona)|(huracan)|(hana)|(napali)|(nairo)|(lito)|(atoll)|(trinket)|(bengal))"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v1, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz v4, :cond_5

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->toMatchResult()Ljava/util/regex/MatchResult;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-interface {v0, v5}, Ljava/util/regex/MatchResult;->group(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto/16 :goto_1

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string/jumbo v1, "i/*m/rni+md"

    const-string v1, "d/+mk/iir*n"

    const/4 v7, 0x4

    const-string v1, "/indo.kr+/*"

    const-string/jumbo v1, "kirin\\d+.*"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v1, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v4, :cond_6

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->toMatchResult()Ljava/util/regex/MatchResult;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-interface {v0, v5}, Ljava/util/regex/MatchResult;->group(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    goto/16 :goto_1

    :cond_6
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string v1, "d./oib*h"

    const-string v1, "/*hio.d/"

    const/4 v7, 0x5

    const-string v1, "*+//.dui"

    const-string/jumbo v1, "hi\\d+.*"

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v1, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eqz v4, :cond_7

    const/4 v6, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->toMatchResult()Ljava/util/regex/MatchResult;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-interface {v0, v5}, Ljava/util/regex/MatchResult;->group(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    goto/16 :goto_1

    :cond_7
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v1, "t/dm*+bp"

    const-string/jumbo v1, "t/+d*b.m"

    const/4 v7, 0x7

    const-string/jumbo v1, "q+*t//m."

    const-string/jumbo v1, "mt\\d+.*"

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v1, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v4, :cond_8

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->toMatchResult()Ljava/util/regex/MatchResult;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-interface {v0, v5}, Ljava/util/regex/MatchResult;->group(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto/16 :goto_1

    :cond_8
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string v1, "*ns/iao+mu.k/p"

    const-string/jumbo v1, "k+a/o.uoin/mp*"

    const/4 v7, 0x2

    const-string/jumbo v1, "kompanio\\d+.*"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v1, v4}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->find()Z

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz v4, :cond_9

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/util/regex/Matcher;->toMatchResult()Ljava/util/regex/MatchResult;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-interface {v0, v5}, Ljava/util/regex/MatchResult;->group(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x2

    goto/16 :goto_1

    :cond_9
    const/4 v7, 0x1

    const-string v1, "?e/myonpnua/xg(?+sd.)m(s)"

    const-string v1, "a?+./u?pm)nssydg)eox*((/n"

    const/4 v7, 0x0

    const-string v1, "?y(+on)x)gs/?e*mussdon.a("

    const-string v1, "(samsung)?e(xynos)?\\d+.*"

    const/4 v7, 0x1

    const/4 v6, 0x5

    invoke-static {v1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-virtual {v1, v0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v1, :cond_a

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->toMatchResult()Ljava/util/regex/MatchResult;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v0, v5}, Ljava/util/regex/MatchResult;->group(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto/16 :goto_1

    :cond_a
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v3}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto/16 :goto_0

    :catch_0
    move-exception v0

    move-object v1, v3

    move-object v1, v3

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto :goto_2

    :catch_1
    move-exception v0

    :goto_2
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :cond_b
    :goto_3
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v3}, Lcom/zego/zegoavkit2/utils/SysUtil;->closeReader(Ljava/io/Reader;)V

    :cond_c
    :goto_4
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-object v2
.end method

.method public static getVersion()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v1, ","

    const-string v1, ","

    const/4 v4, 0x4

    const-string v1, ","

    const-string v1, ","

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v2, "."

    const-string v2, "."

    const/4 v4, 0x3

    const-string v2, "."

    const-string v2, "."

    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-object v0
.end method

.method static isValidSoCModel(Ljava/lang/String;)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "socModel"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz p0, :cond_a

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto/16 :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v1, "s^/.qb*d+"

    const-string v1, ".*^ds+/mq"

    const-string/jumbo v1, "ms^*d.u//"

    const-string v1, "^sm\\d+.*"

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-static {v1, p0}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    return v2

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v1, "d/m.^ssp+/"

    const-string/jumbo v1, "m/s.+/dsd^"

    const-string/jumbo v1, "md*s^+/dq."

    const-string v1, "^sdm\\d+.*"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v1, p0}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    return v2

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string v1, "^*/m+dsmm/"

    const/4 v4, 0x4

    const-string v1, "dms/sm^./+"

    const-string v1, "^msm\\d+.*"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v1, p0}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_3

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    return v2

    :cond_3
    const/4 v4, 0x7

    const-string v1, "d^/m+o.*/a"

    const-string v1, "d+^qo*./a/"

    const/4 v4, 0x5

    const-string v1, "^p*/o/.+ad"

    const-string v1, "^apq\\d+.*"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v1, p0}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v1, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    return v2

    :cond_4
    const/4 v4, 0x2

    const-string/jumbo v1, "tt)ciban(ai))eaol)ar(hba(lnkp)|aoa|)|la(a(ira|ul(h)(ankgo)(lhli|nnw|ebnito)na)(irn|||(ta(^)op)i("

    const-string/jumbo v1, "ke(aabc(a)a|aia)))ankl^()(rolarl)|(innhin||e(woor|tpa|hog|at(a))tait)((i)h)ln|oipnn)|ln|u(a((ilb"

    const/4 v4, 0x1

    const-string v1, "(onak(utp(ai)ta)o)a((altcni)halgltba||ni)())e)a|h(nrarwn(|o|e(uoa(a()l)k)(alhnir)p||lioina^|ai||"

    const-string v1, "^((waipio)|(lahaina)|(kona)|(huracan)|(hana)|(napali)|(nairo)|(lito)|(atoll)|(trinket)|(bengal))"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v1, p0}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v1, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v2

    :cond_5
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v1, "rn/iu/kpi.^d"

    const-string/jumbo v1, "rki/d^u/in.*"

    const/4 v4, 0x4

    const-string v1, "*i/i/^+nqr.k"

    const-string v1, "^kirin\\d+.*"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v1, p0}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v1, :cond_6

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    return v2

    :cond_6
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v1, "./s*+i/p^"

    const-string/jumbo v1, "i/+*^h/p."

    const/4 v4, 0x1

    const-string v1, ".^+mh*/i/"

    const-string v1, "^hi\\d+.*"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v1, p0}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v1, :cond_7

    const/4 v4, 0x7

    const/4 v3, 0x7

    return v2

    :cond_7
    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v1, "/q/do+m^*"

    const-string v1, "/^+dt/*mq"

    const-string v1, ".*+^mb//t"

    const-string v1, "^mt\\d+.*"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v1, p0}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v1, :cond_8

    const/4 v4, 0x0

    const/4 v3, 0x5

    return v2

    :cond_8
    const/4 v3, 0x0

    move v4, v3

    const-string/jumbo v1, "i/+oopu/d*.sam^"

    const-string/jumbo v1, "m.sakio+dp/o*/^"

    const/4 v4, 0x7

    const-string v1, "^kompanio\\d+.*"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v1, p0}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v1, :cond_9

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v2

    :cond_9
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v1, "^/(?m(sp?msen/+ugdys*o))n."

    const-string v1, "?ssms/and^.omug()?e(+)*/yn"

    const/4 v4, 0x6

    const-string v1, "?*d.ms(nqsgn?)s^u(/ay/x)oe"

    const-string v1, "^(samsung)?e(xynos)?\\d+.*"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v1, p0}, Ljava/util/regex/Pattern;->matches(Ljava/lang/String;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz p0, :cond_a

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    return v2

    :cond_a
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    return v0
.end method

.method static readProp(Ljava/lang/String;)Ljava/lang/String;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "propName"
        }
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x5

    const/4 v1, 0x0

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-instance v2, Ljava/lang/ProcessBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 v3, 0x0

    const/4 v7, 0x0

    new-array v4, v3, [Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-direct {v2, v4}, Ljava/lang/ProcessBuilder;-><init>([Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v4, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-array v4, v4, [Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string/jumbo v5, "orsegot"

    const-string/jumbo v5, "gtreoop"

    const/4 v7, 0x4

    const-string/jumbo v5, "pormetg"

    const-string/jumbo v5, "getprop"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    aput-object v5, v4, v3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    aput-object p0, v4, v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v2, v4}, Ljava/lang/ProcessBuilder;->command([Ljava/lang/String;)Ljava/lang/ProcessBuilder;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/ProcessBuilder;->redirectErrorStream(Z)Ljava/lang/ProcessBuilder;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p0}, Ljava/lang/ProcessBuilder;->start()Ljava/lang/Process;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    new-instance v2, Ljava/io/BufferedReader;

    const/4 v7, 0x2

    const/4 v6, 0x4

    new-instance v3, Ljava/io/InputStreamReader;

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {v3, v4}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    invoke-direct {v2, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_4
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez v1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_0
    :try_start_3
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0

    :catch_0
    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/lang/Process;->destroy()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    return-object v0

    :catchall_0
    move-exception v0

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    goto :goto_1

    :catch_1
    move-object v1, v2

    move-object v1, v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    goto :goto_2

    :catchall_1
    move-exception v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_1

    :catchall_2
    move-exception v0

    move-object p0, v1

    move-object p0, v1

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v1, :cond_1

    :try_start_4
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_2

    :catch_2
    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-eqz p0, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p0}, Ljava/lang/Process;->destroy()V

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    throw v0

    :catch_3
    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :catch_4
    :goto_2
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-eqz v1, :cond_3

    :try_start_5
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_5

    :catch_5
    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz p0, :cond_4

    const/4 v7, 0x2

    invoke-virtual {p0}, Ljava/lang/Process;->destroy()V

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    return-object v0
.end method
