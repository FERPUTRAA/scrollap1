.class public Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$VideoCaptureFormat;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "VideoCaptureFormat"
.end annotation


# instance fields
.field public height:I

.field public pixel_format:I

.field public rotation:I

.field public strides:[I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    filled-new-array {v0, v0, v0, v0}, [I

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$VideoCaptureFormat;->strides:[I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput v0, p0, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$VideoCaptureFormat;->width:I

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput v0, p0, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$VideoCaptureFormat;->height:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput v0, p0, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$VideoCaptureFormat;->rotation:I

    const/4 v3, 0x2

    iput v0, p0, Lcom/zego/zegoavkit2/ZegoVideoCaptureDevice$VideoCaptureFormat;->pixel_format:I

    const/4 v3, 0x3

    return-void
.end method
