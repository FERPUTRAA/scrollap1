.class public interface abstract Lcom/videoengine/NTMediaCodecVideoEncoderHevc$MediaCodecVideoEncoderErrorCallback;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/videoengine/NTMediaCodecVideoEncoderHevc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "MediaCodecVideoEncoderErrorCallback"
.end annotation


# virtual methods
.method public abstract onMediaCodecVideoEncoderCriticalError(I)V
.end method
