.class public final enum Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/videoengine/NTMediaCodecVideoEncoderHevc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "BitrateAdjustmentType"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum DYNAMIC_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

.field private static final synthetic ENUM$VALUES:[Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

.field public static final enum FRAMERATE_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

.field public static final enum NO_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    new-instance v0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const-string/jumbo v1, "sTsO_NTESUADM"

    const-string v1, "EMsDANOTTUJ_S"

    const/4 v8, 0x0

    const-string v1, "AUOmSMDJNTETN"

    const-string v1, "NO_ADJUSTMENT"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v2, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-direct {v0, v1, v2}, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;->NO_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    new-instance v1, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string v3, "RRADoETJAM_EFMSmETTA"

    const-string v3, "TEAmMRTD_EFRJUTAAMES"

    const/4 v8, 0x6

    const-string v3, "UDREEbMFAATRT_ETMASN"

    const-string v3, "FRAMERATE_ADJUSTMENT"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v4, 0x1

    const/4 v7, 0x4

    or-int/2addr v8, v7

    invoke-direct {v1, v3, v4}, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x7

    sput-object v1, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;->FRAMERATE_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-instance v3, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string v5, "ENCTAJuSYNAUI_DoMM"

    const-string v5, "YETAoUMSIDT_ANNCJM"

    const/4 v8, 0x1

    const-string v5, "DTYETCSpAIMMN_NAJU"

    const-string v5, "DYNAMIC_ADJUSTMENT"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v6, 0x2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct {v3, v5, v6}, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    sput-object v3, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;->DYNAMIC_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/4 v5, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    new-array v5, v5, [Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    aput-object v0, v5, v2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    aput-object v1, v5, v4

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    aput-object v3, v5, v6

    const/4 v8, 0x7

    const/4 v7, 0x4

    sput-object v5, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;->ENUM$VALUES:[Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v8, 0x2

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~~o~@1iq ~~ ~ @oy@  @i@4~~~@r  ~ @  ~n.@sl~/@@/fto~~ ~M~il@~ K v @ tb~-@d@  ~um@~o~oSofa@@~cb@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const-class v0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const-class v0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v2, 0x7

    const-class v0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const-class v0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v2, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method public static values()[Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;->ENUM$VALUES:[Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    array-length v1, v0

    const/4 v5, 0x1

    new-array v2, v1, [Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-object v2
.end method
