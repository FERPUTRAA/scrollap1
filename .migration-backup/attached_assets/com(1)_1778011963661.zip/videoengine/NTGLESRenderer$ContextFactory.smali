.class Lcom/videoengine/NTGLESRenderer$ContextFactory;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/opengl/GLSurfaceView$EGLContextFactory;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/videoengine/NTGLESRenderer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ContextFactory"
.end annotation


# static fields
.field private static EGL_CONTEXT_CLIENT_VERSION:I = 0x3098


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/videoengine/NTGLESRenderer$ContextFactory;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/videoengine/NTGLESRenderer$ContextFactory;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public createContext(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;)Ljavax/microedition/khronos/egl/EGLContext;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@os ~a~@ @~@@@~@~@@b~@ 1rvi~fu~~yot i@b4oK@ n/lo~ ~~ ~@~@  ~t~sb@ @f@l~ Mi~~.-@ d @@ o o ~~S~c m"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    const-string v0, "eTrmrdRnSeELNs"

    const-string v0, "NnsRrerdSELTGe"

    const/4 v4, 0x2

    const-string/jumbo v0, "nEGNoTrdeeLSre"

    const-string v0, "NTGLESRenderer"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v1, "an rxb n.e0tcto2Stnem OLc egGi"

    const-string/jumbo v1, "g tmecr EnoOtGx0eeSLcatn2.n  i"

    const/4 v4, 0x5

    const-string/jumbo v1, "n nncpuertcL0a.xS EteOi goet2 "

    const-string v1, "creating OpenGL ES 2.0 context"

    const/4 v3, 0x5

    move v4, v3

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v0, "Beerot oeloenefrattCCge"

    const/4 v4, 0x4

    const-string v0, "Before eglCreateContext"

    const/4 v4, 0x1

    invoke-static {v0, p1}, Lcom/videoengine/NTGLESRenderer;->access$0(Ljava/lang/String;Ljavax/microedition/khronos/egl/EGL10;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget v0, Lcom/videoengine/NTGLESRenderer$ContextFactory;->EGL_CONTEXT_CLIENT_VERSION:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v1, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/16 v2, 0x3038

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    filled-new-array {v0, v1, v2}, [I

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    sget-object v1, Ljavax/microedition/khronos/egl/EGL10;->EGL_NO_CONTEXT:Ljavax/microedition/khronos/egl/EGLContext;

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-interface {p1, p2, p3, v1, v0}, Ljavax/microedition/khronos/egl/EGL10;->eglCreateContext(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;Ljavax/microedition/khronos/egl/EGLContext;[I)Ljavax/microedition/khronos/egl/EGLContext;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string p3, "erCfeeapngtltexteo Art"

    const-string p3, "Caeltbogrnxfte teeArte"

    const/4 v4, 0x7

    const-string/jumbo p3, "g aAoxrlqrettnCefteeet"

    const-string p3, "After eglCreateContext"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p3, p1}, Lcom/videoengine/NTGLESRenderer;->access$0(Ljava/lang/String;Ljavax/microedition/khronos/egl/EGL10;)V

    const/4 v4, 0x4

    return-object p2
.end method

.method public destroyContext(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLContext;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-interface {p1, p2, p3}, Ljavax/microedition/khronos/egl/EGL10;->eglDestroyContext(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLContext;)Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method
