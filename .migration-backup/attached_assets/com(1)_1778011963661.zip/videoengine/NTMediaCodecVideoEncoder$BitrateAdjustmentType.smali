.class public final enum Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/videoengine/NTMediaCodecVideoEncoder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "BitrateAdjustmentType"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum DYNAMIC_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

.field private static final synthetic ENUM$VALUES:[Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

.field public static final enum FRAMERATE_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

.field public static final enum NO_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    new-instance v0, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string v1, "AssNST_NOTMDU"

    const-string v1, "ANs_DOMTNTSUJ"

    const/4 v8, 0x5

    const-string v1, "TANmTJDUNSEOM"

    const-string v1, "NO_ADJUSTMENT"

    const/4 v8, 0x3

    const/4 v2, 0x2

    const/4 v8, 0x7

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {v0, v1, v2}, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->NO_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    new-instance v1, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string v3, "JARAo_ANREUTFTmDESMM"

    const-string v3, "RAMmUA_EFTTAEJDRMSNE"

    const/4 v8, 0x5

    const-string v3, "ETNDSbMFAMRTJRAATUE_"

    const-string v3, "FRAMERATE_ADJUSTMENT"

    const/4 v7, 0x7

    move v8, v7

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-direct {v1, v3, v4}, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    sput-object v1, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->FRAMERATE_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    new-instance v3, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v5, "ISYNCouNTT_DUAJMDM"

    const-string v5, "DSY_oJTNAICUMNEMDT"

    const-string v5, "_UDAJSIpTNCTYNDEAM"

    const-string v5, "DYNAMIC_ADJUSTMENT"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v6, 0x2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {v3, v5, v6}, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    sput-object v3, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->DYNAMIC_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v5, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    new-array v5, v5, [Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    aput-object v0, v5, v2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    aput-object v1, v5, v4

    const/4 v7, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    aput-object v3, v5, v6

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    sput-object v5, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->ENUM$VALUES:[Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@b@~@Ms~q@@l1@o@o  ~ ~idut~@~m~.  fncb@ @lo@o~b/S  @ 4~~@~/ K@o@ r ~~ v@~a  ~@~t@y ~~i~~@~fi-~ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-class v0, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const-class v0, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v2, 0x1

    const-class v0, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const-class v0, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v2, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    check-cast p0, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->ENUM$VALUES:[Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    array-length v1, v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-array v2, v1, [Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    const/4 v3, 0x0

    xor-int/2addr v5, v3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-object v2
.end method
