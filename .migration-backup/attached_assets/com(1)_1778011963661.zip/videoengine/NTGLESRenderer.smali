.class public Lcom/videoengine/NTGLESRenderer;
.super Landroid/opengl/GLSurfaceView;

# interfaces
.implements Landroid/opengl/GLSurfaceView$Renderer;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/videoengine/NTGLESRenderer$ConfigChooser;,
        Lcom/videoengine/NTGLESRenderer$ContextFactory;
    }
.end annotation


# static fields
.field private static final DEBUG:Z = false

.field private static final TAG:Ljava/lang/String; = "NTGLESRenderer"


# instance fields
.field private nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

.field private nativeFunctionsRegisted:Z

.field private nativeObject:J

.field private openGLCreated:Z

.field private surfaceCreated:Z

.field private viewHeight:I

.field private viewWidth:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Landroid/opengl/GLSurfaceView;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->surfaceCreated:Z

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->openGLCreated:Z

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionsRegisted:Z

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    const/4 v2, 0x0

    move v3, v2

    iput-object v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeObject:J

    const/4 v2, 0x7

    or-int/2addr v3, v2

    iput p1, p0, Lcom/videoengine/NTGLESRenderer;->viewWidth:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput p1, p0, Lcom/videoengine/NTGLESRenderer;->viewHeight:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0, p1, p1, p1}, Lcom/videoengine/NTGLESRenderer;->init(ZII)V

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;ZII)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Landroid/opengl/GLSurfaceView;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->surfaceCreated:Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->openGLCreated:Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionsRegisted:Z

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeObject:J

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput p1, p0, Lcom/videoengine/NTGLESRenderer;->viewWidth:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput p1, p0, Lcom/videoengine/NTGLESRenderer;->viewHeight:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-direct {p0, p2, p3, p4}, Lcom/videoengine/NTGLESRenderer;->init(ZII)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method private native CreateOpenGLNative(JII)I
.end method

.method private native DrawNative(J)V
.end method

.method public static IsSupported(Landroid/content/Context;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@nso @~~K~o4/@@@@~ v~ts@ f@@/1@@~oo~b~@c M iid~@   laft~~@@S ~~@~ ru   ~@o@~@m~bo -by~i~ ~~~@  l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const-string/jumbo v0, "tstmicyv"

    const-string v0, "casyvtit"

    const/4 v2, 0x0

    const-string/jumbo v0, "iiycovta"

    const-string v0, "activity"

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/app/ActivityManager;->getDeviceConfigurationInfo()Landroid/content/pm/ConfigurationInfo;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget p0, p0, Landroid/content/pm/ConfigurationInfo;->reqGlEsVersion:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/high16 v0, 0x20000

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-lt p0, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p0

    :cond_0
    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p0
.end method

.method public static UseOpenGL2(Ljava/lang/Object;)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-class v0, Lcom/videoengine/NTGLESRenderer;

    const-class v0, Lcom/videoengine/NTGLESRenderer;

    const/4 v2, 0x1

    const-class v0, Lcom/videoengine/NTGLESRenderer;

    const-class v0, Lcom/videoengine/NTGLESRenderer;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return p0
.end method

.method static synthetic access$0(Ljava/lang/String;Ljavax/microedition/khronos/egl/EGL10;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/videoengine/NTGLESRenderer;->checkEglError(Ljava/lang/String;Ljavax/microedition/khronos/egl/EGL10;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method private static checkEglError(Ljava/lang/String;Ljavax/microedition/khronos/egl/EGL10;)V
    .locals 5

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {p1}, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/16 v1, 0x3000

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-ne v0, v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    aput-object p0, v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    aput-object v0, v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v0, "r:0x%bsGmeo r :rxLE"

    const-string v0, "Erem%::srLo  r%Gxx0"

    const/4 v4, 0x0

    const-string/jumbo v0, "xEr r:uore Ls:%%Gx "

    const-string v0, "%s: EGL error: 0x%x"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v1, "GSLnTeRpreeENd"

    const-string v1, "NTGLESRenderer"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0
.end method

.method private init(ZII)V
    .locals 15

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    if-eqz p1, :cond_0

    invoke-virtual {p0}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object v1

    const/4 v2, -0x3

    invoke-interface {v1, v2}, Landroid/view/SurfaceHolder;->setFormat(I)V

    :cond_0
    new-instance v1, Lcom/videoengine/NTGLESRenderer$ContextFactory;

    const/4 v2, 0x0

    invoke-direct {v1, v2}, Lcom/videoengine/NTGLESRenderer$ContextFactory;-><init>(Lcom/videoengine/NTGLESRenderer$ContextFactory;)V

    invoke-virtual {p0, v1}, Landroid/opengl/GLSurfaceView;->setEGLContextFactory(Landroid/opengl/GLSurfaceView$EGLContextFactory;)V

    if-eqz p1, :cond_1

    new-instance v1, Lcom/videoengine/NTGLESRenderer$ConfigChooser;

    const/16 v4, 0x8

    const/16 v5, 0x8

    const/16 v6, 0x8

    const/16 v7, 0x8

    move-object v3, v1

    move-object v3, v1

    move/from16 v8, p2

    move/from16 v8, p2

    move/from16 v8, p2

    move/from16 v8, p2

    move/from16 v9, p3

    move/from16 v9, p3

    move/from16 v9, p3

    move/from16 v9, p3

    invoke-direct/range {v3 .. v9}, Lcom/videoengine/NTGLESRenderer$ConfigChooser;-><init>(IIIIII)V

    goto :goto_0

    :cond_1
    new-instance v1, Lcom/videoengine/NTGLESRenderer$ConfigChooser;

    const/4 v9, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move/from16 v13, p2

    move/from16 v13, p2

    move/from16 v13, p2

    move/from16 v14, p3

    move/from16 v14, p3

    move/from16 v14, p3

    move/from16 v14, p3

    invoke-direct/range {v8 .. v14}, Lcom/videoengine/NTGLESRenderer$ConfigChooser;-><init>(IIIIII)V

    :goto_0
    invoke-virtual {p0, v1}, Landroid/opengl/GLSurfaceView;->setEGLConfigChooser(Landroid/opengl/GLSurfaceView$EGLConfigChooser;)V

    invoke-virtual {p0, p0}, Landroid/opengl/GLSurfaceView;->setRenderer(Landroid/opengl/GLSurfaceView$Renderer;)V

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroid/opengl/GLSurfaceView;->setRenderMode(I)V

    return-void
.end method


# virtual methods
.method public DeRegisterNativeObject()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-boolean v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionsRegisted:Z

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-boolean v0, p0, Lcom/videoengine/NTGLESRenderer;->openGLCreated:Z

    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeObject:J

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public ReDraw()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    iget-boolean v0, p0, Lcom/videoengine/NTGLESRenderer;->surfaceCreated:Z

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/opengl/GLSurfaceView;->requestRender()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public RegisterNativeObject(J)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-wide p1, p0, Lcom/videoengine/NTGLESRenderer;->nativeObject:J

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x5

    and-int/2addr v2, v1

    iput-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionsRegisted:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public onDrawFrame(Ljavax/microedition/khronos/opengles/GL10;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionsRegisted:Z

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz p1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->surfaceCreated:Z

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-nez p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->openGLCreated:Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-wide v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeObject:J

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget p1, p0, Lcom/videoengine/NTGLESRenderer;->viewWidth:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget v2, p0, Lcom/videoengine/NTGLESRenderer;->viewHeight:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {p0, v0, v1, p1, v2}, Lcom/videoengine/NTGLESRenderer;->CreateOpenGLNative(JII)I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 p1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->openGLCreated:Z

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-wide v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeObject:J

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {p0, v0, v1}, Lcom/videoengine/NTGLESRenderer;->DrawNative(J)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-void

    :cond_3
    :goto_0
    const/4 v4, 0x3

    iget-object p1, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method public onSurfaceChanged(Ljavax/microedition/khronos/opengles/GL10;II)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 p1, 0x1

    and-int/2addr v3, p1

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    iput-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->surfaceCreated:Z

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput p2, p0, Lcom/videoengine/NTGLESRenderer;->viewWidth:I

    const/4 v2, 0x1

    move v3, v2

    iput p3, p0, Lcom/videoengine/NTGLESRenderer;->viewHeight:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-boolean v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionsRegisted:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/videoengine/NTGLESRenderer;->nativeObject:J

    const/4 v2, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, v0, v1, p2, p3}, Lcom/videoengine/NTGLESRenderer;->CreateOpenGLNative(JII)I

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-boolean p1, p0, Lcom/videoengine/NTGLESRenderer;->openGLCreated:Z

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/videoengine/NTGLESRenderer;->nativeFunctionLock:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public onSurfaceCreated(Ljavax/microedition/khronos/opengles/GL10;Ljavax/microedition/khronos/egl/EGLConfig;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method
