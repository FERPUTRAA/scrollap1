.class public Lcom/videoengine/NTMediaCodecVideoEncoder;
.super Ljava/lang/Object;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x13
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;,
        Lcom/videoengine/NTMediaCodecVideoEncoder$EncoderProperties;,
        Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;,
        Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;
    }
.end annotation


# static fields
.field private static final BITRATE_ADJUSTMENT_FPS:I = 0x1e

.field private static final BITRATE_CORRECTION_MAX_SCALE:D = 2.0

.field private static final BITRATE_CORRECTION_SEC:D = 3.0

.field private static final BITRATE_CORRECTION_STEPS:I = 0xa

.field private static final COLOR_QCOM_FORMATYUV420PackedSemiPlanar32m:I = 0x7fa30c04

.field private static final DEQUEUE_TIMEOUT:I = 0x0

.field private static final H264_HW_EXCEPTION_MODELS:[Ljava/lang/String;

.field private static final H264_MIME_TYPE:Ljava/lang/String; = "video/avc"

.field private static final MAXIMUM_INITIAL_FPS:I = 0x1e

.field private static final MEDIA_CODEC_RELEASE_TIMEOUT_MS:I = 0x1388

.field private static final MTKH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

.field private static final TAG:Ljava/lang/String; = "NTMediaCodecVideoEncoder"

.field private static final VIDEO_ControlRateConstant:I = 0x2

.field private static final amlogicH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

.field private static codecErrors:I

.field private static errorCallback:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;

.field private static final exynosH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

.field private static final h264HwList:[Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

.field private static final hisiH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

.field private static hwEncoderDisabledTypes:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final hwimgH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

.field private static final qcomH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

.field private static final rkH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

.field private static runningInstance:Lcom/videoengine/NTMediaCodecVideoEncoder;

.field private static final supportedColorList:[I

.field private static final supportedSurfaceColorList:[I


# instance fields
.field private bitrateAccumulator:D

.field private bitrateAccumulatorMax:D

.field private bitrateAdjustmentScaleExp:I

.field private bitrateAdjustmentType:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

.field private bitrateObservationTimeMs:D

.field private colorFormat:I

.field private configData:Ljava/nio/ByteBuffer;

.field private height_:I

.field private mediaCodec:Landroid/media/MediaCodec;

.field private mediaCodecThread:Ljava/lang/Thread;

.field private out_encode_buff_:Ljava/nio/ByteBuffer;

.field private outputBuffers:[Ljava/nio/ByteBuffer;

.field private targetBitrateBps:I

.field private targetFps:I

.field private type:I

.field private width_:I


# direct methods
.method static constructor <clinit>()V
    .locals 13

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    new-instance v0, Ljava/util/HashSet;

    const/4 v12, 0x3

    const/4 v11, 0x3

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v12, 0x2

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    new-instance v0, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    sget-object v1, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->NO_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x7

    const-string/jumbo v2, "mMss.O.Xq"

    const-string v2, ".MsqmX.cO"

    const/4 v12, 0x4

    const-string/jumbo v2, "oq.mXM.mc"

    const-string v2, "OMX.qcom."

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    const/16 v3, 0x13

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-direct {v0, v2, v3, v1}, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->qcomH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    new-instance v2, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x5

    sget-object v4, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->FRAMERATE_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x1

    const-string v5, "Om.Xo.MEyxs"

    const-string v5, "Ox.msoEMXy."

    const/4 v12, 0x7

    const-string v5, ".oEsxbOMXyn"

    const-string v5, "OMX.Exynos."

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    const/16 v6, 0x15

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-direct {v2, v5, v6, v4}, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;)V

    const/4 v11, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x1

    sput-object v2, Lcom/videoengine/NTMediaCodecVideoEncoder;->exynosH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    new-instance v4, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v11, 0x2

    move v12, v11

    const-string v5, ".MXKO.uM"

    const-string v5, "OMX.MTK."

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-direct {v4, v5, v3, v1}, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;)V

    const/4 v12, 0x0

    sput-object v4, Lcom/videoengine/NTMediaCodecVideoEncoder;->MTKH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    new-instance v5, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    const-string/jumbo v7, "o.X.iisph"

    const-string v7, "..iMohsiX"

    const/4 v12, 0x5

    const-string/jumbo v7, "shMXi..Oq"

    const-string v7, "OMX.hisi."

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-direct {v5, v7, v3, v1}, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;)V

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x3

    sput-object v5, Lcom/videoengine/NTMediaCodecVideoEncoder;->hisiH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    new-instance v7, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    const-string v8, "aXsgi.lcmoMO"

    const-string/jumbo v8, "loOmabc.gMXi"

    const/4 v12, 0x1

    const-string/jumbo v8, "i.omlma.cXMO"

    const-string v8, "OMX.amlogic."

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-direct {v7, v8, v3, v1}, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;)V

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x0

    sput-object v7, Lcom/videoengine/NTMediaCodecVideoEncoder;->amlogicH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    new-instance v8, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x3

    const-string v9, "O..roMX"

    const-string v9, ".XMr.Ou"

    const/4 v12, 0x4

    const-string v9, "OMX.rk."

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-direct {v8, v9, v3, v1}, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;)V

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x3

    sput-object v8, Lcom/videoengine/NTMediaCodecVideoEncoder;->rkH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x6

    new-instance v9, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    const-string v10, "IG.pMbXO"

    const-string v10, ".XIGOM.p"

    const/4 v12, 0x7

    const-string v10, "GXMMIOu."

    const-string v10, "OMX.IMG."

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-direct {v9, v10, v3, v1}, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;)V

    const/4 v11, 0x2

    shl-int/2addr v12, v11

    sput-object v9, Lcom/videoengine/NTMediaCodecVideoEncoder;->hwimgH264HwProperties:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x5

    const/4 v1, 0x7

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x6

    new-array v1, v1, [Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x6

    const/4 v10, 0x0

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x2

    aput-object v0, v1, v10

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x2

    const/4 v0, 0x1

    const/4 v12, 0x5

    aput-object v2, v1, v0

    const/4 v11, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x6

    const/4 v0, 0x2

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    aput-object v4, v1, v0

    const/4 v11, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x6

    const/4 v0, 0x3

    const/4 v12, 0x0

    const/4 v11, 0x7

    aput-object v5, v1, v0

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x6

    const/4 v0, 0x4

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    aput-object v7, v1, v0

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x6

    const/4 v0, 0x5

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x5

    aput-object v8, v1, v0

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x2

    const/4 v0, 0x6

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    aput-object v9, v1, v0

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    sput-object v1, Lcom/videoengine/NTMediaCodecVideoEncoder;->h264HwList:[Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x5

    const-string/jumbo v0, "pq7Ns u"

    const-string v0, "eq7su N"

    const/4 v12, 0x7

    const-string v0, "equNx7 "

    const-string v0, "Nexus 7"

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    const-string v1, "eNs ss4"

    const-string/jumbo v1, "exss 4N"

    const-string v1, "Nxume4 "

    const-string v1, "Nexus 4"

    const-string v2, "--SSoHMNmIA3S7GG"

    const-string v2, "HG-m-S7S3IGAUMSN"

    const/4 v12, 0x5

    const-string v2, "G3SI7bAGSMU-3-HS"

    const-string v2, "SAMSUNG-SGH-I337"

    const/4 v12, 0x2

    const/4 v11, 0x3

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->H264_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x7

    const v0, 0x7fa30c00

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x4

    const v1, 0x7fa30c04

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    filled-new-array {v3, v6, v0, v1}, [I

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x6

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->supportedColorList:[I

    const/4 v12, 0x7

    const/4 v11, 0x4

    const v0, 0x7f000789

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x2

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->supportedSurfaceColorList:[I

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->NO_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentType:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic access$0(Lcom/videoengine/NTMediaCodecVideoEncoder;)Landroid/media/MediaCodec;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "t-/S/ u@b f Kd@ @~aMo@@@~n~@~4~~.~  ~~u~@~i@ lv lb1~ri@ o ~ ~t ~@@~c ~o @o@@@bo ~@@~if@~yo  @~~s"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method private checkOnMediaCodecThread()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/Thread;->getId()J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/Thread;->getId()J

    move-result-wide v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    cmp-long v0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const-string v2, " i sle peeed oraouoeVvipeoranoddCrocecMntoiypd"

    const-string/jumbo v2, "oddyoC riVaiMcce eeondvrooiooeud etenla reppsd"

    const/4 v5, 0x3

    const-string v2, "deuaratcqerooioo ncVedEreMpCedyi sndo de evpli"

    const-string v2, "MediaCodecVideoEncoder previously operated on "

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const-string v2, "bnsd anst oc iublw   l"

    const-string v2, " b lsbcwt odenu nl ai "

    const/4 v5, 0x4

    const-string v2, " scm  lwa td ol nnubei"

    const-string v2, " but is now called on "

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    throw v0
.end method

.method static createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;
    .locals 2

    :try_start_0
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p0}, Landroid/media/MediaCodec;->createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0

    :catch_0
    const/4 v1, 0x1

    const/4 p0, 0x2

    const/4 v1, 0x5

    const/4 p0, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public static disableH264HwCodec()V
    .locals 4

    const/4 v3, 0x5

    const-string v0, "aTrdceudiEoeoidCoecndMeV"

    const/4 v3, 0x5

    const-string/jumbo v0, "iTccodoeMNVdndeerEoideoC"

    const-string v0, "NTMediaCodecVideoEncoder"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v1, " nbtlbd.aaops. b 2cop esdH6pnynii4ieid aci"

    const-string/jumbo v1, "io2idlopdit e iegbsc6dbi.pa 4pysaHannc  .n"

    const/4 v3, 0x6

    const-string/jumbo v1, "lnegH6u2a4.ascldd incbinbypis  opeditio .a"

    const-string v1, "H.264 encoding is disabled by application."

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v1, "vev/qadpi"

    const-string v1, "/advivceq"

    const/4 v3, 0x7

    const-string v1, "daievov/q"

    const-string/jumbo v1, "video/avc"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method private static findHwEncoder(Ljava/lang/String;[Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;[I)Lcom/videoengine/NTMediaCodecVideoEncoder$EncoderProperties;
    .locals 17

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    const-string v0, "/vsdvcisa"

    const-string/jumbo v0, "i/sdcvavo"

    const-string/jumbo v0, "veimcoa/d"

    const-string/jumbo v0, "video/avc"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const-string v5, "eVeComdianModoEeTidcdecr"

    const-string v5, "CormeaiNdcdecMTVdodnEiee"

    const-string v5, "aEirdbVeTiCodeocNeMcoded"

    const-string v5, "NTMediaCodecVideoEncoder"

    if-eqz v0, :cond_0

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->H264_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sget-object v6, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-interface {v0, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "M oo:eu"

    const-string v1, "Mlo o:e"

    const-string/jumbo v1, "pMl:do "

    const-string v1, "Model: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "e cir .6qlse2e d4latkbobnH cd ah"

    const-string v1, "de 4hbacicrae2ksoHstd.  l nb6el "

    const-string v1, " has black listed H.264 encoder."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    return-object v4

    :cond_0
    const/4 v6, 0x0

    move v7, v6

    move v7, v6

    move v7, v6

    :goto_0
    invoke-static {}, Landroid/media/MediaCodecList;->getCodecCount()I

    move-result v0

    if-lt v7, v0, :cond_1

    return-object v4

    :cond_1
    :try_start_0
    invoke-static {v7}, Landroid/media/MediaCodecList;->getCodecInfoAt(I)Landroid/media/MediaCodecInfo;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    const-string/jumbo v0, "o sueoc  dcendoinneeatetefrCcri ro"

    const-string/jumbo v0, "tioe runro odrcdco nCnteice nefaee"

    const-string/jumbo v0, "ro mtner  rfoCevndnicee codocietea"

    const-string v0, "Cannot retrieve encoder codec info"

    invoke-static {v5, v0, v8}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :goto_1
    if-eqz v0, :cond_f

    invoke-virtual {v0}, Landroid/media/MediaCodecInfo;->isEncoder()Z

    move-result v8

    if-nez v8, :cond_2

    goto/16 :goto_a

    :cond_2
    invoke-virtual {v0}, Landroid/media/MediaCodecInfo;->getSupportedTypes()[Ljava/lang/String;

    move-result-object v8

    array-length v9, v8

    move v10, v6

    move v10, v6

    :goto_2
    if-lt v10, v9, :cond_3

    move-object v11, v4

    goto :goto_3

    :cond_3
    aget-object v11, v8, v10

    invoke-virtual {v11, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_e

    invoke-virtual {v0}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v8

    move-object v11, v8

    move-object v11, v8

    :goto_3
    if-nez v11, :cond_4

    goto/16 :goto_a

    :cond_4
    new-instance v8, Ljava/lang/StringBuilder;

    const-string/jumbo v9, "i onoacaudernetFo dddcn "

    const-string v9, "dcnc  upn ddnrtFdeoaaieo"

    const-string v9, "  edabocdcitn renFndaeud"

    const-string v9, "Found candidate encoder "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v5, v8}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    sget-object v12, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->NO_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    array-length v13, v2

    move v8, v6

    move v8, v6

    move v8, v6

    :goto_4
    if-lt v8, v13, :cond_5

    move v8, v6

    move v8, v6

    move v8, v6

    move v8, v6

    goto :goto_5

    :cond_5
    aget-object v9, v2, v8

    iget-object v10, v9, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;->codecPrefix:Ljava/lang/String;

    invoke-virtual {v11, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_d

    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I

    iget v14, v9, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;->minSdk:I

    const-string/jumbo v15, "uCdcq "

    const-string v15, "Ccqo d"

    const-string/jumbo v15, "op cCd"

    const-string v15, "Codec "

    if-ge v10, v14, :cond_6

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v14, "tsio srKqsdd lDe iiesdbn v o eu "

    const-string v14, "D ssnrivibts u oo Kdeed lde  Ssi"

    const-string v14, " is disabled due to SDK version "

    invoke-virtual {v9, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v5, v9}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_9

    :cond_6
    iget-object v8, v9, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;->bitrateAdjustmentType:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    sget-object v9, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->NO_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    if-eq v8, v9, :cond_7

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v10, "udss er: en air iqtttmejetrbms"

    const-string/jumbo v10, "j em q stuirtt:ubtird srmeanee"

    const-string/jumbo v10, "uusm  e:r r jmenbstriaiqtedeta"

    const-string v10, " requires bitrate adjustment: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v5, v9}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    move-object v12, v8

    move-object v12, v8

    move-object v12, v8

    :cond_7
    const/4 v8, 0x1

    :goto_5
    if-nez v8, :cond_8

    goto/16 :goto_a

    :cond_8
    :try_start_1
    invoke-virtual {v0, v1}, Landroid/media/MediaCodecInfo;->getCapabilitiesForType(Ljava/lang/String;)Landroid/media/MediaCodecInfo$CodecCapabilities;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    iget-object v8, v0, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    array-length v9, v8

    move v10, v6

    move v10, v6

    move v10, v6

    move v10, v6

    :goto_6
    if-lt v10, v9, :cond_c

    array-length v13, v3

    move v14, v6

    move v14, v6

    move v14, v6

    move v14, v6

    :goto_7
    if-lt v14, v13, :cond_9

    goto/16 :goto_a

    :cond_9
    aget v15, v3, v14

    iget-object v8, v0, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    array-length v9, v8

    move v10, v6

    move v10, v6

    move v10, v6

    move v10, v6

    :goto_8
    if-lt v10, v9, :cond_a

    add-int/lit8 v14, v14, 0x1

    goto :goto_7

    :cond_a
    aget v4, v8, v10

    if-ne v4, v15, :cond_b

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "emf oener croeda noo tidtrgum "

    const-string v2, "Found target encoder for mime "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":  "

    const-string v1, "  :"

    const-string v1, "  :"

    const-string v1, " : "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "Co  orblox:"

    const-string v1, ":ro.obx  Cl"

    const-string/jumbo v1, "xo0:lbo rC."

    const-string v1, ". Color: 0x"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v0, Lcom/videoengine/NTMediaCodecVideoEncoder$EncoderProperties;

    invoke-direct {v0, v11, v4, v12}, Lcom/videoengine/NTMediaCodecVideoEncoder$EncoderProperties;-><init>(Ljava/lang/String;ILcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;)V

    return-object v0

    :cond_b
    add-int/lit8 v10, v10, 0x1

    const/4 v4, 0x0

    goto :goto_8

    :cond_c
    aget v4, v8, v10

    new-instance v13, Ljava/lang/StringBuilder;

    const-string/jumbo v14, "l : 0 u ruxo"

    const-string v14, " C ox ur: 0l"

    const-string v14, "0 or oCp :x "

    const-string v14, "   Color: 0x"

    invoke-direct {v13, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v4}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v5, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    add-int/lit8 v10, v10, 0x1

    const/4 v4, 0x0

    goto :goto_6

    :catch_1
    move-exception v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    const-string v0, "cpvaeperqt nnsttnori ia elcaibdeoirC"

    const-string v0, "e ieioapirete itanobpntscC lcarnevdr"

    const-string v0, "ansc Crepiitttveinadosaiencbleorr  e"

    const-string v0, "Cannot retrieve encoder capabilities"

    invoke-static {v5, v0, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_a

    :cond_d
    :goto_9
    add-int/lit8 v8, v8, 0x1

    const/4 v4, 0x0

    goto/16 :goto_4

    :cond_e
    add-int/lit8 v10, v10, 0x1

    const/4 v4, 0x0

    goto/16 :goto_2

    :cond_f
    :goto_a
    add-int/lit8 v7, v7, 0x1

    const/4 v4, 0x0

    goto/16 :goto_0
.end method

.method private getBitrateScale(I)D
    .locals 6

    const/4 v5, 0x7

    int-to-double v0, p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const/4 v5, 0x4

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    div-double/2addr v0, v2

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const/4 v5, 0x6

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-wide v0
.end method

.method public static isH264HwSupported()Z
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v1, "vadmveoic"

    const-string/jumbo v1, "video/avc"

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->h264HwList:[Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    sget-object v2, Lcom/videoengine/NTMediaCodecVideoEncoder;->supportedColorList:[I

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-static {v1, v0, v2}, Lcom/videoengine/NTMediaCodecVideoEncoder;->findHwEncoder(Ljava/lang/String;[Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;[I)Lcom/videoengine/NTMediaCodecVideoEncoder$EncoderProperties;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    return v0

    :cond_0
    const/4 v4, 0x4

    const/4 v0, 0x0

    move v3, v0

    move v3, v0

    const/4 v4, 0x6

    return v0
.end method

.method public static isH264HwSupportedUsingTextures()Z
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v1, "dvoivc/aq"

    const/4 v4, 0x1

    const-string/jumbo v1, "vvdioao/e"

    const-string/jumbo v1, "video/avc"

    const/4 v3, 0x6

    move v4, v3

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->h264HwList:[Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v2, Lcom/videoengine/NTMediaCodecVideoEncoder;->supportedSurfaceColorList:[I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v1, v0, v2}, Lcom/videoengine/NTMediaCodecVideoEncoder;->findHwEncoder(Ljava/lang/String;[Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;[I)Lcom/videoengine/NTMediaCodecVideoEncoder$EncoderProperties;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    return v0
.end method

.method public static printStackTrace()V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->runningInstance:Lcom/videoengine/NTMediaCodecVideoEncoder;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v0, v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    array-length v1, v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-lez v1, :cond_1

    const-string v1, "aecMdbnak:idc esriracoetVecetC sosdd"

    const-string v1, "ddsteMrccokires ctE CeVaadneao:iedsc"

    const/4 v6, 0x7

    const-string/jumbo v1, "tcoCeMurcetEeaidcsdc renods odVaki:a"

    const-string v1, "MediaCodecVideoEncoder stacks trace:"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo v2, "iddeeedproMaiceNdCVomETn"

    const-string v2, "ddEmoNcdodVMeCeenioaierT"

    const/4 v6, 0x5

    const-string v2, "NTMediaCodecVideoEncoder"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v2, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x3

    array-length v1, v0

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v3, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v6, 0x1

    if-lt v3, v1, :cond_0

    const/4 v6, 0x6

    goto :goto_1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    aget-object v4, v0, v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v2, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    return-void
.end method

.method private reportEncodedFrame(I)V
    .locals 11

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetFps:I

    const/4 v10, 0x2

    if-eqz v0, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget-object v1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentType:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    sget-object v2, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->DYNAMIC_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-eq v1, v2, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    goto/16 :goto_1

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget v1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetBitrateBps:I

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    int-to-double v1, v1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-wide/high16 v3, 0x4020000000000000L    # 8.0

    const-wide/high16 v3, 0x4020000000000000L    # 8.0

    const/4 v10, 0x2

    const-wide/high16 v3, 0x4020000000000000L    # 8.0

    const-wide/high16 v3, 0x4020000000000000L    # 8.0

    const/4 v10, 0x5

    const/4 v9, 0x6

    int-to-double v5, v0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    mul-double/2addr v5, v3

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    div-double/2addr v1, v5

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-wide v3, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    int-to-double v5, p1

    const/4 v10, 0x2

    sub-double/2addr v5, v1

    const/4 v9, 0x3

    move v10, v9

    add-double/2addr v3, v5

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    iput-wide v3, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-wide v1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateObservationTimeMs:D

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    const-wide v5, 0x408f400000000000L    # 1000.0

    const-wide v5, 0x408f400000000000L    # 1000.0

    const/4 v10, 0x7

    const-wide v5, 0x408f400000000000L    # 1000.0

    const-wide v5, 0x408f400000000000L    # 1000.0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    int-to-double v7, v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    div-double/2addr v5, v7

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    add-double/2addr v1, v5

    const/4 v10, 0x2

    const/4 v9, 0x5

    iput-wide v1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateObservationTimeMs:D

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-wide/high16 v0, 0x4008000000000000L    # 3.0

    const-wide/high16 v0, 0x4008000000000000L    # 3.0

    const/4 v10, 0x5

    const-wide/high16 v0, 0x4008000000000000L    # 3.0

    const-wide/high16 v0, 0x4008000000000000L    # 3.0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-wide v5, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulatorMax:D

    const/4 v10, 0x6

    mul-double/2addr v5, v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->min(DD)D

    move-result-wide v0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    iput-wide v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v10, 0x7

    neg-double v2, v5

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->max(DD)D

    move-result-wide v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    iput-wide v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget-wide v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateObservationTimeMs:D

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-wide v2, 0x40a7700000000000L    # 3000.0

    const/4 v10, 0x3

    const-wide v2, 0x40a7700000000000L    # 3000.0

    const-wide v2, 0x40a7700000000000L    # 3000.0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    cmpl-double p1, v0, v2

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-lez p1, :cond_4

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-string/jumbo v0, "oc:q "

    const-string v0, "cc :o"

    const-string v0, "ccs A"

    const-string v0, "Acc: "

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-wide v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v9, 0x7

    const/4 v10, 0x1

    double-to-int v0, v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-string/jumbo v0, "x:.a bM"

    const/4 v10, 0x5

    const-string v0, "a :m. x"

    const-string v0, ". Max: "

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget-wide v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulatorMax:D

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    double-to-int v0, v0

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    const-string v0, "ea:.o Slcu E"

    const-string v0, "alE: .uec pS"

    const/4 v10, 0x6

    const-string v0, "eclaxbSE:p  "

    const-string v0, ". ExpScale: "

    const/4 v10, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    const-string v0, "cMaVedunoCcoodTpeeEeNrid"

    const-string v0, "cCnodeEpocdeVaeMddNTieor"

    const-string v0, "MeooEoTpedecdiVCNeindrcd"

    const-string v0, "NTMediaCodecVideoEncoder"

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {v0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-wide v1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v9, 0x4

    move v10, v9

    iget-wide v3, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulatorMax:D

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    cmpl-double p1, v1, v3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    const/4 v5, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    if-lez p1, :cond_1

    const/4 v9, 0x0

    move v10, v9

    iput-wide v3, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    iget p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    sub-int/2addr p1, v5

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    iput p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto :goto_0

    :cond_1
    const/4 v10, 0x4

    neg-double v6, v3

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    cmpg-double p1, v1, v6

    const/4 v9, 0x1

    move v10, v9

    if-gez p1, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    add-int/2addr p1, v5

    const/4 v10, 0x5

    iput p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v9, 0x2

    move v10, v9

    neg-double v1, v3

    const/4 v10, 0x5

    iput-wide v1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    goto :goto_0

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/4 v5, 0x0

    :goto_0
    const/4 v10, 0x1

    if-eqz v5, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/16 v1, 0xa

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {p1, v1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    iput p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/16 v1, -0xa

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {p1, v1}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    iput p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    const-string v1, "a bqreetq tso dlttisa cgjAn"

    const-string/jumbo v1, "etotijlcq  es asdn aArtigbt"

    const/4 v10, 0x0

    const-string v1, " gsttrus  o ieceAibatjnstld"

    const-string v1, "Adjusting bitrate scale to "

    const/4 v9, 0x2

    shr-int/2addr v10, v9

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget v1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-string v1, ":.Vmlue a"

    const-string v1, ". Value: "

    const/4 v9, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    iget v1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-direct {p0, v1}, Lcom/videoengine/NTMediaCodecVideoEncoder;->getBitrateScale(I)D

    move-result-wide v1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {p1, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    and-int/2addr v10, v9

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {v0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetBitrateBps:I

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x5

    div-int/lit16 p1, p1, 0x3e8

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetFps:I

    const/4 v9, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-direct {p0, p1, v0}, Lcom/videoengine/NTMediaCodecVideoEncoder;->setRates(II)Z

    :cond_3
    const/4 v10, 0x2

    const/4 v9, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v10, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    iput-wide v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateObservationTimeMs:D

    :cond_4
    :goto_1
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    return-void
.end method

.method public static setErrorCallback(Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;)V
    .locals 4

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v0, "ioCeoicdcMorsdVdeeTedNon"

    const-string v0, "eosedVCiceTorcdienNoMEdd"

    const/4 v3, 0x1

    const-string v0, "eoNeMbVnoceiTedaidCddocr"

    const-string v0, "NTMediaCodecVideoEncoder"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v1, "eSrlo umcarctk reb"

    const-string/jumbo v1, "l Smceoacrbrka tre"

    const/4 v3, 0x5

    const-string v1, "carbtarproe clklS "

    const-string v1, "Set error callback"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    sput-object p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->errorCallback:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;

    const/4 v3, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method private setRates(II)Z
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-direct {p0}, Lcom/videoengine/NTMediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    mul-int/lit16 v0, p1, 0x3e8

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentType:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    sget-object v2, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->DYNAMIC_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x3

    move v9, v8

    if-ne v1, v2, :cond_0

    const/4 v9, 0x1

    int-to-double v3, v0

    const/4 v8, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-wide/high16 v5, 0x4020000000000000L    # 8.0

    const-wide/high16 v5, 0x4020000000000000L    # 8.0

    const/4 v9, 0x1

    const-wide/high16 v5, 0x4020000000000000L    # 8.0

    const-wide/high16 v5, 0x4020000000000000L    # 8.0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    div-double v5, v3, v5

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    iput-wide v5, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulatorMax:D

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget v5, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetBitrateBps:I

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-lez v5, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-ge v0, v5, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-wide v6, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    mul-double/2addr v6, v3

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    int-to-double v3, v5

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    div-double/2addr v6, v3

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    iput-wide v6, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulator:D

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    iput v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetBitrateBps:I

    const/4 v9, 0x2

    iput p2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetFps:I

    const/4 v9, 0x7

    const/4 v8, 0x2

    sget-object v3, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->FRAMERATE_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string v4, " p bo s.k:Fs"

    const/4 v9, 0x2

    const-string v4, "Fss   b.qpk:"

    const-string v4, " kbps. Fps: "

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string/jumbo v5, "sts s:aReb"

    const-string v5, "etR: basse"

    const/4 v9, 0x6

    const-string/jumbo v5, "sasmR :ett"

    const-string/jumbo v5, "setRates: "

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-string v6, "VdMNoeuCeoreoineddETadci"

    const-string v6, "CedeNnuiiTecEVeadcdodrMo"

    const/4 v9, 0x7

    const-string v6, "eciorboNddcEenVeTidCaedo"

    const-string v6, "NTMediaCodecVideoEncoder"

    const/4 v9, 0x0

    const/4 v8, 0x6

    if-ne v1, v3, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-lez p2, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x2

    mul-int/lit8 v0, v0, 0x1e

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    div-int/2addr v0, p2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-direct {p2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-string p1, "  >-"

    const-string p1, ">  -"

    const-string p1, ">-  "

    const-string p1, " -> "

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    div-int/lit16 p1, v0, 0x3e8

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetFps:I

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v8, 0x1

    invoke-static {v6, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-ne v1, v2, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-direct {p2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetFps:I

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-string/jumbo p1, "lp.Epcuax:S "

    const-string p1, "al:.Sx pEepc"

    const/4 v9, 0x2

    const-string p1, ".lxpEcSp:  e"

    const-string p1, ". ExpScale: "

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v9, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {v6, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-eqz p1, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    int-to-double v0, v0

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct {p0, p1}, Lcom/videoengine/NTMediaCodecVideoEncoder;->getBitrateScale(I)D

    move-result-wide p1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    mul-double/2addr v0, p1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    double-to-int v0, v0

    const/4 v8, 0x4

    const/4 v8, 0x1

    goto :goto_0

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-direct {p2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    iget p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetFps:I

    const/4 v9, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-static {v6, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    :goto_0
    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    new-instance p1, Landroid/os/Bundle;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string/jumbo p2, "etioatrqqvebd"

    const-string p2, "aveb-dtoqetir"

    const/4 v9, 0x0

    const-string/jumbo p2, "tistdiebroev-"

    const-string/jumbo p2, "video-bitrate"

    const/4 v9, 0x0

    invoke-virtual {p1, p2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v9, 0x4

    iget-object p2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p2, p1}, Landroid/media/MediaCodec;->setParameters(Landroid/os/Bundle;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    const/4 p1, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    return p1

    :catch_0
    move-exception p1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-string p2, "elametessdRf ta"

    const-string/jumbo p2, "fesaRtsdteslae "

    const/4 v9, 0x1

    const-string p2, "Rldfoessae tiat"

    const-string/jumbo p2, "setRates failed"

    const/4 v8, 0x0

    and-int/2addr v9, v8

    invoke-static {v6, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    const/4 p1, 0x0

    const/4 v9, 0x1

    return p1
.end method


# virtual methods
.method dequeueInputBuffer()I
    .locals 5

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/videoengine/NTMediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/media/MediaCodec;->dequeueInputBuffer(J)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    return v0

    :catch_0
    move-exception v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v1, "ddodTbnCreVieieoMccdeomN"

    const-string/jumbo v1, "nedmderoiMcoeNoddVCeTiEc"

    const/4 v4, 0x3

    const-string/jumbo v1, "rNdCedueniVdaEcoocieoeTd"

    const-string v1, "NTMediaCodecVideoEncoder"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v2, "derfpatpendeuIluteqBfeufui"

    const-string v2, "dequeueIntputBuffer failed"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v0, -0x2

    const/4 v4, 0x2

    return v0
.end method

.method public dequeueOutputBuffer(J)Z
    .locals 15

    move-object v10, p0

    move-object v10, p0

    move-object v10, p0

    move-object v10, p0

    const-string/jumbo v11, "nrdaoCdNcieToMceVodeeoEd"

    const-string/jumbo v11, "inCcMdVTqddcoiENaedoeeeo"

    const-string v11, "NTMediaCodecVideoEncoder"

    invoke-direct {p0}, Lcom/videoengine/NTMediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    const/4 v12, 0x0

    :try_start_0
    iget-object v0, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    new-instance v0, Landroid/media/MediaCodec$BufferInfo;

    invoke-direct {v0}, Landroid/media/MediaCodec$BufferInfo;-><init>()V

    iget-object v1, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    invoke-virtual {v1, v0, v2, v3}, Landroid/media/MediaCodec;->dequeueOutputBuffer(Landroid/media/MediaCodec$BufferInfo;J)I

    move-result v1

    const/4 v4, 0x2

    const/4 v13, 0x1

    if-ltz v1, :cond_1

    iget v5, v0, Landroid/media/MediaCodec$BufferInfo;->flags:I

    and-int/2addr v5, v4

    if-eqz v5, :cond_0

    move v5, v13

    move v5, v13

    move v5, v13

    move v5, v13

    goto :goto_0

    :cond_0
    move v5, v12

    move v5, v12

    move v5, v12

    :goto_0
    if-eqz v5, :cond_1

    new-instance v5, Ljava/lang/StringBuilder;

    const-string/jumbo v6, "l sc Cu.cOfsegnf  fo:b daifitreeg t"

    const-string v6, ":gtnobia rescOCefeo ft  di glf c.uf"

    const-string/jumbo v6, "rcimd s Oto f i ua:ce.eftngfosCe gl"

    const-string v6, "Codec config flag is ture. Offset: "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v6, v0, Landroid/media/MediaCodec$BufferInfo;->offset:I

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "e Suo.z "

    const-string v6, ": zSe.u "

    const-string v6, ".iz Sb :"

    const-string v6, ". Size: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v6, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v11, v5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iget v5, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    invoke-static {v5}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v5

    iput-object v5, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    iget-object v5, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->outputBuffers:[Ljava/nio/ByteBuffer;

    aget-object v5, v5, v1

    iget v6, v0, Landroid/media/MediaCodec$BufferInfo;->offset:I

    invoke-virtual {v5, v6}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    iget-object v5, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->outputBuffers:[Ljava/nio/ByteBuffer;

    aget-object v5, v5, v1

    iget v6, v0, Landroid/media/MediaCodec$BufferInfo;->offset:I

    iget v7, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    add-int/2addr v6, v7

    invoke-virtual {v5, v6}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    iget-object v5, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    iget-object v6, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->outputBuffers:[Ljava/nio/ByteBuffer;

    aget-object v6, v6, v1

    invoke-virtual {v5, v6}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    iget-object v5, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v5, v1, v12}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V

    iget-object v1, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v1, v0, v2, v3}, Landroid/media/MediaCodec;->dequeueOutputBuffer(Landroid/media/MediaCodec$BufferInfo;J)I

    move-result v1

    :cond_1
    if-ltz v1, :cond_8

    iget-object v2, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->outputBuffers:[Ljava/nio/ByteBuffer;

    aget-object v2, v2, v1

    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->duplicate()Ljava/nio/ByteBuffer;

    move-result-object v2

    iget v3, v0, Landroid/media/MediaCodec$BufferInfo;->offset:I

    invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    iget v3, v0, Landroid/media/MediaCodec$BufferInfo;->offset:I

    iget v5, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    add-int/2addr v3, v5

    invoke-virtual {v2, v3}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    iget v3, v0, Landroid/media/MediaCodec$BufferInfo;->flags:I
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    and-int/2addr v3, v13

    if-eqz v3, :cond_2

    move v3, v13

    move v3, v13

    move v3, v13

    move v3, v13

    goto :goto_1

    :cond_2
    move v3, v12

    move v3, v12

    move v3, v12

    move v3, v12

    :goto_1
    const/4 v5, 0x0

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const-string v8, " info.size="

    if-eqz v3, :cond_5

    :try_start_1
    iget v9, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->type:I

    if-ne v9, v4, :cond_5

    iget-object v4, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    invoke-virtual {v4}, Ljava/nio/Buffer;->capacity()I

    move-result v4

    iget-object v9, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    invoke-virtual {v9}, Ljava/nio/Buffer;->capacity()I

    move-result v9

    iget v14, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    add-int/2addr v9, v14

    if-ge v4, v9, :cond_3

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v9, ".osalwu aactptu, eilrm_unyo-ceyciccp slpa lltd c: ebo,ati__ tio2ifalf"

    const-string v9, "a oabtlplollc  :t   iet-oaaucty2 psfi,_,smarlw_cyioaoiitfcedc._euclpn"

    const-string v9, "dccittuppl_a flcae ,twiao lr c.fec: yb_ia2o atnpol- ylo _ol,istuciasm"

    const-string/jumbo v9, "out_encode_buff_.capacity is too small 2, it will re-alloc, capacity:"

    invoke-direct {v4, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v9, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    invoke-virtual {v9}, Ljava/nio/Buffer;->capacity()I

    move-result v9

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v8, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v11, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    iput-object v5, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    iget-object v4, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    invoke-virtual {v4}, Ljava/nio/Buffer;->capacity()I

    move-result v4

    iget v5, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    add-int/2addr v4, v5

    iget v5, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->width_:I

    iget v8, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->height_:I

    mul-int/2addr v5, v8

    div-int/lit8 v5, v5, 0x4

    add-int/2addr v4, v5

    invoke-static {v4}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v4

    iput-object v4, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    :cond_3
    iget-object v4, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    invoke-virtual {v4}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    iget-object v4, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    iget-object v5, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    invoke-virtual {v4, v5}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    iget-object v4, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    invoke-virtual {v4, v2}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    iget-object v2, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    invoke-virtual {v2, v12}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    iget-object v2, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    invoke-virtual {v2}, Ljava/nio/Buffer;->capacity()I

    move-result v2

    iget v4, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    add-int/2addr v2, v4

    iget-object v4, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v4, v1, v12}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V

    if-eqz v3, :cond_4

    move v3, v13

    move v3, v13

    goto :goto_2

    :cond_4
    move v3, v12

    move v3, v12

    move v3, v12

    move v3, v12

    :goto_2
    iget-wide v0, v0, Landroid/media/MediaCodec$BufferInfo;->presentationTimeUs:J

    div-long v4, v0, v6

    iget-object v0, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    int-to-long v6, v2

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    move-wide v3, v4

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-wide/from16 v8, p1

    invoke-virtual/range {v1 .. v9}, Lcom/videoengine/NTMediaCodecVideoEncoder;->executeEncodedData(IJLjava/nio/ByteBuffer;JJ)V

    return v13

    :cond_5
    iget-object v4, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    invoke-virtual {v4}, Ljava/nio/Buffer;->capacity()I

    move-result v4

    iget v9, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    if-ge v4, v9, :cond_6

    new-instance v4, Ljava/lang/StringBuilder;

    const-string/jumbo v9, "oriapaooq dl_lt3clac aei-wim_y:itlsl a ciualtp s fcbueycfc,t,nooqte."

    const-string/jumbo v9, "mcp fcluq y_uaac,lrtyfn lco-l,ttii ceat3i do aooocesii:lb. a_teawspl"

    const-string v9, "cescfta_w  , accleaslbyopi a-fi idli:iolte_n l,t3omu.tcalrou oycpt_a"

    const-string/jumbo v9, "out_encode_buff_.capacity is too small3, it will re-alloc, capacity:"

    invoke-direct {v4, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v9, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    invoke-virtual {v9}, Ljava/nio/Buffer;->capacity()I

    move-result v9

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v8, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v11, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    iput-object v5, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    iget v4, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    iget v5, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->width_:I

    iget v8, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->height_:I

    mul-int/2addr v5, v8

    div-int/lit8 v5, v5, 0x4

    add-int/2addr v4, v5

    invoke-static {v4}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v4

    iput-object v4, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    :cond_6
    iget-object v4, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    invoke-virtual {v4, v2}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    iget-object v2, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    invoke-virtual {v2, v12}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    iget v2, v0, Landroid/media/MediaCodec$BufferInfo;->size:I

    iget-object v4, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v4, v1, v12}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V

    if-eqz v3, :cond_7

    move v3, v13

    move v3, v13

    move v3, v13

    move v3, v13

    goto :goto_3

    :cond_7
    move v3, v12

    move v3, v12

    move v3, v12

    :goto_3
    iget-wide v0, v0, Landroid/media/MediaCodec$BufferInfo;->presentationTimeUs:J

    div-long v4, v0, v6

    iget-object v0, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    int-to-long v6, v2

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move v2, v3

    move v2, v3

    move v2, v3

    move-wide v3, v4

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-wide/from16 v8, p1

    invoke-virtual/range {v1 .. v9}, Lcom/videoengine/NTMediaCodecVideoEncoder;->executeEncodedData(IJLjava/nio/ByteBuffer;JJ)V

    return v13

    :cond_8
    const/4 v0, -0x3

    if-ne v1, v0, :cond_9

    iget-object v0, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->getOutputBuffers()[Ljava/nio/ByteBuffer;

    move-result-object v0

    iput-object v0, v10, Lcom/videoengine/NTMediaCodecVideoEncoder;->outputBuffers:[Ljava/nio/ByteBuffer;

    return v12

    :cond_9
    const/4 v0, -0x2

    if-ne v1, v0, :cond_a

    return v12

    :cond_a
    const/4 v0, -0x1

    if-ne v1, v0, :cond_b

    return v12

    :cond_b
    new-instance v0, Ljava/lang/RuntimeException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "tfrmeed s:ufuOetpuequ"

    const-string v3, ":usOfuBt eupqftueeder"

    const-string v3, "eB:ro uteedptuefuOquf"

    const-string v3, "dequeueOutputBuffer: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    move-exception v0

    const-string/jumbo v1, "pu efbuOeefuqeuBldtirdfmea"

    const-string/jumbo v1, "uetmpreiutdOefafudf eBeuql"

    const-string v1, "eBeuefuulaftidtpuq eeOudrf"

    const-string v1, "dequeueOutputBuffer failed"

    invoke-static {v11, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v12
.end method

.method public encodeBuffer(Z[BJ)Z
    .locals 11

    const/4 v9, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-direct {p0}, Lcom/videoengine/NTMediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    const/4 v0, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    const-string/jumbo v1, "oeeooiCNoardceieddnEMVTd"

    const/4 v10, 0x4

    const-string/jumbo v1, "oddanVepoNMrdCTecEeoiide"

    const-string v1, "NTMediaCodecVideoEncoder"

    const/4 v10, 0x0

    const/4 v9, 0x5

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v10, 0x2

    const/4 v9, 0x2

    new-instance p1, Landroid/os/Bundle;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-string v2, "es-neyrqqtub"

    const-string/jumbo v2, "nutqrbec-esy"

    const/4 v10, 0x1

    const-string v2, "cqses-netyrs"

    const-string/jumbo v2, "request-sync"

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p1, v2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v2, p1}, Landroid/media/MediaCodec;->setParameters(Landroid/os/Bundle;)V

    :cond_0
    const/4 v10, 0x7

    invoke-virtual {p0}, Lcom/videoengine/NTMediaCodecVideoEncoder;->getInputBuffers()[Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {p0}, Lcom/videoengine/NTMediaCodecVideoEncoder;->dequeueInputBuffer()I

    move-result v3

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-ltz v3, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    aget-object p1, p1, v3

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {p1, p2}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p1}, Ljava/nio/Buffer;->position()I

    move-result v2

    const/4 v10, 0x7

    const/4 v9, 0x2

    array-length v4, p2

    const/4 v10, 0x4

    if-eq v2, v4, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-string v4, " usmi)ft ineptro(:pufunrrBo]o[.e"

    const-string v4, " uieifuo:rn .]nofBrup(tr[eti)pos"

    const/4 v10, 0x7

    const-string/jumbo v4, "fup]o)fnio :tospBur .ore(rnetii["

    const-string v4, "[error] inputBuffer.position(): "

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {p1}, Ljava/nio/Buffer;->position()I

    move-result p1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const-string/jumbo p1, "vy.:g 4p0n e2uth,"

    const/4 v10, 0x3

    const-string p1, "4l2g:bnyt  .vuh,e"

    const-string p1, ",  yuv420.length:"

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    array-length p1, p2

    const/4 v10, 0x2

    const/4 v9, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    const/4 v4, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    array-length v5, p2

    const/4 v10, 0x4

    const-wide/16 p1, 0x3e8

    const/4 v10, 0x4

    const-wide/16 p1, 0x3e8

    const-wide/16 p1, 0x3e8

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    mul-long v6, p3, p1

    const/4 v9, 0x7

    shl-int/2addr v10, v9

    const/4 v8, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual/range {v2 .. v8}, Landroid/media/MediaCodec;->queueInputBuffer(IIIJI)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_2
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    const/4 p1, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    return p1

    :catch_0
    move-exception p1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-string/jumbo p2, "nuaeieuodefqldcfBer"

    const-string/jumbo p2, "fBlafefiqeudeonedrc"

    const/4 v10, 0x7

    const-string p2, "eBf filpdefncueoeda"

    const-string p2, "encodeBuffer failed"

    invoke-static {v1, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v9, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    return v0
.end method

.method public native executeEncodedData(IJLjava/nio/ByteBuffer;JJ)V
.end method

.method public getColorFormat()I
    .locals 4

    const/4 v3, 0x7

    iget v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->colorFormat:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/16 v1, 0x13

    const/4 v2, 0x3

    move v3, v2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/16 v1, 0x15

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-ne v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v0
.end method

.method getInputBuffers()[Ljava/nio/ByteBuffer;
    .locals 3

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/media/MediaCodec;->getInputBuffers()[Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public initEncode(IIIII)Z
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const-string/jumbo v1, "o c:t diqieEannaJ"

    const-string v1, " nsaaJdcitoE e:in"

    const/4 v8, 0x7

    const-string v1, "aesJ:cvd otnni Ea"

    const-string v1, "Java initEncode: "

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const-string v1, ":  "

    const-string v1, " : "

    const-string v1, "  :"

    const-string v1, " : "

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string v1, " x "

    const-string/jumbo v1, "x  "

    const/4 v8, 0x2

    const-string v1, "  x"

    const-string v1, " x "

    const/4 v8, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    shl-int/2addr v8, v7

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string v1, "@.  "

    const-string v1, ". @ "

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string v1, "bmpm "

    const-string v1, " bsmp"

    const/4 v8, 0x6

    const-string/jumbo v1, "k bso"

    const-string v1, " kbps"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string v1, "cdnrMbaiCodoodTeEdciVoee"

    const-string/jumbo v1, "oeVroMedCaoEdncideiodeTc"

    const/4 v8, 0x7

    const-string v1, "dMVCdruodcNiEecoieeoenad"

    const-string v1, "NTMediaCodecVideoEncoder"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    iput p2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->width_:I

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    iput p3, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->height_:I

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-nez v0, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->h264HwList:[Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    sget-object v2, Lcom/videoengine/NTMediaCodecVideoEncoder;->supportedColorList:[I

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string/jumbo v3, "ibodc/vpv"

    const-string/jumbo v3, "vvocebd/i"

    const/4 v8, 0x0

    const-string/jumbo v3, "ieadcvvoq"

    const-string/jumbo v3, "video/avc"

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v3, v0, v2}, Lcom/videoengine/NTMediaCodecVideoEncoder;->findHwEncoder(Ljava/lang/String;[Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;[I)Lcom/videoengine/NTMediaCodecVideoEncoder$EncoderProperties;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-eqz v0, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    mul-int v2, p2, p3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    mul-int/lit8 v2, v2, 0x3

    const/4 v8, 0x5

    const/4 v4, 0x6

    const/4 v8, 0x7

    const/4 v4, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    div-int/2addr v2, v4

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    add-int/lit16 v2, v2, 0x800

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {v2}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    iput-object v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    sput-object p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->runningInstance:Lcom/videoengine/NTMediaCodecVideoEncoder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget v2, v0, Lcom/videoengine/NTMediaCodecVideoEncoder$EncoderProperties;->colorFormat:I

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    iput v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->colorFormat:I

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object v2, v0, Lcom/videoengine/NTMediaCodecVideoEncoder$EncoderProperties;->bitrateAdjustmentType:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    iput-object v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentType:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    sget-object v5, Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;->FRAMERATE_ADJUSTMENT:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/16 v6, 0x1e

    const/4 v8, 0x1

    if-ne v2, v5, :cond_0

    const/4 v8, 0x5

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    invoke-static {p5, v6}, Ljava/lang/Math;->min(II)I

    move-result v6

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance p5, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string v2, "afsorCrmol: ot"

    const-string v2, "Color format: "

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-direct {p5, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->colorFormat:I

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p5

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {v1, p5}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x1

    const/4 v7, 0x1

    mul-int/lit16 p4, p4, 0x3e8

    const/4 v8, 0x0

    const/4 v7, 0x3

    iput p4, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetBitrateBps:I

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    iput v6, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetFps:I

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    int-to-double p4, p4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-wide/high16 v5, 0x4020000000000000L    # 8.0

    const-wide/high16 v5, 0x4020000000000000L    # 8.0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    div-double/2addr p4, v5

    const/4 v7, 0x6

    move v8, v7

    iput-wide p4, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulatorMax:D

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-wide/16 p4, 0x0

    const-wide/16 p4, 0x0

    const/4 v8, 0x2

    const-wide/16 p4, 0x0

    const-wide/16 p4, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    iput-wide p4, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    iput-wide p4, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateObservationTimeMs:D

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    const/4 p4, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    iput p4, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p5

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    iput-object p5, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v3, p2, p3}, Landroid/media/MediaFormat;->createVideoFormat(Ljava/lang/String;II)Landroid/media/MediaFormat;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string p3, "beimtru"

    const-string/jumbo p3, "tetibru"

    const/4 v8, 0x4

    const-string/jumbo p3, "trbaoei"

    const-string p3, "bitrate"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget p5, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetBitrateBps:I

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p2, p3, p5}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string/jumbo p3, "oaimebt-rpdt"

    const-string/jumbo p3, "tritabmp-deo"

    const/4 v8, 0x1

    const-string p3, "driebtuamto-"

    const-string p3, "bitrate-mode"

    const/4 v8, 0x2

    const/4 v7, 0x1

    invoke-virtual {p2, p3, v4}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string/jumbo p3, "fot-qalpoorr"

    const-string/jumbo p3, "oflatrorqo-c"

    const/4 v8, 0x6

    const-string/jumbo p3, "ocr-ofloqatm"

    const-string p3, "color-format"

    const/4 v8, 0x0

    iget p5, v0, Lcom/videoengine/NTMediaCodecVideoEncoder$EncoderProperties;->colorFormat:I

    const/4 v7, 0x4

    move v8, v7

    invoke-virtual {p2, p3, p5}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const/4 v8, 0x5

    const-string p3, "asstf-erar"

    const-string p3, "e-sraatref"

    const/4 v8, 0x3

    const-string/jumbo p3, "ftmm-earre"

    const-string/jumbo p3, "frame-rate"

    const/4 v8, 0x7

    iget p5, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->targetFps:I

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p2, p3, p5}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string p5, ": mmo  art"

    const-string/jumbo p5, "tarm  :mF "

    const/4 v8, 0x1

    const-string p5, " a orb:tmF"

    const-string p5, "  Format: "

    const/4 v8, 0x5

    invoke-direct {p3, p5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {v1, p3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string/jumbo p3, "tve-nruimaoa-lie"

    const-string p3, "aitfomlrev-eni-a"

    const-string p3, "aiartniprevmfl--"

    const-string/jumbo p3, "i-frame-interval"

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/16 p5, 0xa

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p2, p3, p5}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object p3, v0, Lcom/videoengine/NTMediaCodecVideoEncoder$EncoderProperties;->codecName:Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x3

    invoke-static {p3}, Lcom/videoengine/NTMediaCodecVideoEncoder;->createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;

    move-result-object p3

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    iput-object p3, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    iput p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->type:I

    const/4 v8, 0x6

    if-nez p3, :cond_1

    const/4 v7, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string p1, "dtde co qe aante Crmnreenaib"

    const-string p1, "dCreebmriena d  tnca eetnoao"

    const/4 v8, 0x3

    const-string p1, "Can not create media encoder"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    return p4

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 p1, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    const/4 p5, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p3, p2, p5, p5, p1}, Landroid/media/MediaCodec;->configure(Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V

    const/4 v8, 0x3

    iget-object p2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p2}, Landroid/media/MediaCodec;->start()V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget-object p2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p2}, Landroid/media/MediaCodec;->getOutputBuffers()[Ljava/nio/ByteBuffer;

    move-result-object p2

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    iput-object p2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->outputBuffers:[Ljava/nio/ByteBuffer;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    const-string/jumbo p3, "tfsbu uupfr:O eu"

    const-string/jumbo p3, "fuuse u t:brfuOp"

    const/4 v8, 0x1

    const-string/jumbo p3, "tu m:frte pfusub"

    const-string p3, "Output buffers: "

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget-object p3, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->outputBuffers:[Ljava/nio/ByteBuffer;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    array-length p3, p3

    const/4 v8, 0x2

    const/4 v7, 0x1

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x0

    const/4 v7, 0x0

    return p1

    :catch_0
    move-exception p1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string p2, "dcialinpfie oeEdt"

    const/4 v8, 0x1

    const-string/jumbo p2, "ndceoianEi ofltde"

    const-string/jumbo p2, "initEncode failed"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v1, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    return p4

    :cond_2
    const/4 v8, 0x0

    new-instance p2, Ljava/lang/RuntimeException;

    const/4 v7, 0x7

    move v8, v7

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-string/jumbo p4, "tdH rbfncnn r o Wdq nfoaoC e"

    const-string/jumbo p4, "no fdnrfqoct  doi W an nCerH"

    const/4 v8, 0x6

    const-string/jumbo p4, "rnoe  ufi enr dc Hon tCaWonf"

    const-string p4, "Can not find HW encoder for "

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-direct {p3, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-direct {p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    throw p2

    :cond_3
    const/4 v8, 0x7

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v8, 0x0

    const-string p2, "eeFs ?tprtlgos(ra) o"

    const-string/jumbo p2, "rtsloeo? e)Fare gs(t"

    const/4 v8, 0x0

    const-string/jumbo p2, "or)os(aoqrteFee ? lg"

    const-string p2, "Forgot to release()?"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    move v8, v7

    throw p1
.end method

.method public release()V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string v0, "EasJer daornamlseee"

    const-string/jumbo v0, "lromen acesaeJeaErd"

    const/4 v6, 0x7

    const-string v0, "Java releaseEncoder"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v1, "TicVoodeNEoridMceaCedndo"

    const/4 v6, 0x0

    const-string v1, "ecdmioroTCddaeceNiEdVnMo"

    const-string v1, "NTMediaCodecVideoEncoder"

    const/4 v6, 0x5

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/videoengine/NTMediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v0, v2}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v6, 0x1

    new-instance v3, Lcom/videoengine/NTMediaCodecVideoEncoder$1;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {v3, p0, v0}, Lcom/videoengine/NTMediaCodecVideoEncoder$1;-><init>(Lcom/videoengine/NTMediaCodecVideoEncoder;Ljava/util/concurrent/CountDownLatch;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    new-instance v4, Ljava/lang/Thread;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {v4, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v4}, Ljava/lang/Thread;->start()V

    const/4 v6, 0x4

    const-wide/16 v3, 0x1388

    const-wide/16 v3, 0x1388

    const/4 v6, 0x3

    const-wide/16 v3, 0x1388

    const-wide/16 v3, 0x1388

    const/4 v6, 0x5

    const/4 v5, 0x3

    invoke-static {v0, v3, v4}, Lcom/ntjbase/NTThreadUtils;->awaitUninterruptibly(Ljava/util/concurrent/CountDownLatch;J)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string/jumbo v0, "ieuaoest bdm eecoM ilenoredet"

    const-string/jumbo v0, "teiorbdem ieltec eMunoae edsr"

    const/4 v6, 0x2

    const-string/jumbo v0, "rmle bod treedueceeniaaiM ste"

    const-string v0, "Media encoder release timeout"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    sget v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->codecErrors:I

    const/4 v5, 0x7

    add-int/2addr v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    sput v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->codecErrors:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->errorCallback:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string v2, "boaIrou ruvkcaEd.orcenc e :srk e colr"

    const-string v2, "enalcluEsac cIr. oo e eokrorkdb rrcv:"

    const/4 v6, 0x2

    const-string v2, "ae cr kpEl rorvs nol.erIcode rcoackbr"

    const-string v2, "Invoke codec error callback. Errors: "

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    sget v2, Lcom/videoengine/NTMediaCodecVideoEncoder;->codecErrors:I

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->errorCallback:Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    sget v2, Lcom/videoengine/NTMediaCodecVideoEncoder;->codecErrors:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-interface {v0, v2}, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;->onMediaCodecVideoEncoderCriticalError(I)V

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoEncoder;->runningInstance:Lcom/videoengine/NTMediaCodecVideoEncoder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->out_encode_buff_:Ljava/nio/ByteBuffer;

    const-string/jumbo v0, "set out_encode_buff_ to null"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v0, "searvJ nqEooeaelprndeeca"

    const-string v0, "aeadre pesnornaeelvc oEJ"

    const/4 v6, 0x1

    const-string v0, "aesleaovns dedrecano rEe"

    const-string v0, "Java releaseEncoder done"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    return-void
.end method

.method releaseOutputBuffer(I)Z
    .locals 5

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/videoengine/NTMediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1, p1, v0}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 p1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    return p1

    :catch_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v1, "niomdVModcecddToerNeCiae"

    const-string v1, "NTMediaCodecVideoEncoder"

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    const-string v2, "afauofeee tsduirllBuqpeOfr"

    const-string v2, " urartsaqBeieOfufdulflpeee"

    const/4 v4, 0x1

    const-string/jumbo v2, "r OeabflpuueiedflsftBratee"

    const-string/jumbo v2, "releaseOutputBuffer failed"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v1, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    return v0
.end method
