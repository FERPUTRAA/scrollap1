.class Lcom/videoengine/NTGLESRenderer$ConfigChooser;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/opengl/GLSurfaceView$EGLConfigChooser;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/videoengine/NTGLESRenderer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ConfigChooser"
.end annotation


# static fields
.field private static EGL_OPENGL_ES2_BIT:I = 0x4

.field private static s_configAttribs2:[I


# instance fields
.field protected mAlphaSize:I

.field protected mBlueSize:I

.field protected mDepthSize:I

.field protected mGreenSize:I

.field protected mRedSize:I

.field protected mStencilSize:I

.field private mValue:[I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/16 v0, 0x9

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-array v0, v0, [I

    const/4 v5, 0x1

    const/4 v1, 0x5

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/16 v2, 0x3024

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    aput v2, v0, v1

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v2, 0x4

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    aput v2, v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v1, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/16 v3, 0x3023

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    aput v3, v0, v1

    const/4 v5, 0x2

    const/4 v1, 0x4

    const/4 v5, 0x7

    const/4 v1, 0x3

    const/4 v5, 0x4

    aput v2, v0, v1

    const/4 v5, 0x4

    const/16 v1, 0x3022

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    aput v1, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v1, 0x5

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    aput v2, v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v1, 0x6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v3, 0x3040

    const/4 v4, 0x2

    and-int/2addr v5, v4

    aput v3, v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v1, 0x7

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    aput v2, v0, v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/16 v1, 0x8

    const/4 v5, 0x5

    const/16 v2, 0x3038

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    aput v2, v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    sput-object v0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->s_configAttribs2:[I

    const/4 v4, 0x7

    move v5, v4

    return-void
.end method

.method public constructor <init>(IIIIII)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-array v0, v0, [I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mValue:[I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput p1, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mRedSize:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput p2, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mGreenSize:I

    iput p3, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mBlueSize:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput p4, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mAlphaSize:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput p5, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mDepthSize:I

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput p6, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mStencilSize:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method private findConfigAttrib(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;II)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~si~~t~@@bi m@/nil~@uKf 1~ .oM~  @S~@@~~ fbac @ ~ -o@~~ @ s@ ~b~@  o@@@ ~~@ roold/@@@~v ~~4~~ot"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mValue:[I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {p1, p2, p3, p4, v0}, Ljavax/microedition/khronos/egl/EGL10;->eglGetConfigAttrib(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;I[I)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mValue:[I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p2, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    aget p1, p1, p2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return p5
.end method

.method private printConfig(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;)V
    .locals 35

    const/16 v0, 0x21

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    const-string v2, "_REmELGFEIS_sBZ"

    const-string v2, "BRs_L_ZIEGFESEU"

    const-string v2, "IREFoZ_SLFEGU_B"

    const-string v2, "EGL_BUFFER_SIZE"

    const-string/jumbo v3, "mLS_IbGHAPAZE_"

    const-string v3, "SA_mIPZL_EGAEH"

    const-string v3, "PLSIH_uAELGAZE"

    const-string v3, "EGL_ALPHA_SIZE"

    const-string v4, "UZISBo_pELELE"

    const-string v4, "ES_Lo_BEILZUE"

    const-string v4, "Z__LSEGEqIUBE"

    const-string v4, "EGL_BLUE_SIZE"

    const-string v5, "ESsEGNL_EIGZER"

    const-string v5, "RZELIb_EEGNGSE"

    const-string v5, "SE_mNRE_IGGZEE"

    const-string v5, "EGL_GREEN_SIZE"

    const-string v6, "DGuEoER_SLIZ"

    const-string v6, "LERDIGuSZ_EE"

    const-string v6, "D__RGbEIESLE"

    const-string v6, "EGL_RED_SIZE"

    const-string v7, "DZ_GEpuTE_IPES"

    const-string v7, "GDLEEZPpI_STE_"

    const-string v7, "LHZ_TIPpS_EEGE"

    const-string v7, "EGL_DEPTH_SIZE"

    const-string/jumbo v8, "qITCGEI_qLEZS_EL"

    const-string v8, "IESEZ_ILqSL_EGTC"

    const-string v8, "SEsSCNLT__IEZGLE"

    const-string v8, "EGL_STENCIL_SIZE"

    const-string/jumbo v9, "sECm_FNV_GGAOEITC"

    const-string v9, "EEsAT_CGCAON_FIGV"

    const-string v9, "GTF_oL_ECVOAAICNG"

    const-string v9, "EGL_CONFIG_CAVEAT"

    const-string v10, "L_GICbDFG_NOE"

    const-string v10, "EGL_CONFIG_ID"

    const-string v11, "E_VELLumL"

    const-string v11, "E_LmLVLGE"

    const-string v11, "EGLEEVLpL"

    const-string v11, "EGL_LEVEL"

    const-string v12, "R_HHBTMoqEEILFG__UPFXA"

    const-string v12, "GFHHoUM_XL_EPGFARTIBE_"

    const-string v12, "_FsB_FM_ARPUTGLHEGIXHE"

    const-string v12, "EGL_MAX_PBUFFER_HEIGHT"

    const-string v13, "MPEmUEFXX_LbI_L_SPAFEB"

    const-string v13, "FELISbLMG_EX_A_XUPBFEP"

    const-string v13, "MFRXoSFX__GEEABPLPLIEU"

    const-string v13, "EGL_MAX_PBUFFER_PIXELS"

    const-string v14, "ELRHub_DFBPUGTEWXA_FI"

    const-string v14, "AD_EHFuPMLRTE_XFUGWBI"

    const-string v14, "__GEBHuLFTMWFP_DXEUAI"

    const-string v14, "EGL_MAX_PBUFFER_WIDTH"

    const-string v15, "BARRNp_pEDGIVE_TLENLE"

    const-string v15, "_IRNGLVpDRATENEAELEB_"

    const-string v15, "RAGRAETVqB_ELED_IENNL"

    const-string v15, "EGL_NATIVE_RENDERABLE"

    const-string v16, "D_sATLIANI_VE_GSLVIE"

    const-string v16, "VNALLSI_qT_VEGEDAI_I"

    const-string v16, "S_AmNUAILVDIT_EIEV_G"

    const-string v16, "EGL_NATIVE_VISUAL_ID"

    const-string v17, "UE_SoTINVIPAVEEAGTs_LY"

    const-string v17, "PEsTYGLVVSNTAAEE_IUIL_"

    const-string v17, "EGL_NATIVE_VISUAL_TYPE"

    const-string v18, "ERR_DbCEREPEVGOURL_SEEm"

    const-string v18, "EEDmORLERS_VERGPSERC_EU"

    const-string v18, "CSRLUEuERESP_DESEO_ERRV"

    const-string v18, "EGL_PRESERVED_RESOURCES"

    const-string v19, "MoSELGPp_EA"

    const-string v19, "EMSAoPSEL_G"

    const-string v19, "EPGLLSMSqE_"

    const-string v19, "EGL_SAMPLES"

    const-string v20, "PEsFRbSB_LAMESUL_F"

    const-string v20, "PAEFEbMS_FULRGS_LB"

    const-string v20, "MELmELUS__FGAERPFS"

    const-string v20, "EGL_SAMPLE_BUFFERS"

    const-string v21, "AE_ToYEEL_SPCRUF"

    const-string v21, "EGL_SURFACE_TYPE"

    const-string v22, "RGYNubP_STNPRE_AEETT"

    const-string v22, "R_PTESu_TLENYENTAPGR"

    const-string v22, "EPN_PLuRSGEY_ETANTTA"

    const-string v22, "EGL_TRANSPARENT_TYPE"

    const-string v23, "RUNTAPVpGDSTEEEER_R_Ap_LA"

    const-string v23, "T_GE_EApRVPEARDNE_TRALSUL"

    const-string v23, "DR_AEENLqSPUETVTA_AR_NGLR"

    const-string v23, "EGL_TRANSPARENT_RED_VALUE"

    const-string v24, "N_sVNATq_EGEUSRTLREARGLAP_N"

    const-string v24, "EPEGAN_Nq_RELASARGNUV_TLRET"

    const-string v24, "LERm_TNGENEE_VNAPTRULA_EARS"

    const-string v24, "EGL_TRANSPARENT_GREEN_VALUE"

    const-string v25, "LEPEoTLNG_UsT_LABR_SNVUAER"

    const-string v25, "NAsL_VATPU_G_UEENLTBRESRAL"

    const-string v25, "VUL_TbRET_BRNAELA_LEASUEPN"

    const-string v25, "EGL_TRANSPARENT_BLUE_VALUE"

    const-string v26, "D_EBBEu_TRNROG_XUTLTEI_"

    const-string v26, "RGTmETB_D_RLU_NIEXETBO_"

    const-string v26, "OXE_UGLpBET_ITTRG_EB_RD"

    const-string v26, "EGL_BIND_TO_TEXTURE_RGB"

    const-string v27, "X_RAEIGoq__BUETTGDR_BEON"

    const-string v27, "O_RXoTTBEDI__ERUN_BGGTAE"

    const-string v27, "__sXROETTEBDAI_BTNELGUG_"

    const-string v27, "EGL_BIND_TO_TEXTURE_RGBA"

    const-string v28, "MP_mAbNIEESNLR_VTAGIL"

    const-string v28, "_ISEPbN__GTLERIAALNMV"

    const-string v28, "SI__oALNNVARWPMEGILET"

    const-string v28, "EGL_MIN_SWAP_INTERVAL"

    const-string v29, "WSENLbA_AE_TMXVR_LIPu"

    const-string v29, "_LPEAAuR_XNVMAL_EITSW"

    const-string v29, "EEGALVuXSAWM_AR_NLTPI"

    const-string v29, "EGL_MAX_SWAP_INTERVAL"

    const-string/jumbo v30, "pIMANLSp__NIZEELCG"

    const-string v30, "EC_LLAEpIZEG_NSNMI"

    const-string v30, "CEAMLIEGqSNNEUZL__"

    const-string v30, "EGL_LUMINANCE_SIZE"

    const-string v31, "AEsH_A_GqLESPM_LIAK"

    const-string v31, "HL_GAP_KqEAASLIZME_"

    const-string v31, "LLAmG_EHSKE_IP_SAAZ"

    const-string v31, "EGL_ALPHA_MASK_SIZE"

    const-string v32, "YsULo___EPETRFLFRBOEC"

    const-string v32, "OPsEFORETLEFR__BYUCL_"

    const-string v32, "OTEYObCLB_RPFFGUER_L_"

    const-string v32, "EGL_COLOR_BUFFER_TYPE"

    const-string v33, "_DLEPTuALREGBEENY_R"

    const-string v33, "E_RmED_BPALENRYGLET"

    const-string v33, "EGL_RENDERABLE_TYPE"

    const-string v34, "COMLONFpG_TNER"

    const-string v34, "EGL_CONFORMANT"

    filled-new-array/range {v2 .. v34}, [Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x1

    new-array v4, v3, [I

    const/4 v5, 0x0

    move v6, v5

    move v6, v5

    move v6, v5

    move v6, v5

    :goto_0
    if-lt v6, v0, :cond_0

    return-void

    :cond_0
    aget v7, v1, v6

    aget-object v8, v2, v6

    move-object/from16 v9, p1

    move-object/from16 v9, p1

    move-object/from16 v9, p1

    move-object/from16 v9, p1

    move-object/from16 v10, p2

    move-object/from16 v10, p2

    move-object/from16 v10, p2

    move-object/from16 v11, p3

    move-object/from16 v11, p3

    move-object/from16 v11, p3

    invoke-interface {v9, v10, v11, v7, v4}, Ljavax/microedition/khronos/egl/EGL10;->eglGetConfigAttrib(Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;I[I)Z

    move-result v7

    if-eqz v7, :cond_1

    const/4 v7, 0x2

    new-array v7, v7, [Ljava/lang/Object;

    aput-object v8, v7, v5

    aget v8, v4, v5

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    aput-object v8, v7, v3

    const-string v8, "/  %:n %qs"

    const-string v8, "  %s: %d\n"

    invoke-static {v8, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "GdsoNerRreTSnL"

    const-string/jumbo v8, "rTRNoLSeeGernd"

    const-string v8, "NTGLESRenderer"

    invoke-static {v8, v7}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_1

    :cond_1
    invoke-interface/range {p1 .. p1}, Ljavax/microedition/khronos/egl/EGL10;->eglGetError()I

    move-result v7

    const/16 v8, 0x3000

    if-ne v7, v8, :cond_1

    :goto_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    nop

    :array_0
    .array-data 4
        0x3020
        0x3021
        0x3022
        0x3023
        0x3024
        0x3025
        0x3026
        0x3027
        0x3028
        0x3029
        0x302a
        0x302b
        0x302c
        0x302d
        0x302e
        0x302f
        0x3030
        0x3031
        0x3032
        0x3033
        0x3034
        0x3037
        0x3036
        0x3035
        0x3039
        0x303a
        0x303b
        0x303c
        0x303d
        0x303e
        0x303f
        0x3040
        0x3042
    .end array-data
.end method

.method private printConfigs(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;[Ljavax/microedition/khronos/egl/EGLConfig;)V
    .locals 9

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    array-length v0, p3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v1, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-array v2, v1, [Ljava/lang/Object;

    const/4 v8, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v4, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    aput-object v3, v2, v4

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string/jumbo v3, "oncmaiusf oigb%nt"

    const-string/jumbo v3, "is%iubfncgrnoato "

    const/4 v8, 0x6

    const-string/jumbo v3, "nn%iosogrdf itaou"

    const-string v3, "%d configurations"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v3, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string v3, "LeESebTdrGrNen"

    const-string v3, "NTGLESRenderer"

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {v3, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    move v2, v4

    move v2, v4

    const/4 v8, 0x1

    move v2, v4

    move v2, v4

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-lt v2, v0, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    return-void

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    new-array v5, v1, [Ljava/lang/Object;

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    aput-object v6, v5, v4

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string/jumbo v6, "nourn/utfndaiu: o%C"

    const-string/jumbo v6, "fnu adun:t%oiin/rCo"

    const/4 v8, 0x1

    const-string v6, "%o:duCnparifin/ng t"

    const-string v6, "Configuration %d:\n"

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v6, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x1

    invoke-static {v3, v5}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    aget-object v5, p3, v2

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct {p0, p1, p2, v5}, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->printConfig(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    goto :goto_0
.end method


# virtual methods
.method public chooseConfig(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;)Ljavax/microedition/khronos/egl/EGLConfig;
    .locals 10

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/4 v0, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    new-array v0, v0, [I

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    sget-object v3, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->s_configAttribs2:[I

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    const/4 v4, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v5, 0x0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-interface/range {v1 .. v6}, Ljavax/microedition/khronos/egl/EGL10;->eglChooseConfig(Ljavax/microedition/khronos/egl/EGLDisplay;[I[Ljavax/microedition/khronos/egl/EGLConfig;I[I)Z

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    const/4 v1, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    aget v5, v0, v1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-lez v5, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    new-array v7, v5, [Ljavax/microedition/khronos/egl/EGLConfig;

    const/4 v9, 0x5

    const/4 v8, 0x5

    sget-object v3, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->s_configAttribs2:[I

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, v7

    move-object v4, v7

    move-object v4, v7

    move-object v4, v7

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-interface/range {v1 .. v6}, Ljavax/microedition/khronos/egl/EGL10;->eglChooseConfig(Ljavax/microedition/khronos/egl/EGLDisplay;[I[Ljavax/microedition/khronos/egl/EGLConfig;I[I)Z

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p0, p1, p2, v7}, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->chooseConfig(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;[Ljavax/microedition/khronos/egl/EGLConfig;)Ljavax/microedition/khronos/egl/EGLConfig;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    return-object p1

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const-string/jumbo p2, "tanipn Nqggoc hf comfoccSpe"

    const-string p2, " pcNohsp icnmoafeggfoncc tS"

    const/4 v9, 0x6

    const-string/jumbo p2, "onsogsioicSm ncffg ate pchc"

    const-string p2, "No configs match configSpec"

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    throw p1
.end method

.method public chooseConfig(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;[Ljavax/microedition/khronos/egl/EGLConfig;)Ljavax/microedition/khronos/egl/EGLConfig;
    .locals 12

    array-length v0, p3

    const/4 v1, 0x0

    :goto_0
    if-lt v1, v0, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    aget-object v8, p3, v1

    const/16 v6, 0x3025

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    invoke-direct/range {v2 .. v7}, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->findConfigAttrib(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;II)I

    move-result v9

    const/16 v6, 0x3026

    invoke-direct/range {v2 .. v7}, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->findConfigAttrib(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;II)I

    move-result v2

    iget v3, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mDepthSize:I

    if-lt v9, v3, :cond_2

    iget v3, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mStencilSize:I

    if-ge v2, v3, :cond_1

    goto :goto_1

    :cond_1
    const/16 v6, 0x3024

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    invoke-direct/range {v2 .. v7}, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->findConfigAttrib(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;II)I

    move-result v9

    const/16 v6, 0x3023

    invoke-direct/range {v2 .. v7}, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->findConfigAttrib(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;II)I

    move-result v10

    const/16 v6, 0x3022

    invoke-direct/range {v2 .. v7}, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->findConfigAttrib(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;II)I

    move-result v11

    const/16 v6, 0x3021

    invoke-direct/range {v2 .. v7}, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->findConfigAttrib(Ljavax/microedition/khronos/egl/EGL10;Ljavax/microedition/khronos/egl/EGLDisplay;Ljavax/microedition/khronos/egl/EGLConfig;II)I

    move-result v2

    iget v3, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mRedSize:I

    if-ne v9, v3, :cond_2

    iget v3, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mGreenSize:I

    if-ne v10, v3, :cond_2

    iget v3, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mBlueSize:I

    if-ne v11, v3, :cond_2

    iget v3, p0, Lcom/videoengine/NTGLESRenderer$ConfigChooser;->mAlphaSize:I

    if-ne v2, v3, :cond_2

    return-object v8

    :cond_2
    :goto_1
    add-int/lit8 v1, v1, 0x1

    goto :goto_0
.end method
