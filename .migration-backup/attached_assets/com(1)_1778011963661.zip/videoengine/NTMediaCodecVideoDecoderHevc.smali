.class public Lcom/videoengine/NTMediaCodecVideoDecoderHevc;
.super Ljava/lang/Object;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "InlinedApi"
    }
.end annotation

.annotation build Landroid/annotation/TargetApi;
    value = 0x10
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/videoengine/NTMediaCodecVideoDecoderHevc$DecoderProperties;,
        Lcom/videoengine/NTMediaCodecVideoDecoderHevc$MediaCodecVideoDecoderErrorCallback;
    }
.end annotation


# static fields
.field private static final COLOR_QCOM_FORMATYUV420PackedSemiPlanar32m:I = 0x7fa30c04

.field private static final COLOR_QCOM_FORMATYVU420PackedSemiPlanar16m4ka:I = 0x7fa30c02

.field private static final COLOR_QCOM_FORMATYVU420PackedSemiPlanar32m4ka:I = 0x7fa30c01

.field private static final COLOR_QCOM_FORMATYVU420PackedSemiPlanar64x32Tile2m8ka:I = 0x7fa30c03

.field private static final DEQUEUE_INPUT_TIMEOUT:I = 0x7a120

.field private static final H265_MIME_TYPE:Ljava/lang/String; = "video/hevc"

.field private static final MAX_DECODE_TIME_MS:J = 0xc8L

.field private static final MEDIA_CODEC_RELEASE_TIMEOUT_MS:I = 0x1388

.field private static final TAG:Ljava/lang/String; = "DNHWDecoderHevc"

.field private static codecErrors:I

.field private static colorMode:I

.field private static errorCallback:Lcom/videoengine/NTMediaCodecVideoDecoderHevc$MediaCodecVideoDecoderErrorCallback;

.field private static hwDecoderDisabledTypes:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static runningInstance:Lcom/videoengine/NTMediaCodecVideoDecoderHevc;

.field private static final supportedColorList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private static final supportedH265HwCodecPrefixes:[Ljava/lang/String;


# instance fields
.field private colorFormat:I

.field private droppedFrames:I

.field private hasDecodedFirstFrame:Z

.field private height:I

.field private inputBuffers:[Ljava/nio/ByteBuffer;

.field private inputByteBuf:Ljava/nio/ByteBuffer;

.field private last_render_ts_:J

.field private mediaCodec:Landroid/media/MediaCodec;

.field private mediaCodecThread:Ljava/lang/Thread;

.field private out_decode_buf:Ljava/nio/ByteBuffer;

.field private outputBuffers:[Ljava/nio/ByteBuffer;

.field private sliceHeight:I

.field private stride:I

.field private surface_:Landroid/view/Surface;

.field private width:I


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    new-instance v0, Ljava/util/HashSet;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->hwDecoderDisabledTypes:Ljava/util/Set;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    const-string v1, "Omso.MX.q"

    const-string v1, "MOsoX.m.q"

    const/4 v10, 0x7

    const-string v1, ".OqmmXMo."

    const-string v1, "OMX.qcom."

    const/4 v10, 0x5

    const-string v2, "MM..oOTK"

    const-string v2, "OMX.MTK."

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-string v3, ".I.tlbOemM"

    const-string v3, ".lMmOtI.eX"

    const-string/jumbo v3, "n.XIOeutl."

    const-string v3, "OMX.Intel."

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-string v4, "Xn..soypEMx"

    const-string v4, ".xMXoOnysE."

    const/4 v10, 0x3

    const-string/jumbo v4, "oMxnO.y.qsX"

    const-string v4, "OMX.Exynos."

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string v5, "XsshibiOM"

    const-string/jumbo v5, "shiXObM.i"

    const/4 v10, 0x4

    const-string/jumbo v5, "sX.mOihiM"

    const-string v5, "OMX.hisi."

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string v6, ".Xrko.O"

    const-string v6, "OMX.rk."

    const/4 v10, 0x0

    const-string v7, "alMuwbinr..eOl"

    const-string/jumbo v7, "lX.aewulOn.Mri"

    const/4 v10, 0x4

    const-string/jumbo v7, "llXineun.MraOw"

    const-string v7, "OMX.allwinner."

    const/4 v9, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-string v8, "M..XpOIp"

    const-string v8, "I.MMX.Op"

    const/4 v10, 0x5

    const-string/jumbo v8, "qMIM.O.G"

    const-string v8, "OMX.IMG."

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    filled-new-array/range {v1 .. v8}, [Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->supportedH265HwCodecPrefixes:[Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/16 v0, 0x8

    const/4 v10, 0x1

    const/4 v9, 0x5

    new-array v0, v0, [Ljava/lang/Integer;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    const/16 v1, 0x13

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/4 v2, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    aput-object v1, v0, v2

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    const/16 v1, 0x15

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    const/4 v2, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    aput-object v1, v0, v2

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    const v1, 0x7fa30c00

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/4 v2, 0x2

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    aput-object v1, v0, v2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    const/16 v1, 0x11

    const/4 v10, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/4 v2, 0x3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    aput-object v1, v0, v2

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    const v1, 0x7fa30c01

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v2, 0x4

    const/4 v9, 0x4

    move v10, v9

    aput-object v1, v0, v2

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    const v1, 0x7fa30c02

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    const/4 v2, 0x5

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    aput-object v1, v0, v2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    const v1, 0x7fa30c03

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/4 v2, 0x6

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    aput-object v1, v0, v2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const v1, 0x7fa30c04

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    aput-object v1, v0, v2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x6

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->supportedColorList:Ljava/util/List;

    const/4 v10, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputByteBuf:Ljava/nio/ByteBuffer;

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->out_decode_buf:Ljava/nio/ByteBuffer;

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    iput-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->surface_:Landroid/view/Surface;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-wide v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->last_render_ts_:J

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method static synthetic access$0(Lcom/videoengine/NTMediaCodecVideoDecoderHevc;)Landroid/media/MediaCodec;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " isM .~f@@dv~~n~~~i@a@lb~o~t ~ o@~~@@@~@b~ /r~~t~  ~  @~-1o/b 4clufsy@ ~ @@@~   ~oS@o@  i@@@o@~m"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method private checkOnMediaCodecThread()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalStateException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/Thread;->getId()J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/Thread;->getId()J

    move-result-wide v2

    const/4 v4, 0x2

    shr-int/2addr v5, v4

    cmp-long v0, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v2, "rpdmvaddeVoe saTcrue NepeeioycenedMdoolq rCot oi"

    const-string v2, "e o MCrrqpNoecdddtne po eyeDsiraddcoieTolaeeVuov"

    const-string v2, "NTMediaCodecVideoDecoder previously operated on "

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const-string v2, "a e ocil l sb nontu ds"

    const-string v2, "cdsa   u tiseonnol l b"

    const/4 v5, 0x6

    const-string v2, "dewiob bola  ctnsl  u "

    const-string v2, " but is now called on "

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v5, 0x2

    throw v0
.end method

.method private dequeueInputBuffer()I
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->checkOnMediaCodecThread()V

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-wide/32 v1, 0x7a120

    const-wide/32 v1, 0x7a120

    const-wide/32 v1, 0x7a120

    const-wide/32 v1, 0x7a120

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {v0, v1, v2}, Landroid/media/MediaCodec;->dequeueInputBuffer(J)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    return v0

    :catch_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v1, "eWNcecuHeDrodHD"

    const-string v1, "drHmceeDWNDceoH"

    const/4 v4, 0x4

    const-string v1, "DdcWHeeproecHNv"

    const-string v1, "DNHWDecoderHevc"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo v2, "ttufaueeqfq fepouBenedIrid"

    const-string v2, "dtfqofuueua eptrIfnBdeieue"

    const/4 v4, 0x3

    const-string/jumbo v2, "uuspeeIlaftfeBertfeud qdui"

    const-string v2, "dequeueIntputBuffer failed"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v0, -0x2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    return v0
.end method

.method public static disableH265HwCodec()V
    .locals 4

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v0, "eHemcrcDbdDoHvW"

    const-string v0, "WHccDbrDdoevHeN"

    const/4 v3, 0x6

    const-string v0, "DcDrodeWHeHeNvo"

    const-string v0, "DNHWDecoderHevc"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo v1, "yanl bdbH2a. id bt di niie.iolcgpesaodcp56"

    const-string v1, "H.265 decoding is disabled by application."

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->hwDecoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v1, "iveduouevc"

    const-string/jumbo v1, "veidvcueoh"

    const-string v1, "ceev/vdpih"

    const-string/jumbo v1, "video/hevc"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method private static findDecoder(Ljava/lang/String;[Ljava/lang/String;)Lcom/videoengine/NTMediaCodecVideoDecoderHevc$DecoderProperties;
    .locals 13

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const-string v1, " oHi peyqi eonernddocmgfdi TtmWrf  "

    const-string v1, " dmeWToprmo fnH e di i gon yrdtecfi"

    const-string v1, " ds o igWnrrietorfyTi   mfeddeomHcn"

    const-string v1, "Trying to find HW decoder for mime "

    const/4 v12, 0x3

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x7

    const-string/jumbo v1, "vdcmceHoDWDreHq"

    const-string v1, "WvcHHeNoqDDdrce"

    const-string v1, "HeecooHNWcervDd"

    const-string v1, "DNHWDecoderHevc"

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x4

    const/4 v0, 0x0

    const/4 v12, 0x2

    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v12, 0x0

    invoke-static {}, Landroid/media/MediaCodecList;->getCodecCount()I

    move-result v3

    const/4 v12, 0x1

    const/4 v4, 0x0

    const/4 v12, 0x3

    if-lt v2, v3, :cond_0

    const/4 v12, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const-string v0, " ef ebNWdHmoosndocrmf d  r iu"

    const-string v0, " dsd eioW  fmN rmncfeooor uHd"

    const-string/jumbo v0, "ifreeouorn modm f c dHe uoNW "

    const-string v0, "No HW decoder found for mime "

    const/4 v12, 0x6

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v12, 0x2

    invoke-static {v1, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x5

    return-object v4

    :cond_0
    :try_start_0
    const/4 v12, 0x6

    invoke-static {v2}, Landroid/media/MediaCodecList;->getCodecInfoAt(I)Landroid/media/MediaCodecInfo;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v12, 0x3

    goto :goto_1

    :catch_0
    move-exception v3

    const/4 v12, 0x3

    const-string/jumbo v5, "rc rndcpedroeeCeatf mceeoto  inivo"

    const-string v5, "afomecee neve i r Cnitdceoordntocr"

    const-string/jumbo v5, "vro cieoqened eetiarnnoCcfcdodre  "

    const-string v5, "Cannot retrieve decoder codec info"

    const/4 v12, 0x3

    invoke-static {v1, v5, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    :goto_1
    const/4 v12, 0x7

    if-eqz v3, :cond_c

    const/4 v12, 0x6

    invoke-virtual {v3}, Landroid/media/MediaCodecInfo;->isEncoder()Z

    move-result v5

    const/4 v12, 0x0

    if-eqz v5, :cond_1

    const/4 v12, 0x0

    goto/16 :goto_a

    :cond_1
    const/4 v12, 0x0

    invoke-virtual {v3}, Landroid/media/MediaCodecInfo;->getSupportedTypes()[Ljava/lang/String;

    move-result-object v5

    const/4 v12, 0x1

    array-length v6, v5

    const/4 v12, 0x6

    move v7, v0

    move v7, v0

    move v7, v0

    move v7, v0

    :goto_2
    const/4 v12, 0x6

    if-lt v7, v6, :cond_2

    :goto_3
    move-object v8, v4

    const/4 v12, 0x7

    goto :goto_4

    :cond_2
    const/4 v12, 0x2

    aget-object v8, v5, v7

    const/4 v12, 0x1

    invoke-virtual {v8, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    const/4 v12, 0x5

    if-eqz v8, :cond_b

    invoke-virtual {v3}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x2

    goto :goto_3

    :goto_4
    const/4 v12, 0x5

    if-nez v8, :cond_3

    const/4 v12, 0x6

    goto/16 :goto_a

    :cond_3
    const/4 v12, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const-string/jumbo v5, "trs adeiadenn oec cdudFd"

    const-string v5, "Found candidate decoder "

    const/4 v12, 0x4

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x3

    invoke-static {v1, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x7

    array-length v9, p1

    const/4 v12, 0x4

    move v4, v0

    move v4, v0

    move v4, v0

    move v4, v0

    :goto_5
    if-lt v4, v9, :cond_4

    const/4 v12, 0x5

    move v4, v0

    move v4, v0

    move v4, v0

    move v4, v0

    const/4 v12, 0x6

    goto :goto_6

    :cond_4
    const/4 v12, 0x4

    aget-object v5, p1, v4

    const/4 v12, 0x4

    invoke-virtual {v8, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    const/4 v12, 0x4

    if-eqz v5, :cond_a

    const/4 v12, 0x1

    const/4 v4, 0x1

    :goto_6
    const/4 v12, 0x3

    if-nez v4, :cond_5

    const/4 v12, 0x7

    goto/16 :goto_a

    :cond_5
    :try_start_1
    const/4 v12, 0x3

    invoke-virtual {v3, p0}, Landroid/media/MediaCodecInfo;->getCapabilitiesForType(Ljava/lang/String;)Landroid/media/MediaCodecInfo$CodecCapabilities;

    move-result-object v3
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v12, 0x0

    iget-object v4, v3, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    const/4 v12, 0x7

    array-length v5, v4

    const/4 v12, 0x4

    move v6, v0

    move v6, v0

    move v6, v0

    move v6, v0

    :goto_7
    const/4 v12, 0x1

    if-lt v6, v5, :cond_9

    const/4 v12, 0x3

    sget-object v4, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->supportedColorList:Ljava/util/List;

    const/4 v12, 0x7

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_8
    const/4 v12, 0x4

    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v12, 0x6

    if-nez v4, :cond_6

    const/4 v12, 0x7

    goto/16 :goto_a

    :cond_6
    const/4 v12, 0x6

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v12, 0x7

    check-cast v4, Ljava/lang/Integer;

    const/4 v12, 0x1

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v9

    const/4 v12, 0x6

    iget-object v10, v3, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    const/4 v12, 0x6

    array-length v11, v10

    const/4 v12, 0x6

    move v4, v0

    move v4, v0

    move v4, v0

    move v4, v0

    :goto_9
    const/4 v12, 0x4

    if-lt v4, v11, :cond_7

    const/4 v12, 0x4

    goto :goto_8

    :cond_7
    const/4 v12, 0x3

    aget v5, v10, v4

    const/4 v12, 0x2

    if-ne v5, v9, :cond_8

    const/4 v12, 0x6

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const-string/jumbo p1, "t gmudaeedt cFro oore"

    const-string/jumbo p1, "gdr orFeecdtouod tae "

    const-string p1, "Found target decoder "

    const/4 v12, 0x7

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x0

    invoke-virtual {p0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const-string p1, "0ob:o olxC "

    const-string/jumbo p1, "l:.Cobo0 x "

    const-string/jumbo p1, "x o:rb oC.l"

    const-string p1, ". Color: 0x"

    const/4 v12, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    invoke-static {v5}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v12, 0x2

    invoke-static {v1, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x5

    new-instance p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc$DecoderProperties;

    const/4 v12, 0x5

    invoke-direct {p0, v8, v5}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc$DecoderProperties;-><init>(Ljava/lang/String;I)V

    const/4 v12, 0x3

    return-object p0

    :cond_8
    const/4 v12, 0x1

    add-int/lit8 v4, v4, 0x1

    const/4 v12, 0x3

    goto :goto_9

    :cond_9
    const/4 v12, 0x3

    aget v7, v4, v6

    new-instance v9, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const-string v10, " Coox u l0 u"

    const-string v10, "C or ou l 0x"

    const-string v10, " o :xrCp 0l "

    const-string v10, "   Color: 0x"

    const/4 v12, 0x2

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x6

    invoke-static {v7}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v7

    const/4 v12, 0x7

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v12, 0x7

    invoke-static {v1, v7}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x2

    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_7

    :catch_1
    move-exception v3

    const/4 v12, 0x0

    const-string/jumbo v4, "li nernbqeecCdo tstdtrepaaaeoiviicep"

    const-string v4, "abtaevspeiidccnlCtaetn piiordr oeee "

    const-string v4, "bestecneetrprsdec iin la rodtaeCivai"

    const-string v4, "Cannot retrieve decoder capabilities"

    const/4 v12, 0x6

    invoke-static {v1, v4, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v12, 0x2

    goto :goto_a

    :cond_a
    const/4 v12, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v12, 0x3

    goto/16 :goto_5

    :cond_b
    const/4 v12, 0x5

    add-int/lit8 v7, v7, 0x1

    const/4 v12, 0x7

    goto/16 :goto_2

    :cond_c
    :goto_a
    const/4 v12, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v12, 0x2

    goto/16 :goto_0
.end method

.method public static isH265HwSupported()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->hwDecoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v1, "q/dmoiceeh"

    const-string/jumbo v1, "hedecvi/qo"

    const/4 v3, 0x0

    const-string/jumbo v1, "odevoe/cih"

    const-string/jumbo v1, "video/hevc"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->supportedH265HwCodecPrefixes:[Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->findDecoder(Ljava/lang/String;[Ljava/lang/String;)Lcom/videoengine/NTMediaCodecVideoDecoderHevc$DecoderProperties;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x2

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public static printStackTrace()V
    .locals 7

    const/4 v6, 0x3

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->runningInstance:Lcom/videoengine/NTMediaCodecVideoDecoderHevc;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    shr-int/2addr v6, v5

    iget-object v0, v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    array-length v1, v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-lez v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string v1, "CrekibTac:N crdesodsVeetDooteaedc csia"

    const-string/jumbo v1, "oasocec :MearkieNdrtdeVTDsdc iCecostae"

    const/4 v6, 0x4

    const-string v1, "NTMediaCodecVideoDecoder stacks trace:"

    const/4 v5, 0x4

    xor-int/2addr v6, v5

    const-string v2, "cHDdvHuecomrDeW"

    const-string v2, "cHDmecvdoeeHWDr"

    const/4 v6, 0x5

    const-string v2, "DovceNDpeHWdrce"

    const-string v2, "DNHWDecoderHevc"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v2, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    array-length v1, v0

    const/4 v5, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-lt v3, v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    goto :goto_1

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    aget-object v4, v0, v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v2, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-void
.end method

.method private reset(II)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string v1, ":esaorevJ ta"

    const/4 v3, 0x3

    const-string v1, " veeaJtrq:as"

    const-string v1, "Java reset: "

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, " x "

    const-string v1, "  x"

    const/4 v3, 0x6

    const-string v1, "  x"

    const-string v1, " x "

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v1, "rNsHeDWcHveboce"

    const-string v1, "eHNevbHcrecoWDD"

    const/4 v3, 0x4

    const-string/jumbo v1, "reomWdveeDNDcHH"

    const-string v1, "DNHWDecoderHevc"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/media/MediaCodec;->flush()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->width:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->height:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-boolean p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->hasDecodedFirstFrame:Z

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->droppedFrames:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string p2, "Incorrect reset call for non-initialized decoder."

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    throw p1
.end method

.method private returnDecodedOutputBuffer(I)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalStateException;,
            Landroid/media/MediaCodec$CodecException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->checkOnMediaCodecThread()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, p1, v1}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method public static setErrorCallback(Lcom/videoengine/NTMediaCodecVideoDecoderHevc$MediaCodecVideoDecoderErrorCallback;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string v0, "NoHHoecedrWDuDv"

    const-string/jumbo v0, "rHedcWuDoecDHNv"

    const/4 v3, 0x2

    const-string/jumbo v0, "vodDWbeHccNrHeD"

    const-string v0, "DNHWDecoderHevc"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string/jumbo v1, "plrta uaebSc okrrc"

    const-string v1, "eebkctap  laorSrrc"

    const/4 v3, 0x7

    const-string/jumbo v1, "kertr rplcalSc eob"

    const-string v1, "Set error callback"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    sput-object p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->errorCallback:Lcom/videoengine/NTMediaCodecVideoDecoderHevc$MediaCodecVideoDecoderErrorCallback;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method public dequeueOutputBuffer(J)Z
    .locals 16

    move-object/from16 v13, p0

    move-object/from16 v13, p0

    move-object/from16 v13, p0

    move-object/from16 v13, p0

    invoke-direct/range {p0 .. p0}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->checkOnMediaCodecThread()V

    iget-object v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->out_decode_buf:Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    new-instance v14, Landroid/media/MediaCodec$BufferInfo;

    invoke-direct {v14}, Landroid/media/MediaCodec$BufferInfo;-><init>()V

    :goto_0
    iget-object v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    invoke-virtual {v0, v14, v1, v2}, Landroid/media/MediaCodec;->dequeueOutputBuffer(Landroid/media/MediaCodec$BufferInfo;J)I

    move-result v15

    const/4 v0, -0x3

    const-string/jumbo v1, "rHWeceqNqDDvdcH"

    const-string/jumbo v1, "vDHDroccqdeeWHN"

    const-string v1, "HDsoDcrveeedcHW"

    const-string v1, "DNHWDecoderHevc"

    if-eq v15, v0, :cond_e

    const/4 v0, -0x2

    const/4 v2, 0x1

    if-eq v15, v0, :cond_4

    const/4 v0, -0x1

    const/4 v1, 0x0

    if-eq v15, v0, :cond_3

    iget-object v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->surface_:Landroid/view/Surface;

    if-eqz v0, :cond_2

    invoke-direct/range {p0 .. p0}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->checkOnMediaCodecThread()V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iget-wide v5, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->last_render_ts_:J

    sub-long v5, v3, v5

    const-wide/16 v7, 0x13

    const-wide/16 v7, 0x13

    const-wide/16 v7, 0x13

    const-wide/16 v7, 0x13

    cmp-long v0, v5, v7

    if-lez v0, :cond_1

    iget-object v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    iget v5, v14, Landroid/media/MediaCodec$BufferInfo;->size:I

    if-eqz v5, :cond_0

    goto :goto_1

    :cond_0
    move v2, v1

    move v2, v1

    :goto_1
    invoke-virtual {v0, v15, v2}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V

    iput-wide v3, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->last_render_ts_:J

    goto :goto_0

    :cond_1
    iget-object v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v0, v15, v1}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V

    goto :goto_0

    :cond_2
    iput-boolean v2, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->hasDecodedFirstFrame:Z

    iget-object v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->outputBuffers:[Ljava/nio/ByteBuffer;

    aget-object v0, v0, v15

    iget v2, v14, Landroid/media/MediaCodec$BufferInfo;->offset:I

    invoke-virtual {v0, v2}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    iget v2, v14, Landroid/media/MediaCodec$BufferInfo;->offset:I

    iget v3, v14, Landroid/media/MediaCodec$BufferInfo;->size:I

    add-int/2addr v2, v3

    invoke-virtual {v0, v2}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    iget-object v2, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->out_decode_buf:Ljava/nio/ByteBuffer;

    invoke-virtual {v2, v0}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    iget-object v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->out_decode_buf:Ljava/nio/ByteBuffer;

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    iget v0, v14, Landroid/media/MediaCodec$BufferInfo;->size:I

    sget v1, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorMode:I

    iget v2, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->width:I

    iget v3, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->height:I

    iget v4, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->sliceHeight:I

    iget v5, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->stride:I

    iget-wide v6, v14, Landroid/media/MediaCodec$BufferInfo;->presentationTimeUs:J

    const-wide/16 v8, 0x3e8

    const-wide/16 v8, 0x3e8

    div-long/2addr v6, v8

    iget-object v8, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->out_decode_buf:Ljava/nio/ByteBuffer;

    int-to-long v9, v0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-wide/from16 v11, p1

    invoke-virtual/range {v0 .. v12}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->executeDecodedData(IIIIIJLjava/nio/ByteBuffer;JJ)V

    invoke-direct {v13, v15}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->returnDecodedOutputBuffer(I)V

    iget-object v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->out_decode_buf:Ljava/nio/ByteBuffer;

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    goto/16 :goto_0

    :cond_3
    return v1

    :cond_4
    iget-object v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->getOutputFormat()Landroid/media/MediaFormat;

    move-result-object v0

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, " eomftesncDo:meg hdcar d"

    const-string/jumbo v4, "rhsdcoefDamn:cda g  eteo"

    const-string/jumbo v4, "ncgtodahofoDr raceem  :e"

    const-string v4, "Decoder format changed: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Landroid/media/MediaFormat;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const-string v3, "bwhdt"

    const-string/jumbo v3, "hwdmt"

    const-string/jumbo v3, "huwit"

    const-string/jumbo v3, "width"

    invoke-virtual {v0, v3}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v4

    const-string/jumbo v5, "hheiog"

    const-string v5, "epgihh"

    const-string/jumbo v5, "height"

    invoke-virtual {v0, v5}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v6

    new-instance v7, Ljava/lang/StringBuilder;

    const-string/jumbo v8, "ocr wDw_q bdhmdr:a cettinfgeo hnae"

    const-string/jumbo v8, "wctribneDod_hdnr: ce d aah wmotgef"

    const-string v8, "desdhd ec_etD:ofrrmahg noewancw i "

    const-string v8, "Decoder format changed: new_width "

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, ":ngmth_uieh, e"

    const-string/jumbo v8, "h,egn utih:e _"

    const-string/jumbo v8, "gh eo nh,w:_it"

    const-string v8, ", new_height: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v1, v7}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iget v7, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->width:I

    if-ne v4, v7, :cond_5

    iget v7, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->height:I

    if-eq v6, v7, :cond_6

    :cond_5
    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, " if .benuasnogCgp zeeirc"

    const-string/jumbo v8, "igi h fpuesgea rCcnnoze."

    const-string/jumbo v8, "iC cs ua .uredgoeifzgneh"

    const-string/jumbo v8, "size change. Configured "

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v8, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->width:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, "*"

    const-string v8, "*"

    const-string v8, "*"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v9, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->height:I

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v9, "qp.wNe"

    const-string/jumbo v9, "w.q Ne"

    const-string v9, " Nqe.w"

    const-string v9, ". New "

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_6
    invoke-virtual {v0, v3}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v3

    iput v3, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->width:I

    invoke-virtual {v0, v5}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v3

    iput v3, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->height:I

    iget v4, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->width:I

    move-wide/from16 v5, p1

    invoke-virtual {v13, v4, v3, v5, v6}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->passResolutionInfo(IIJ)V

    const/4 v3, 0x0

    iput-object v3, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->out_decode_buf:Ljava/nio/ByteBuffer;

    iget v3, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->width:I

    iget v4, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->height:I

    mul-int/2addr v3, v4

    const/4 v4, 0x2

    mul-int/2addr v3, v4

    invoke-static {v3}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v3

    iput-object v3, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->out_decode_buf:Ljava/nio/ByteBuffer;

    const-string/jumbo v3, "t-solrcamsor"

    const-string/jumbo v3, "tlsmfocra-ro"

    const-string/jumbo v3, "olmmrf-otcro"

    const-string v3, "color-format"

    invoke-virtual {v0, v3}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_8

    invoke-virtual {v0, v3}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v3

    iput v3, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorFormat:I

    new-instance v3, Ljava/lang/StringBuilder;

    const-string/jumbo v7, "xormo C:0"

    const-string v7, ":oCmx r0l"

    const-string/jumbo v7, "x o0Cblro"

    const-string v7, "Color: 0x"

    invoke-direct {v3, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v7, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorFormat:I

    invoke-static {v7}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    sget-object v3, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->supportedColorList:Ljava/util/List;

    iget v7, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorFormat:I

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v3, v7}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_8

    iget-object v3, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->surface_:Landroid/view/Surface;

    if-eqz v3, :cond_7

    const-string v3, "atmoocur tiliot.nlsfnoor  "

    const-string/jumbo v3, "ro.toomsfa irtn.l coot nil"

    const-string v3, " flilrmpn otatocn.ro stio."

    const-string/jumbo v3, "not in color format list.."

    invoke-static {v1, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_2

    :cond_7
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Nfoopusnq rmp:ra eor b totdc"

    const-string/jumbo v2, "f:opsb olu oprcr ttdNoamnre "

    const-string v2, "Non supported color format: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v2, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorFormat:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8
    :goto_2
    iget v3, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorFormat:I

    const/16 v7, 0x11

    if-ne v3, v7, :cond_9

    const/4 v2, 0x3

    sput v2, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorMode:I

    goto :goto_3

    :cond_9
    const/16 v7, 0x13

    if-ne v3, v7, :cond_a

    sput v2, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorMode:I

    goto :goto_3

    :cond_a
    const/16 v2, 0x15

    if-ne v3, v2, :cond_b

    sput v4, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorMode:I

    goto :goto_3

    :cond_b
    sput v4, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorMode:I

    :goto_3
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "cosreooMl"

    const-string v3, "colorMode"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget v3, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorMode:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const-string v2, "erumsd"

    const-string/jumbo v2, "uidsre"

    const-string/jumbo v2, "tdrioe"

    const-string/jumbo v2, "stride"

    invoke-virtual {v0, v2}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_c

    invoke-virtual {v0, v2}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v2

    iput v2, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->stride:I

    :cond_c
    const-string v2, "el-cibgihsht"

    const-string/jumbo v2, "slice-height"

    invoke-virtual {v0, v2}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_d

    invoke-virtual {v0, v2}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v0

    iput v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->sliceHeight:I

    :cond_d
    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "hrtie Fp ad emg d te:iaielhrncs"

    const-string v2, "Frame stride and slice height: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v2, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->stride:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " x "

    const-string v2, " x "

    const-string/jumbo v2, "x  "

    const-string v2, " x "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->sliceHeight:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    iget v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->width:I

    iget v1, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->stride:I

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->stride:I

    iget v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->height:I

    iget v1, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->sliceHeight:I

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->sliceHeight:I

    goto/16 :goto_0

    :cond_e
    move-wide/from16 v5, p1

    iget-object v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->getOutputBuffers()[Ljava/nio/ByteBuffer;

    move-result-object v0

    iput-object v0, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->outputBuffers:[Ljava/nio/ByteBuffer;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v2, "gnetfqubsur ecdcroeuh oD:ep  fda"

    const-string/jumbo v2, "oD e gecqdfc uuet ps:rdrbhefuoan"

    const-string/jumbo v2, "np get:peadofe udfDtrhoc ec usub"

    const-string v2, "Decoder output buffers changed: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, v13, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->outputBuffers:[Ljava/nio/ByteBuffer;

    array-length v2, v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    goto/16 :goto_0
.end method

.method public native executeDecodedData(IIIIIJLjava/nio/ByteBuffer;JJ)V
.end method

.method public getInputBuffer(I)Ljava/nio/ByteBuffer;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputByteBuf:Ljava/nio/ByteBuffer;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/high16 v0, 0x10000

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-ge p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputByteBuf:Ljava/nio/ByteBuffer;

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    add-int/lit16 p1, p1, 0x800

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputByteBuf:Ljava/nio/ByteBuffer;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-virtual {v0}, Ljava/nio/Buffer;->capacity()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-ge v0, p1, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    add-int/lit16 p1, p1, 0x800

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputByteBuf:Ljava/nio/ByteBuffer;

    :cond_2
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputByteBuf:Ljava/nio/ByteBuffer;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p1
.end method

.method public initDecode(IILandroid/view/SurfaceView;)Z
    .locals 9

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-nez v0, :cond_5

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v8, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    iput-wide v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->last_render_ts_:J

    const/4 v8, 0x7

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->supportedH265HwCodecPrefixes:[Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v1, "chveivsoqd"

    const-string/jumbo v1, "oiscdhveve"

    const/4 v8, 0x2

    const-string/jumbo v1, "oesvvi/hce"

    const-string/jumbo v1, "video/hevc"

    const/4 v8, 0x4

    invoke-static {v1, v0}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->findDecoder(Ljava/lang/String;[Ljava/lang/String;)Lcom/videoengine/NTMediaCodecVideoDecoderHevc$DecoderProperties;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-eqz v0, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v3, " imm: :d  DcoaveaJni"

    const-string v3, " evm: dD:aaoeinJc i "

    const/4 v8, 0x2

    const-string/jumbo v3, "n  toa:e Jdc ia:oDei"

    const-string v3, "Java initDecode:  : "

    const/4 v7, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v3, " x "

    const-string v3, " x "

    const/4 v8, 0x7

    const-string v3, " x "

    const-string v3, " x "

    const/4 v8, 0x7

    const/4 v7, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string v3, "0o:.lbo Cox"

    const-string/jumbo v3, "o:rxooC0l. "

    const-string/jumbo v3, "r .Coou0x: "

    const-string v3, ". Color: 0x"

    const/4 v7, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget v3, v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc$DecoderProperties;->colorFormat:I

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string/jumbo v3, "orvecWNpHebHDDe"

    const-string v3, "cNorHbeDDecHevW"

    const/4 v8, 0x3

    const-string v3, "DceWHdeeqDNvrcH"

    const-string v3, "DNHWDecoderHevc"

    const/4 v8, 0x7

    const/4 v7, 0x4

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    sput-object p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->runningInstance:Lcom/videoengine/NTMediaCodecVideoDecoderHevc;

    const/4 v8, 0x7

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    iput-object v2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v4, 0x0

    :try_start_0
    const/4 v8, 0x5

    iput p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->width:I

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    iput p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->height:I

    const/4 v8, 0x5

    iput p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->stride:I

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    iput p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->sliceHeight:I

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v5, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    iput-object v5, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->out_decode_buf:Ljava/nio/ByteBuffer;

    const/4 v8, 0x3

    const/4 v7, 0x7

    mul-int v6, p1, p2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    mul-int/lit8 v6, v6, 0x2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {v6}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v6

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    iput-object v6, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->out_decode_buf:Ljava/nio/ByteBuffer;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {v1, p1, p2}, Landroid/media/MediaFormat;->createVideoFormat(Ljava/lang/String;II)Landroid/media/MediaFormat;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-nez p3, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string/jumbo p2, "oosotlcrafm-"

    const-string p2, "aofm-ourloct"

    const/4 v8, 0x7

    const-string p2, "alrmtofcm-or"

    const-string p2, "color-format"

    const/4 v8, 0x4

    iget v1, v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc$DecoderProperties;->colorFormat:I

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {p1, p2, v1}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v1, "  mFooap: "

    const-string v1, " :otF mpa "

    const/4 v8, 0x0

    const-string v1, "  Format: "

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {v3, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v1, ":pat.bseFomeolroqoripcr"

    const-string/jumbo v1, "tropsolaqiperoe.:oFmrcr"

    const/4 v8, 0x7

    const-string v1, "etF.otuarrr:oiorespolcp"

    const-string/jumbo v1, "properties.colorFormat:"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget v1, v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc$DecoderProperties;->colorFormat:I

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x4

    invoke-static {v3, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x1

    iget-object p2, v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc$DecoderProperties;->codecName:Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {p2}, Landroid/media/MediaCodec;->createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x4

    iput-object p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-nez p2, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    const-string p1, " cen msprdodn e otetaadeCrci"

    const-string p1, "eisnco eCoctadd  ertad eermn"

    const/4 v8, 0x2

    const-string p1, "eeadteCtq nacneaicem  drd or"

    const-string p1, "Can not create media decoder"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    return v4

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz p3, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p3}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eqz p2, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-interface {p2}, Landroid/view/SurfaceHolder;->getSurface()Landroid/view/Surface;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    iput-object p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->surface_:Landroid/view/Surface;

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->surface_:Landroid/view/Surface;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-eqz p2, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x4

    iget-object p3, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p3, p1, p2, v5, v4}, Landroid/media/MediaCodec;->configure(Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto :goto_0

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-object p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x4

    const/4 v7, 0x3

    invoke-virtual {p2, p1, v5, v5, v4}, Landroid/media/MediaCodec;->configure(Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    iget-object p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p1}, Landroid/media/MediaCodec;->start()V

    const/4 v8, 0x1

    iget p1, v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc$DecoderProperties;->colorFormat:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    iput p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->colorFormat:I

    const/4 v8, 0x3

    iget-object p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p1}, Landroid/media/MediaCodec;->getOutputBuffers()[Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    iput-object p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->outputBuffers:[Ljava/nio/ByteBuffer;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-object p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p1}, Landroid/media/MediaCodec;->getInputBuffers()[Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    iput-object p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputBuffers:[Ljava/nio/ByteBuffer;

    const/4 v8, 0x5

    const/4 v7, 0x1

    iput-boolean v4, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->hasDecodedFirstFrame:Z

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    iput v4, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->droppedFrames:I

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string/jumbo p2, "eusr:mI bpf fsu"

    const-string p2, " nbmfpe s:urufI"

    const/4 v8, 0x4

    const-string/jumbo p2, "nremIf:fu  spub"

    const-string p2, "Input buffers: "

    const/4 v8, 0x6

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    move v8, v7

    iget-object p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputBuffers:[Ljava/nio/ByteBuffer;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    array-length p2, p2

    const/4 v8, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string/jumbo p2, "fs.eo:tutOpbo fruu"

    const-string/jumbo p2, "pbffoutuut:Oe.r  s"

    const/4 v8, 0x1

    const-string p2, "O bu:brpeu stu. ft"

    const-string p2, ". Output buffers: "

    const/4 v8, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget-object p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->outputBuffers:[Ljava/nio/ByteBuffer;

    const/4 v8, 0x6

    array-length p2, p2

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {v3, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    return v2

    :catch_0
    move-exception p1

    const/4 v8, 0x6

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    return v2

    :catch_1
    move-exception p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string p2, " bilDfuiotdincede"

    const-string/jumbo p2, "iDoeebdiitlefdnc "

    const/4 v8, 0x4

    const-string/jumbo p2, "initDecode failed"

    const/4 v8, 0x6

    invoke-static {v3, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    return v4

    :cond_4
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string p2, "d  6o2Wpan  oCH5c.ied ntredf..nHfo"

    const-string p2, "Cannot find HW decoder for H.265.."

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    throw p1

    :cond_5
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-string/jumbo p2, "r rt aoeq)eons?eDo(doiue e:Ftigl"

    const-string/jumbo p2, "oac:d utoDinFoetoee?ei r)re slg("

    const/4 v8, 0x0

    const-string/jumbo p2, "gesoFDtiodnc tioo(e?)esrr e: ael"

    const-string/jumbo p2, "initDecode: Forgot to release()?"

    const/4 v8, 0x0

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    throw p1
.end method

.method public onEncodedData(IIJJ)Z
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-direct {p0}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->checkOnMediaCodecThread()V

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {p0}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->dequeueInputBuffer()I

    move-result v1

    const/4 v8, 0x5

    if-ltz v1, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputBuffers:[Ljava/nio/ByteBuffer;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    aget-object p2, p2, v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object p5, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputByteBuf:Ljava/nio/ByteBuffer;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p5}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-object p5, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputByteBuf:Ljava/nio/ByteBuffer;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {p5, p1}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object p5, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->inputByteBuf:Ljava/nio/ByteBuffer;

    const/4 v8, 0x3

    const/4 v7, 0x1

    invoke-virtual {p2, p5}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    const/4 v7, 0x5

    move v8, v7

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-wide/16 p5, 0x3e8

    const-wide/16 p5, 0x3e8

    const-wide/16 p5, 0x3e8

    const-wide/16 p5, 0x3e8

    const/4 v8, 0x1

    mul-long v4, p3, p5

    const/4 v8, 0x7

    const/4 v6, 0x7

    const/4 v8, 0x1

    const/4 v6, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    move v3, p1

    move v3, p1

    const/4 v8, 0x7

    move v3, p1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual/range {v0 .. v6}, Landroid/media/MediaCodec;->queueInputBuffer(IIIJI)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/4 p1, 0x1

    const/4 v7, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    return p1

    :catch_0
    move-exception p1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string p2, "eDvmWpdHrDcHcee"

    const-string p2, "deeNcHWprDHvDec"

    const/4 v8, 0x1

    const-string p2, "coDdoeHrWevecHN"

    const-string p2, "DNHWDecoderHevc"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string/jumbo p3, "focfdb eaqlnedfeeri"

    const-string/jumbo p3, "ndeB eaeqrfidcfefol"

    const-string p3, "encodeBuffer failed"

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {p2, p3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 p1, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    return p1
.end method

.method public native passResolutionInfo(IIJ)V
.end method

.method public release()V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo v1, "me e aue arddoemfl .eoaocprrr Tabed uopea: estsJsnfDl"

    const-string v1, "aes le eatevorb :afaderu foeo lnp.T acsemJDoddps rrme"

    const/4 v6, 0x3

    const-string/jumbo v1, "sasrandp e  adTodeefl  o ca.eJreDlro treoemupm:evpafb"

    const-string v1, "Java releaseDecoder. Total number of dropped frames: "

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget v1, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->droppedFrames:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string/jumbo v1, "mcrNDvecqeeHdoD"

    const-string v1, "dDemHeDNecHcovr"

    const/4 v6, 0x3

    const-string v1, "desveNceDWDoHHc"

    const-string v1, "DNHWDecoderHevc"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->checkOnMediaCodecThread()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-direct {v0, v2}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v5, 0x5

    move v6, v5

    new-instance v3, Lcom/videoengine/NTMediaCodecVideoDecoderHevc$1;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v3, p0, v0}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc$1;-><init>(Lcom/videoengine/NTMediaCodecVideoDecoderHevc;Ljava/util/concurrent/CountDownLatch;)V

    const/4 v5, 0x1

    move v6, v5

    new-instance v4, Ljava/lang/Thread;

    const/4 v6, 0x6

    invoke-direct {v4, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v4}, Ljava/lang/Thread;->start()V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-wide/16 v3, 0x1388

    const-wide/16 v3, 0x1388

    const/4 v6, 0x0

    const-wide/16 v3, 0x1388

    const-wide/16 v3, 0x1388

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0, v3, v4}, Lcom/ntjbase/NTThreadUtils;->awaitUninterruptibly(Ljava/util/concurrent/CountDownLatch;J)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-nez v0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string/jumbo v0, "oe mealudreortieeis edt Maced"

    const-string v0, "Media decoder release timeout"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    sget v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->codecErrors:I

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    add-int/2addr v0, v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    sput v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->codecErrors:I

    const/4 v5, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->errorCallback:Lcom/videoengine/NTMediaCodecVideoDecoderHevc$MediaCodecVideoDecoderErrorCallback;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const-string/jumbo v2, "evaaorkeolrbclck ooceor orr nE:r  cds"

    const-string/jumbo v2, "rosaoorlaecr cr evbE lko.eoncc rkdr: "

    const/4 v6, 0x3

    const-string v2, "crbvnbcorarr ee: r ok.coEorslld aI ck"

    const-string v2, "Invoke codec error callback. Errors: "

    const/4 v5, 0x4

    move v6, v5

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    sget v2, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->codecErrors:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    sget-object v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->errorCallback:Lcom/videoengine/NTMediaCodecVideoDecoderHevc$MediaCodecVideoDecoderErrorCallback;

    const/4 v6, 0x3

    sget v2, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->codecErrors:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v0, v2}, Lcom/videoengine/NTMediaCodecVideoDecoderHevc$MediaCodecVideoDecoderErrorCallback;->onMediaCodecVideoDecoderCriticalError(I)V

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    iput-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    sput-object v0, Lcom/videoengine/NTMediaCodecVideoDecoderHevc;->runningInstance:Lcom/videoengine/NTMediaCodecVideoDecoderHevc;

    const/4 v5, 0x4

    shr-int/2addr v6, v5

    const-string v0, "eleorbudan DoaeseeJd vca"

    const-string v0, "edDrebaceeld vo eoJsneaa"

    const/4 v6, 0x7

    const-string v0, "Deealcep neJarrad vsoode"

    const-string v0, "Java releaseDecoder done"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-void
.end method
