.class Lcom/videoengine/NTMediaCodecVideoEncoderHevc$MediaCodecProperties;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/videoengine/NTMediaCodecVideoEncoderHevc;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "MediaCodecProperties"
.end annotation


# instance fields
.field public final bitrateAdjustmentType:Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

.field public final codecPrefix:Ljava/lang/String;

.field public final minSdk:I


# direct methods
.method constructor <init>(Ljava/lang/String;ILcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$MediaCodecProperties;->codecPrefix:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x7

    iput p2, p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$MediaCodecProperties;->minSdk:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$MediaCodecProperties;->bitrateAdjustmentType:Lcom/videoengine/NTMediaCodecVideoEncoderHevc$BitrateAdjustmentType;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method
