.class Lcom/videoengine/NTMediaCodecVideoEncoder$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/videoengine/NTMediaCodecVideoEncoder;->release()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/videoengine/NTMediaCodecVideoEncoder;

.field private final synthetic val$releaseDone:Ljava/util/concurrent/CountDownLatch;


# direct methods
.method constructor <init>(Lcom/videoengine/NTMediaCodecVideoEncoder;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoder;

    const/4 v1, 0x7

    const/4 v0, 0x0

    iput-object p2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder$1;->val$releaseDone:Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "d s@oc@ M~~o~lv @@@ @m~~~yn/i~~K4@ ~  f~~s~o  /aiuS~b@-@~@@ l ~1.~@@bi r@b~@ t f~@ o~@~t@~o@ @ o"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x4

    const-string v0, "aesesreCl-mideoac.de"

    const/4 v7, 0x0

    const-string v0, "aedmem-sdli.eoeae-rC"

    const-string/jumbo v0, "mediaCodec.release--"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const-string v1, "aeemd  dieenli cMrledrefasoa"

    const/4 v7, 0x3

    const-string v1, "ciedoeM aldirle aoeer eeadnf"

    const-string v1, "Media encoder release failed"

    const/4 v7, 0x4

    const-string v2, "a+o+sb.eeoCeerdidamc"

    const-string v2, "ere+o+laiemedoacC.sd"

    const-string/jumbo v2, "ima.e+uedoadrceleC+e"

    const-string/jumbo v2, "mediaCodec.release++"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v3, "NedinEMpeordoTiabedoCdcV"

    const-string/jumbo v3, "ideirbCaeNMcoodTndVeoEcd"

    const/4 v7, 0x3

    const-string v3, "dMeNdoeeqnTaooircdcVCeiE"

    const-string v3, "NTMediaCodecVideoEncoder"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/videoengine/NTMediaCodecVideoEncoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v4}, Lcom/videoengine/NTMediaCodecVideoEncoder;->access$0(Lcom/videoengine/NTMediaCodecVideoEncoder;)Landroid/media/MediaCodec;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz v4, :cond_0

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string/jumbo v4, "muse.cas+oeo+dpdi"

    const-string/jumbo v4, "i.amdcuodsoe+etp+"

    const/4 v7, 0x3

    const-string v4, "acCm.tpisdom+odee"

    const-string/jumbo v4, "mediaCodec.stop++"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {v3, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    and-int/2addr v7, v6

    iget-object v4, p0, Lcom/videoengine/NTMediaCodecVideoEncoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoder;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v4}, Lcom/videoengine/NTMediaCodecVideoEncoder;->access$0(Lcom/videoengine/NTMediaCodecVideoEncoder;)Landroid/media/MediaCodec;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v4}, Landroid/media/MediaCodec;->stop()V

    const-string v4, "doo-oe.p-etasmicp"

    const-string v4, "dms.ap-pdoeceio-t"

    const/4 v7, 0x0

    const-string v4, "cdmCtb.d-i-espoeo"

    const-string/jumbo v4, "mediaCodec.stop--"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v3, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x7

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoder;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v2}, Lcom/videoengine/NTMediaCodecVideoEncoder;->access$0(Lcom/videoengine/NTMediaCodecVideoEncoder;)Landroid/media/MediaCodec;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v2}, Landroid/media/MediaCodec;->release()V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_2

    :catchall_0
    move-exception v4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto :goto_0

    :catch_0
    move-exception v4

    :try_start_2
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-string v5, "Me lefuadcrooddnesetp iqi"

    const-string/jumbo v5, "pces oiaqdM defnlireaedto"

    const/4 v7, 0x2

    const-string v5, "dndslatpoarfpce d ieiMeoe"

    const-string v5, "Media encoder stop failed"

    const/4 v7, 0x7

    const/4 v6, 0x1

    invoke-static {v3, v5, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v2}, Lcom/videoengine/NTMediaCodecVideoEncoder;->access$0(Lcom/videoengine/NTMediaCodecVideoEncoder;)Landroid/media/MediaCodec;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v2}, Landroid/media/MediaCodec;->release()V

    const/4 v7, 0x1

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_2

    :catch_1
    move-exception v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v3, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_2

    :goto_0
    :try_start_4
    const/4 v7, 0x7

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoder;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v2}, Lcom/videoengine/NTMediaCodecVideoEncoder;->access$0(Lcom/videoengine/NTMediaCodecVideoEncoder;)Landroid/media/MediaCodec;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v2}, Landroid/media/MediaCodec;->release()V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_1

    :catch_2
    move-exception v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {v3, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    throw v4

    :cond_0
    :goto_2
    const/4 v7, 0x2

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoder$1;->val$releaseDone:Ljava/util/concurrent/CountDownLatch;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    return-void
.end method
