.class public Lcom/videoengine/NTRenderer;
.super Ljava/lang/Object;


# static fields
.field private static TAG:Ljava/lang/String; = "ViERenderer"


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public static CreateRenderer(Landroid/content/Context;)Landroid/view/SurfaceView;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ys~ sKro~@ i~l~~buo~ ~n bm  @@@~~@M~.~@o @ @@~~ tb~@~l~@@f~@ / -dcoo~~  S/@i1@  @@a@~4 ~~ t@fiv"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/videoengine/NTRenderer;->CreateRenderer(Landroid/content/Context;Z)Landroid/view/SurfaceView;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method public static CreateRenderer(Landroid/content/Context;Z)Landroid/view/SurfaceView;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/videoengine/NTGLESRenderer;->IsSupported(Landroid/content/Context;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object p1, Lcom/videoengine/NTRenderer;->TAG:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const-string/jumbo v0, "trsdS0Lnp uEpdASGo..i 2o"

    const/4 v2, 0x5

    const-string v0, " tdm. ooSpndSurLAr2Ep.G0"

    const-string v0, "Support Android GLES20.."

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance p1, Lcom/videoengine/NTGLESRenderer;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p1, p0}, Lcom/videoengine/NTGLESRenderer;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object p1, Lcom/videoengine/NTRenderer;->TAG:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string v0, ".rvUoecawaiSei ftemV es."

    const-string v0, ".e mfeeVi.cUnivesraSwa t"

    const-string v0, "Use native SurfaceView.."

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance p1, Landroid/view/SurfaceView;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p1, p0}, Landroid/view/SurfaceView;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p1
.end method
