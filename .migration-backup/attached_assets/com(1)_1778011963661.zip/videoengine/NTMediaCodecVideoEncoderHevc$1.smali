.class Lcom/videoengine/NTMediaCodecVideoEncoderHevc$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/videoengine/NTMediaCodecVideoEncoderHevc;->release()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/videoengine/NTMediaCodecVideoEncoderHevc;

.field private final synthetic val$releaseDone:Ljava/util/concurrent/CountDownLatch;


# direct methods
.method constructor <init>(Lcom/videoengine/NTMediaCodecVideoEncoderHevc;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoderHevc;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$1;->val$releaseDone:Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " oso4@t  ~~ o @~~.@~if  @~~~ @  @M@@@~b/~1~cuor-~ ~ fba@ K@blio~l~@@@@d~~ tvn@ iy~~@@ /~@ ~osm~@"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x2

    const-string v0, "doem.ersseed-aimael-"

    const-string v0, "e-seoCdse.aemla-erdi"

    const/4 v7, 0x6

    const-string/jumbo v0, "i-deo.lcaseoCdr-eeam"

    const-string/jumbo v0, "mediaCodec.release--"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string/jumbo v1, "rleaab eoaem Mlrced eeidnefd"

    const-string v1, "dlsm aeeedae d elcafrreMnoei"

    const-string v1, "eMeeerulcrldi i a anofsedeae"

    const-string v1, "Media encoder release failed"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string v2, "eiC.edrpe++oleceaodm"

    const-string v2, "+seaoem.eeoCld+rdice"

    const/4 v7, 0x1

    const-string v2, "+die+rmCq.eesdloaeca"

    const-string/jumbo v2, "mediaCodec.release++"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string v3, "MdsVceocdroiNebcediCaovHETed"

    const-string v3, "MnoeebEHaccideeNoddTvcVCiord"

    const/4 v7, 0x4

    const-string v3, "edemoHcMEcVcarooidnvCddiTNee"

    const-string v3, "NTMediaCodecVideoEncoderHevc"

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v4, p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoderHevc;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v4}, Lcom/videoengine/NTMediaCodecVideoEncoderHevc;->access$0(Lcom/videoengine/NTMediaCodecVideoEncoderHevc;)Landroid/media/MediaCodec;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v4, :cond_0

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string/jumbo v4, "ise+ooaptmuoC+cd."

    const-string v4, "c+oad.ue+tesmpiCo"

    const/4 v7, 0x1

    const-string/jumbo v4, "om+oibce+.tepaddC"

    const-string/jumbo v4, "mediaCodec.stop++"

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v3, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x5

    iget-object v4, p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoderHevc;

    const/4 v7, 0x7

    const/4 v6, 0x3

    invoke-static {v4}, Lcom/videoengine/NTMediaCodecVideoEncoderHevc;->access$0(Lcom/videoengine/NTMediaCodecVideoEncoderHevc;)Landroid/media/MediaCodec;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v4}, Landroid/media/MediaCodec;->stop()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string/jumbo v4, "poma-ou.etcCspie-"

    const-string v4, "atc.pmoposdCeei--"

    const/4 v7, 0x4

    const-string v4, "cCtam-opeo.eisddp"

    const-string/jumbo v4, "mediaCodec.stop--"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v3, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoderHevc;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v2}, Lcom/videoengine/NTMediaCodecVideoEncoderHevc;->access$0(Lcom/videoengine/NTMediaCodecVideoEncoderHevc;)Landroid/media/MediaCodec;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v2}, Landroid/media/MediaCodec;->release()V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_2

    :catchall_0
    move-exception v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_0

    :catch_0
    move-exception v4

    :try_start_2
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v5, "d aeMaeeqlipcsfnirdotqoe "

    const-string v5, "d astdeMqoanif leropideec"

    const/4 v7, 0x6

    const-string v5, "aoslMres dpiidtdfe ac one"

    const-string v5, "Media encoder stop failed"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {v3, v5, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoderHevc;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v2}, Lcom/videoengine/NTMediaCodecVideoEncoderHevc;->access$0(Lcom/videoengine/NTMediaCodecVideoEncoderHevc;)Landroid/media/MediaCodec;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v2}, Landroid/media/MediaCodec;->release()V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto :goto_2

    :catch_1
    move-exception v0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {v3, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_2

    :goto_0
    :try_start_4
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    shl-int/2addr v7, v6

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$1;->this$0:Lcom/videoengine/NTMediaCodecVideoEncoderHevc;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v2}, Lcom/videoengine/NTMediaCodecVideoEncoderHevc;->access$0(Lcom/videoengine/NTMediaCodecVideoEncoderHevc;)Landroid/media/MediaCodec;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v2}, Landroid/media/MediaCodec;->release()V

    const/4 v7, 0x2

    const/4 v6, 0x3

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    const/4 v6, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto :goto_1

    :catch_2
    move-exception v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v3, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    throw v4

    :cond_0
    :goto_2
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoEncoderHevc$1;->val$releaseDone:Ljava/util/concurrent/CountDownLatch;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    return-void
.end method
