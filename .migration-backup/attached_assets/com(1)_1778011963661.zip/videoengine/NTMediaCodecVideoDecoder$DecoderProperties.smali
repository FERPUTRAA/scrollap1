.class Lcom/videoengine/NTMediaCodecVideoDecoder$DecoderProperties;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/videoengine/NTMediaCodecVideoDecoder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "DecoderProperties"
.end annotation


# instance fields
.field public final codecName:Ljava/lang/String;

.field public final colorFormat:I


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoder$DecoderProperties;->codecName:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoder$DecoderProperties;->colorFormat:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method
