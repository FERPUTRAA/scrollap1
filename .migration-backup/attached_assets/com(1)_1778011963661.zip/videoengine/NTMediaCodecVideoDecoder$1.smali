.class Lcom/videoengine/NTMediaCodecVideoDecoder$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/videoengine/NTMediaCodecVideoDecoder;->release()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/videoengine/NTMediaCodecVideoDecoder;

.field private final synthetic val$releaseDone:Ljava/util/concurrent/CountDownLatch;


# direct methods
.method constructor <init>(Lcom/videoengine/NTMediaCodecVideoDecoder;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/videoengine/NTMediaCodecVideoDecoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoDecoder;

    const/4 v1, 0x0

    const/4 v0, 0x0

    iput-object p2, p0, Lcom/videoengine/NTMediaCodecVideoDecoder$1;->val$releaseDone:Ljava/util/concurrent/CountDownLatch;

    const/4 v0, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@ns~~ ~~K i @o~l@~@Mt@@@@/bc1 ~~~~@~@~rom  tib~o@ @~-y @~u d@f/~~ v ai~~~l @4@@s@f @@b o~Soo  . "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x5

    const-string/jumbo v0, "mC.molecsdsieaee-red"

    const-string v0, "eislcasm-edaeeo.edCr"

    const/4 v7, 0x3

    const-string v0, "de-ooemaCcar.-eidsle"

    const-string/jumbo v0, "mediaCodec.release--"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const-string v1, " rmadbsoedaMlceefriieeadee l"

    const-string v1, "ceima eideMsraleleaerod fde "

    const-string v1, "a dsefueordMe rldae ieaecide"

    const-string v1, "Media decoder release failed"

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string/jumbo v2, "iaeCorcps+dlmdae.ee+"

    const-string v2, "e.ecoCdlmaae+ioes+dr"

    const/4 v7, 0x7

    const-string v2, "+eedsl+Cqemedeaio.ra"

    const-string/jumbo v2, "mediaCodec.release++"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-string v3, "DrseeHdbcND"

    const-string v3, "DercHbNdoeD"

    const/4 v7, 0x6

    const-string v3, "edDmDHWocer"

    const-string v3, "DNHWDecoder"

    const/4 v6, 0x6

    move v7, v6

    iget-object v4, p0, Lcom/videoengine/NTMediaCodecVideoDecoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoDecoder;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {v4}, Lcom/videoengine/NTMediaCodecVideoDecoder;->access$0(Lcom/videoengine/NTMediaCodecVideoDecoder;)Landroid/media/MediaCodec;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v4, :cond_0

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string/jumbo v4, "ipoao.dse+eCcomud"

    const-string v4, "codpa.umdC+e+ioes"

    const/4 v7, 0x0

    const-string v4, "++Cm.bpasotcdodee"

    const-string/jumbo v4, "mediaCodec.stop++"

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v3, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v4, p0, Lcom/videoengine/NTMediaCodecVideoDecoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoDecoder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {v4}, Lcom/videoengine/NTMediaCodecVideoDecoder;->access$0(Lcom/videoengine/NTMediaCodecVideoDecoder;)Landroid/media/MediaCodec;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v4}, Landroid/media/MediaCodec;->stop()V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string v4, "ep-dCpustc.moiod-"

    const-string v4, ".omoedtpp-iecs-Cd"

    const/4 v7, 0x5

    const-string v4, "aotd-ispdmoCcpe-e"

    const-string/jumbo v4, "mediaCodec.stop--"

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v3, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v6, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoDecoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoDecoder;

    const/4 v7, 0x3

    const/4 v6, 0x1

    invoke-static {v2}, Lcom/videoengine/NTMediaCodecVideoDecoder;->access$0(Lcom/videoengine/NTMediaCodecVideoDecoder;)Landroid/media/MediaCodec;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v2}, Landroid/media/MediaCodec;->release()V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    goto :goto_2

    :catchall_0
    move-exception v4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_0

    :catch_0
    move-exception v4

    :try_start_2
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string/jumbo v5, "fieod qlq c dpedirtdaoaeM"

    const-string/jumbo v5, "oe  daoaqpelsdMdie citrfd"

    const/4 v7, 0x4

    const-string/jumbo v5, "pistiddedcesaafM  dole or"

    const-string v5, "Media decoder stop failed"

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v3, v5, v4}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoDecoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoDecoder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v2}, Lcom/videoengine/NTMediaCodecVideoDecoder;->access$0(Lcom/videoengine/NTMediaCodecVideoDecoder;)Landroid/media/MediaCodec;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v2}, Landroid/media/MediaCodec;->release()V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    const/4 v7, 0x4

    goto :goto_2

    :catch_1
    move-exception v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v3, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_2

    :goto_0
    :try_start_4
    const/4 v7, 0x3

    invoke-static {v3, v2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/videoengine/NTMediaCodecVideoDecoder$1;->this$0:Lcom/videoengine/NTMediaCodecVideoDecoder;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v2}, Lcom/videoengine/NTMediaCodecVideoDecoder;->access$0(Lcom/videoengine/NTMediaCodecVideoDecoder;)Landroid/media/MediaCodec;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v2}, Landroid/media/MediaCodec;->release()V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto :goto_1

    :catch_2
    move-exception v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v3, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    throw v4

    :cond_0
    :goto_2
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/videoengine/NTMediaCodecVideoDecoder$1;->val$releaseDone:Ljava/util/concurrent/CountDownLatch;

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-void
.end method
