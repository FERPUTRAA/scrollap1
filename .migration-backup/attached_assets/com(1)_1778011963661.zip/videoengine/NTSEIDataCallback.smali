.class public interface abstract Lcom/videoengine/NTSEIDataCallback;
.super Ljava/lang/Object;


# virtual methods
.method public abstract getSEIDataByteBuffer(I)Ljava/nio/ByteBuffer;
.end method

.method public abstract onSEIDataCallback(IIJJJ)V
.end method
