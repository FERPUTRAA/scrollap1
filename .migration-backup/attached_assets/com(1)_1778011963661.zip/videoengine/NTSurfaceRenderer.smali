.class public Lcom/videoengine/NTSurfaceRenderer;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/SurfaceHolder$Callback;


# static fields
.field private static final TAG:Ljava/lang/String; = "ViESurfaceRenderer"


# instance fields
.field private bitmap:Landroid/graphics/Bitmap;

.field private byteBuffer:Ljava/nio/ByteBuffer;

.field private dstBottomScale:F

.field private dstLeftScale:F

.field private dstRect:Landroid/graphics/Rect;

.field private dstRightScale:F

.field private dstTopScale:F

.field private srcRect:Landroid/graphics/Rect;

.field private surfaceHolder:Landroid/view/SurfaceHolder;

.field private video_height:I

.field private video_width:I


# direct methods
.method public constructor <init>(Landroid/view/SurfaceView;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Landroid/graphics/Rect;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->srcRect:Landroid/graphics/Rect;

    const/4 v3, 0x6

    new-instance v0, Landroid/graphics/Rect;

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRect:Landroid/graphics/Rect;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x3

    iput v0, p0, Lcom/videoengine/NTSurfaceRenderer;->dstTopScale:F

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput v1, p0, Lcom/videoengine/NTSurfaceRenderer;->dstBottomScale:F

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput v0, p0, Lcom/videoengine/NTSurfaceRenderer;->dstLeftScale:F

    const/4 v3, 0x7

    iput v1, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRightScale:F

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput v0, p0, Lcom/videoengine/NTSurfaceRenderer;->video_width:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput v0, p0, Lcom/videoengine/NTSurfaceRenderer;->video_height:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/view/SurfaceView;->getHolder()Landroid/view/SurfaceHolder;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/videoengine/NTSurfaceRenderer;->surfaceHolder:Landroid/view/SurfaceHolder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string p1, "eEsuReeericaSVdnrs"

    const-string/jumbo p1, "risVnaReuecdeeErSr"

    const/4 v3, 0x4

    const-string/jumbo p1, "riSmdeVreuerfncaRE"

    const-string p1, "ViESurfaceRenderer"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string/jumbo v0, "w l oheRmlsrrr,f.uNcSetTidcaeoendfarHuenu .e"

    const-string v0, "e HmTrurlSe.aewfdierRunertrdufhcs oNea, nc.l"

    const/4 v3, 0x0

    const-string v0, "NTSurfaceRenderer, surfaceHolder with null.."

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {p1, p0}, Landroid/view/SurfaceHolder;->addCallback(Landroid/view/SurfaceHolder$Callback;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/videoengine/NTSurfaceRenderer;->surfaceHolder:Landroid/view/SurfaceHolder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/videoengine/NTSurfaceRenderer;->surfaceCreated(Landroid/view/SurfaceHolder;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method private changeDestRect(II)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~@ m b@@ @~@if@ /~@i~@b@@@~ b@o~aMfv4~@~~~@~ y  o~u/cK b ~S@oonrt~~ io- .~~l  @  s~o@~ 1@l@@~d~t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRect:Landroid/graphics/Rect;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v1, v0, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x4

    int-to-float v1, v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget v2, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRightScale:F

    const/4 v4, 0x4

    int-to-float p1, p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    mul-float/2addr v2, p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    add-float/2addr v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    float-to-int p1, v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput p1, v0, Landroid/graphics/Rect;->right:I

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget p1, v0, Landroid/graphics/Rect;->top:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    int-to-float p1, p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v1, p0, Lcom/videoengine/NTSurfaceRenderer;->dstBottomScale:F

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    int-to-float p2, p2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    mul-float/2addr v1, p2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    add-float/2addr p1, v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    float-to-int p1, p1

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput p1, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-void
.end method

.method private saveBitmapToJPEG(II)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance p1, Ljava/io/ByteArrayOutputStream;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {p1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x7

    iget-object p2, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v5, 0x2

    sget-object v0, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/16 v1, 0x64

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {p2, v0, v1, p1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance p2, Ljava/io/FileOutputStream;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string v0, "e_drnru/gsr/cd.jpddea"

    const-string v0, "/sdcard/render_%d.jpg"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    aput-object v2, v1, v3

    const/4 v5, 0x5

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {p2, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p2, p1}, Ljava/io/FileOutputStream;->write([B)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p2}, Ljava/io/OutputStream;->flush()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/io/FileOutputStream;->close()V
    :try_end_0
    .catch Ljava/io/FileNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void
.end method


# virtual methods
.method public CreateBitmap(II)Landroid/graphics/Bitmap;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v1, "emarteipByaCpeB t"

    const-string v1, "CreateByteBitmap "

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v1, ":"

    const-string v1, ":"

    const/4 v4, 0x4

    const-string v1, ":"

    const-string v1, ":"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo v1, "uaeicVSRqdeefrnrrE"

    const-string v1, "ViESurfaceRenderer"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v0, -0x4

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v0, Landroid/graphics/Bitmap$Config;->RGB_565:Landroid/graphics/Bitmap$Config;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {p1, p2, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v4, 0x6

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->srcRect:Landroid/graphics/Rect;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x3

    iput v2, v1, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput v2, v1, Landroid/graphics/Rect;->top:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput p2, v1, Landroid/graphics/Rect;->bottom:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput p1, v1, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object v0
.end method

.method public CreateByteBuffer(II)Ljava/nio/ByteBuffer;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    const-string/jumbo v1, "uC eorBfyBttefaer"

    const/4 v3, 0x1

    const-string v1, "afsreurCetyeBe ft"

    const-string v1, "CreateByteBuffer "

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const-string v1, ":"

    const-string v1, ":"

    const/4 v3, 0x1

    const-string v1, ":"

    const-string v1, ":"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v1, "deemEreacnfRiSuVeb"

    const-string/jumbo v1, "riEScbarfeVeRndeue"

    const-string v1, "SeunoVrReeErrdecaf"

    const-string v1, "ViESurfaceRenderer"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v0, p0, Lcom/videoengine/NTSurfaceRenderer;->video_width:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-ne v0, p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v0, p0, Lcom/videoengine/NTSurfaceRenderer;->video_height:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eq v0, p2, :cond_3

    :cond_0
    const/4 v3, 0x4

    iget-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    move v2, v0

    move v2, v0

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->byteBuffer:Ljava/nio/ByteBuffer;

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/videoengine/NTSurfaceRenderer;->CreateBitmap(II)Landroid/graphics/Bitmap;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    mul-int v0, p1, p2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    mul-int/lit8 v0, v0, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->surfaceHolder:Landroid/view/SurfaceHolder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lcom/videoengine/NTSurfaceRenderer;->surfaceCreated(Landroid/view/SurfaceHolder;)V

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput p1, p0, Lcom/videoengine/NTSurfaceRenderer;->video_width:I

    const/4 v3, 0x1

    iput p2, p0, Lcom/videoengine/NTSurfaceRenderer;->video_height:I

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/videoengine/NTSurfaceRenderer;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object p1
.end method

.method public DrawBitmap()V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-nez v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-void

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->surfaceHolder:Landroid/view/SurfaceHolder;

    const/4 v5, 0x0

    or-int/2addr v6, v5

    if-nez v0, :cond_1

    const/4 v5, 0x0

    or-int/2addr v6, v5

    const-string v0, "VeSiabcerErdeuufeR"

    const-string v0, "eSueifuVeRrcdrEear"

    const/4 v6, 0x7

    const-string/jumbo v0, "ideefSuurnrcReVaEe"

    const-string v0, "ViESurfaceRenderer"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string/jumbo v1, "huwiormpwHlsau.epirrBtc. D lpfadn tae"

    const-string/jumbo v1, "lipi.Blpwuhnm leaae ft sa.crrHDuwtdor"

    const/4 v6, 0x2

    const-string/jumbo v1, "lDau a.rql.hrdentmeaircfstpui ww oH,B"

    const-string v1, "DrawBitmap, surfaceHolder with null.."

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    return-void

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v0}, Landroid/view/SurfaceHolder;->lockCanvas()Landroid/graphics/Canvas;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v0, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/videoengine/NTSurfaceRenderer;->srcRect:Landroid/graphics/Rect;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v3, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRect:Landroid/graphics/Rect;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v4, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/graphics/Canvas;->drawBitmap(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->surfaceHolder:Landroid/view/SurfaceHolder;

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-interface {v1, v0}, Landroid/view/SurfaceHolder;->unlockCanvasAndPost(Landroid/graphics/Canvas;)V

    :cond_2
    const/4 v5, 0x6

    const/4 v5, 0x1

    return-void
.end method

.method public DrawByteBuffer()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v2, 0x1

    move v3, v2

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->rewind()Ljava/nio/Buffer;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v3, 0x3

    const/4 v2, 0x7

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/graphics/Bitmap;->copyPixelsFromBuffer(Ljava/nio/Buffer;)V

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/videoengine/NTSurfaceRenderer;->DrawBitmap()V

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public ReleaseSurface()V
    .locals 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v0, "eSserRecesarlafE:+eiuureRfVe:qcSdn"

    const-string v0, "+RfuEdn:qree:riaesrflVSaReececueSa"

    const/4 v4, 0x3

    const-string/jumbo v0, "ifrmSuudcSfcRae++er:ernEeaaeesR:Vl"

    const-string v0, "ViESurfaceRender::ReleaseSurface++"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v1, "rRndoueVfeeSeacsri"

    const-string/jumbo v1, "reseRduVeaerficnSr"

    const/4 v4, 0x1

    const-string/jumbo v1, "uarrebnVciRfeSeedE"

    const-string v1, "ViESurfaceRenderer"

    const/4 v4, 0x7

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x1

    const/4 v0, 0x2

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/videoengine/NTSurfaceRenderer;->surfaceHolder:Landroid/view/SurfaceHolder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-interface {v2, p0}, Landroid/view/SurfaceHolder;->removeCallback(Landroid/view/SurfaceHolder$Callback;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->surfaceHolder:Landroid/view/SurfaceHolder;

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v0, "fSaeseur--urrc:eRnad:eflueieaRSmec"

    const-string v0, "ee-mfeRVee::nclRSuSrcufeasra-reida"

    const/4 v4, 0x2

    const-string v0, "erEaeeVpRSsre:-uffSniculeraeadR-:e"

    const-string v0, "ViESurfaceRender::ReleaseSurface--"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void
.end method

.method public SetCoordinates(FFFF)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v1, "o diooteqaCnSst"

    const-string/jumbo v1, "oSCeoattsedi no"

    const/4 v4, 0x3

    const-string/jumbo v1, "iCs ronaotstedS"

    const-string v1, "SetCoordinates "

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    shr-int/2addr v4, v3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v1, ","

    const-string v1, ","

    const/4 v4, 0x3

    const-string v1, ","

    const-string v1, ","

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    or-int/2addr v4, v3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v2, ":"

    const-string v2, ":"

    const/4 v4, 0x0

    const-string v2, ":"

    const-string v2, ":"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo v1, "rbamVrSrEceinfReue"

    const-string v1, "cVneebErReerarSifu"

    const/4 v4, 0x5

    const-string/jumbo v1, "rcrRoViuaEdfeeSere"

    const-string v1, "ViESurfaceRenderer"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput p1, p0, Lcom/videoengine/NTSurfaceRenderer;->dstLeftScale:F

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput p2, p0, Lcom/videoengine/NTSurfaceRenderer;->dstTopScale:F

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput p3, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRightScale:F

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput p4, p0, Lcom/videoengine/NTSurfaceRenderer;->dstBottomScale:F

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method

.method public surfaceChanged(Landroid/view/SurfaceHolder;III)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string p1, "Viecrbrn:car:CueensuRhaduEeegffd"

    const-string/jumbo p1, "nc::RruEnfgucirCdsefaaeVaerdeheu"

    const/4 v2, 0x6

    const-string p1, "ViESurfaceRender::surfaceChanged"

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string/jumbo p2, "reiEueupfSnerVcraR"

    const-string p2, "SefVnerpruceiRaerE"

    const/4 v2, 0x6

    const-string/jumbo p2, "nrRVESeprrudecaief"

    const-string p2, "ViESurfaceRenderer"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0, p3, p4}, Lcom/videoengine/NTSurfaceRenderer;->changeDestRect(II)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const-string v0, "cnqrRs:iqaf:hairneErdwfgdSceheCuiad tnueVe"

    const-string/jumbo v0, "hEidc:_dqVtfdneergahS nnRcsrwuiaeiaerCuef:"

    const/4 v2, 0x2

    const-string/jumbo v0, "i suh:fuS:aReetcaaddsrfenwhgerdCnri_cV:Ene"

    const-string v0, "ViESurfaceRender::surfaceChanged in_width:"

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string/jumbo p3, "tnimgh h_ei"

    const-string/jumbo p3, "h_sii etghn"

    const/4 v2, 0x2

    const-string p3, "_h:gohn iti"

    const-string p3, " in_height:"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string p3, ":setrbceclf tm"

    const-string p3, "cstme.lf:ecr t"

    const/4 v2, 0x5

    const-string p3, "cl:eRturt scfe"

    const-string p3, " srcRect.left:"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object p3, p0, Lcom/videoengine/NTSurfaceRenderer;->srcRect:Landroid/graphics/Rect;

    const/4 v2, 0x0

    iget p3, p3, Landroid/graphics/Rect;->left:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    move v2, v1

    const-string p3, "cso:cpep .oRr"

    const-string p3, "c.Reo:orcstp "

    const/4 v2, 0x2

    const-string p3, "coe .sc:qrptt"

    const-string p3, " srcRect.top:"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object p3, p0, Lcom/videoengine/NTSurfaceRenderer;->srcRect:Landroid/graphics/Rect;

    iget p3, p3, Landroid/graphics/Rect;->top:I

    const/4 v2, 0x3

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-string/jumbo p3, "iescR.hrtg: rct"

    const-string p3, " srcRect.right:"

    const/4 v2, 0x0

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x5

    iget-object p3, p0, Lcom/videoengine/NTSurfaceRenderer;->srcRect:Landroid/graphics/Rect;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget p3, p3, Landroid/graphics/Rect;->right:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const-string p3, " srcRect.bottom:"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object p3, p0, Lcom/videoengine/NTSurfaceRenderer;->srcRect:Landroid/graphics/Rect;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget p3, p3, Landroid/graphics/Rect;->bottom:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const-string p3, " t:mlfdtRbc.et"

    const-string/jumbo p3, "lRtt:bt ecf.de"

    const/4 v2, 0x6

    const-string p3, ".tltotcfe:Reds"

    const-string p3, " dstRect.left:"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object p3, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRect:Landroid/graphics/Rect;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget p3, p3, Landroid/graphics/Rect;->left:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string p3, "d.teub:c Rtpt"

    const-string p3, "Rotetcupt.: d"

    const/4 v2, 0x4

    const-string/jumbo p3, "ot. stuptec:d"

    const-string p3, " dstRect.top:"

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object p3, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRect:Landroid/graphics/Rect;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget p3, p3, Landroid/graphics/Rect;->top:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    move v2, v1

    const-string/jumbo p3, "ict stdpeR.p:tr"

    const-string/jumbo p3, "rtRe:hspd it.ct"

    const/4 v2, 0x7

    const-string p3, "R.gs:dhtqtr iec"

    const-string p3, " dstRect.right:"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p3, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRect:Landroid/graphics/Rect;

    const/4 v2, 0x2

    iget p3, p3, Landroid/graphics/Rect;->right:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string p3, "b:ssd ttqcmetoto"

    const-string/jumbo p3, "tedm.ostqo :ctbt"

    const/4 v2, 0x1

    const-string p3, ".tem tbtstRdmooc"

    const-string p3, " dstRect.bottom:"

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object p3, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRect:Landroid/graphics/Rect;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget p3, p3, Landroid/graphics/Rect;->bottom:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p2, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public surfaceCreated(Landroid/view/SurfaceHolder;)V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo p1, "fcN,oerdC.e.urar sTcrrsefnRadeueeat"

    const-string p1, ".dserr cftceT.aureaenaSfCdrs,erRNeu"

    const/4 v6, 0x2

    const-string/jumbo p1, "tf .aberfaTr.eueeRrCrdc,euNeSdcensa"

    const-string p1, "NTSurfaceRenderer, surfaceCreated.."

    const/4 v6, 0x5

    const-string/jumbo v0, "iRSfrEumnedVeuecre"

    const-string/jumbo v0, "runmfVeedESecierrR"

    const/4 v6, 0x6

    const-string v0, "ceSrrEuprneiedaeVf"

    const-string v0, "ViESurfaceRenderer"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/videoengine/NTSurfaceRenderer;->surfaceHolder:Landroid/view/SurfaceHolder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-interface {p1}, Landroid/view/SurfaceHolder;->lockCanvas()Landroid/graphics/Canvas;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz p1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->surfaceHolder:Landroid/view/SurfaceHolder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v1}, Landroid/view/SurfaceHolder;->getSurfaceFrame()Landroid/graphics/Rect;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget v2, v1, Landroid/graphics/Rect;->right:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget v3, v1, Landroid/graphics/Rect;->left:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    sub-int/2addr v2, v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget v3, v1, Landroid/graphics/Rect;->bottom:I

    const/4 v6, 0x5

    iget v4, v1, Landroid/graphics/Rect;->top:I

    const/4 v5, 0x3

    move v6, v5

    sub-int/2addr v3, v4

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {p0, v2, v3}, Lcom/videoengine/NTSurfaceRenderer;->changeDestRect(II)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string/jumbo v3, "safadeirqsfa.ddeercEutVelCR:tunrreSeo ce::"

    const-string/jumbo v3, "uderot eretnSfe.Rdcusaedc:eClVt:fasiarreE:"

    const/4 v6, 0x7

    const-string/jumbo v3, "rSsatlrfdefE:sCsiertdncedfcturV: Ru:a.eeea"

    const-string v3, "ViESurfaceRender::surfaceCreated dst.left:"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget v3, v1, Landroid/graphics/Rect;->left:I

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const-string v3, ".ttmbp:so"

    const-string/jumbo v3, "t:d.pbtso"

    const/4 v6, 0x4

    const-string/jumbo v3, "p .to:std"

    const-string v3, " dst.top:"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget v3, v1, Landroid/graphics/Rect;->top:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo v3, "tr:tgsuihd."

    const/4 v6, 0x2

    const-string v3, ":thgrbsd.ti"

    const-string v3, " dst.right:"

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget v3, v1, Landroid/graphics/Rect;->right:I

    const/4 v6, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string/jumbo v3, "omps oud.btt"

    const-string v3, " mtd.bsptoot"

    const/4 v6, 0x3

    const-string v3, "dtstoompb:.t"

    const-string v3, " dst.bottom:"

    const/4 v6, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    iget v1, v1, Landroid/graphics/Rect;->bottom:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string/jumbo v1, "sfcteqr.qlceR:"

    const-string v1, "e Recl:rqstfc."

    const/4 v6, 0x0

    const-string v1, "e:sl tRecsc.tf"

    const-string v1, " srcRect.left:"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->srcRect:Landroid/graphics/Rect;

    const/4 v6, 0x6

    iget v1, v1, Landroid/graphics/Rect;->left:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string/jumbo v1, "tctmoerRp s:s"

    const-string v1, "c speotr.Rts:"

    const/4 v6, 0x1

    const-string/jumbo v1, "octpo:ets.crR"

    const-string v1, " srcRect.top:"

    const/4 v6, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->srcRect:Landroid/graphics/Rect;

    const/4 v6, 0x7

    const/4 v5, 0x6

    iget v1, v1, Landroid/graphics/Rect;->top:I

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string v1, ":. etbmrcsrRicg"

    const-string v1, "c gm:cRerr.tsti"

    const/4 v6, 0x0

    const-string/jumbo v1, "i:tc eucrRsrhg."

    const-string v1, " srcRect.right:"

    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->srcRect:Landroid/graphics/Rect;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget v1, v1, Landroid/graphics/Rect;->right:I

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo v1, "stRt.mcp:eooc ot"

    const-string v1, "eot.oR:tm cbtcos"

    const-string v1, ":ttRboccqosm.rt "

    const-string v1, " srcRect.bottom:"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->srcRect:Landroid/graphics/Rect;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget v1, v1, Landroid/graphics/Rect;->bottom:I

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string/jumbo v1, "scsb.fe:Rtet d"

    const-string/jumbo v1, "fstR bt:e.tced"

    const/4 v6, 0x2

    const-string/jumbo v1, "tdtmte:c.Rsel "

    const-string v1, " dstRect.left:"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRect:Landroid/graphics/Rect;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget v1, v1, Landroid/graphics/Rect;->left:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v1, "tcdpotuets.: "

    const-string/jumbo v1, "tc p.Ruestdt:"

    const/4 v6, 0x7

    const-string/jumbo v1, "otctsb.R p:dt"

    const-string v1, " dstRect.top:"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRect:Landroid/graphics/Rect;

    const/4 v6, 0x7

    const/4 v5, 0x6

    iget v1, v1, Landroid/graphics/Rect;->top:I

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string/jumbo v1, "t:ttgdusRice. r"

    const-string v1, " dstRect.right:"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRect:Landroid/graphics/Rect;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget v1, v1, Landroid/graphics/Rect;->right:I

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v1, ":stt.b pteodtmcR"

    const/4 v6, 0x7

    const-string/jumbo v1, "tobttc:ptedR smo"

    const-string v1, " dstRect.bottom:"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/videoengine/NTSurfaceRenderer;->dstRect:Landroid/graphics/Rect;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget v1, v1, Landroid/graphics/Rect;->bottom:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/videoengine/NTSurfaceRenderer;->surfaceHolder:Landroid/view/SurfaceHolder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v0, p1}, Landroid/view/SurfaceHolder;->unlockCanvasAndPost(Landroid/graphics/Canvas;)V

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-void
.end method

.method public surfaceDestroyed(Landroid/view/SurfaceHolder;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string p1, "SrefidecqRqVEarern"

    const-string/jumbo p1, "iSufrrRrqnEecedVea"

    const/4 v2, 0x2

    const-string/jumbo p1, "rEsecSafderVieRuen"

    const-string p1, "ViESurfaceRenderer"

    const/4 v2, 0x3

    const-string/jumbo v0, "fVRmie::uenscsaferyroreetEaduDedrrce"

    const-string v0, "aEsutdceordreaer:sRnyieucrf:efDseVre"

    const/4 v2, 0x0

    const-string/jumbo v0, "ricootuDrRaaeVesdE:ersSrnedc:fyreuee"

    const-string v0, "ViESurfaceRenderer::surfaceDestroyed"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/videoengine/NTSurfaceRenderer;->bitmap:Landroid/graphics/Bitmap;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/videoengine/NTSurfaceRenderer;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method
