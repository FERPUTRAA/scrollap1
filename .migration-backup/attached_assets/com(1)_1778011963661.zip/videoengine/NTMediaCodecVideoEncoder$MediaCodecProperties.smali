.class Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/videoengine/NTMediaCodecVideoEncoder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "MediaCodecProperties"
.end annotation


# instance fields
.field public final bitrateAdjustmentType:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

.field public final codecPrefix:Ljava/lang/String;

.field public final minSdk:I


# direct methods
.method constructor <init>(Ljava/lang/String;ILcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;->codecPrefix:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput p2, p0, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;->minSdk:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p3, p0, Lcom/videoengine/NTMediaCodecVideoEncoder$MediaCodecProperties;->bitrateAdjustmentType:Lcom/videoengine/NTMediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method
