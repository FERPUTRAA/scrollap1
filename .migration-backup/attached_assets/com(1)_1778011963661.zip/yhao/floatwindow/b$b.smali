.class Lcom/yhao/floatwindow/b$b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/yhao/floatwindow/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yhao/floatwindow/b;->o()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/yhao/floatwindow/b;


# direct methods
.method constructor <init>(Lcom/yhao/floatwindow/b;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/yhao/floatwindow/b$b;->a:Lcom/yhao/floatwindow/b;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onFail()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~fsln~ y~l@i~@  ~r o~~~d-  @@@@ om KtvM @~@~ub@t~@/~oi @b@~  S   of@  o~~@i~@a@~4@@~c@~s1/~~o@~."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/yhao/floatwindow/b$b;->a:Lcom/yhao/floatwindow/b;

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/yhao/floatwindow/b;->n(Lcom/yhao/floatwindow/b;)Lcom/yhao/floatwindow/l;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/yhao/floatwindow/b$b;->a:Lcom/yhao/floatwindow/b;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/yhao/floatwindow/b;->n(Lcom/yhao/floatwindow/b;)Lcom/yhao/floatwindow/l;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0}, Lcom/yhao/floatwindow/l;->onFail()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public onSuccess()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/yhao/floatwindow/b$b;->a:Lcom/yhao/floatwindow/b;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/yhao/floatwindow/b;->m(Lcom/yhao/floatwindow/b;)Landroid/view/WindowManager;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/yhao/floatwindow/b$b;->a:Lcom/yhao/floatwindow/b;

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/yhao/floatwindow/b;->k(Lcom/yhao/floatwindow/b;)Landroid/view/View;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/yhao/floatwindow/b$b;->a:Lcom/yhao/floatwindow/b;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v2}, Lcom/yhao/floatwindow/b;->l(Lcom/yhao/floatwindow/b;)Landroid/view/WindowManager$LayoutParams;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {v0, v1, v2}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/yhao/floatwindow/b$b;->a:Lcom/yhao/floatwindow/b;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/yhao/floatwindow/b;->n(Lcom/yhao/floatwindow/b;)Lcom/yhao/floatwindow/l;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/yhao/floatwindow/b$b;->a:Lcom/yhao/floatwindow/b;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/yhao/floatwindow/b;->n(Lcom/yhao/floatwindow/b;)Lcom/yhao/floatwindow/l;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0}, Lcom/yhao/floatwindow/l;->onSuccess()V

    :cond_0
    const/4 v4, 0x4

    return-void
.end method
