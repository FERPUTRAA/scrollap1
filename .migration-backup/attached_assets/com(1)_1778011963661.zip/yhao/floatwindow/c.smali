.class Lcom/yhao/floatwindow/c;
.super Lcom/yhao/floatwindow/d;


# instance fields
.field private a:Landroid/widget/Toast;

.field private b:Ljava/lang/Object;

.field private c:Ljava/lang/reflect/Method;

.field private d:Ljava/lang/reflect/Method;

.field private e:I

.field private f:I


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/yhao/floatwindow/d;-><init>()V

    const/4 v2, 0x2

    new-instance v0, Landroid/widget/Toast;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0, p1}, Landroid/widget/Toast;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/yhao/floatwindow/c;->a:Landroid/widget/Toast;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method private k()V
    .locals 7

    :try_start_0
    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "/@sf@i  o~@~@/~~~v ~@ a~tcu@ o~od 4  ~M @ t@1f~~~i~lm@@b @y.@~@~b ib@@  @~~@Kl s S-oo~@@~~~ rn@~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/yhao/floatwindow/c;->a:Landroid/widget/Toast;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string v1, "NTm"

    const-string/jumbo v1, "mTN"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/yhao/floatwindow/c;->a:Landroid/widget/Toast;

    const/4 v6, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput-object v0, p0, Lcom/yhao/floatwindow/c;->b:Ljava/lang/Object;

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string/jumbo v2, "sohw"

    const-string/jumbo v2, "hswo"

    const/4 v6, 0x5

    const-string/jumbo v2, "whos"

    const-string/jumbo v2, "show"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v3, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    iput-object v0, p0, Lcom/yhao/floatwindow/c;->c:Ljava/lang/reflect/Method;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/yhao/floatwindow/c;->b:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo v2, "hide"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/yhao/floatwindow/c;->d:Ljava/lang/reflect/Method;

    const/4 v6, 0x7

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/yhao/floatwindow/c;->b:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v2, "mrsmasa"

    const-string/jumbo v2, "masrPsa"

    const/4 v6, 0x4

    const-string/jumbo v2, "maPsoam"

    const-string/jumbo v2, "mParams"

    const/4 v6, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/yhao/floatwindow/c;->b:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    check-cast v0, Landroid/view/WindowManager$LayoutParams;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/16 v2, 0x28

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    iput v2, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v5, 0x4

    and-int/2addr v6, v5

    iget v2, p0, Lcom/yhao/floatwindow/c;->e:I

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    iput v2, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    const/4 v5, 0x5

    move v6, v5

    iget v2, p0, Lcom/yhao/floatwindow/c;->f:I

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput v2, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput v3, v0, Landroid/view/WindowManager$LayoutParams;->windowAnimations:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/yhao/floatwindow/c;->b:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo v2, "tmeVebwNx"

    const-string/jumbo v2, "ewmmxeNVt"

    const/4 v6, 0x6

    const-string/jumbo v2, "wNieVtuex"

    const-string/jumbo v2, "mNextView"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/yhao/floatwindow/c;->b:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/yhao/floatwindow/c;->a:Landroid/widget/Toast;

    const/4 v6, 0x3

    invoke-virtual {v2}, Landroid/widget/Toast;->getView()Landroid/view/View;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    return-void
.end method


# virtual methods
.method public a()V
    .locals 5

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/yhao/floatwindow/c;->d:Ljava/lang/reflect/Method;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/yhao/floatwindow/c;->b:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method public d()V
    .locals 5

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/yhao/floatwindow/c;->c:Ljava/lang/reflect/Method;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/yhao/floatwindow/c;->b:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-void
.end method

.method public e(III)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/yhao/floatwindow/c;->a:Landroid/widget/Toast;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p2, p3}, Landroid/widget/Toast;->setGravity(III)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public f(II)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p1, p0, Lcom/yhao/floatwindow/c;->e:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p2, p0, Lcom/yhao/floatwindow/c;->f:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public g(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/yhao/floatwindow/c;->a:Landroid/widget/Toast;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/widget/Toast;->setView(Landroid/view/View;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/yhao/floatwindow/c;->k()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method
