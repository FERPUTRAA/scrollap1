.class public Lcom/yhao/floatwindow/e$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/yhao/floatwindow/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field a:Landroid/content/Context;

.field b:Landroid/view/View;

.field private c:I

.field d:I

.field e:I

.field f:I

.field g:I

.field h:I

.field i:Z

.field j:[Ljava/lang/Class;

.field k:I

.field l:I

.field m:I

.field n:J

.field o:Landroid/animation/TimeInterpolator;

.field private p:Ljava/lang/String;

.field q:Z

.field r:Lcom/yhao/floatwindow/l;

.field s:Lcom/yhao/floatwindow/r;


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v0, -0x2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput v0, p0, Lcom/yhao/floatwindow/e$a;->d:I

    const/4 v3, 0x0

    iput v0, p0, Lcom/yhao/floatwindow/e$a;->e:I

    const/4 v3, 0x7

    const v0, 0x800033

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput v0, p0, Lcom/yhao/floatwindow/e$a;->f:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-boolean v0, p0, Lcom/yhao/floatwindow/e$a;->i:Z

    const/4 v3, 0x1

    const/4 v0, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput v0, p0, Lcom/yhao/floatwindow/e$a;->k:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-wide/16 v0, 0x12c

    const-wide/16 v0, 0x12c

    const/4 v3, 0x3

    const-wide/16 v0, 0x12c

    const-wide/16 v0, 0x12c

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/yhao/floatwindow/e$a;->n:J

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v0, "_osdwnoltafaefdta_tl_igu"

    const-string v0, "ags_aaitoltno__ftdedfluw"

    const/4 v3, 0x7

    const-string/jumbo v0, "wtamln_dfgutlweatfoo_d_a"

    const-string v0, "default_float_window_tag"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/yhao/floatwindow/e$a;->p:Ljava/lang/String;

    const/4 v3, 0x3

    return-void
.end method

.method constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, -0x2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput v0, p0, Lcom/yhao/floatwindow/e$a;->d:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v0, p0, Lcom/yhao/floatwindow/e$a;->e:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    const v0, 0x800033

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput v0, p0, Lcom/yhao/floatwindow/e$a;->f:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/yhao/floatwindow/e$a;->i:Z

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput v0, p0, Lcom/yhao/floatwindow/e$a;->k:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-wide/16 v0, 0x12c

    const-wide/16 v0, 0x12c

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/yhao/floatwindow/e$a;->n:J

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo v0, "fglaow__onmdeutaoia_tfwl"

    const-string/jumbo v0, "waamfe_d_uflwdoalitgt_no"

    const/4 v3, 0x3

    const-string/jumbo v0, "t_e_obwtloaidtuafdw_gfal"

    const-string v0, "default_float_window_tag"

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/yhao/floatwindow/e$a;->p:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "K@@n@ u/mo ~to@i@a ~io@oS~~~4t ~@ d by~b b@u/~@ @1 oc@~ @ l. ilv-@@  ~~~fr@f ~~o ~~~@s@~@M@~~ @~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    invoke-static {}, Lcom/yhao/floatwindow/e;->a()Ljava/util/Map;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/yhao/floatwindow/e;->b(Ljava/util/Map;)Ljava/util/Map;

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-static {}, Lcom/yhao/floatwindow/e;->a()Ljava/util/Map;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/yhao/floatwindow/e$a;->p:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-nez v0, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/yhao/floatwindow/e$a;->b:Landroid/view/View;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-nez v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    iget v1, p0, Lcom/yhao/floatwindow/e$a;->c:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v1, "Vnebeespeao t   inwhos"

    const-string v1, "behson aoV ets ie ntew"

    const/4 v4, 0x3

    const-string/jumbo v1, "n nhse!eqe i t wVobast"

    const-string v1, "View has not been set!"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    throw v0

    :cond_2
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez v0, :cond_3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v1, p0, Lcom/yhao/floatwindow/e$a;->c:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/yhao/floatwindow/q;->c(Landroid/content/Context;I)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/yhao/floatwindow/e$a;->b:Landroid/view/View;

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v0, Lcom/yhao/floatwindow/g;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v0, p0}, Lcom/yhao/floatwindow/g;-><init>(Lcom/yhao/floatwindow/e$a;)V

    invoke-static {}, Lcom/yhao/floatwindow/e;->a()Ljava/util/Map;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/yhao/floatwindow/e$a;->p:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string v1, " es  dioagttraahhwa eob senePtotF he snt sW anWilslfoeag Fl dw w,otfa odw  ieadbneed"

    const-string/jumbo v1, "etsw blleo iWtwadehat eltaobe o hto PrandWwaseg   dnfidnf eF taF,aa disse  o wegothn"

    const/4 v4, 0x6

    const-string v1, "aahmioao  n ideoddn th, ewtaolntatohewbf swrwl t aFisgen e e talgefan dFWs PeW sdto "

    const-string v1, "FloatWindow of this tag has been added, Please set a new tag for the new FloatWindow"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    throw v0
.end method

.method public b(Z)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/yhao/floatwindow/e$a;->q:Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method public varargs c(Z[Ljava/lang/Class;)Lcom/yhao/floatwindow/e$a;
    .locals 2
    .param p2    # [Ljava/lang/Class;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/yhao/floatwindow/e$a;->i:Z

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/yhao/floatwindow/e$a;->j:[Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x1

    return-object p0
.end method

.method public d(I)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p1, p0, Lcom/yhao/floatwindow/e$a;->e:I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public e(IF)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-nez p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->b(Landroid/content/Context;)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    iget-object p1, p0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->a(Landroid/content/Context;)I

    move-result p1

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    int-to-float p1, p1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    mul-float/2addr p1, p2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    float-to-int p1, p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p1, p0, Lcom/yhao/floatwindow/e$a;->e:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method public f(JLandroid/animation/TimeInterpolator;)Lcom/yhao/floatwindow/e$a;
    .locals 2
    .param p3    # Landroid/animation/TimeInterpolator;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/yhao/floatwindow/e$a;->n:J

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/yhao/floatwindow/e$a;->o:Landroid/animation/TimeInterpolator;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method public g(I)Lcom/yhao/floatwindow/e$a;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0, v0}, Lcom/yhao/floatwindow/e$a;->h(III)Lcom/yhao/floatwindow/e$a;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p1
.end method

.method public h(III)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/yhao/floatwindow/e$a;->k:I

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p2, p0, Lcom/yhao/floatwindow/e$a;->l:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p3, p0, Lcom/yhao/floatwindow/e$a;->m:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method public i(Lcom/yhao/floatwindow/l;)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/yhao/floatwindow/e$a;->r:Lcom/yhao/floatwindow/l;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method public j(Ljava/lang/String;)Lcom/yhao/floatwindow/e$a;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/yhao/floatwindow/e$a;->p:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method

.method public k(I)Lcom/yhao/floatwindow/e$a;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/j0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/yhao/floatwindow/e$a;->c:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method public l(Landroid/view/View;)Lcom/yhao/floatwindow/e$a;
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/yhao/floatwindow/e$a;->b:Landroid/view/View;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method public m(Lcom/yhao/floatwindow/r;)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v1, 0x4

    return-object p0
.end method

.method public n(I)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lcom/yhao/floatwindow/e$a;->d:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method public o(IF)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    if-nez p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->b(Landroid/content/Context;)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->a(Landroid/content/Context;)I

    move-result p1

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    int-to-float p1, p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    mul-float/2addr p1, p2

    const/4 v1, 0x4

    float-to-int p1, p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/yhao/floatwindow/e$a;->d:I

    const/4 v1, 0x1

    return-object p0
.end method

.method public p(I)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p1, p0, Lcom/yhao/floatwindow/e$a;->g:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method public q(IF)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-nez p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->b(Landroid/content/Context;)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->a(Landroid/content/Context;)I

    move-result p1

    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    int-to-float p1, p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    mul-float/2addr p1, p2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    float-to-int p1, p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p1, p0, Lcom/yhao/floatwindow/e$a;->g:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method public r(I)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x2

    iput p1, p0, Lcom/yhao/floatwindow/e$a;->h:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public s(IF)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    if-nez p1, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->b(Landroid/content/Context;)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x1

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->a(Landroid/content/Context;)I

    move-result p1

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    int-to-float p1, p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    mul-float/2addr p1, p2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    float-to-int p1, p1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Lcom/yhao/floatwindow/e$a;->h:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method
