.class public interface abstract Lcom/yhao/floatwindow/l;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onFail()V
.end method

.method public abstract onSuccess()V
.end method
