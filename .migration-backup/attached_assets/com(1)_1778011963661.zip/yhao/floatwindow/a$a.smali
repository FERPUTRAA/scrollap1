.class Lcom/yhao/floatwindow/a$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yhao/floatwindow/a;->onActivityPaused(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/yhao/floatwindow/a;


# direct methods
.method constructor <init>(Lcom/yhao/floatwindow/a;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/yhao/floatwindow/a$a;->a:Lcom/yhao/floatwindow/a;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ s@~bi@itl  d/~l@ ~/ s~i  o~m@4v   @@@. ~MS~~@~a@bf@@~ b@~~~~f@~u@@ ctr~o ~o@Kn~@~o@ 1 o~@o-~ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/yhao/floatwindow/a$a;->a:Lcom/yhao/floatwindow/a;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/yhao/floatwindow/a;->a(Lcom/yhao/floatwindow/a;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/yhao/floatwindow/a$a;->a:Lcom/yhao/floatwindow/a;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/yhao/floatwindow/a;->b(Lcom/yhao/floatwindow/a;Z)Z

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/yhao/floatwindow/a$a;->a:Lcom/yhao/floatwindow/a;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/yhao/floatwindow/a;->c(Lcom/yhao/floatwindow/a;)Lcom/yhao/floatwindow/h;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v0}, Lcom/yhao/floatwindow/h;->a()V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method
