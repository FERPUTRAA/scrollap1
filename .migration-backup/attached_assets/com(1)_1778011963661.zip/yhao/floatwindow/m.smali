.class Lcom/yhao/floatwindow/m;
.super Ljava/lang/Object;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method static a(Landroid/content/Context;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ts  @@ vu ~soo@d @-~@~1@a~@ @i~@oob~4b~ ~~~~~yol~~K@f~@~  @ S ~@/~Mm  ~ @c t@ ib@@ol~/i@.@~nr f"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return p0
.end method

.method static b(Landroid/content/Context;)Z
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    const-string/jumbo v1, "soampp"

    const-string/jumbo v1, "psspao"

    const/4 v10, 0x0

    const-string v1, "asopop"

    const-string v1, "appops"

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    check-cast v1, Landroid/app/AppOpsManager;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-class v2, Landroid/app/AppOpsManager;

    const-class v2, Landroid/app/AppOpsManager;

    const/4 v10, 0x6

    const-class v2, Landroid/app/AppOpsManager;

    const-class v2, Landroid/app/AppOpsManager;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string v3, "Okhmcpc"

    const/4 v10, 0x4

    const-string/jumbo v3, "hcecpbk"

    const-string v3, "checkOp"

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v4, 0x3

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    sget-object v6, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    aput-object v6, v5, v0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/4 v7, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    aput-object v6, v5, v7

    const/4 v10, 0x4

    const/4 v9, 0x6

    const-class v6, Ljava/lang/String;

    const-class v6, Ljava/lang/String;

    const/4 v10, 0x4

    const-class v6, Ljava/lang/String;

    const-class v6, Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/4 v8, 0x2

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    aput-object v6, v5, v8

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {v2, v3, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    new-array v3, v4, [Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    const/16 v4, 0x18

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    aput-object v4, v3, v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v4

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    aput-object v4, v3, v7

    const/4 v9, 0x2

    xor-int/2addr v10, v9

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    aput-object p0, v3, v8

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v2, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    check-cast p0, Ljava/lang/Integer;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-nez p0, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    move v0, v7

    move v0, v7

    const/4 v10, 0x2

    move v0, v7

    move v0, v7

    :catch_0
    :cond_0
    const/4 v10, 0x4

    return v0
.end method

.method private static c(Landroid/content/Context;)Z
    .locals 11
    .annotation build Landroidx/annotation/w0;
        api = 0x17
    .end annotation

    const/4 v9, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string/jumbo v1, "onwdoi"

    const/4 v10, 0x6

    const-string/jumbo v1, "udiwnw"

    const-string/jumbo v1, "window"

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    check-cast v1, Landroid/view/WindowManager;

    const/4 v10, 0x3

    if-nez v1, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    return v0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    new-instance v2, Landroid/view/View;

    const/4 v9, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-direct {v2, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    new-instance p0, Landroid/view/WindowManager$LayoutParams;

    const/4 v9, 0x5

    or-int/2addr v10, v9

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v10, 0x3

    const/4 v5, 0x0

    const/4 v10, 0x4

    move v9, v5

    move v9, v5

    const/4 v10, 0x2

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/16 v6, 0x1a

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-lt v3, v6, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/16 v3, 0x7f6

    const/4 v9, 0x6

    and-int/2addr v10, v9

    goto :goto_0

    :cond_1
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/16 v3, 0x7d3

    :goto_0
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    move v6, v3

    move v6, v3

    const/4 v10, 0x2

    move v6, v3

    move v6, v3

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    const/16 v7, 0x18

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v8, -0x2

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-direct/range {v3 .. v8}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v2, p0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-interface {v1, v2, p0}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-interface {v1, v2}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/4 p0, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    return p0

    :catch_0
    move-exception p0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-string/jumbo v2, "resbiehpsOa onrPsimF"

    const-string/jumbo v2, "nioasbom hesFiPOresr"

    const-string v2, "emeFs :sqPsnrirOoaih"

    const-string/jumbo v2, "hasPermissionForO e:"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    move v10, v9

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {p0}, Lcom/yhao/floatwindow/i;->b(Ljava/lang/String;)V

    const/4 v10, 0x5

    return v0
.end method

.method static d(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/16 v1, 0x1a

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/yhao/floatwindow/m;->c(Landroid/content/Context;)Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    return p0
.end method
