.class final Lcom/yhao/floatwindow/j$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/yhao/floatwindow/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yhao/floatwindow/j;->e(Landroid/content/Context;Lcom/yhao/floatwindow/l;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onFail()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "tvsi~   ~Kacs~@@@ lr@@@ oi~@f~/l@nm~~@~@~~ t ~@@1 .-/ ~~~o~ydbuMo~~o@@@S  o ~~oi@ f~~ @b@~ 4@@ b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    invoke-static {}, Lcom/yhao/floatwindow/j;->a()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v1, Lcom/yhao/floatwindow/l;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v1}, Lcom/yhao/floatwindow/l;->onFail()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {}, Lcom/yhao/floatwindow/j;->a()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public onSuccess()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {}, Lcom/yhao/floatwindow/j;->a()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast v1, Lcom/yhao/floatwindow/l;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v1}, Lcom/yhao/floatwindow/l;->onSuccess()V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    invoke-static {}, Lcom/yhao/floatwindow/j;->a()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method
