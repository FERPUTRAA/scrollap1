.class public Lcom/yhao/floatwindow/e;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/yhao/floatwindow/e$a;
    }
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "default_float_window_tag"

.field private static b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/yhao/floatwindow/f;",
            ">;"
        }
    .end annotation
.end field

.field private static c:Lcom/yhao/floatwindow/e$a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a()Ljava/util/Map;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s in/b@@m @@@/i@bbo~~ @~ a~4fsl~oo@v M@ ~o@-~  @ @u~@ co @~~t~ rf~@t~S~~o~ ~d~ @~~@i.y@lK~~1 @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/yhao/floatwindow/e;->b:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic b(Ljava/util/Map;)Ljava/util/Map;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    sput-object p0, Lcom/yhao/floatwindow/e;->b:Ljava/util/Map;

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-object p0
.end method

.method public static c()V
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo v0, "no_mtodtwaaw_uslgeafidtl"

    const-string/jumbo v0, "ofs_auwwt_onaeidalgtdtl_"

    const/4 v2, 0x2

    const-string/jumbo v0, "etuloagodfw_at_n_lwodaif"

    const-string v0, "default_float_window_tag"

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/yhao/floatwindow/e;->d(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public static d(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lcom/yhao/floatwindow/e;->b:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {v0, p0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lcom/yhao/floatwindow/e;->b:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast v0, Lcom/yhao/floatwindow/f;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/yhao/floatwindow/f;->a()V

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/yhao/floatwindow/e;->b:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public static e()Lcom/yhao/floatwindow/f;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-string/jumbo v0, "o_ttdbole_aiwnwdg_mtffla"

    const-string v0, "_dtmitoadww_agotn_elfafl"

    const/4 v2, 0x7

    const-string/jumbo v0, "ww_tlduatgi_fodf_oeuaaln"

    const-string v0, "default_float_window_tag"

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/yhao/floatwindow/e;->f(Ljava/lang/String;)Lcom/yhao/floatwindow/f;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public static f(Ljava/lang/String;)Lcom/yhao/floatwindow/f;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lcom/yhao/floatwindow/e;->b:Ljava/util/Map;

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast p0, Lcom/yhao/floatwindow/f;

    :goto_0
    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public static g(Landroid/content/Context;)Lcom/yhao/floatwindow/e$a;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance v0, Lcom/yhao/floatwindow/e$a;

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/yhao/floatwindow/e$a;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    sput-object v0, Lcom/yhao/floatwindow/e;->c:Lcom/yhao/floatwindow/e$a;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method
