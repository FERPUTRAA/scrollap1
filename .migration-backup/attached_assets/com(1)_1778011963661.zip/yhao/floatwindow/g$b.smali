.class Lcom/yhao/floatwindow/g$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yhao/floatwindow/g;->E()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field a:F

.field b:F

.field c:F

.field d:F

.field e:I

.field f:I

.field final synthetic g:Lcom/yhao/floatwindow/g;


# direct methods
.method constructor <init>(Lcom/yhao/floatwindow/g;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 7
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ClickableViewAccessibility"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "o~s@oM~mfbtu~@@  ~b ~~~~o@~lfv~ @~. -r~o@ ty@l~/Kb@o@~  ci@@~ 1/~dn~@~sS 4~i @@ @@~oa @i@~@~  @ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz v0, :cond_8

    const/4 v6, 0x7

    const/4 v1, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eq v0, v2, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x7

    if-eq v0, v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    goto/16 :goto_3

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget v0, p0, Lcom/yhao/floatwindow/g$b;->a:F

    const/4 v6, 0x6

    sub-float/2addr p1, v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput p1, p0, Lcom/yhao/floatwindow/g$b;->c:F

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget v0, p0, Lcom/yhao/floatwindow/g$b;->b:F

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    sub-float/2addr p1, v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    iput p1, p0, Lcom/yhao/floatwindow/g$b;->d:F

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->s(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/d;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1}, Lcom/yhao/floatwindow/d;->b()I

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    int-to-float p1, p1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget v0, p0, Lcom/yhao/floatwindow/g$b;->c:F

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    add-float/2addr p1, v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    float-to-int p1, p1

    const/4 v6, 0x7

    const/4 v5, 0x5

    iput p1, p0, Lcom/yhao/floatwindow/g$b;->e:I

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->s(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/d;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p1}, Lcom/yhao/floatwindow/d;->c()I

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    int-to-float p1, p1

    const/4 v6, 0x2

    iget v0, p0, Lcom/yhao/floatwindow/g$b;->d:F

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    add-float/2addr p1, v0

    const/4 v5, 0x0

    shl-int/2addr v6, v5

    float-to-int p1, p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    iput p1, p0, Lcom/yhao/floatwindow/g$b;->f:I

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->s(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/d;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget v0, p0, Lcom/yhao/floatwindow/g$b;->e:I

    const/4 v5, 0x2

    shr-int/2addr v6, v5

    iget v1, p0, Lcom/yhao/floatwindow/g$b;->f:I

    invoke-virtual {p1, v0, v1}, Lcom/yhao/floatwindow/d;->i(II)V

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object p1, p1, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz p1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x4

    const/4 v5, 0x5

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object p1, p1, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v0, p0, Lcom/yhao/floatwindow/g$b;->e:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget v1, p0, Lcom/yhao/floatwindow/g$b;->f:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-interface {p1, v0, v1}, Lcom/yhao/floatwindow/r;->e(II)V

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    iput p1, p0, Lcom/yhao/floatwindow/g$b;->a:F

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput p1, p0, Lcom/yhao/floatwindow/g$b;->b:F

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    goto/16 :goto_3

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v3

    const/4 v5, 0x6

    or-int/2addr v6, v5

    invoke-static {v0, v3}, Lcom/yhao/floatwindow/g;->u(Lcom/yhao/floatwindow/g;F)F

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result p2

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-static {v0, p2}, Lcom/yhao/floatwindow/g;->w(Lcom/yhao/floatwindow/g;F)F

    const/4 v6, 0x6

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x3

    invoke-static {p2}, Lcom/yhao/floatwindow/g;->t(Lcom/yhao/floatwindow/g;)F

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v3}, Lcom/yhao/floatwindow/g;->m(Lcom/yhao/floatwindow/g;)F

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    sub-float/2addr v0, v3

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    iget-object v3, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v3}, Lcom/yhao/floatwindow/g;->z(Lcom/yhao/floatwindow/g;)I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    int-to-float v3, v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    cmpl-float v0, v0, v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v3, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-gtz v0, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v0}, Lcom/yhao/floatwindow/g;->v(Lcom/yhao/floatwindow/g;)F

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v4, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v4}, Lcom/yhao/floatwindow/g;->p(Lcom/yhao/floatwindow/g;)F

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    sub-float/2addr v0, v4

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v4}, Lcom/yhao/floatwindow/g;->z(Lcom/yhao/floatwindow/g;)I

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    int-to-float v4, v4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    cmpl-float v0, v0, v4

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-lez v0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x7

    goto :goto_0

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    move v0, v3

    move v0, v3

    const/4 v6, 0x4

    move v0, v3

    move v0, v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto :goto_1

    :cond_4
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    move v0, v2

    const/4 v6, 0x3

    move v0, v2

    move v0, v2

    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {p2, v0}, Lcom/yhao/floatwindow/g;->y(Lcom/yhao/floatwindow/g;Z)Z

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object p2, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p2}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x1

    iget p2, p2, Lcom/yhao/floatwindow/e$a;->k:I

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v0, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eq p2, v0, :cond_6

    const/4 v5, 0x0

    move v6, v5

    const/4 p1, 0x4

    move v6, p1

    if-eq p2, p1, :cond_5

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto/16 :goto_3

    :cond_5
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->s(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/d;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/yhao/floatwindow/d;->b()I

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object p2, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {p2}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget p2, p2, Lcom/yhao/floatwindow/e$a;->g:I

    const/4 v6, 0x2

    filled-new-array {p1, p2}, [I

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo p2, "x"

    const-string/jumbo p2, "x"

    const/4 v6, 0x7

    const-string/jumbo p2, "x"

    const-string/jumbo p2, "x"

    const/4 v6, 0x0

    invoke-static {p2, p1}, Landroid/animation/PropertyValuesHolder;->ofInt(Ljava/lang/String;[I)Landroid/animation/PropertyValuesHolder;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object p2, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p2}, Lcom/yhao/floatwindow/g;->s(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/d;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p2}, Lcom/yhao/floatwindow/d;->c()I

    move-result p2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    iget v0, v0, Lcom/yhao/floatwindow/e$a;->h:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    filled-new-array {p2, v0}, [I

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v0, "y"

    const-string/jumbo v0, "y"

    const/4 v6, 0x5

    const-string/jumbo v0, "y"

    const-string/jumbo v0, "y"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0, p2}, Landroid/animation/PropertyValuesHolder;->ofInt(Ljava/lang/String;[I)Landroid/animation/PropertyValuesHolder;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-array v1, v1, [Landroid/animation/PropertyValuesHolder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    aput-object p1, v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    aput-object p2, v1, v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-static {v1}, Landroid/animation/ValueAnimator;->ofPropertyValuesHolder([Landroid/animation/PropertyValuesHolder;)Landroid/animation/ValueAnimator;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v0, p1}, Lcom/yhao/floatwindow/g;->B(Lcom/yhao/floatwindow/g;Landroid/animation/ValueAnimator;)Landroid/animation/ValueAnimator;

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->A(Lcom/yhao/floatwindow/g;)Landroid/animation/ValueAnimator;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    new-instance p2, Lcom/yhao/floatwindow/g$b$b;

    const/4 v6, 0x7

    invoke-direct {p2, p0}, Lcom/yhao/floatwindow/g$b$b;-><init>(Lcom/yhao/floatwindow/g$b;)V

    const/4 v6, 0x6

    invoke-virtual {p1, p2}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const/4 v5, 0x6

    move v6, v5

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->n(Lcom/yhao/floatwindow/g;)V

    const/4 v6, 0x3

    goto/16 :goto_3

    :cond_6
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object p2, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p2}, Lcom/yhao/floatwindow/g;->s(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/d;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p2}, Lcom/yhao/floatwindow/d;->b()I

    move-result p2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    mul-int/lit8 v0, p2, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    add-int/2addr v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v1, v1, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v6, 0x0

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/yhao/floatwindow/q;->b(Landroid/content/Context;)I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    if-le v0, v1, :cond_7

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/yhao/floatwindow/q;->b(Landroid/content/Context;)I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    sub-int/2addr v0, p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget p1, p1, Lcom/yhao/floatwindow/e$a;->m:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    sub-int/2addr v0, p1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_2

    :cond_7
    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget v0, p1, Lcom/yhao/floatwindow/e$a;->l:I

    :goto_2
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    filled-new-array {p2, v0}, [I

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-static {p2}, Landroid/animation/ValueAnimator;->ofInt([I)Landroid/animation/ValueAnimator;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {p1, p2}, Lcom/yhao/floatwindow/g;->B(Lcom/yhao/floatwindow/g;Landroid/animation/ValueAnimator;)Landroid/animation/ValueAnimator;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->A(Lcom/yhao/floatwindow/g;)Landroid/animation/ValueAnimator;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance p2, Lcom/yhao/floatwindow/g$b$a;

    const/4 v6, 0x6

    const/4 v5, 0x4

    invoke-direct {p2, p0}, Lcom/yhao/floatwindow/g$b$a;-><init>(Lcom/yhao/floatwindow/g$b;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p1, p2}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->n(Lcom/yhao/floatwindow/g;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto :goto_3

    :cond_8
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {p1, v0}, Lcom/yhao/floatwindow/g;->o(Lcom/yhao/floatwindow/g;F)F

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {p1, v0}, Lcom/yhao/floatwindow/g;->q(Lcom/yhao/floatwindow/g;F)F

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawX()F

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    iput p1, p0, Lcom/yhao/floatwindow/g$b;->a:F

    const/4 v6, 0x3

    invoke-virtual {p2}, Landroid/view/MotionEvent;->getRawY()F

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    iput p1, p0, Lcom/yhao/floatwindow/g$b;->b:F

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->r(Lcom/yhao/floatwindow/g;)V

    :goto_3
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object p1, p0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->x(Lcom/yhao/floatwindow/g;)Z

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    return p1
.end method
