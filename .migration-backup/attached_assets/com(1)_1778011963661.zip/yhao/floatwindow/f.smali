.class public abstract Lcom/yhao/floatwindow/f;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method abstract a()V
.end method

.method public abstract b()Landroid/view/View;
.end method

.method public abstract c()I
.end method

.method public abstract d()I
.end method

.method public abstract e()V
.end method

.method public abstract f()Z
.end method

.method public abstract g()V
.end method

.method public abstract h(I)V
.end method

.method public abstract i(IF)V
.end method

.method public abstract j(I)V
.end method

.method public abstract k(IF)V
.end method
