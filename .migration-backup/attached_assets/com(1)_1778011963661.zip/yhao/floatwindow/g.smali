.class public Lcom/yhao/floatwindow/g;
.super Lcom/yhao/floatwindow/f;


# instance fields
.field private a:Lcom/yhao/floatwindow/e$a;

.field private b:Lcom/yhao/floatwindow/d;

.field private c:Lcom/yhao/floatwindow/a;

.field private d:Z

.field private e:Z

.field private f:Landroid/animation/ValueAnimator;

.field private g:Landroid/animation/TimeInterpolator;

.field private h:F

.field private i:F

.field private j:F

.field private k:F

.field private l:Z

.field private m:I


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/yhao/floatwindow/f;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/yhao/floatwindow/g;->e:Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x4

    iput-boolean v0, p0, Lcom/yhao/floatwindow/g;->l:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method constructor <init>(Lcom/yhao/floatwindow/e$a;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/yhao/floatwindow/f;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-boolean v0, p0, Lcom/yhao/floatwindow/g;->e:Z

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput-boolean v0, p0, Lcom/yhao/floatwindow/g;->l:Z

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-object p1, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v5, 0x0

    iget v0, p1, Lcom/yhao/floatwindow/e$a;->k:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    if-nez v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/16 v1, 0x19

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-lt v0, v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance v0, Lcom/yhao/floatwindow/b;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v1, p1, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/yhao/floatwindow/e$a;->r:Lcom/yhao/floatwindow/l;

    const/4 v5, 0x3

    invoke-direct {v0, v1, p1}, Lcom/yhao/floatwindow/b;-><init>(Landroid/content/Context;Lcom/yhao/floatwindow/l;)V

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v0, Lcom/yhao/floatwindow/c;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object p1, p1, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {v0, p1}, Lcom/yhao/floatwindow/c;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-instance v0, Lcom/yhao/floatwindow/b;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v1, p1, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v4, 0x7

    move v5, v4

    iget-object p1, p1, Lcom/yhao/floatwindow/e$a;->r:Lcom/yhao/floatwindow/l;

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-direct {v0, v1, p1}, Lcom/yhao/floatwindow/b;-><init>(Landroid/content/Context;Lcom/yhao/floatwindow/l;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/yhao/floatwindow/g;->E()V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    iget v1, v0, Lcom/yhao/floatwindow/e$a;->d:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget v0, v0, Lcom/yhao/floatwindow/e$a;->e:I

    const/4 v5, 0x7

    invoke-virtual {p1, v1, v0}, Lcom/yhao/floatwindow/d;->f(II)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget v1, v0, Lcom/yhao/floatwindow/e$a;->f:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget v2, v0, Lcom/yhao/floatwindow/e$a;->g:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget v0, v0, Lcom/yhao/floatwindow/e$a;->h:I

    const/4 v4, 0x3

    and-int/2addr v5, v4

    invoke-virtual {p1, v1, v2, v0}, Lcom/yhao/floatwindow/d;->e(III)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v5, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->b:Landroid/view/View;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1, v0}, Lcom/yhao/floatwindow/d;->g(Landroid/view/View;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    new-instance p1, Lcom/yhao/floatwindow/a;

    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v1, v0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-boolean v2, v0, Lcom/yhao/floatwindow/e$a;->i:Z

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->j:[Ljava/lang/Class;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v3, Lcom/yhao/floatwindow/g$a;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {v3, p0}, Lcom/yhao/floatwindow/g$a;-><init>(Lcom/yhao/floatwindow/g;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {p1, v1, v2, v0, v3}, Lcom/yhao/floatwindow/a;-><init>(Landroid/content/Context;Z[Ljava/lang/Class;Lcom/yhao/floatwindow/h;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput-object p1, p0, Lcom/yhao/floatwindow/g;->c:Lcom/yhao/floatwindow/a;

    const/4 v4, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-void
.end method

.method static synthetic A(Lcom/yhao/floatwindow/g;)Landroid/animation/ValueAnimator;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/yhao/floatwindow/g;->f:Landroid/animation/ValueAnimator;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic B(Lcom/yhao/floatwindow/g;Landroid/animation/ValueAnimator;)Landroid/animation/ValueAnimator;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/yhao/floatwindow/g;->f:Landroid/animation/ValueAnimator;

    const/4 v1, 0x3

    return-object p1
.end method

.method private C()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->f:Landroid/animation/ValueAnimator;

    const/4 v2, 0x0

    const/4 v1, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->f:Landroid/animation/ValueAnimator;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->cancel()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method private D()V
    .locals 4

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v2, 0x6

    move v3, v2

    iget v0, v0, Lcom/yhao/floatwindow/e$a;->k:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    const-string/jumbo v1, "lwsoiltihaotetmnafo !t gFweo oits vdos osWnd   "

    const-string/jumbo v1, "ofsso  dodttinW gtas v llthamFooliinot! woe  we"

    const/4 v3, 0x2

    const-string/jumbo v1, "otimn ioo t otnFfooee wssv Wda!wtlialom gt hadl"

    const-string v1, "FloatWindow of this tag is not allowed to move!"

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    throw v0
.end method

.method private E()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v0, v0, Lcom/yhao/floatwindow/e$a;->k:I

    const/4 v2, 0x7

    move v3, v2

    const/4 v1, 0x1

    and-int/2addr v3, v1

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eq v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/yhao/floatwindow/g;->b()Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v1, Lcom/yhao/floatwindow/g$b;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/yhao/floatwindow/g$b;-><init>(Lcom/yhao/floatwindow/g;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method

.method private F()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->o:Landroid/animation/TimeInterpolator;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-nez v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->g:Landroid/animation/TimeInterpolator;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Landroid/view/animation/DecelerateInterpolator;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v0}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/yhao/floatwindow/g;->g:Landroid/animation/TimeInterpolator;

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/yhao/floatwindow/g;->g:Landroid/animation/TimeInterpolator;

    const/4 v4, 0x5

    const/4 v3, 0x1

    iput-object v1, v0, Lcom/yhao/floatwindow/e$a;->o:Landroid/animation/TimeInterpolator;

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->f:Landroid/animation/ValueAnimator;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v4, 0x1

    iget-object v1, v1, Lcom/yhao/floatwindow/e$a;->o:Landroid/animation/TimeInterpolator;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->f:Landroid/animation/ValueAnimator;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v1, Lcom/yhao/floatwindow/g$c;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v1, p0}, Lcom/yhao/floatwindow/g$c;-><init>(Lcom/yhao/floatwindow/g;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->f:Landroid/animation/ValueAnimator;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-wide v1, v1, Lcom/yhao/floatwindow/e$a;->n:J

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0}, Lcom/yhao/floatwindow/r;->d()V

    :cond_2
    const/4 v3, 0x6

    move v4, v3

    return-void
.end method

.method static synthetic l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;
    .locals 2

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v1, 0x0

    const/4 v0, 0x3

    return-object p0
.end method

.method static synthetic m(Lcom/yhao/floatwindow/g;)F
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget p0, p0, Lcom/yhao/floatwindow/g;->h:F

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic n(Lcom/yhao/floatwindow/g;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x6

    invoke-direct {p0}, Lcom/yhao/floatwindow/g;->F()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic o(Lcom/yhao/floatwindow/g;F)F
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p1, p0, Lcom/yhao/floatwindow/g;->h:F

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p1
.end method

.method static synthetic p(Lcom/yhao/floatwindow/g;)F
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    iget p0, p0, Lcom/yhao/floatwindow/g;->i:F

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic q(Lcom/yhao/floatwindow/g;F)F
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p1, p0, Lcom/yhao/floatwindow/g;->i:F

    const/4 v1, 0x7

    return p1
.end method

.method static synthetic r(Lcom/yhao/floatwindow/g;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/yhao/floatwindow/g;->C()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic s(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/d;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic t(Lcom/yhao/floatwindow/g;)F
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget p0, p0, Lcom/yhao/floatwindow/g;->j:F

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p0
.end method

.method static synthetic u(Lcom/yhao/floatwindow/g;F)F
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p1, p0, Lcom/yhao/floatwindow/g;->j:F

    const/4 v1, 0x0

    const/4 v0, 0x1

    return p1
.end method

.method static synthetic v(Lcom/yhao/floatwindow/g;)F
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget p0, p0, Lcom/yhao/floatwindow/g;->k:F

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic w(Lcom/yhao/floatwindow/g;F)F
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/yhao/floatwindow/g;->k:F

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return p1
.end method

.method static synthetic x(Lcom/yhao/floatwindow/g;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-boolean p0, p0, Lcom/yhao/floatwindow/g;->l:Z

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic y(Lcom/yhao/floatwindow/g;Z)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/yhao/floatwindow/g;->l:Z

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic z(Lcom/yhao/floatwindow/g;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget p0, p0, Lcom/yhao/floatwindow/g;->m:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p0
.end method


# virtual methods
.method a()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-virtual {v0}, Lcom/yhao/floatwindow/d;->a()V

    const/4 v2, 0x0

    const/4 v0, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/yhao/floatwindow/g;->d:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    invoke-interface {v0}, Lcom/yhao/floatwindow/r;->onDismiss()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public b()Landroid/view/View;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v2, 0x0

    const/4 v1, 0x2

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput v0, p0, Lcom/yhao/floatwindow/g;->m:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->b:Landroid/view/View;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-virtual {v0}, Lcom/yhao/floatwindow/d;->b()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-virtual {v0}, Lcom/yhao/floatwindow/d;->c()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public e()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-boolean v0, p0, Lcom/yhao/floatwindow/g;->e:Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-boolean v0, p0, Lcom/yhao/floatwindow/g;->d:Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/yhao/floatwindow/g;->b()Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    iput-boolean v0, p0, Lcom/yhao/floatwindow/g;->d:Z

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Lcom/yhao/floatwindow/r;->b()V

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/yhao/floatwindow/g;->d:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public g()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-boolean v0, p0, Lcom/yhao/floatwindow/g;->e:Z

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/yhao/floatwindow/d;->d()V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput-boolean v2, p0, Lcom/yhao/floatwindow/g;->e:Z

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-boolean v1, p0, Lcom/yhao/floatwindow/g;->d:Z

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    move v4, v3

    iget-boolean v0, p0, Lcom/yhao/floatwindow/g;->d:Z

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/yhao/floatwindow/g;->b()Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-boolean v1, p0, Lcom/yhao/floatwindow/g;->d:Z

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-interface {v0}, Lcom/yhao/floatwindow/r;->c()V

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void
.end method

.method public h(I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/yhao/floatwindow/g;->D()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput p1, v0, Lcom/yhao/floatwindow/e$a;->g:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {v0, p1}, Lcom/yhao/floatwindow/d;->h(I)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public i(IF)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/yhao/floatwindow/g;->D()V

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v1, 0x7

    or-int/2addr v2, v1

    if-nez p1, :cond_0

    const/4 v2, 0x5

    iget-object p1, v0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->b(Landroid/content/Context;)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    iget-object p1, v0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->a(Landroid/content/Context;)I

    move-result p1

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    int-to-float p1, p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    mul-float/2addr p1, p2

    const/4 v2, 0x3

    const/4 v1, 0x5

    float-to-int p1, p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    iput p1, v0, Lcom/yhao/floatwindow/e$a;->g:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object p2, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget p2, p2, Lcom/yhao/floatwindow/e$a;->g:I

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Lcom/yhao/floatwindow/d;->h(I)V

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public j(I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/yhao/floatwindow/g;->D()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput p1, v0, Lcom/yhao/floatwindow/e$a;->h:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/yhao/floatwindow/d;->j(I)V

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public k(IF)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/yhao/floatwindow/g;->D()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object p1, v0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->b(Landroid/content/Context;)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object p1, v0, Lcom/yhao/floatwindow/e$a;->a:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/yhao/floatwindow/q;->a(Landroid/content/Context;)I

    move-result p1

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    int-to-float p1, p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    mul-float/2addr p1, p2

    const/4 v2, 0x7

    float-to-int p1, p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput p1, v0, Lcom/yhao/floatwindow/e$a;->h:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/yhao/floatwindow/g;->b:Lcom/yhao/floatwindow/d;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/yhao/floatwindow/g;->a:Lcom/yhao/floatwindow/e$a;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget p2, p2, Lcom/yhao/floatwindow/e$a;->h:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1, p2}, Lcom/yhao/floatwindow/d;->j(I)V

    const/4 v2, 0x3

    return-void
.end method
