.class Lcom/yhao/floatwindow/g$b$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yhao/floatwindow/g$b;->onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/yhao/floatwindow/g$b;


# direct methods
.method constructor <init>(Lcom/yhao/floatwindow/g$b;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/yhao/floatwindow/g$b$a;->a:Lcom/yhao/floatwindow/g$b;

    const/4 v0, 0x0

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "bns v ~t~b@~~ocdK@ M  r@~~@ @so@Sf 4~@@o~ @~@~a~ ~o@i@m~uo@@~~l@~@~ @ y./fb~i~~@1-@ ~lit@~/o    "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast p1, Ljava/lang/Integer;

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/yhao/floatwindow/g$b$a;->a:Lcom/yhao/floatwindow/g$b;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, v0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/yhao/floatwindow/g;->s(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/d;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/yhao/floatwindow/d;->h(I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/yhao/floatwindow/g$b$a;->a:Lcom/yhao/floatwindow/g$b;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, v0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/yhao/floatwindow/g$b$a;->a:Lcom/yhao/floatwindow/g$b;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, v0, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, v0, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/yhao/floatwindow/g$b$a;->a:Lcom/yhao/floatwindow/g$b;

    const/4 v3, 0x3

    iget-object v1, v1, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-static {v1}, Lcom/yhao/floatwindow/g;->v(Lcom/yhao/floatwindow/g;)F

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    float-to-int v1, v1

    const/4 v2, 0x4

    and-int/2addr v3, v2

    invoke-interface {v0, p1, v1}, Lcom/yhao/floatwindow/r;->e(II)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method
