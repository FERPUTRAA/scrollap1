.class Lcom/yhao/floatwindow/o;
.super Ljava/lang/Object;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "los-~t.~c~ ~~~1i r@b~@@ /m~S@bfo   ~ f~ d@ ~M~a@l~o~~~@so  @~~4n ~@~ ib@~/oK@@ @@tvy oi@@~@@  @u"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const-string/jumbo v3, "oetmg rs"

    const-string/jumbo v3, "r sotgpe"

    const/4 v5, 0x0

    const-string/jumbo v3, "gop oert"

    const-string/jumbo v3, "getprop "

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v1, Ljava/io/BufferedReader;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v2, Ljava/io/InputStreamReader;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/Process;->getInputStream()Ljava/io/InputStream;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {v2, p0}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/16 p0, 0x400

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {v1, v2, p0}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_3
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    move-object v0, v1

    move-object v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_1

    :catchall_1
    move-exception p0

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    :try_start_3
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    goto :goto_2

    :catch_1
    move-exception v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_2
    const/4 v5, 0x3

    throw p0

    :catch_2
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :catch_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v1, :cond_1

    :try_start_4
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_4

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_3

    :catch_4
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_3
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-object v0
.end method

.method static b(Landroid/content/Intent;Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/high16 v0, 0x10000

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1, p0, v0}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-lez p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 p0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 p0, 0x2

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p0
.end method
