.class Lcom/yhao/floatwindow/j;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "ro.miui.ui.version.name"

.field private static final b:Ljava/lang/String; = "V5"

.field private static final c:Ljava/lang/String; = "V6"

.field private static final d:Ljava/lang/String; = "V7"

.field private static final e:Ljava/lang/String; = "V8"

.field private static final f:Ljava/lang/String; = "V9"

.field private static g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/yhao/floatwindow/l;",
            ">;"
        }
    .end annotation
.end field

.field private static h:Lcom/yhao/floatwindow/l;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic a()Ljava/util/List;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i1s- @o@~@@t   o@~~~n~@i~.@@@~~@t~l ~i@  o ~~v~~4 ~o~~l @d@@oKc r@  /S~@@ / @ybfmo~b @~abs~ @~Mu"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lcom/yhao/floatwindow/j;->g:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic b()Lcom/yhao/floatwindow/l;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lcom/yhao/floatwindow/j;->h:Lcom/yhao/floatwindow/l;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method private static c(Landroid/view/WindowManager;Landroid/view/View;Landroid/view/WindowManager$LayoutParams;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/yhao/floatwindow/j;->k(Z)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {p0, p1, p2}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v1, 0x6

    move v2, v1

    invoke-static {p0}, Lcom/yhao/floatwindow/j;->k(Z)V

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method

.method private static d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string/jumbo v0, "ue.momisiiavmso.einrr.u"

    const-string/jumbo v0, "irsviu.ronou.emeins.ima"

    const/4 v2, 0x5

    const-string/jumbo v0, "iurroieois.aniumv.eo.n."

    const-string/jumbo v0, "ro.miui.ui.version.name"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/yhao/floatwindow/o;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method static e(Landroid/content/Context;Lcom/yhao/floatwindow/l;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/yhao/floatwindow/m;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {p1}, Lcom/yhao/floatwindow/l;->onSuccess()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget-object v0, Lcom/yhao/floatwindow/j;->g:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    sput-object v0, Lcom/yhao/floatwindow/j;->g:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance v0, Lcom/yhao/floatwindow/j$a;

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/yhao/floatwindow/j$a;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    sput-object v0, Lcom/yhao/floatwindow/j;->h:Lcom/yhao/floatwindow/l;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/yhao/floatwindow/j;->i(Landroid/content/Context;)V

    :cond_1
    const/4 v2, 0x2

    sget-object p0, Lcom/yhao/floatwindow/j;->g:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method private static f(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x3

    shr-int/2addr v5, v4

    const-string/jumbo v2, "t.iSTb.L_rITPCdN_TaTGsdeOnIAEStAIDgmAsioIPNnS"

    const-string/jumbo v2, "n.SmASDeiIECLPtgaAsTGSANTtIdN_PITidLs_.OoInrT"

    const/4 v5, 0x4

    const-string/jumbo v2, "irPsI.uPEoNTOi_GeSSTAgADSnadtI.LNEAdIt_TTLsIn"

    const-string v2, "android.settings.APPLICATION_DETAILS_SETTINGS"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo v2, "pgpaeao"

    const-string v2, "aepcoga"

    const/4 v5, 0x4

    const-string/jumbo v2, "gqapeck"

    const-string/jumbo v2, "package"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    move v5, v3

    const/4 v4, 0x3

    move v5, v4

    invoke-static {v2, v0, v3}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/high16 v0, 0x10000000

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v1, p0}, Lcom/yhao/floatwindow/o;->b(Landroid/content/Intent;Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo p0, "ias bblens ntetnavitl!oi"

    const-string p0, "eo anbvleatlnttiaiin!sb "

    const/4 v5, 0x4

    const-string/jumbo p0, "i amtseatltanon nve!bii "

    const-string/jumbo p0, "intent is not available!"

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/yhao/floatwindow/i;->b(Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void
.end method

.method private static g(Landroid/content/Context;)V
    .locals 5

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo v1, "unuPoim_RoainDAciI..ERP_TtePttn.OM"

    const-string v1, "PTtPeDuEoimiR.EPnt_MOiu..nRnIAca_t"

    const/4 v4, 0x2

    const-string/jumbo v1, "u.nRIbiEAt.ttPMcaTPoEiPO_n_imRD.ni"

    const-string/jumbo v1, "miui.intent.action.APP_PERM_EDITOR"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v1, "ucmmruuoceii..renitpyst"

    const-string/jumbo v1, "misycmnp.ruiuetce.oietr"

    const/4 v4, 0x6

    const-string/jumbo v1, "iueysocpmtc.cemtrurein."

    const-string v1, "com.miui.securitycenter"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v2, "iorpsiqoqnsictecmEdimr.eierisuivPrp.tpypssAtAmmtmcioe.inns.e"

    const-string v2, "cosvumpiqeepeAssytirs.mPoirmsi.itro.nEmciprpm.tAnesdoincitie"

    const/4 v4, 0x0

    const-string/jumbo v2, "iussi.isceEotmos.m.iiicrtsoptsnepdr.revsPirermptnAnocpmiAmie"

    const-string v2, "com.miui.permcenter.permissions.AppPermissionsEditorActivity"

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string v2, "_epmsxknagrem"

    const-string/jumbo v2, "ras_kxnaemepg"

    const-string/jumbo v2, "g_reoxntameap"

    const-string/jumbo v2, "extra_pkgname"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/high16 v1, 0x10000000

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-static {v0, p0}, Lcom/yhao/floatwindow/o;->b(Landroid/content/Intent;Landroid/content/Context;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const-string p0, " eonnbv!teiitblains lma "

    const-string/jumbo p0, "on mtiaanilae vilne!tsb "

    const/4 v4, 0x5

    const-string p0, "e itilu!oanvebit tnalsn "

    const-string/jumbo p0, "intent is not available!"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/yhao/floatwindow/i;->b(Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void
.end method

.method private static h(Landroid/content/Context;)V
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string v1, "PERPuRnpP._Iomi_AtTOti.tDMEioc.iae"

    const-string v1, "P.iEo_tAeEPiu_nanDPotROi.T.MiRIctm"

    const/4 v7, 0x0

    const-string v1, "_iitPR_RqOEan.DiPEIiTnoMmuAtt.cPen"

    const-string/jumbo v1, "miui.intent.action.APP_PERM_EDITOR"

    const/4 v7, 0x6

    const/4 v6, 0x0

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string/jumbo v2, "iistetvitonreibcriy.sAuenmmsosc.rirEossPmmtcm.oeipseipri."

    const-string/jumbo v2, "srrvtbosmeism.etPsoiiAcmti..ie.psieindomeyErotrupcrmsinic"

    const/4 v7, 0x0

    const-string v2, "com.miui.permcenter.permissions.PermissionsEditorActivity"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string v3, "ctemni.uomsccyuertrmuei"

    const-string v3, ".oymciucumrenuisctrtee."

    const-string v3, "com.miui.securitycenter"

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0, v3, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v4, "mantog_pkeape"

    const-string/jumbo v4, "nergktmpeaap_"

    const/4 v7, 0x2

    const-string/jumbo v4, "tpagnbrxaemek"

    const-string/jumbo v4, "extra_pkgname"

    const/4 v7, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0, v4, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/high16 v2, 0x10000000

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v7, 0x2

    invoke-static {v0, p0}, Lcom/yhao/floatwindow/o;->b(Landroid/content/Intent;Landroid/content/Context;)Z

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x6

    if-eqz v5, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v7, 0x2

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, v4, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {v0, p0}, Lcom/yhao/floatwindow/o;->b(Landroid/content/Intent;Landroid/content/Context;)Z

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v1, :cond_1

    const/4 v7, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string/jumbo p0, "iilqlau! tib vnnes notat"

    const-string p0, "btstnivlq !naia  eeinolt"

    const-string/jumbo p0, "iteae tpll tb!isavaionn "

    const-string/jumbo p0, "intent is not available!"

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {p0}, Lcom/yhao/floatwindow/i;->b(Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    return-void
.end method

.method private static i(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {}, Lcom/yhao/floatwindow/j;->d()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v2, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    packed-switch v1, :pswitch_data_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto/16 :goto_0

    :pswitch_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const-string v1, "9V"

    const-string v1, "9V"

    const/4 v4, 0x0

    const-string v1, "V9"

    const-string v1, "V9"

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    goto/16 :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto/16 :goto_0

    :pswitch_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v1, "V8"

    const-string v1, "8V"

    const-string v1, "V8"

    const-string v1, "V8"

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x3

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :pswitch_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string v1, "7V"

    const-string v1, "7V"

    const/4 v4, 0x1

    const-string v1, "7V"

    const-string v1, "V7"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-nez v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v2, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :pswitch_3
    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string v1, "6V"

    const-string v1, "V6"

    const/4 v4, 0x3

    const-string v1, "V6"

    const-string v1, "V6"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x5

    or-int/2addr v4, v3

    if-nez v0, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_0

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_0

    :pswitch_4
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string v1, "5V"

    const-string v1, "5V"

    const/4 v4, 0x6

    const-string v1, "V5"

    const-string v1, "V5"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez v0, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_0

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    packed-switch v2, :pswitch_data_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_1

    :pswitch_5
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/yhao/floatwindow/j;->h(Landroid/content/Context;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto :goto_1

    :pswitch_6
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/yhao/floatwindow/j;->g(Landroid/content/Context;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto :goto_1

    :pswitch_7
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/yhao/floatwindow/j;->f(Landroid/content/Context;)V

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v0, Lcom/yhao/floatwindow/j$b;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0, p0}, Lcom/yhao/floatwindow/j$b;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/yhao/floatwindow/a;->e(Lcom/yhao/floatwindow/n;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0xa9f
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_6
        :pswitch_5
        :pswitch_5
    .end packed-switch
.end method

.method static j()Z
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string v1, ":i u sMiq"

    const-string v1, ":isMu i  "

    const/4 v3, 0x3

    const-string v1, "  s :Miu "

    const-string v1, " Miui  : "

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {}, Lcom/yhao/floatwindow/j;->d()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/yhao/floatwindow/i;->a(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v1, "oiXmmm"

    const-string v1, "aoimXm"

    const/4 v3, 0x0

    const-string/jumbo v1, "maiXoi"

    const-string v1, "Xiaomi"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    return v0
.end method

.method private static k(Z)V
    .locals 4

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string v0, "dlB.obiums.ui"

    const-string/jumbo v0, "miui.os.Build"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string v1, "IS_INTERNATIONAL_BUILD"

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p0}, Ljava/lang/reflect/Field;->setBoolean(Ljava/lang/Object;Z)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method
