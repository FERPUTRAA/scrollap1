.class Lcom/yhao/floatwindow/g$b$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yhao/floatwindow/g$b;->onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/yhao/floatwindow/g$b;


# direct methods
.method constructor <init>(Lcom/yhao/floatwindow/g$b;)V
    .locals 2

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/yhao/floatwindow/g$b$b;->a:Lcom/yhao/floatwindow/g$b;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s @~s@@~~~@SM @-d i@ K/b i~~@o~@om ~~no4~ l~t@ o1@ ua~~@ b@@bf~~y@@  r~fto@i vo ~~.~ c@~ @l/@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    const-string/jumbo v0, "x"

    const-string/jumbo v0, "x"

    const-string/jumbo v0, "x"

    const-string/jumbo v0, "x"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Landroid/animation/ValueAnimator;->getAnimatedValue(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const-string/jumbo v1, "y"

    const/4 v3, 0x7

    const-string/jumbo v1, "y"

    const-string/jumbo v1, "y"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, v1}, Landroid/animation/ValueAnimator;->getAnimatedValue(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast p1, Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/yhao/floatwindow/g$b$b;->a:Lcom/yhao/floatwindow/g$b;

    const/4 v3, 0x1

    iget-object v1, v1, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/yhao/floatwindow/g;->s(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/d;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v1, v0, p1}, Lcom/yhao/floatwindow/d;->i(II)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/yhao/floatwindow/g$b$b;->a:Lcom/yhao/floatwindow/g$b;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, v1, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-static {v1}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, v1, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/yhao/floatwindow/g$b$b;->a:Lcom/yhao/floatwindow/g$b;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v1, v1, Lcom/yhao/floatwindow/g$b;->g:Lcom/yhao/floatwindow/g;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v1}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, v1, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v2, 0x5

    move v3, v2

    invoke-interface {v1, v0, p1}, Lcom/yhao/floatwindow/r;->e(II)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method
