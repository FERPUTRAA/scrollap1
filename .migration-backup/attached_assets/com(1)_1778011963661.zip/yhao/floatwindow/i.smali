.class Lcom/yhao/floatwindow/i;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "FloatWindow"


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method static a(Ljava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~so- i@ti @~~~/. l@ b ~mv a~b ~f ~@b @1@~@Kor~~/ ~~~n @l@4~S@i@ ~~fd@@yc@oo@ o~@Mt@ @~u@~~ ~so@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const-string/jumbo v0, "odimWoawstF"

    const-string v0, "dtsolWioFaw"

    const/4 v2, 0x6

    const-string v0, "dltioFWonow"

    const-string v0, "FloatWindow"

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-static {v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method static b(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const-string v0, "WtoiFbmoadl"

    const-string/jumbo v0, "laWmwdtoiFo"

    const/4 v2, 0x7

    const-string v0, "WodiwluntaF"

    const-string v0, "FloatWindow"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method
