.class final Lcom/yhao/floatwindow/j$b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/yhao/floatwindow/n;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yhao/floatwindow/j;->i(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/yhao/floatwindow/j$b;->a:Landroid/content/Context;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@os@ litfo~~rK~ b ~~@@@b~/m~~ @i  o@Sfil~ ~@@~~n  o @~a@d4@ @o@~s  -~M ~  @o/c@b~. ~t~@y1~~v@u@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/yhao/floatwindow/j$b;->a:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/yhao/floatwindow/m;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {}, Lcom/yhao/floatwindow/j;->b()Lcom/yhao/floatwindow/l;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0}, Lcom/yhao/floatwindow/l;->onSuccess()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-static {}, Lcom/yhao/floatwindow/j;->b()Lcom/yhao/floatwindow/l;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {v0}, Lcom/yhao/floatwindow/l;->onFail()V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method
