.class interface abstract Lcom/yhao/floatwindow/n;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()V
.end method
