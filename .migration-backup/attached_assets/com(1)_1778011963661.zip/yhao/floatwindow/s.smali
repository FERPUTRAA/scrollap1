.class public Lcom/yhao/floatwindow/s;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/yhao/floatwindow/r;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b st @1Mn~@~v@    ~@o~ S@@b/@~~~fsy4u  ~~oK~ r/@tm@a @l@@@o .~@@-~@~od~ ~~oli@@i @~  b~@~ ~~c~of"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    return-void
.end method

.method public b()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-void
.end method

.method public c()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public d()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public e(II)V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method public f()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    return-void
.end method

.method public onDismiss()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method
