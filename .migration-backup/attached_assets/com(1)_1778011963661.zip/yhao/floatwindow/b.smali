.class Lcom/yhao/floatwindow/b;
.super Lcom/yhao/floatwindow/d;


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Landroid/view/WindowManager;

.field private final c:Landroid/view/WindowManager$LayoutParams;

.field private d:Landroid/view/View;

.field private e:I

.field private f:I

.field private g:Z

.field private h:Lcom/yhao/floatwindow/l;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/yhao/floatwindow/l;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/yhao/floatwindow/d;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    iput-boolean v0, p0, Lcom/yhao/floatwindow/b;->g:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/yhao/floatwindow/b;->a:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/yhao/floatwindow/b;->h:Lcom/yhao/floatwindow/l;

    const/4 v2, 0x3

    const-string/jumbo p2, "wdssoi"

    const-string/jumbo p2, "wosiwd"

    const/4 v2, 0x2

    const-string/jumbo p2, "window"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p1, Landroid/view/WindowManager;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/yhao/floatwindow/b;->b:Landroid/view/WindowManager;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance p1, Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p1}, Landroid/view/WindowManager$LayoutParams;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/yhao/floatwindow/b;->c:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 p2, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput p2, p1, Landroid/view/WindowManager$LayoutParams;->format:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/16 p2, 0x228

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput p2, p1, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput v0, p1, Landroid/view/WindowManager$LayoutParams;->windowAnimations:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method static synthetic k(Lcom/yhao/floatwindow/b;)Landroid/view/View;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@lmo ~o~@l~vto i~ @bi~o~ @y   @s@@r~a~@4~@i1~f~  ~~@ @do S/@b@n~ o u   @~tK@-/M@~~~@@~.m cb~@f~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/yhao/floatwindow/b;->d:Landroid/view/View;

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic l(Lcom/yhao/floatwindow/b;)Landroid/view/WindowManager$LayoutParams;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/yhao/floatwindow/b;->c:Landroid/view/WindowManager$LayoutParams;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic m(Lcom/yhao/floatwindow/b;)Landroid/view/WindowManager;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/yhao/floatwindow/b;->b:Landroid/view/WindowManager;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic n(Lcom/yhao/floatwindow/b;)Lcom/yhao/floatwindow/l;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/yhao/floatwindow/b;->h:Lcom/yhao/floatwindow/l;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p0
.end method

.method private o()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/16 v1, 0x1a

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/yhao/floatwindow/b;->c:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/16 v1, 0x7f6

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->type:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/yhao/floatwindow/b;->c:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 v1, 0x7d2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->type:I

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/yhao/floatwindow/b;->a:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v1, Lcom/yhao/floatwindow/b$b;

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-direct {v1, p0}, Lcom/yhao/floatwindow/b$b;-><init>(Lcom/yhao/floatwindow/b;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/yhao/floatwindow/FloatActivity;->b(Landroid/content/Context;Lcom/yhao/floatwindow/l;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x0

    move v2, v0

    move v2, v0

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/yhao/floatwindow/b;->g:Z

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/yhao/floatwindow/b;->b:Landroid/view/WindowManager;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/yhao/floatwindow/b;->d:Landroid/view/View;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method b()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/yhao/floatwindow/b;->e:I

    const/4 v1, 0x7

    move v2, v1

    return v0
.end method

.method c()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lcom/yhao/floatwindow/b;->f:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public d()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/16 v1, 0x19

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-lt v0, v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/yhao/floatwindow/b;->o()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {}, Lcom/yhao/floatwindow/j;->j()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/yhao/floatwindow/b;->o()V

    goto :goto_0

    :cond_1
    :try_start_0
    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/yhao/floatwindow/b;->c:Landroid/view/WindowManager$LayoutParams;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/16 v1, 0x7d5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->type:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/yhao/floatwindow/b;->b:Landroid/view/WindowManager;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/yhao/floatwindow/b;->d:Landroid/view/View;

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-interface {v1, v2, v0}, Landroid/view/ViewManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :catch_0
    const/4 v4, 0x4

    iget-object v0, p0, Lcom/yhao/floatwindow/b;->b:Landroid/view/WindowManager;

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/yhao/floatwindow/b;->d:Landroid/view/View;

    invoke-interface {v0, v1}, Landroid/view/ViewManager;->removeView(Landroid/view/View;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v0, " 5uYo_A28T/O5d9Tu/P3E1m"

    const-string v0, "P3/mO u8uY95Ad12S5E/TT_"

    const/4 v4, 0x3

    const-string v0, " 3TE1bu/5OdPT/9SuY58_A2"

    const-string v0, "TYPE_TOAST \u5931\u8d25"

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/yhao/floatwindow/i;->b(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/yhao/floatwindow/b;->o()V

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void
.end method

.method public e(III)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/yhao/floatwindow/b;->c:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->gravity:I

    const/4 v2, 0x1

    iput p2, p0, Lcom/yhao/floatwindow/b;->e:I

    const/4 v1, 0x3

    or-int/2addr v2, v1

    iput p2, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    iput p3, p0, Lcom/yhao/floatwindow/b;->f:I

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput p3, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public f(II)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/yhao/floatwindow/b;->c:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput p2, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public g(Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/yhao/floatwindow/b;->d:Landroid/view/View;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method h(I)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-boolean v0, p0, Lcom/yhao/floatwindow/b;->g:Z

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/yhao/floatwindow/b;->c:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput p1, p0, Lcom/yhao/floatwindow/b;->e:I

    const/4 v3, 0x2

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/yhao/floatwindow/b;->b:Landroid/view/WindowManager;

    const/4 v3, 0x6

    const/4 v2, 0x3

    iget-object v1, p0, Lcom/yhao/floatwindow/b;->d:Landroid/view/View;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {p1, v1, v0}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method public i(II)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/yhao/floatwindow/b;->g:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/yhao/floatwindow/b;->c:Landroid/view/WindowManager$LayoutParams;

    const/4 v2, 0x6

    iput p1, p0, Lcom/yhao/floatwindow/b;->e:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput p2, p0, Lcom/yhao/floatwindow/b;->f:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput p2, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/yhao/floatwindow/b;->b:Landroid/view/WindowManager;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/yhao/floatwindow/b;->d:Landroid/view/View;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {p1, p2, v0}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method j(I)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-boolean v0, p0, Lcom/yhao/floatwindow/b;->g:Z

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/yhao/floatwindow/b;->c:Landroid/view/WindowManager$LayoutParams;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput p1, p0, Lcom/yhao/floatwindow/b;->f:I

    const/4 v3, 0x3

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/yhao/floatwindow/b;->b:Landroid/view/WindowManager;

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/yhao/floatwindow/b;->d:Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {p1, v1, v0}, Landroid/view/ViewManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method
