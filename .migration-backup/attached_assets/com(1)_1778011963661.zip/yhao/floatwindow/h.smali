.class interface abstract Lcom/yhao/floatwindow/h;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method

.method public abstract c()V
.end method
