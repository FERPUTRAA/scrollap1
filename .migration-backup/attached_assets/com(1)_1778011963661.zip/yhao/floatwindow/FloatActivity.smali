.class public Lcom/yhao/floatwindow/FloatActivity;
.super Landroid/app/Activity;


# static fields
.field private static a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/yhao/floatwindow/l;",
            ">;"
        }
    .end annotation
.end field

.field private static b:Lcom/yhao/floatwindow/l;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a()Ljava/util/List;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "obs ~@/~  ar@~ .t~@S~ @ Mt@bi@~f~@~~ @n bK o@  @ ~moo4@~o@ ovy~i ~@  f~~l@s~1d~@~-~@~c@i@u/@~~ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/yhao/floatwindow/FloatActivity;->a:Ljava/util/List;

    const/4 v2, 0x3

    return-object v0
.end method

.method static declared-synchronized b(Landroid/content/Context;Lcom/yhao/floatwindow/l;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-class v0, Lcom/yhao/floatwindow/FloatActivity;

    const-class v0, Lcom/yhao/floatwindow/FloatActivity;

    const/4 v4, 0x3

    const-class v0, Lcom/yhao/floatwindow/FloatActivity;

    const-class v0, Lcom/yhao/floatwindow/FloatActivity;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/yhao/floatwindow/m;->a(Landroid/content/Context;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {p1}, Lcom/yhao/floatwindow/l;->onSuccess()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void

    :cond_0
    :try_start_1
    const/4 v3, 0x7

    const/4 v4, 0x0

    sget-object v1, Lcom/yhao/floatwindow/FloatActivity;->a:Ljava/util/List;

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    if-nez v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v1, Ljava/util/ArrayList;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x6

    sput-object v1, Lcom/yhao/floatwindow/FloatActivity;->a:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v1, Lcom/yhao/floatwindow/FloatActivity$a;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v1}, Lcom/yhao/floatwindow/FloatActivity$a;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    sput-object v1, Lcom/yhao/floatwindow/FloatActivity;->b:Lcom/yhao/floatwindow/l;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-class v2, Lcom/yhao/floatwindow/FloatActivity;

    const-class v2, Lcom/yhao/floatwindow/FloatActivity;

    const/4 v4, 0x7

    const-class v2, Lcom/yhao/floatwindow/FloatActivity;

    const-class v2, Lcom/yhao/floatwindow/FloatActivity;

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    invoke-direct {v1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/high16 v2, 0x10000000

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v4, 0x6

    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-object p0, Lcom/yhao/floatwindow/FloatActivity;->a:Ljava/util/List;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    throw p0
.end method

.method private c()V
    .locals 5
    .annotation build Landroidx/annotation/w0;
        api = 0x17
    .end annotation

    const/4 v4, 0x5

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string v1, "d_GmEsAMRMatoPSInAdEaOLREV.YoOteAnsrSsicInN_..tii"

    const-string/jumbo v1, "t_sEnn.O.AcVoAgRnSSEarItasIdiAOoN.i_PMEedGsLYRMit"

    const/4 v4, 0x3

    const-string v1, "SOL.oYERnttVcArtAsR.diOdeEIoN.igsNIiMP_GnaSM_anEo"

    const-string v1, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v2, ":ceagbak"

    const-string v2, "cagmek:a"

    const/4 v4, 0x4

    const-string/jumbo v2, "package:"

    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const v1, 0x2d133014

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x4

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    const/4 v0, 0x3

    move v1, v0

    const p2, 0x2d133014

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    if-ne p1, p2, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/yhao/floatwindow/m;->d(Landroid/content/Context;)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    sget-object p1, Lcom/yhao/floatwindow/FloatActivity;->b:Lcom/yhao/floatwindow/l;

    const/4 v1, 0x5

    invoke-interface {p1}, Lcom/yhao/floatwindow/l;->onSuccess()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    sget-object p1, Lcom/yhao/floatwindow/FloatActivity;->b:Lcom/yhao/floatwindow/l;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-interface {p1}, Lcom/yhao/floatwindow/l;->onFail()V

    :cond_1
    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/yhao/floatwindow/FloatActivity;->c()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-void
.end method
