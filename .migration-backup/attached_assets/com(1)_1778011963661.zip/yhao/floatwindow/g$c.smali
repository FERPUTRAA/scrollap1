.class Lcom/yhao/floatwindow/g$c;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/yhao/floatwindow/g;->F()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/yhao/floatwindow/g;


# direct methods
.method constructor <init>(Lcom/yhao/floatwindow/g;)V
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    iput-object p1, p0, Lcom/yhao/floatwindow/g$c;->a:Lcom/yhao/floatwindow/g;

    const/4 v1, 0x1

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s@ o~~~@@~il~ @o@@@@bol/~o @ c~ @~.ifot~4~ f~@@u rd-@~~@  y@m@b~@~~ ~ o1@t a  ~@ M~sbSiv  /~~K"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p1, p0, Lcom/yhao/floatwindow/g$c;->a:Lcom/yhao/floatwindow/g;

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->A(Lcom/yhao/floatwindow/g;)Landroid/animation/ValueAnimator;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->removeAllUpdateListeners()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/yhao/floatwindow/g$c;->a:Lcom/yhao/floatwindow/g;

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->A(Lcom/yhao/floatwindow/g;)Landroid/animation/ValueAnimator;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/animation/Animator;->removeAllListeners()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/yhao/floatwindow/g$c;->a:Lcom/yhao/floatwindow/g;

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    shl-int/2addr v1, v0

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lcom/yhao/floatwindow/g;->B(Lcom/yhao/floatwindow/g;Landroid/animation/ValueAnimator;)Landroid/animation/ValueAnimator;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/yhao/floatwindow/g$c;->a:Lcom/yhao/floatwindow/g;

    const/4 v1, 0x2

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object p1, p1, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/yhao/floatwindow/g$c;->a:Lcom/yhao/floatwindow/g;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/yhao/floatwindow/g;->l(Lcom/yhao/floatwindow/g;)Lcom/yhao/floatwindow/e$a;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object p1, p1, Lcom/yhao/floatwindow/e$a;->s:Lcom/yhao/floatwindow/r;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {p1}, Lcom/yhao/floatwindow/r;->f()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    return-void
.end method
