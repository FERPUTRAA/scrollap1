.class Lcom/yhao/floatwindow/q;
.super Ljava/lang/Object;


# static fields
.field private static a:Landroid/graphics/Point;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method static a(Landroid/content/Context;)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ts@~f i4@c@@@lv~s    .~o~~~o@~~o@~o@ @ia-~b@ @bodf~@~Snm/~@ i   ~ ~  @l~o~@t/1~uK@@~ ~  ~y~@r@M"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/yhao/floatwindow/q;->a:Landroid/graphics/Point;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    new-instance v0, Landroid/graphics/Point;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    sput-object v0, Lcom/yhao/floatwindow/q;->a:Landroid/graphics/Point;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string v0, "dnsmwo"

    const-string/jumbo v0, "insdwo"

    const-string/jumbo v0, "wdwoon"

    const-string/jumbo v0, "window"

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast p0, Landroid/view/WindowManager;

    const/4 v1, 0x5

    const/4 v1, 0x2

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    sget-object v0, Lcom/yhao/floatwindow/q;->a:Landroid/graphics/Point;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/view/Display;->getSize(Landroid/graphics/Point;)V

    :cond_0
    const/4 v2, 0x6

    sget-object p0, Lcom/yhao/floatwindow/q;->a:Landroid/graphics/Point;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget p0, p0, Landroid/graphics/Point;->y:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return p0
.end method

.method static b(Landroid/content/Context;)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Lcom/yhao/floatwindow/q;->a:Landroid/graphics/Point;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x4

    new-instance v0, Landroid/graphics/Point;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    const/4 v2, 0x4

    sput-object v0, Lcom/yhao/floatwindow/q;->a:Landroid/graphics/Point;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string v0, "dnmowb"

    const-string/jumbo v0, "nwomdw"

    const/4 v2, 0x4

    const-string/jumbo v0, "udniwo"

    const-string/jumbo v0, "window"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    check-cast p0, Landroid/view/WindowManager;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/yhao/floatwindow/q;->a:Landroid/graphics/Point;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/view/Display;->getSize(Landroid/graphics/Point;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object p0, Lcom/yhao/floatwindow/q;->a:Landroid/graphics/Point;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget p0, p0, Landroid/graphics/Point;->x:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return p0
.end method

.method static c(Landroid/content/Context;I)Landroid/view/View;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string v0, "_lafnoepyoatitu"

    const-string/jumbo v0, "il_oounlyefatta"

    const/4 v2, 0x2

    const-string/jumbo v0, "layout_inflater"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p0, Landroid/view/LayoutInflater;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method static d(Landroid/view/View;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    new-instance v0, Landroid/graphics/Rect;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return p0
.end method
