.class Lcom/yhao/floatwindow/a;
.super Landroid/content/BroadcastReceiver;

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# static fields
.field private static final h:Ljava/lang/String; = "reason"

.field private static final i:Ljava/lang/String; = "homekey"

.field private static final j:J = 0x12cL

.field private static k:Lcom/yhao/floatwindow/n;

.field private static l:I


# instance fields
.field private a:Landroid/os/Handler;

.field private b:[Ljava/lang/Class;

.field private c:Z

.field private d:I

.field private e:I

.field private f:Z

.field private g:Lcom/yhao/floatwindow/h;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Z[Ljava/lang/Class;Lcom/yhao/floatwindow/h;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-boolean p2, p0, Lcom/yhao/floatwindow/a;->c:Z

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/yhao/floatwindow/a;->b:[Ljava/lang/Class;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    sget p2, Lcom/yhao/floatwindow/a;->l:I

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    add-int/lit8 p2, p2, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    sput p2, Lcom/yhao/floatwindow/a;->l:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p4, p0, Lcom/yhao/floatwindow/a;->g:Lcom/yhao/floatwindow/h;

    const/4 v1, 0x5

    new-instance p2, Landroid/os/Handler;

    const/4 v1, 0x4

    invoke-direct {p2}, Landroid/os/Handler;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/yhao/floatwindow/a;->a:Landroid/os/Handler;

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    check-cast p2, Landroid/app/Application;

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p2, p0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    new-instance p2, Landroid/content/IntentFilter;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    const-string/jumbo p3, "rIsLO.YinEnDtaLod.TcnOo.AEnGCdtSSSiaei_stM"

    const-string p3, "EDsid.TGcCLenSi_rInA.tanYSatLOoitEnoS.MOdS"

    const/4 v1, 0x0

    const-string/jumbo p3, "tISmDitoCOiLSaS.EeO_n_naTdrLM.ntYEAcoiSd.n"

    const-string p3, "android.intent.action.CLOSE_SYSTEM_DIALOGS"

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p2, p3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1, p0, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-void
.end method

.method static synthetic a(Lcom/yhao/floatwindow/a;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~@ o@b@@~@~b~~  ~~  @ o4S~.@ o  f d~~ ~~~l/i~~fb~Mto ~m~~ls1iar@@~@n@@ y/v-o@~@o ti@ @ u@@c o~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget p0, p0, Lcom/yhao/floatwindow/a;->e:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic b(Lcom/yhao/floatwindow/a;Z)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/yhao/floatwindow/a;->f:Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic c(Lcom/yhao/floatwindow/a;)Lcom/yhao/floatwindow/h;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/yhao/floatwindow/a;->g:Lcom/yhao/floatwindow/h;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method private d(Landroid/app/Activity;)Z
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/yhao/floatwindow/a;->b:[Ljava/lang/Class;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v1, 0x1

    move v6, v1

    const/4 v5, 0x3

    move v6, v5

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    return v1

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    array-length v2, v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-ge v3, v2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    aget-object v4, v0, v3

    const/4 v6, 0x7

    invoke-virtual {v4, p1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x2

    if-eqz v4, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-boolean p1, p0, Lcom/yhao/floatwindow/a;->c:Z

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    return p1

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x0

    iget-boolean p1, p0, Lcom/yhao/floatwindow/a;->c:Z

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    xor-int/2addr p1, v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    return p1
.end method

.method public static e(Lcom/yhao/floatwindow/n;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    sput-object p0, Lcom/yhao/floatwindow/a;->k:Lcom/yhao/floatwindow/n;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget p1, p0, Lcom/yhao/floatwindow/a;->e:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    add-int/lit8 p1, p1, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput p1, p0, Lcom/yhao/floatwindow/a;->e:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/yhao/floatwindow/a;->a:Landroid/os/Handler;

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v0, Lcom/yhao/floatwindow/a$a;

    const/4 v4, 0x3

    invoke-direct {v0, p0}, Lcom/yhao/floatwindow/a$a;-><init>(Lcom/yhao/floatwindow/a;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-wide/16 v1, 0x12c

    const/4 v4, 0x1

    const-wide/16 v1, 0x12c

    const-wide/16 v1, 0x12c

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object v0, Lcom/yhao/floatwindow/a;->k:Lcom/yhao/floatwindow/n;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget v1, Lcom/yhao/floatwindow/a;->l:I

    const/4 v3, 0x5

    add-int/lit8 v1, v1, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    sput v1, Lcom/yhao/floatwindow/a;->l:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Lcom/yhao/floatwindow/n;->a()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    sput-object v0, Lcom/yhao/floatwindow/a;->k:Lcom/yhao/floatwindow/n;

    :cond_0
    const/4 v2, 0x2

    const/4 v3, 0x7

    iget v0, p0, Lcom/yhao/floatwindow/a;->e:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput v0, p0, Lcom/yhao/floatwindow/a;->e:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/yhao/floatwindow/a;->d(Landroid/app/Activity;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/yhao/floatwindow/a;->g:Lcom/yhao/floatwindow/h;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {p1}, Lcom/yhao/floatwindow/h;->c()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/yhao/floatwindow/a;->g:Lcom/yhao/floatwindow/h;

    const/4 v3, 0x6

    invoke-interface {p1}, Lcom/yhao/floatwindow/h;->b()V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-boolean p1, p0, Lcom/yhao/floatwindow/a;->f:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz p1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-boolean p1, p0, Lcom/yhao/floatwindow/a;->f:Z

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    iget p1, p0, Lcom/yhao/floatwindow/a;->d:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    add-int/lit8 p1, p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p1, p0, Lcom/yhao/floatwindow/a;->d:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    iget p1, p0, Lcom/yhao/floatwindow/a;->d:I

    const/4 v1, 0x0

    const/4 v0, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/yhao/floatwindow/a;->d:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-nez p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/yhao/floatwindow/a;->g:Lcom/yhao/floatwindow/h;

    const/4 v1, 0x3

    invoke-interface {p1}, Lcom/yhao/floatwindow/h;->a()V

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string/jumbo v0, "ntYOibSncLtamMCio.n.dieSSESaG_rEtoA._nDIOL"

    const-string v0, "LrSmnMG_ctLdani_oeOSAa.ECoD..SiOEtYitdSInn"

    const/4 v2, 0x3

    const-string/jumbo v0, "noIOiCuteoSar.Mc_OtGSEEd_itT..SDdLninSanYA"

    const-string v0, "android.intent.action.CLOSE_SYSTEM_DIALOGS"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string/jumbo p1, "rpsoeo"

    const-string/jumbo p1, "oesron"

    const/4 v2, 0x6

    const-string/jumbo p1, "orqaes"

    const-string/jumbo p1, "reason"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string p2, "bhsokme"

    const-string p2, "eeomhbk"

    const/4 v2, 0x6

    const-string/jumbo p2, "homekey"

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/yhao/floatwindow/a;->g:Lcom/yhao/floatwindow/h;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {p1}, Lcom/yhao/floatwindow/h;->a()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method
