.class public interface abstract Lcom/google/android/gms/dynamic/g;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T::",
        "Lcom/google/android/gms/dynamic/e;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# virtual methods
.method public abstract a(Lcom/google/android/gms/dynamic/e;)V
    .param p1    # Lcom/google/android/gms/dynamic/e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end method
