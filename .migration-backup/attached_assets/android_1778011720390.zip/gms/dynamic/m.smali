.class final Lcom/google/android/gms/dynamic/m;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/dynamic/q;


# instance fields
.field final synthetic a:Landroid/widget/FrameLayout;

.field final synthetic b:Landroid/view/LayoutInflater;

.field final synthetic c:Landroid/view/ViewGroup;

.field final synthetic d:Landroid/os/Bundle;

.field final synthetic e:Lcom/google/android/gms/dynamic/a;


# direct methods
.method constructor <init>(Lcom/google/android/gms/dynamic/a;Landroid/widget/FrameLayout;Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/dynamic/m;->e:Lcom/google/android/gms/dynamic/a;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/gms/dynamic/m;->a:Landroid/widget/FrameLayout;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p3, p0, Lcom/google/android/gms/dynamic/m;->b:Landroid/view/LayoutInflater;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p4, p0, Lcom/google/android/gms/dynamic/m;->c:Landroid/view/ViewGroup;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p5, p0, Lcom/google/android/gms/dynamic/m;->d:Landroid/os/Bundle;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/dynamic/e;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "u svs~@i@b1b ~i/a/@@ ~f~  ~@@S o@@M~  ~mr@@i~l@t~fo4-@n. c @~K @~od@~@~@  ~~ ~~ o~b ~@y@~l~o@o t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/gms/dynamic/m;->a:Landroid/widget/FrameLayout;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/view/ViewGroup;->removeAllViews()V

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/dynamic/m;->e:Lcom/google/android/gms/dynamic/a;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/google/android/gms/dynamic/a;->p(Lcom/google/android/gms/dynamic/a;)Lcom/google/android/gms/dynamic/e;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/dynamic/m;->b:Landroid/view/LayoutInflater;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/dynamic/m;->c:Landroid/view/ViewGroup;

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/android/gms/dynamic/m;->d:Landroid/os/Bundle;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p1, v0, v1, v2}, Lcom/google/android/gms/dynamic/e;->d(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/dynamic/m;->a:Landroid/widget/FrameLayout;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method

.method public final d()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method
