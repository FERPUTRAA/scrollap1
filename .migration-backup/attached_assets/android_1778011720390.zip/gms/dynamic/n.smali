.class final Lcom/google/android/gms/dynamic/n;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Landroid/content/Intent;


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/dynamic/n;->a:Landroid/content/Context;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/android/gms/dynamic/n;->b:Landroid/content/Intent;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "M@s ~@i   ~o@~~4-l@l@  @ ~~~o~@/cK  r~ ~o@@~@v@oyb.~ fn@~t/ ~fbio@@i @S~ u~@@  ~ ~1b~~s@dmao@~~t"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/gms/dynamic/n;->a:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/dynamic/n;->b:Landroid/content/Intent;

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string v0, "ecfmleerHesLdyliecDprfe"

    const-string/jumbo v0, "pcsideryfDceHeeLereflel"

    const/4 v3, 0x3

    const-string/jumbo v0, "reeeoryHlfLDeifprdeceec"

    const-string v0, "DeferredLifecycleHelper"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v1, "a erFbtidutssetnniomlentr a it lo"

    const-string v1, "eenmitnirntl ri dsaaot oltstu Fet"

    const/4 v3, 0x5

    const-string/jumbo v1, "tttoeFuetlrunitolsraio tn d s iea"

    const-string v1, "Failed to start resolution intent"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v2, 0x2

    and-int/2addr v3, v2

    return-void
.end method
