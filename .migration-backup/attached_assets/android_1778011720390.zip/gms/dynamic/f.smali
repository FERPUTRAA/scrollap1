.class public final Lcom/google/android/gms/dynamic/f;
.super Lcom/google/android/gms/dynamic/d$a;


# annotations
.annotation build Lcom/google/android/gms/common/util/y;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/android/gms/dynamic/d$a;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field private final a:Ljava/lang/Object;


# direct methods
.method private constructor <init>(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/dynamic/d$a;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/dynamic/f;->a:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static b(Lcom/google/android/gms/dynamic/d;)Ljava/lang/Object;
    .locals 9
    .param p0    # Lcom/google/android/gms/dynamic/d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/android/gms/dynamic/d;",
            ")TT;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    instance-of v0, p0, Lcom/google/android/gms/dynamic/f;

    const/4 v8, 0x3

    if-eqz v0, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    check-cast p0, Lcom/google/android/gms/dynamic/f;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object p0, p0, Lcom/google/android/gms/dynamic/f;->a:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v7, 0x4

    return-object p0

    :cond_0
    const/4 v8, 0x2

    invoke-interface {p0}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v0}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    array-length v1, v0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v3, 0x0

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    move v3, v2

    move v3, v2

    const/4 v8, 0x5

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x7

    if-ge v2, v1, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    aget-object v5, v0, v2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v5}, Ljava/lang/reflect/Field;->isSynthetic()Z

    move-result v6

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-nez v6, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    add-int/lit8 v3, v3, 0x1

    move-object v4, v5

    move-object v4, v5

    move-object v4, v5

    move-object v4, v5

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    goto :goto_0

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v1, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-ne v3, v1, :cond_4

    const/4 v8, 0x4

    invoke-static {v4}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v4}, Ljava/lang/reflect/AccessibleObject;->isAccessible()Z

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-nez v0, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v4, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    :try_start_0
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v4, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    return-object p0

    :catch_0
    move-exception p0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const-string/jumbo v1, "neset lrenndfCBhdid.st eicrl ecoio suaoestm"

    const-string/jumbo v1, "tuseeCinihnislrcm o de .fdcoleBsr atoe dten"

    const/4 v8, 0x1

    const-string v1, "Could not access the field in remoteBinder."

    const/4 v7, 0x7

    or-int/2addr v8, v7

    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    throw v0

    :catch_1
    move-exception p0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string/jumbo v1, "i imo le .cnjdrtblnuBe"

    const-string v1, "Binder object is null."

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {v0, v1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    throw v0

    :cond_3
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string/jumbo v0, "fitaojrtd !ra ebIOeciletnem lcdroa vWreppd"

    const-string/jumbo v0, "p lmnerejeoi drtd cvaIatprcfedWbteal!i Orp"

    const/4 v8, 0x1

    const-string v0, " tjrpbeapl  eWdvrilitrfdOa cceend!eIrotape"

    const-string v0, "IObjectWrapper declared field not private!"

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    throw p0

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    array-length v0, v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string/jumbo v2, "ex  dtufOndpeo uif drlc Ilebrca Uemeoe:ejardpenWetbrp"

    const-string v2, " p eold o ejWbifaerxp:dcUcrbd uedeenreOamefn ctIetrlp"

    const/4 v8, 0x4

    const-string v2, "Unexpected number of IObjectWrapper declared fields: "

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    throw p0
.end method

.method public static c(Ljava/lang/Object;)Lcom/google/android/gms/dynamic/d;
    .locals 3
    .param p0    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;)",
            "Lcom/google/android/gms/dynamic/d;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/dynamic/f;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/google/android/gms/dynamic/f;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method
