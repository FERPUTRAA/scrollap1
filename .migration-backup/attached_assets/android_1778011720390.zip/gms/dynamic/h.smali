.class public abstract Lcom/google/android/gms/dynamic/h;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/dynamic/h$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private b:Ljava/lang/Object;


# direct methods
.method protected constructor <init>(Ljava/lang/String;)V
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/dynamic/h;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected abstract a(Landroid/os/IBinder;)Ljava/lang/Object;
    .param p1    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/IBinder;",
            ")TT;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end method

.method protected final b(Landroid/content/Context;)Ljava/lang/Object;
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/dynamic/h$a;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/dynamic/h;->b:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/k;->i(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p1

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/dynamic/h;->a:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast p1, Landroid/os/IBinder;

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/gms/dynamic/h;->a(Landroid/os/IBinder;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/dynamic/h;->b:Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/dynamic/h$a;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string/jumbo v1, "ras aesdlntoo Cso .tcucre"

    const-string/jumbo v1, "snstruoC.ceoo tc dcesl ar"

    const-string v1, "Could not access creator."

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, v1, p1}, Lcom/google/android/gms/dynamic/h$a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0

    :catch_1
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/dynamic/h$a;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v1, "adcmC.teo srtue nntt imoirnalt"

    const-string v1, " o.mCltdn naestue trtiaotncior"

    const/4 v3, 0x0

    const-string/jumbo v1, "rnetoiditcrsanuCn at lt.atoeo "

    const-string v1, "Could not instantiate creator."

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v0, v1, p1}, Lcom/google/android/gms/dynamic/h$a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    throw v0

    :catch_2
    move-exception p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/dynamic/h$a;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo v1, "oCe rbcdroatnl  lstsca.aodo l"

    const-string v1, "Could not load creator class."

    const/4 v3, 0x5

    invoke-direct {v0, v1, p1}, Lcom/google/android/gms/dynamic/h$a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v3, 0x7

    throw v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance p1, Lcom/google/android/gms/dynamic/h$a;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v0, "tdtx tuc Coluoen  rmee.oegtnt"

    const-string v0, "Could not get remote context."

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p1, v0}, Lcom/google/android/gms/dynamic/h$a;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    throw p1

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/gms/dynamic/h;->b:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p1
.end method
