.class final Lcom/google/android/gms/dynamic/k;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/dynamic/q;


# instance fields
.field final synthetic a:Landroid/app/Activity;

.field final synthetic b:Landroid/os/Bundle;

.field final synthetic c:Landroid/os/Bundle;

.field final synthetic d:Lcom/google/android/gms/dynamic/a;


# direct methods
.method constructor <init>(Lcom/google/android/gms/dynamic/a;Landroid/app/Activity;Landroid/os/Bundle;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/dynamic/k;->d:Lcom/google/android/gms/dynamic/a;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/android/gms/dynamic/k;->a:Landroid/app/Activity;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/google/android/gms/dynamic/k;->b:Landroid/os/Bundle;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p4, p0, Lcom/google/android/gms/dynamic/k;->c:Landroid/os/Bundle;

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/dynamic/e;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ms@@K@  ~fota~v4@@~i~ o  @~@    o~/S@~M@ns~ i~~~@@@d 1@o~b ~b@ ~tclu~@ .r@iy@ ~b-~@ of~~@o~/l ~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/google/android/gms/dynamic/k;->d:Lcom/google/android/gms/dynamic/a;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/android/gms/dynamic/a;->p(Lcom/google/android/gms/dynamic/a;)Lcom/google/android/gms/dynamic/e;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/dynamic/k;->a:Landroid/app/Activity;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/gms/dynamic/k;->b:Landroid/os/Bundle;

    const/4 v4, 0x0

    const/4 v3, 0x7

    iget-object v2, p0, Lcom/google/android/gms/dynamic/k;->c:Landroid/os/Bundle;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {p1, v0, v1, v2}, Lcom/google/android/gms/dynamic/e;->c(Landroid/app/Activity;Landroid/os/Bundle;Landroid/os/Bundle;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method

.method public final d()I
    .locals 3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    return v0
.end method
