.class public abstract Lcom/google/android/gms/dynamic/d$a;
.super Lcom/google/android/gms/internal/common/zzb;

# interfaces
.implements Lcom/google/android/gms/dynamic/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/dynamic/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, "asson.gnodrei.mpyI.mg.iaWdljpto.mscgrareccoeO"

    const-string v0, "cos..jeemacrooico.ymmdinergptrgWIsd.paOdan.lg"

    const/4 v2, 0x0

    const-string v0, "egemaccoIWnemmmobyrost.a.gl.nrcaprdd.p.Odoiig"

    const-string v0, "com.google.android.gms.dynamic.IObjectWrapper"

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/common/zzb;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public static a(Landroid/os/IBinder;)Lcom/google/android/gms/dynamic/d;
    .locals 4
    .param p0    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@nr@of/f@@  a-~@~@ b1@~@y ~ @c  @@@ @~~@lovs o@~~u~~~4t@~@M o~~ Kobb~  ~~l~i@oS ~@t ~i.io~~/dm  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 p0, 0x0

    or-int/2addr v3, p0

    const/4 v2, 0x7

    move v3, v2

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string v0, "cgadmbgagjimOe.dmcbr.onodsar.pmyloenrI.ocpet."

    const-string/jumbo v0, "opgmlrWpIncgjaim.r.a.doeedoneO.bcmtagdco.ryms"

    const-string v0, "aotgomu.srcmlnpiOceyo.Wabrjigcn.geddraIo.pd.e"

    const-string v0, "com.google.android.gms.dynamic.IObjectWrapper"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    instance-of v1, v0, Lcom/google/android/gms/dynamic/d;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v0, Lcom/google/android/gms/dynamic/d;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v2, 0x4

    move v3, v2

    new-instance v0, Lcom/google/android/gms/dynamic/s;

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, p0}, Lcom/google/android/gms/dynamic/s;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0
.end method
