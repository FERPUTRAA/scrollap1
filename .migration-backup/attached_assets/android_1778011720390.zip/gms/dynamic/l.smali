.class final Lcom/google/android/gms/dynamic/l;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/dynamic/q;


# instance fields
.field final synthetic a:Landroid/os/Bundle;

.field final synthetic b:Lcom/google/android/gms/dynamic/a;


# direct methods
.method constructor <init>(Lcom/google/android/gms/dynamic/a;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/dynamic/l;->b:Lcom/google/android/gms/dynamic/a;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/android/gms/dynamic/l;->a:Landroid/os/Bundle;

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/dynamic/e;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sitr~o1o~~ffl   @@  ~ni@ ~K~~ t @ @ .@a~@~ ~@@bc~@o~s~@4~~@/v~iu@o@@Sb @~y /lo  -Mo~~~~md @b@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/gms/dynamic/l;->b:Lcom/google/android/gms/dynamic/a;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/google/android/gms/dynamic/a;->p(Lcom/google/android/gms/dynamic/a;)Lcom/google/android/gms/dynamic/e;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/dynamic/l;->a:Landroid/os/Bundle;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {p1, v0}, Lcom/google/android/gms/dynamic/e;->b(Landroid/os/Bundle;)V

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public final d()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method
