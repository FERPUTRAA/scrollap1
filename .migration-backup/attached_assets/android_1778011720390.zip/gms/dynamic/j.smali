.class final Lcom/google/android/gms/dynamic/j;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/dynamic/g;


# instance fields
.field final synthetic a:Lcom/google/android/gms/dynamic/a;


# direct methods
.method constructor <init>(Lcom/google/android/gms/dynamic/a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/dynamic/j;->a:Lcom/google/android/gms/dynamic/a;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/dynamic/e;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/dynamic/j;->a:Lcom/google/android/gms/dynamic/a;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0, p1}, Lcom/google/android/gms/dynamic/a;->r(Lcom/google/android/gms/dynamic/a;Lcom/google/android/gms/dynamic/e;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/google/android/gms/dynamic/j;->a:Lcom/google/android/gms/dynamic/a;

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/google/android/gms/dynamic/a;->q(Lcom/google/android/gms/dynamic/a;)Ljava/util/LinkedList;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Lcom/google/android/gms/dynamic/q;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/gms/dynamic/j;->a:Lcom/google/android/gms/dynamic/a;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v1}, Lcom/google/android/gms/dynamic/a;->p(Lcom/google/android/gms/dynamic/a;)Lcom/google/android/gms/dynamic/e;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v0, v1}, Lcom/google/android/gms/dynamic/q;->a(Lcom/google/android/gms/dynamic/e;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/google/android/gms/dynamic/j;->a:Lcom/google/android/gms/dynamic/a;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/google/android/gms/dynamic/a;->q(Lcom/google/android/gms/dynamic/a;)Ljava/util/LinkedList;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/util/LinkedList;->clear()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/gms/dynamic/j;->a:Lcom/google/android/gms/dynamic/a;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/google/android/gms/dynamic/a;->s(Lcom/google/android/gms/dynamic/a;Landroid/os/Bundle;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method
