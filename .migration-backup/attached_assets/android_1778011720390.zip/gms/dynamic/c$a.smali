.class public abstract Lcom/google/android/gms/dynamic/c$a;
.super Lcom/google/android/gms/internal/common/zzb;

# interfaces
.implements Lcom/google/android/gms/dynamic/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/dynamic/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string v0, ".msdnrgsetnyFerIoagog..sgiaWlediaooncmmpcm.dprr"

    const-string v0, "arscnm.mm.IorlaprgoFtod.ggpW.e.mrendceiiagyndos"

    const/4 v2, 0x3

    const-string/jumbo v0, "ignmanioyg..rleoemcW.anrpmIa.odore.dgcaspmgFrdm"

    const-string v0, "com.google.android.gms.dynamic.IFragmentWrapper"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/common/zzb;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public static a(Landroid/os/IBinder;)Lcom/google/android/gms/dynamic/c;
    .locals 4
    .param p0    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~i@ou@.4   @l@@M~K~@afynd-/~to1~b o@~~ o~~@f~@/o~@ ~i ~~ @~~c~~ b~@ ~@@@m@ ~ S @  lrso@@tvob@  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo v0, "togrobcaoyiaa.rspeIeogndc..mrpim.dnW.lenFmdamgr"

    const-string v0, "com.google.android.gms.dynamic.IFragmentWrapper"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    instance-of v1, v0, Lcom/google/android/gms/dynamic/c;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast v0, Lcom/google/android/gms/dynamic/c;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/dynamic/r;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, p0}, Lcom/google/android/gms/dynamic/r;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0
.end method


# virtual methods
.method protected final zza(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 2
    .param p2    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v0, 0x3

    const/4 v1, 0x6

    packed-switch p1, :pswitch_data_0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return p1

    :pswitch_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    invoke-static {p1}, Lcom/google/android/gms/dynamic/d$a;->a(Landroid/os/IBinder;)Lcom/google/android/gms/dynamic/d;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzb(Landroid/os/Parcel;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-interface {p0, p1}, Lcom/google/android/gms/dynamic/c;->t(Lcom/google/android/gms/dynamic/d;)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    goto/16 :goto_0

    :pswitch_1
    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    sget-object p1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x7

    const/4 v0, 0x0

    invoke-static {p2, p1}, Lcom/google/android/gms/internal/common/zzc;->zza(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    check-cast p1, Landroid/content/Intent;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p4

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzb(Landroid/os/Parcel;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-interface {p0, p1, p4}, Lcom/google/android/gms/dynamic/c;->S(Landroid/content/Intent;I)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    goto/16 :goto_0

    :pswitch_2
    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    sget-object p1, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p2, p1}, Lcom/google/android/gms/internal/common/zzc;->zza(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    check-cast p1, Landroid/content/Intent;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzb(Landroid/os/Parcel;)V

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-interface {p0, p1}, Lcom/google/android/gms/dynamic/c;->R(Landroid/content/Intent;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    goto/16 :goto_0

    :pswitch_3
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzf(Landroid/os/Parcel;)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzb(Landroid/os/Parcel;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-interface {p0, p1}, Lcom/google/android/gms/dynamic/c;->j0(Z)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    goto/16 :goto_0

    :pswitch_4
    const/4 v1, 0x7

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzf(Landroid/os/Parcel;)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzb(Landroid/os/Parcel;)V

    const/4 v1, 0x1

    invoke-interface {p0, p1}, Lcom/google/android/gms/dynamic/c;->M(Z)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    goto/16 :goto_0

    :pswitch_5
    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzf(Landroid/os/Parcel;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzb(Landroid/os/Parcel;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    invoke-interface {p0, p1}, Lcom/google/android/gms/dynamic/c;->G(Z)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    goto/16 :goto_0

    :pswitch_6
    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzf(Landroid/os/Parcel;)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzb(Landroid/os/Parcel;)V

    const/4 v1, 0x7

    invoke-interface {p0, p1}, Lcom/google/android/gms/dynamic/c;->C(Z)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v0, 0x5

    and-int/2addr v1, v0

    goto/16 :goto_0

    :pswitch_7
    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    invoke-static {p1}, Lcom/google/android/gms/dynamic/d$a;->a(Landroid/os/IBinder;)Lcom/google/android/gms/dynamic/d;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzb(Landroid/os/Parcel;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-interface {p0, p1}, Lcom/google/android/gms/dynamic/c;->d0(Lcom/google/android/gms/dynamic/d;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    goto/16 :goto_0

    :pswitch_8
    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzA()Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    sget p2, Lcom/google/android/gms/internal/common/zzc;->zza:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    goto/16 :goto_0

    :pswitch_9
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzz()Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    sget p2, Lcom/google/android/gms/internal/common/zzc;->zza:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    goto/16 :goto_0

    :pswitch_a
    const/4 v0, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzy()Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    sget p2, Lcom/google/android/gms/internal/common/zzc;->zza:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    goto/16 :goto_0

    :pswitch_b
    const/4 v1, 0x4

    const/4 v0, 0x1

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzx()Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x6

    sget p2, Lcom/google/android/gms/internal/common/zzc;->zza:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    goto/16 :goto_0

    :pswitch_c
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzw()Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    sget p2, Lcom/google/android/gms/internal/common/zzc;->zza:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    goto/16 :goto_0

    :pswitch_d
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzv()Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    sget p2, Lcom/google/android/gms/internal/common/zzc;->zza:I

    const/4 v1, 0x6

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    goto/16 :goto_0

    :pswitch_e
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzu()Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    sget p2, Lcom/google/android/gms/internal/common/zzc;->zza:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x2

    const/4 v1, 0x0

    goto/16 :goto_0

    :pswitch_f
    const/4 v1, 0x5

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzi()Lcom/google/android/gms/dynamic/d;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p3, p1}, Lcom/google/android/gms/internal/common/zzc;->zze(Landroid/os/Parcel;Landroid/os/IInterface;)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    goto/16 :goto_0

    :pswitch_10
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzt()Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    sget p2, Lcom/google/android/gms/internal/common/zzc;->zza:I

    const/4 v1, 0x5

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    goto/16 :goto_0

    :pswitch_11
    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzc()I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x7

    move v1, v0

    goto/16 :goto_0

    :pswitch_12
    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzf()Lcom/google/android/gms/dynamic/c;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p3, p1}, Lcom/google/android/gms/internal/common/zzc;->zze(Landroid/os/Parcel;Landroid/os/IInterface;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    goto/16 :goto_0

    :pswitch_13
    const/4 v0, 0x6

    move v1, v0

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzj()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    goto/16 :goto_0

    :pswitch_14
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzs()Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    sget p2, Lcom/google/android/gms/internal/common/zzc;->zza:I

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    goto :goto_0

    :pswitch_15
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzh()Lcom/google/android/gms/dynamic/d;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p3, p1}, Lcom/google/android/gms/internal/common/zzc;->zze(Landroid/os/Parcel;Landroid/os/IInterface;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    goto :goto_0

    :pswitch_16
    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zze()Lcom/google/android/gms/dynamic/c;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-static {p3, p1}, Lcom/google/android/gms/internal/common/zzc;->zze(Landroid/os/Parcel;Landroid/os/IInterface;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    goto :goto_0

    :pswitch_17
    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzb()I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    goto :goto_0

    :pswitch_18
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzd()Landroid/os/Bundle;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p3, p1}, Lcom/google/android/gms/internal/common/zzc;->zzd(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    goto :goto_0

    :pswitch_19
    const/4 v1, 0x3

    invoke-interface {p0}, Lcom/google/android/gms/dynamic/c;->zzg()Lcom/google/android/gms/dynamic/d;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p3, p1}, Lcom/google/android/gms/internal/common/zzc;->zze(Landroid/os/Parcel;Landroid/os/IInterface;)V

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
