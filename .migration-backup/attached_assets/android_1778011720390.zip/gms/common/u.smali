.class public Lcom/google/android/gms/common/u;
.super Ljava/lang/Exception;


# instance fields
.field private final zza:Landroid/content/Intent;


# direct methods
.method public constructor <init>(Ljava/lang/String;Landroid/content/Intent;)V
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/gms/common/u;->zza:Landroid/content/Intent;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a()Landroid/content/Intent;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "cus~~~ ~ ~nK@~@~~~sm@bf @o@  dy~~~/i@~@@@@o li-at@vo4 oo~ ~b @ @r~f @t 1@/~o M~.l@@@  ~S@ b ~~i@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x5

    const/4 v2, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/u;->zza:Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0
.end method
