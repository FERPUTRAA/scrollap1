.class public Lcom/google/android/gms/common/p;
.super Ljava/lang/Object;


# annotations
.annotation runtime Ly4/b;
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Z

.field private final c:Ljava/lang/String;
    .annotation runtime Lv7/h;
    .end annotation
.end field

.field private final d:Ljava/lang/Throwable;
    .annotation runtime Lv7/h;
    .end annotation
.end field


# direct methods
.method private constructor <init>(Ljava/lang/String;IZLjava/lang/String;Ljava/lang/Throwable;)V
    .locals 2
    .param p4    # Ljava/lang/String;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .param p5    # Ljava/lang/Throwable;
        .annotation runtime Lv7/h;
        .end annotation
    .end param

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/google/android/gms/common/p;->a:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x3

    iput-boolean p3, p0, Lcom/google/android/gms/common/p;->b:Z

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p4, p0, Lcom/google/android/gms/common/p;->c:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p5, p0, Lcom/google/android/gms/common/p;->d:Ljava/lang/Throwable;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)Lcom/google/android/gms/common/p;
    .locals 9
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Throwable;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, " ~su/io~ ~@m~ ~bcol@  ~r~@o~1@~@@  @S~ t~~@~f @o d-~~i. @~  @~b@~@a@bn@~@ov~ @@fM t@@~i o~/Klys "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v6, Lcom/google/android/gms/common/p;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v2, 0x1

    move v8, v2

    const/4 v7, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v3, 0x0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/p;-><init>(Ljava/lang/String;IZLjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    return-object v6
.end method

.method public static d(Ljava/lang/String;I)Lcom/google/android/gms/common/p;
    .locals 9
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    new-instance v6, Lcom/google/android/gms/common/p;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v3, 0x1

    const/4 v7, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v4, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 v5, 0x0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    move v2, p1

    move v2, p1

    const/4 v8, 0x6

    move v2, p1

    move v2, p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/p;-><init>(Ljava/lang/String;IZLjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-object v6
.end method


# virtual methods
.method public final b()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-boolean v0, p0, Lcom/google/android/gms/common/p;->b:Z

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-nez v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/p;->c:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/p;->d:Ljava/lang/Throwable;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v2, "ltamgaecft s:iVcorPRksnai"

    const-string v2, "RasteckaVrsf clgii:Pnatoe"

    const/4 v4, 0x7

    const-string v2, "PackageVerificationRslt: "

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v2, Ljava/lang/SecurityException;

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-direct {v2, v0, v1}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw v2

    :cond_0
    const/4 v3, 0x5

    move v4, v3

    new-instance v1, Ljava/lang/SecurityException;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v1, v0}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    throw v1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void
.end method

.method public final c()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/gms/common/p;->b:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method
