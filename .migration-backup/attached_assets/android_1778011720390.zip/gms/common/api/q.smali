.class public final Lcom/google/android/gms/common/api/q;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public static a()Lcom/google/android/gms/common/api/p;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/gms/common/api/p<",
            "Lcom/google/android/gms/common/api/Status;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/common/api/internal/z;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/api/internal/z;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->cancel()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0
.end method

.method public static b(Lcom/google/android/gms/common/api/v;)Lcom/google/android/gms/common/api/p;
    .locals 4
    .param p0    # Lcom/google/android/gms/common/api/v;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R::",
            "Lcom/google/android/gms/common/api/v;",
            ">(TR;)",
            "Lcom/google/android/gms/common/api/p<",
            "TR;>;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v0, " tsen u eRm ssotslnulbt"

    const-string/jumbo v0, "u ssnnbe tmReullots t l"

    const/4 v3, 0x5

    const-string/jumbo v0, "ottm  e beunRsnl mtuuls"

    const-string v0, "Result must not be null"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {p0}, Lcom/google/android/gms/common/api/v;->getStatus()Lcom/google/android/gms/common/api/Status;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/Status;->A2()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0x10

    const/4 v2, 0x5

    and-int/2addr v3, v2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string/jumbo v1, "tsSEoCdoaoe sL.tutsmtCESsoeuedmtoCaCun cDmb Nm"

    const-string/jumbo v1, "uEbmaNm CotSa.C mEsmuteLeADsdottsS ntdoeCsocCu"

    const/4 v3, 0x3

    const-string/jumbo v1, "ntdNabmCeto  oS suSdCtmeC t.DotAceLuuoEsCbsEma"

    const-string v1, "Status code must be CommonStatusCodes.CANCELED"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/common/api/g0;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/api/g0;-><init>(Lcom/google/android/gms/common/api/v;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->cancel()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0
.end method

.method public static c(Lcom/google/android/gms/common/api/v;Lcom/google/android/gms/common/api/l;)Lcom/google/android/gms/common/api/p;
    .locals 4
    .param p0    # Lcom/google/android/gms/common/api/v;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/gms/common/api/l;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R::",
            "Lcom/google/android/gms/common/api/v;",
            ">(TR;",
            "Lcom/google/android/gms/common/api/l;",
            ")",
            "Lcom/google/android/gms/common/api/p<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v0, " sun su ttb Ruoenltelmo"

    const-string/jumbo v0, "t tmotb  nns uoelRulsel"

    const/4 v3, 0x7

    const-string/jumbo v0, "mltnulup sse oetlb  nRu"

    const-string v0, "Result must not be null"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {p0}, Lcom/google/android/gms/common/api/v;->getStatus()Lcom/google/android/gms/common/api/Status;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/Status;->E2()Z

    move-result v0

    const/4 v3, 0x3

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x3

    move v3, v2

    const-string v1, "aSm US dqtnESbSt  otuCcuC sosbt"

    const-string v1, " ua nboCsSt EtSsCSU cotdm tubeS"

    const/4 v3, 0x2

    const-string/jumbo v1, "uSsdnSCs uE cSeSsmbate U tt Coo"

    const-string v1, "Status code must not be SUCCESS"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/common/api/h0;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0, p1, p0}, Lcom/google/android/gms/common/api/h0;-><init>(Lcom/google/android/gms/common/api/l;Lcom/google/android/gms/common/api/v;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->setResult(Lcom/google/android/gms/common/api/v;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public static d(Lcom/google/android/gms/common/api/v;)Lcom/google/android/gms/common/api/o;
    .locals 4
    .param p0    # Lcom/google/android/gms/common/api/v;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R::",
            "Lcom/google/android/gms/common/api/v;",
            ">(TR;)",
            "Lcom/google/android/gms/common/api/o<",
            "TR;>;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v0, "ntRmu uu selttlnsbumole"

    const-string/jumbo v0, "llont uunu mtet suRebls"

    const/4 v3, 0x7

    const-string v0, "R  eous obn lntsluuttme"

    const-string v0, "Result must not be null"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    and-int/2addr v3, v2

    new-instance v0, Lcom/google/android/gms/common/api/i0;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/api/i0;-><init>(Lcom/google/android/gms/common/api/l;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->setResult(Lcom/google/android/gms/common/api/v;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance p0, Lcom/google/android/gms/common/api/internal/r;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/r;-><init>(Lcom/google/android/gms/common/api/p;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p0
.end method

.method public static e(Lcom/google/android/gms/common/api/v;Lcom/google/android/gms/common/api/l;)Lcom/google/android/gms/common/api/o;
    .locals 3
    .param p0    # Lcom/google/android/gms/common/api/v;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/gms/common/api/l;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R::",
            "Lcom/google/android/gms/common/api/v;",
            ">(TR;",
            "Lcom/google/android/gms/common/api/l;",
            ")",
            "Lcom/google/android/gms/common/api/o<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo v0, "l R pbtse lnltue bunuts"

    const-string v0, " slRusupetotblt uen nl "

    const/4 v2, 0x7

    const-string/jumbo v0, "seuno uutb  Resn lltulm"

    const-string v0, "Result must not be null"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/gms/common/api/i0;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/api/i0;-><init>(Lcom/google/android/gms/common/api/l;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->setResult(Lcom/google/android/gms/common/api/v;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    new-instance p0, Lcom/google/android/gms/common/api/internal/r;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/r;-><init>(Lcom/google/android/gms/common/api/p;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public static f(Lcom/google/android/gms/common/api/Status;)Lcom/google/android/gms/common/api/p;
    .locals 4
    .param p0    # Lcom/google/android/gms/common/api/Status;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/Status;",
            ")",
            "Lcom/google/android/gms/common/api/p<",
            "Lcom/google/android/gms/common/api/Status;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v0, "tunqeblps  m  ttnuoRsul"

    const-string/jumbo v0, "olnuse tqtuRu  nlmb stl"

    const/4 v3, 0x4

    const-string v0, " esbt  tqlnlsumRule uno"

    const-string v0, "Result must not be null"

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/common/api/internal/z;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/api/internal/z;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->setResult(Lcom/google/android/gms/common/api/v;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public static g(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/common/api/l;)Lcom/google/android/gms/common/api/p;
    .locals 3
    .param p0    # Lcom/google/android/gms/common/api/Status;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/gms/common/api/l;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/Status;",
            "Lcom/google/android/gms/common/api/l;",
            ")",
            "Lcom/google/android/gms/common/api/p<",
            "Lcom/google/android/gms/common/api/Status;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string/jumbo v0, "lRssusubo te nn smt lut"

    const-string v0, " nstuel enotbuusR smlt "

    const/4 v2, 0x2

    const-string/jumbo v0, "otemntlesR  s un umbllu"

    const-string v0, "Result must not be null"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Lcom/google/android/gms/common/api/internal/z;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/api/internal/z;-><init>(Lcom/google/android/gms/common/api/l;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->setResult(Lcom/google/android/gms/common/api/v;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method
