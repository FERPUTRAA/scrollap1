.class public final Lcom/google/android/gms/common/api/l$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/api/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# instance fields
.field private a:Landroid/accounts/Account;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final b:Ljava/util/Set;

.field private final c:Ljava/util/Set;

.field private d:I

.field private e:Landroid/view/View;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private final h:Ljava/util/Map;

.field private final i:Landroid/content/Context;

.field private final j:Ljava/util/Map;

.field private k:Lcom/google/android/gms/common/api/internal/l;

.field private l:I

.field private m:Lcom/google/android/gms/common/api/l$c;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private n:Landroid/os/Looper;

.field private o:Lcom/google/android/gms/common/f;

.field private p:Lcom/google/android/gms/common/api/a$a;

.field private final q:Ljava/util/ArrayList;

.field private final r:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/l$a;->b:Ljava/util/Set;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/api/l$a;->c:Ljava/util/Set;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Landroidx/collection/a;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0}, Landroidx/collection/a;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/gms/common/api/l$a;->h:Ljava/util/Map;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance v0, Landroidx/collection/a;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0}, Landroidx/collection/a;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/l$a;->j:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v0, -0x1

    const/4 v2, 0x5

    move v1, v0

    move v1, v0

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/android/gms/common/api/l$a;->l:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/common/f;->x()Lcom/google/android/gms/common/f;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/l$a;->o:Lcom/google/android/gms/common/f;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/signin/e;->c:Lcom/google/android/gms/common/api/a$a;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/api/l$a;->p:Lcom/google/android/gms/common/api/a$a;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/api/l$a;->q:Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/common/api/l$a;->r:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/api/l$a;->i:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/gms/common/api/l$a;->n:Landroid/os/Looper;

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/common/api/l$a;->f:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/l$a;->g:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/api/l$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/gms/common/api/l$c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/l$a;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    const-string/jumbo p1, "rpsn i  c tosuieeoavnencldrdettMs"

    const-string/jumbo p1, "tnsneo  pde ledriMnsoac ceitsrvtu"

    const/4 v1, 0x3

    const-string/jumbo p1, "onMmsune e rtrsotipcevtel ina ced"

    const-string p1, "Must provide a connected listener"

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p2, p1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/l$a;->q:Ljava/util/ArrayList;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const-string/jumbo p1, "ucstontt emeir nepllidcr  deaonfoi ivoesa"

    const-string/jumbo p1, "lremosvoantreniacitpi  cd  iuesdeefotnln "

    const/4 v1, 0x0

    const-string/jumbo p1, "lvonebrecodtnrM itpnti difes laienaes cou"

    const-string p1, "Must provide a connection failed listener"

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p3, p1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/api/l$a;->r:Ljava/util/ArrayList;

    const/4 v1, 0x6

    invoke-virtual {p1, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method private final varargs q(Lcom/google/android/gms/common/api/a;Lcom/google/android/gms/common/api/a$d;[Lcom/google/android/gms/common/api/Scope;)V
    .locals 5
    .param p2    # Lcom/google/android/gms/common/api/a$d;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "S- .boul@ o~~@ldf~@@uc~@ /ta4s@~ Mf b~~ ~@t ~~~~m~byoo @onio~@1  ~~@ ~~@ @ri~Ki@  v~@@@@~@ ~ @ @"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/a;->c()Lcom/google/android/gms/common/api/a$e;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string/jumbo v1, "o ea tnplueblrmu  dncenltl  oBestsii"

    const-string v1, "  m onos rnuectdtel euBbisiab lleltn"

    const/4 v4, 0x3

    const-string v1, " lbuee bqudstn cun iiBllee s amlntto"

    const-string v1, "Base client builder must not be null"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    check-cast v0, Lcom/google/android/gms/common/api/a$e;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v1, Ljava/util/HashSet;

    const/4 v4, 0x1

    invoke-virtual {v0, p2}, Lcom/google/android/gms/common/api/a$e;->getImpliedScopes(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v1, p2}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    array-length p2, p3

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ge v0, p2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    aget-object v2, p3, v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {v1, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x3

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object p2, p0, Lcom/google/android/gms/common/api/l$a;->h:Ljava/util/Map;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance p3, Lcom/google/android/gms/common/internal/j0;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {p3, v1}, Lcom/google/android/gms/common/internal/j0;-><init>(Ljava/util/Set;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p2, p1, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/gms/common/api/a;)Lcom/google/android/gms/common/api/l$a;
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/a<",
            "+",
            "Lcom/google/android/gms/common/api/a$d$e;",
            ">;)",
            "Lcom/google/android/gms/common/api/l$a;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const-string v0, "bbsno m lstu iutpAnl"

    const-string/jumbo v0, "llAtbb tnp  iouunm s"

    const/4 v3, 0x1

    const-string/jumbo v0, "mtumol ulbi t npen s"

    const-string v0, "Api must not be null"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/l$a;->j:Ljava/util/Map;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/a;->c()Lcom/google/android/gms/common/api/a$e;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const-string/jumbo v0, "li ooB nb tb  tseltmu uieruleledansn"

    const-string/jumbo v0, "lbuslautbnoeut iBd nes  neeui ltmr l"

    const/4 v3, 0x0

    const-string v0, "Base client builder must not be null"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast p1, Lcom/google/android/gms/common/api/a$e;

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    invoke-virtual {p1, v1}, Lcom/google/android/gms/common/api/a$e;->getImpliedScopes(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/l$a;->c:Ljava/util/Set;

    const/4 v3, 0x2

    invoke-interface {v0, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/l$a;->b:Ljava/util/Set;

    const/4 v2, 0x7

    move v3, v2

    invoke-interface {v0, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v3, 0x3

    const/4 v2, 0x6

    return-object p0
.end method

.method public b(Lcom/google/android/gms/common/api/a;Lcom/google/android/gms/common/api/a$d$c;)Lcom/google/android/gms/common/api/l$a;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/api/a$d$c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<O::",
            "Lcom/google/android/gms/common/api/a$d$c;",
            ">(",
            "Lcom/google/android/gms/common/api/a<",
            "TO;>;TO;)",
            "Lcom/google/android/gms/common/api/l$a;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string/jumbo v0, "t pnebuit uslAmo pln"

    const-string v0, " ntnep plmuuilA sbto"

    const/4 v2, 0x2

    const-string/jumbo v0, "l ut eu mopb iAlntus"

    const-string v0, "Api must not be null"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string/jumbo v0, "i pho Nptiost mltipneAesa o rtedrqnltp  fru"

    const-string/jumbo v0, "teahoulsqel  nofr ittompAisp   oten Npdritr"

    const-string/jumbo v0, "u ts irnq eNplmeisf oaohr  ietrpoo lAittpdn"

    const-string v0, "Null options are not permitted for this Api"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p2, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/l$a;->j:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/a;->c()Lcom/google/android/gms/common/api/a$e;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string v0, " lsle dtaunsesenmr bti tuo s blucBen"

    const-string v0, "bnseuo li lneB t tml nlurbect usdesa"

    const/4 v2, 0x2

    const-string/jumbo v0, "nctmulill r mbtes eetd ulio ne uBbas"

    const-string v0, "Base client builder must not be null"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast p1, Lcom/google/android/gms/common/api/a$e;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1, p2}, Lcom/google/android/gms/common/api/a$e;->getImpliedScopes(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/google/android/gms/common/api/l$a;->c:Ljava/util/Set;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {p2, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/google/android/gms/common/api/l$a;->b:Ljava/util/Set;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {p2, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public varargs c(Lcom/google/android/gms/common/api/a;Lcom/google/android/gms/common/api/a$d$c;[Lcom/google/android/gms/common/api/Scope;)Lcom/google/android/gms/common/api/l$a;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/api/a$d$c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # [Lcom/google/android/gms/common/api/Scope;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<O::",
            "Lcom/google/android/gms/common/api/a$d$c;",
            ">(",
            "Lcom/google/android/gms/common/api/a<",
            "TO;>;TO;[",
            "Lcom/google/android/gms/common/api/Scope;",
            ")",
            "Lcom/google/android/gms/common/api/l$a;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string/jumbo v0, "ums ob t npluno Aiel"

    const-string v0, "Api must not be null"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "hstlnbm o  ili rrafp A eidne tpsmiptoeNruot"

    const-string v0, " n mepie oAmtt pi ptrafrot urdnssililNteo h"

    const/4 v2, 0x6

    const-string v0, " Ast hu eptfoepuatte  lNio mltriri nrinpdoo"

    const-string v0, "Null options are not permitted for this Api"

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p2, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/l$a;->j:Ljava/util/Map;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/gms/common/api/l$a;->q(Lcom/google/android/gms/common/api/a;Lcom/google/android/gms/common/api/a$d;[Lcom/google/android/gms/common/api/Scope;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public varargs d(Lcom/google/android/gms/common/api/a;[Lcom/google/android/gms/common/api/Scope;)Lcom/google/android/gms/common/api/l$a;
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Lcom/google/android/gms/common/api/Scope;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/android/gms/common/api/a$d$e;",
            ">(",
            "Lcom/google/android/gms/common/api/a<",
            "+",
            "Lcom/google/android/gms/common/api/a$d$e;",
            ">;[",
            "Lcom/google/android/gms/common/api/Scope;",
            ")",
            "Lcom/google/android/gms/common/api/l$a;"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v0, "tm tu upbllno sAp in"

    const-string v0, "Api must not be null"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/l$a;->j:Ljava/util/Map;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0, p1, v1, p2}, Lcom/google/android/gms/common/api/l$a;->q(Lcom/google/android/gms/common/api/a;Lcom/google/android/gms/common/api/a$d;[Lcom/google/android/gms/common/api/Scope;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p0
.end method

.method public e(Lcom/google/android/gms/common/api/l$b;)Lcom/google/android/gms/common/api/l$a;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/l$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo v0, "sr  utueqibon tt lneLmeso"

    const-string/jumbo v0, "t Llo beounutlers tsiem n"

    const/4 v2, 0x2

    const-string/jumbo v0, "tssnl  mn Lreiunt eoleusb"

    const-string v0, "Listener must not be null"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/l$a;->q:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method public f(Lcom/google/android/gms/common/api/l$c;)Lcom/google/android/gms/common/api/l$a;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/l$c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const-string v0, "be mnnsltnLoet uesu timr "

    const-string/jumbo v0, "nsn ebtsetobmtLr iuunl e "

    const/4 v2, 0x0

    const-string v0, "blonotu iersnnsLl  uettm "

    const-string v0, "Listener must not be null"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/l$a;->r:Ljava/util/ArrayList;

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method

.method public g(Lcom/google/android/gms/common/api/Scope;)Lcom/google/android/gms/common/api/l$a;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/Scope;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "cntu b emntS s elpobuu"

    const-string v0, "bmus nunucoetoeptS  l "

    const/4 v2, 0x6

    const-string/jumbo v0, "ltmn su buontpSuc l oe"

    const-string v0, "Scope must not be null"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/l$a;->b:Ljava/util/Set;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public h()Lcom/google/android/gms/common/api/l;
    .locals 22
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    iget-object v0, v1, Lcom/google/android/gms/common/api/l$a;->j:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v2, 0x1

    xor-int/2addr v0, v2

    const-string v3, "amdd Acpeoat pai()s e PpsdIlad l to a untt"

    const-string v3, " tp IAepadPoodmna (tAt dl  aais duetlac s)"

    const-string/jumbo v3, "tuaap eaqn d  dl csdle )aA Iot Ao(tdtmliPa"

    const-string/jumbo v3, "must call addApi() to add at least one API"

    invoke-static {v0, v3}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    invoke-virtual/range {p0 .. p0}, Lcom/google/android/gms/common/api/l$a;->p()Lcom/google/android/gms/common/internal/g;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/g;->n()Ljava/util/Map;

    move-result-object v3

    new-instance v11, Landroidx/collection/a;

    invoke-direct {v11}, Landroidx/collection/a;-><init>()V

    new-instance v14, Landroidx/collection/a;

    invoke-direct {v14}, Landroidx/collection/a;-><init>()V

    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    iget-object v4, v1, Lcom/google/android/gms/common/api/l$a;->j:Ljava/util/Map;

    invoke-interface {v4}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v12

    const/4 v13, 0x0

    const/4 v4, 0x0

    move-object/from16 v16, v4

    move-object/from16 v16, v4

    move/from16 v17, v13

    move/from16 v17, v13

    move/from16 v17, v13

    move/from16 v17, v13

    :cond_0
    :goto_0
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_5

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v10, v4

    move-object v10, v4

    move-object v10, v4

    move-object v10, v4

    check-cast v10, Lcom/google/android/gms/common/api/a;

    iget-object v4, v1, Lcom/google/android/gms/common/api/l$a;->j:Ljava/util/Map;

    invoke-interface {v4, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v18

    invoke-interface {v3, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-eqz v4, :cond_1

    move v4, v2

    move v4, v2

    move v4, v2

    move v4, v2

    goto :goto_1

    :cond_1
    move v4, v13

    move v4, v13

    move v4, v13

    move v4, v13

    :goto_1
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    invoke-interface {v11, v10, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v9, Lcom/google/android/gms/common/api/internal/y3;

    invoke-direct {v9, v10, v4}, Lcom/google/android/gms/common/api/internal/y3;-><init>(Lcom/google/android/gms/common/api/a;Z)V

    invoke-virtual {v15, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v10}, Lcom/google/android/gms/common/api/a;->a()Lcom/google/android/gms/common/api/a$a;

    move-result-object v4

    invoke-static {v4}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v19, v4

    move-object/from16 v19, v4

    move-object/from16 v19, v4

    move-object/from16 v19, v4

    check-cast v19, Lcom/google/android/gms/common/api/a$a;

    iget-object v5, v1, Lcom/google/android/gms/common/api/l$a;->i:Landroid/content/Context;

    iget-object v6, v1, Lcom/google/android/gms/common/api/l$a;->n:Landroid/os/Looper;

    move-object/from16 v4, v19

    move-object/from16 v4, v19

    move-object/from16 v4, v19

    move-object/from16 v4, v19

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object/from16 v8, v18

    move-object/from16 v8, v18

    move-object/from16 v8, v18

    move-object/from16 v8, v18

    move-object/from16 v20, v9

    move-object/from16 v20, v9

    move-object/from16 v20, v9

    move-object/from16 v20, v9

    move-object/from16 v21, v10

    move-object/from16 v21, v10

    move-object/from16 v21, v10

    move-object/from16 v21, v10

    move-object/from16 v10, v20

    invoke-virtual/range {v4 .. v10}, Lcom/google/android/gms/common/api/a$a;->buildClient(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Ljava/lang/Object;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)Lcom/google/android/gms/common/api/a$f;

    move-result-object v4

    invoke-virtual/range {v21 .. v21}, Lcom/google/android/gms/common/api/a;->b()Lcom/google/android/gms/common/api/a$c;

    move-result-object v5

    invoke-interface {v14, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual/range {v19 .. v19}, Lcom/google/android/gms/common/api/a$e;->getPriority()I

    move-result v5

    if-ne v5, v2, :cond_3

    if-eqz v18, :cond_2

    move/from16 v17, v2

    move/from16 v17, v2

    move/from16 v17, v2

    move/from16 v17, v2

    goto :goto_2

    :cond_2
    move/from16 v17, v13

    move/from16 v17, v13

    :cond_3
    :goto_2
    invoke-interface {v4}, Lcom/google/android/gms/common/api/a$f;->providesSignIn()Z

    move-result v4

    if-eqz v4, :cond_0

    if-nez v16, :cond_4

    move-object/from16 v16, v21

    goto/16 :goto_0

    :cond_4
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual/range {v21 .. v21}, Lcom/google/android/gms/common/api/a;->d()Ljava/lang/String;

    move-result-object v2

    invoke-virtual/range {v16 .. v16}, Lcom/google/android/gms/common/api/a;->d()Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "tusn  wieno aet bqs c"

    const-string v2, "cottanwsquin ebe   d "

    const-string v2, "cbhmst ote  uniden  a"

    const-string v2, " cannot be used with "

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_5
    if-eqz v16, :cond_8

    if-nez v17, :cond_7

    iget-object v3, v1, Lcom/google/android/gms/common/api/l$a;->a:Landroid/accounts/Account;

    if-nez v3, :cond_6

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    goto :goto_3

    :cond_6
    move v3, v13

    move v3, v13

    move v3, v13

    move v3, v13

    :goto_3
    new-array v4, v2, [Ljava/lang/Object;

    invoke-virtual/range {v16 .. v16}, Lcom/google/android/gms/common/api/a;->d()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v13

    const-string v5, " rnlo ei Atsa  olBenoi stwBninOnopgt eSiicdo.%etpn ldusgs.l. tgdouheS oiunu CuniGcsen   giieotncaltscIosMnatGairenue"

    const-string/jumbo v5, "otsidno  tul.dnntMonsetpn oia ci.ASe lsGsiiepoued nne s.luu  usrrtSgt egeitenceIi OlBsctg nnw inChoonGlacuaigno%aiB "

    const-string/jumbo v5, "nn.i bogutc  oeiap eGiiGr.ulisn swet aBltchdleeccnngtginn OotsCgonAltiniuao dndutonauseee   St inop .rloeB%ntui sMsS"

    const-string v5, "Must not set an account in GoogleApiClient.Builder when using %s. Set account in GoogleSignInOptions.Builder instead"

    invoke-static {v3, v5, v4}, Lcom/google/android/gms/common/internal/v;->z(ZLjava/lang/String;[Ljava/lang/Object;)V

    iget-object v3, v1, Lcom/google/android/gms/common/api/l$a;->b:Ljava/util/Set;

    iget-object v4, v1, Lcom/google/android/gms/common/api/l$a;->c:Ljava/util/Set;

    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    new-array v4, v2, [Ljava/lang/Object;

    invoke-virtual/range {v16 .. v16}, Lcom/google/android/gms/common/api/a;->d()Ljava/lang/String;

    move-result-object v5

    aput-object v5, v4, v13

    const-string/jumbo v5, "oBnn  uiGdoe. netSouosoinleoiGss.rtlntsec  i.lIu%O.oni aieB eitn cwdeiu lsultg phMuengc inCs onetS gptrAntdgimses"

    const-string v5, "cudmsOtnsrliiri insnpG Iu.nienAt.gdouos  Sea.oeilgni wg tielBosi  clst %td gC eoGen uasnoeoc.eSBeetusitntMolhp nn"

    const-string/jumbo v5, "pu  toepsseus As pdguinosllBnSs..snoe golta  tiBoiisCeh nuGreditctrg%uiSainweitGI.   n ioocetnnOnecngnotldliMe.pe"

    const-string v5, "Must not set scopes in GoogleApiClient.Builder when using %s. Set account in GoogleSignInOptions.Builder instead."

    invoke-static {v3, v5, v4}, Lcom/google/android/gms/common/internal/v;->z(ZLjava/lang/String;[Ljava/lang/Object;)V

    goto :goto_4

    :cond_7
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual/range {v16 .. v16}, Lcom/google/android/gms/common/api/a;->d()Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "tWhu insqig"

    const-string/jumbo v4, "nWhioui stg"

    const-string v4, "With using "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "c sm oenyne,col nneitirtubdfneOi dboia heipiGnssOt.SogisIegnllp iaGoBpw"

    const-string/jumbo v2, "ltcSpbcrneta nai hewe.eingo neoonfipislIsgepi ,Oniit dssdooOGm BnlyiGub"

    const-string v2, ".gumniIhssot oniwimtiepeBn ipo sdlpd y taSGeolb esOO,rgnoeneaGifinin cl"

    const-string v2, ", GamesOptions can only be specified within GoogleSignInOptions.Builder"

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8
    :goto_4
    invoke-interface {v14}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v3

    invoke-static {v3, v2}, Lcom/google/android/gms/common/api/internal/j1;->K(Ljava/lang/Iterable;Z)I

    move-result v16

    iget-object v5, v1, Lcom/google/android/gms/common/api/l$a;->i:Landroid/content/Context;

    new-instance v2, Lcom/google/android/gms/common/api/internal/j1;

    new-instance v6, Ljava/util/concurrent/locks/ReentrantLock;

    invoke-direct {v6}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    iget-object v7, v1, Lcom/google/android/gms/common/api/l$a;->n:Landroid/os/Looper;

    iget-object v9, v1, Lcom/google/android/gms/common/api/l$a;->o:Lcom/google/android/gms/common/f;

    iget-object v10, v1, Lcom/google/android/gms/common/api/l$a;->p:Lcom/google/android/gms/common/api/a$a;

    iget-object v12, v1, Lcom/google/android/gms/common/api/l$a;->q:Ljava/util/ArrayList;

    iget-object v13, v1, Lcom/google/android/gms/common/api/l$a;->r:Ljava/util/ArrayList;

    iget v3, v1, Lcom/google/android/gms/common/api/l$a;->l:I

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v0, v15

    move-object v0, v15

    move-object v0, v15

    move-object v0, v15

    move v15, v3

    move v15, v3

    move v15, v3

    move-object/from16 v17, v0

    move-object/from16 v17, v0

    move-object/from16 v17, v0

    move-object/from16 v17, v0

    invoke-direct/range {v4 .. v17}, Lcom/google/android/gms/common/api/internal/j1;-><init>(Landroid/content/Context;Ljava/util/concurrent/locks/Lock;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/f;Lcom/google/android/gms/common/api/a$a;Ljava/util/Map;Ljava/util/List;Ljava/util/List;Ljava/util/Map;IILjava/util/ArrayList;)V

    invoke-static {}, Lcom/google/android/gms/common/api/l;->J()Ljava/util/Set;

    move-result-object v3

    monitor-enter v3

    :try_start_0
    invoke-static {}, Lcom/google/android/gms/common/api/l;->J()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    monitor-exit v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    iget v0, v1, Lcom/google/android/gms/common/api/l$a;->l:I

    if-ltz v0, :cond_9

    iget-object v0, v1, Lcom/google/android/gms/common/api/l$a;->k:Lcom/google/android/gms/common/api/internal/l;

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/p3;->i(Lcom/google/android/gms/common/api/internal/l;)Lcom/google/android/gms/common/api/internal/p3;

    move-result-object v0

    iget v3, v1, Lcom/google/android/gms/common/api/l$a;->l:I

    iget-object v4, v1, Lcom/google/android/gms/common/api/l$a;->m:Lcom/google/android/gms/common/api/l$c;

    invoke-virtual {v0, v3, v2, v4}, Lcom/google/android/gms/common/api/internal/p3;->j(ILcom/google/android/gms/common/api/l;Lcom/google/android/gms/common/api/l$c;)V

    :cond_9
    return-object v2

    :catchall_0
    move-exception v0

    :try_start_1
    monitor-exit v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public i(Landroidx/fragment/app/FragmentActivity;ILcom/google/android/gms/common/api/l$c;)Lcom/google/android/gms/common/api/l$a;
    .locals 4
    .param p1    # Landroidx/fragment/app/FragmentActivity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/gms/common/api/l$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/common/api/internal/l;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/api/internal/l;-><init>(Landroid/app/Activity;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-ltz p2, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const-string v1, "  -notmstaIcenle vodinuuebneg"

    const-string v1, " cIaoeutei lneuentngvsmt d-nb"

    const/4 v3, 0x7

    const-string v1, "-nenebbdtiglnvns icteoIet m a"

    const-string v1, "clientId must be non-negative"

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-static {p1, v1}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput p2, p0, Lcom/google/android/gms/common/api/l$a;->l:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object p3, p0, Lcom/google/android/gms/common/api/l$a;->m:Lcom/google/android/gms/common/api/l$c;

    const/4 v3, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/l$a;->k:Lcom/google/android/gms/common/api/internal/l;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p0
.end method

.method public j(Landroidx/fragment/app/FragmentActivity;Lcom/google/android/gms/common/api/l$c;)Lcom/google/android/gms/common/api/l$a;
    .locals 3
    .param p1    # Landroidx/fragment/app/FragmentActivity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/api/l$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0, p2}, Lcom/google/android/gms/common/api/l$a;->i(Landroidx/fragment/app/FragmentActivity;ILcom/google/android/gms/common/api/l$c;)Lcom/google/android/gms/common/api/l$a;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public k(Ljava/lang/String;)Lcom/google/android/gms/common/api/l$a;
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Landroid/accounts/Account;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v1, ".glopcueog"

    const-string/jumbo v1, "olcgm.gpoe"

    const/4 v3, 0x1

    const-string/jumbo v1, "mocglgopoe"

    const-string v1, "com.google"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, p1, v1}, Landroid/accounts/Account;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/l$a;->a:Landroid/accounts/Account;

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object p0
.end method

.method public l(I)Lcom/google/android/gms/common/api/l$a;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    iput p1, p0, Lcom/google/android/gms/common/api/l$a;->d:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method public m(Landroid/os/Handler;)Lcom/google/android/gms/common/api/l$a;
    .locals 3
    .param p1    # Landroid/os/Handler;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, "dnHul leqtrnlm qns b ote"

    const-string/jumbo v0, "tmslnlnaqdonH r ete bl u"

    const/4 v2, 0x5

    const-string/jumbo v0, "s smeutlbt rHeon  lnunda"

    const-string v0, "Handler must not be null"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/api/l$a;->n:Landroid/os/Looper;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method public n(Landroid/view/View;)Lcom/google/android/gms/common/api/l$a;
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, "Vllmunus sonewbmi   t"

    const-string v0, "  ssulnblVtiwo enum e"

    const/4 v2, 0x7

    const-string/jumbo v0, "i ewol osten muuVtln "

    const-string v0, "View must not be null"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/l$a;->e:Landroid/view/View;

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method public o()Lcom/google/android/gms/common/api/l$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string v0, " fnlmbdt>cut<eu>a<a"

    const-string/jumbo v0, "ft<mn> <>eaclcadtuu"

    const/4 v2, 0x7

    const-string/jumbo v0, "ucd fcua<>nu<>taotl"

    const-string v0, "<<default account>>"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/api/l$a;->k(Ljava/lang/String;)Lcom/google/android/gms/common/api/l$a;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method public final p()Lcom/google/android/gms/common/internal/g;
    .locals 13
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    sget-object v0, Lcom/google/android/gms/signin/a;->j:Lcom/google/android/gms/signin/a;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/api/l$a;->j:Ljava/util/Map;

    const/4 v11, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    sget-object v2, Lcom/google/android/gms/signin/e;->g:Lcom/google/android/gms/common/api/a;

    const/4 v11, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-interface {v1, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    if-eqz v1, :cond_0

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/l$a;->j:Ljava/util/Map;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x4

    check-cast v0, Lcom/google/android/gms/signin/a;

    :cond_0
    move-object v9, v0

    move-object v9, v0

    move-object v9, v0

    const/4 v12, 0x5

    const/4 v11, 0x5

    new-instance v0, Lcom/google/android/gms/common/internal/g;

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x1

    iget-object v2, p0, Lcom/google/android/gms/common/api/l$a;->a:Landroid/accounts/Account;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x1

    iget-object v3, p0, Lcom/google/android/gms/common/api/l$a;->b:Ljava/util/Set;

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget-object v4, p0, Lcom/google/android/gms/common/api/l$a;->h:Ljava/util/Map;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x3

    iget v5, p0, Lcom/google/android/gms/common/api/l$a;->d:I

    const/4 v12, 0x6

    const/4 v11, 0x4

    iget-object v6, p0, Lcom/google/android/gms/common/api/l$a;->e:Landroid/view/View;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget-object v7, p0, Lcom/google/android/gms/common/api/l$a;->f:Ljava/lang/String;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget-object v8, p0, Lcom/google/android/gms/common/api/l$a;->g:Ljava/lang/String;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 v10, 0x0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-direct/range {v1 .. v10}, Lcom/google/android/gms/common/internal/g;-><init>(Landroid/accounts/Account;Ljava/util/Set;Ljava/util/Map;ILandroid/view/View;Ljava/lang/String;Ljava/lang/String;Lcom/google/android/gms/signin/a;Z)V

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x4

    return-object v0
.end method
