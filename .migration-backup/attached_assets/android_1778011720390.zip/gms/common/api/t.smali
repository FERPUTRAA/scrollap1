.class public abstract Lcom/google/android/gms/common/api/t;
.super Lcom/google/android/gms/common/api/x;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<R::",
        "Lcom/google/android/gms/common/api/v;",
        ">",
        "Lcom/google/android/gms/common/api/x<",
        "TR;>;"
    }
.end annotation


# instance fields
.field private final a:Landroid/app/Activity;

.field private final b:I


# direct methods
.method protected constructor <init>(Landroid/app/Activity;I)V
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/common/api/x;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string/jumbo v0, "sbs lvtm oni cAyint teluu"

    const-string/jumbo v0, "umst   uenybinitol vAtcsl"

    const/4 v2, 0x5

    const-string v0, " mlmltibvtttse yioncnu  u"

    const-string v0, "Activity must not be null"

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/api/t;->a:Landroid/app/Activity;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p2, p0, Lcom/google/android/gms/common/api/t;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public final b(Lcom/google/android/gms/common/api/Status;)V
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/Status;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@~/oo@c@@ t~~i~Sbbb~@ ~ t@~@if~o.@s4@o Km~ @ @~l~/ ~niv a@-~o~@M u @1 ~~~d@ y r f@@ @@~l~o~o@~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/Status;->C2()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/t;->a:Landroid/app/Activity;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/android/gms/common/api/t;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1, v0, v1}, Lcom/google/android/gms/common/api/Status;->F2(Landroid/app/Activity;I)V
    :try_end_0
    .catch Landroid/content/IntentSender$SendIntentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string/jumbo v0, "otsmCkubelllaagnlvRecsR"

    const/4 v3, 0x5

    const-string/jumbo v0, "kteusbsRlvlnoabCeaclgli"

    const-string v0, "ResolvingResultCallback"

    const/4 v3, 0x0

    const-string/jumbo v1, "looti udttFotloeuersraa in"

    const-string/jumbo v1, "toidoualitrloattens  oserF"

    const/4 v3, 0x3

    const-string v1, "eluFoatprtn ia lodssettor "

    const-string v1, "Failed to start resolution"

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance p1, Lcom/google/android/gms/common/api/Status;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/16 v0, 0x8

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/api/Status;-><init>(I)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/t;->d(Lcom/google/android/gms/common/api/Status;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/t;->d(Lcom/google/android/gms/common/api/Status;)V

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method public abstract c(Lcom/google/android/gms/common/api/v;)V
    .param p1    # Lcom/google/android/gms/common/api/v;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TR;)V"
        }
    .end annotation
.end method

.method public abstract d(Lcom/google/android/gms/common/api/Status;)V
    .param p1    # Lcom/google/android/gms/common/api/Status;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method
