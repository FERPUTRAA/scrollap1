.class public interface abstract Lcom/google/android/gms/common/api/n;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()[Lcom/google/android/gms/common/Feature;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end method
