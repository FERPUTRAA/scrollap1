.class public final Lcom/google/android/gms/common/api/k0;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x7

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    const/4 v1, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    const/4 v2, 0x0

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    move v4, v2

    move v4, v2

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-ge v5, v0, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v5

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {v5}, Lh4/a;->O(I)I

    move-result v6

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 v7, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-eq v6, v7, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/4 v7, 0x2

    const/4 v9, 0x6

    if-eq v6, v7, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-eq v6, v7, :cond_1

    const/4 v8, 0x3

    move v9, v8

    const/4 v7, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    move v9, v8

    if-eq v6, v7, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {p1, v5}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    sget-object v3, Lcom/google/android/gms/common/ConnectionResult;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-static {p1, v5, v3}, Lh4/a;->C(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    check-cast v3, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    goto :goto_0

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    sget-object v2, Landroid/app/PendingIntent;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v9, 0x5

    const/4 v8, 0x2

    invoke-static {p1, v5, v2}, Lh4/a;->C(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    check-cast v2, Landroid/app/PendingIntent;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_0

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {p1, v5}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    goto :goto_0

    :cond_3
    const/4 v8, 0x3

    move v9, v8

    invoke-static {p1, v5}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v4

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    goto/16 :goto_0

    :cond_4
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-instance p1, Lcom/google/android/gms/common/api/Status;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-direct {p1, v4, v1, v2, v3}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;Landroid/app/PendingIntent;Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    return-object p1
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    new-array p1, p1, [Lcom/google/android/gms/common/api/Status;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method
