.class public Lcom/google/android/gms/common/api/k$a$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/api/k$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field private a:Lcom/google/android/gms/common/api/internal/y;

.field private b:Landroid/os/Looper;


# direct methods
.method public constructor <init>()V
    .locals 2
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a()Lcom/google/android/gms/common/api/k$a;
    .locals 6
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/k$a$a;->a:Lcom/google/android/gms/common/api/internal/y;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance v0, Lcom/google/android/gms/common/api/internal/b;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/common/api/internal/b;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/api/k$a$a;->a:Lcom/google/android/gms/common/api/internal/y;

    :cond_0
    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/k$a$a;->b:Landroid/os/Looper;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput-object v0, p0, Lcom/google/android/gms/common/api/k$a$a;->b:Landroid/os/Looper;

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v0, Lcom/google/android/gms/common/api/k$a;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/api/k$a$a;->a:Lcom/google/android/gms/common/api/internal/y;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/google/android/gms/common/api/k$a$a;->b:Landroid/os/Looper;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v0, v1, v3, v2, v3}, Lcom/google/android/gms/common/api/k$a;-><init>(Lcom/google/android/gms/common/api/internal/y;Landroid/accounts/Account;Landroid/os/Looper;Lcom/google/android/gms/common/api/f0;)V

    const/4 v4, 0x3

    and-int/2addr v5, v4

    return-object v0
.end method

.method public b(Landroid/os/Looper;)Lcom/google/android/gms/common/api/k$a$a;
    .locals 3
    .param p1    # Landroid/os/Looper;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-string/jumbo v0, "ntspoeeuLsb mounr . tlsl"

    const-string/jumbo v0, "ltsLbusne rnu m.opeltoo "

    const/4 v2, 0x3

    const-string/jumbo v0, "ueomepul to om.nLtrbn sl"

    const-string v0, "Looper must not be null."

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/api/k$a$a;->b:Landroid/os/Looper;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public c(Lcom/google/android/gms/common/api/internal/y;)Lcom/google/android/gms/common/api/k$a$a;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/internal/y;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string/jumbo v0, "n .moSueutcxMtlepaeilar ttt oombnpussn "

    const-string v0, "eEum.benta prom  nn slsotilMaStutcxtpue"

    const/4 v2, 0x0

    const-string/jumbo v0, "nn t betellbppxM iottusmeracnsutuE.pSo "

    const-string v0, "StatusExceptionMapper must not be null."

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/k$a$a;->a:Lcom/google/android/gms/common/api/internal/y;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method
