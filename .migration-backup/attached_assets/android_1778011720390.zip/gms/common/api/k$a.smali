.class public Lcom/google/android/gms/common/api/k$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/api/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/api/k$a$a;
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final c:Lcom/google/android/gms/common/api/k$a;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field


# instance fields
.field public final a:Lcom/google/android/gms/common/api/internal/y;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public final b:Landroid/os/Looper;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/gms/common/api/k$a$a;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/common/api/k$a$a;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/k$a$a;->a()Lcom/google/android/gms/common/api/k$a;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    sput-object v0, Lcom/google/android/gms/common/api/k$a;->c:Lcom/google/android/gms/common/api/k$a;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>(Lcom/google/android/gms/common/api/internal/y;Landroid/accounts/Account;Landroid/os/Looper;)V
    .locals 2
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/api/k$a;->a:Lcom/google/android/gms/common/api/internal/y;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/google/android/gms/common/api/k$a;->b:Landroid/os/Looper;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/gms/common/api/internal/y;Landroid/accounts/Account;Landroid/os/Looper;Lcom/google/android/gms/common/api/f0;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 p2, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/gms/common/api/k$a;-><init>(Lcom/google/android/gms/common/api/internal/y;Landroid/accounts/Account;Landroid/os/Looper;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method
