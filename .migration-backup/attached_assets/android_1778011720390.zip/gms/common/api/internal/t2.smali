.class public final Lcom/google/android/gms/common/api/internal/t2;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/util/concurrent/ExecutorService;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/android/gms/internal/base/zat;->zaa()Lcom/google/android/gms/internal/base/zaq;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v1, Lcom/google/android/gms/common/util/concurrent/c;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v2, "oasrf_CmTsGAs"

    const-string v2, "TAs_CGfsoamrn"

    const/4 v4, 0x6

    const-string v2, "Gf_mnsAoTmaCr"

    const-string v2, "GAC_Transform"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v1, v2}, Lcom/google/android/gms/common/util/concurrent/c;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x1

    move v4, v2

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    invoke-interface {v0, v1, v2}, Lcom/google/android/gms/internal/base/zaq;->zaa(Ljava/util/concurrent/ThreadFactory;I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    sput-object v0, Lcom/google/android/gms/common/api/internal/t2;->a:Ljava/util/concurrent/ExecutorService;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void
.end method

.method public static a()Ljava/util/concurrent/ExecutorService;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @lbo /im@o~@an  @c@/~@@sb  ~t~@ o@@i4~@ d@@~~ ~ u1~~~if~@ l@~~v-o Moy ~o~ f@ rK @@~~~o~~b@~@. t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/common/api/internal/t2;->a:Ljava/util/concurrent/ExecutorService;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method
