.class public final Lcom/google/android/gms/common/api/internal/i0;
.super Lcom/google/android/gms/common/api/internal/u3;


# instance fields
.field private final e:Landroidx/collection/c;

.field private final f:Lcom/google/android/gms/common/api/internal/i;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/m;Lcom/google/android/gms/common/api/internal/i;Lcom/google/android/gms/common/f;)V
    .locals 2
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0, p1, p3}, Lcom/google/android/gms/common/api/internal/u3;-><init>(Lcom/google/android/gms/common/api/internal/m;Lcom/google/android/gms/common/f;)V

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    new-instance p1, Landroidx/collection/c;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p1}, Landroidx/collection/c;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/i0;->e:Landroidx/collection/c;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/i0;->f:Lcom/google/android/gms/common/api/internal/i;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->mLifecycleFragment:Lcom/google/android/gms/common/api/internal/m;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    const-string/jumbo p2, "otsspnsrecncesyoleCeenfLilclH"

    const-string/jumbo p2, "pcsltienneyCsrlolefeecLcHoisn"

    const/4 v1, 0x4

    const-string p2, "csnmryeCeieeHeoeolfclsnlcipLn"

    const-string p2, "ConnectionlessLifecycleHelper"

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-interface {p1, p2, p0}, Lcom/google/android/gms/common/api/internal/m;->d(Ljava/lang/String;Lcom/google/android/gms/common/api/internal/LifecycleCallback;)V

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static j(Landroid/app/Activity;Lcom/google/android/gms/common/api/internal/i;Lcom/google/android/gms/common/api/internal/c;)V
    .locals 4
    .annotation build Landroidx/annotation/l0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "oct o/~ K-~~fl1~~ ~ nf~~o@ @  io@ ~ ~l~o@@/~ ~@o~@ obiS @i @~drM@@u~@ ~.t~~@a b@ ~m@s@~@y@~@@4b "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->getFragment(Landroid/app/Activity;)Lcom/google/android/gms/common/api/internal/m;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const-string/jumbo v0, "rpstsbifycemHeoneLcelinlocene"

    const-string v0, "esnmlcinsprifyeoloccLCeteeeHn"

    const/4 v3, 0x7

    const-string/jumbo v0, "nHeiiruoeslpCesocneclecfnlLte"

    const-string v0, "ConnectionlessLifecycleHelper"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/common/api/internal/i0;

    const-class v1, Lcom/google/android/gms/common/api/internal/i0;

    const-class v1, Lcom/google/android/gms/common/api/internal/i0;

    const-class v1, Lcom/google/android/gms/common/api/internal/i0;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {p0, v0, v1}, Lcom/google/android/gms/common/api/internal/m;->j(Ljava/lang/String;Ljava/lang/Class;)Lcom/google/android/gms/common/api/internal/LifecycleCallback;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v0, Lcom/google/android/gms/common/api/internal/i0;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/common/api/internal/i0;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/android/gms/common/f;->x()Lcom/google/android/gms/common/f;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, p0, p1, v1}, Lcom/google/android/gms/common/api/internal/i0;-><init>(Lcom/google/android/gms/common/api/internal/m;Lcom/google/android/gms/common/api/internal/i;Lcom/google/android/gms/common/f;)V

    :cond_0
    const/4 v3, 0x0

    const-string/jumbo p0, "li nbonpuocKneAaepl y"

    const-string p0, "a ulop Knnylci ebonAe"

    const/4 v3, 0x2

    const-string p0, "Kocyplleqna tAui nb e"

    const-string p0, "ApiKey cannot be null"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p2, p0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    and-int/2addr v3, v2

    iget-object p0, v0, Lcom/google/android/gms/common/api/internal/i0;->e:Landroidx/collection/c;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0, p2}, Landroidx/collection/c;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/api/internal/i;->b(Lcom/google/android/gms/common/api/internal/i0;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method private final k()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i0;->e:Landroidx/collection/c;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroidx/collection/c;->isEmpty()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i0;->f:Lcom/google/android/gms/common/api/internal/i;

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/api/internal/i;->b(Lcom/google/android/gms/common/api/internal/i0;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method protected final b(Lcom/google/android/gms/common/ConnectionResult;I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i0;->f:Lcom/google/android/gms/common/api/internal/i;

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/common/api/internal/i;->I(Lcom/google/android/gms/common/ConnectionResult;I)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method protected final c()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i0;->f:Lcom/google/android/gms/common/api/internal/i;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/i;->J()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method final i()Landroidx/collection/c;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i0;->e:Landroidx/collection/c;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public final onResume()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-super {p0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->onResume()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/i0;->k()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public final onStart()V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-super {p0}, Lcom/google/android/gms/common/api/internal/u3;->onStart()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/i0;->k()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public final onStop()V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-super {p0}, Lcom/google/android/gms/common/api/internal/u3;->onStop()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i0;->f:Lcom/google/android/gms/common/api/internal/i;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/api/internal/i;->c(Lcom/google/android/gms/common/api/internal/i0;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method
