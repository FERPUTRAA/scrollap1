.class public final Lcom/google/android/gms/common/api/internal/q3;
.super Ljava/lang/Object;


# instance fields
.field private final a:Landroidx/collection/a;

.field private final b:Landroidx/collection/a;

.field private final c:Lcom/google/android/gms/tasks/TaskCompletionSource;

.field private d:I

.field private e:Z


# direct methods
.method public constructor <init>(Ljava/lang/Iterable;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance v0, Landroidx/collection/a;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v0}, Landroidx/collection/a;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/q3;->b:Landroidx/collection/a;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v0, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/q3;->c:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-boolean v0, p0, Lcom/google/android/gms/common/api/internal/q3;->e:Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    new-instance v0, Landroidx/collection/a;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v0}, Landroidx/collection/a;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/q3;->a:Landroidx/collection/a;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    check-cast v0, Lcom/google/android/gms/common/api/m;

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/q3;->a:Landroidx/collection/a;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {v0}, Lcom/google/android/gms/common/api/m;->getApiKey()Lcom/google/android/gms/common/api/internal/c;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1, v0, v2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/q3;->a:Landroidx/collection/a;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroidx/collection/a;->keySet()Ljava/util/Set;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-interface {p1}, Ljava/util/Set;->size()I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput p1, p0, Lcom/google/android/gms/common/api/internal/q3;->d:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void
.end method


# virtual methods
.method public final a()Lcom/google/android/gms/tasks/Task;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o~sl  ~i@@ ~1o~~@4 @o  m@S@b Mor~~@~~~fftba@ @~  @ snul~~~@@@~by @@~~.o@t @K~vii ~@~/ c -d@~o /~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/q3;->c:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public final b()Ljava/util/Set;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/q3;->a:Landroidx/collection/a;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroidx/collection/a;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public final c(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/String;)V
    .locals 3
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/q3;->a:Landroidx/collection/a;

    const/4 v2, 0x2

    invoke-virtual {v0, p1, p2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/q3;->b:Landroidx/collection/a;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p3}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget p1, p0, Lcom/google/android/gms/common/api/internal/q3;->d:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/common/api/internal/q3;->d:I

    const/4 v1, 0x4

    or-int/2addr v2, v1

    invoke-virtual {p2}, Lcom/google/android/gms/common/ConnectionResult;->C2()Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-boolean p1, p0, Lcom/google/android/gms/common/api/internal/q3;->e:Z

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget p1, p0, Lcom/google/android/gms/common/api/internal/q3;->d:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-nez p1, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-boolean p1, p0, Lcom/google/android/gms/common/api/internal/q3;->e:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz p1, :cond_1

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/q3;->a:Landroidx/collection/a;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance p2, Lcom/google/android/gms/common/api/c;

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p2, p1}, Lcom/google/android/gms/common/api/c;-><init>(Landroidx/collection/a;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/q3;->c:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setException(Ljava/lang/Exception;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/q3;->c:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/q3;->b:Landroidx/collection/a;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setResult(Ljava/lang/Object;)V

    :cond_2
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method
