.class public abstract Lcom/google/android/gms/common/api/internal/u3;
.super Lcom/google/android/gms/common/api/internal/LifecycleCallback;

# interfaces
.implements Landroid/content/DialogInterface$OnCancelListener;


# instance fields
.field protected volatile a:Z

.field protected final b:Ljava/util/concurrent/atomic/AtomicReference;

.field private final c:Landroid/os/Handler;

.field protected final d:Lcom/google/android/gms/common/f;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/m;Lcom/google/android/gms/common/f;)V
    .locals 3
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;-><init>(Lcom/google/android/gms/common/api/internal/m;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/u3;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance p1, Lcom/google/android/gms/internal/base/zau;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Lcom/google/android/gms/internal/base/zau;-><init>(Landroid/os/Looper;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/u3;->c:Landroid/os/Handler;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/u3;->d:Lcom/google/android/gms/common/f;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method private final a(Lcom/google/android/gms/common/ConnectionResult;I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s~ua@l-M o@lbd .@~@ c~@~@@~~~~@@   ri~@Sb~ K v@ t   @ i ys~@~~no~~o@~4@ ~ tom~~f@i ~/oof~~b@@/"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u3;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/common/api/internal/u3;->b(Lcom/google/android/gms/common/ConnectionResult;I)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method private final d()V
    .locals 4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u3;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/u3;->c()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method private static final e(Lcom/google/android/gms/common/api/internal/r3;)I
    .locals 2
    .param p0    # Lcom/google/android/gms/common/api/internal/r3;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    if-nez p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p0, -0x1

    const/4 v1, 0x6

    const/4 v0, 0x6

    return p0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/r3;->a()I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p0
.end method

.method static bridge synthetic f(Lcom/google/android/gms/common/api/internal/u3;Lcom/google/android/gms/common/ConnectionResult;I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/api/internal/u3;->a(Lcom/google/android/gms/common/ConnectionResult;I)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    return-void
.end method

.method static bridge synthetic g(Lcom/google/android/gms/common/api/internal/u3;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/u3;->d()V

    const/4 v0, 0x2

    and-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method protected abstract b(Lcom/google/android/gms/common/ConnectionResult;I)V
.end method

.method protected abstract c()V
.end method

.method public final h(Lcom/google/android/gms/common/ConnectionResult;I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance v0, Lcom/google/android/gms/common/api/internal/r3;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0, p1, p2}, Lcom/google/android/gms/common/api/internal/r3;-><init>(Lcom/google/android/gms/common/ConnectionResult;I)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/u3;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 p2, 0x0

    or-int/2addr v2, p2

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1, p2, v0}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz p2, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/u3;->c:Landroid/os/Handler;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p2, Lcom/google/android/gms/common/api/internal/t3;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p2, p0, v0}, Lcom/google/android/gms/common/api/internal/t3;-><init>(Lcom/google/android/gms/common/api/internal/u3;Lcom/google/android/gms/common/api/internal/r3;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void

    :cond_1
    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public final onActivityResult(IILandroid/content/Intent;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u3;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/gms/common/api/internal/r3;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x6

    if-eq p1, v1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 p2, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eq p1, p2, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/u3;->d:Lcom/google/android/gms/common/f;

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->getActivity()Landroid/app/Activity;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Lcom/google/android/gms/common/f;->j(Landroid/content/Context;)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/u3;->d()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_6

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/r3;->b()Lcom/google/android/gms/common/ConnectionResult;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/16 p3, 0x12

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-ne p2, p3, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ne p1, p3, :cond_5

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto/16 :goto_1

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p1, -0x1

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ne p2, p1, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/u3;->d()V

    const/4 v3, 0x6

    return-void

    :cond_3
    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez p2, :cond_5

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_6

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/16 p1, 0xd

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p3, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string/jumbo p2, "renmstalR>rEFe>euDolti<uiaorsi<l"

    const-string p2, "eestl<u>ilorrne<aor>tiDiaFlurREs"

    const/4 v3, 0x0

    const-string/jumbo p2, "srerotuo<l<i>onRlDF>iroleiauarte"

    const-string p2, "<<ResolutionFailureErrorDetail>>"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p3, p2, p1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance p2, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/r3;->b()Lcom/google/android/gms/common/ConnectionResult;

    move-result-object p3

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p3}, Lcom/google/android/gms/common/ConnectionResult;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p2, p1, v1, p3}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/u3;->e(Lcom/google/android/gms/common/api/internal/r3;)I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p0, p2, p1}, Lcom/google/android/gms/common/api/internal/u3;->a(Lcom/google/android/gms/common/ConnectionResult;I)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_5
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_6

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/r3;->b()Lcom/google/android/gms/common/ConnectionResult;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/r3;->a()I

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/api/internal/u3;->a(Lcom/google/android/gms/common/ConnectionResult;I)V

    :cond_6
    :goto_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method public final onCancel(Landroid/content/DialogInterface;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance p1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/16 v0, 0xd

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    invoke-direct {p1, v0, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u3;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast v0, Lcom/google/android/gms/common/api/internal/r3;

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/u3;->e(Lcom/google/android/gms/common/api/internal/r3;)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/api/internal/u3;->a(Lcom/google/android/gms/common/ConnectionResult;I)V

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 6
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-super {p0, p1}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->onCreate(Landroid/os/Bundle;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz p1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u3;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo v1, "vrmrebsnl_ooire"

    const-string/jumbo v1, "rr_milorsvneore"

    const-string/jumbo v1, "loeig_uosrnrrvr"

    const-string/jumbo v1, "resolving_error"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p1, v1, v2}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v2, "tfstlaspa_udo"

    const-string/jumbo v2, "ilafo_ttaussd"

    const/4 v5, 0x7

    const-string/jumbo v2, "tlsu_stdqiafa"

    const-string/jumbo v2, "failed_status"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p1, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v3, "dts_osilenbuorlfa"

    const-string/jumbo v3, "itndrbfilauoeosl_"

    const/4 v5, 0x6

    const-string/jumbo v3, "ioamt_lnferoidsle"

    const-string/jumbo v3, "failed_resolution"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1, v3}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    check-cast v3, Landroid/app/PendingIntent;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {v1, v2, v3}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v2, "itefodi_aec_ulin"

    const-string/jumbo v2, "neiaflud_ctdi_ie"

    const/4 v5, 0x7

    const-string/jumbo v2, "iced_bleftnidai_"

    const-string/jumbo v2, "failed_client_id"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v3, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1, v2, v3}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance v2, Lcom/google/android/gms/common/api/internal/r3;

    const/4 v5, 0x5

    invoke-direct {v2, v1, p1}, Lcom/google/android/gms/common/api/internal/r3;-><init>(Lcom/google/android/gms/common/ConnectionResult;I)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    move v5, v2

    :goto_0
    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    :cond_1
    const/4 v4, 0x7

    const/4 v5, 0x5

    return-void
.end method

.method public final onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-super {p0, p1}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->onSaveInstanceState(Landroid/os/Bundle;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u3;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast v0, Lcom/google/android/gms/common/api/internal/r3;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x2

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v1, "igrpe_usrreorvo"

    const-string/jumbo v1, "oog_reiprrsenrv"

    const/4 v4, 0x6

    const-string/jumbo v1, "oerrsrvpniel_gr"

    const-string/jumbo v1, "resolving_error"

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x3

    move v3, v2

    move v3, v2

    const/4 v4, 0x3

    invoke-virtual {p1, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v1, "iea_idniqdt_efqc"

    const-string v1, "eaiefl__qtdinicd"

    const/4 v4, 0x1

    const-string/jumbo v1, "nestcldief_da_li"

    const-string/jumbo v1, "failed_client_id"

    const/4 v4, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/r3;->a()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, v1, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/r3;->b()Lcom/google/android/gms/common/ConnectionResult;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v2, "iaemdtsastfls"

    const-string v2, "adsatie_ltssf"

    const/4 v4, 0x0

    const-string/jumbo v2, "sa_foatetsidl"

    const-string/jumbo v2, "failed_status"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p1, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/r3;->b()Lcom/google/android/gms/common/ConnectionResult;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/common/ConnectionResult;->A2()Landroid/app/PendingIntent;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string v1, "eetfibruo_olnldia"

    const-string/jumbo v1, "failed_resolution"

    const/4 v4, 0x7

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void
.end method

.method public onStart()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-super {p0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->onStart()V

    const/4 v1, 0x5

    move v2, v1

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x3

    const/4 v1, 0x1

    iput-boolean v0, p0, Lcom/google/android/gms/common/api/internal/u3;->a:Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public onStop()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->onStop()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/google/android/gms/common/api/internal/u3;->a:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method
