.class final Lcom/google/android/gms/common/api/internal/y1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/ConnectionResult;

.field final synthetic b:Lcom/google/android/gms/common/api/internal/z1;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/z1;Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/y1;->b:Lcom/google/android/gms/common/api/internal/z1;

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/y1;->a:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "/@sM/@f~d~ ~ @~@ ot@~  @@rot~ o s~~  ~ooi~b@vlS~~@~y4~fnbu @i  ~  c@@-~~@b@@a@ i ~@~o l@~1~m~.K@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y1;->b:Lcom/google/android/gms/common/api/internal/z1;

    const/4 v6, 0x6

    const/4 v5, 0x1

    iget-object v1, v0, Lcom/google/android/gms/common/api/internal/z1;->f:Lcom/google/android/gms/common/api/internal/i;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/i;->C(Lcom/google/android/gms/common/api/internal/i;)Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/z1;->f(Lcom/google/android/gms/common/api/internal/z1;)Lcom/google/android/gms/common/api/internal/c;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    check-cast v0, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v6, 0x5

    if-nez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-void

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/y1;->a:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1}, Lcom/google/android/gms/common/ConnectionResult;->C2()Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x5

    or-int/2addr v6, v5

    if-eqz v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/y1;->b:Lcom/google/android/gms/common/api/internal/z1;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v1, v3}, Lcom/google/android/gms/common/api/internal/z1;->g(Lcom/google/android/gms/common/api/internal/z1;Z)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/y1;->b:Lcom/google/android/gms/common/api/internal/z1;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/z1;->e(Lcom/google/android/gms/common/api/internal/z1;)Lcom/google/android/gms/common/api/a$f;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {v1}, Lcom/google/android/gms/common/api/a$f;->requiresSignIn()Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v1, :cond_1

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y1;->b:Lcom/google/android/gms/common/api/internal/z1;

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/z1;->h(Lcom/google/android/gms/common/api/internal/z1;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-void

    :cond_1
    :try_start_0
    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/y1;->b:Lcom/google/android/gms/common/api/internal/z1;

    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/z1;->e(Lcom/google/android/gms/common/api/internal/z1;)Lcom/google/android/gms/common/api/a$f;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/z1;->e(Lcom/google/android/gms/common/api/internal/z1;)Lcom/google/android/gms/common/api/a$f;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-interface {v1}, Lcom/google/android/gms/common/api/a$f;->getScopesForConnectionlessNonSignIn()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-interface {v3, v2, v1}, Lcom/google/android/gms/common/api/a$f;->getRemoteService(Lcom/google/android/gms/common/internal/n;Ljava/util/Set;)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-void

    :catch_0
    move-exception v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string/jumbo v3, "rMlmaGiAapeoegsg"

    const-string/jumbo v3, "goseiGraeplgMaoA"

    const/4 v6, 0x7

    const-string/jumbo v3, "lGaAoeMaiornogeg"

    const-string v3, "GoogleApiManager"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v4, "bed fbrlm.oire Frskto  eaogetc rime"

    const-string v4, "Fr mgtelferoesce  roie  arodimb kt."

    const/4 v6, 0x4

    const-string/jumbo v4, "vF etcua  doe ftrrrokgbm. el ereios"

    const-string v4, "Failed to get service from broker. "

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v3, v4, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/y1;->b:Lcom/google/android/gms/common/api/internal/z1;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/z1;->e(Lcom/google/android/gms/common/api/internal/z1;)Lcom/google/android/gms/common/api/a$f;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string v3, "  rtbefpl rreg e.aeredviooimtFo co"

    const-string v3, "ee.eo rfmcr d ee F okibaotoglritvr"

    const/4 v6, 0x2

    const-string/jumbo v3, "toed grrq  lFimsv o.rtao erekcfbee"

    const-string v3, "Failed to get service from broker."

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v1, v3}, Lcom/google/android/gms/common/api/a$f;->disconnect(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    new-instance v1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v6, 0x5

    const/16 v3, 0xa

    const/4 v5, 0x5

    const/4 v5, 0x3

    invoke-direct {v1, v3}, Lcom/google/android/gms/common/ConnectionResult;-><init>(I)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/common/api/internal/v1;->I(Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/Exception;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/y1;->a:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/common/api/internal/v1;->I(Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/Exception;)V

    const/4 v6, 0x6

    return-void
.end method
