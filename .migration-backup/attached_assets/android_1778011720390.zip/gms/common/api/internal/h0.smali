.class public final Lcom/google/android/gms/common/api/internal/h0;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/util/Map;

.field private final b:Ljava/util/Map;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Ljava/util/WeakHashMap;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/h0;->a:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Ljava/util/WeakHashMap;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/h0;->b:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method static bridge synthetic a(Lcom/google/android/gms/common/api/internal/h0;)Ljava/util/Map;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "vSs-~@~/d~u~fc ~~oi@ @~@ ~ om @@@@o l a~ @1 ~@oi@ bt~~@@~ i@K~@  ~~ 4 .~~@ fb@~oybst@rnMl/ @~o~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/h0;->a:Ljava/util/Map;

    const/4 v0, 0x6

    move v1, v0

    return-object p0
.end method

.method static bridge synthetic b(Lcom/google/android/gms/common/api/internal/h0;)Ljava/util/Map;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/h0;->b:Ljava/util/Map;

    const/4 v1, 0x2

    return-object p0
.end method

.method private final h(ZLcom/google/android/gms/common/api/Status;)V
    .locals 6

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/h0;->a:Ljava/util/Map;

    const/4 v5, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    new-instance v1, Ljava/util/HashMap;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/h0;->a:Ljava/util/Map;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/h0;->b:Ljava/util/Map;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    monitor-enter v2

    :try_start_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v3, p0, Lcom/google/android/gms/common/api/internal/h0;->b:Ljava/util/Map;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v0, v3}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v2, :cond_2

    const/4 v4, 0x6

    move v5, v4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez p1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    check-cast v3, Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v3, :cond_0

    :cond_1
    const/4 v5, 0x5

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    check-cast v2, Lcom/google/android/gms/common/api/internal/BasePendingResult;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v2, p2}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->forceFailureUnlessReady(Lcom/google/android/gms/common/api/Status;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_3
    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v1, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-nez p1, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    check-cast v2, Ljava/lang/Boolean;

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v2, :cond_3

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    check-cast v1, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v2, Lcom/google/android/gms/common/api/b;

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-direct {v2, p2}, Lcom/google/android/gms/common/api/b;-><init>(Lcom/google/android/gms/common/api/Status;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/TaskCompletionSource;->trySetException(Ljava/lang/Exception;)Z

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto :goto_1

    :cond_5
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-void

    :catchall_0
    move-exception p1

    :try_start_2
    const/4 v5, 0x1

    const/4 v4, 0x4

    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    throw p1

    :catchall_1
    move-exception p1

    :try_start_3
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    throw p1
.end method


# virtual methods
.method final c(Lcom/google/android/gms/common/api/internal/BasePendingResult;Z)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/h0;->a:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance p2, Lcom/google/android/gms/common/api/internal/f0;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p2, p0, p1}, Lcom/google/android/gms/common/api/internal/f0;-><init>(Lcom/google/android/gms/common/api/internal/h0;Lcom/google/android/gms/common/api/internal/BasePendingResult;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Lcom/google/android/gms/common/api/p;->addStatusListener(Lcom/google/android/gms/common/api/p$a;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method final d(Lcom/google/android/gms/tasks/TaskCompletionSource;Z)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/h0;->b:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/api/internal/g0;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/api/internal/g0;-><init>(Lcom/google/android/gms/common/api/internal/h0;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-virtual {p2, v0}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method final e(ILjava/lang/String;)V
    .locals 5
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string v1, "c nmlw clsv g htTnoeP s ssclt eetynoeoGrooieaao"

    const-string/jumbo v1, "tlseo v T ote acscl ts lPewognn rhanoieoseyoscG"

    const/4 v4, 0x1

    const-string/jumbo v1, "og oo ollni i eaotcGssc Taltvee sc oyshnerwPten"

    const-string v1, "The connection to Google Play services was lost"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    move v4, v3

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-ne p1, v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const-string p1, " en dbcetnveitius  coemnr.docs"

    const-string p1, "c rmnt teunesenocdciv ed.o osi"

    const/4 v4, 0x1

    const-string/jumbo p1, "sei o.uoirdtvint uncdsc ne eec"

    const-string p1, " due to service disconnection."

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x2

    if-ne p1, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo p1, "etooocdpneddibt uo x ep  tjca."

    const-string/jumbo p1, "tdoao    xep eedbteijotu.dnocc"

    const/4 v4, 0x2

    const-string p1, "e edeubtq dit.dccxajeoooe p nt"

    const-string p1, " due to dead object exception."

    const/4 v3, 0x1

    move v4, v3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz p2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo p1, "s ss  itocsreebarnotnf :an od"

    const-string/jumbo p1, "tdoo bir  acsatn  fcoessrenn:"

    const/4 v4, 0x5

    const-string/jumbo p1, "tsnmec Lrefn soa ods:trcno a "

    const-string p1, " Last reason for disconnect: "

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance p2, Lcom/google/android/gms/common/api/Status;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/16 v0, 0x14

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p2, v0, p1}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p0, v1, p2}, Lcom/google/android/gms/common/api/internal/h0;->h(ZLcom/google/android/gms/common/api/Status;)V

    const/4 v4, 0x1

    return-void
.end method

.method public final f()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v1, Lcom/google/android/gms/common/api/internal/i;->r:Lcom/google/android/gms/common/api/Status;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {p0, v0, v1}, Lcom/google/android/gms/common/api/internal/h0;->h(ZLcom/google/android/gms/common/api/Status;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method final g()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/h0;->a:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/h0;->b:Ljava/util/Map;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    return v0

    :cond_1
    :goto_0
    const/4 v1, 0x7

    move v2, v1

    const/4 v0, 0x1

    xor-int/2addr v2, v0

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method
