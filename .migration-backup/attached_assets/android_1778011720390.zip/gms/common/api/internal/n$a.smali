.class public final Lcom/google/android/gms/common/api/internal/n$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/api/internal/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<",
        "L:Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field private final a:Ljava/lang/Object;

.field private final b:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/Object;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(T",
            "L;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n$a;->a:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/n$a;->b:Ljava/lang/String;

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n$a;->a:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-static {v0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/n$a;->b:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v2, "@"

    const-string v2, "@"

    const/4 v4, 0x1

    const-string v2, "@"

    const-string v2, "@"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x2

    if-ne p0, p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    instance-of v1, p1, Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-nez v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    return v2

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    check-cast p1, Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/n$a;->a:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v3, p1, Lcom/google/android/gms/common/api/internal/n$a;->a:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-ne v1, v3, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/n$a;->b:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object p1, p1, Lcom/google/android/gms/common/api/internal/n$a;->b:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x0

    return v0

    :cond_2
    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    return v2
.end method

.method public hashCode()I
    .locals 4
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n$a;->a:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    mul-int/lit8 v0, v0, 0x1f

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/n$a;->b:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    return v0
.end method
