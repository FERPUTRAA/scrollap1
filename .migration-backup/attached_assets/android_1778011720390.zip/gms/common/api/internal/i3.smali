.class public final Lcom/google/android/gms/common/api/internal/i3;
.super Ljava/lang/Object;


# static fields
.field public static final c:Lcom/google/android/gms/common/api/Status;


# instance fields
.field final a:Ljava/util/Set;
    .annotation build Landroidx/annotation/k1;
    .end annotation
.end field

.field private final b:Lcom/google/android/gms/common/api/internal/h3;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Lcom/google/android/gms/common/api/Status;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 v1, 0x8

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v2, " csssPovtccoee GsT ia oeiylwlon r ettol enhngsa"

    const-string v2, "The connection to Google Play services was lost"

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    sput-object v0, Lcom/google/android/gms/common/api/internal/i3;->c:Lcom/google/android/gms/common/api/Status;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Ljava/util/WeakHashMap;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/util/Collections;->synchronizedSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/i3;->a:Ljava/util/Set;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/gms/common/api/internal/h3;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/api/internal/h3;-><init>(Lcom/google/android/gms/common/api/internal/i3;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/i3;->b:Lcom/google/android/gms/common/api/internal/h3;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method final a(Lcom/google/android/gms/common/api/internal/BasePendingResult;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~l@mtn@ @/.o~f~ Mub~@dtbS@~~ fy~~    @/boi~~K @~~@o1@@@v~sc@@~ ~~ m  i ~@@4@~ l~ ao@ @~~@or ~o-i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i3;->a:Ljava/util/Set;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i3;->b:Lcom/google/android/gms/common/api/internal/h3;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->zan(Lcom/google/android/gms/common/api/internal/h3;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public final b()V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i3;->a:Ljava/util/Set;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-array v2, v1, [Lcom/google/android/gms/common/api/internal/BasePendingResult;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {v0, v2}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    check-cast v0, [Lcom/google/android/gms/common/api/internal/BasePendingResult;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    array-length v2, v0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-ge v1, v2, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    aget-object v3, v0, v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->zan(Lcom/google/android/gms/common/api/internal/h3;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v3}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->zam()Z

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/i3;->a:Ljava/util/Set;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {v4, v3}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x1

    return-void
.end method
