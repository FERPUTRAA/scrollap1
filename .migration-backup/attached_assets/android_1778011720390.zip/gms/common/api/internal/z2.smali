.class public final synthetic Lcom/google/android/gms/common/api/internal/z2;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/v;


# instance fields
.field public final synthetic a:Lcom/google/android/gms/common/util/d;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/common/util/d;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/z2;->a:Lcom/google/android/gms/common/util/d;

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l s/~@iybM~d~no~c.ibo -~o~u@~  4  ~@K om~~ofiS~~o@~   @1~b ~~@@@@~~@@~t @a~@/ svt@@@@ ~lf~@r  @@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/z2;->a:Lcom/google/android/gms/common/util/d;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    check-cast p1, Lcom/google/android/gms/common/api/a$b;

    const/4 v2, 0x4

    const/4 v1, 0x0

    check-cast p2, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0, p1, p2}, Lcom/google/android/gms/common/util/d;->accept(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method
