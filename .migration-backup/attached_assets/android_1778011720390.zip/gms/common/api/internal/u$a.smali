.class public Lcom/google/android/gms/common/api/internal/u$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/api/internal/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A::",
        "Lcom/google/android/gms/common/api/a$b;",
        "L:Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field private a:Lcom/google/android/gms/common/api/internal/v;

.field private b:Lcom/google/android/gms/common/api/internal/v;

.field private c:Ljava/lang/Runnable;

.field private d:Lcom/google/android/gms/common/api/internal/n;

.field private e:[Lcom/google/android/gms/common/Feature;

.field private f:Z

.field private g:I


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/common/api/internal/o2;->a:Lcom/google/android/gms/common/api/internal/o2;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/u$a;->c:Ljava/lang/Runnable;

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    move v2, v1

    iput-boolean v0, p0, Lcom/google/android/gms/common/api/internal/u$a;->f:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/gms/common/api/internal/r2;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    sget-object p1, Lcom/google/android/gms/common/api/internal/o2;->a:Lcom/google/android/gms/common/api/internal/o2;

    const/4 v0, 0x0

    shr-int/2addr v1, v0

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/u$a;->c:Ljava/lang/Runnable;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/gms/common/api/internal/u$a;->f:Z

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method static bridge synthetic i(Lcom/google/android/gms/common/api/internal/u$a;)Lcom/google/android/gms/common/api/internal/v;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "s1s4t  @~@@~oKl~ ~@ @r@ bo~@l~~o.c ~~ ~@~~ f ~-u@  @~f~b/~~oS  ~Mvbn@@t~ y@i @@~a@o~ o ~m@d@@ii/"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/u$a;->a:Lcom/google/android/gms/common/api/internal/v;

    const/4 v1, 0x3

    const/4 v0, 0x5

    return-object p0
.end method

.method static bridge synthetic j(Lcom/google/android/gms/common/api/internal/u$a;)Lcom/google/android/gms/common/api/internal/v;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/u$a;->b:Lcom/google/android/gms/common/api/internal/v;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method


# virtual methods
.method public a()Lcom/google/android/gms/common/api/internal/u;
    .locals 11
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/gms/common/api/internal/u<",
            "TA;T",
            "L;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u$a;->a:Lcom/google/android/gms/common/api/internal/v;

    const/4 v10, 0x0

    const/4 v1, 0x1

    const/4 v10, 0x2

    and-int/2addr v9, v1

    const/4 v10, 0x3

    const/4 v2, 0x0

    const/4 v10, 0x0

    move v9, v2

    move v9, v2

    const/4 v10, 0x2

    if-eqz v0, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    move v0, v1

    move v0, v1

    const/4 v10, 0x4

    move v0, v1

    move v0, v1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    goto :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v9, 0x6

    move v0, v2

    move v0, v2

    const/4 v10, 0x7

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    const-string/jumbo v3, "re mustrifisetnn tcg eMsts"

    const-string/jumbo v3, "sosf ereceMgunn stts tirti"

    const/4 v10, 0x1

    const-string/jumbo v3, "u itonstuMotins ee retcrfs"

    const-string v3, "Must set register function"

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {v0, v3}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u$a;->b:Lcom/google/android/gms/common/api/internal/v;

    const/4 v10, 0x4

    if-eqz v0, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    move v0, v1

    const/4 v10, 0x7

    move v0, v1

    move v0, v1

    const/4 v10, 0x5

    goto :goto_1

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    move v0, v2

    const/4 v10, 0x6

    move v0, v2

    move v0, v2

    :goto_1
    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-string v3, " ecsubftrMnumeionn sieugtrtt"

    const-string/jumbo v3, "g  meeuutnMe itcisntsrntuofr"

    const/4 v10, 0x6

    const-string/jumbo v3, "os e sucuut tfiiegttnnreuMns"

    const-string v3, "Must set unregister function"

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-static {v0, v3}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    const/4 v9, 0x6

    move v10, v9

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u$a;->d:Lcom/google/android/gms/common/api/internal/n;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    if-eqz v0, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    goto :goto_2

    :cond_2
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    move v1, v2

    const/4 v10, 0x4

    move v1, v2

    move v1, v2

    :goto_2
    const/4 v10, 0x2

    const/4 v9, 0x6

    const-string/jumbo v0, "hduMs sprloee o"

    const-string/jumbo v0, "tssMoedu  rhloe"

    const/4 v10, 0x3

    const-string/jumbo v0, "tlsste hqoreudM"

    const-string v0, "Must set holder"

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {v1, v0}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u$a;->d:Lcom/google/android/gms/common/api/internal/n;

    const/4 v9, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/n;->b()Lcom/google/android/gms/common/api/internal/n$a;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-string v1, "e sltmbbl unyne otuK"

    const-string/jumbo v1, "oyen btlu Ktnmblesu "

    const/4 v10, 0x2

    const-string v1, "Kelmtn utmuo  bnesl "

    const-string v1, "Key must not be null"

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    check-cast v0, Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    new-instance v1, Lcom/google/android/gms/common/api/internal/u;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    new-instance v8, Lcom/google/android/gms/common/api/internal/p2;

    const/4 v10, 0x1

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/u$a;->d:Lcom/google/android/gms/common/api/internal/n;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v5, p0, Lcom/google/android/gms/common/api/internal/u$a;->e:[Lcom/google/android/gms/common/Feature;

    const/4 v9, 0x3

    move v10, v9

    iget-boolean v6, p0, Lcom/google/android/gms/common/api/internal/u$a;->f:Z

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget v7, p0, Lcom/google/android/gms/common/api/internal/u$a;->g:I

    move-object v2, v8

    move-object v2, v8

    move-object v2, v8

    move-object v2, v8

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-direct/range {v2 .. v7}, Lcom/google/android/gms/common/api/internal/p2;-><init>(Lcom/google/android/gms/common/api/internal/u$a;Lcom/google/android/gms/common/api/internal/n;[Lcom/google/android/gms/common/Feature;ZI)V

    const/4 v9, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    new-instance v2, Lcom/google/android/gms/common/api/internal/q2;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-direct {v2, p0, v0}, Lcom/google/android/gms/common/api/internal/q2;-><init>(Lcom/google/android/gms/common/api/internal/u$a;Lcom/google/android/gms/common/api/internal/n$a;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u$a;->c:Ljava/lang/Runnable;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/4 v3, 0x0

    const/4 v9, 0x5

    shl-int/2addr v10, v9

    invoke-direct {v1, v8, v2, v0, v3}, Lcom/google/android/gms/common/api/internal/u;-><init>(Lcom/google/android/gms/common/api/internal/t;Lcom/google/android/gms/common/api/internal/c0;Ljava/lang/Runnable;Lcom/google/android/gms/common/api/internal/s2;)V

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    return-object v1
.end method

.method public b(Ljava/lang/Runnable;)Lcom/google/android/gms/common/api/internal/u$a;
    .locals 2
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Runnable;",
            ")",
            "Lcom/google/android/gms/common/api/internal/u$a<",
            "TA;T",
            "L;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/u$a;->c:Ljava/lang/Runnable;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method public c(Lcom/google/android/gms/common/api/internal/v;)Lcom/google/android/gms/common/api/internal/u$a;
    .locals 2
    .param p1    # Lcom/google/android/gms/common/api/internal/v;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/internal/v<",
            "TA;",
            "Lcom/google/android/gms/tasks/TaskCompletionSource<",
            "Ljava/lang/Void;",
            ">;>;)",
            "Lcom/google/android/gms/common/api/internal/u$a<",
            "TA;T",
            "L;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/u$a;->a:Lcom/google/android/gms/common/api/internal/v;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method public d(Z)Lcom/google/android/gms/common/api/internal/u$a;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)",
            "Lcom/google/android/gms/common/api/internal/u$a<",
            "TA;T",
            "L;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/gms/common/api/internal/u$a;->f:Z

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method public varargs e([Lcom/google/android/gms/common/Feature;)Lcom/google/android/gms/common/api/internal/u$a;
    .locals 2
    .param p1    # [Lcom/google/android/gms/common/Feature;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lcom/google/android/gms/common/Feature;",
            ")",
            "Lcom/google/android/gms/common/api/internal/u$a<",
            "TA;T",
            "L;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/u$a;->e:[Lcom/google/android/gms/common/Feature;

    const/4 v0, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public f(I)Lcom/google/android/gms/common/api/internal/u$a;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Lcom/google/android/gms/common/api/internal/u$a<",
            "TA;T",
            "L;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/common/api/internal/u$a;->g:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method public g(Lcom/google/android/gms/common/api/internal/v;)Lcom/google/android/gms/common/api/internal/u$a;
    .locals 2
    .param p1    # Lcom/google/android/gms/common/api/internal/v;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/internal/v<",
            "TA;",
            "Lcom/google/android/gms/tasks/TaskCompletionSource<",
            "Ljava/lang/Boolean;",
            ">;>;)",
            "Lcom/google/android/gms/common/api/internal/u$a<",
            "TA;T",
            "L;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/u$a;->b:Lcom/google/android/gms/common/api/internal/v;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method public h(Lcom/google/android/gms/common/api/internal/n;)Lcom/google/android/gms/common/api/internal/u$a;
    .locals 2
    .param p1    # Lcom/google/android/gms/common/api/internal/n;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/internal/n<",
            "T",
            "L;",
            ">;)",
            "Lcom/google/android/gms/common/api/internal/u$a<",
            "TA;T",
            "L;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/u$a;->d:Lcom/google/android/gms/common/api/internal/n;

    const/4 v1, 0x1

    const/4 v0, 0x3

    return-object p0
.end method
