.class public final Lcom/google/android/gms/common/api/internal/l3;
.super Lcom/google/android/gms/common/api/internal/e2;


# instance fields
.field private final b:Lcom/google/android/gms/common/api/internal/a0;

.field private final c:Lcom/google/android/gms/tasks/TaskCompletionSource;

.field private final d:Lcom/google/android/gms/common/api/internal/y;


# direct methods
.method public constructor <init>(ILcom/google/android/gms/common/api/internal/a0;Lcom/google/android/gms/tasks/TaskCompletionSource;Lcom/google/android/gms/common/api/internal/y;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/e2;-><init>(I)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/google/android/gms/common/api/internal/l3;->c:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/l3;->b:Lcom/google/android/gms/common/api/internal/a0;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p4, p0, Lcom/google/android/gms/common/api/internal/l3;->d:Lcom/google/android/gms/common/api/internal/y;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p3, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    if-ne p1, p3, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/common/api/internal/a0;->c()Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    if-nez p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const-string/jumbo p2, "sBsst .i  ratesri-gstsdo isoteamnt aeearsnhewas   t-rtn csuefsfplvldoomuua softehtlloe"

    const-string p2, "aos - afooatlpholeifslsto.u ttssaedtwnlemasBisst  cueani rrfu  vohgrnr-se emh tettseds"

    const/4 v1, 0x6

    const-string p2, "Best-effort write calls cannot pass methods that should auto-resolve missing features."

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    throw p1

    :cond_1
    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/common/api/Status;)V
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/Status;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " como~. @~~uKl@i ~@  ~~~~r~vtoio@   @@~@~~t/@ @l @ y@41o~~f /M~~@~~a~~S@b-n@~o ~@b s@fm@bd @@@i "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/l3;->d:Lcom/google/android/gms/common/api/internal/y;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/l3;->c:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/y;->a(Lcom/google/android/gms/common/api/Status;)Ljava/lang/Exception;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v1, p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->trySetException(Ljava/lang/Exception;)Z

    const/4 v3, 0x1

    return-void
.end method

.method public final b(Ljava/lang/Exception;)V
    .locals 3
    .param p1    # Ljava/lang/Exception;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/l3;->c:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->trySetException(Ljava/lang/Exception;)Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public final c(Lcom/google/android/gms/common/api/internal/v1;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/DeadObjectException;
        }
    .end annotation

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/l3;->b:Lcom/google/android/gms/common/api/internal/a0;

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/v1;->w()Lcom/google/android/gms/common/api/a$f;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/l3;->c:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, p1, v1}, Lcom/google/android/gms/common/api/internal/a0;->b(Lcom/google/android/gms/common/api/a$b;Lcom/google/android/gms/tasks/TaskCompletionSource;)V
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/l3;->c:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->trySetException(Ljava/lang/Exception;)Z

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    return-void

    :catch_1
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/n3;->e(Landroid/os/RemoteException;)Lcom/google/android/gms/common/api/Status;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/internal/l3;->a(Lcom/google/android/gms/common/api/Status;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void

    :catch_2
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw p1
.end method

.method public final d(Lcom/google/android/gms/common/api/internal/h0;Z)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/internal/h0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/l3;->c:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1, v0, p2}, Lcom/google/android/gms/common/api/internal/h0;->d(Lcom/google/android/gms/tasks/TaskCompletionSource;Z)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public final f(Lcom/google/android/gms/common/api/internal/v1;)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/l3;->b:Lcom/google/android/gms/common/api/internal/a0;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/a0;->c()Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p1
.end method

.method public final g(Lcom/google/android/gms/common/api/internal/v1;)[Lcom/google/android/gms/common/Feature;
    .locals 2
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/l3;->b:Lcom/google/android/gms/common/api/internal/a0;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/a0;->e()[Lcom/google/android/gms/common/Feature;

    move-result-object p1

    const/4 v1, 0x7

    return-object p1
.end method
