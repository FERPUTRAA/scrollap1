.class final Lcom/google/android/gms/common/api/internal/m1;
.super Lcom/google/android/gms/internal/base/zau;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/api/internal/n1;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/n1;Landroid/os/Looper;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/m1;->a:Lcom/google/android/gms/common/api/internal/n1;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0, p2}, Lcom/google/android/gms/internal/base/zau;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ sm~   ooi~~u/@y ~@l@ ~@ 4t1~@f.M ~@b~@~lr@fon  Kciv~ @~@o @ @~@@ a~~~~o~/@   st@~-@So~d~b@@~bi"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eq v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x2

    const/4 v3, 0x4

    if-eq v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v1, " domgwUimkes:n asse "

    const-string/jumbo v1, "gasesi  :nn kUsomwed"

    const/4 v3, 0x3

    const-string/jumbo v1, "oeU:oigdks w n annme"

    const-string v1, "Unknown message id: "

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v0, "CamaebrGgnaMStA"

    const-string/jumbo v0, "retmtaCaMGAagnS"

    const/4 v3, 0x5

    const-string v0, "aMeGgtuCeaaSnrt"

    const-string v0, "GACStateManager"

    invoke-static {v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x6

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast p1, Ljava/lang/RuntimeException;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    throw p1

    :cond_1
    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast p1, Lcom/google/android/gms/common/api/internal/l1;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/m1;->a:Lcom/google/android/gms/common/api/internal/n1;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/api/internal/l1;->b(Lcom/google/android/gms/common/api/internal/n1;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method
