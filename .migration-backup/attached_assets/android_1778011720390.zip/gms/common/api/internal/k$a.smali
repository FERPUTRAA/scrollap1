.class public abstract Lcom/google/android/gms/common/api/internal/k$a;
.super Lcom/google/android/gms/internal/base/zab;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/k;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/api/internal/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo v0, "sasmi..assmtColcntb.gogamtca.muilcpanoo.e.Iaodlre.drnkngSl"

    const-string v0, "aIstct.aalg..gom.gulaos.lnaamCrpnSdsiikcme.ldrboooone.mcnt"

    const/4 v2, 0x5

    const-string/jumbo v0, "tnnmmbu..ndlC.elmo.dscrrcataaioSig.ognmliI.aooloetpmcgs.ak"

    const-string v0, "com.google.android.gms.common.api.internal.IStatusCallback"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/base/zab;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Lcom/google/android/gms/common/api/internal/k;
    .locals 4
    .param p0    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "4@@~o@~@ ~ @@~@~o s1vodoaK~~~~rM-.  n@@t@@@~  bo ~ @ ~y@ tob@/f@ml~~ou@~ i~@cl/  @~ ~@ f~iS ~~b~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v0, "e.kInbadllaeo.goCmtrdonsatom.aalbormng.ci.amomtlpgis.u.Scn"

    const-string/jumbo v0, "lCgmi.nm.glm.Itrmrsnaglbdnua.ockadsoaSniaptotlca.eoo.om.ie"

    const/4 v3, 0x6

    const-string v0, "com.google.android.gms.common.api.internal.IStatusCallback"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    instance-of v1, v0, Lcom/google/android/gms/common/api/internal/k;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    check-cast v0, Lcom/google/android/gms/common/api/internal/k;

    const/4 v2, 0x3

    move v3, v2

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/common/api/internal/c2;

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/api/internal/c2;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method


# virtual methods
.method protected final zaa(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 2
    .param p2    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    const/4 p3, 0x1

    const/4 v1, 0x6

    if-ne p1, p3, :cond_0

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    sget-object p1, Lcom/google/android/gms/common/api/Status;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p2, p1}, Lcom/google/android/gms/internal/base/zac;->zaa(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    check-cast p1, Lcom/google/android/gms/common/api/Status;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p2}, Lcom/google/android/gms/internal/base/zac;->zab(Landroid/os/Parcel;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-interface {p0, p1}, Lcom/google/android/gms/common/api/internal/k;->onResult(Lcom/google/android/gms/common/api/Status;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return p3

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p1
.end method
