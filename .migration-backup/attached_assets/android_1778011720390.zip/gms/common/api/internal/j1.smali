.class public final Lcom/google/android/gms/common/api/internal/j1;
.super Lcom/google/android/gms/common/api/l;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/d2;


# instance fields
.field final A:Lcom/google/android/gms/common/api/internal/i3;

.field private final B:Lcom/google/android/gms/common/internal/r0;

.field private final e:Ljava/util/concurrent/locks/Lock;

.field private final f:Lcom/google/android/gms/common/internal/s0;

.field private g:Lcom/google/android/gms/common/api/internal/f2;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final h:I

.field private final i:Landroid/content/Context;

.field private final j:Landroid/os/Looper;

.field final k:Ljava/util/Queue;
    .annotation build Landroidx/annotation/k1;
    .end annotation
.end field

.field private volatile l:Z

.field private m:J

.field private n:J

.field private final o:Lcom/google/android/gms/common/api/internal/h1;

.field private final p:Lcom/google/android/gms/common/f;

.field q:Lcom/google/android/gms/common/api/internal/zabx;
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field final r:Ljava/util/Map;

.field s:Ljava/util/Set;

.field final t:Lcom/google/android/gms/common/internal/g;

.field final u:Ljava/util/Map;

.field final v:Lcom/google/android/gms/common/api/a$a;

.field private final w:Lcom/google/android/gms/common/api/internal/o;

.field private final x:Ljava/util/ArrayList;

.field private y:Ljava/lang/Integer;

.field z:Ljava/util/Set;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/concurrent/locks/Lock;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/f;Lcom/google/android/gms/common/api/a$a;Ljava/util/Map;Ljava/util/List;Ljava/util/List;Ljava/util/Map;IILjava/util/ArrayList;)V
    .locals 6

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p3

    move-object v1, p3

    move-object v1, p3

    move-object v1, p3

    move/from16 v2, p11

    move/from16 v2, p11

    move/from16 v2, p11

    move/from16 v2, p11

    invoke-direct {p0}, Lcom/google/android/gms/common/api/l;-><init>()V

    const/4 v3, 0x0

    iput-object v3, v0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    new-instance v4, Ljava/util/LinkedList;

    invoke-direct {v4}, Ljava/util/LinkedList;-><init>()V

    iput-object v4, v0, Lcom/google/android/gms/common/api/internal/j1;->k:Ljava/util/Queue;

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/android/gms/common/util/e;->c()Z

    move-result v5

    if-eq v4, v5, :cond_0

    const-wide/32 v4, 0x1d4c0

    const-wide/32 v4, 0x1d4c0

    const-wide/32 v4, 0x1d4c0

    goto :goto_0

    :cond_0
    const-wide/16 v4, 0x2710

    const-wide/16 v4, 0x2710

    const-wide/16 v4, 0x2710

    const-wide/16 v4, 0x2710

    :goto_0
    iput-wide v4, v0, Lcom/google/android/gms/common/api/internal/j1;->m:J

    const-wide/16 v4, 0x1388

    const-wide/16 v4, 0x1388

    const-wide/16 v4, 0x1388

    const-wide/16 v4, 0x1388

    iput-wide v4, v0, Lcom/google/android/gms/common/api/internal/j1;->n:J

    new-instance v4, Ljava/util/HashSet;

    invoke-direct {v4}, Ljava/util/HashSet;-><init>()V

    iput-object v4, v0, Lcom/google/android/gms/common/api/internal/j1;->s:Ljava/util/Set;

    new-instance v4, Lcom/google/android/gms/common/api/internal/o;

    invoke-direct {v4}, Lcom/google/android/gms/common/api/internal/o;-><init>()V

    iput-object v4, v0, Lcom/google/android/gms/common/api/internal/j1;->w:Lcom/google/android/gms/common/api/internal/o;

    iput-object v3, v0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    iput-object v3, v0, Lcom/google/android/gms/common/api/internal/j1;->z:Ljava/util/Set;

    new-instance v3, Lcom/google/android/gms/common/api/internal/c1;

    invoke-direct {v3, p0}, Lcom/google/android/gms/common/api/internal/c1;-><init>(Lcom/google/android/gms/common/api/internal/j1;)V

    iput-object v3, v0, Lcom/google/android/gms/common/api/internal/j1;->B:Lcom/google/android/gms/common/internal/r0;

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    iput-object v4, v0, Lcom/google/android/gms/common/api/internal/j1;->i:Landroid/content/Context;

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    iput-object v4, v0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    new-instance v4, Lcom/google/android/gms/common/internal/s0;

    invoke-direct {v4, p3, v3}, Lcom/google/android/gms/common/internal/s0;-><init>(Landroid/os/Looper;Lcom/google/android/gms/common/internal/r0;)V

    iput-object v4, v0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    iput-object v1, v0, Lcom/google/android/gms/common/api/internal/j1;->j:Landroid/os/Looper;

    new-instance v3, Lcom/google/android/gms/common/api/internal/h1;

    invoke-direct {v3, p0, p3}, Lcom/google/android/gms/common/api/internal/h1;-><init>(Lcom/google/android/gms/common/api/internal/j1;Landroid/os/Looper;)V

    iput-object v3, v0, Lcom/google/android/gms/common/api/internal/j1;->o:Lcom/google/android/gms/common/api/internal/h1;

    move-object v1, p5

    move-object v1, p5

    move-object v1, p5

    move-object v1, p5

    iput-object v1, v0, Lcom/google/android/gms/common/api/internal/j1;->p:Lcom/google/android/gms/common/f;

    iput v2, v0, Lcom/google/android/gms/common/api/internal/j1;->h:I

    if-ltz v2, :cond_1

    invoke-static/range {p12 .. p12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iput-object v1, v0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    :cond_1
    move-object v1, p7

    move-object v1, p7

    move-object v1, p7

    move-object v1, p7

    iput-object v1, v0, Lcom/google/android/gms/common/api/internal/j1;->u:Ljava/util/Map;

    move-object/from16 v1, p10

    move-object/from16 v1, p10

    move-object/from16 v1, p10

    move-object/from16 v1, p10

    iput-object v1, v0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    move-object/from16 v1, p13

    move-object/from16 v1, p13

    move-object/from16 v1, p13

    move-object/from16 v1, p13

    iput-object v1, v0, Lcom/google/android/gms/common/api/internal/j1;->x:Ljava/util/ArrayList;

    new-instance v1, Lcom/google/android/gms/common/api/internal/i3;

    invoke-direct {v1}, Lcom/google/android/gms/common/api/internal/i3;-><init>()V

    iput-object v1, v0, Lcom/google/android/gms/common/api/internal/j1;->A:Lcom/google/android/gms/common/api/internal/i3;

    invoke-interface {p8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/google/android/gms/common/api/l$b;

    iget-object v3, v0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    invoke-virtual {v3, v2}, Lcom/google/android/gms/common/internal/s0;->f(Lcom/google/android/gms/common/api/l$b;)V

    goto :goto_1

    :cond_2
    invoke-interface {p9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/google/android/gms/common/api/l$c;

    iget-object v3, v0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    invoke-virtual {v3, v2}, Lcom/google/android/gms/common/internal/s0;->g(Lcom/google/android/gms/common/api/l$c;)V

    goto :goto_2

    :cond_3
    move-object v2, p4

    move-object v2, p4

    move-object v2, p4

    move-object v2, p4

    iput-object v2, v0, Lcom/google/android/gms/common/api/internal/j1;->t:Lcom/google/android/gms/common/internal/g;

    move-object v1, p6

    move-object v1, p6

    iput-object v1, v0, Lcom/google/android/gms/common/api/internal/j1;->v:Lcom/google/android/gms/common/api/a$a;

    return-void
.end method

.method public static K(Ljava/lang/Iterable;Z)I
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~MsKt  i@ @ib@S@f~@l~f~  au@iv c~o 4~bsn~@ @l 1~@r ~~~oot@ d/~o~ @m ~.@@oo-~b~ /~@~@@~y@@ @  ~@~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    check-cast v2, Lcom/google/android/gms/common/api/a$f;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-interface {v2}, Lcom/google/android/gms/common/api/a$f;->requiresSignIn()Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    or-int/2addr v0, v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-interface {v2}, Lcom/google/android/gms/common/api/a$f;->providesSignIn()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    or-int/2addr v1, v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz p1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 p0, 0x0

    const/4 p0, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    return p0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 p0, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    return p0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 p0, 0x3

    const/4 v5, 0x5

    const/4 v4, 0x0

    return p0
.end method

.method static bridge synthetic L(Lcom/google/android/gms/common/api/internal/j1;)Landroid/content/Context;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/j1;->i:Landroid/content/Context;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p0
.end method

.method static N(I)Ljava/lang/String;
    .locals 3

    const/4 v1, 0x2

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x1

    const/4 v1, 0x5

    if-eq p0, v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eq p0, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eq p0, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string p0, "WNKmNsO"

    const-string p0, "NUsWNKO"

    const/4 v2, 0x2

    const-string p0, "OUKNoNW"

    const-string p0, "UNKNOWN"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string p0, "N_SmMEIDI_GNONEO_"

    const/4 v2, 0x4

    const-string p0, "NEMN_bO_IINEGDN_S"

    const-string p0, "SIGN_IN_MODE_NONE"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0

    :cond_1
    const/4 v2, 0x1

    const-string p0, "I__ONOuIIDNLSMPOo_TAE"

    const-string p0, "_ODOoMENAL_TIO_GIPSIN"

    const-string p0, "_SIIEL_pTOOIDA_GOMNNP"

    const-string p0, "SIGN_IN_MODE_OPTIONAL"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string p0, "ESbU_QNIq_EDMIIRENGRO"

    const-string p0, "SG_IMbEEOND_ENQIIRRUD"

    const/4 v2, 0x1

    const-string p0, "MDsOEIQNS_DGUENIR_RE_"

    const-string p0, "SIGN_IN_MODE_REQUIRED"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method static bridge synthetic O(Lcom/google/android/gms/common/api/internal/j1;Lcom/google/android/gms/common/api/l;Lcom/google/android/gms/common/api/internal/z;Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    const/4 p3, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/gms/common/api/internal/j1;->T(Lcom/google/android/gms/common/api/l;Lcom/google/android/gms/common/api/internal/z;Z)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method static bridge synthetic P(Lcom/google/android/gms/common/api/internal/j1;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/gms/common/api/internal/j1;->l:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/j1;->U()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {p0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {p0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    throw v0
.end method

.method static bridge synthetic Q(Lcom/google/android/gms/common/api/internal/j1;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/j1;->R()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/j1;->U()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {p0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {p0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    throw v0
.end method

.method private final S(I)V
    .locals 14

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x0

    if-nez v0, :cond_0

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x1

    if-ne v0, p1, :cond_8

    :goto_0
    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v13, 0x6

    const/4 v12, 0x4

    if-eqz p1, :cond_1

    const/4 v13, 0x2

    const/4 v12, 0x3

    return-void

    :cond_1
    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v12, 0x2

    const/4 v13, 0x6

    invoke-interface {p1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object p1

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x7

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x6

    const/4 v0, 0x0

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x1

    move v1, v0

    const/4 v13, 0x3

    move v1, v0

    move v1, v0

    :goto_1
    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x3

    if-eqz v2, :cond_2

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x7

    check-cast v2, Lcom/google/android/gms/common/api/a$f;

    const/4 v13, 0x2

    const/4 v12, 0x4

    invoke-interface {v2}, Lcom/google/android/gms/common/api/a$f;->requiresSignIn()Z

    move-result v3

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x0

    or-int/2addr v0, v3

    const/4 v12, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-interface {v2}, Lcom/google/android/gms/common/api/a$f;->providesSignIn()Z

    move-result v2

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x6

    or-int/2addr v1, v2

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x3

    goto :goto_1

    :cond_2
    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v13, 0x1

    const/4 v12, 0x4

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x1

    const/4 v2, 0x1

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x7

    if-eq p1, v2, :cond_4

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x4

    const/4 v1, 0x2

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x4

    if-eq p1, v1, :cond_3

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x7

    goto :goto_2

    :cond_3
    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x4

    if-eqz v0, :cond_5

    const/4 v12, 0x7

    move v13, v12

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/j1;->i:Landroid/content/Context;

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x7

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x5

    iget-object v5, p0, Lcom/google/android/gms/common/api/internal/j1;->j:Landroid/os/Looper;

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x2

    iget-object v6, p0, Lcom/google/android/gms/common/api/internal/j1;->p:Lcom/google/android/gms/common/f;

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x5

    iget-object v7, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x0

    iget-object v8, p0, Lcom/google/android/gms/common/api/internal/j1;->t:Lcom/google/android/gms/common/internal/g;

    const/4 v12, 0x1

    const/4 v13, 0x6

    iget-object v9, p0, Lcom/google/android/gms/common/api/internal/j1;->u:Ljava/util/Map;

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x7

    iget-object v10, p0, Lcom/google/android/gms/common/api/internal/j1;->v:Lcom/google/android/gms/common/api/a$a;

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x3

    iget-object v11, p0, Lcom/google/android/gms/common/api/internal/j1;->x:Ljava/util/ArrayList;

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x3

    invoke-static/range {v2 .. v11}, Lcom/google/android/gms/common/api/internal/e0;->t(Landroid/content/Context;Lcom/google/android/gms/common/api/internal/j1;Ljava/util/concurrent/locks/Lock;Landroid/os/Looper;Lcom/google/android/gms/common/g;Ljava/util/Map;Lcom/google/android/gms/common/internal/g;Ljava/util/Map;Lcom/google/android/gms/common/api/a$a;Ljava/util/ArrayList;)Lcom/google/android/gms/common/api/internal/e0;

    move-result-object p1

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x1

    return-void

    :cond_4
    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x1

    if-eqz v0, :cond_7

    const/4 v13, 0x1

    if-nez v1, :cond_6

    :cond_5
    :goto_2
    const/4 v13, 0x1

    const/4 v12, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->i:Landroid/content/Context;

    const/4 v13, 0x6

    iget-object v3, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x4

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/j1;->j:Landroid/os/Looper;

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x5

    iget-object v5, p0, Lcom/google/android/gms/common/api/internal/j1;->p:Lcom/google/android/gms/common/f;

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x0

    iget-object v6, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x4

    iget-object v7, p0, Lcom/google/android/gms/common/api/internal/j1;->t:Lcom/google/android/gms/common/internal/g;

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x1

    iget-object v8, p0, Lcom/google/android/gms/common/api/internal/j1;->u:Ljava/util/Map;

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x7

    iget-object v9, p0, Lcom/google/android/gms/common/api/internal/j1;->v:Lcom/google/android/gms/common/api/a$a;

    const/4 v13, 0x3

    const/4 v12, 0x6

    iget-object v10, p0, Lcom/google/android/gms/common/api/internal/j1;->x:Ljava/util/ArrayList;

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x5

    new-instance p1, Lcom/google/android/gms/common/api/internal/n1;

    move-object v0, p1

    move-object v0, p1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v11, p0

    move-object v11, p0

    move-object v11, p0

    move-object v11, p0

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-direct/range {v0 .. v11}, Lcom/google/android/gms/common/api/internal/n1;-><init>(Landroid/content/Context;Lcom/google/android/gms/common/api/internal/j1;Ljava/util/concurrent/locks/Lock;Landroid/os/Looper;Lcom/google/android/gms/common/g;Ljava/util/Map;Lcom/google/android/gms/common/internal/g;Ljava/util/Map;Lcom/google/android/gms/common/api/a$a;Ljava/util/ArrayList;Lcom/google/android/gms/common/api/internal/d2;)V

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x3

    return-void

    :cond_6
    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x1

    const-string v0, "_SRmLNNNaPGI_DndN_GiII( IEI_es_D_ENIuIt nG.SnoicSAOTOPEOO)s_NI_nIOetMUee.AUoO NQE RCt GDawh_MutncE LG"

    const-string/jumbo v0, "hsDaIEuONEQ SGGODL nOGMGREPNc_T_SDOtc tANONPLIR_UtMsNE) IA.ioCSned_I_.et _NoN u__(IiwEOae IGIIn_IenUn"

    const/4 v13, 0x6

    const-string v0, "cGeRo G taO_DONnOiE.LS PInowCu_NAOGtOGIhOi sdISAN_SM _EI_QE_R_DEUN INs_e)IPc E.aeIn(tnNGIeUTMo_sINLnD"

    const-string v0, "Cannot use SIGN_IN_MODE_REQUIRED with GOOGLE_SIGN_IN_API. Use connect(SIGN_IN_MODE_OPTIONAL) instead."

    const/4 v13, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x6

    throw p1

    :cond_7
    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x7

    const-string/jumbo v0, "tanDeb Nb tEG RinasEtieIiNno aa RtItiEQeoO.snUehtndlI)McnGo  nta(t  n nl_dIdPcuog  etnepoi uoot.eaaneAUepcacs_sA_sDeS C dhyc o"

    const-string/jumbo v0, "tiacendpdne It  tNlQ  sdUGUN ea M_.utGota)uatenage eRc ne D sncty hDnnAltIs c aCnaoRiPoe ohSpE onAo_IbnEndoon_(eEsO.iiticsateI"

    const/4 v13, 0x0

    const-string v0, " liooCudneGee tGogaDeaUEaNtcDeIR e_ydO loitQtnena)onA EMi nhptt.tsSnicc_eaob(stc eshon ndnEn s natIsnUciuadeA u   R_aoIIt  tNP"

    const-string v0, "SIGN_IN_MODE_REQUIRED cannot be used on a GoogleApiClient that does not contain any authenticated APIs. Use connect() instead."

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x5

    throw p1

    :cond_8
    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x1

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/j1;->N(I)Ljava/lang/String;

    move-result-object v1

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x5

    const-string/jumbo v3, "qd i:nep-Cn i sn snmotugo"

    const-string v3, "anenit nq:-osumgo iC  nds"

    const/4 v13, 0x0

    const-string v3, "C sntadiqmnnosu g ein e-o"

    const-string v3, "Cannot use sign-in mode: "

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    move v13, v12

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/j1;->N(I)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const-string/jumbo p1, "sast y  ar ee  w.daMstelos"

    const-string p1, ". stM eyoes wae  lraasd to"

    const/4 v13, 0x6

    const-string/jumbo p1, "wyrmsoaae s a dlMed.  etto"

    const-string p1, ". Mode was already set to "

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x4

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x7

    throw v0
.end method

.method private final T(Lcom/google/android/gms/common/api/l;Lcom/google/android/gms/common/api/internal/z;Z)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v0, Lcom/google/android/gms/common/internal/service/a;->d:Lcom/google/android/gms/common/internal/service/f;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/service/f;->a(Lcom/google/android/gms/common/api/l;)Lcom/google/android/gms/common/api/p;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v1, Lcom/google/android/gms/common/api/internal/g1;

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-direct {v1, p0, p2, p3, p1}, Lcom/google/android/gms/common/api/internal/g1;-><init>(Lcom/google/android/gms/common/api/internal/j1;Lcom/google/android/gms/common/api/internal/z;ZLcom/google/android/gms/common/api/l;)V

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/api/p;->setResultCallback(Lcom/google/android/gms/common/api/w;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method private final U()V
    .locals 3
    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/s0;->b()V

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/gms/common/api/internal/f2;

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-interface {v0}, Lcom/google/android/gms/common/api/internal/f2;->f()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public final A()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/j1;->i()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/j1;->g()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public final B(Lcom/google/android/gms/common/api/l$b;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/l$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/s0;->f(Lcom/google/android/gms/common/api/l$b;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public final C(Lcom/google/android/gms/common/api/l$c;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/l$c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/s0;->g(Lcom/google/android/gms/common/api/l$c;)V

    const/4 v2, 0x4

    return-void
.end method

.method public final D(Ljava/lang/Object;)Lcom/google/android/gms/common/api/internal/n;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<",
            "L:Ljava/lang/Object;",
            ">(T",
            "L;",
            ")",
            "Lcom/google/android/gms/common/api/internal/n<",
            "T",
            "L;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->w:Lcom/google/android/gms/common/api/internal/o;

    const/4 v4, 0x3

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->j:Landroid/os/Looper;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v2, "T_ENomO"

    const-string v2, "OPTmEN_"

    const/4 v4, 0x1

    const-string v2, "OTNY_bE"

    const-string v2, "NO_TYPE"

    const/4 v4, 0x1

    invoke-virtual {v0, p1, v1, v2}, Lcom/google/android/gms/common/api/internal/o;->d(Ljava/lang/Object;Landroid/os/Looper;Ljava/lang/String;)Lcom/google/android/gms/common/api/internal/n;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x6

    throw p1
.end method

.method public final E(Landroidx/fragment/app/FragmentActivity;)V
    .locals 3
    .param p1    # Landroidx/fragment/app/FragmentActivity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/gms/common/api/internal/l;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/api/internal/l;-><init>(Landroid/app/Activity;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget p1, p0, Lcom/google/android/gms/common/api/internal/j1;->h:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ltz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/p3;->i(Lcom/google/android/gms/common/api/internal/l;)Lcom/google/android/gms/common/api/internal/p3;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/gms/common/api/internal/j1;->h:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/api/internal/p3;->k(I)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string v0, ".ntnoaemsatcmdaogl oC tadceoueen suontegle aiMamint u lptl cfae Albyebia"

    const/4 v2, 0x2

    const-string v0, "alC aduatoe ludaaniamlnostasoebtce  i tMnngAbtne mmiuueegtapl tle.eycfoc"

    const-string v0, "Called stopAutoManage but automatic lifecycle management is not enabled."

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    throw p1
.end method

.method public final F(Lcom/google/android/gms/common/api/l$b;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/l$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/s0;->h(Lcom/google/android/gms/common/api/l$b;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public final G(Lcom/google/android/gms/common/api/l$c;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/l$c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/s0;->i(Lcom/google/android/gms/common/api/l$c;)V

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public final H(Lcom/google/android/gms/common/api/internal/g3;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->z:Ljava/util/Set;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->z:Ljava/util/Set;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->z:Ljava/util/Set;

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    throw p1
.end method

.method public final I(Lcom/google/android/gms/common/api/internal/g3;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->z:Ljava/util/Set;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v1, "tlgoGnlpiboleCmepIA"

    const-string/jumbo v1, "oIopCbneiglGmAetlpl"

    const/4 v3, 0x5

    const-string v1, "GCeiIlAtqppnoielgmo"

    const-string v1, "GoogleApiClientImpl"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez v0, :cond_0

    :try_start_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string p1, "dss mdonr  tporfefmhrenr.tsioat v ua gpeeewet n rsonirtgAese mtaedrnornm"

    const-string p1, "e edwruv  g opsrnnegrne.odo tedrmnaeisenspttm trm aaf oremsrhetfi Anrtot"

    const/4 v3, 0x4

    const-string p1, "emmmmoonpvedh.ts egrteonteetramennoisa  tirearssdfopr f ndwt gn re rAtr "

    const-string p1, "Attempted to remove pending transform when no transforms are registered."

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/Exception;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    const/4 v3, 0x1

    invoke-static {v1, p1, v0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez p1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string p1, " oF oafl misropm tnh titdnonsper tle eedaei-k oaaodemv !ymeyramlg r"

    const-string/jumbo p1, "masntsepetvehlim eoam to praloaro io snalydg  ! mr eeyt n-frdmedkiF"

    const/4 v3, 0x0

    const-string p1, " iendb ine ssthrlae atsl mamtnk e  - eteamorpdo!odegmyvro rof aylmF"

    const-string p1, "Failed to remove pending transform - this may lead to memory leaks!"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/Exception;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v1, p1, v0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->lock()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->z:Ljava/util/Set;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez p1, :cond_2

    :try_start_3
    const/4 v3, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_2
    :try_start_4
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/util/Set;->isEmpty()Z

    move-result p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    xor-int/lit8 p1, p1, 0x1

    :try_start_5
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez p1, :cond_3

    :goto_0
    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz p1, :cond_3

    const/4 v3, 0x0

    invoke-interface {p1}, Lcom/google/android/gms/common/api/internal/f2;->g()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    :cond_3
    :goto_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void

    :catchall_0
    move-exception p1

    :try_start_6
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    throw p1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    :catchall_1
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    throw p1
.end method

.method final M()Ljava/lang/String;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v0, Ljava/io/StringWriter;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/io/StringWriter;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v1, Ljava/io/PrintWriter;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {v1, v0}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0, v2, v3, v1, v3}, Lcom/google/android/gms/common/api/internal/j1;->j(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object v0
.end method

.method final R()Z
    .locals 4
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-boolean v0, p0, Lcom/google/android/gms/common/api/internal/j1;->l:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    return v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-boolean v1, p0, Lcom/google/android/gms/common/api/internal/j1;->l:Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->o:Lcom/google/android/gms/common/api/internal/h1;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v2, 0x5

    and-int/2addr v3, v2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->o:Lcom/google/android/gms/common/api/internal/h1;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->q:Lcom/google/android/gms/common/api/internal/zabx;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/zabx;->b()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->q:Lcom/google/android/gms/common/api/internal/zabx;

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return v1
.end method

.method public final a(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->k:Ljava/util/Queue;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->k:Ljava/util/Queue;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/util/Queue;->remove()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/gms/common/api/internal/e$a;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/api/l;->m(Lcom/google/android/gms/common/api/internal/e$a;)Lcom/google/android/gms/common/api/internal/e$a;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/s0;->d(Landroid/os/Bundle;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public final b(IZ)V
    .locals 7
    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v0, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/4 v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-ne p1, v1, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-nez p2, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-boolean p1, p0, Lcom/google/android/gms/common/api/internal/j1;->l:Z

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz p1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    move v6, v5

    iput-boolean v1, p0, Lcom/google/android/gms/common/api/internal/j1;->l:Z

    const/4 v5, 0x1

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->q:Lcom/google/android/gms/common/api/internal/zabx;

    const/4 v6, 0x5

    if-nez p1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {}, Lcom/google/android/gms/common/util/e;->c()Z

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-nez p1, :cond_1

    :try_start_0
    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->p:Lcom/google/android/gms/common/f;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/j1;->i:Landroid/content/Context;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-instance v2, Lcom/google/android/gms/common/api/internal/i1;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-direct {v2, p0}, Lcom/google/android/gms/common/api/internal/i1;-><init>(Lcom/google/android/gms/common/api/internal/j1;)V

    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p1, p2, v2}, Lcom/google/android/gms/common/f;->H(Landroid/content/Context;Lcom/google/android/gms/common/api/internal/b2;)Lcom/google/android/gms/common/api/internal/zabx;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->q:Lcom/google/android/gms/common/api/internal/zabx;
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->o:Lcom/google/android/gms/common/api/internal/h1;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1, v1}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-wide v2, p0, Lcom/google/android/gms/common/api/internal/j1;->m:J

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1, p2, v2, v3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->o:Lcom/google/android/gms/common/api/internal/h1;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-wide v2, p0, Lcom/google/android/gms/common/api/internal/j1;->n:J

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1, p2, v2, v3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    :cond_2
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    move p1, v1

    move p1, v1

    const/4 v6, 0x4

    move p1, v1

    move p1, v1

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/j1;->A:Lcom/google/android/gms/common/api/internal/i3;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object p2, p2, Lcom/google/android/gms/common/api/internal/i3;->a:Ljava/util/Set;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-array v2, v1, [Lcom/google/android/gms/common/api/internal/BasePendingResult;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {p2, v2}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    check-cast p2, [Lcom/google/android/gms/common/api/internal/BasePendingResult;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    array-length v2, p2

    :goto_1
    const/4 v6, 0x1

    if-ge v1, v2, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    aget-object v3, p2, v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    sget-object v4, Lcom/google/android/gms/common/api/internal/i3;->c:Lcom/google/android/gms/common/api/Status;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v3, v4}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->forceFailureUnlessReady(Lcom/google/android/gms/common/api/Status;)V

    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_1

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p2, p1}, Lcom/google/android/gms/common/internal/s0;->e(I)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p2}, Lcom/google/android/gms/common/internal/s0;->a()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-ne p1, v0, :cond_5

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/j1;->U()V

    :cond_5
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-void
.end method

.method public final c(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 5
    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->p:Lcom/google/android/gms/common/f;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->i:Landroid/content/Context;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/common/g;->l(Landroid/content/Context;I)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/j1;->R()Z

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-boolean v0, p0, Lcom/google/android/gms/common/api/internal/j1;->l:Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/s0;->c(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/s0;->a()V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method public final d()Lcom/google/android/gms/common/ConnectionResult;
    .locals 6
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x6

    const/4 v3, 0x5

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eq v0, v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    move v0, v2

    move v0, v2

    const/4 v5, 0x1

    move v0, v2

    move v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    move v5, v4

    move v0, v3

    move v0, v3

    const/4 v5, 0x6

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v1, "rdoUbCug  Idn ealso cbttt eonc qletiuannkhtmchenl  "

    const-string v1, " lehdanrqsmentnitclc gtnte t oenhaokUd c l boI buCe"

    const/4 v5, 0x7

    const-string v1, " tn ghbpd e soto bnCc mctrlilotkanhel  deeIUeouancn"

    const-string v1, "blockingConnect must not be called on the UI thread"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/android/gms/common/api/internal/j1;->h:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-ltz v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v4, 0x5

    move v5, v4

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    move v2, v3

    move v2, v3

    const/4 v5, 0x7

    move v2, v3

    move v2, v3

    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v0, " lsu-b eatlohc hbedeois iyxn.vmemSyi a-ieenat  sanugedon ltg"

    const/4 v5, 0x5

    const-string/jumbo v0, "iu-gmeynqgaaa.  d lixehbmeepsoscd ntibt ohilean  S -vtleueny"

    const-string v0, "Sign-in mode should have been set explicitly by auto-manage."

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v2, v0}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_2

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-nez v0, :cond_3

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v0, v3}, Lcom/google/android/gms/common/api/internal/j1;->K(Ljava/lang/Iterable;Z)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_2

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v1, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eq v0, v1, :cond_4

    :goto_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    check-cast v0, Ljava/lang/Integer;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/j1;->S(I)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/s0;->b()V

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    check-cast v0, Lcom/google/android/gms/common/api/internal/f2;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {v0}, Lcom/google/android/gms/common/api/internal/f2;->e()Lcom/google/android/gms/common/ConnectionResult;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-object v0

    :cond_4
    :try_start_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo v1, "ktsd c.cmtnPOTt ie_Dln tonnS_ssCcNTlnaE-)(wNMnO NoGEsNnml_itCi. cCn_d AsAl taLcIoNnnieb IIe D(PSIieNehOIgoOG)o Oo_egOI_nLa  a"

    const-string v1, "N am_dkCo Oin_OaIeIoC cenhNPSTIlt Asi_ _IOoA-t t I).TlGnN C.cO  SPn)wMOgIcdislnGan(eL_es Dnmiato_En (tniNgMcnONeotEnscebLNlDo"

    const/4 v5, 0x7

    const-string/jumbo v1, "s(cm_etnI( -h bICS.MnDnna)cld o _LOi G.TO)eGe LPlcODnn oIstN lOAP_N Iedi nkNOaeiTE_iAgcnNnoMm_tiIootE CltogOCsalNateSnIn_Ns c"

    const-string v1, "Cannot call blockingConnect() when sign-in mode is set to SIGN_IN_MODE_OPTIONAL. Call connect(SIGN_IN_MODE_OPTIONAL) instead."

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    throw v0
.end method

.method public final e(JLjava/util/concurrent/TimeUnit;)Lcom/google/android/gms/common/ConnectionResult;
    .locals 5
    .param p3    # Ljava/util/concurrent/TimeUnit;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eq v0, v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    move v0, v2

    move v0, v2

    const/4 v4, 0x1

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v1, "tUunooot    c mrnctehd kacIb eghteoloint dnbeesllnC"

    const-string/jumbo v1, "kn soemhtteC nho clb oU  bdn droettnlccetueIoalgn i"

    const-string/jumbo v1, "oUntcbocC lbtk  g dnrndIe umel ntciabh teele htoaos"

    const-string v1, "blockingConnect must not be called on the UI thread"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v4, 0x0

    const-string/jumbo v0, "ul t  ubnnsiimetetnubTmUl"

    const-string/jumbo v0, "uU t bembnmottsu ninlleiT"

    const/4 v4, 0x7

    const-string/jumbo v0, "inellt pn  oTUmeutmin tsb"

    const-string v0, "TimeUnit must not be null"

    const/4 v4, 0x7

    invoke-static {p3, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v0, v2}, Lcom/google/android/gms/common/api/internal/j1;->K(Ljava/lang/Iterable;Z)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    goto :goto_1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eq v0, v1, :cond_2

    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast v0, Ljava/lang/Integer;

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/j1;->S(I)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/s0;->b()V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    check-cast v0, Lcom/google/android/gms/common/api/internal/f2;

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-interface {v0, p1, p2, p3}, Lcom/google/android/gms/common/api/internal/f2;->n(JLjava/util/concurrent/TimeUnit;)Lcom/google/android/gms/common/ConnectionResult;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-interface {p2}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object p1

    :cond_2
    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x6

    const-string p2, "IGnae_utiIcgieI)oAanLnsEIOncn.tOgNmo IlPoC   )SdNe_D (N  GnAM EnItTni nNdnCloonet_ MS_clsol_aw(NPhis eaNcb-eTstcDkOOOL.tO _iC"

    const/4 v4, 0x5

    const-string p2, "esiiCn nqSeiilOchotNtNITmnOgsEnaODodnesenlt_-) .O__NaGMC Il.cN OSCNosoMkIOcn( ToIAP_DnLL)twtl aI (g E t eIac _Gno_ dinlbnPeAN"

    const-string p2, "Cannot call blockingConnect() when sign-in mode is set to SIGN_IN_MODE_OPTIONAL. Call connect(SIGN_IN_MODE_OPTIONAL) instead."

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {p2}, Ljava/util/concurrent/locks/Lock;->unlock()V

    throw p1
.end method

.method public final f()Lcom/google/android/gms/common/api/p;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/gms/common/api/p<",
            "Lcom/google/android/gms/common/api/Status;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/j1;->u()Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string v1, " ssignitooneeConAcpnc e letldGttoypie"

    const-string v1, "dencclCpon etoteytGs ieltA nei ogopni"

    const/4 v7, 0x6

    const-string/jumbo v1, "ogemc t dnleytel oin oGeiintcA.osepnt"

    const-string v1, "GoogleApiClient is not connected yet."

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x4

    shl-int/2addr v7, v6

    const/4 v2, 0x1

    move v7, v2

    const/4 v6, 0x5

    move v7, v6

    if-eqz v0, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/4 v3, 0x2

    if-eq v0, v3, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    move v2, v1

    move v2, v1

    const/4 v7, 0x6

    move v2, v1

    :cond_1
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string v0, "c_tLo_EtrtNon_eODaCwenGncchnIAt  cGanGcuAnIsRP teedeIAaluoiof SONl"

    const-string/jumbo v0, "odIcrOCAqANaN sS Gw_ntellGR ntuaotecth Oan_uPAecconn_fGtDLIcEeInie"

    const/4 v7, 0x5

    const-string v0, "RDdn_bunG aeIo liPwAaeneNloOsOtcGEcnIG_ncIufh aAonNteec_Lrtc SAtuC"

    const-string v0, "Cannot use clearDefaultAccountAndReconnect with GOOGLE_SIGN_IN_API"

    const/4 v6, 0x0

    move v7, v6

    invoke-static {v2, v0}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v6, 0x4

    shr-int/2addr v7, v6

    new-instance v0, Lcom/google/android/gms/common/api/internal/z;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/api/internal/z;-><init>(Lcom/google/android/gms/common/api/l;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    sget-object v3, Lcom/google/android/gms/common/internal/service/a;->a:Lcom/google/android/gms/common/api/a$g;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-interface {v2, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-eqz v2, :cond_2

    const/4 v6, 0x1

    shl-int/2addr v7, v6

    invoke-direct {p0, p0, v0, v1}, Lcom/google/android/gms/common/api/internal/j1;->T(Lcom/google/android/gms/common/api/l;Lcom/google/android/gms/common/api/internal/z;Z)V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto :goto_1

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-instance v1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v6, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    new-instance v2, Lcom/google/android/gms/common/api/internal/d1;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {v2, p0, v1, v0}, Lcom/google/android/gms/common/api/internal/d1;-><init>(Lcom/google/android/gms/common/api/internal/j1;Ljava/util/concurrent/atomic/AtomicReference;Lcom/google/android/gms/common/api/internal/z;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    new-instance v3, Lcom/google/android/gms/common/api/internal/f1;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {v3, p0, v0}, Lcom/google/android/gms/common/api/internal/f1;-><init>(Lcom/google/android/gms/common/api/internal/j1;Lcom/google/android/gms/common/api/internal/z;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/j1;->i:Landroid/content/Context;

    new-instance v5, Lcom/google/android/gms/common/api/l$a;

    const/4 v7, 0x1

    invoke-direct {v5, v4}, Lcom/google/android/gms/common/api/l$a;-><init>(Landroid/content/Context;)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    sget-object v4, Lcom/google/android/gms/common/internal/service/a;->b:Lcom/google/android/gms/common/api/a;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v5, v4}, Lcom/google/android/gms/common/api/l$a;->a(Lcom/google/android/gms/common/api/a;)Lcom/google/android/gms/common/api/l$a;

    const/4 v6, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v5, v2}, Lcom/google/android/gms/common/api/l$a;->e(Lcom/google/android/gms/common/api/l$b;)Lcom/google/android/gms/common/api/l$a;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v5, v3}, Lcom/google/android/gms/common/api/l$a;->f(Lcom/google/android/gms/common/api/l$c;)Lcom/google/android/gms/common/api/l$a;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/j1;->o:Lcom/google/android/gms/common/api/internal/h1;

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v5, v2}, Lcom/google/android/gms/common/api/l$a;->m(Landroid/os/Handler;)Lcom/google/android/gms/common/api/l$a;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v5}, Lcom/google/android/gms/common/api/l$a;->h()Lcom/google/android/gms/common/api/l;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v2}, Lcom/google/android/gms/common/api/l;->g()V

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    return-object v0
.end method

.method public final g()V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v0, p0, Lcom/google/android/gms/common/api/internal/j1;->h:I

    const/4 v6, 0x0

    const/4 v1, 0x2

    const/4 v6, 0x1

    move v5, v1

    move v5, v1

    const/4 v6, 0x2

    const/4 v2, 0x1

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-ltz v0, :cond_1

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    move v0, v3

    move v0, v3

    const/4 v6, 0x7

    move v0, v3

    move v0, v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    move v0, v2

    move v0, v2

    const/4 v6, 0x2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string/jumbo v4, "nalhanuiyi --ote. p h enedm tas g bdevcgollossb iuuxySeeinem"

    const-string v4, "  senadlxty eiine.Svb-tahges nbionyuotdamc-sel ep h egmou li"

    const/4 v6, 0x7

    const-string v4, "Sign-in mode should have been set explicitly by auto-manage."

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v0, v4}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_1

    :cond_1
    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez v0, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0, v2}, Lcom/google/android/gms/common/api/internal/j1;->K(Ljava/lang/Iterable;Z)I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v6, 0x7

    goto :goto_1

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    if-eq v0, v1, :cond_5

    :goto_1
    const/4 v5, 0x6

    move v6, v5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->y:Ljava/lang/Integer;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    check-cast v0, Ljava/lang/Integer;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {v4}, Ljava/util/concurrent/locks/Lock;->lock()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v4, 0x3

    const/4 v6, 0x4

    if-eq v0, v4, :cond_4

    const/4 v6, 0x5

    if-eq v0, v3, :cond_4

    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-ne v0, v1, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_2

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    move v1, v0

    const/4 v6, 0x5

    move v1, v0

    move v1, v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_3

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    move v1, v0

    move v1, v0

    const/4 v6, 0x0

    move v1, v0

    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    move v2, v3

    move v2, v3

    :goto_3
    :try_start_1
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string/jumbo v3, "lme- nopgi mn: Iliglad"

    const-string/jumbo v3, "gIdmlimieneo -al ng l:"

    const/4 v6, 0x2

    const-string v3, "e-olneiaqm Ilg sg:inl "

    const-string v3, "Illegal sign-in mode: "

    const/4 v5, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v2, v0}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {p0, v1}, Lcom/google/android/gms/common/api/internal/j1;->S(I)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/j1;->U()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void

    :catchall_0
    move-exception v0

    :try_start_3
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    throw v0

    :cond_5
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string v1, "(TstnO cetnoNdc  NlIn)eaAaAOoI_ gs CsGGodNt cI h)eiNnIw_S.MMIEP_t_ne_lon Pe e_cNEaSnIntaiCS(illon NOtIO.D OLDMoOcLT"

    const-string/jumbo v1, "o sho NM_anII_)CnPtaNMi _dl t_ePOeIIGa_oGD(  .InOs ieAnMliCnSO oltctaT OSNdAD SgLcoILNnnncettw.OecToNO_(ln)EcN IeEs"

    const-string v1, "IN mEOen ete_DIoeos_  nNTLcaaOI)a_ oE. wN.(DN)dCG_OsdeMSnSaLA PIilclnNnO _MPlsnMntI(AnnOcotItN ioSGeC gTnl iOc_Ihct"

    const-string v1, "Cannot call connect() when SignInMode is set to SIGN_IN_MODE_OPTIONAL. Call connect(SIGN_IN_MODE_OPTIONAL) instead."

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    move-exception v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    throw v0
.end method

.method public final h(I)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    const/4 v4, 0x1

    const/4 v0, 0x4

    const/4 v4, 0x1

    const/4 v0, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eq p1, v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eq p1, v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v0, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ne p1, v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    move p1, v0

    move p1, v0

    const/4 v4, 0x4

    move p1, v0

    move p1, v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v1, 0x0

    :cond_1
    :goto_0
    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const-string v2, "esnlo i:legd- olnI mga"

    const-string/jumbo v2, "n: eebigI- nomdl lgals"

    const/4 v4, 0x6

    const-string v2, "Illegal sign-in mode: "

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v1, v0}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/j1;->S(I)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/j1;->U()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    throw p1
.end method

.method public final i()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->A:Lcom/google/android/gms/common/api/internal/i3;

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/i3;->b()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {v0}, Lcom/google/android/gms/common/api/internal/f2;->i()V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->w:Lcom/google/android/gms/common/api/internal/o;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/o;->e()V

    const/4 v4, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->k:Ljava/util/Queue;

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast v1, Lcom/google/android/gms/common/api/internal/e$a;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->zan(Lcom/google/android/gms/common/api/internal/h3;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->cancel()V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->k:Ljava/util/Queue;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/Collection;->clear()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/j1;->R()Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/s0;->a()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x1

    const/4 v4, 0x7

    throw v0
.end method

.method public final j(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 4
    .param p2    # Ljava/io/FileDescriptor;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v1, "exutobmnC"

    const-string/jumbo v1, "oxe=mCutn"

    const/4 v3, 0x7

    const-string/jumbo v1, "tx=temuCo"

    const-string/jumbo v1, "mContext="

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->i:Landroid/content/Context;

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "mRgiusmpen"

    const-string/jumbo v1, "mResuming="

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-boolean v1, p0, Lcom/google/android/gms/common/api/internal/j1;->l:Z

    invoke-virtual {v0, v1}, Ljava/io/PrintWriter;->print(Z)V

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->k:Ljava/util/Queue;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v1, "=mQeW(u)qpsrk. izoe"

    const-string/jumbo v1, "kuu=(Wopmr.s)izQe e"

    const/4 v3, 0x2

    const-string v1, "Q=si. keWsoume)zue("

    const-string v1, " mWorkQueue.size()="

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1, v0}, Ljava/io/PrintWriter;->print(I)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->A:Lcom/google/android/gms/common/api/internal/i3;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, v0, Lcom/google/android/gms/common/api/internal/i3;->a:Ljava/util/Set;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string/jumbo v1, "eulnUsz qadsmnCil)Acime=ps.o"

    const/4 v3, 0x1

    const-string v1, " mUnconsumedApiCalls.size()="

    const/4 v2, 0x0

    const/4 v2, 0x1

    invoke-virtual {p3, v1}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Ljava/io/PrintWriter;->println(I)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/google/android/gms/common/api/internal/f2;->k(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public final l(Lcom/google/android/gms/common/api/internal/e$a;)Lcom/google/android/gms/common/api/internal/e$a;
    .locals 6
    .param p1    # Lcom/google/android/gms/common/api/internal/e$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<A::",
            "Lcom/google/android/gms/common/api/a$b;",
            "R::",
            "Lcom/google/android/gms/common/api/v;",
            "T:",
            "Lcom/google/android/gms/common/api/internal/e$a<",
            "TR;TA;>;>(TT;)TT;"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/e$a;->getApi()Lcom/google/android/gms/common/api/a;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/e$a;->getClientKey()Lcom/google/android/gms/common/api/a$c;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-interface {v1, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/a;->d()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v0, "PtsmI A"

    const-string v0, " hstIAP"

    const/4 v5, 0x1

    const-string/jumbo v0, "te PohA"

    const-string/jumbo v0, "the API"

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v3, "C mpubcteofenioludgiAgio   loentosi t Gse"

    const-string/jumbo v3, "otlmogue ifordiettosiuCiocnepnesAG  l   g"

    const/4 v5, 0x4

    const-string v3, "ef uA un isiipltde egitroo  tgoloGnescouC"

    const-string v3, "GoogleApiClient is not configured to use "

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const-string/jumbo v0, "rairi.op  dehuof rllq ct"

    const-string v0, "ae  orte .urhfr ilqidclo"

    const/4 v5, 0x6

    const-string v0, "dqhriclrquf .la  ot esre"

    const-string v0, " required for this call."

    const/4 v5, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v1, v0}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v5, 0x0

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v4, 0x4

    move v5, v4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->k:Ljava/util/Queue;

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-interface {v0, p1}, Ljava/util/Queue;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/f2;->o(Lcom/google/android/gms/common/api/internal/e$a;)Lcom/google/android/gms/common/api/internal/e$a;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    throw p1
.end method

.method public final m(Lcom/google/android/gms/common/api/internal/e$a;)Lcom/google/android/gms/common/api/internal/e$a;
    .locals 6
    .param p1    # Lcom/google/android/gms/common/api/internal/e$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<A::",
            "Lcom/google/android/gms/common/api/a$b;",
            "T:",
            "Lcom/google/android/gms/common/api/internal/e$a<",
            "+",
            "Lcom/google/android/gms/common/api/v;",
            "TA;>;>(TT;)TT;"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/e$a;->getApi()Lcom/google/android/gms/common/api/a;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/e$a;->getClientKey()Lcom/google/android/gms/common/api/a$c;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/a;->d()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string v1, "PhsAbte"

    const-string/jumbo v1, "hAteIbP"

    const/4 v5, 0x1

    const-string v1, " hemPtI"

    const-string/jumbo v1, "the API"

    :goto_0
    const/4 v5, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v3, "duono ln uin Aoou osete eotrGicisegCpft g"

    const-string/jumbo v3, "t on euoiCeAuueGof g npint sogt lilcrodse"

    const/4 v5, 0x1

    const-string v3, "Atie btto ou ue olgninosf dleGringoC sice"

    const-string v3, "GoogleApiClient is not configured to use "

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v1, "e ridcurqf se p atil.rou"

    const-string/jumbo v1, "rsufr .pdihiaoetce l  rq"

    const/4 v5, 0x5

    const-string v1, "drariilplsufroht    q.ec"

    const-string v1, " required for this call."

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    move v5, v4

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v0, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-boolean v1, p0, Lcom/google/android/gms/common/api/internal/j1;->l:Z

    const/4 v5, 0x7

    if-eqz v1, :cond_1

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->k:Ljava/util/Queue;

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-interface {v0, p1}, Ljava/util/Queue;->add(Ljava/lang/Object;)Z

    :goto_1
    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->k:Ljava/util/Queue;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->k:Ljava/util/Queue;

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Queue;->remove()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    check-cast v0, Lcom/google/android/gms/common/api/internal/e$a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->A:Lcom/google/android/gms/common/api/internal/i3;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/i3;->a(Lcom/google/android/gms/common/api/internal/BasePendingResult;)V

    const/4 v4, 0x1

    or-int/2addr v5, v4

    sget-object v1, Lcom/google/android/gms/common/api/Status;->h:Lcom/google/android/gms/common/api/Status;

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/api/internal/e$a;->setFailedResult(Lcom/google/android/gms/common/api/Status;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/f2;->q(Lcom/google/android/gms/common/api/internal/e$a;)Lcom/google/android/gms/common/api/internal/e$a;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x2

    return-object p1

    :cond_3
    :try_start_1
    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v0, "eiAtqe nqeitcdgoe .cisten o GCnoolltn"

    const-string/jumbo v0, "oCle t oqsildGccitigonnetyAn oee.e nt"

    const/4 v5, 0x6

    const-string/jumbo v0, "l sAGeseotdngoiio le pite noneCc.cnyt"

    const-string v0, "GoogleApiClient is not connected yet."

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    throw p1
.end method

.method public final o(Lcom/google/android/gms/common/api/a$c;)Lcom/google/android/gms/common/api/a$f;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/a$c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<C::",
            "Lcom/google/android/gms/common/api/a$f;",
            ">(",
            "Lcom/google/android/gms/common/api/a$c<",
            "TC;>;)TC;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    check-cast p1, Lcom/google/android/gms/common/api/a$f;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string/jumbo v0, "oAs. ptneteud Apeseporawpr iqi str"

    const/4 v2, 0x5

    const-string/jumbo v0, "rn mwtatieti.erpup dA eppsooqAser "

    const-string v0, "Appropriate Api was not requested."

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p1
.end method

.method public final p(Lcom/google/android/gms/common/api/a;)Lcom/google/android/gms/common/ConnectionResult;
    .locals 5
    .param p1    # Lcom/google/android/gms/common/api/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/a<",
            "*>;)",
            "Lcom/google/android/gms/common/ConnectionResult;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v0, "olologeeiCtAlGinpIm"

    const-string v0, "GoogleApiClientImpl"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/j1;->u()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-boolean v1, p0, Lcom/google/android/gms/common/api/internal/j1;->l:Z

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v0, "otseebe pno ncAlvglnk cosds nneenCt tonn GoRilaensltetuoCmtCcuegiioni"

    const-string/jumbo v0, "ongmsiAtCeovncpCntGol saRl elinonsn cugeinleeec toCtodt nkoe siuietnn"

    const/4 v4, 0x6

    const-string/jumbo v0, "tnsptouusene ncetueioogGn C clndiRnncenlCnCeaooleletsti vA  oistkenig"

    const-string v0, "Cannot invoke getConnectionResult unless GoogleApiClient is connected"

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    throw p1

    :cond_1
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/a;->b()Lcom/google/android/gms/common/api/a$c;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v1, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v1, Lcom/google/android/gms/common/api/internal/f2;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {v1, p1}, Lcom/google/android/gms/common/api/internal/f2;->l(Lcom/google/android/gms/common/api/a;)Lcom/google/android/gms/common/ConnectionResult;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-nez v1, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-boolean v1, p0, Lcom/google/android/gms/common/api/internal/j1;->l:Z

    const/4 v4, 0x0

    const/4 v3, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object p1, Lcom/google/android/gms/common/ConnectionResult;->C:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/j1;->M()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/a;->d()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    const-string/jumbo p1, "otse tnpab o  en noe on dtiesc  nittuaqe stno riineli hdecnsutopnsRiecemntnitnteltpudcgo  efcC nr ee"

    const-string/jumbo p1, "nomtoneoscednuectd tt nie c  cln itsoufpueRtnnsrCaqrdsnse  etpinaenieihgote  ni  obnoe itte ste ln c"

    const/4 v4, 0x6

    const-string/jumbo p1, "sotndicnqnseeii  e tcsCtos  h ob eo segnlcrenp untnrpetdnf Rntntcnensnael tdtt iiiuoceo quoeeiet  am"

    const-string p1, " requested in getConnectionResult is not connected but is not present in the failed  connections map"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/Exception;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/Exception;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v0, p1, v1}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance p1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 v0, 0x8

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {p1, v0, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_1
    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object p1

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object v1

    :cond_4
    :try_start_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/a;->d()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const-string p1, "egsA wGotdnllereiieasbtoi egv wC srpenthri"

    const-string/jumbo p1, "i ieebwhrrpotegaCAln e vdigwtel iretsonG s"

    const/4 v4, 0x5

    const-string/jumbo p1, "idsmgohterl  eltAr oGevaniweigwepins Cetre"

    const-string p1, " was never registered with GoogleApiClient"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->e:Ljava/util/concurrent/locks/Lock;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    throw p1
.end method

.method public final q()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->i:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public final r()Landroid/os/Looper;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->j:Landroid/os/Looper;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public final s(Lcom/google/android/gms/common/api/a;)Z
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/a<",
            "*>;)Z"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/a;->b()Lcom/google/android/gms/common/api/a$c;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p1
.end method

.method public final t(Lcom/google/android/gms/common/api/a;)Z
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/a<",
            "*>;)Z"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/j1;->u()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->r:Ljava/util/Map;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/a;->b()Lcom/google/android/gms/common/api/a$c;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    check-cast p1, Lcom/google/android/gms/common/api/a$f;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p1}, Lcom/google/android/gms/common/api/a$f;->isConnected()Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return p1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return v1
.end method

.method public final u()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0}, Lcom/google/android/gms/common/api/internal/f2;->p()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public final v()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0}, Lcom/google/android/gms/common/api/internal/f2;->m()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x5

    return v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public final w(Lcom/google/android/gms/common/api/l$b;)Z
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/l$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/s0;->j(Lcom/google/android/gms/common/api/l$b;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return p1
.end method

.method public final x(Lcom/google/android/gms/common/api/l$c;)Z
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/l$c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->f:Lcom/google/android/gms/common/internal/s0;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/s0;->k(Lcom/google/android/gms/common/api/l$c;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p1
.end method

.method public final y(Lcom/google/android/gms/common/api/internal/w;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v2, 0x5

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/f2;->j(Lcom/google/android/gms/common/api/internal/w;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p1
.end method

.method public final z()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j1;->g:Lcom/google/android/gms/common/api/internal/f2;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-interface {v0}, Lcom/google/android/gms/common/api/internal/f2;->h()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method
