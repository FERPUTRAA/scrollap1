.class final Lcom/google/android/gms/common/api/internal/g4;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/api/internal/LifecycleCallback;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lcom/google/android/gms/common/api/internal/h4;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/h4;Lcom/google/android/gms/common/api/internal/LifecycleCallback;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/g4;->c:Lcom/google/android/gms/common/api/internal/h4;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/g4;->a:Lcom/google/android/gms/common/api/internal/LifecycleCallback;

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/google/android/gms/common/api/internal/g4;->b:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "o@s~c/ @b@~ ~lm1~b~t@~~  o@@@@4@~~@@~~aMS@@ ~~y i~f n@ ~~oiif~s~~oo  @rK@ ~ @ @v u~b/od@ l.@ -~t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g4;->c:Lcom/google/android/gms/common/api/internal/h4;

    const/4 v3, 0x6

    move v4, v3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/h4;->c0(Lcom/google/android/gms/common/api/internal/h4;)I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-lez v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g4;->a:Lcom/google/android/gms/common/api/internal/LifecycleCallback;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/h4;->d0(Lcom/google/android/gms/common/api/internal/h4;)Landroid/os/Bundle;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/g4;->b:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/h4;->d0(Lcom/google/android/gms/common/api/internal/h4;)Landroid/os/Bundle;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->onCreate(Landroid/os/Bundle;)V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g4;->c:Lcom/google/android/gms/common/api/internal/h4;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/h4;->c0(Lcom/google/android/gms/common/api/internal/h4;)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-lt v0, v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g4;->a:Lcom/google/android/gms/common/api/internal/LifecycleCallback;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->onStart()V

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g4;->c:Lcom/google/android/gms/common/api/internal/h4;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/h4;->c0(Lcom/google/android/gms/common/api/internal/h4;)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x3

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-lt v0, v1, :cond_3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g4;->a:Lcom/google/android/gms/common/api/internal/LifecycleCallback;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->onResume()V

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g4;->c:Lcom/google/android/gms/common/api/internal/h4;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/h4;->c0(Lcom/google/android/gms/common/api/internal/h4;)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-lt v0, v1, :cond_4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g4;->a:Lcom/google/android/gms/common/api/internal/LifecycleCallback;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->onStop()V

    :cond_4
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g4;->c:Lcom/google/android/gms/common/api/internal/h4;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/h4;->c0(Lcom/google/android/gms/common/api/internal/h4;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-lt v0, v1, :cond_5

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g4;->a:Lcom/google/android/gms/common/api/internal/LifecycleCallback;

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->onDestroy()V

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method
