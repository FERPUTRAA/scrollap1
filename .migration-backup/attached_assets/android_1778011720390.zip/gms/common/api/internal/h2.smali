.class public final Lcom/google/android/gms/common/api/internal/h2;
.super Lcom/google/android/gms/common/api/internal/u3;


# instance fields
.field private e:Lcom/google/android/gms/tasks/TaskCompletionSource;


# direct methods
.method private constructor <init>(Lcom/google/android/gms/common/api/internal/m;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/common/f;->x()Lcom/google/android/gms/common/f;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/api/internal/u3;-><init>(Lcom/google/android/gms/common/api/internal/m;Lcom/google/android/gms/common/f;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance p1, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/h2;->e:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->mLifecycleFragment:Lcom/google/android/gms/common/api/internal/m;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string v0, "GlsrsvmHaelbpiAyltiei"

    const-string v0, "GmsAvailabilityHelper"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {p1, v0, p0}, Lcom/google/android/gms/common/api/internal/m;->d(Ljava/lang/String;Lcom/google/android/gms/common/api/internal/LifecycleCallback;)V

    const/4 v2, 0x7

    return-void
.end method

.method public static i(Landroid/app/Activity;)Lcom/google/android/gms/common/api/internal/h2;
    .locals 4
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  im~~@~@@ @ @ ~vbto~@tl-@@~@4Sm@~~a  o ~oy @bo ~f~~~/ @ @@.@~l@dor f~ ~@@ic~ ~1~~~~oMbui / n@Ks"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {p0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->getFragment(Landroid/app/Activity;)Lcom/google/android/gms/common/api/internal/m;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v0, "GtaioyliilHaebeplAsvm"

    const-string v0, "GmsAvailabilityHelper"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-class v1, Lcom/google/android/gms/common/api/internal/h2;

    const-class v1, Lcom/google/android/gms/common/api/internal/h2;

    const-class v1, Lcom/google/android/gms/common/api/internal/h2;

    const-class v1, Lcom/google/android/gms/common/api/internal/h2;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {p0, v0, v1}, Lcom/google/android/gms/common/api/internal/m;->j(Ljava/lang/String;Ljava/lang/Class;)Lcom/google/android/gms/common/api/internal/LifecycleCallback;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast v0, Lcom/google/android/gms/common/api/internal/h2;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p0, v0, Lcom/google/android/gms/common/api/internal/h2;->e:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/tasks/Task;->isComplete()Z

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance p0, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    iput-object p0, v0, Lcom/google/android/gms/common/api/internal/h2;->e:Lcom/google/android/gms/tasks/TaskCompletionSource;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/gms/common/api/internal/h2;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/api/internal/h2;-><init>(Lcom/google/android/gms/common/api/internal/m;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0
.end method


# virtual methods
.method protected final b(Lcom/google/android/gms/common/ConnectionResult;I)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/common/ConnectionResult;->z2()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez p2, :cond_0

    const/4 v4, 0x0

    move v5, v4

    const-string p2, "Gset bgonerilrErgselrcioP os cno ecnyvoa"

    const-string/jumbo p2, "gvsosoeneiPoElt iyrr letc rncaosnGoegcr "

    const-string/jumbo p2, "nn eacu ierrttcorongcG vPlErs esoeigloo "

    const-string p2, "Error connecting to Google Play services"

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/h2;->e:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v5, 0x0

    new-instance v1, Lcom/google/android/gms/common/api/b;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v2, Lcom/google/android/gms/common/api/Status;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {v2, p1, p2, v3}, Lcom/google/android/gms/common/api/Status;-><init>(Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/String;I)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {v1, v2}, Lcom/google/android/gms/common/api/b;-><init>(Lcom/google/android/gms/common/api/Status;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setException(Ljava/lang/Exception;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method protected final c()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->mLifecycleFragment:Lcom/google/android/gms/common/api/internal/m;

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-interface {v0}, Lcom/google/android/gms/common/api/internal/m;->L()Landroid/app/Activity;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/h2;->e:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    new-instance v1, Lcom/google/android/gms/common/api/b;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    new-instance v2, Lcom/google/android/gms/common/api/Status;

    const/4 v5, 0x0

    const/16 v3, 0x8

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {v2, v3}, Lcom/google/android/gms/common/api/Status;-><init>(I)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {v1, v2}, Lcom/google/android/gms/common/api/b;-><init>(Lcom/google/android/gms/common/api/Status;)V

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->trySetException(Ljava/lang/Exception;)Z

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/u3;->d:Lcom/google/android/gms/common/f;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/f;->j(Landroid/content/Context;)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/h2;->e:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->trySetResult(Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void

    :cond_1
    const/4 v4, 0x1

    move v5, v4

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/h2;->e:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/google/android/gms/tasks/Task;->isComplete()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-nez v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance v2, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v5, 0x7

    invoke-direct {v2, v0, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x2

    and-int/2addr v5, v4

    invoke-virtual {p0, v2, v0}, Lcom/google/android/gms/common/api/internal/u3;->h(Lcom/google/android/gms/common/ConnectionResult;I)V

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void
.end method

.method public final j()Lcom/google/android/gms/tasks/Task;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/h2;->e:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public final onDestroy()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-super {p0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->onDestroy()V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/h2;->e:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v1, Ljava/util/concurrent/CancellationException;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const-string v2, "ce  oeapbvega oeba P wteiosadfalidosesbctHaote l .yve c dGrl rdmsstliyoluveiyrae"

    const-string v2, "Host activity was destroyed before Google Play services could be made available."

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v1, v2}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->trySetException(Ljava/lang/Exception;)Z

    const/4 v4, 0x0

    const/4 v3, 0x2

    return-void
.end method
