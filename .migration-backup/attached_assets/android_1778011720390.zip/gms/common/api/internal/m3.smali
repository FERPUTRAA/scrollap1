.class public final Lcom/google/android/gms/common/api/internal/m3;
.super Lcom/google/android/gms/common/api/internal/f3;


# instance fields
.field public final c:Lcom/google/android/gms/common/api/internal/n$a;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/internal/n$a;Lcom/google/android/gms/tasks/TaskCompletionSource;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v0, 0x4

    move v2, v0

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0, v0, p2}, Lcom/google/android/gms/common/api/internal/f3;-><init>(ILcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/m3;->c:Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method public final bridge synthetic d(Lcom/google/android/gms/common/api/internal/h0;Z)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/api/internal/h0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s~~o @~rm~o~ o@  4@~n@ b @l~ o~~@ @ @f  ~@i~fl-@ ~o~Kib~t~ci~u@ @b.d~1S@@o~ ~@tM/@@v a @ ~@y~s"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    return-void
.end method

.method public final f(Lcom/google/android/gms/common/api/internal/v1;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/v1;->y()Ljava/util/Map;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/m3;->c:Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast p1, Lcom/google/android/gms/common/api/internal/n2;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object p1, p1, Lcom/google/android/gms/common/api/internal/n2;->a:Lcom/google/android/gms/common/api/internal/t;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/t;->f()Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    return p1

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p1
.end method

.method public final g(Lcom/google/android/gms/common/api/internal/v1;)[Lcom/google/android/gms/common/Feature;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/v1;->y()Ljava/util/Map;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/m3;->c:Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast p1, Lcom/google/android/gms/common/api/internal/n2;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez p1, :cond_0

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object p1, p1, Lcom/google/android/gms/common/api/internal/n2;->a:Lcom/google/android/gms/common/api/internal/t;

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/t;->c()[Lcom/google/android/gms/common/Feature;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p1
.end method

.method public final h(Lcom/google/android/gms/common/api/internal/v1;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/v1;->y()Ljava/util/Map;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/m3;->c:Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast v0, Lcom/google/android/gms/common/api/internal/n2;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/v1;->w()Lcom/google/android/gms/common/api/a$f;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/f3;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v2, v0, Lcom/google/android/gms/common/api/internal/n2;->b:Lcom/google/android/gms/common/api/internal/c0;

    invoke-virtual {v2, p1, v1}, Lcom/google/android/gms/common/api/internal/c0;->b(Lcom/google/android/gms/common/api/a$b;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object p1, v0, Lcom/google/android/gms/common/api/internal/n2;->a:Lcom/google/android/gms/common/api/internal/t;

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/t;->a()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/f3;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->trySetResult(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    return-void
.end method
