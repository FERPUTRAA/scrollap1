.class public final synthetic Lcom/google/android/gms/common/api/internal/o2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final synthetic a:Lcom/google/android/gms/common/api/internal/o2;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    new-instance v0, Lcom/google/android/gms/common/api/internal/o2;

    const/4 v1, 0x1

    move v2, v1

    invoke-direct {v0}, Lcom/google/android/gms/common/api/internal/o2;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    sput-object v0, Lcom/google/android/gms/common/api/internal/o2;->a:Lcom/google/android/gms/common/api/internal/o2;

    const/4 v2, 0x7

    return-void
.end method

.method private synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "i~so~@~M-~~ oblS  @@~ft a~@~u ~@ ~m@@4 1b/~@cb ~ ~r~l@@@@@si ~@@i~vo ~ @@n/   yf~t.~@@~oKo ~d~ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    return-void
.end method
