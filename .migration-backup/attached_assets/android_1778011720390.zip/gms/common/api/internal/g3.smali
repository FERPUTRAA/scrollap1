.class public final Lcom/google/android/gms/common/api/internal/g3;
.super Lcom/google/android/gms/common/api/z;

# interfaces
.implements Lcom/google/android/gms/common/api/w;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<R::",
        "Lcom/google/android/gms/common/api/v;",
        ">",
        "Lcom/google/android/gms/common/api/z<",
        "TR;>;",
        "Lcom/google/android/gms/common/api/w<",
        "TR;>;"
    }
.end annotation


# instance fields
.field private a:Lcom/google/android/gms/common/api/y;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private b:Lcom/google/android/gms/common/api/internal/g3;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private volatile c:Lcom/google/android/gms/common/api/x;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private d:Lcom/google/android/gms/common/api/p;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final e:Ljava/lang/Object;

.field private f:Lcom/google/android/gms/common/api/Status;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final g:Ljava/lang/ref/WeakReference;

.field private final h:Lcom/google/android/gms/common/api/internal/e3;

.field private i:Z


# direct methods
.method public constructor <init>(Ljava/lang/ref/WeakReference;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/common/api/z;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->a:Lcom/google/android/gms/common/api/y;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->b:Lcom/google/android/gms/common/api/internal/g3;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->c:Lcom/google/android/gms/common/api/x;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->d:Lcom/google/android/gms/common/api/p;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v1, Ljava/lang/Object;

    const/4 v2, 0x3

    move v3, v2

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->e:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->f:Lcom/google/android/gms/common/api/Status;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-boolean v0, p0, Lcom/google/android/gms/common/api/internal/g3;->i:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v0, "emsreuutne os btleiptGsgloCe eno ifnnc llr"

    const-string/jumbo v0, "otsfelunui  p eortntGmelr bgCenolesi cenel"

    const/4 v3, 0x1

    const-string v0, " lsmeee lbftp CietoeomnnuueeAlGlonrc tinr "

    const-string v0, "GoogleApiClient reference must not be null"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/g3;->g:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    check-cast p1, Lcom/google/android/gms/common/api/l;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/common/api/internal/e3;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/l;->r()Landroid/os/Looper;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/api/internal/e3;-><init>(Lcom/google/android/gms/common/api/internal/g3;Landroid/os/Looper;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->h:Lcom/google/android/gms/common/api/internal/e3;

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method static bridge synthetic d(Lcom/google/android/gms/common/api/internal/g3;)Lcom/google/android/gms/common/api/y;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "4o@-o@b1bb@ n@@@dS i @f~@@f@ ~ ~moM~K~~~r@u i~ @a@ ~@o/~t@ ~y~v~ ~t~    l@/~~@c@ @~oilo~@~~.o  s"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/g3;->a:Lcom/google/android/gms/common/api/y;

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method static bridge synthetic e(Lcom/google/android/gms/common/api/internal/g3;)Lcom/google/android/gms/common/api/internal/e3;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/g3;->h:Lcom/google/android/gms/common/api/internal/e3;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method static bridge synthetic f(Lcom/google/android/gms/common/api/internal/g3;)Lcom/google/android/gms/common/api/internal/g3;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/g3;->b:Lcom/google/android/gms/common/api/internal/g3;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method static bridge synthetic g(Lcom/google/android/gms/common/api/internal/g3;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/g3;->e:Ljava/lang/Object;

    const/4 v1, 0x2

    return-object p0
.end method

.method static bridge synthetic h(Lcom/google/android/gms/common/api/internal/g3;)Ljava/lang/ref/WeakReference;
    .locals 2

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/g3;->g:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method static bridge synthetic i(Lcom/google/android/gms/common/api/internal/g3;Lcom/google/android/gms/common/api/v;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/g3;->q(Lcom/google/android/gms/common/api/v;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method static bridge synthetic j(Lcom/google/android/gms/common/api/internal/g3;Lcom/google/android/gms/common/api/Status;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/g3;->m(Lcom/google/android/gms/common/api/Status;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method private final m(Lcom/google/android/gms/common/api/Status;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->e:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/g3;->f:Lcom/google/android/gms/common/api/Status;

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/g3;->o(Lcom/google/android/gms/common/api/Status;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    monitor-exit v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    throw p1
.end method

.method private final n()V
    .locals 4
    .annotation build Lz4/a;
        value = "syncToken"
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->a:Lcom/google/android/gms/common/api/y;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->c:Lcom/google/android/gms/common/api/x;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_3

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->g:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast v0, Lcom/google/android/gms/common/api/l;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-boolean v1, p0, Lcom/google/android/gms/common/api/internal/g3;->i:Z

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->a:Lcom/google/android/gms/common/api/y;

    const/4 v2, 0x4

    move v3, v2

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/api/l;->H(Lcom/google/android/gms/common/api/internal/g3;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/google/android/gms/common/api/internal/g3;->i:Z

    :cond_1
    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->f:Lcom/google/android/gms/common/api/Status;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/g3;->o(Lcom/google/android/gms/common/api/Status;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :cond_2
    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->d:Lcom/google/android/gms/common/api/p;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_3

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/api/p;->setResultCallback(Lcom/google/android/gms/common/api/w;)V

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method private final o(Lcom/google/android/gms/common/api/Status;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->e:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->a:Lcom/google/android/gms/common/api/y;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v1, p1}, Lcom/google/android/gms/common/api/y;->b(Lcom/google/android/gms/common/api/Status;)Lcom/google/android/gms/common/api/Status;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v1, "  uunbellriltenstnFnrt omuoau "

    const-string v1, "  om laFruntlutonmesrluneniu t"

    const/4 v3, 0x5

    const-string v1, " laot uo Fnul ennuernurimsttlu"

    const-string/jumbo v1, "onFailure must not return null"

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1, v1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast p1, Lcom/google/android/gms/common/api/Status;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->b:Lcom/google/android/gms/common/api/internal/g3;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v1, Lcom/google/android/gms/common/api/internal/g3;

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v1, p1}, Lcom/google/android/gms/common/api/internal/g3;->m(Lcom/google/android/gms/common/api/Status;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/g3;->p()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->c:Lcom/google/android/gms/common/api/x;

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v1, Lcom/google/android/gms/common/api/x;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1, p1}, Lcom/google/android/gms/common/api/x;->b(Lcom/google/android/gms/common/api/Status;)V

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    throw p1
.end method

.method private final p()Z
    .locals 4
    .annotation build Lz4/a;
        value = "syncToken"
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->g:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast v0, Lcom/google/android/gms/common/api/l;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->c:Lcom/google/android/gms/common/api/x;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    return v0
.end method

.method private static final q(Lcom/google/android/gms/common/api/v;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    instance-of v0, p0, Lcom/google/android/gms/common/api/r;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    :try_start_0
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast v0, Lcom/google/android/gms/common/api/r;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {v0}, Lcom/google/android/gms/common/api/r;->release()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    return-void

    :catch_0
    move-exception v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v1, "strmduppoaelrRoTnlmeI"

    const-string v1, "epesodsulornlamTtRrIm"

    const/4 v4, 0x0

    const-string v1, "eoIfRnTaqrpdlusrtemsl"

    const-string v1, "TransformedResultImpl"

    const/4 v3, 0x0

    or-int/2addr v4, v3

    const-string v2, "bos al rlsbeetUeen"

    const-string/jumbo v2, "nea sbaeUelelb tro"

    const/4 v4, 0x6

    const-string/jumbo v2, "slnmeteoleba aU  e"

    const-string v2, "Unable to release "

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v2, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v1, p0, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/common/api/v;)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->e:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {p1}, Lcom/google/android/gms/common/api/v;->getStatus()Lcom/google/android/gms/common/api/Status;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/Status;->E2()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->a:Lcom/google/android/gms/common/api/y;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    move v4, v3

    invoke-static {}, Lcom/google/android/gms/common/api/internal/t2;->a()Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v2, Lcom/google/android/gms/common/api/internal/d3;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v2, p0, p1}, Lcom/google/android/gms/common/api/internal/d3;-><init>(Lcom/google/android/gms/common/api/internal/g3;Lcom/google/android/gms/common/api/v;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {v1, v2}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/g3;->p()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->c:Lcom/google/android/gms/common/api/x;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v1, Lcom/google/android/gms/common/api/x;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Lcom/google/android/gms/common/api/x;->c(Lcom/google/android/gms/common/api/v;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    move v4, v3

    invoke-interface {p1}, Lcom/google/android/gms/common/api/v;->getStatus()Lcom/google/android/gms/common/api/Status;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0, v1}, Lcom/google/android/gms/common/api/internal/g3;->m(Lcom/google/android/gms/common/api/Status;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/g3;->q(Lcom/google/android/gms/common/api/v;)V

    :cond_2
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    throw p1
.end method

.method public final b(Lcom/google/android/gms/common/api/x;)V
    .locals 7
    .param p1    # Lcom/google/android/gms/common/api/x;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/x<",
            "-TR;>;)V"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->e:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->c:Lcom/google/android/gms/common/api/x;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x2

    if-nez v1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    move v1, v2

    move v1, v2

    const/4 v6, 0x0

    move v1, v2

    move v1, v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    move v1, v3

    move v1, v3

    const/4 v6, 0x3

    move v1, v3

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string v4, ") y otala.F olnulwacCtniilncae("

    const-string v4, " aFintulc Ct ncn)a.n(ealwaiylol"

    const/4 v6, 0x1

    const-string/jumbo v4, "loln bwtd yiaCetncl naa(lci)F.n"

    const-string v4, "Cannot call andFinally() twice."

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v1, v4}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->a:Lcom/google/android/gms/common/api/y;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-nez v1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto :goto_1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    move v2, v3

    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v1, "ans(tru nraeatRnmftedha as. houecnCeao apenn)loTll   (intlFmd)ldns"

    const-string v1, "entnahopfunoa anr)ol  tacrF(ten .aesh m(ils tn enalTl sRedmdl)dnCa"

    const/4 v6, 0x4

    const-string v1, "acalrtapR ie.neaT) aryFCd(n nlatone anfm (hsul onhse t)s domnldlet"

    const-string v1, "Cannot call then() and andFinally() on the same TransformedResult."

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v2, v1}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/g3;->c:Lcom/google/android/gms/common/api/x;

    const/4 v6, 0x5

    const/4 v5, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/g3;->n()V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    throw p1
.end method

.method public final c(Lcom/google/android/gms/common/api/y;)Lcom/google/android/gms/common/api/z;
    .locals 7
    .param p1    # Lcom/google/android/gms/common/api/y;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<S::",
            "Lcom/google/android/gms/common/api/v;",
            ">(",
            "Lcom/google/android/gms/common/api/y<",
            "-TR;+TS;>;)",
            "Lcom/google/android/gms/common/api/z<",
            "TS;>;"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->e:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->a:Lcom/google/android/gms/common/api/y;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    shr-int/2addr v6, v3

    and-int/2addr v5, v3

    if-nez v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    move v1, v2

    move v1, v2

    const/4 v6, 0x6

    move v1, v2

    move v1, v2

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    move v1, v3

    move v1, v3

    const/4 v6, 0x3

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v6, 0x2

    const-string/jumbo v4, "ntl )i aqCnaecwol.hnqcet("

    const-string v4, "Caoethn(qa wt cln .ince)l"

    const/4 v6, 0x1

    const-string v4, "( sn hc)a cintlewttoCl.ne"

    const-string v4, "Cannot call then() twice."

    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-static {v1, v4}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->c:Lcom/google/android/gms/common/api/x;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-nez v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    goto :goto_1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    move v2, v3

    move v2, v3

    const/4 v6, 0x7

    move v2, v3

    move v2, v3

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string v1, "Rn mf)all nhrlanduh edcsnFonaeltm esn ise aCtmy.  anaoela(tnort)(s"

    const-string/jumbo v1, "hmsaentys nlelnifaCsFnmta dhod)utenal) eoa  c(n(ltn rsnolRa e. dar"

    const-string v1, " al outon(c TnlmyeldaenoCstilaF hotna.nh)n en( )measntdfsaa elr Rd"

    const-string v1, "Cannot call then() and andFinally() on the same TransformedResult."

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v2, v1}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v6, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/g3;->a:Lcom/google/android/gms/common/api/y;

    const/4 v6, 0x7

    new-instance p1, Lcom/google/android/gms/common/api/internal/g3;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/g3;->g:Ljava/lang/ref/WeakReference;

    const/4 v6, 0x5

    const/4 v5, 0x1

    invoke-direct {p1, v1}, Lcom/google/android/gms/common/api/internal/g3;-><init>(Ljava/lang/ref/WeakReference;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/g3;->b:Lcom/google/android/gms/common/api/internal/g3;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/g3;->n()V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    monitor-exit v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    throw p1
.end method

.method final k()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->c:Lcom/google/android/gms/common/api/x;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public final l(Lcom/google/android/gms/common/api/p;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/g3;->e:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/g3;->d:Lcom/google/android/gms/common/api/p;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/g3;->n()V

    const/4 v2, 0x0

    monitor-exit v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    throw p1
.end method
