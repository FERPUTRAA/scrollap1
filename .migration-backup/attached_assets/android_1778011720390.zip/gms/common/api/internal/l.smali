.class public Lcom/google/android/gms/common/api/internal/l;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# instance fields
.field private final a:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/app/Activity;)V
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    and-int/2addr v2, v1

    const-string v0, "Aissmluts vt ionut clbynt"

    const-string v0, "A syc lu ltitnmtnesuotibv"

    const/4 v2, 0x4

    const-string v0, "elimAv n btusiytmt uot lc"

    const-string v0, "Activity must not be null"

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/l;->a:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/ContextWrapper;)V
    .locals 2
    .param p1    # Landroid/content/ContextWrapper;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x2

    move v1, v0

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x1

    throw p1
.end method


# virtual methods
.method public final a()Landroid/app/Activity;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "m .1os ~l ~lo~@bc/r~ @o@~f~S~M~/@y~ u@ivaKo bto~~b @@~ @~f~~~   @@~@~n@-~@@~@i~o ~@ dto @@@i  @4"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/l;->a:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast v0, Landroid/app/Activity;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public final b()Landroidx/fragment/app/FragmentActivity;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/l;->a:Ljava/lang/Object;

    const/4 v2, 0x0

    check-cast v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v2, 0x5

    const/4 v1, 0x6

    return-object v0
.end method

.method public final c()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/l;->a:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    instance-of v0, v0, Landroid/app/Activity;

    const/4 v2, 0x0

    const/4 v1, 0x2

    return v0
.end method

.method public final d()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/l;->a:Ljava/lang/Object;

    const/4 v2, 0x3

    instance-of v0, v0, Landroidx/fragment/app/FragmentActivity;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method
