.class public final Lcom/google/android/gms/common/api/internal/p3;
.super Lcom/google/android/gms/common/api/internal/u3;


# instance fields
.field private final e:Landroid/util/SparseArray;


# direct methods
.method private constructor <init>(Lcom/google/android/gms/common/api/internal/m;)V
    .locals 3

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/android/gms/common/f;->x()Lcom/google/android/gms/common/f;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/api/internal/u3;-><init>(Lcom/google/android/gms/common/api/internal/m;Lcom/google/android/gms/common/f;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance p1, Landroid/util/SparseArray;

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->mLifecycleFragment:Lcom/google/android/gms/common/api/internal/m;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string v0, "AlsHastareeouMeg"

    const-string/jumbo v0, "rostunAelegHeMaa"

    const/4 v2, 0x2

    const-string/jumbo v0, "teumrlanAHaeoegp"

    const-string v0, "AutoManageHelper"

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {p1, v0, p0}, Lcom/google/android/gms/common/api/internal/m;->d(Ljava/lang/String;Lcom/google/android/gms/common/api/internal/LifecycleCallback;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public static i(Lcom/google/android/gms/common/api/internal/l;)Lcom/google/android/gms/common/api/internal/p3;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o@i~o~ySl ~@~  @@@@o a~~@t~ @~@ @1id~/~l~ @@m@ ~ @@b t@n/sb   ~@-~.c  ~~~@fo~ui4 orbo~v~~f@Ko~@M"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    invoke-static {p0}, Lcom/google/android/gms/common/api/internal/LifecycleCallback;->getFragment(Lcom/google/android/gms/common/api/internal/l;)Lcom/google/android/gms/common/api/internal/m;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const-string/jumbo v0, "uonmltAaaerHeeMg"

    const/4 v3, 0x6

    const-string v0, "aeHglbuMnoArpeat"

    const-string v0, "AutoManageHelper"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/gms/common/api/internal/p3;

    const-class v1, Lcom/google/android/gms/common/api/internal/p3;

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/gms/common/api/internal/p3;

    const-class v1, Lcom/google/android/gms/common/api/internal/p3;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {p0, v0, v1}, Lcom/google/android/gms/common/api/internal/m;->j(Ljava/lang/String;Ljava/lang/Class;)Lcom/google/android/gms/common/api/internal/LifecycleCallback;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast v0, Lcom/google/android/gms/common/api/internal/p3;

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/common/api/internal/p3;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/api/internal/p3;-><init>(Lcom/google/android/gms/common/api/internal/m;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method private final l(I)Lcom/google/android/gms/common/api/internal/o3;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-gt v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p1, Lcom/google/android/gms/common/api/internal/o3;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p1
.end method


# virtual methods
.method protected final b(Lcom/google/android/gms/common/ConnectionResult;I)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const-string v0, ".tipleugom -pehaan eae lgSni.cnudogreni vnowric Urcsrolottot en"

    const-string v0, "Ungcoinoht.ecl-r u.eSo gioc nonatldiptvnerwaetoa ge prsnn lmrei"

    const/4 v3, 0x3

    const-string v0, ".ni  wlphS.oUvleneoonne tnmgas pin-r polccrergidunraatgeeit otc"

    const-string v0, "Unresolved error while connecting client. Stopping auto-manage."

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v1, "ogrHueeAqbealapM"

    const-string/jumbo v1, "rMneHbgeoaAluape"

    const/4 v3, 0x0

    const-string v1, "epsMAoaalgHtruen"

    const-string v1, "AutoManageHelper"

    const/4 v3, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-gez p2, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/Exception;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p1}, Ljava/lang/Exception;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string p2, " tcmtrHfdsFnkdtp lciaoEicuLlcIurefevrlaAb   ybong eeearlcMotn nuiaenileieDliiocRu argn sale eolieto"

    const-string/jumbo p2, "ne sonua yMpnklo ttdifarceoesD utIf dblcl  cFcearAtrnvlReloirEeaeeiliaeigclL oaeisbiHgrnitou cul en"

    const-string/jumbo p2, "neceoutr ocrbiesnLicuelnifAaaiyesaaigtltl kcooe eF nltdaecberniuDg I oplvidlnraHeiRe s  oorMclfel t"

    const-string p2, "AutoManageLifecycleHelper received onErrorResolutionFailed callback but no failing client ID is set"

    const/4 v2, 0x1

    move v3, v2

    invoke-static {v1, p2, p1}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast v0, Lcom/google/android/gms/common/api/internal/o3;

    const/4 v3, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    invoke-virtual {p0, p2}, Lcom/google/android/gms/common/api/internal/p3;->k(I)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object p2, v0, Lcom/google/android/gms/common/api/internal/o3;->c:Lcom/google/android/gms/common/api/l$c;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz p2, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {p2, p1}, Lcom/google/android/gms/common/api/internal/q;->c(Lcom/google/android/gms/common/ConnectionResult;)V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method protected final c()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    if-ge v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/p3;->l(I)Lcom/google/android/gms/common/api/internal/o3;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v1, v1, Lcom/google/android/gms/common/api/internal/o3;->b:Lcom/google/android/gms/common/api/l;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/l;->g()V

    :cond_0
    const/4 v2, 0x5

    const/4 v3, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method public final dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 6

    const/4 v0, 0x0

    move v5, v0

    move v4, v0

    move v4, v0

    :goto_0
    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-ge v0, v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/p3;->l(I)Lcom/google/android/gms/common/api/internal/o3;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string v3, " tpoAbeGiienlgoCl"

    const-string v3, "GoogleApiClient #"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v3, v1, Lcom/google/android/gms/common/api/internal/o3;->a:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/io/PrintWriter;->print(I)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string v2, ":"

    const-string v2, ":"

    const/4 v5, 0x5

    const-string v2, ":"

    const-string v2, ":"

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {p3, v2}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/google/android/gms/common/api/internal/o3;->b:Lcom/google/android/gms/common/api/l;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string v3, "  "

    const-string v3, "  "

    const/4 v5, 0x1

    const-string v3, "  "

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1, v2, p2, p3, p4}, Lcom/google/android/gms/common/api/l;->j(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    return-void
.end method

.method public final j(ILcom/google/android/gms/common/api/l;Lcom/google/android/gms/common/api/l$c;)V
    .locals 7
    .param p3    # Lcom/google/android/gms/common/api/l$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v6, 0x7

    const/4 v5, 0x2

    const-string/jumbo v0, "lcinCuulGen tec olbitpnonnaseA gnlpteao"

    const-string v0, "elplcoCpnloiiblaeueningon A aGntn cstte"

    const/4 v6, 0x5

    const-string/jumbo v0, "lgeieCspltn uentlbnoc  ieacaloGpnntinoA"

    const-string v0, "GoogleApiClient instance cannot be null"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {p2, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->indexOfKey(I)I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v2, "Aliigw nqCpneodhoratdaiitGAle y g namaieg  "

    const/4 v6, 0x1

    const-string v2, "Already managing a GoogleApiClient with id "

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-gez v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v0, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u3;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    check-cast v0, Lcom/google/android/gms/common/api/internal/r3;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-boolean v1, p0, Lcom/google/android/gms/common/api/internal/u3;->a:Z

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v4, " tniaa gqfriAlnsstuoM ncrtgea e"

    const-string/jumbo v4, "iasgeMr acnt otAlnerfi aun gost"

    const/4 v6, 0x0

    const-string/jumbo v4, "uisr ngrtna tioaMa eteAngsolcf "

    const-string/jumbo v4, "starting AutoManage for client "

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const-string v4, " "

    const-string v4, " "

    const/4 v6, 0x3

    const-string v4, " "

    const-string v4, " "

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string v2, "ergmtamepnAHaluM"

    const-string v2, "HotmpAlngeauareM"

    const/4 v6, 0x5

    const-string/jumbo v2, "uorloaeegHenaAtp"

    const-string v2, "AutoManageHelper"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v1, Lcom/google/android/gms/common/api/internal/o3;

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/google/android/gms/common/api/internal/o3;-><init>(Lcom/google/android/gms/common/api/internal/p3;ILcom/google/android/gms/common/api/l;Lcom/google/android/gms/common/api/l$c;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p2, v1}, Lcom/google/android/gms/common/api/l;->C(Lcom/google/android/gms/common/api/l$c;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object p3, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p3, p1, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-boolean p1, p0, Lcom/google/android/gms/common/api/internal/u3;->a:Z

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz p1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-nez v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string p3, "c cotbenoin"

    const-string/jumbo p3, "nn iooctnec"

    const/4 v6, 0x4

    const-string/jumbo p3, "tnccgnueoi "

    const-string p3, "connecting "

    const/4 v5, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v2, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p2}, Lcom/google/android/gms/common/api/l;->g()V

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    return-void
.end method

.method public final k(I)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast v0, Lcom/google/android/gms/common/api/internal/o3;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    invoke-virtual {v1, p1}, Landroid/util/SparseArray;->remove(I)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p1, v0, Lcom/google/android/gms/common/api/internal/o3;->b:Lcom/google/android/gms/common/api/l;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/api/l;->G(Lcom/google/android/gms/common/api/l$c;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object p1, v0, Lcom/google/android/gms/common/api/internal/o3;->b:Lcom/google/android/gms/common/api/l;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/l;->i()V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public final onStart()V
    .locals 6

    const/4 v5, 0x1

    invoke-super {p0}, Lcom/google/android/gms/common/api/internal/u3;->onStart()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v5, 0x5

    const/4 v4, 0x7

    iget-boolean v1, p0, Lcom/google/android/gms/common/api/internal/u3;->a:Z

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const-string v3, "Sntrabop"

    const-string/jumbo v3, "taSrnbo "

    const/4 v5, 0x7

    const-string/jumbo v3, "onStart "

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v1, " "

    const-string v1, " "

    const/4 v5, 0x7

    const-string v1, " "

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v1, "MueAHtanqloaeure"

    const-string v1, "auorHaulpenteeAM"

    const/4 v5, 0x0

    const-string/jumbo v1, "nMsAteleogruaHep"

    const-string v1, "AutoManageHelper"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/u3;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-ge v0, v1, :cond_1

    const/4 v5, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/p3;->l(I)Lcom/google/android/gms/common/api/internal/o3;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v1, v1, Lcom/google/android/gms/common/api/internal/o3;->b:Lcom/google/android/gms/common/api/l;

    const/4 v5, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/l;->g()V

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-void
.end method

.method public final onStop()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-super {p0}, Lcom/google/android/gms/common/api/internal/u3;->onStop()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/p3;->e:Landroid/util/SparseArray;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ge v0, v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/p3;->l(I)Lcom/google/android/gms/common/api/internal/o3;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v1, v1, Lcom/google/android/gms/common/api/internal/o3;->b:Lcom/google/android/gms/common/api/l;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/l;->i()V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method
