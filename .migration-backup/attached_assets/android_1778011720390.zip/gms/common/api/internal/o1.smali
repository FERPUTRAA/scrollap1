.class public final Lcom/google/android/gms/common/api/internal/o1;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/util/concurrent/ExecutorService;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/base/zat;->zaa()Lcom/google/android/gms/internal/base/zaq;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v1, Lcom/google/android/gms/common/util/concurrent/c;

    const/4 v3, 0x4

    and-int/2addr v4, v3

    const-string/jumbo v2, "xEstGr_cAues"

    const-string v2, "Exsrtoe_uGAc"

    const/4 v4, 0x2

    const-string v2, "AoEmtCG_ucrx"

    const-string v2, "GAC_Executor"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v1, v2}, Lcom/google/android/gms/common/util/concurrent/c;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {v0, v2, v1, v2}, Lcom/google/android/gms/internal/base/zaq;->zac(ILjava/util/concurrent/ThreadFactory;I)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    sput-object v0, Lcom/google/android/gms/common/api/internal/o1;->a:Ljava/util/concurrent/ExecutorService;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void
.end method

.method public static a()Ljava/util/concurrent/ExecutorService;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " s~ o@ ~  ~ ~l/itv -   y@r~@1 u4@@ ~f@@i@lbKc@M~ot~~bf~ ~o~S/~@~o m~i@.@@~ ~ no@~o@o~ad@@@@~b~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/common/api/internal/o1;->a:Ljava/util/concurrent/ExecutorService;

    const/4 v2, 0x0

    return-object v0
.end method
