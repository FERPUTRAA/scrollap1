.class final Lcom/google/android/gms/common/api/internal/w2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/google/android/gms/signin/internal/zak;

.field final synthetic b:Lcom/google/android/gms/common/api/internal/y2;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/y2;Lcom/google/android/gms/signin/internal/zak;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/w2;->b:Lcom/google/android/gms/common/api/internal/y2;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/w2;->a:Lcom/google/android/gms/signin/internal/zak;

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s~o @@t~   ~~ l~l i@@i o  ~@s~~o@ fm~ f@aSu~@  c~~1v4~y@i rbb@o @-/@@o ~@b~tK@~~~@@Mn~ /d~@o.~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/w2;->b:Lcom/google/android/gms/common/api/internal/y2;

    const/4 v3, 0x6

    const/4 v2, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/w2;->a:Lcom/google/android/gms/signin/internal/zak;

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/google/android/gms/common/api/internal/y2;->p0(Lcom/google/android/gms/common/api/internal/y2;Lcom/google/android/gms/signin/internal/zak;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method
