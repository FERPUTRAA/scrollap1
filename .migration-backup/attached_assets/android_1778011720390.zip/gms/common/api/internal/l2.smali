.class public final synthetic Lcom/google/android/gms/common/api/internal/l2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/google/android/gms/common/api/internal/p;

.field public final synthetic b:Landroid/os/IBinder;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/common/api/internal/p;Landroid/os/IBinder;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/l2;->a:Lcom/google/android/gms/common/api/internal/p;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/l2;->b:Landroid/os/IBinder;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~cslK@~ tf@@@~omSbo ~ di/@@@~M b ~1 @ @~~@@s~ov i  ~o~bf~~~-. r~ ~  ~@ i@u@@ay o~tln@/@o~~@~4@@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/l2;->a:Lcom/google/android/gms/common/api/internal/p;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/l2;->b:Landroid/os/IBinder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/api/internal/p;->f(Landroid/os/IBinder;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    return-void
.end method
