.class public final Lcom/google/android/gms/common/api/internal/k3;
.super Lcom/google/android/gms/common/api/internal/f3;


# instance fields
.field public final c:Lcom/google/android/gms/common/api/internal/n2;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/internal/n2;Lcom/google/android/gms/tasks/TaskCompletionSource;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0, v0, p2}, Lcom/google/android/gms/common/api/internal/f3;-><init>(ILcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v1, 0x5

    move v2, v1

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/k3;->c:Lcom/google/android/gms/common/api/internal/n2;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public final bridge synthetic d(Lcom/google/android/gms/common/api/internal/h0;Z)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/api/internal/h0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    return-void
.end method

.method public final f(Lcom/google/android/gms/common/api/internal/v1;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/k3;->c:Lcom/google/android/gms/common/api/internal/n2;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget-object p1, p1, Lcom/google/android/gms/common/api/internal/n2;->a:Lcom/google/android/gms/common/api/internal/t;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/t;->f()Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    return p1
.end method

.method public final g(Lcom/google/android/gms/common/api/internal/v1;)[Lcom/google/android/gms/common/Feature;
    .locals 2
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/k3;->c:Lcom/google/android/gms/common/api/internal/n2;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p1, p1, Lcom/google/android/gms/common/api/internal/n2;->a:Lcom/google/android/gms/common/api/internal/t;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/t;->c()[Lcom/google/android/gms/common/Feature;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method

.method public final h(Lcom/google/android/gms/common/api/internal/v1;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/k3;->c:Lcom/google/android/gms/common/api/internal/n2;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, v0, Lcom/google/android/gms/common/api/internal/n2;->a:Lcom/google/android/gms/common/api/internal/t;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/v1;->w()Lcom/google/android/gms/common/api/a$f;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/f3;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/common/api/internal/t;->d(Lcom/google/android/gms/common/api/a$b;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/k3;->c:Lcom/google/android/gms/common/api/internal/n2;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, v0, Lcom/google/android/gms/common/api/internal/n2;->a:Lcom/google/android/gms/common/api/internal/t;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/t;->b()Lcom/google/android/gms/common/api/internal/n$a;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/v1;->y()Ljava/util/Map;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/k3;->c:Lcom/google/android/gms/common/api/internal/n2;

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-interface {p1, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x7

    move v4, v3

    return-void
.end method
