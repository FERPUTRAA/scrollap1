.class final Lcom/google/android/gms/common/api/internal/p0;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/e$c;


# instance fields
.field private final a:Ljava/lang/ref/WeakReference;

.field private final b:Lcom/google/android/gms/common/api/a;

.field private final c:Z


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/internal/a1;Lcom/google/android/gms/common/api/a;Z)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/p0;->a:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/p0;->b:Lcom/google/android/gms/common/api/a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-boolean p3, p0, Lcom/google/android/gms/common/api/internal/p0;->c:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method static bridge synthetic b(Lcom/google/android/gms/common/api/internal/p0;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@svmado@oo@u@ tf@@~~r-i@~llofo~ ~~~ ~.~ ~b/~ i@bK @ ~@@c~ o/@~@~ ~@ 1@i bnS@~~Ms y @ ~~t4@ ~ ~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-boolean p0, p0, Lcom/google/android/gms/common/api/internal/p0;->c:Z

    const/4 v1, 0x1

    return p0
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 6
    .param p1    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/p0;->a:Ljava/lang/ref/WeakReference;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    check-cast v0, Lcom/google/android/gms/common/api/internal/a1;

    const/4 v5, 0x2

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->u(Lcom/google/android/gms/common/api/internal/a1;)Lcom/google/android/gms/common/api/internal/n1;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v2, v2, Lcom/google/android/gms/common/api/internal/n1;->n:Lcom/google/android/gms/common/api/internal/j1;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/google/android/gms/common/api/l;->r()Landroid/os/Looper;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-ne v1, v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    move v1, v3

    move v1, v3

    const/4 v5, 0x3

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string v2, " vpmrrenRtelinBhdoagpidletnteGAiedodrlctcCeinn  osnghha oe toulS liea br me"

    const-string/jumbo v2, "onReportServiceBinding must be called on the GoogleApiClient handler thread"

    const/4 v5, 0x4

    invoke-static {v1, v2}, Lcom/google/android/gms/common/internal/v;->y(ZLjava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->z(Lcom/google/android/gms/common/api/internal/a1;)Ljava/util/concurrent/locks/Lock;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0, v3}, Lcom/google/android/gms/common/api/internal/a1;->G(Lcom/google/android/gms/common/api/internal/a1;I)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_1

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/ConnectionResult;->C2()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-nez v1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/p0;->b:Lcom/google/android/gms/common/api/a;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-boolean v2, p0, Lcom/google/android/gms/common/api/internal/p0;->c:Z

    const/4 v5, 0x5

    invoke-static {v0, p1, v1, v2}, Lcom/google/android/gms/common/api/internal/a1;->D(Lcom/google/android/gms/common/api/internal/a1;Lcom/google/android/gms/common/ConnectionResult;Lcom/google/android/gms/common/api/a;Z)V

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->H(Lcom/google/android/gms/common/api/internal/a1;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    if-eqz p1, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->E(Lcom/google/android/gms/common/api/internal/a1;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_4
    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->z(Lcom/google/android/gms/common/api/internal/a1;)Ljava/util/concurrent/locks/Lock;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->z(Lcom/google/android/gms/common/api/internal/a1;)Ljava/util/concurrent/locks/Lock;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    throw p1
.end method
