.class final Lcom/google/android/gms/common/api/internal/h1;
.super Lcom/google/android/gms/internal/base/zau;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/api/internal/j1;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/j1;Landroid/os/Looper;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/h1;->a:Lcom/google/android/gms/common/api/internal/j1;

    const/4 v1, 0x0

    const/4 v0, 0x6

    invoke-direct {p0, p2}, Lcom/google/android/gms/internal/base/zau;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "ovsboSf.f o ~ t~ri@ ~l~@~~@ /@ iym ~ot M @@ @~n~K/o ~~@~u@ ~db 4@~ols@~@    c@b@@@@~1~i~~@~@-@~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget p1, p1, Landroid/os/Message;->what:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eq p1, v0, :cond_1

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eq p1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const-string v1, " nsmkon: Uindaewms e"

    const-string/jumbo v1, "sase mineUns:do  nkw"

    const/4 v3, 0x6

    const-string v1, "dsm owg:nesnUa oekin"

    const-string v1, "Unknown message id: "

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string/jumbo v0, "omimebntGCgiloIApll"

    const-string v0, "ItmmApoopigGneiClll"

    const/4 v3, 0x4

    const-string/jumbo v0, "oGliomuglnlAIptCiee"

    const-string v0, "GoogleApiClientImpl"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/h1;->a:Lcom/google/android/gms/common/api/internal/j1;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/j1;->P(Lcom/google/android/gms/common/api/internal/j1;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/h1;->a:Lcom/google/android/gms/common/api/internal/j1;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/j1;->Q(Lcom/google/android/gms/common/api/internal/j1;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method
