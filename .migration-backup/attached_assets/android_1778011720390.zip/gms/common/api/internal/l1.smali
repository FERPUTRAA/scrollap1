.class abstract Lcom/google/android/gms/common/api/internal/l1;
.super Ljava/lang/Object;


# instance fields
.field private final a:Lcom/google/android/gms/common/api/internal/k1;


# direct methods
.method protected constructor <init>(Lcom/google/android/gms/common/api/internal/k1;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/l1;->a:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method protected abstract a()V
.end method

.method public final b(Lcom/google/android/gms/common/api/internal/n1;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ts~~a @ @~4  ~@@M ~b~~- ~.~ ~@1c ~@@i~@ooin@lfo~ i@~/ df@@y~o @@b~ ~@Km~~ btrs@l@ov@~ o~ /u @S@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/n1;->d(Lcom/google/android/gms/common/api/internal/n1;)Ljava/util/concurrent/locks/Lock;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/n1;->c(Lcom/google/android/gms/common/api/internal/n1;)Lcom/google/android/gms/common/api/internal/k1;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/l1;->a:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/l1;->a()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/n1;->d(Lcom/google/android/gms/common/api/internal/n1;)Ljava/util/concurrent/locks/Lock;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/n1;->d(Lcom/google/android/gms/common/api/internal/n1;)Ljava/util/concurrent/locks/Lock;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x5

    throw v0
.end method
