.class public final Lcom/google/android/gms/common/api/internal/v1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/l$b;
.implements Lcom/google/android/gms/common/api/l$c;
.implements Lcom/google/android/gms/common/api/internal/z3;


# instance fields
.field private final a:Ljava/util/Queue;

.field private final b:Lcom/google/android/gms/common/api/a$f;
    .annotation runtime Lm9/c;
    .end annotation
.end field

.field private final c:Lcom/google/android/gms/common/api/internal/c;

.field private final d:Lcom/google/android/gms/common/api/internal/h0;

.field private final e:Ljava/util/Set;

.field private final f:Ljava/util/Map;

.field private final g:I

.field private final h:Lcom/google/android/gms/common/api/internal/y2;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private i:Z

.field private final j:Ljava/util/List;

.field private k:Lcom/google/android/gms/common/ConnectionResult;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private l:I

.field final synthetic m:Lcom/google/android/gms/common/api/internal/i;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/internal/i;Lcom/google/android/gms/common/api/k;)V
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v0, Ljava/util/LinkedList;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->a:Ljava/util/Queue;

    const/4 v4, 0x7

    const/4 v3, 0x6

    new-instance v0, Ljava/util/HashSet;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->e:Ljava/util/Set;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->f:Ljava/util/Map;

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->j:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->k:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x5

    const/4 v1, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/android/gms/common/api/internal/v1;->l:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p2, v1, p0}, Lcom/google/android/gms/common/api/k;->zab(Landroid/os/Looper;Lcom/google/android/gms/common/api/internal/v1;)Lcom/google/android/gms/common/api/a$f;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p2}, Lcom/google/android/gms/common/api/k;->getApiKey()Lcom/google/android/gms/common/api/internal/c;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-object v2, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v4, 0x2

    new-instance v2, Lcom/google/android/gms/common/api/internal/h0;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v2}, Lcom/google/android/gms/common/api/internal/h0;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-object v2, p0, Lcom/google/android/gms/common/api/internal/v1;->d:Lcom/google/android/gms/common/api/internal/h0;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/common/api/k;->zaa()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput v2, p0, Lcom/google/android/gms/common/api/internal/v1;->g:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v1}, Lcom/google/android/gms/common/api/a$f;->requiresSignIn()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->n(Lcom/google/android/gms/common/api/internal/i;)Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2, v0, p1}, Lcom/google/android/gms/common/api/k;->zac(Landroid/content/Context;Landroid/os/Handler;)Lcom/google/android/gms/common/api/internal/y2;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->h:Lcom/google/android/gms/common/api/internal/y2;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->h:Lcom/google/android/gms/common/api/internal/y2;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method static bridge synthetic A(Lcom/google/android/gms/common/api/internal/v1;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@os1~ o lo~~~ u@@.~M -  n~~~@~~~s@~@b ofi foKb/trl~  @ @@ mv@t@~~o~@ S@i/@4 @diy  ~@a~@c~~b~@@ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/v1;->k()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method static bridge synthetic B(Lcom/google/android/gms/common/api/internal/v1;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->l(I)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method static bridge synthetic C(Lcom/google/android/gms/common/api/internal/v1;Lcom/google/android/gms/common/api/internal/x1;)V
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->j:Ljava/util/List;

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-boolean p1, p0, Lcom/google/android/gms/common/api/internal/v1;->i:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez p1, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {p1}, Lcom/google/android/gms/common/api/a$f;->isConnected()Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez p1, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/v1;->F()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/v1;->j()V

    :cond_2
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method static bridge synthetic D(Lcom/google/android/gms/common/api/internal/v1;Lcom/google/android/gms/common/api/internal/x1;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->j:Ljava/util/List;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz v0, :cond_2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v6, 0x4

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/16 v1, 0xf

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/16 v1, 0x10

    const/4 v5, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/x1;->a(Lcom/google/android/gms/common/api/internal/x1;)Lcom/google/android/gms/common/Feature;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->a:Ljava/util/Queue;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance v1, Ljava/util/ArrayList;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->a:Ljava/util/Queue;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v2, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    check-cast v2, Lcom/google/android/gms/common/api/internal/n3;

    const/4 v5, 0x5

    move v6, v5

    instance-of v3, v2, Lcom/google/android/gms/common/api/internal/e2;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz v3, :cond_0

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    check-cast v3, Lcom/google/android/gms/common/api/internal/e2;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v3, p0}, Lcom/google/android/gms/common/api/internal/e2;->g(Lcom/google/android/gms/common/api/internal/v1;)[Lcom/google/android/gms/common/Feature;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz v3, :cond_0

    const/4 v6, 0x2

    invoke-static {v3, p1}, Lcom/google/android/gms/common/util/b;->d([Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    const/4 v5, 0x4

    shr-int/2addr v6, v5

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x1

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v2, 0x0

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-ge v2, v0, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast v3, Lcom/google/android/gms/common/api/internal/n3;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/v1;->a:Ljava/util/Queue;

    invoke-interface {v4, v3}, Ljava/util/Collection;->remove(Ljava/lang/Object;)Z

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    new-instance v4, Lcom/google/android/gms/common/api/a0;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {v4, p1}, Lcom/google/android/gms/common/api/a0;-><init>(Lcom/google/android/gms/common/Feature;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v3, v4}, Lcom/google/android/gms/common/api/internal/n3;->b(Ljava/lang/Exception;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_1

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x7

    return-void
.end method

.method static bridge synthetic O(Lcom/google/android/gms/common/api/internal/v1;)Z
    .locals 2

    const/4 v1, 0x2

    iget-boolean p0, p0, Lcom/google/android/gms/common/api/internal/v1;->i:Z

    const/4 v1, 0x3

    const/4 v0, 0x0

    return p0
.end method

.method static bridge synthetic P(Lcom/google/android/gms/common/api/internal/v1;Z)Z
    .locals 2

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x2

    move v0, p1

    move v0, p1

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->r(Z)Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p0
.end method

.method private final f([Lcom/google/android/gms/common/Feature;)Lcom/google/android/gms/common/Feature;
    .locals 11
    .param p1    # [Lcom/google/android/gms/common/Feature;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 v0, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x7

    if-eqz p1, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    array-length v1, p1

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    if-nez v1, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    goto/16 :goto_3

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    invoke-interface {v1}, Lcom/google/android/gms/common/api/a$f;->getAvailableFeatures()[Lcom/google/android/gms/common/Feature;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    const/4 v2, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-nez v1, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    new-array v1, v2, [Lcom/google/android/gms/common/Feature;

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x2

    new-instance v3, Landroidx/collection/a;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    array-length v4, v1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-direct {v3, v4}, Landroidx/collection/a;-><init>(I)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    move v4, v2

    const/4 v10, 0x3

    move v4, v2

    move v4, v2

    :goto_0
    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    array-length v5, v1

    const/4 v9, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-ge v4, v5, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    aget-object v5, v1, v4

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v5}, Lcom/google/android/gms/common/Feature;->y2()Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {v5}, Lcom/google/android/gms/common/Feature;->z2()J

    move-result-wide v7

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-interface {v3, v6, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x7

    goto :goto_0

    :cond_2
    const/4 v9, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    array-length v1, p1

    :goto_1
    const/4 v10, 0x1

    if-ge v2, v1, :cond_5

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    aget-object v4, p1, v2

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v4}, Lcom/google/android/gms/common/Feature;->y2()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x6

    const/4 v9, 0x7

    invoke-interface {v3, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    check-cast v5, Ljava/lang/Long;

    const/4 v10, 0x0

    const/4 v9, 0x5

    if-eqz v5, :cond_4

    const/4 v10, 0x3

    const/4 v9, 0x2

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v4}, Lcom/google/android/gms/common/Feature;->z2()J

    move-result-wide v7

    const/4 v10, 0x1

    const/4 v9, 0x0

    cmp-long v5, v5, v7

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-gez v5, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    goto :goto_2

    :cond_3
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    goto :goto_1

    :cond_4
    :goto_2
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    return-object v4

    :cond_5
    :goto_3
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    return-object v0
.end method

.method private final g(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 6
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->e:Ljava/util/Set;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    if-eqz v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    check-cast v1, Lcom/google/android/gms/common/api/internal/q3;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    sget-object v2, Lcom/google/android/gms/common/ConnectionResult;->C:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p1, v2}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-interface {v2}, Lcom/google/android/gms/common/api/a$f;->getEndpointPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v2, 0x0

    :goto_1
    const/4 v5, 0x6

    iget-object v3, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, v3, p1, v2}, Lcom/google/android/gms/common/api/internal/q3;->c(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/String;)V

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->e:Ljava/util/Set;

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {p1}, Ljava/util/Set;->clear()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-void
.end method

.method private final h(Lcom/google/android/gms/common/api/Status;)V
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x4

    move v2, v0

    move v2, v0

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0, p1, v0, v1}, Lcom/google/android/gms/common/api/internal/v1;->i(Lcom/google/android/gms/common/api/Status;Ljava/lang/Exception;Z)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method private final i(Lcom/google/android/gms/common/api/Status;Ljava/lang/Exception;Z)V
    .locals 6
    .param p1    # Lcom/google/android/gms/common/api/Status;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Exception;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v5, 0x4

    const/4 v0, 0x0

    and-int/2addr v4, v0

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz p1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    move v2, v0

    const/4 v5, 0x1

    move v2, v0

    move v2, v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz p2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    move v0, v1

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eq v2, v0, :cond_6

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->a:Ljava/util/Queue;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_2
    :goto_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v1, :cond_5

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast v1, Lcom/google/android/gms/common/api/internal/n3;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz p3, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget v2, v1, Lcom/google/android/gms/common/api/internal/n3;->a:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v3, 0x2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-ne v2, v3, :cond_2

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz p1, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1, p1}, Lcom/google/android/gms/common/api/internal/n3;->a(Lcom/google/android/gms/common/api/Status;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_3

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v1, p2}, Lcom/google/android/gms/common/api/internal/n3;->b(Ljava/lang/Exception;)V

    :goto_3
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_2

    :cond_5
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-void

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo p2, "suomlu ltxl uRa cdpns eiso ttbehSnO"

    const-string p2, "Rns eotelcui lhSleOsbon td xpuast u"

    const/4 v5, 0x0

    const-string p2, "Rstloetedu obOulx ph taS enl iousnc"

    const-string p2, "Status XOR exception should be null"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    throw p1
.end method

.method private final j()V
    .locals 7
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->a:Ljava/util/Queue;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v6, 0x0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x6

    if-ge v2, v1, :cond_2

    const/4 v6, 0x2

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast v3, Lcom/google/android/gms/common/api/internal/n3;

    const/4 v6, 0x5

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {v4}, Lcom/google/android/gms/common/api/a$f;->isConnected()Z

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-nez v4, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_1

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {p0, v3}, Lcom/google/android/gms/common/api/internal/v1;->p(Lcom/google/android/gms/common/api/internal/n3;)Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v4, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/v1;->a:Ljava/util/Queue;

    const/4 v5, 0x2

    move v6, v5

    invoke-interface {v4, v3}, Ljava/util/Collection;->remove(Ljava/lang/Object;)Z

    :cond_1
    const/4 v5, 0x4

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-void
.end method

.method private final k()V
    .locals 6
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/v1;->E()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    sget-object v0, Lcom/google/android/gms/common/ConnectionResult;->C:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/v1;->g(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/v1;->o()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->f:Ljava/util/Map;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    check-cast v1, Lcom/google/android/gms/common/api/internal/n2;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v2, v1, Lcom/google/android/gms/common/api/internal/n2;->a:Lcom/google/android/gms/common/api/internal/t;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v2}, Lcom/google/android/gms/common/api/internal/t;->c()[Lcom/google/android/gms/common/Feature;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p0, v2}, Lcom/google/android/gms/common/api/internal/v1;->f([Lcom/google/android/gms/common/Feature;)Lcom/google/android/gms/common/Feature;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v2, :cond_0

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, v1, Lcom/google/android/gms/common/api/internal/n2;->a:Lcom/google/android/gms/common/api/internal/t;

    const/4 v5, 0x7

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v4, 0x5

    move v5, v4

    new-instance v3, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {v3}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1, v2, v3}, Lcom/google/android/gms/common/api/internal/t;->d(Lcom/google/android/gms/common/api/a$b;Lcom/google/android/gms/tasks/TaskCompletionSource;)V
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    goto :goto_0

    :catch_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :catch_1
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v0, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/api/internal/v1;->b(I)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const-string v1, "de htbhrentO wn jscrwgaiiimtiDalsioelErr oeelgelm ct .ohentbetnpcd"

    const-string/jumbo v1, "lmcm isthr.OoendldleDnwghogi cwasiei het trrEipa entneojlrceebtt e"

    const/4 v5, 0x0

    const-string/jumbo v1, "o.srtcueidelthbgieEnhsh onea rjnewxarwnDedmilgltOcttc e rloipe tei"

    const-string v1, "DeadObjectException thrown while calling register listener method."

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-interface {v0, v1}, Lcom/google/android/gms/common/api/a$f;->disconnect(Ljava/lang/String;)V

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/v1;->j()V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/v1;->m()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-void
.end method

.method private final l(I)V
    .locals 6
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/v1;->E()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v0, 0x1

    move v5, v0

    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput-boolean v0, p0, Lcom/google/android/gms/common/api/internal/v1;->i:Z

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v0}, Lcom/google/android/gms/common/api/a$f;->getLastDisconnectMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->d:Lcom/google/android/gms/common/api/internal/h0;

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {v1, p1, v0}, Lcom/google/android/gms/common/api/internal/h0;->e(ILjava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/16 v2, 0x9

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v0, v2, p1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-wide/16 v2, 0x1388

    const-wide/16 v2, 0x1388

    const/4 v5, 0x3

    const-wide/16 v2, 0x1388

    const-wide/16 v2, 0x1388

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1, p1, v2, v3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/16 v2, 0xb

    const/4 v5, 0x5

    invoke-static {v0, v2, p1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-wide/32 v2, 0x1d4c0

    const-wide/32 v2, 0x1d4c0

    const/4 v5, 0x3

    const-wide/32 v2, 0x1d4c0

    const-wide/32 v2, 0x1d4c0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1, p1, v2, v3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->w(Lcom/google/android/gms/common/api/internal/i;)Lcom/google/android/gms/common/internal/t0;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/t0;->c()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->f:Ljava/util/Map;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {p1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    check-cast v0, Lcom/google/android/gms/common/api/internal/n2;

    const/4 v4, 0x7

    move v5, v4

    iget-object v0, v0, Lcom/google/android/gms/common/api/internal/n2;->c:Ljava/lang/Runnable;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    return-void
.end method

.method private final m()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/16 v2, 0xc

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v0}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1, v2, v0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/i;->m(Lcom/google/android/gms/common/api/internal/i;)J

    move-result-wide v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v3, v0, v1, v2}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void
.end method

.method private final n(Lcom/google/android/gms/common/api/internal/n3;)V
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->d:Lcom/google/android/gms/common/api/internal/h0;

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/v1;->d()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Lcom/google/android/gms/common/api/internal/n3;->d(Lcom/google/android/gms/common/api/internal/h0;Z)V

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1, p0}, Lcom/google/android/gms/common/api/internal/n3;->c(Lcom/google/android/gms/common/api/internal/v1;)V
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void

    :catch_0
    const/4 v3, 0x7

    const/4 p1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->b(I)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v3, 0x6

    const-string v0, "boo tglpeoAraeir hjnlrinuwEDlxdthepni.eCc OnuninRntw ca"

    const-string/jumbo v0, "npcnooliaeeiRnwd wujhCrrhoc.ti ntnrEne ugxtDll neAObaip"

    const/4 v3, 0x1

    const-string/jumbo v0, "iaronup.qoxurne eiabnj nhtleCAg DeREtcdnntiwlreOphclnw "

    const-string v0, "DeadObjectException thrown while running ApiCallRunner."

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {p1, v0}, Lcom/google/android/gms/common/api/a$f;->disconnect(Ljava/lang/String;)V

    const/4 v3, 0x1

    return-void
.end method

.method private final o()V
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-boolean v0, p0, Lcom/google/android/gms/common/api/internal/v1;->i:Z

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/16 v2, 0xb

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v1}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/16 v2, 0x9

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v2, v1}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput-boolean v0, p0, Lcom/google/android/gms/common/api/internal/v1;->i:Z

    :cond_0
    const/4 v4, 0x0

    return-void
.end method

.method private final p(Lcom/google/android/gms/common/api/internal/n3;)Z
    .locals 9
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    instance-of v0, p1, Lcom/google/android/gms/common/api/internal/e2;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 v1, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-nez v0, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->n(Lcom/google/android/gms/common/api/internal/n3;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    return v1

    :cond_0
    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    check-cast v0, Lcom/google/android/gms/common/api/internal/e2;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/api/internal/e2;->g(Lcom/google/android/gms/common/api/internal/v1;)[Lcom/google/android/gms/common/Feature;

    move-result-object v2

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {p0, v2}, Lcom/google/android/gms/common/api/internal/v1;->f([Lcom/google/android/gms/common/Feature;)Lcom/google/android/gms/common/Feature;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-nez v2, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->n(Lcom/google/android/gms/common/api/internal/n3;)V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    return v1

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v7, 0x3

    move v8, v7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v2}, Lcom/google/android/gms/common/Feature;->y2()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v2}, Lcom/google/android/gms/common/Feature;->z2()J

    move-result-wide v4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string/jumbo p1, "tosieasccrcsueedibo  t n cebetqu a  euurleua(ete  frx"

    const-string/jumbo p1, "teu nbuuet  acidbou(eefeeue elrqc sr t ea rxloasct ic"

    const/4 v8, 0x3

    const-string p1, " could not execute call because it requires feature ("

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-string p1, ", "

    const-string p1, ", "

    const/4 v8, 0x4

    const-string p1, ", "

    const-string p1, ", "

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v6, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string p1, ")."

    const-string p1, ")."

    const/4 v8, 0x5

    const-string p1, ".)"

    const-string p1, ")."

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x1

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-string v3, "eGamAgnloopigMua"

    const-string/jumbo v3, "lGAapougagMneieo"

    const/4 v8, 0x6

    const-string v3, "agalogeAGoioeMnr"

    const-string v3, "GoogleApiManager"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v3, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->d(Lcom/google/android/gms/common/api/internal/i;)Z

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz p1, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/api/internal/e2;->f(Lcom/google/android/gms/common/api/internal/v1;)Z

    move-result p1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-eqz p1, :cond_4

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-instance v0, Lcom/google/android/gms/common/api/internal/x1;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/4 v1, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-direct {v0, p1, v2, v1}, Lcom/google/android/gms/common/api/internal/x1;-><init>(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/Feature;Lcom/google/android/gms/common/api/internal/w1;)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->j:Ljava/util/List;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result p1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-wide/16 v2, 0x1388

    const-wide/16 v2, 0x1388

    const/4 v8, 0x3

    const-wide/16 v2, 0x1388

    const-wide/16 v2, 0x1388

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/16 v4, 0xf

    const/4 v8, 0x2

    if-ltz p1, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->j:Ljava/util/List;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    check-cast p1, Lcom/google/android/gms/common/api/internal/x1;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v0, v4, p1}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x2

    invoke-static {v0, v4, p1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v1, p1, v2, v3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    goto/16 :goto_0

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->j:Ljava/util/List;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {p1, v4, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v5, p1, v2, v3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/16 v3, 0x10

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {p1, v3, v0}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-wide/32 v3, 0x1d4c0

    const-wide/32 v3, 0x1d4c0

    const/4 v8, 0x3

    const-wide/32 v3, 0x1d4c0

    const-wide/32 v3, 0x1d4c0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v2, p1, v3, v4}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-instance p1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v8, 0x0

    const/4 v0, 0x2

    const/4 v8, 0x1

    move v7, v0

    move v7, v0

    const/4 v8, 0x5

    invoke-direct {p1, v0, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->q(Lcom/google/android/gms/common/ConnectionResult;)Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-nez v0, :cond_3

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v8, 0x6

    iget v1, p0, Lcom/google/android/gms/common/api/internal/v1;->g:I

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0, p1, v1}, Lcom/google/android/gms/common/api/internal/i;->f(Lcom/google/android/gms/common/ConnectionResult;I)Z

    :cond_3
    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 p1, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    return p1

    :cond_4
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-instance p1, Lcom/google/android/gms/common/api/a0;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-direct {p1, v2}, Lcom/google/android/gms/common/api/a0;-><init>(Lcom/google/android/gms/common/Feature;)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/api/internal/n3;->b(Ljava/lang/Exception;)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    return v1
.end method

.method private final q(Lcom/google/android/gms/common/ConnectionResult;)Z
    .locals 5
    .param p1    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/android/gms/common/api/internal/i;->B()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/i;->s(Lcom/google/android/gms/common/api/internal/i;)Lcom/google/android/gms/common/api/internal/i0;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/i;->D(Lcom/google/android/gms/common/api/internal/i;)Ljava/util/Set;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {v1, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/i;->s(Lcom/google/android/gms/common/api/internal/i;)Lcom/google/android/gms/common/api/internal/i0;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v2, p0, Lcom/google/android/gms/common/api/internal/v1;->g:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, p1, v2}, Lcom/google/android/gms/common/api/internal/u3;->h(Lcom/google/android/gms/common/ConnectionResult;I)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 p1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x6

    return p1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x4

    move v4, v3

    return p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    throw p1
.end method

.method private final r(Z)Z
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0}, Lcom/google/android/gms/common/api/a$f;->isConnected()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->f:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->d:Lcom/google/android/gms/common/api/internal/h0;

    const/4 v1, 0x3

    and-int/2addr v2, v1

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/h0;->g()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    if-eqz p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/v1;->m()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string/jumbo v0, "occmobinrnve Teit  .gsutpincio"

    const-string/jumbo v0, "iinrgtnpe mn. ooe tncTucoisicv"

    const/4 v2, 0x5

    const-string/jumbo v0, "onmsnructeenngo iotcTiu e.icv "

    const-string v0, "Timing out service connection."

    const/4 v2, 0x1

    invoke-interface {p1, v0}, Lcom/google/android/gms/common/api/a$f;->disconnect(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x1

    and-int/2addr v1, p1

    const/4 v2, 0x1

    return p1

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p1
.end method

.method static bridge synthetic v(Lcom/google/android/gms/common/api/internal/v1;)Lcom/google/android/gms/common/api/a$f;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method static bridge synthetic x(Lcom/google/android/gms/common/api/internal/v1;)Lcom/google/android/gms/common/api/internal/c;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v1, 0x3

    return-object p0
.end method

.method static bridge synthetic z(Lcom/google/android/gms/common/api/internal/v1;Lcom/google/android/gms/common/api/Status;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->h(Lcom/google/android/gms/common/api/Status;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final E()V
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->k:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v2, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public final F()V
    .locals 10
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v9, 0x4

    const/4 v8, 0x7

    invoke-interface {v0}, Lcom/google/android/gms/common/api/a$f;->isConnected()Z

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-nez v0, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v9, 0x7

    const/4 v8, 0x5

    invoke-interface {v0}, Lcom/google/android/gms/common/api/a$f;->isConnecting()Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-eqz v0, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto/16 :goto_0

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    const/16 v0, 0xa

    :try_start_0
    const/4 v9, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/i;->w(Lcom/google/android/gms/common/api/internal/i;)Lcom/google/android/gms/common/internal/t0;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/i;->n(Lcom/google/android/gms/common/api/internal/i;)Landroid/content/Context;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object v3, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v2, v1, v3}, Lcom/google/android/gms/common/internal/t0;->b(Landroid/content/Context;Lcom/google/android/gms/common/api/a$f;)I

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-eqz v1, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    new-instance v2, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v3, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-direct {v2, v1, v3}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string/jumbo v1, "ogMierApaepaonlg"

    const-string v1, "GoogleApiManager"

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    move v9, v8

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-string/jumbo v7, "h sTrveoqie qefr"

    const-string/jumbo v7, "vorefsreqi ceT h"

    const/4 v9, 0x6

    const-string/jumbo v7, "irseeT fr se coh"

    const-string v7, "The service for "

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string/jumbo v4, "slvmiso nbla aet a "

    const-string v4, ":osnaabt llia ve s "

    const/4 v9, 0x2

    const-string v4, "ain o vi llastae: o"

    const-string v4, " is not available: "

    const/4 v8, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {v1, v4}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x5

    or-int/2addr v9, v8

    invoke-virtual {p0, v2, v3}, Lcom/google/android/gms/common/api/internal/v1;->I(Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/Exception;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    return-void

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v3, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v8, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    new-instance v4, Lcom/google/android/gms/common/api/internal/z1;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-direct {v4, v1, v2, v3}, Lcom/google/android/gms/common/api/internal/z1;-><init>(Lcom/google/android/gms/common/api/internal/i;Lcom/google/android/gms/common/api/a$f;Lcom/google/android/gms/common/api/internal/c;)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    invoke-interface {v2}, Lcom/google/android/gms/common/api/a$f;->requiresSignIn()Z

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-eqz v1, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->h:Lcom/google/android/gms/common/api/internal/y2;

    const/4 v9, 0x5

    const/4 v8, 0x1

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    check-cast v1, Lcom/google/android/gms/common/api/internal/y2;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v1, v4}, Lcom/google/android/gms/common/api/internal/y2;->q0(Lcom/google/android/gms/common/api/internal/x2;)V

    :cond_2
    :try_start_1
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-interface {v1, v4}, Lcom/google/android/gms/common/api/a$f;->connect(Lcom/google/android/gms/common/internal/e$c;)V
    :try_end_1
    .catch Ljava/lang/SecurityException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    return-void

    :catch_0
    move-exception v1

    const/4 v9, 0x3

    const/4 v8, 0x1

    new-instance v2, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-direct {v2, v0}, Lcom/google/android/gms/common/ConnectionResult;-><init>(I)V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p0, v2, v1}, Lcom/google/android/gms/common/api/internal/v1;->I(Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/Exception;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    return-void

    :catch_1
    move-exception v1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    new-instance v2, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-direct {v2, v0}, Lcom/google/android/gms/common/ConnectionResult;-><init>(I)V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p0, v2, v1}, Lcom/google/android/gms/common/api/internal/v1;->I(Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/Exception;)V

    :cond_3
    :goto_0
    const/4 v8, 0x5

    move v9, v8

    return-void
.end method

.method public final G(Lcom/google/android/gms/common/api/internal/n3;)V
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v1, 0x5

    shr-int/2addr v2, v1

    invoke-interface {v0}, Lcom/google/android/gms/common/api/a$f;->isConnected()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->p(Lcom/google/android/gms/common/api/internal/n3;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/v1;->m()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->a:Ljava/util/Queue;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Ljava/util/Queue;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->a:Ljava/util/Queue;

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-interface {v0, p1}, Ljava/util/Queue;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->k:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz p1, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/common/ConnectionResult;->B2()Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz p1, :cond_2

    const/4 v1, 0x2

    and-int/2addr v2, v1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->k:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/android/gms/common/api/internal/v1;->I(Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/Exception;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void

    :cond_2
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/v1;->F()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method final H()V
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/gms/common/api/internal/v1;->l:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/gms/common/api/internal/v1;->l:I

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method

.method public final I(Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/Exception;)V
    .locals 7
    .param p1    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Exception;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->h:Lcom/google/android/gms/common/api/internal/y2;

    const/4 v6, 0x2

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/y2;->r0()V

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/v1;->E()V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->w(Lcom/google/android/gms/common/api/internal/i;)Lcom/google/android/gms/common/internal/t0;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/t0;->c()V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->g(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    instance-of v0, v0, Lcom/google/android/gms/common/internal/service/q;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/16 v2, 0x18

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eq v0, v2, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v0, v1}, Lcom/google/android/gms/common/api/internal/i;->E(Lcom/google/android/gms/common/api/internal/i;Z)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/16 v3, 0x13

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-wide/32 v3, 0x493e0

    const/4 v6, 0x7

    const-wide/32 v3, 0x493e0

    const-wide/32 v3, 0x493e0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v2, v0, v3, v4}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/4 v2, 0x4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-ne v0, v2, :cond_2

    const/4 v6, 0x6

    invoke-static {}, Lcom/google/android/gms/common/api/internal/i;->q()Lcom/google/android/gms/common/api/Status;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->h(Lcom/google/android/gms/common/api/Status;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-void

    :cond_2
    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->a:Ljava/util/Queue;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v0, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->k:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-void

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v0, 0x0

    move v6, v0

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz p2, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object p1

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 p1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {p0, v0, p2, p1}, Lcom/google/android/gms/common/api/internal/v1;->i(Lcom/google/android/gms/common/api/Status;Ljava/lang/Exception;Z)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-void

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {p2}, Lcom/google/android/gms/common/api/internal/i;->d(Lcom/google/android/gms/common/api/internal/i;)Z

    move-result p2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz p2, :cond_9

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p2, p1}, Lcom/google/android/gms/common/api/internal/i;->r(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;)Lcom/google/android/gms/common/api/Status;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {p0, p2, v0, v1}, Lcom/google/android/gms/common/api/internal/v1;->i(Lcom/google/android/gms/common/api/Status;Ljava/lang/Exception;Z)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/v1;->a:Ljava/util/Queue;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {p2}, Ljava/util/Collection;->isEmpty()Z

    move-result p2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz p2, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_5
    const/4 v5, 0x6

    move v6, v5

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->q(Lcom/google/android/gms/common/ConnectionResult;)Z

    move-result p2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-nez p2, :cond_8

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget v0, p0, Lcom/google/android/gms/common/api/internal/v1;->g:I

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p2, p1, v0}, Lcom/google/android/gms/common/api/internal/i;->f(Lcom/google/android/gms/common/ConnectionResult;I)Z

    move-result p2

    const/4 v6, 0x3

    const/4 v5, 0x6

    if-nez p2, :cond_8

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result p2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/16 v0, 0x12

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-ne p2, v0, :cond_6

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    iput-boolean v1, p0, Lcom/google/android/gms/common/api/internal/v1;->i:Z

    :cond_6
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-boolean p2, p0, Lcom/google/android/gms/common/api/internal/v1;->i:Z

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz p2, :cond_7

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/16 v1, 0x9

    const/4 v5, 0x2

    move v6, v5

    invoke-static {p1, v1, p2}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-wide/16 v1, 0x1388

    const-wide/16 v1, 0x1388

    const/4 v6, 0x3

    const-wide/16 v1, 0x1388

    const-wide/16 v1, 0x1388

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0, p1, v1, v2}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-void

    :cond_7
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p2, p1}, Lcom/google/android/gms/common/api/internal/i;->r(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;)Lcom/google/android/gms/common/api/Status;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->h(Lcom/google/android/gms/common/api/Status;)V

    :cond_8
    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-void

    :cond_9
    const/4 v5, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/v1;->c:Lcom/google/android/gms/common/api/internal/c;

    const/4 v6, 0x0

    invoke-static {p2, p1}, Lcom/google/android/gms/common/api/internal/i;->r(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;)Lcom/google/android/gms/common/api/Status;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->h(Lcom/google/android/gms/common/api/Status;)V

    const/4 v6, 0x0

    return-void
.end method

.method public final J(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 7
    .param p1    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v4, "fI Sgbole mniFinndr"

    const-string v4, " fFmadgeioSriln Inn"

    const/4 v6, 0x0

    const-string/jumbo v4, "lnFoeiuS ign Infdor"

    const-string/jumbo v4, "onSignInFailed for "

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string/jumbo v1, "tp wih"

    const-string v1, " iwhot"

    const/4 v6, 0x5

    const-string/jumbo v1, "tiqhw "

    const-string v1, " with "

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-interface {v0, v1}, Lcom/google/android/gms/common/api/a$f;->disconnect(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v0, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/android/gms/common/api/internal/v1;->I(Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/Exception;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-void
.end method

.method public final K(Lcom/google/android/gms/common/api/internal/q3;)V
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->e:Ljava/util/Set;

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public final L()V
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v1, 0x2

    and-int/2addr v2, v1

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/gms/common/api/internal/v1;->i:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/v1;->F()V

    :cond_0
    const/4 v2, 0x0

    return-void
.end method

.method public final M()V
    .locals 8
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    sget-object v0, Lcom/google/android/gms/common/api/internal/i;->r:Lcom/google/android/gms/common/api/Status;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/v1;->h(Lcom/google/android/gms/common/api/Status;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->d:Lcom/google/android/gms/common/api/internal/h0;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/h0;->f()V

    const/4 v7, 0x4

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->f:Ljava/util/Map;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    new-array v2, v1, [Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {v0, v2}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    check-cast v0, [Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    array-length v2, v0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-ge v1, v2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    aget-object v3, v0, v1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-instance v4, Lcom/google/android/gms/common/api/internal/m3;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-instance v5, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v7, 0x6

    const/4 v6, 0x3

    invoke-direct {v5}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    const/4 v7, 0x0

    invoke-direct {v4, v3, v5}, Lcom/google/android/gms/common/api/internal/m3;-><init>(Lcom/google/android/gms/common/api/internal/n$a;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0, v4}, Lcom/google/android/gms/common/api/internal/v1;->G(Lcom/google/android/gms/common/api/internal/n3;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x2

    new-instance v0, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/4 v1, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(I)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/v1;->g(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v7, 0x1

    const/4 v6, 0x3

    invoke-interface {v0}, Lcom/google/android/gms/common/api/a$f;->isConnected()Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v0, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    new-instance v1, Lcom/google/android/gms/common/api/internal/u1;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {v1, p0}, Lcom/google/android/gms/common/api/internal/u1;-><init>(Lcom/google/android/gms/common/api/internal/v1;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-interface {v0, v1}, Lcom/google/android/gms/common/api/a$f;->onUserSignOut(Lcom/google/android/gms/common/internal/e$e;)V

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    return-void
.end method

.method public final N()V
    .locals 5
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-boolean v0, p0, Lcom/google/android/gms/common/api/internal/v1;->i:Z

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/v1;->o()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->p(Lcom/google/android/gms/common/api/internal/i;)Lcom/google/android/gms/common/f;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->n(Lcom/google/android/gms/common/api/internal/i;)Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/f;->j(Landroid/content/Context;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/16 v1, 0x12

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-ne v0, v1, :cond_0

    const/4 v4, 0x6

    new-instance v0, Lcom/google/android/gms/common/api/Status;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/16 v1, 0x15

    const/4 v4, 0x0

    const-string/jumbo v2, "fisnnt aege.paovsucol  codtoinseletgltomiecdiarp P wCbotme nr   ouot eyGe"

    const-string v2, " itp baoCceoptant Pioimt lnceruroGfs.o   lmteweo l c eneaogyuneddsttvgoei"

    const/4 v4, 0x7

    const-string/jumbo v2, "t pmoa ntnlatlouiendnum  sgo v ep.iiPcGemooeesgteC  tctrieir dteofolwoac "

    const-string v2, "Connection timed out waiting for Google Play services update to complete."

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    new-instance v0, Lcom/google/android/gms/common/api/Status;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/16 v1, 0x16

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v2, "lou oe. twnuIgoAnwlootP   idn ermnrihcsfn  taor eneaekeuri nc"

    const-string v2, "API failed to connect while resuming due to an unknown error."

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/v1;->h(Lcom/google/android/gms/common/api/Status;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v1, " gi ubsrTnul it.cncw tigeonnemniohium"

    const-string v1, " c.ieguncwol Termni snntiiiugnet uhmo"

    const/4 v4, 0x3

    const-string/jumbo v1, "ooiwTtu.mgr nc iinshuunmieoni eg nect"

    const-string v1, "Timing out connection while resuming."

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {v0, v1}, Lcom/google/android/gms/common/api/a$f;->disconnect(Ljava/lang/String;)V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method

.method final Q()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0}, Lcom/google/android/gms/common/api/a$f;->isConnected()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public final X(Lcom/google/android/gms/common/ConnectionResult;Lcom/google/android/gms/common/api/a;Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    throw p1
.end method

.method public final a(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-ne v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/v1;->k()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/gms/common/api/internal/r1;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/api/internal/r1;-><init>(Lcom/google/android/gms/common/api/internal/v1;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public final b(I)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    if-ne v1, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/v1;->l(I)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v1, Lcom/google/android/gms/common/api/internal/s1;

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    invoke-direct {v1, p0, p1}, Lcom/google/android/gms/common/api/internal/s1;-><init>(Lcom/google/android/gms/common/api/internal/v1;I)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v3, 0x7

    return-void
.end method

.method public final c(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/google/android/gms/common/api/internal/v1;->I(Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/Exception;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public final d()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {v0}, Lcom/google/android/gms/common/api/a$f;->requiresSignIn()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    return v0
.end method

.method public final e()Z
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/v1;->r(Z)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public final s()I
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/gms/common/api/internal/v1;->g:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method final t()I
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/gms/common/api/internal/v1;->l:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method public final u()Lcom/google/android/gms/common/ConnectionResult;
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->m:Lcom/google/android/gms/common/api/internal/i;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/i;->o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->h(Landroid/os/Handler;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->k:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public final w()Lcom/google/android/gms/common/api/a$f;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->b:Lcom/google/android/gms/common/api/a$f;

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-object v0
.end method

.method public final y()Ljava/util/Map;
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v1;->f:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method
