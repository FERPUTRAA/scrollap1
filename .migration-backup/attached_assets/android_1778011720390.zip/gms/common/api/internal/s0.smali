.class final Lcom/google/android/gms/common/api/internal/s0;
.super Lcom/google/android/gms/common/api/internal/z0;


# instance fields
.field private final b:Ljava/util/Map;

.field final synthetic c:Lcom/google/android/gms/common/api/internal/a1;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/internal/a1;Ljava/util/Map;)V
    .locals 3

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/s0;->c:Lcom/google/android/gms/common/api/internal/a1;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/api/internal/z0;-><init>(Lcom/google/android/gms/common/api/internal/a1;Lcom/google/android/gms/common/api/internal/y0;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/s0;->b:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 8
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/s0;->c:Lcom/google/android/gms/common/api/internal/a1;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    new-instance v1, Lcom/google/android/gms/common/internal/t0;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->t(Lcom/google/android/gms/common/api/internal/a1;)Lcom/google/android/gms/common/g;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v1, v0}, Lcom/google/android/gms/common/internal/t0;-><init>(Lcom/google/android/gms/common/g;)V

    const/4 v7, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    new-instance v2, Ljava/util/ArrayList;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/google/android/gms/common/api/internal/s0;->b:Ljava/util/Map;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-interface {v3}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz v4, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    check-cast v4, Lcom/google/android/gms/common/api/a$f;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-interface {v4}, Lcom/google/android/gms/common/api/a$f;->requiresGooglePlayServices()Z

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eqz v5, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v5, p0, Lcom/google/android/gms/common/api/internal/s0;->b:Ljava/util/Map;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-interface {v5, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    check-cast v5, Lcom/google/android/gms/common/api/internal/p0;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {v5}, Lcom/google/android/gms/common/api/internal/p0;->b(Lcom/google/android/gms/common/api/internal/p0;)Z

    move-result v5

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-nez v5, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {v2, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto :goto_0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v4, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 v5, -0x1

    const/4 v7, 0x2

    if-eqz v3, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v0

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-ge v4, v0, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    check-cast v3, Lcom/google/android/gms/common/api/a$f;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v5, p0, Lcom/google/android/gms/common/api/internal/s0;->c:Lcom/google/android/gms/common/api/internal/a1;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v5}, Lcom/google/android/gms/common/api/internal/a1;->s(Lcom/google/android/gms/common/api/internal/a1;)Landroid/content/Context;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v1, v5, v3}, Lcom/google/android/gms/common/internal/t0;->b(Landroid/content/Context;Lcom/google/android/gms/common/api/a$f;)I

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-nez v5, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    goto :goto_1

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-ge v4, v2, :cond_5

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    check-cast v3, Lcom/google/android/gms/common/api/a$f;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v5, p0, Lcom/google/android/gms/common/api/internal/s0;->c:Lcom/google/android/gms/common/api/internal/a1;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v5}, Lcom/google/android/gms/common/api/internal/a1;->s(Lcom/google/android/gms/common/api/internal/a1;)Landroid/content/Context;

    move-result-object v5

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v1, v5, v3}, Lcom/google/android/gms/common/internal/t0;->b(Landroid/content/Context;Lcom/google/android/gms/common/api/a$f;)I

    move-result v5

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v5, :cond_4

    :cond_5
    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz v5, :cond_6

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    new-instance v0, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-direct {v0, v5, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/s0;->c:Lcom/google/android/gms/common/api/internal/a1;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {v1}, Lcom/google/android/gms/common/api/internal/a1;->u(Lcom/google/android/gms/common/api/internal/a1;)Lcom/google/android/gms/common/api/internal/n1;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v3, Lcom/google/android/gms/common/api/internal/q0;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-direct {v3, p0, v1, v0}, Lcom/google/android/gms/common/api/internal/q0;-><init>(Lcom/google/android/gms/common/api/internal/s0;Lcom/google/android/gms/common/api/internal/k1;Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v2, v3}, Lcom/google/android/gms/common/api/internal/n1;->u(Lcom/google/android/gms/common/api/internal/l1;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    return-void

    :cond_6
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/s0;->c:Lcom/google/android/gms/common/api/internal/a1;

    const/4 v7, 0x3

    const/4 v6, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->F(Lcom/google/android/gms/common/api/internal/a1;)Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v2, :cond_7

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->x(Lcom/google/android/gms/common/api/internal/a1;)Lcom/google/android/gms/signin/f;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v2, :cond_7

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->x(Lcom/google/android/gms/common/api/internal/a1;)Lcom/google/android/gms/signin/f;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-interface {v0}, Lcom/google/android/gms/signin/f;->e()V

    :cond_7
    const/4 v7, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/s0;->b:Ljava/util/Map;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x0

    if-eqz v2, :cond_9

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    check-cast v2, Lcom/google/android/gms/common/api/a$f;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object v3, p0, Lcom/google/android/gms/common/api/internal/s0;->b:Ljava/util/Map;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    check-cast v3, Lcom/google/android/gms/common/internal/e$c;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-interface {v2}, Lcom/google/android/gms/common/api/a$f;->requiresGooglePlayServices()Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eqz v4, :cond_8

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/s0;->c:Lcom/google/android/gms/common/api/internal/a1;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {v4}, Lcom/google/android/gms/common/api/internal/a1;->s(Lcom/google/android/gms/common/api/internal/a1;)Landroid/content/Context;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v1, v4, v2}, Lcom/google/android/gms/common/internal/t0;->b(Landroid/content/Context;Lcom/google/android/gms/common/api/a$f;)I

    move-result v4

    const/4 v7, 0x3

    if-eqz v4, :cond_8

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/s0;->c:Lcom/google/android/gms/common/api/internal/a1;

    const/4 v7, 0x4

    invoke-static {v2}, Lcom/google/android/gms/common/api/internal/a1;->u(Lcom/google/android/gms/common/api/internal/a1;)Lcom/google/android/gms/common/api/internal/n1;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    new-instance v5, Lcom/google/android/gms/common/api/internal/r0;

    const/4 v6, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-direct {v5, p0, v2, v3}, Lcom/google/android/gms/common/api/internal/r0;-><init>(Lcom/google/android/gms/common/api/internal/s0;Lcom/google/android/gms/common/api/internal/k1;Lcom/google/android/gms/common/internal/e$c;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Lcom/google/android/gms/common/api/internal/n1;->u(Lcom/google/android/gms/common/api/internal/l1;)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto :goto_2

    :cond_8
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-interface {v2, v3}, Lcom/google/android/gms/common/api/a$f;->connect(Lcom/google/android/gms/common/internal/e$c;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_2

    :cond_9
    const/4 v6, 0x1

    const/4 v7, 0x1

    return-void
.end method
