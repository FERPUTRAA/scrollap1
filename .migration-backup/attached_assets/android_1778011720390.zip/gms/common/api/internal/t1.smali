.class final Lcom/google/android/gms/common/api/internal/t1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/api/internal/u1;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/u1;)V
    .locals 2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/t1;->a:Lcom/google/android/gms/common/api/internal/u1;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@@s~@@ lf@~~ ~l fab@~~~@ ~ @~4@.c~~tinm@yo~@@ u o/~ts/~~@ K@~o~@ ~  S ~r v@  ob~Mooi-@~@b@@  1id"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/t1;->a:Lcom/google/android/gms/common/api/internal/u1;

    const/4 v4, 0x7

    iget-object v0, v0, Lcom/google/android/gms/common/api/internal/u1;->a:Lcom/google/android/gms/common/api/internal/v1;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/v1;->v(Lcom/google/android/gms/common/api/internal/v1;)Lcom/google/android/gms/common/api/a$f;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/v1;->v(Lcom/google/android/gms/common/api/internal/v1;)Lcom/google/android/gms/common/api/a$f;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo v2, "t  mddscotsi usgibec.sast  gcownnini neee"

    const-string v2, "dssgn.gss iotticiawnd  ennu stiecce oeb a"

    const/4 v4, 0x2

    const-string v2, " baeogeec.t i dnssoicnntsoe idwtg a sniuc"

    const-string v2, " disconnecting because it was signed out."

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v1, v0}, Lcom/google/android/gms/common/api/a$f;->disconnect(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method
