.class public final Lcom/google/android/gms/common/api/internal/m2;
.super Ljava/lang/Object;


# instance fields
.field public final a:Lcom/google/android/gms/common/api/internal/n3;

.field public final b:I

.field public final c:Lcom/google/android/gms/common/api/k;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/internal/n3;ILcom/google/android/gms/common/api/k;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/m2;->a:Lcom/google/android/gms/common/api/internal/n3;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p2, p0, Lcom/google/android/gms/common/api/internal/m2;->b:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/google/android/gms/common/api/internal/m2;->c:Lcom/google/android/gms/common/api/k;

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method
