.class public Lcom/google/android/gms/common/api/internal/i;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final r:Lcom/google/android/gms/common/api/Status;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private static final s:Lcom/google/android/gms/common/api/Status;

.field private static final t:Ljava/lang/Object;

.field private static u:Lcom/google/android/gms/common/api/internal/i;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lz4/a;
        value = "lock"
    .end annotation
.end field


# instance fields
.field private a:J

.field private b:Z

.field private c:Lcom/google/android/gms/common/internal/TelemetryData;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private f:Lcom/google/android/gms/common/internal/c0;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final g:Landroid/content/Context;

.field private final h:Lcom/google/android/gms/common/f;

.field private final i:Lcom/google/android/gms/common/internal/t0;

.field private final j:Ljava/util/concurrent/atomic/AtomicInteger;

.field private final k:Ljava/util/concurrent/atomic/AtomicInteger;

.field private final l:Ljava/util/Map;

.field private m:Lcom/google/android/gms/common/api/internal/i0;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lz4/a;
        value = "lock"
    .end annotation
.end field

.field private final n:Ljava/util/Set;
    .annotation build Lz4/a;
        value = "lock"
    .end annotation
.end field

.field private final o:Ljava/util/Set;

.field private final p:Landroid/os/Handler;
    .annotation runtime Lm9/c;
    .end annotation
.end field

.field private volatile q:Z


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Lcom/google/android/gms/common/api/Status;

    const/4 v4, 0x7

    const/4 v1, 0x4

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string v2, "Iesr uPidcl g .hS nogr s eiAeosrwos- lilrithssuac awcn"

    const-string v2, ".ssenraruoAwhiudr-tlos SIPtl  igeewc sih r cgl  nasoci"

    const/4 v4, 0x0

    const-string/jumbo v2, "isum lgPIeo wt.u -nsswoencSi t lrcahigr a rdepicrh lsA"

    const-string v2, "Sign-out occurred while this API call was in progress."

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    sput-object v0, Lcom/google/android/gms/common/api/internal/i;->r:Lcom/google/android/gms/common/api/Status;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v0, Lcom/google/android/gms/common/api/Status;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v2, "oec o .sbT  i tmI elis husmunkilae  thnPsAeaedr m"

    const-string/jumbo v2, "sTemtkin ea oemg  hamPlbnessui dlh uIr.ctse A  i "

    const/4 v4, 0x5

    const-string v2, "b ssIb  ialehniA ee mmtut iaePgu nrl  s. eoTkshtc"

    const-string v2, "The user must be signed in to make this API call."

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    sput-object v0, Lcom/google/android/gms/common/api/internal/i;->s:Lcom/google/android/gms/common/api/Status;

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    sput-object v0, Lcom/google/android/gms/common/api/internal/i;->t:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/f;)V
    .locals 7
    .annotation build Lf4/a;
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x6

    move v6, v5

    const-wide/16 v0, 0x2710

    const-wide/16 v0, 0x2710

    const/4 v6, 0x0

    const-wide/16 v0, 0x2710

    const-wide/16 v0, 0x2710

    const/4 v6, 0x4

    const/4 v5, 0x0

    iput-wide v0, p0, Lcom/google/android/gms/common/api/internal/i;->a:J

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x5

    iput-boolean v0, p0, Lcom/google/android/gms/common/api/internal/i;->b:Z

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-instance v1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v6, 0x0

    iput-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->j:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x7

    const/4 v5, 0x0

    new-instance v1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {v1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    iput-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->k:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v1, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v3, 0x5

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/high16 v4, 0x3f400000    # 0.75f

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {v1, v3, v4, v2}, Ljava/util/concurrent/ConcurrentHashMap;-><init>(IFI)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    iput-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->m:Lcom/google/android/gms/common/api/internal/i0;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance v1, Landroidx/collection/c;

    const/4 v6, 0x1

    invoke-direct {v1}, Landroidx/collection/c;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    iput-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->n:Ljava/util/Set;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance v1, Landroidx/collection/c;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {v1}, Landroidx/collection/c;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    iput-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->o:Ljava/util/Set;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    iput-boolean v2, p0, Lcom/google/android/gms/common/api/internal/i;->q:Z

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->g:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v1, Lcom/google/android/gms/internal/base/zau;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {v1, p2, p0}, Lcom/google/android/gms/internal/base/zau;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    const/4 v6, 0x7

    iput-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v5, 0x5

    and-int/2addr v6, v5

    iput-object p3, p0, Lcom/google/android/gms/common/api/internal/i;->h:Lcom/google/android/gms/common/f;

    const/4 v6, 0x0

    const/4 v5, 0x6

    new-instance p2, Lcom/google/android/gms/common/internal/t0;

    const/4 v6, 0x0

    invoke-direct {p2, p3}, Lcom/google/android/gms/common/internal/t0;-><init>(Lcom/google/android/gms/common/g;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/i;->i:Lcom/google/android/gms/common/internal/t0;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/util/l;->a(Landroid/content/Context;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz p1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    iput-boolean v0, p0, Lcom/google/android/gms/common/api/internal/i;->q:Z

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 p1, 0x6

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v1, p1}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-void
.end method

.method static bridge synthetic B()Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@o  @lu@@ f@~o ~.@~1fs ~o@~c ~@~~odur @b~bm  ~K~S@y~@4@ @-~~ @  l~@ at~~b~  @M ~o~~t~/inovi/@i@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/common/api/internal/i;->t:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method static bridge synthetic C(Lcom/google/android/gms/common/api/internal/i;)Ljava/util/Map;
    .locals 2

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p0
.end method

.method static bridge synthetic D(Lcom/google/android/gms/common/api/internal/i;)Ljava/util/Set;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/i;->n:Ljava/util/Set;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method static bridge synthetic E(Lcom/google/android/gms/common/api/internal/i;Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/gms/common/api/internal/i;->b:Z

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public static a()V
    .locals 5
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    sget-object v0, Lcom/google/android/gms/common/api/internal/i;->t:Ljava/lang/Object;

    const/4 v4, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    sget-object v1, Lcom/google/android/gms/common/api/internal/i;->u:Lcom/google/android/gms/common/api/internal/i;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v2, v1, Lcom/google/android/gms/common/api/internal/i;->k:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v1, v1, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/16 v2, 0xa

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1, v2}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Landroid/os/Handler;->sendMessageAtFrontOfQueue(Landroid/os/Message;)Z

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    throw v1
.end method

.method static bridge synthetic d(Lcom/google/android/gms/common/api/internal/i;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iget-boolean p0, p0, Lcom/google/android/gms/common/api/internal/i;->q:Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    return p0
.end method

.method private static g(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;)Lcom/google/android/gms/common/api/Status;
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v0, Lcom/google/android/gms/common/api/Status;

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/c;->b()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v3, "A pPI"

    const-string v3, "PI Ao"

    const/4 v5, 0x1

    const-string v3, "I: qA"

    const-string v3, "API: "

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string p0, "dfsnioclevt atei ae t:abhhwa oid  obisn.lc nneevinosit  Ci"

    const-string/jumbo p0, "hs e b haiaoveotdnica nCitwsbetit:.  noc enn ledii vliofa "

    const/4 v5, 0x0

    const-string p0, ": emiiie  otvol.vic Ctdiw nson lhfa  endliate baact einohn"

    const-string p0, " is not available on this device. Connection failed with: "

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-direct {v0, p1, p0}, Lcom/google/android/gms/common/api/Status;-><init>(Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/String;)V

    const/4 v5, 0x7

    return-object v0
.end method

.method private final h(Lcom/google/android/gms/common/api/k;)Lcom/google/android/gms/common/api/internal/v1;
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/k;->getApiKey()Lcom/google/android/gms/common/api/internal/c;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    check-cast v0, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/api/internal/v1;-><init>(Lcom/google/android/gms/common/api/internal/i;Lcom/google/android/gms/common/api/k;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {p1, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/v1;->d()Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->o:Ljava/util/Set;

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-interface {p1, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/v1;->F()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0
.end method

.method private final i()Lcom/google/android/gms/common/internal/c0;
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->f:Lcom/google/android/gms/common/internal/c0;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->g:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/b0;->a(Landroid/content/Context;)Lcom/google/android/gms/common/internal/c0;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->f:Lcom/google/android/gms/common/internal/c0;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->f:Lcom/google/android/gms/common/internal/c0;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method private final j()V
    .locals 4
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->c:Lcom/google/android/gms/common/internal/TelemetryData;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/TelemetryData;->d()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-gtz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/i;->e()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/i;->i()Lcom/google/android/gms/common/internal/c0;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v1, v0}, Lcom/google/android/gms/common/internal/c0;->b(Lcom/google/android/gms/common/internal/TelemetryData;)Lcom/google/android/gms/tasks/Task;

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    move v3, v2

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->c:Lcom/google/android/gms/common/internal/TelemetryData;

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method private final k(Lcom/google/android/gms/tasks/TaskCompletionSource;ILcom/google/android/gms/common/api/k;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz p2, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p3}, Lcom/google/android/gms/common/api/k;->getApiKey()Lcom/google/android/gms/common/api/internal/c;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p0, p2, p3}, Lcom/google/android/gms/common/api/internal/i2;->a(Lcom/google/android/gms/common/api/internal/i;ILcom/google/android/gms/common/api/internal/c;)Lcom/google/android/gms/common/api/internal/i2;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p2, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object p3, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/gms/common/api/internal/p1;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0, p3}, Lcom/google/android/gms/common/api/internal/p1;-><init>(Landroid/os/Handler;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1, v0, p2}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Ljava/util/concurrent/Executor;Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    :cond_0
    const/4 v2, 0x1

    return-void
.end method

.method static bridge synthetic m(Lcom/google/android/gms/common/api/internal/i;)J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/google/android/gms/common/api/internal/i;->a:J

    const/4 v3, 0x3

    const/4 v2, 0x3

    return-wide v0
.end method

.method static bridge synthetic n(Lcom/google/android/gms/common/api/internal/i;)Landroid/content/Context;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/i;->g:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method static bridge synthetic o(Lcom/google/android/gms/common/api/internal/i;)Landroid/os/Handler;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method static bridge synthetic p(Lcom/google/android/gms/common/api/internal/i;)Lcom/google/android/gms/common/f;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/i;->h:Lcom/google/android/gms/common/f;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method static bridge synthetic q()Lcom/google/android/gms/common/api/Status;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/common/api/internal/i;->s:Lcom/google/android/gms/common/api/Status;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method static bridge synthetic r(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;)Lcom/google/android/gms/common/api/Status;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/google/android/gms/common/api/internal/i;->g(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;)Lcom/google/android/gms/common/api/Status;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method static bridge synthetic s(Lcom/google/android/gms/common/api/internal/i;)Lcom/google/android/gms/common/api/internal/i0;
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/i;->m:Lcom/google/android/gms/common/api/internal/i0;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method public static u()Lcom/google/android/gms/common/api/internal/i;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    sget-object v0, Lcom/google/android/gms/common/api/internal/i;->t:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    sget-object v1, Lcom/google/android/gms/common/api/internal/i;->u:Lcom/google/android/gms/common/api/internal/i;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string v2, "egnnog e  aMlscabei on ftIsutaoamaegntrir-ntleesrs gn unneu"

    const-string v2, "Must guarantee manager is non-null before using getInstance"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v1, v2}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v1, Lcom/google/android/gms/common/api/internal/i;->u:Lcom/google/android/gms/common/api/internal/i;

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    throw v1
.end method

.method public static v(Landroid/content/Context;)Lcom/google/android/gms/common/api/internal/i;
    .locals 6
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    sget-object v0, Lcom/google/android/gms/common/api/internal/i;->t:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    sget-object v1, Lcom/google/android/gms/common/api/internal/i;->u:Lcom/google/android/gms/common/api/internal/i;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {}, Lcom/google/android/gms/common/internal/k;->f()Landroid/os/HandlerThread;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v2, Lcom/google/android/gms/common/api/internal/i;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {}, Lcom/google/android/gms/common/f;->x()Lcom/google/android/gms/common/f;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-direct {v2, p0, v1, v3}, Lcom/google/android/gms/common/api/internal/i;-><init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/f;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    sput-object v2, Lcom/google/android/gms/common/api/internal/i;->u:Lcom/google/android/gms/common/api/internal/i;

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object p0, Lcom/google/android/gms/common/api/internal/i;->u:Lcom/google/android/gms/common/api/internal/i;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    throw p0
.end method

.method static bridge synthetic w(Lcom/google/android/gms/common/api/internal/i;)Lcom/google/android/gms/common/internal/t0;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/i;->i:Lcom/google/android/gms/common/internal/t0;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method


# virtual methods
.method public final A(Lcom/google/android/gms/common/api/k;Lcom/google/android/gms/common/api/internal/n$a;I)Lcom/google/android/gms/tasks/Task;
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/k;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/api/internal/n$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    const/4 v3, 0x4

    invoke-direct {p0, v0, p3, p1}, Lcom/google/android/gms/common/api/internal/i;->k(Lcom/google/android/gms/tasks/TaskCompletionSource;ILcom/google/android/gms/common/api/k;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    new-instance p3, Lcom/google/android/gms/common/api/internal/m3;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p3, p2, v0}, Lcom/google/android/gms/common/api/internal/m3;-><init>(Lcom/google/android/gms/common/api/internal/n$a;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/i;->k:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v1, Lcom/google/android/gms/common/api/internal/m2;

    const/4 v3, 0x1

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v1, p3, p2, p1}, Lcom/google/android/gms/common/api/internal/m2;-><init>(Lcom/google/android/gms/common/api/internal/n3;ILcom/google/android/gms/common/api/k;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/16 p2, 0xd

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1, p2, v1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p2, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object p1
.end method

.method public final F(Lcom/google/android/gms/common/api/k;ILcom/google/android/gms/common/api/internal/e$a;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/k;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/gms/common/api/internal/e$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/api/internal/j3;

    const/4 v2, 0x2

    invoke-direct {v0, p2, p3}, Lcom/google/android/gms/common/api/internal/j3;-><init>(ILcom/google/android/gms/common/api/internal/e$a;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/i;->k:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance p3, Lcom/google/android/gms/common/api/internal/m2;

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p3, v0, p2, p1}, Lcom/google/android/gms/common/api/internal/m2;-><init>(Lcom/google/android/gms/common/api/internal/n3;ILcom/google/android/gms/common/api/k;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 p2, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1, p2, p3}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-virtual {p2, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public final G(Lcom/google/android/gms/common/api/k;ILcom/google/android/gms/common/api/internal/a0;Lcom/google/android/gms/tasks/TaskCompletionSource;Lcom/google/android/gms/common/api/internal/y;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/k;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/gms/common/api/internal/a0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Lcom/google/android/gms/tasks/TaskCompletionSource;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Lcom/google/android/gms/common/api/internal/y;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    invoke-virtual {p3}, Lcom/google/android/gms/common/api/internal/a0;->d()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p4, v0, p1}, Lcom/google/android/gms/common/api/internal/i;->k(Lcom/google/android/gms/tasks/TaskCompletionSource;ILcom/google/android/gms/common/api/k;)V

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/api/internal/l3;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0, p2, p3, p4, p5}, Lcom/google/android/gms/common/api/internal/l3;-><init>(ILcom/google/android/gms/common/api/internal/a0;Lcom/google/android/gms/tasks/TaskCompletionSource;Lcom/google/android/gms/common/api/internal/y;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/i;->k:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance p3, Lcom/google/android/gms/common/api/internal/m2;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p3, v0, p2, p1}, Lcom/google/android/gms/common/api/internal/m2;-><init>(Lcom/google/android/gms/common/api/internal/n3;ILcom/google/android/gms/common/api/k;)V

    const/4 v1, 0x5

    move v2, v1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v1, 0x2

    and-int/2addr v2, v1

    const/4 p2, 0x6

    const/4 p2, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1, p2, p3}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p2, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method final H(Lcom/google/android/gms/common/internal/MethodInvocation;IJI)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    new-instance v6, Lcom/google/android/gms/common/api/internal/j2;

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    move v2, p2

    move v2, p2

    const/4 v8, 0x1

    move v2, p2

    move v2, p2

    move-wide v3, p3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    move v5, p5

    const/4 v8, 0x4

    move v5, p5

    move v5, p5

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/api/internal/j2;-><init>(Lcom/google/android/gms/common/internal/MethodInvocation;IJI)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/16 p2, 0x12

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p1, p2, v6}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v8, 0x1

    const/4 v7, 0x6

    invoke-virtual {p2, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    return-void
.end method

.method public final I(Lcom/google/android/gms/common/ConnectionResult;I)V
    .locals 5
    .param p1    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/common/api/internal/i;->f(Lcom/google/android/gms/common/ConnectionResult;I)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1, p2, v2, p1}, Landroid/os/Handler;->obtainMessage(IIILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method

.method public final J()V
    .locals 4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v3, 0x2

    const/4 v1, 0x3

    const/4 v3, 0x7

    move v2, v1

    move v2, v1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    return-void
.end method

.method public final K(Lcom/google/android/gms/common/api/k;)V
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/k;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public final b(Lcom/google/android/gms/common/api/internal/i0;)V
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/internal/i0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/common/api/internal/i;->t:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->m:Lcom/google/android/gms/common/api/internal/i0;

    const/4 v3, 0x5

    const/4 v2, 0x2

    if-eq v1, p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->m:Lcom/google/android/gms/common/api/internal/i0;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->n:Ljava/util/Set;

    const/4 v3, 0x5

    invoke-interface {v1}, Ljava/util/Set;->clear()V

    :cond_0
    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->n:Ljava/util/Set;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/i0;->i()Landroidx/collection/c;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v1, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    throw p1
.end method

.method final c(Lcom/google/android/gms/common/api/internal/i0;)V
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/internal/i0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v0, Lcom/google/android/gms/common/api/internal/i;->t:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->m:Lcom/google/android/gms/common/api/internal/i0;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ne v1, p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->m:Lcom/google/android/gms/common/api/internal/i0;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->n:Ljava/util/Set;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {p1}, Ljava/util/Set;->clear()V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    monitor-exit v0

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw p1
.end method

.method final e()Z
    .locals 6
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-boolean v0, p0, Lcom/google/android/gms/common/api/internal/i;->b:Z

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x2

    move v5, v4

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    return v1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {}, Lcom/google/android/gms/common/internal/x;->b()Lcom/google/android/gms/common/internal/x;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/x;->a()Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->A2()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    return v1

    :cond_2
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->i:Lcom/google/android/gms/common/internal/t0;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/i;->g:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    const v3, 0xc1fa340

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v3}, Lcom/google/android/gms/common/internal/t0;->a(Landroid/content/Context;I)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v2, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eq v0, v2, :cond_4

    const/4 v5, 0x0

    if-nez v0, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x0

    goto :goto_1

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    return v1

    :cond_4
    :goto_1
    const/4 v4, 0x3

    move v5, v4

    const/4 v0, 0x1

    xor-int/2addr v5, v0

    return v0
.end method

.method final f(Lcom/google/android/gms/common/ConnectionResult;I)Z
    .locals 4
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->h:Lcom/google/android/gms/common/f;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->g:Landroid/content/Context;

    const/4 v3, 0x3

    invoke-virtual {v0, v1, p1, p2}, Lcom/google/android/gms/common/f;->M(Landroid/content/Context;Lcom/google/android/gms/common/ConnectionResult;I)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    return p1
.end method

.method public final handleMessage(Landroid/os/Message;)Z
    .locals 11
    .param p1    # Landroid/os/Message;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    const/16 v1, 0xd

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    const-wide/32 v2, 0x493e0

    const-wide/32 v2, 0x493e0

    const/4 v10, 0x5

    const-wide/32 v2, 0x493e0

    const-wide/32 v2, 0x493e0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-string/jumbo v4, "nlegebiGApgruoMo"

    const-string/jumbo v4, "rGalAeuggneioMpo"

    const/4 v10, 0x4

    const-string/jumbo v4, "olieaguoMAGngera"

    const-string v4, "GoogleApiManager"

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/16 v5, 0x11

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v6, 0x1

    const/4 v6, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/4 v7, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/4 v8, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    packed-switch v0, :pswitch_data_0

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string v1, " dgswnspniep:kn maeo"

    const-string v1, ":midnoepnw gks easn "

    const/4 v10, 0x5

    const-string/jumbo v1, "sa:n dgnqei eUmwk os"

    const-string v1, "Unknown message id: "

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-static {v4, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    return v7

    :pswitch_0
    const/4 v10, 0x5

    const/4 v9, 0x1

    iput-boolean v7, p0, Lcom/google/android/gms/common/api/internal/i;->b:Z

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    goto/16 :goto_7

    :pswitch_1
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    check-cast p1, Lcom/google/android/gms/common/api/internal/j2;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-wide v0, p1, Lcom/google/android/gms/common/api/internal/j2;->c:J

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-nez v0, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x4

    new-instance v0, Lcom/google/android/gms/common/internal/TelemetryData;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget v1, p1, Lcom/google/android/gms/common/api/internal/j2;->b:I

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    new-array v2, v8, [Lcom/google/android/gms/common/internal/MethodInvocation;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object p1, p1, Lcom/google/android/gms/common/api/internal/j2;->a:Lcom/google/android/gms/common/internal/MethodInvocation;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    aput-object p1, v2, v7

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {v2}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-direct {v0, v1, p1}, Lcom/google/android/gms/common/internal/TelemetryData;-><init>(ILjava/util/List;)V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/i;->i()Lcom/google/android/gms/common/internal/c0;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-interface {p1, v0}, Lcom/google/android/gms/common/internal/c0;->b(Lcom/google/android/gms/common/internal/TelemetryData;)Lcom/google/android/gms/tasks/Task;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto/16 :goto_7

    :cond_0
    const/4 v10, 0x3

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->c:Lcom/google/android/gms/common/internal/TelemetryData;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz v0, :cond_3

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/TelemetryData;->y2()Ljava/util/List;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/TelemetryData;->d()I

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    iget v2, p1, Lcom/google/android/gms/common/api/internal/j2;->b:I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-ne v0, v2, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x1

    if-eqz v1, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget v1, p1, Lcom/google/android/gms/common/api/internal/j2;->d:I

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-lt v0, v1, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    goto :goto_0

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->c:Lcom/google/android/gms/common/internal/TelemetryData;

    const/4 v10, 0x4

    iget-object v1, p1, Lcom/google/android/gms/common/api/internal/j2;->a:Lcom/google/android/gms/common/internal/MethodInvocation;

    const/4 v10, 0x3

    const/4 v9, 0x3

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/internal/TelemetryData;->z2(Lcom/google/android/gms/common/internal/MethodInvocation;)V

    const/4 v9, 0x1

    xor-int/2addr v10, v9

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v0, v5}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v10, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/i;->j()V

    :cond_3
    :goto_1
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->c:Lcom/google/android/gms/common/internal/TelemetryData;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-nez v0, :cond_11

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v1, p1, Lcom/google/android/gms/common/api/internal/j2;->a:Lcom/google/android/gms/common/internal/MethodInvocation;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    new-instance v1, Lcom/google/android/gms/common/internal/TelemetryData;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget v2, p1, Lcom/google/android/gms/common/api/internal/j2;->b:I

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-direct {v1, v2, v0}, Lcom/google/android/gms/common/internal/TelemetryData;-><init>(ILjava/util/List;)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    iput-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->c:Lcom/google/android/gms/common/internal/TelemetryData;

    const/4 v10, 0x7

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v0, v5}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    iget-wide v2, p1, Lcom/google/android/gms/common/api/internal/j2;->c:J

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    goto/16 :goto_7

    :pswitch_2
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/i;->j()V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    goto/16 :goto_7

    :pswitch_3
    const/4 v10, 0x6

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    check-cast p1, Lcom/google/android/gms/common/api/internal/x1;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/x1;->b(Lcom/google/android/gms/common/api/internal/x1;)Lcom/google/android/gms/common/api/internal/c;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-eqz v0, :cond_11

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x6

    const/4 v9, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/x1;->b(Lcom/google/android/gms/common/api/internal/x1;)Lcom/google/android/gms/common/api/internal/c;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    check-cast v0, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-static {v0, p1}, Lcom/google/android/gms/common/api/internal/v1;->D(Lcom/google/android/gms/common/api/internal/v1;Lcom/google/android/gms/common/api/internal/x1;)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    goto/16 :goto_7

    :pswitch_4
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    check-cast p1, Lcom/google/android/gms/common/api/internal/x1;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/x1;->b(Lcom/google/android/gms/common/api/internal/x1;)Lcom/google/android/gms/common/api/internal/c;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-eqz v0, :cond_11

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/x1;->b(Lcom/google/android/gms/common/api/internal/x1;)Lcom/google/android/gms/common/api/internal/c;

    move-result-object v1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    check-cast v0, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static {v0, p1}, Lcom/google/android/gms/common/api/internal/v1;->C(Lcom/google/android/gms/common/api/internal/v1;Lcom/google/android/gms/common/api/internal/x1;)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    goto/16 :goto_7

    :pswitch_5
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x1

    check-cast p1, Lcom/google/android/gms/common/api/internal/j0;

    const/4 v9, 0x1

    move v10, v9

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/j0;->a()Lcom/google/android/gms/common/api/internal/c;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x6

    invoke-interface {v1, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-nez v1, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/j0;->b()Lcom/google/android/gms/tasks/TaskCompletionSource;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {p1, v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setResult(Ljava/lang/Object;)V

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    goto/16 :goto_7

    :cond_4
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-interface {v1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x5

    check-cast v0, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {v0, v7}, Lcom/google/android/gms/common/api/internal/v1;->P(Lcom/google/android/gms/common/api/internal/v1;Z)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/j0;->b()Lcom/google/android/gms/tasks/TaskCompletionSource;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {p1, v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setResult(Ljava/lang/Object;)V

    const/4 v10, 0x1

    const/4 v9, 0x3

    goto/16 :goto_7

    :pswitch_6
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x4

    iget-object v1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    if-eqz v0, :cond_11

    const/4 v9, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    check-cast p1, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/v1;->e()Z

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto/16 :goto_7

    :pswitch_7
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    iget-object v1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-eqz v0, :cond_11

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    check-cast p1, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/v1;->N()V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto/16 :goto_7

    :pswitch_8
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->o:Ljava/util/Set;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_5
    :goto_2
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-eqz v0, :cond_6

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    check-cast v0, Lcom/google/android/gms/common/api/internal/c;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v9, 0x5

    move v10, v9

    invoke-interface {v1, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    check-cast v0, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-eqz v0, :cond_5

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/v1;->M()V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    goto :goto_2

    :cond_6
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->o:Ljava/util/Set;

    const/4 v10, 0x7

    invoke-interface {p1}, Ljava/util/Set;->clear()V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    goto/16 :goto_7

    :pswitch_9
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object v1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz v0, :cond_11

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    check-cast p1, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x1

    const/4 v9, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/v1;->L()V

    const/4 v9, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    goto/16 :goto_7

    :pswitch_a
    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    check-cast p1, Lcom/google/android/gms/common/api/k;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/i;->h(Lcom/google/android/gms/common/api/k;)Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto/16 :goto_7

    :pswitch_b
    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->g:Landroid/content/Context;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    instance-of p1, p1, Landroid/app/Application;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-eqz p1, :cond_11

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->g:Landroid/content/Context;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    check-cast p1, Landroid/app/Application;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/d;->c(Landroid/app/Application;)V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {}, Lcom/google/android/gms/common/api/internal/d;->b()Lcom/google/android/gms/common/api/internal/d;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    new-instance v0, Lcom/google/android/gms/common/api/internal/q1;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/api/internal/q1;-><init>(Lcom/google/android/gms/common/api/internal/i;)V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/api/internal/d;->a(Lcom/google/android/gms/common/api/internal/d$a;)V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {}, Lcom/google/android/gms/common/api/internal/d;->b()Lcom/google/android/gms/common/api/internal/d;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {p1, v8}, Lcom/google/android/gms/common/api/internal/d;->e(Z)Z

    move-result p1

    const/4 v10, 0x3

    const/4 v9, 0x5

    if-nez p1, :cond_11

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    iput-wide v2, p0, Lcom/google/android/gms/common/api/internal/i;->a:J

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    goto/16 :goto_7

    :pswitch_c
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    iget v0, p1, Landroid/os/Message;->arg1:I

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    check-cast p1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-interface {v2}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_7
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-eqz v3, :cond_8

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x7

    check-cast v3, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x0

    invoke-virtual {v3}, Lcom/google/android/gms/common/api/internal/v1;->s()I

    move-result v7

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-ne v7, v0, :cond_7

    move-object v6, v3

    move-object v6, v3

    move-object v6, v3

    move-object v6, v3

    :cond_8
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    if-eqz v6, :cond_a

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-ne v0, v1, :cond_9

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->h:Lcom/google/android/gms/common/f;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    new-instance v1, Lcom/google/android/gms/common/api/Status;

    const/4 v9, 0x3

    move v10, v9

    invoke-virtual {p1}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result v2

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v0, v2}, Lcom/google/android/gms/common/f;->h(I)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/ConnectionResult;->z2()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const-string/jumbo v3, "oaserroroiercsun i r qbmn a ge tahwllnce  sEry darslueesrr:eige, so"

    const-string v3, "eeirrrcgqeeerlohiu osl nr rsst rsc Eabwe raelianysnr,g moo:o  ua de"

    const/4 v10, 0x0

    const-string v3, "eoemsonoi or a  llgu rec,rrce s rsmuwgre :nridiae tbsrEeosr lteayah"

    const-string v3, "Error resolution was canceled by the user, original error message: "

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    const-string v0, ": "

    const-string v0, ": "

    const/4 v10, 0x3

    const-string v0, ": "

    const-string v0, ": "

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    move v10, v9

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-direct {v1, v5, p1}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {v6, v1}, Lcom/google/android/gms/common/api/internal/v1;->z(Lcom/google/android/gms/common/api/internal/v1;Lcom/google/android/gms/common/api/Status;)V

    const/4 v10, 0x4

    const/4 v9, 0x3

    goto/16 :goto_7

    :cond_9
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-static {v6}, Lcom/google/android/gms/common/api/internal/v1;->x(Lcom/google/android/gms/common/api/internal/v1;)Lcom/google/android/gms/common/api/internal/c;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-static {v0, p1}, Lcom/google/android/gms/common/api/internal/i;->g(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;)Lcom/google/android/gms/common/api/Status;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-static {v6, p1}, Lcom/google/android/gms/common/api/internal/v1;->z(Lcom/google/android/gms/common/api/internal/v1;Lcom/google/android/gms/common/api/Status;)V

    const/4 v10, 0x0

    const/4 v9, 0x7

    goto/16 :goto_7

    :cond_a
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    const-string v1, "  oioPunns  tda CfItnscloeni"

    const-string/jumbo v1, "itso nIet lPaficnCsnuAd o n "

    const/4 v10, 0x1

    const-string v1, "Could not find API instance "

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-string/jumbo v0, "i teabdhn  tgclor .yq insewuulel imaf"

    const-string/jumbo v0, "ni.mihuet g arcf  etqdasle nlluewioy "

    const/4 v10, 0x4

    const-string/jumbo v0, "sllidtu cwqn ayeuoifel nae ilhr  gtue"

    const-string v0, " while trying to fail enqueued calls."

    const/4 v9, 0x3

    move v10, v9

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    new-instance v0, Ljava/lang/Exception;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    const/4 v10, 0x7

    invoke-static {v4, p1, v0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto/16 :goto_7

    :pswitch_d
    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    check-cast p1, Lcom/google/android/gms/common/api/internal/m2;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget-object v1, p1, Lcom/google/android/gms/common/api/internal/m2;->c:Lcom/google/android/gms/common/api/k;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/k;->getApiKey()Lcom/google/android/gms/common/api/internal/c;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    check-cast v0, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-nez v0, :cond_b

    const/4 v10, 0x7

    iget-object v0, p1, Lcom/google/android/gms/common/api/internal/m2;->c:Lcom/google/android/gms/common/api/k;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/api/internal/i;->h(Lcom/google/android/gms/common/api/k;)Lcom/google/android/gms/common/api/internal/v1;

    move-result-object v0

    :cond_b
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/v1;->d()Z

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-eqz v1, :cond_c

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->k:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    iget v2, p1, Lcom/google/android/gms/common/api/internal/m2;->b:I

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-eq v1, v2, :cond_c

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object p1, p1, Lcom/google/android/gms/common/api/internal/m2;->a:Lcom/google/android/gms/common/api/internal/n3;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    sget-object v1, Lcom/google/android/gms/common/api/internal/i;->r:Lcom/google/android/gms/common/api/Status;

    const/4 v10, 0x1

    const/4 v9, 0x4

    invoke-virtual {p1, v1}, Lcom/google/android/gms/common/api/internal/n3;->a(Lcom/google/android/gms/common/api/Status;)V

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/v1;->M()V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    goto/16 :goto_7

    :cond_c
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object p1, p1, Lcom/google/android/gms/common/api/internal/m2;->a:Lcom/google/android/gms/common/api/internal/n3;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/api/internal/v1;->G(Lcom/google/android/gms/common/api/internal/n3;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    goto/16 :goto_7

    :pswitch_e
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-interface {p1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_3
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-eqz v0, :cond_11

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    check-cast v0, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/v1;->E()V

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/v1;->F()V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    goto :goto_3

    :pswitch_f
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    check-cast p1, Lcom/google/android/gms/common/api/internal/q3;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/q3;->b()Ljava/util/Set;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_4
    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-eqz v2, :cond_11

    const/4 v10, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    check-cast v2, Lcom/google/android/gms/common/api/internal/c;

    const/4 v9, 0x7

    xor-int/2addr v10, v9

    iget-object v3, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    check-cast v3, Lcom/google/android/gms/common/api/internal/v1;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-nez v3, :cond_d

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    new-instance v0, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(I)V

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {p1, v2, v0, v6}, Lcom/google/android/gms/common/api/internal/q3;->c(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v10, 0x6

    goto/16 :goto_7

    :cond_d
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v3}, Lcom/google/android/gms/common/api/internal/v1;->Q()Z

    move-result v4

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-eqz v4, :cond_e

    const/4 v9, 0x6

    move v10, v9

    sget-object v4, Lcom/google/android/gms/common/ConnectionResult;->C:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v3}, Lcom/google/android/gms/common/api/internal/v1;->w()Lcom/google/android/gms/common/api/a$f;

    move-result-object v3

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-interface {v3}, Lcom/google/android/gms/common/api/a$f;->getEndpointPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {p1, v2, v4, v3}, Lcom/google/android/gms/common/api/internal/q3;->c(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x0

    goto :goto_4

    :cond_e
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {v3}, Lcom/google/android/gms/common/api/internal/v1;->u()Lcom/google/android/gms/common/ConnectionResult;

    move-result-object v4

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-eqz v4, :cond_f

    const/4 v9, 0x5

    shl-int/2addr v10, v9

    invoke-virtual {p1, v2, v4, v6}, Lcom/google/android/gms/common/api/internal/q3;->c(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/ConnectionResult;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    goto :goto_4

    :cond_f
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v3, p1}, Lcom/google/android/gms/common/api/internal/v1;->K(Lcom/google/android/gms/common/api/internal/q3;)V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v3}, Lcom/google/android/gms/common/api/internal/v1;->F()V

    const/4 v10, 0x7

    goto/16 :goto_4

    :pswitch_10
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    check-cast p1, Ljava/lang/Boolean;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-eq v8, p1, :cond_10

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto :goto_5

    :cond_10
    const/4 v9, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    const-wide/16 v2, 0x2710

    const-wide/16 v2, 0x2710

    const/4 v10, 0x4

    const-wide/16 v2, 0x2710

    const-wide/16 v2, 0x2710

    :goto_5
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x4

    iput-wide v2, p0, Lcom/google/android/gms/common/api/internal/i;->a:J

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/16 v0, 0xc

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v10, 0x4

    const/4 v9, 0x2

    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_6
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    if-eqz v1, :cond_11

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    check-cast v1, Lcom/google/android/gms/common/api/internal/c;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {v2, v0, v1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x7

    iget-wide v3, p0, Lcom/google/android/gms/common/api/internal/i;->a:J

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v2, v1, v3, v4}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    goto :goto_6

    :cond_11
    :goto_7
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    return v8

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_d
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_d
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final l()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->j:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method final t(Lcom/google/android/gms/common/api/internal/c;)Lcom/google/android/gms/common/api/internal/v1;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/i;->l:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    check-cast p1, Lcom/google/android/gms/common/api/internal/v1;

    return-object p1
.end method

.method public final x(Ljava/lang/Iterable;)Lcom/google/android/gms/tasks/Task;
    .locals 4
    .param p1    # Ljava/lang/Iterable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/common/api/internal/q3;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/api/internal/q3;-><init>(Ljava/lang/Iterable;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1, v1, v0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v1, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/q3;->a()Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p1
.end method

.method public final y(Lcom/google/android/gms/common/api/k;)Lcom/google/android/gms/tasks/Task;
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/k;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/common/api/internal/j0;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/k;->getApiKey()Lcom/google/android/gms/common/api/internal/c;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/api/internal/j0;-><init>(Lcom/google/android/gms/common/api/internal/c;)V

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/16 v1, 0xe

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, v1, v0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    invoke-virtual {v1, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/j0;->b()Lcom/google/android/gms/tasks/TaskCompletionSource;

    move-result-object p1

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object p1
.end method

.method public final z(Lcom/google/android/gms/common/api/k;Lcom/google/android/gms/common/api/internal/t;Lcom/google/android/gms/common/api/internal/c0;Ljava/lang/Runnable;)Lcom/google/android/gms/tasks/Task;
    .locals 5
    .param p1    # Lcom/google/android/gms/common/api/k;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/api/internal/t;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/gms/common/api/internal/c0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v0, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p2}, Lcom/google/android/gms/common/api/internal/t;->e()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {p0, v0, v1, p1}, Lcom/google/android/gms/common/api/internal/i;->k(Lcom/google/android/gms/tasks/TaskCompletionSource;ILcom/google/android/gms/common/api/k;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v1, Lcom/google/android/gms/common/api/internal/k3;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v2, Lcom/google/android/gms/common/api/internal/n2;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v2, p2, p3, p4}, Lcom/google/android/gms/common/api/internal/n2;-><init>(Lcom/google/android/gms/common/api/internal/t;Lcom/google/android/gms/common/api/internal/c0;Ljava/lang/Runnable;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v1, v2, v0}, Lcom/google/android/gms/common/api/internal/k3;-><init>(Lcom/google/android/gms/common/api/internal/n2;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/i;->k:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance p3, Lcom/google/android/gms/common/api/internal/m2;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p3, v1, p2, p1}, Lcom/google/android/gms/common/api/internal/m2;-><init>(Lcom/google/android/gms/common/api/internal/n3;ILcom/google/android/gms/common/api/k;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/16 p2, 0x8

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, p2, p3}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/i;->p:Landroid/os/Handler;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p2, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object p1
.end method
