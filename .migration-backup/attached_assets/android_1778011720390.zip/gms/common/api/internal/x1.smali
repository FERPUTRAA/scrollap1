.class final Lcom/google/android/gms/common/api/internal/x1;
.super Ljava/lang/Object;


# instance fields
.field private final a:Lcom/google/android/gms/common/api/internal/c;

.field private final b:Lcom/google/android/gms/common/Feature;


# direct methods
.method synthetic constructor <init>(Lcom/google/android/gms/common/api/internal/c;Lcom/google/android/gms/common/Feature;Lcom/google/android/gms/common/api/internal/w1;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/x1;->a:Lcom/google/android/gms/common/api/internal/c;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/x1;->b:Lcom/google/android/gms/common/Feature;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method static bridge synthetic a(Lcom/google/android/gms/common/api/internal/x1;)Lcom/google/android/gms/common/Feature;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "s@s@~@~~-o b~ob@@~ @c @ uo@b~n@@~l ~ dK   ~~io@fa   m@@~ ~M/v~S~@ ~  ~~@@i~4@tf1 ol/r~.y~o~t@@@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/x1;->b:Lcom/google/android/gms/common/Feature;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p0
.end method

.method static bridge synthetic b(Lcom/google/android/gms/common/api/internal/x1;)Lcom/google/android/gms/common/api/internal/c;
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/x1;->a:Lcom/google/android/gms/common/api/internal/c;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    const/4 v4, 0x5

    instance-of v1, p1, Lcom/google/android/gms/common/api/internal/x1;

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    check-cast p1, Lcom/google/android/gms/common/api/internal/x1;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/x1;->a:Lcom/google/android/gms/common/api/internal/c;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v2, p1, Lcom/google/android/gms/common/api/internal/x1;->a:Lcom/google/android/gms/common/api/internal/c;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v1, v2}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/x1;->b:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/google/android/gms/common/api/internal/x1;->b:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v1, p1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 p1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    return p1

    :cond_0
    const/4 v4, 0x3

    return v0
.end method

.method public final hashCode()I
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/x1;->a:Lcom/google/android/gms/common/api/internal/c;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v2, 0x3

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    aput-object v0, v1, v2

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x5

    move v3, v0

    move v3, v0

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/x1;->b:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    aput-object v2, v1, v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-static {v1}, Lcom/google/android/gms/common/internal/t;->c([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/google/android/gms/common/internal/t;->d(Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo v1, "yek"

    const-string/jumbo v1, "yek"

    const/4 v4, 0x4

    const-string/jumbo v1, "yke"

    const-string/jumbo v1, "key"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/x1;->a:Lcom/google/android/gms/common/api/internal/c;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v1, "aeemtur"

    const-string/jumbo v1, "feature"

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/x1;->b:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/t$a;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object v0
.end method
