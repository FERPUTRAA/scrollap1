.class final Lcom/google/android/gms/common/api/internal/v0;
.super Lcom/google/android/gms/signin/internal/c;


# instance fields
.field private final a:Ljava/lang/ref/WeakReference;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/a1;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/signin/internal/c;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/v0;->a:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public final h(Lcom/google/android/gms/signin/internal/zak;)V
    .locals 5
    .annotation build Landroidx/annotation/g;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, ". sl@/f  v~f@@bs@c 1~~@@nd~l~bt~~@~o@~ o4@~-~@~o@~ai~@   ~K~  o~~@@~i @b @o@@~ mi r~~ Sy/@@M tou"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v0;->a:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    check-cast v0, Lcom/google/android/gms/common/api/internal/a1;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->u(Lcom/google/android/gms/common/api/internal/a1;)Lcom/google/android/gms/common/api/internal/n1;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v2, Lcom/google/android/gms/common/api/internal/u0;

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-direct {v2, p0, v0, v0, p1}, Lcom/google/android/gms/common/api/internal/u0;-><init>(Lcom/google/android/gms/common/api/internal/v0;Lcom/google/android/gms/common/api/internal/k1;Lcom/google/android/gms/common/api/internal/a1;Lcom/google/android/gms/signin/internal/zak;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Lcom/google/android/gms/common/api/internal/n1;->u(Lcom/google/android/gms/common/api/internal/l1;)V

    const/4 v4, 0x2

    return-void
.end method
