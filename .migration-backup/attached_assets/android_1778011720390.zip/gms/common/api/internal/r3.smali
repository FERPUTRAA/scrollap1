.class final Lcom/google/android/gms/common/api/internal/r3;
.super Ljava/lang/Object;


# instance fields
.field private final a:I

.field private final b:Lcom/google/android/gms/common/ConnectionResult;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/ConnectionResult;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/r3;->b:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput p2, p0, Lcom/google/android/gms/common/api/internal/r3;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method final a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ st  mo/@c  f @  K @lbS/a1do@@~o 4~~@ ~.~ @~@i~~@t  M@oo ~ru~~~@~@~~~fy@ @v@ ol~~~-~in@s~@@ib~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/gms/common/api/internal/r3;->a:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method final b()Lcom/google/android/gms/common/ConnectionResult;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/r3;->b:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method
