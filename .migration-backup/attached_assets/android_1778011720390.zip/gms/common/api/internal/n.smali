.class public final Lcom/google/android/gms/common/api/internal/n;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/api/internal/n$a;,
        Lcom/google/android/gms/common/api/internal/n$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<",
        "L:Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field private final a:Ljava/util/concurrent/Executor;

.field private volatile b:Ljava/lang/Object;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private volatile c:Lcom/google/android/gms/common/api/internal/n$a;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroid/os/Looper;Ljava/lang/Object;Ljava/lang/String;)V
    .locals 3
    .param p1    # Landroid/os/Looper;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Looper;",
            "T",
            "L;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    move v2, v1

    new-instance v0, Lcom/google/android/gms/common/util/concurrent/a;

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/util/concurrent/a;-><init>(Landroid/os/Looper;)V

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/n;->a:Ljava/util/concurrent/Executor;

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    const-string/jumbo p1, "tnsnulse   tmolbtLss neeu"

    const-string p1, "elsnturnLmse ebutos  ltn "

    const/4 v2, 0x7

    const-string/jumbo p1, "omnmlueiLbrttsun l e s en"

    const-string p1, "Listener must not be null"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p2, p1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n;->b:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance p1, Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p1, p2, p3}, Lcom/google/android/gms/common/api/internal/n$a;-><init>(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n;->c:Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method constructor <init>(Ljava/util/concurrent/Executor;Ljava/lang/Object;Ljava/lang/String;)V
    .locals 3
    .param p1    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Executor;",
            "T",
            "L;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string/jumbo v0, "s emobulctonn  eulr tutEx"

    const-string/jumbo v0, "nm colboxt  enuoltr utsEu"

    const-string v0, "Executor must not be null"

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast p1, Ljava/util/concurrent/Executor;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n;->a:Ljava/util/concurrent/Executor;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo p1, "sb nnbe luioLl tneettuors"

    const-string/jumbo p1, "l lioo etsn eunrntemstbuL"

    const/4 v2, 0x0

    const-string p1, "bl nrlumt t useutnein soL"

    const-string p1, "Listener must not be null"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p2, p1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n;->b:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance p1, Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v1, 0x4

    move v2, v1

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p1, p2, p3}, Lcom/google/android/gms/common/api/internal/n$a;-><init>(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n;->c:Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  @@b~ip @  o~ Km/o~by/~@@st @@f@~ a~ f@~~o@@.or~~ l@n-S~lib@ d~~@ @@~41i @~@ Mo~ ~ ~t~u@ ~vc@o~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/n;->b:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/n;->c:Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public b()Lcom/google/android/gms/common/api/internal/n$a;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/gms/common/api/internal/n$a<",
            "T",
            "L;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n;->c:Lcom/google/android/gms/common/api/internal/n$a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public c()Z
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n;->b:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public d(Lcom/google/android/gms/common/api/internal/n$b;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/internal/n$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/internal/n$b<",
            "-T",
            "L;",
            ">;)V"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string/jumbo v0, "ombifbnu ttnNoislt ulee  "

    const/4 v2, 0x4

    const-string v0, "esNo nutqfoirbi lul tne t"

    const-string v0, "Notifier must not be null"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/gms/common/api/internal/g2;

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/api/internal/g2;-><init>(Lcom/google/android/gms/common/api/internal/n;Lcom/google/android/gms/common/api/internal/n$b;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/n;->a:Ljava/util/concurrent/Executor;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method final e(Lcom/google/android/gms/common/api/internal/n$b;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n;->b:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {p1}, Lcom/google/android/gms/common/api/internal/n$b;->b()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void

    :cond_0
    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {p1, v0}, Lcom/google/android/gms/common/api/internal/n$b;->a(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void

    :catch_0
    move-exception v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {p1}, Lcom/google/android/gms/common/api/internal/n$b;->b()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    throw v0
.end method
