.class public Lcom/google/android/gms/common/api/internal/u;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/api/internal/u$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A::",
        "Lcom/google/android/gms/common/api/a$b;",
        "L:Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field public final a:Lcom/google/android/gms/common/api/internal/t;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/gms/common/api/internal/t<",
            "TA;T",
            "L;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public final b:Lcom/google/android/gms/common/api/internal/c0;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public final c:Ljava/lang/Runnable;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method synthetic constructor <init>(Lcom/google/android/gms/common/api/internal/t;Lcom/google/android/gms/common/api/internal/c0;Ljava/lang/Runnable;Lcom/google/android/gms/common/api/internal/s2;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/u;->a:Lcom/google/android/gms/common/api/internal/t;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/u;->b:Lcom/google/android/gms/common/api/internal/c0;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/google/android/gms/common/api/internal/u;->c:Ljava/lang/Runnable;

    const/4 v1, 0x0

    return-void
.end method

.method public static a()Lcom/google/android/gms/common/api/internal/u$a;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<A::",
            "Lcom/google/android/gms/common/api/a$b;",
            "L:Ljava/lang/Object;",
            ">()",
            "Lcom/google/android/gms/common/api/internal/u$a<",
            "TA;T",
            "L;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/common/api/internal/u$a;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/api/internal/u$a;-><init>(Lcom/google/android/gms/common/api/internal/r2;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0
.end method
