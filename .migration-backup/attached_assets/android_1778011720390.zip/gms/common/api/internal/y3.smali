.class public final Lcom/google/android/gms/common/api/internal/y3;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/l$b;
.implements Lcom/google/android/gms/common/api/l$c;


# instance fields
.field public final a:Lcom/google/android/gms/common/api/a;

.field private final b:Z

.field private c:Lcom/google/android/gms/common/api/internal/z3;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/a;Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/y3;->a:Lcom/google/android/gms/common/api/a;

    const/4 v1, 0x7

    iput-boolean p2, p0, Lcom/google/android/gms/common/api/internal/y3;->b:Z

    const/4 v1, 0x2

    const/4 v0, 0x7

    return-void
.end method

.method private final e()Lcom/google/android/gms/common/api/internal/z3;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~osb ~ @-.~~~@ @yi@@ ~bl~ruf@ l~ot  @c~/n@~i~1@oi~Ko @~@v~~ 4@ @s /@m @  Sa~~~of@~ ~@@@d @ tM~o~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y3;->c:Lcom/google/android/gms/common/api/internal/z3;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v1, "ce mesnlsibleio h eabcoa dteiemcrcnnon  eobs .sannClneneogei t hr nueleHtatCtpccakntticaltttC"

    const-string v1, "btsaao l beiiinmlnceceosnpeceoceleeona ttrd lenin t acacige t ttHotrsnkene nClt.sutahn CCbhc "

    const/4 v3, 0x5

    const-string/jumbo v1, "nklloCcbi laubeonei.neea  ntsgeccnmicoherton ttCfnceanstb orpnlttectes hciCHeate int  d ol aa"

    const-string v1, "Callbacks must be attached to a ClientConnectionHelper instance before connecting the client."

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y3;->c:Lcom/google/android/gms/common/api/internal/z3;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0
.end method


# virtual methods
.method public final a(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/y3;->e()Lcom/google/android/gms/common/api/internal/z3;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/f;->a(Landroid/os/Bundle;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public final b(I)V
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/y3;->e()Lcom/google/android/gms/common/api/internal/z3;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/f;->b(I)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public final c(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 5
    .param p1    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y3;->a:Lcom/google/android/gms/common/api/a;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-boolean v1, p0, Lcom/google/android/gms/common/api/internal/y3;->b:Z

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/y3;->e()Lcom/google/android/gms/common/api/internal/z3;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {v2, p1, v0, v1}, Lcom/google/android/gms/common/api/internal/z3;->X(Lcom/google/android/gms/common/ConnectionResult;Lcom/google/android/gms/common/api/a;Z)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method

.method public final d(Lcom/google/android/gms/common/api/internal/z3;)V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/y3;->c:Lcom/google/android/gms/common/api/internal/z3;

    const/4 v1, 0x2

    return-void
.end method
