.class final Lcom/google/android/gms/common/api/internal/o3;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/l$c;


# instance fields
.field public final a:I

.field public final b:Lcom/google/android/gms/common/api/l;

.field public final c:Lcom/google/android/gms/common/api/l$c;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field final synthetic d:Lcom/google/android/gms/common/api/internal/p3;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/internal/p3;ILcom/google/android/gms/common/api/l;Lcom/google/android/gms/common/api/l$c;)V
    .locals 2
    .param p3    # Lcom/google/android/gms/common/api/l;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/o3;->d:Lcom/google/android/gms/common/api/internal/p3;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p2, p0, Lcom/google/android/gms/common/api/internal/o3;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/google/android/gms/common/api/internal/o3;->b:Lcom/google/android/gms/common/api/l;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p4, p0, Lcom/google/android/gms/common/api/internal/o3;->c:Lcom/google/android/gms/common/api/l$c;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final c(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 5
    .param p1    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "u@s~~~fs~ Sy@ M4@i~~ fo@it @oc@m ~ra- ~t@@ o@1~ @@/@ @~. ~@o~~lb@l@~ ~ @ d~~n v~~~o~@K@ i~o@  /b"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const-string/jumbo v1, "tlemMuerapsnegHa"

    const-string v1, "ApsMlneagetauHer"

    const/4 v4, 0x5

    const-string v1, "HaMpoeetaruenlgA"

    const-string v1, "AutoManageHelper"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const-string/jumbo v2, "uuaefbtoiel esiirrnomgn RFl"

    const-string/jumbo v2, "ot mi uFrsenifuleglorneoaiR"

    const/4 v4, 0x3

    const-string/jumbo v2, "sleF tufaro leuuoorgibnienR"

    const-string v2, "beginFailureResolution for "

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget v0, p0, Lcom/google/android/gms/common/api/internal/o3;->a:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/o3;->d:Lcom/google/android/gms/common/api/internal/p3;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1, p1, v0}, Lcom/google/android/gms/common/api/internal/u3;->h(Lcom/google/android/gms/common/ConnectionResult;I)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    return-void
.end method
