.class final Lcom/google/android/gms/common/api/internal/s3;
.super Lcom/google/android/gms/common/api/internal/b2;


# instance fields
.field final synthetic a:Landroid/app/Dialog;

.field final synthetic b:Lcom/google/android/gms/common/api/internal/t3;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/t3;Landroid/app/Dialog;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/s3;->b:Lcom/google/android/gms/common/api/internal/t3;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/s3;->a:Landroid/app/Dialog;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/b2;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@~@f @b@b@cl~~@nom@~  utSv~a ~ i~@@M~@ do~@  @ l~ ~oKf@@~/4  r-~b/ @@y~~o1~i o~@o@  ~ts.~~@@i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/s3;->b:Lcom/google/android/gms/common/api/internal/t3;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, v0, Lcom/google/android/gms/common/api/internal/t3;->b:Lcom/google/android/gms/common/api/internal/u3;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/u3;->g(Lcom/google/android/gms/common/api/internal/u3;)V

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/s3;->a:Landroid/app/Dialog;

    const/4 v1, 0x6

    const/4 v1, 0x7

    invoke-virtual {v0}, Landroid/app/Dialog;->isShowing()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/s3;->a:Landroid/app/Dialog;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
