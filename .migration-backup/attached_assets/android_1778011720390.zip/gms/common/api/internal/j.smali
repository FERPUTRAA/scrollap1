.class public final Lcom/google/android/gms/common/api/internal/j;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field private static final e:Ljava/lang/Object;

.field private static f:Lcom/google/android/gms/common/api/internal/j;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lz4/a;
        value = "lock"
    .end annotation
.end field


# instance fields
.field private final a:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final b:Lcom/google/android/gms/common/api/Status;

.field private final c:Z

.field private final d:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/gms/common/api/internal/j;->e:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method constructor <init>(Landroid/content/Context;)V
    .locals 6
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    sget v1, Lcom/google/android/gms/common/R$string;->common_google_play_services_unknown_issue:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getResourcePackageName(I)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v2, "_mspeuaelae_nleotansbggopeme_"

    const/4 v5, 0x7

    const-string v2, "eesoaeeoma_gup_gambnnsete_llr"

    const-string/jumbo v2, "google_app_measurement_enable"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v3, "gnrmtee"

    const-string v3, "enrmteg"

    const-string/jumbo v3, "etneorg"

    const-string/jumbo v3, "integer"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v3, v1}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    shr-int/2addr v5, v4

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    move v1, v3

    move v1, v3

    const/4 v5, 0x2

    move v1, v3

    move v1, v3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    move v1, v2

    move v1, v2

    const/4 v5, 0x0

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    move v2, v3

    move v2, v3

    const/4 v5, 0x2

    move v2, v3

    move v2, v3

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-boolean v1, p0, Lcom/google/android/gms/common/api/internal/j;->d:Z

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    goto :goto_2

    :cond_2
    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput-boolean v3, p0, Lcom/google/android/gms/common/api/internal/j;->d:Z

    :goto_2
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-boolean v2, p0, Lcom/google/android/gms/common/api/internal/j;->c:Z

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/internal/n1;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez v0, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v0, Lcom/google/android/gms/common/internal/a0;

    const/4 v4, 0x0

    move v5, v4

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/internal/a0;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string p1, "_igogbp_olepd"

    const-string/jumbo p1, "g_gioolpdpeo_"

    const/4 v5, 0x1

    const-string p1, "__gdelupigpao"

    const-string/jumbo p1, "google_app_id"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/a0;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz p1, :cond_4

    const/4 v4, 0x5

    move v5, v4

    new-instance p1, Lcom/google/android/gms/common/api/Status;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/16 v0, 0xa

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v1, "imvfo hpragopgrMpprf psgweesg_o  nl_gerns dacldm eoi u aa.iteu olmgsiii tbs oeo"

    const-string/jumbo v1, "nos_obadglr  spMgofuvmgmereeeophatlrr    c.s ig oeoiaiu pwpd aifngitensmolg s_i"

    const-string v1, "eedpp roqrgisa glir ai ssoepeuog am lru ggdrin Mtmfatpnhns ciooe_mwoe.i go_lvfs"

    const-string v1, "Missing google app id value from from string resources with name google_app_id."

    const/4 v5, 0x0

    const/4 v4, 0x6

    invoke-direct {p1, v0, v1}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/j;->b:Lcom/google/android/gms/common/api/Status;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/j;->a:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x4

    return-void

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/j;->a:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    sget-object p1, Lcom/google/android/gms/common/api/Status;->f:Lcom/google/android/gms/common/api/Status;

    const/4 v5, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/j;->b:Lcom/google/android/gms/common/api/Status;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Z)V
    .locals 2
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/j;->a:Ljava/lang/String;

    const/4 v0, 0x0

    const/4 v1, 0x2

    sget-object p1, Lcom/google/android/gms/common/api/Status;->f:Lcom/google/android/gms/common/api/Status;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/j;->b:Lcom/google/android/gms/common/api/Status;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-boolean p2, p0, Lcom/google/android/gms/common/api/internal/j;->c:Z

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    xor-int/lit8 p1, p2, 0x1

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/google/android/gms/common/api/internal/j;->d:Z

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method private static b(Ljava/lang/String;)Lcom/google/android/gms/common/api/internal/j;
    .locals 6
    .annotation build Lf4/a;
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@isbf~~@ o@ ~o@@vi~~u.@@~@~ @ b/ @~y~S~o  4oM@  @l~-@ @  1/ ~~cdl@ro~~@mnt~~b  ~K@ @~~~@tos ~fa@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    sget-object v0, Lcom/google/android/gms/common/api/internal/j;->e:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object v1, Lcom/google/android/gms/common/api/internal/j;->f:Lcom/google/android/gms/common/api/internal/j;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object v1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v3, "irbmlaelteacsfi net bIdo ezlu emi"

    const-string v3, "Initialize must be called before "

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string p0, "."

    const-string p0, "."

    const/4 v5, 0x3

    const-string p0, "."

    const-string p0, "."

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-direct {v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    throw v1

    :catchall_0
    move-exception p0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    move v5, v4

    throw p0
.end method

.method static c()V
    .locals 4
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object v0, Lcom/google/android/gms/common/api/internal/j;->e:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    monitor-enter v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x0

    :try_start_0
    const/4 v2, 0x6

    move v3, v2

    sput-object v1, Lcom/google/android/gms/common/api/internal/j;->f:Lcom/google/android/gms/common/api/internal/j;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :catchall_0
    move-exception v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    throw v1
.end method

.method public static d()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string v0, "AglIogeuGteood"

    const-string/jumbo v0, "lpoeogutegIdAG"

    const/4 v2, 0x1

    const-string v0, "GgelAbgdppetIo"

    const-string/jumbo v0, "getGoogleAppId"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/j;->b(Ljava/lang/String;)Lcom/google/android/gms/common/api/internal/j;

    move-result-object v0

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, v0, Lcom/google/android/gms/common/api/internal/j;->a:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public static e(Landroid/content/Context;)Lcom/google/android/gms/common/api/Status;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const-string v0, "Cm neuunte.ot uotl sln tb"

    const-string v0, "Context must not be null."

    const/4 v2, 0x7

    move v3, v2

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    sget-object v0, Lcom/google/android/gms/common/api/internal/j;->e:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v1, Lcom/google/android/gms/common/api/internal/j;->f:Lcom/google/android/gms/common/api/internal/j;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    new-instance v1, Lcom/google/android/gms/common/api/internal/j;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/google/android/gms/common/api/internal/j;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    sput-object v1, Lcom/google/android/gms/common/api/internal/j;->f:Lcom/google/android/gms/common/api/internal/j;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object p0, Lcom/google/android/gms/common/api/internal/j;->f:Lcom/google/android/gms/common/api/internal/j;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/j;->b:Lcom/google/android/gms/common/api/Status;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    throw p0
.end method

.method public static f(Landroid/content/Context;Ljava/lang/String;Z)Lcom/google/android/gms/common/api/Status;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, " oueelCpt tnn tubots. lmn"

    const/4 v2, 0x7

    const-string v0, "butmClepenx n ottsuo  .lt"

    const-string v0, "Context must not be null."

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string/jumbo p0, "nm .nqbpqye put te pIDos"

    const-string p0, ".tnpneIpq pt bymuDseom  "

    const-string p0, "App ID must be nonempty."

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p1, p0}, Lcom/google/android/gms/common/internal/v;->m(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object p0, Lcom/google/android/gms/common/api/internal/j;->e:Ljava/lang/Object;

    const/4 v2, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/common/api/internal/j;->f:Lcom/google/android/gms/common/api/internal/j;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/api/internal/j;->a(Ljava/lang/String;)Lcom/google/android/gms/common/api/Status;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/api/internal/j;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {v0, p1, p2}, Lcom/google/android/gms/common/api/internal/j;-><init>(Ljava/lang/String;Z)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput-object v0, Lcom/google/android/gms/common/api/internal/j;->f:Lcom/google/android/gms/common/api/internal/j;

    const/4 v2, 0x0

    const/4 v1, 0x3

    iget-object p1, v0, Lcom/google/android/gms/common/api/internal/j;->b:Lcom/google/android/gms/common/api/Status;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    throw p1
.end method

.method public static g()Z
    .locals 4
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v0, "mlsnEdsnbsMtuaseiaee"

    const-string v0, "elsneteMendibsaEaums"

    const/4 v3, 0x2

    const-string v0, "MnamEemesiasbdrleneu"

    const-string/jumbo v0, "isMeasurementEnabled"

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/j;->b(Ljava/lang/String;)Lcom/google/android/gms/common/api/internal/j;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, v0, Lcom/google/android/gms/common/api/internal/j;->b:Lcom/google/android/gms/common/api/Status;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/Status;->E2()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-boolean v0, v0, Lcom/google/android/gms/common/api/internal/j;->c:Z

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x1

    move v3, v0

    const/4 v2, 0x4

    move v3, v2

    return v0

    :cond_0
    const/4 v2, 0x2

    move v3, v2

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return v0
.end method

.method public static h()Z
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string v0, "cduiomiiMaetEDsbtlpyaexeesirsln"

    const-string/jumbo v0, "isMeasurementExplicitlyDisabled"

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/j;->b(Ljava/lang/String;)Lcom/google/android/gms/common/api/internal/j;

    move-result-object v0

    const/4 v2, 0x4

    iget-boolean v0, v0, Lcom/google/android/gms/common/api/internal/j;->d:Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method


# virtual methods
.method a(Ljava/lang/String;)Lcom/google/android/gms/common/api/Status;
    .locals 5
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j;->a:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez p1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j;->a:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v0, Lcom/google/android/gms/common/api/Status;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v2, "./pf blieItllzpwehlt aieapwhi:siiwtod/t e Dfsn   lObcneGywadrf  oiIeal Dugd pn    A tIts osei er"

    const-string v2, "Initialize was called with two different Google App IDs.  Only the first app ID will be used: \'"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string p1, "//."

    const-string p1, "//."

    const-string p1, "//."

    const-string p1, "\'."

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/16 v1, 0xa

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {v0, v1, p1}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;)V

    const/4 v3, 0x1

    move v4, v3

    return-object v0

    :cond_0
    const/4 v3, 0x6

    move v4, v3

    sget-object p1, Lcom/google/android/gms/common/api/Status;->f:Lcom/google/android/gms/common/api/Status;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object p1
.end method
