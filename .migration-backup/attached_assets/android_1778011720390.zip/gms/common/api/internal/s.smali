.class public abstract Lcom/google/android/gms/common/api/internal/s;
.super Lcom/google/android/gms/common/api/p;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<A::",
        "Lcom/google/android/gms/common/api/v;",
        "B::",
        "Lcom/google/android/gms/common/api/v;",
        ">",
        "Lcom/google/android/gms/common/api/p<",
        "TB;>;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# virtual methods
.method public final addStatusListener(Lcom/google/android/gms/common/api/p$a;)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/api/p$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s~/ u@-S@@binv~@~~~~y~~i~@ @ ~i.cfb@~ t~1s~l f/@@tl o~~@M  o@@ @od m  K@~oo @ @@o ~br~a~~~@4@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    throw p1
.end method

.method public final await()Lcom/google/android/gms/common/api/v;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TB;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    throw v0
.end method

.method public final await(JLjava/util/concurrent/TimeUnit;)Lcom/google/android/gms/common/api/v;
    .locals 2
    .param p3    # Ljava/util/concurrent/TimeUnit;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Ljava/util/concurrent/TimeUnit;",
            ")TB;"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    throw p1
.end method

.method public final cancel()V
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    throw v0
.end method

.method public final isCanceled()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    throw v0
.end method

.method public final setResultCallback(Lcom/google/android/gms/common/api/w;)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/api/w;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/w<",
            "-TB;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    throw p1
.end method

.method public final setResultCallback(Lcom/google/android/gms/common/api/w;JLjava/util/concurrent/TimeUnit;)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/api/w;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Ljava/util/concurrent/TimeUnit;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/w<",
            "-TB;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    throw p1
.end method

.method public final then(Lcom/google/android/gms/common/api/y;)Lcom/google/android/gms/common/api/z;
    .locals 2
    .param p1    # Lcom/google/android/gms/common/api/y;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<S::",
            "Lcom/google/android/gms/common/api/v;",
            ">(",
            "Lcom/google/android/gms/common/api/y<",
            "-TB;+TS;>;)",
            "Lcom/google/android/gms/common/api/z<",
            "TS;>;"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    throw p1
.end method
