.class final Lcom/google/android/gms/common/api/internal/v2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/api/internal/y2;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/y2;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/v2;->a:Lcom/google/android/gms/common/api/internal/y2;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ s~  b@@~~@ ~itK~4/i @@   ubs@~/ @@moo@~y ll~ .~S1@~v@ Mf@ @~fr~bnit~o ~ c~~@@a~ -do@~~~o @~@@@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/v2;->a:Lcom/google/android/gms/common/api/internal/y2;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/y2;->o0(Lcom/google/android/gms/common/api/internal/y2;)Lcom/google/android/gms/common/api/internal/x2;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x4

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Lcom/google/android/gms/common/ConnectionResult;-><init>(I)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v0, v1}, Lcom/google/android/gms/common/api/internal/x2;->c(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method
