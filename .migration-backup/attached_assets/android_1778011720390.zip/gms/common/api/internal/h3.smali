.class final Lcom/google/android/gms/common/api/internal/h3;
.super Ljava/lang/Object;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/api/internal/i3;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/i3;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/h3;->a:Lcom/google/android/gms/common/api/internal/i3;

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method
