.class public final Lcom/google/android/gms/common/api/internal/j3;
.super Lcom/google/android/gms/common/api/internal/n3;


# instance fields
.field protected final b:Lcom/google/android/gms/common/api/internal/e$a;


# direct methods
.method public constructor <init>(ILcom/google/android/gms/common/api/internal/e$a;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/api/internal/n3;-><init>(I)V

    const/4 v0, 0x4

    and-int/2addr v1, v0

    const-string/jumbo p1, "hrsuem s.lonntNdna t abeeu lro"

    const/4 v1, 0x7

    const-string/jumbo p1, "tuslhndlrn.eatum l o esneab No"

    const-string p1, "Null methods are not runnable."

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p2, p1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    check-cast p1, Lcom/google/android/gms/common/api/internal/e$a;

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/j3;->b:Lcom/google/android/gms/common/api/internal/e$a;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/common/api/Status;)V
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/Status;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "i@@mKt@ @bb@~4fli@i~o~@ ~@ ~l~1~S~d~@os  v@@ @~ub@~@ ~t@m o~ro~~o-M f ~ ~y ~~n o@@.~a@ //~ ~@c@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j3;->b:Lcom/google/android/gms/common/api/internal/e$a;

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/api/internal/e$a;->setFailedResult(Lcom/google/android/gms/common/api/Status;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string v0, "RurpoCmalliAn"

    const-string/jumbo v0, "rlAmnliapuCnR"

    const/4 v3, 0x6

    const-string/jumbo v0, "upaAlbnilreCn"

    const-string v0, "ApiCallRunner"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v1, "iflitruipeouaecE reng toxop"

    const-string v1, "aroxonEgteiriu petci eolfpr"

    const/4 v3, 0x0

    const-string v1, "ai inelpirgprefutoporcexE n"

    const-string v1, "Exception reporting failure"

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method public final b(Ljava/lang/Exception;)V
    .locals 5
    .param p1    # Ljava/lang/Exception;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v0, Lcom/google/android/gms/common/api/Status;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v1, ": "

    const/4 v4, 0x1

    const-string v1, " :"

    const-string v1, ": "

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/16 v1, 0xa

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0, v1, p1}, Lcom/google/android/gms/common/api/Status;-><init>(ILjava/lang/String;)V

    :try_start_0
    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/j3;->b:Lcom/google/android/gms/common/api/internal/e$a;

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/api/internal/e$a;->setFailedResult(Lcom/google/android/gms/common/api/Status;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void

    :catch_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v0, "pnnlACrbquRil"

    const-string/jumbo v0, "paiCrbnRnlAlu"

    const/4 v4, 0x7

    const-string v0, "AesuClalRnpni"

    const-string v0, "ApiCallRunner"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v1, "iEnmixtutfeioeprougrpa  rnc"

    const-string/jumbo v1, "io iueutfrcrtnp gaErxieeonp"

    const/4 v4, 0x6

    const-string/jumbo v1, "g opooe ruapxeliricEitnfrne"

    const-string v1, "Exception reporting failure"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method

.method public final c(Lcom/google/android/gms/common/api/internal/v1;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/DeadObjectException;
        }
    .end annotation

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j3;->b:Lcom/google/android/gms/common/api/internal/e$a;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/v1;->w()Lcom/google/android/gms/common/api/a$f;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/api/internal/e$a;->run(Lcom/google/android/gms/common/api/a$b;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/internal/j3;->b(Ljava/lang/Exception;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public final d(Lcom/google/android/gms/common/api/internal/h0;Z)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/internal/h0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/j3;->b:Lcom/google/android/gms/common/api/internal/e$a;

    const/4 v2, 0x2

    invoke-virtual {p1, v0, p2}, Lcom/google/android/gms/common/api/internal/h0;->c(Lcom/google/android/gms/common/api/internal/BasePendingResult;Z)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method
