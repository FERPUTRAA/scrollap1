.class public final Lcom/google/android/gms/common/api/internal/zabx;
.super Landroid/content/BroadcastReceiver;


# instance fields
.field a:Landroid/content/Context;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final b:Lcom/google/android/gms/common/api/internal/b2;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/internal/b2;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/zabx;->b:Lcom/google/android/gms/common/api/internal/b2;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "tysu   @@~v f@.M/~  ~@n~~or~d@@i~~4~ oo@  ~Ko~ob/@  ~~@itl@m~~@@f@o- i@~@@@~ s bc ~~bS @~l~@@ a1"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/zabx;->a:Landroid/content/Context;

    return-void
.end method

.method public final declared-synchronized b()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/zabx;->a:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/zabx;->a:Landroid/content/Context;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    throw v0
.end method

.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p2}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1}, Landroid/net/Uri;->getSchemeSpecificPart()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    const-string/jumbo p2, "g.eml.ddg.osmaricgnmoo"

    const-string/jumbo p2, "omsng.idcdsgoglm.aro.e"

    const/4 v1, 0x0

    const-string/jumbo p2, "oelgoad.s.crggmomod.oi"

    const-string p2, "com.google.android.gms"

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-eqz p1, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/zabx;->b:Lcom/google/android/gms/common/api/internal/b2;

    const/4 v1, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/b2;->a()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/zabx;->b()V

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method
