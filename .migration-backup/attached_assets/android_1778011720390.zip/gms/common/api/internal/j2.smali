.class final Lcom/google/android/gms/common/api/internal/j2;
.super Ljava/lang/Object;


# instance fields
.field final a:Lcom/google/android/gms/common/internal/MethodInvocation;

.field final b:I

.field final c:J

.field final d:I


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/internal/MethodInvocation;IJI)V
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/j2;->a:Lcom/google/android/gms/common/internal/MethodInvocation;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p2, p0, Lcom/google/android/gms/common/api/internal/j2;->b:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-wide p3, p0, Lcom/google/android/gms/common/api/internal/j2;->c:J

    const/4 v1, 0x7

    iput p5, p0, Lcom/google/android/gms/common/api/internal/j2;->d:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method
