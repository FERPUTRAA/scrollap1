.class final Lcom/google/android/gms/common/api/internal/s1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcom/google/android/gms/common/api/internal/v1;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/internal/v1;I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/s1;->b:Lcom/google/android/gms/common/api/internal/v1;

    const/4 v1, 0x2

    iput p2, p0, Lcom/google/android/gms/common/api/internal/s1;->a:I

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, ".~sudt@@ro~ @1m@S~~-osMb~i ~oo/ @ ~ ~Kbvi~~@ lo4 ~ ~~ @  @ib@ @@ @~@f ~y~t f~@n@l@~/~c@@@o  a~~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/s1;->b:Lcom/google/android/gms/common/api/internal/v1;

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/gms/common/api/internal/s1;->a:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/google/android/gms/common/api/internal/v1;->B(Lcom/google/android/gms/common/api/internal/v1;I)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    return-void
.end method
