.class public final Lcom/google/android/gms/common/api/internal/y2;
.super Lcom/google/android/gms/signin/internal/c;

# interfaces
.implements Lcom/google/android/gms/common/api/l$b;
.implements Lcom/google/android/gms/common/api/l$c;


# static fields
.field private static final h:Lcom/google/android/gms/common/api/a$a;


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Landroid/os/Handler;

.field private final c:Lcom/google/android/gms/common/api/a$a;

.field private final d:Ljava/util/Set;

.field private final e:Lcom/google/android/gms/common/internal/g;

.field private f:Lcom/google/android/gms/signin/f;

.field private g:Lcom/google/android/gms/common/api/internal/x2;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/signin/e;->c:Lcom/google/android/gms/common/api/a$a;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/gms/common/api/internal/y2;->h:Lcom/google/android/gms/common/api/a$a;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/os/Handler;Lcom/google/android/gms/common/internal/g;)V
    .locals 3
    .param p3    # Lcom/google/android/gms/common/internal/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/gms/common/api/internal/y2;->h:Lcom/google/android/gms/common/api/a$a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/signin/internal/c;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/y2;->a:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/y2;->b:Landroid/os/Handler;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string/jumbo p1, "tostsC l etiiusnnsb nelg neutlm"

    const-string p1, "Sgsinnbtlml nnt lsuoeits  Cteeu"

    const/4 v2, 0x0

    const-string p1, " nnmltl tets sguetmniteloSnbCi "

    const-string p1, "ClientSettings must not be null"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p3, p1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p1, Lcom/google/android/gms/common/internal/g;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/y2;->e:Lcom/google/android/gms/common/internal/g;

    const/4 v2, 0x7

    invoke-virtual {p3}, Lcom/google/android/gms/common/internal/g;->i()Ljava/util/Set;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/y2;->d:Ljava/util/Set;

    const/4 v2, 0x3

    const/4 v1, 0x3

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/y2;->c:Lcom/google/android/gms/common/api/a$a;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method static bridge synthetic o0(Lcom/google/android/gms/common/api/internal/y2;)Lcom/google/android/gms/common/api/internal/x2;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o~~@o ~t @o~@4@bc@~v.@@iSr@@M  o @l~b m Ko @~/~n~ @o1~f@~ ~a ~@slyt-@@f~~ii  ~~~ ~@/~ @bd@  o~@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/y2;->g:Lcom/google/android/gms/common/api/internal/x2;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method static bridge synthetic p0(Lcom/google/android/gms/common/api/internal/y2;Lcom/google/android/gms/signin/internal/zak;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/signin/internal/zak;->y2()Lcom/google/android/gms/common/ConnectionResult;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/common/ConnectionResult;->C2()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/signin/internal/zak;->z2()Lcom/google/android/gms/common/internal/zav;

    move-result-object p1

    const/4 v5, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    check-cast p1, Lcom/google/android/gms/common/internal/zav;

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/zav;->y2()Lcom/google/android/gms/common/ConnectionResult;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/common/ConnectionResult;->C2()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/Exception;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/lang/Exception;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string v2, "IgSCoboodnnmraiti"

    const-string/jumbo v2, "odSmnoiCarintngIo"

    const/4 v5, 0x4

    const-string/jumbo v2, "iinnagurSrooIdnoC"

    const-string v2, "SignInCoordinator"

    const-string v3, "elsaeiip fweevoa nnchuic getru:rdcsSl onet -ciuo"

    const-string v3, "Sdneoir ucacol- itnandwiucuvhoieslc regefe : ste"

    const-string/jumbo v3, "ttuci enqene eru  -ioaolerducvfshsg  ndcil:ewSca"

    const-string v3, "Sign-in succeeded with resolve account failure: "

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v3, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v2, p1, v1}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/y2;->g:Lcom/google/android/gms/common/api/internal/x2;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-interface {p1, v0}, Lcom/google/android/gms/common/api/internal/x2;->c(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v5, 0x0

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/y2;->f:Lcom/google/android/gms/signin/f;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {p0}, Lcom/google/android/gms/common/api/a$f;->disconnect()V

    const/4 v4, 0x6

    move v5, v4

    return-void

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y2;->g:Lcom/google/android/gms/common/api/internal/x2;

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/zav;->z2()Lcom/google/android/gms/common/internal/n;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/y2;->d:Ljava/util/Set;

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-interface {v0, p1, v1}, Lcom/google/android/gms/common/api/internal/x2;->b(Lcom/google/android/gms/common/internal/n;Ljava/util/Set;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/y2;->g:Lcom/google/android/gms/common/api/internal/x2;

    const/4 v5, 0x5

    invoke-interface {p1, v0}, Lcom/google/android/gms/common/api/internal/x2;->c(Lcom/google/android/gms/common/ConnectionResult;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/y2;->f:Lcom/google/android/gms/signin/f;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {p0}, Lcom/google/android/gms/common/api/a$f;->disconnect()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void
.end method


# virtual methods
.method public final a(Landroid/os/Bundle;)V
    .locals 2
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/y2;->f:Lcom/google/android/gms/signin/f;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-interface {p1, p0}, Lcom/google/android/gms/signin/f;->a(Lcom/google/android/gms/signin/internal/e;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public final b(I)V
    .locals 3
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y2;->g:Lcom/google/android/gms/common/api/internal/x2;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/x2;->d(I)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public final c(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y2;->g:Lcom/google/android/gms/common/api/internal/x2;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/x2;->c(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public final h(Lcom/google/android/gms/signin/internal/zak;)V
    .locals 3
    .annotation build Landroidx/annotation/g;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/gms/common/api/internal/w2;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/api/internal/w2;-><init>(Lcom/google/android/gms/common/api/internal/y2;Lcom/google/android/gms/signin/internal/zak;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/y2;->b:Landroid/os/Handler;

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v2, 0x6

    return-void
.end method

.method public final q0(Lcom/google/android/gms/common/api/internal/x2;)V
    .locals 11
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const/4 v10, 0x4

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y2;->f:Lcom/google/android/gms/signin/f;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-eqz v0, :cond_0

    const/4 v10, 0x3

    invoke-interface {v0}, Lcom/google/android/gms/common/api/a$f;->disconnect()V

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y2;->e:Lcom/google/android/gms/common/internal/g;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    const/4 v10, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/internal/g;->o(Ljava/lang/Integer;)V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget-object v2, p0, Lcom/google/android/gms/common/api/internal/y2;->c:Lcom/google/android/gms/common/api/a$a;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-object v3, p0, Lcom/google/android/gms/common/api/internal/y2;->a:Landroid/content/Context;

    const/4 v10, 0x5

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y2;->b:Landroid/os/Handler;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v5, p0, Lcom/google/android/gms/common/api/internal/y2;->e:Lcom/google/android/gms/common/internal/g;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {v0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v4

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v5}, Lcom/google/android/gms/common/internal/g;->k()Lcom/google/android/gms/signin/a;

    move-result-object v6

    move-object v7, p0

    move-object v7, p0

    move-object v7, p0

    move-object v7, p0

    move-object v8, p0

    move-object v8, p0

    move-object v8, p0

    move-object v8, p0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual/range {v2 .. v8}, Lcom/google/android/gms/common/api/a$a;->buildClient(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Ljava/lang/Object;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)Lcom/google/android/gms/common/api/a$f;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/y2;->f:Lcom/google/android/gms/signin/f;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/y2;->g:Lcom/google/android/gms/common/api/internal/x2;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/y2;->d:Ljava/util/Set;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz p1, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-interface {p1}, Ljava/util/Set;->isEmpty()Z

    move-result p1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz p1, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    goto :goto_0

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/y2;->f:Lcom/google/android/gms/signin/f;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-interface {p1}, Lcom/google/android/gms/signin/f;->e()V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    return-void

    :cond_2
    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/y2;->b:Landroid/os/Handler;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    new-instance v0, Lcom/google/android/gms/common/api/internal/v2;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/api/internal/v2;-><init>(Lcom/google/android/gms/common/api/internal/y2;)V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    return-void
.end method

.method public final r0()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/y2;->f:Lcom/google/android/gms/signin/f;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    invoke-interface {v0}, Lcom/google/android/gms/common/api/a$f;->disconnect()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
