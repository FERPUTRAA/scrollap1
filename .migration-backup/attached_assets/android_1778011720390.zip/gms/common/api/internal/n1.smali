.class public final Lcom/google/android/gms/common/api/internal/n1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/f2;
.implements Lcom/google/android/gms/common/api/internal/z3;


# instance fields
.field private final a:Ljava/util/concurrent/locks/Lock;

.field private final b:Ljava/util/concurrent/locks/Condition;

.field private final c:Landroid/content/Context;

.field private final d:Lcom/google/android/gms/common/g;

.field private final e:Lcom/google/android/gms/common/api/internal/m1;

.field final f:Ljava/util/Map;

.field final g:Ljava/util/Map;

.field final h:Lcom/google/android/gms/common/internal/g;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field final i:Ljava/util/Map;

.field final j:Lcom/google/android/gms/common/api/a$a;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private volatile k:Lcom/google/android/gms/common/api/internal/k1;
    .annotation runtime Lm9/c;
    .end annotation
.end field

.field private l:Lcom/google/android/gms/common/ConnectionResult;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field m:I

.field final n:Lcom/google/android/gms/common/api/internal/j1;

.field final o:Lcom/google/android/gms/common/api/internal/d2;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/google/android/gms/common/api/internal/j1;Ljava/util/concurrent/locks/Lock;Landroid/os/Looper;Lcom/google/android/gms/common/g;Ljava/util/Map;Lcom/google/android/gms/common/internal/g;Ljava/util/Map;Lcom/google/android/gms/common/api/a$a;Ljava/util/ArrayList;Lcom/google/android/gms/common/api/internal/d2;)V
    .locals 3
    .param p7    # Lcom/google/android/gms/common/internal/g;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p9    # Lcom/google/android/gms/common/api/a$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->g:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->l:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->c:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p3, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p5, p0, Lcom/google/android/gms/common/api/internal/n1;->d:Lcom/google/android/gms/common/g;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p6, p0, Lcom/google/android/gms/common/api/internal/n1;->f:Ljava/util/Map;

    const/4 v2, 0x4

    iput-object p7, p0, Lcom/google/android/gms/common/api/internal/n1;->h:Lcom/google/android/gms/common/internal/g;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p8, p0, Lcom/google/android/gms/common/api/internal/n1;->i:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object p9, p0, Lcom/google/android/gms/common/api/internal/n1;->j:Lcom/google/android/gms/common/api/a$a;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/n1;->n:Lcom/google/android/gms/common/api/internal/j1;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object p11, p0, Lcom/google/android/gms/common/api/internal/n1;->o:Lcom/google/android/gms/common/api/internal/d2;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {p10}, Ljava/util/List;->size()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p2, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-ge p2, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {p10, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p5

    const/4 v2, 0x5

    const/4 v1, 0x5

    check-cast p5, Lcom/google/android/gms/common/api/internal/y3;

    const/4 v2, 0x6

    invoke-virtual {p5, p0}, Lcom/google/android/gms/common/api/internal/y3;->d(Lcom/google/android/gms/common/api/internal/z3;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    add-int/lit8 p2, p2, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    move v2, v1

    new-instance p1, Lcom/google/android/gms/common/api/internal/m1;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p1, p0, p4}, Lcom/google/android/gms/common/api/internal/m1;-><init>(Lcom/google/android/gms/common/api/internal/n1;Landroid/os/Looper;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->e:Lcom/google/android/gms/common/api/internal/m1;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {p3}, Ljava/util/concurrent/locks/Lock;->newCondition()Ljava/util/concurrent/locks/Condition;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->b:Ljava/util/concurrent/locks/Condition;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance p1, Lcom/google/android/gms/common/api/internal/b1;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p1, p0}, Lcom/google/android/gms/common/api/internal/b1;-><init>(Lcom/google/android/gms/common/api/internal/n1;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method static bridge synthetic c(Lcom/google/android/gms/common/api/internal/n1;)Lcom/google/android/gms/common/api/internal/k1;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " csoKS @i  ~d@@@@ @ @ ~@~f~f@~~vo~  ~~~@i1o4~@@@i~@s-o ~b~bnt @l ~ ~~l~Mt~ m@~a/@/b~~@ oo y@ur. "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p0
.end method

.method static bridge synthetic d(Lcom/google/android/gms/common/api/internal/n1;)Ljava/util/concurrent/locks/Lock;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method


# virtual methods
.method public final X(Lcom/google/android/gms/common/ConnectionResult;Lcom/google/android/gms/common/api/a;Z)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/api/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v1, 0x7

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-interface {v0, p1, p2, p3}, Lcom/google/android/gms/common/api/internal/k1;->d(Lcom/google/android/gms/common/ConnectionResult;Lcom/google/android/gms/common/api/a;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    iget-object p2, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {p2}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    throw p1
.end method

.method public final a(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/k1;->a(Landroid/os/Bundle;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    throw p1
.end method

.method public final b(I)V
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/k1;->e(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    throw p1
.end method

.method public final e()Lcom/google/android/gms/common/ConnectionResult;
    .locals 5
    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/n1;->f()V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    instance-of v0, v0, Lcom/google/android/gms/common/api/internal/a1;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->b:Ljava/util/concurrent/locks/Condition;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Condition;->await()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :catch_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance v0, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/16 v2, 0xf

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v0, v2, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object v0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v4, 0x1

    const/4 v3, 0x1

    instance-of v0, v0, Lcom/google/android/gms/common/api/internal/n0;

    const/4 v4, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget-object v0, Lcom/google/android/gms/common/ConnectionResult;->C:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0

    :cond_1
    const/4 v3, 0x4

    move v4, v3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->l:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v3, 0x0

    move v4, v3

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    return-object v0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v0, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/16 v2, 0xd

    const/4 v3, 0x5

    move v4, v3

    invoke-direct {v0, v2, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    return-object v0
.end method

.method public final f()V
    .locals 3
    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x1

    invoke-interface {v0}, Lcom/google/android/gms/common/api/internal/k1;->c()V

    const/4 v2, 0x5

    return-void
.end method

.method public final g()V
    .locals 3
    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    instance-of v0, v0, Lcom/google/android/gms/common/api/internal/n0;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/gms/common/api/internal/n0;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/n0;->j()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public final h()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public final i()V
    .locals 3
    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {v0}, Lcom/google/android/gms/common/api/internal/k1;->g()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->g:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public final j(Lcom/google/android/gms/common/api/internal/w;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x3

    return p1
.end method

.method public final k(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .locals 7
    .param p2    # Ljava/io/FileDescriptor;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v1, "tesStam"

    const/4 v6, 0x6

    const-string v1, "em=mtSa"

    const-string/jumbo v1, "mState="

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v0

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->i:Ljava/util/Map;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast v2, Lcom/google/android/gms/common/api/a;

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v2}, Lcom/google/android/gms/common/api/a;->d()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x2

    invoke-virtual {v3, v4}, Ljava/io/PrintWriter;->append(Ljava/lang/CharSequence;)Ljava/io/PrintWriter;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const-string v4, ":"

    const-string v4, ":"

    const/4 v6, 0x0

    const-string v4, ":"

    const-string v4, ":"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/google/android/gms/common/api/internal/n1;->f:Ljava/util/Map;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v2}, Lcom/google/android/gms/common/api/a;->b()Lcom/google/android/gms/common/api/a$c;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    check-cast v2, Lcom/google/android/gms/common/api/a$f;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    check-cast v2, Lcom/google/android/gms/common/api/a$f;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v3, "  "

    const-string v3, "  "

    const/4 v6, 0x1

    const-string v3, "  "

    const-string v3, "  "

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-interface {v2, v1, p2, p3, p4}, Lcom/google/android/gms/common/api/a$f;->dump(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_0
    const/4 v6, 0x3

    return-void
.end method

.method public final l(Lcom/google/android/gms/common/api/a;)Lcom/google/android/gms/common/ConnectionResult;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->f:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/a;->b()Lcom/google/android/gms/common/api/a$c;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->f:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast v0, Lcom/google/android/gms/common/api/a$f;

    const/4 v1, 0x6

    move v2, v1

    invoke-interface {v0}, Lcom/google/android/gms/common/api/a$f;->isConnected()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object p1, Lcom/google/android/gms/common/ConnectionResult;->C:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->g:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->g:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    check-cast p1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p1

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p1
.end method

.method public final m()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x4

    instance-of v0, v0, Lcom/google/android/gms/common/api/internal/a1;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public final n(JLjava/util/concurrent/TimeUnit;)Lcom/google/android/gms/common/ConnectionResult;
    .locals 5
    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/n1;->f()V

    const/4 v3, 0x0

    and-int/2addr v4, v3

    invoke-virtual {p3, p1, p2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide p1

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object p3, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    instance-of p3, p3, Lcom/google/android/gms/common/api/internal/a1;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x2

    if-eqz p3, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    cmp-long p3, p1, v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-gtz p3, :cond_0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/common/api/internal/n1;->i()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance p1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v3, 0x3

    move v4, v3

    const/16 p2, 0xe

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p1, p2, v0}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v4, 0x2

    return-object p1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p3, p0, Lcom/google/android/gms/common/api/internal/n1;->b:Ljava/util/concurrent/locks/Condition;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {p3, p1, p2}, Ljava/util/concurrent/locks/Condition;->awaitNanos(J)J

    move-result-wide p1
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :catch_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance p1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/16 p2, 0xf

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {p1, p2, v0}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v3, 0x3

    or-int/2addr v4, v3

    return-object p1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v4, 0x4

    instance-of p1, p1, Lcom/google/android/gms/common/api/internal/n0;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz p1, :cond_2

    const/4 v4, 0x1

    sget-object p1, Lcom/google/android/gms/common/ConnectionResult;->C:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x2

    const/4 v3, 0x7

    return-object p1

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->l:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz p1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object p1

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance p1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/16 p2, 0xd

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {p1, p2, v0}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object p1
.end method

.method public final o(Lcom/google/android/gms/common/api/internal/e$a;)Lcom/google/android/gms/common/api/internal/e$a;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/internal/e$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->zak()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v1, 0x4

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/k1;->f(Lcom/google/android/gms/common/api/internal/e$a;)Lcom/google/android/gms/common/api/internal/e$a;

    const/4 v1, 0x4

    or-int/2addr v2, v1

    return-object p1
.end method

.method public final p()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    instance-of v0, v0, Lcom/google/android/gms/common/api/internal/n0;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method public final q(Lcom/google/android/gms/common/api/internal/e$a;)Lcom/google/android/gms/common/api/internal/e$a;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/internal/e$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lz4/a;
        value = "lock"
    .end annotation

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/BasePendingResult;->zak()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/api/internal/k1;->h(Lcom/google/android/gms/common/api/internal/e$a;)Lcom/google/android/gms/common/api/internal/e$a;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p1
.end method

.method final r()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->n:Lcom/google/android/gms/common/api/internal/j1;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/j1;->R()Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/common/api/internal/n0;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/api/internal/n0;-><init>(Lcom/google/android/gms/common/api/internal/n1;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0}, Lcom/google/android/gms/common/api/internal/k1;->b()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->b:Ljava/util/concurrent/locks/Condition;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Condition;->signalAll()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x5

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    throw v0
.end method

.method final s()V
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    new-instance v0, Lcom/google/android/gms/common/api/internal/a1;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v3, p0, Lcom/google/android/gms/common/api/internal/n1;->h:Lcom/google/android/gms/common/internal/g;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/n1;->i:Ljava/util/Map;

    const/4 v9, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-object v5, p0, Lcom/google/android/gms/common/api/internal/n1;->d:Lcom/google/android/gms/common/g;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-object v6, p0, Lcom/google/android/gms/common/api/internal/n1;->j:Lcom/google/android/gms/common/api/a$a;

    const/4 v10, 0x7

    const/4 v9, 0x2

    iget-object v7, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v9, 0x5

    move v10, v9

    iget-object v8, p0, Lcom/google/android/gms/common/api/internal/n1;->c:Landroid/content/Context;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-direct/range {v1 .. v8}, Lcom/google/android/gms/common/api/internal/a1;-><init>(Lcom/google/android/gms/common/api/internal/n1;Lcom/google/android/gms/common/internal/g;Ljava/util/Map;Lcom/google/android/gms/common/g;Lcom/google/android/gms/common/api/a$a;Ljava/util/concurrent/locks/Lock;Landroid/content/Context;)V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v10, 0x3

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-interface {v0}, Lcom/google/android/gms/common/api/internal/k1;->b()V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->b:Ljava/util/concurrent/locks/Condition;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Condition;->signalAll()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    return-void

    :catchall_0
    move-exception v0

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v10, 0x6

    const/4 v9, 0x7

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v10, 0x1

    throw v0
.end method

.method final t(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->l:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance p1, Lcom/google/android/gms/common/api/internal/b1;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p1, p0}, Lcom/google/android/gms/common/api/internal/b1;-><init>(Lcom/google/android/gms/common/api/internal/n1;)V

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->k:Lcom/google/android/gms/common/api/internal/k1;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {p1}, Lcom/google/android/gms/common/api/internal/k1;->b()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->b:Ljava/util/concurrent/locks/Condition;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {p1}, Ljava/util/concurrent/locks/Condition;->signalAll()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->a:Ljava/util/concurrent/locks/Lock;

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    throw p1
.end method

.method final u(Lcom/google/android/gms/common/api/internal/l1;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->e:Lcom/google/android/gms/common/api/internal/m1;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v1, 0x1

    move v3, v1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v2, 0x4

    move v3, v2

    return-void
.end method

.method final v(Ljava/lang/RuntimeException;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/n1;->e:Lcom/google/android/gms/common/api/internal/m1;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method
