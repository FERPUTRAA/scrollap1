.class final Lcom/google/android/gms/common/api/internal/t0;
.super Lcom/google/android/gms/common/api/internal/z0;


# instance fields
.field private final b:Ljava/util/ArrayList;

.field final synthetic c:Lcom/google/android/gms/common/api/internal/a1;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/internal/a1;Ljava/util/ArrayList;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/api/internal/t0;->c:Lcom/google/android/gms/common/api/internal/a1;

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/api/internal/z0;-><init>(Lcom/google/android/gms/common/api/internal/a1;Lcom/google/android/gms/common/api/internal/y0;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object p2, p0, Lcom/google/android/gms/common/api/internal/t0;->b:Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 8
    .annotation build Landroidx/annotation/l1;
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "S@s i~~cb~ @ @  K m~ -~@s@  yv@@ t~b~@@.@nb @~o@@ o@ 4t~fiu~~~fio /~~1a@/~@~ ~o@~ ~ol~~@lor @@d~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/t0;->c:Lcom/google/android/gms/common/api/internal/a1;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->u(Lcom/google/android/gms/common/api/internal/a1;)Lcom/google/android/gms/common/api/internal/n1;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v1, v1, Lcom/google/android/gms/common/api/internal/n1;->n:Lcom/google/android/gms/common/api/internal/j1;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/api/internal/a1;->y(Lcom/google/android/gms/common/api/internal/a1;)Ljava/util/Set;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    iput-object v0, v1, Lcom/google/android/gms/common/api/internal/j1;->s:Ljava/util/Set;

    const/4 v7, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/api/internal/t0;->b:Ljava/util/ArrayList;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-ge v2, v1, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    check-cast v3, Lcom/google/android/gms/common/api/a$f;

    const/4 v6, 0x3

    move v7, v6

    iget-object v4, p0, Lcom/google/android/gms/common/api/internal/t0;->c:Lcom/google/android/gms/common/api/internal/a1;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v4}, Lcom/google/android/gms/common/api/internal/a1;->w(Lcom/google/android/gms/common/api/internal/a1;)Lcom/google/android/gms/common/internal/n;

    move-result-object v5

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v4}, Lcom/google/android/gms/common/api/internal/a1;->u(Lcom/google/android/gms/common/api/internal/a1;)Lcom/google/android/gms/common/api/internal/n1;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v4, v4, Lcom/google/android/gms/common/api/internal/n1;->n:Lcom/google/android/gms/common/api/internal/j1;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v4, v4, Lcom/google/android/gms/common/api/internal/j1;->s:Ljava/util/Set;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-interface {v3, v5, v4}, Lcom/google/android/gms/common/api/a$f;->getRemoteService(Lcom/google/android/gms/common/internal/n;Ljava/util/Set;)V

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    return-void
.end method
