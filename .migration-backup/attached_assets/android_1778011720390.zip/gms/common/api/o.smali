.class public abstract Lcom/google/android/gms/common/api/o;
.super Lcom/google/android/gms/common/api/p;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<R::",
        "Lcom/google/android/gms/common/api/v;",
        ">",
        "Lcom/google/android/gms/common/api/p<",
        "TR;>;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/api/p;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public abstract a()Lcom/google/android/gms/common/api/v;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TR;"
        }
    .end annotation
.end method

.method public abstract b()Z
.end method
