.class public final Lcom/google/android/gms/common/api/j0;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " ~s@ @co~@i f~nb~bM K~/~s@ar d   ~o.~~@v  i@~ o~ f-o@i@/  @1tot y~@o~@@~u~l~l@ b@@@ ~@4@@~mS~@~~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x7

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v1, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-ge v3, v0, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v3}, Lh4/a;->O(I)I

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v5, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eq v4, v5, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eq v4, v5, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {p1, v3}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {p1, v3}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto :goto_0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {p1, v3}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_0

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    new-instance p1, Lcom/google/android/gms/common/api/Scope;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {p1, v2, v1}, Lcom/google/android/gms/common/api/Scope;-><init>(ILjava/lang/String;)V

    const/4 v6, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    return-object p1
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    new-array p1, p1, [Lcom/google/android/gms/common/api/Scope;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p1
.end method
