.class public final synthetic Lcom/google/android/gms/common/i0;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:Z

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Lcom/google/android/gms/common/n0;


# direct methods
.method public synthetic constructor <init>(ZLjava/lang/String;Lcom/google/android/gms/common/n0;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    iput-boolean p1, p0, Lcom/google/android/gms/common/i0;->a:Z

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/android/gms/common/i0;->b:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/google/android/gms/common/i0;->c:Lcom/google/android/gms/common/n0;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "c@s/oo@ ~d~ o~  ~f@l @f~4o@t~s~@@@ @i.  ~b~@~o ~/@~~@~vi~1@@ ~ m@ or ~b@@bt @~u-M~~ S@n@lK~~ ai "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    iget-boolean v0, p0, Lcom/google/android/gms/common/i0;->a:Z

    const/4 v4, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/i0;->b:Ljava/lang/String;

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/android/gms/common/i0;->c:Lcom/google/android/gms/common/n0;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v0, v1, v2}, Lcom/google/android/gms/common/r0;->d(ZLjava/lang/String;Lcom/google/android/gms/common/n0;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object v0
.end method
