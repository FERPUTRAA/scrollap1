.class public Lcom/google/android/gms/common/d;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation runtime Lcom/google/errorprone/annotations/RestrictedInheritance;
    allowedOnPath = ".*javatests/com/google/android/gmscore/integ/client/common/robolectric/.*"
    explanation = "Sub classing of GMS Core\'s APIs are restricted to testing fakes."
    link = "go/gmscore-restrictedinheritance"
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field private static final a:Lcom/google/android/gms/common/b0;

.field private static final b:Lcom/google/android/gms/common/b0;

.field private static final c:Ljava/util/HashMap;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v0, Lcom/google/android/gms/common/a1;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {v0}, Lcom/google/android/gms/common/a1;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string/jumbo v1, "gosadsgsogonrce..iom.d"

    const-string/jumbo v1, "gmsddnsaecoo.imorg.o.g"

    const/4 v6, 0x1

    const-string v1, ".rgmogidcgolmsaom..edn"

    const-string v1, "com.google.android.gms"

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/a1;->d(Ljava/lang/String;)Lcom/google/android/gms/common/a1;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const-wide/32 v1, 0xc2bd840

    const-wide/32 v1, 0xc2bd840

    const/4 v6, 0x2

    const-wide/32 v1, 0xc2bd840

    const-wide/32 v1, 0xc2bd840

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/common/a1;->a(J)Lcom/google/android/gms/common/a1;

    const/4 v6, 0x1

    sget-object v1, Lcom/google/android/gms/common/r0;->d:Lcom/google/android/gms/common/p0;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/common/p0;->c()[B

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    sget-object v3, Lcom/google/android/gms/common/r0;->b:Lcom/google/android/gms/common/p0;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v3}, Lcom/google/android/gms/common/p0;->c()[B

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v2, v3}, Lcom/google/android/gms/internal/common/zzag;->zzn(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/android/gms/internal/common/zzag;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0, v2}, Lcom/google/android/gms/common/a1;->c(Ljava/util/List;)Lcom/google/android/gms/common/a1;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    sget-object v2, Lcom/google/android/gms/common/r0;->c:Lcom/google/android/gms/common/p0;

    const/4 v6, 0x3

    invoke-virtual {v2}, Lcom/google/android/gms/common/p0;->c()[B

    move-result-object v3

    const/4 v5, 0x1

    move v6, v5

    sget-object v4, Lcom/google/android/gms/common/r0;->a:Lcom/google/android/gms/common/p0;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v4}, Lcom/google/android/gms/common/p0;->c()[B

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v3, v4}, Lcom/google/android/gms/internal/common/zzag;->zzn(Ljava/lang/Object;Ljava/lang/Object;)Lcom/google/android/gms/internal/common/zzag;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0, v3}, Lcom/google/android/gms/common/a1;->b(Ljava/util/List;)Lcom/google/android/gms/common/a1;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0}, Lcom/google/android/gms/common/a1;->e()Lcom/google/android/gms/common/b0;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    sput-object v0, Lcom/google/android/gms/common/d;->a:Lcom/google/android/gms/common/b0;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v0, Lcom/google/android/gms/common/a1;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v0}, Lcom/google/android/gms/common/a1;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo v3, "mdneovaninoddg..moc"

    const-string/jumbo v3, "iormndnn.emvcddago."

    const/4 v6, 0x6

    const-string/jumbo v3, "rn.cgbindedmoainod."

    const-string v3, "com.android.vending"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, v3}, Lcom/google/android/gms/common/a1;->d(Ljava/lang/String;)Lcom/google/android/gms/common/a1;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-wide/32 v3, 0x4e6e200

    const-wide/32 v3, 0x4e6e200

    const/4 v6, 0x4

    const-wide/32 v3, 0x4e6e200

    const-wide/32 v3, 0x4e6e200

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0, v3, v4}, Lcom/google/android/gms/common/a1;->a(J)Lcom/google/android/gms/common/a1;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v1}, Lcom/google/android/gms/common/p0;->c()[B

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v1}, Lcom/google/android/gms/internal/common/zzag;->zzm(Ljava/lang/Object;)Lcom/google/android/gms/internal/common/zzag;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/a1;->c(Ljava/util/List;)Lcom/google/android/gms/common/a1;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v2}, Lcom/google/android/gms/common/p0;->c()[B

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v1}, Lcom/google/android/gms/internal/common/zzag;->zzm(Ljava/lang/Object;)Lcom/google/android/gms/internal/common/zzag;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/a1;->b(Ljava/util/List;)Lcom/google/android/gms/common/a1;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/common/a1;->e()Lcom/google/android/gms/common/b0;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    sput-object v0, Lcom/google/android/gms/common/d;->b:Lcom/google/android/gms/common/b0;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    sput-object v0, Lcom/google/android/gms/common/d;->c:Ljava/util/HashMap;

    const/4 v6, 0x1

    return-void
.end method
