.class public final Lcom/google/android/gms/common/h;
.super Ljava/lang/Exception;


# instance fields
.field public final errorCode:I


# direct methods
.method public constructor <init>(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Exception;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/common/h;->errorCode:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method
