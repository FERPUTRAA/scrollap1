.class public Lcom/google/android/gms/common/k;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final a:I = 0xbdfcb8
    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "com.google.android.gms"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final c:Ljava/lang/String; = "com.google.android.play.games"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final d:Ljava/lang/String; = "com.android.vending"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field static final e:I = 0x9b6d
    .annotation build Lf4/a;
    .end annotation
.end field

.field static final f:I = 0x28c4
    .annotation build Lf4/a;
    .end annotation
.end field

.field static final g:Ljava/util/concurrent/atomic/AtomicBoolean;
    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field private static h:Z

.field static i:Z
    .annotation build Landroidx/annotation/k1;
    .end annotation
.end field

.field private static final j:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/gms/common/k;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    sput-object v0, Lcom/google/android/gms/common/k;->j:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method constructor <init>()V
    .locals 2
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Lcom/google/android/gms/common/k;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x5

    const/4 v1, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v0, "onsfititosna"

    const-string/jumbo v0, "oisnnotiatif"

    const-string/jumbo v0, "fiimaictonon"

    const-string/jumbo v0, "notification"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast p0, Landroid/app/NotificationManager;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/16 v0, 0x28c4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/app/NotificationManager;->cancel(I)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :catch_0
    move-exception p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v0, "eGlmaytsocgevePSlrliiU"

    const-string v0, "esGroveSgUiayliotleclP"

    const-string v0, "GooglePlayServicesUtil"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const-string/jumbo v1, "ts aoi.tioeSNrunSiobca ol%fiptcEtnxicep ileAgrvneyEitrrioypisa r unsalcsin"

    const/4 v3, 0x7

    const-string v1, "cittubiploti%ltutpSefciciiy np aanioeagAensiS srcsrvrEi bN rlE.osronxeyanc"

    const-string v1, "Suppressing Security Exception %s in cancelAvailabilityErrorNotifications."

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0, v1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method public static b()V
    .locals 4
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v0, Lcom/google/android/gms/common/k;->j:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const/4 v3, 0x4

    return-void
.end method

.method public static c(Landroid/content/Context;I)V
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/i;,
            Lcom/google/android/gms/common/h;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/gms/common/g;->i()Lcom/google/android/gms/common/g;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, p0, p1}, Lcom/google/android/gms/common/g;->k(Landroid/content/Context;I)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    const-string v0, "e"

    const/4 v3, 0x0

    const-string v0, "e"

    const-string v0, "e"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/android/gms/common/g;->i()Lcom/google/android/gms/common/g;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v1, p0, p1, v0}, Lcom/google/android/gms/common/g;->e(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x4

    move v3, v2

    const-string/jumbo v1, "rv Go uS lec Pearlerlodt aoasbeley vaerigbntoi"

    const-string v1, " la rbbeaiS  ruoclserieatdtoolPlGr gvoevenya e"

    const/4 v3, 0x6

    const-string v1, " e lrgepvoareis varan loder eoPlStue yGtoaobli"

    const-string v1, "GooglePlayServices not available due to error "

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "iaioogvcqeeSPtGUrlluys"

    const-string v1, "cUeliiuorsGevoPSlgeaty"

    const/4 v3, 0x7

    const-string v1, "PasUievsllyoogelecirtG"

    const-string v1, "GooglePlayServicesUtil"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance p0, Lcom/google/android/gms/common/h;

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/h;-><init>(I)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    throw p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/common/i;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo v1, "llcm ia apoavlrGsgyS ievaeoPnlee t"

    const-string v1, " oG asnpevceiygeoPblaavrlS lleta i"

    const/4 v3, 0x4

    const-string v1, "aovbo rya alieesSlnoe tl aGvlPegic"

    const-string v1, "Google Play Services not available"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, p1, v1, p0}, Lcom/google/android/gms/common/i;-><init>(ILjava/lang/String;Landroid/content/Intent;)V

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    throw v0

    :cond_1
    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method public static d(Landroid/content/Context;)I
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, "docqnboodsmaig.g..emor"

    const-string v1, "c.sggnmiqoom.dgeoa.odr"

    const/4 v3, 0x2

    const-string v1, "com.google.android.gms"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, v1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget p0, p0, Landroid/content/pm/PackageInfo;->versionCode:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return p0

    :catch_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string p0, "eeeUoiulvSilPsclGyotsa"

    const-string/jumbo p0, "icstglysGolaeiePevlSoU"

    const/4 v3, 0x7

    const-string p0, "acGoUsgpPlitrlilyeSeve"

    const-string p0, "GooglePlayServicesUtil"

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string v1, "emsiecagq seiiP g sros.ylnGoil s"

    const-string v1, ".egmiGglncrs oassoPiliisey s  em"

    const/4 v3, 0x6

    const-string v1, " esGsgsgamoclniePsvssrio  iyil. "

    const-string v1, "Google Play services is missing."

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v0
.end method

.method public static e(Landroid/content/Context;)I
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->x(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/android/gms/common/util/e;->a(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return p0
.end method

.method public static f(ILandroid/content/Context;I)Landroid/app/PendingIntent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/l;
        imports = {
            "com.google.android.gms.common.GoogleApiAvailabilityLight"
        }
        replacement = "GoogleApiAvailabilityLight.getInstance().getErrorResolutionPendingIntent(context, errorCode, requestCode)"
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/android/gms/common/g;->i()Lcom/google/android/gms/common/g;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p0, p2}, Lcom/google/android/gms/common/g;->f(Landroid/content/Context;II)Landroid/app/PendingIntent;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public static g(I)Ljava/lang/String;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/ConnectionResult;->E2(I)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method

.method public static h(I)Landroid/content/Intent;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/l;
        imports = {
            "com.google.android.gms.common.GoogleApiAvailabilityLight"
        }
        replacement = "GoogleApiAvailabilityLight.getInstance().getErrorResolutionIntent(null, errorCode, null)"
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/android/gms/common/g;->i()Lcom/google/android/gms/common/g;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1, p0, v1}, Lcom/google/android/gms/common/g;->e(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p0
.end method

.method public static i(Landroid/content/Context;)Landroid/content/Context;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v0, "olsmmoda..cmgrogiged.o"

    const-string/jumbo v0, "ondro..gieslogdmocma.g"

    const/4 v3, 0x2

    const-string/jumbo v0, "onclorogg.ooa.dm.gedmi"

    const-string v0, "com.google.android.gms"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object p0

    :catch_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x6

    move v3, v2

    return-object p0
.end method

.method public static j(Landroid/content/Context;)Landroid/content/res/Resources;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, "egdlrb.o.ga.bmmgcoisod"

    const-string v0, "d.sgcblmaigog.medoroo."

    const/4 v2, 0x6

    const-string v0, ".soooiu.g.modlggdearnm"

    const-string v0, "com.google.android.gms"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->getResourcesForApplication(Ljava/lang/String;)Landroid/content/res/Resources;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0

    :catch_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0
.end method

.method public static k(Landroid/content/Context;)Z
    .locals 7
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    sget-boolean v0, Lcom/google/android/gms/common/k;->i:Z

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x2

    shl-int/2addr v6, v5

    const/4 v2, 0x1

    move v6, v2

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    if-nez v0, :cond_1

    :try_start_0
    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {p0}, Lcom/google/android/gms/common/wrappers/d;->a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v3, "c.oruoapmmd.oggli.ogne"

    const-string/jumbo v3, "lgo.ooucg.desg.mioamrn"

    const/4 v6, 0x4

    const-string/jumbo v3, "roeo.gi.q.ldcsnmmogogd"

    const-string v3, "com.google.android.gms"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/16 v4, 0x40

    const/4 v6, 0x3

    invoke-virtual {v0, v3, v4}, Lcom/google/android/gms/common/wrappers/c;->f(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-static {p0}, Lcom/google/android/gms/common/l;->a(Landroid/content/Context;)Lcom/google/android/gms/common/l;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v0, v1}, Lcom/google/android/gms/common/l;->f(Landroid/content/pm/PackageInfo;Z)Z

    move-result p0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez p0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0, v2}, Lcom/google/android/gms/common/l;->f(Landroid/content/pm/PackageInfo;Z)Z

    move-result p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz p0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    sput-boolean v2, Lcom/google/android/gms/common/k;->h:Z

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    sput-boolean v1, Lcom/google/android/gms/common/k;->h:Z
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    sput-boolean v2, Lcom/google/android/gms/common/k;->i:Z

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_2

    :catchall_0
    move-exception p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_1

    :catch_0
    move-exception p0

    :try_start_1
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string/jumbo v0, "leseUoplGiogaslietrPcy"

    const-string/jumbo v0, "oetgcospliiraGveUeylPl"

    const/4 v6, 0x6

    const-string/jumbo v0, "otSmsieorylvlePigleGUa"

    const-string v0, "GooglePlayServicesUtil"

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v3, "iskfotmpeaao g va.asnnaln  qnyreelCedG eogiocc"

    const-string/jumbo v3, "kodeCigaqenaeipGy ta g snPensnel aav.mr occflo"

    const/4 v6, 0x4

    const-string v3, "eo.Pib vaa gskcefms naalayn eprcnCg dtGnoieol "

    const-string v3, "Cannot find Google Play services package name."

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v0, v3, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x1

    const/4 v6, 0x2

    sput-boolean v2, Lcom/google/android/gms/common/k;->i:Z

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_2

    :goto_1
    const/4 v6, 0x7

    sput-boolean v2, Lcom/google/android/gms/common/k;->i:Z

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    throw p0

    :cond_1
    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    sget-boolean p0, Lcom/google/android/gms/common/k;->h:Z

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-nez p0, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {}, Lcom/google/android/gms/common/util/l;->k()Z

    move-result p0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-nez p0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x1

    goto :goto_3

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    return v1

    :cond_3
    :goto_3
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    return v2
.end method

.method public static l(Landroid/content/Context;)I
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/m;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget v0, Lcom/google/android/gms/common/k;->a:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/android/gms/common/k;->m(Landroid/content/Context;I)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p0
.end method

.method public static m(Landroid/content/Context;I)I
    .locals 12
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x3

    const-string v0, "GooglePlayServicesUtil"

    :try_start_0
    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    sget v2, Lcom/google/android/gms/common/R$string;->common_google_play_services_unknown_issue:I

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x3

    const/4 v10, 0x2

    goto :goto_0

    :catchall_0
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string v1, "ceruroufhrs onrtyccyCddsraovuwhg rshote s  aiilroeej.oPuTnnfriscu.o    snues eeiceles cpn cholae  ee gtdr et euuortotaeeotk en"

    const-string/jumbo v1, "sfsrhw .uheCeoiTjt yorrp .eourlh tfa edgckcutyc nP oeeeeeocurnenur elurrn  egdosiaseioo  dionerutosnshsvc ettlrceat  ce  r oas"

    const/4 v11, 0x4

    const-string v1, "esern  pnoornc.cdha Gauc reitvrce alrererc  l trpttujanoys u  uPtoiwuodiruTee  reCelndhosocoseeyktti sg.sooneseeo fe  f uechgr"

    const-string v1, "The Google Play services resources were not found. Check your project configuration to ensure that the resources are included."

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x4

    const/4 v10, 0x7

    const-string v2, ".omsl.omqdormagdigne.g"

    const-string v2, "doameromng..ilg.odmgsc"

    const/4 v11, 0x1

    const-string/jumbo v2, "o.sdegogscnao.mlgrmo.i"

    const-string v2, "com.google.android.gms"

    const/4 v11, 0x6

    const/4 v10, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-nez v1, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    sget-object v1, Lcom/google/android/gms/common/k;->j:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-eqz v1, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    goto :goto_1

    :cond_0
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {p0}, Lcom/google/android/gms/common/internal/n1;->a(Landroid/content/Context;)I

    move-result v1

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-eqz v1, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    sget v3, Lcom/google/android/gms/common/k;->a:I

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-ne v1, v3, :cond_1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x5

    goto :goto_1

    :cond_1
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    new-instance p0, Lcom/google/android/gms/common/GooglePlayServicesIncorrectManifestValueException;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-direct {p0, v1}, Lcom/google/android/gms/common/GooglePlayServicesIncorrectManifestValueException;-><init>(I)V

    const/4 v10, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    throw p0

    :cond_2
    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x3

    new-instance p0, Lcom/google/android/gms/common/GooglePlayServicesMissingManifestValueException;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/common/GooglePlayServicesMissingManifestValueException;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    throw p0

    :cond_3
    :goto_1
    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->m(Landroid/content/Context;)Z

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    const/4 v3, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    const/4 v4, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-nez v1, :cond_4

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->p(Landroid/content/Context;)Z

    move-result v1

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-nez v1, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    move v1, v3

    move v1, v3

    const/4 v11, 0x7

    move v1, v3

    move v1, v3

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x2

    goto :goto_2

    :cond_4
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    move v1, v4

    move v1, v4

    const/4 v11, 0x7

    move v1, v4

    move v1, v4

    :goto_2
    const/4 v11, 0x4

    const/4 v10, 0x6

    if-ltz p1, :cond_5

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    move v5, v3

    move v5, v3

    const/4 v11, 0x2

    move v5, v3

    move v5, v3

    const/4 v11, 0x3

    const/4 v10, 0x2

    goto :goto_3

    :cond_5
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    move v5, v4

    move v5, v4

    const/4 v11, 0x0

    move v5, v4

    move v5, v4

    :goto_3
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static {v5}, Lcom/google/android/gms/common/internal/v;->a(Z)V

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v6

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x6

    const/16 v7, 0x9

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x7

    if-eqz v1, :cond_6

    :try_start_1
    const/4 v10, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    const-string/jumbo v8, "i.dmcmodiong.ovdena"

    const-string v8, ".iniodgcao.monnvdde"

    const/4 v11, 0x7

    const-string/jumbo v8, "nrnoovgea.mcddnii.d"

    const-string v8, "com.android.vending"

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    const/16 v9, 0x2040

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v6, v8, v9}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v8
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    goto :goto_5

    :catch_0
    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    const-string p1, " s PtbbrGytsu eoeoi t oeerg.,lguisSqhri bem i s ila"

    const-string p1, " oubibuiStieeoP eeytGleot.rigs  rs,mr i tgss h qal "

    const/4 v11, 0x7

    const-string p1, " requires the Google Play Store, but it is missing."

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :goto_4
    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    move v3, v7

    move v3, v7

    const/4 v11, 0x0

    move v3, v7

    move v3, v7

    const/4 v11, 0x2

    const/4 v10, 0x6

    goto/16 :goto_7

    :cond_6
    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    const/4 v8, 0x0

    :goto_5
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    const/16 v9, 0x40

    :try_start_2
    const/4 v10, 0x0

    move v11, v10

    invoke-virtual {v6, v2, v9}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v9
    :try_end_2
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_2 .. :try_end_2} :catch_2

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-static {p0}, Lcom/google/android/gms/common/l;->a(Landroid/content/Context;)Lcom/google/android/gms/common/l;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-static {v9, v3}, Lcom/google/android/gms/common/l;->f(Landroid/content/pm/PackageInfo;Z)Z

    move-result p0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-nez p0, :cond_7

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    const-string/jumbo p1, "rldlheustvPicG ui oeire  baaver i i,ulstst n oqiy gi.uesrnrgeea"

    const-string p1, " requires Google Play services, but their signature is invalid."

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    goto :goto_4

    :cond_7
    const/4 v11, 0x3

    if-eqz v1, :cond_8

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-static {v8}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {v8, v3}, Lcom/google/android/gms/common/l;->f(Landroid/content/pm/PackageInfo;Z)Z

    move-result p0

    const/4 v11, 0x2

    const/4 v10, 0x2

    if-nez p0, :cond_8

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    const-string/jumbo p1, "ue  raupPr aigs  veunlGlo S,rq   tagteiiseodseiliitnbso.ru"

    const-string p1, " Sui vurobluedsat,oeeultgn tsrrt.Pi  iqieiselaosirG a   gn"

    const/4 v11, 0x5

    const-string/jumbo p1, "olv uuSuq , ali riygstiiqgiG ettria beoe.tea nsrnP e lodrs"

    const-string p1, " requires Google Play Store, but its signature is invalid."

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    goto/16 :goto_4

    :cond_8
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x4

    if-eqz v1, :cond_9

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-eqz v8, :cond_9

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget-object p0, v8, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    aget-object p0, p0, v4

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    iget-object v1, v9, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    aget-object v1, v1, v4

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {p0, v1}, Landroid/content/pm/Signature;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-nez p0, :cond_9

    const/4 v11, 0x2

    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    const-string p1, "  so Glaiegyiyp crteeott ive oradtfih tlns n PSusaluleor quGatoe.e/g,/ t sP rstbrsoeeasm go"

    const-string/jumbo p1, "ntaPcyrpsrestatobql  lesloSt/y trleid s anea rfoeieGgs  v ouaG g eioe ,.ou ht oi/smetuPrcgt"

    const/4 v11, 0x6

    const-string/jumbo p1, "utgmt leogb  it ier snerieG/leas qo.u ryoe,eoa aartdnh thscoPv iePocsmtl   /tyoeGStsrlag sf"

    const-string p1, " requires Google Play Store, but its signature doesn\'t match that of Google Play services."

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x3

    const/4 v10, 0x5

    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    goto/16 :goto_4

    :cond_9
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    iget p0, v9, Landroid/content/pm/PackageInfo;->versionCode:I

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-static {p0}, Lcom/google/android/gms/common/util/e0;->a(I)I

    move-result p0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/util/e0;->a(I)I

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-ge p0, v1, :cond_a

    const/4 v11, 0x6

    iget p0, v9, Landroid/content/pm/PackageInfo;->versionCode:I

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-string/jumbo v2, "o frooasoc seqlt irao vgG Pedleyfe  u"

    const-string v2, "eovfg euqrtoclr yd  e ooo saseGiaPlf "

    const/4 v11, 0x1

    const-string v2, " a yPblo roglo ioeaetr  Gevftessfuc o"

    const-string v2, "Google Play services out of date for "

    const/4 v11, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    move v11, v10

    const-string/jumbo v2, "r siuque e R"

    const-string v2, "Rss ue r qei"

    const/4 v11, 0x3

    const-string/jumbo v2, "ueeq .ips Rr"

    const-string v2, ".  Requires "

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    const-string p1, " mutod fqb "

    const-string p1, " obmu uf td"

    const/4 v11, 0x1

    const-string p1, " but found "

    const/4 v11, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    const/4 v3, 0x2

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    goto :goto_7

    :cond_a
    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    iget-object p0, v9, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    if-nez p0, :cond_b

    :try_start_3
    const/4 v10, 0x2

    move v11, v10

    invoke-virtual {v6, v2, v4}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0
    :try_end_3
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_3 .. :try_end_3} :catch_1

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    goto :goto_6

    :catch_1
    move-exception p0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    const-string v1, " gsoeeG l.slere,f rsiwlstue  niiec anegretiirn bamoqt ehgini sp/n/ytaohsvio ptycPug"

    const-string/jumbo v1, "ionoohvolr ese,rqy leeegsriis Ptiiyifgn arGtiepsngugtnlwcistb apeto ea  mc/e.nh / u"

    const/4 v11, 0x4

    const-string/jumbo v1, "o omspoeessesiaeahecqiePitpn/g tott iii inw/  vfngrcgeaiyrreG. hm nsllugnr y  etblu"

    const-string v1, " requires Google Play services, but they\'re missing when getting application info."

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-static {v0, p1, p0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto :goto_7

    :cond_b
    :goto_6
    const/4 v11, 0x6

    const/4 v10, 0x5

    iget-boolean p0, p0, Landroid/content/pm/ApplicationInfo;->enabled:Z

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-nez p0, :cond_c

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/4 v3, 0x3

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    goto :goto_7

    :cond_c
    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    return v4

    :catch_2
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-string p1, "chsgoutqn sev buy r .et mibleirraorii seeyg,sePG l as"

    const-string p1, " GPlibtgoeihvcyie .s sers lrrmeryasu b qtsgu,e ia een"

    const/4 v11, 0x7

    const-string/jumbo p1, "meougb oc.sr iey siel sGsatibPsrrr neveteaeq ugh iy l"

    const-string p1, " requires Google Play services, but they are missing."

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :goto_7
    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    return v3
.end method

.method public static n(Landroid/content/Context;I)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/l;
        imports = {
            "com.google.android.gms.common.util.UidVerifier"
        }
        replacement = "UidVerifier.isGooglePlayServicesUid(context, uid)"
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/google/android/gms/common/util/c0;->a(Landroid/content/Context;I)Z

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return p0
.end method

.method public static o(Landroid/content/Context;I)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/16 v0, 0x12

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x1

    move v3, v1

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    if-ne p1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    return v1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-ne p1, v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string p1, "d.amomuogeudsilroco..n"

    const-string/jumbo p1, "lan.oeurdgoodocgmi.m.s"

    const/4 v3, 0x2

    const-string p1, "daool..p.emgoomgisdcgr"

    const-string p1, "com.google.android.gms"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lcom/google/android/gms/common/k;->u(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    return p0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    return p0
.end method

.method public static p(Landroid/content/Context;I)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/16 v0, 0x9

    const/4 v2, 0x7

    if-ne p1, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string/jumbo p1, "vddipedmqi.c.ngnoro"

    const-string/jumbo p1, "vi..nrcpoddigdneonm"

    const/4 v2, 0x0

    const-string p1, "dasgcinroendnm.o.dv"

    const-string p1, "com.android.vending"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, p1}, Lcom/google/android/gms/common/k;->u(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return p0
.end method

.method public static q(Landroid/content/Context;)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x12
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/android/gms/common/util/v;->g()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v0, "erus"

    const-string/jumbo v0, "urse"

    const/4 v3, 0x7

    const-string/jumbo v0, "sreu"

    const-string/jumbo v0, "user"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    check-cast v0, Landroid/os/UserManager;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Landroid/os/UserManager;->getApplicationRestrictions(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "urte"

    const-string/jumbo v0, "true"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string v1, "ci_mrfqleodptirete"

    const-string/jumbo v1, "irofdpteqce_trreli"

    const/4 v3, 0x5

    const-string v1, "et_lodiroceftrpise"

    const-string/jumbo v1, "restricted_profile"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return p0
.end method

.method public static r(Landroid/content/Context;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/l;
        imports = {
            "com.google.android.gms.common.util.DeviceProperties"
        }
        replacement = "DeviceProperties.isSidewinder(context)"
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->g(Landroid/content/Context;)Z

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return p0
.end method

.method public static s(I)Z
    .locals 4
    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eq p0, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eq p0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v1, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eq p0, v1, :cond_0

    const/4 v3, 0x0

    const/16 v1, 0x9

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eq p0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    return p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v0
.end method

.method public static t(Landroid/content/Context;ILjava/lang/String;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x13
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/l;
        imports = {
            "com.google.android.gms.common.util.UidVerifier"
        }
        replacement = "UidVerifier.uidHasPackageName(context, uid, packageName)"
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p1, p2}, Lcom/google/android/gms/common/util/c0;->b(Landroid/content/Context;ILjava/lang/String;)Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p0
.end method

.method static u(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 7
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string/jumbo v0, "lgin.bomdso.sorgecdm.a"

    const-string/jumbo v0, "gosedmnd.r.ooiasmglco."

    const/4 v6, 0x2

    const-string/jumbo v0, "lo.nsduidromooggg.amce"

    const-string v0, "com.google.android.gms"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {}, Lcom/google/android/gms/common/util/v;->j()Z

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v2, 0x1

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x1

    move v5, v3

    move v5, v3

    const/4 v6, 0x1

    if-eqz v1, :cond_1

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/content/pm/PackageManager;->getPackageInstaller()Landroid/content/pm/PackageInstaller;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/content/pm/PackageInstaller;->getAllSessions()Ljava/util/List;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v4, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    check-cast v4, Landroid/content/pm/PackageInstaller$SessionInfo;

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v4}, Landroid/content/pm/PackageInstaller$SessionInfo;->getAppPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eqz v4, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    return v2

    :catch_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    return v3

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/16 v4, 0x2000

    :try_start_1
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v1, p1, v4}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v0, :cond_2

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-boolean p0, p1, Landroid/content/pm/ApplicationInfo;->enabled:Z

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    return p0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x2

    iget-boolean p1, p1, Landroid/content/pm/ApplicationInfo;->enabled:Z

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eqz p1, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p0}, Lcom/google/android/gms/common/k;->q(Landroid/content/Context;)Z

    move-result p0
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-nez p0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    return v2

    :catch_1
    :cond_3
    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    return v3
.end method
