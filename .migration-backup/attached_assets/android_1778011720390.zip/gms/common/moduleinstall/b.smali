.class public final Lcom/google/android/gms/common/moduleinstall/b;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Landroid/app/Activity;)Lcom/google/android/gms/common/moduleinstall/c;
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/moduleinstall/internal/a0;-><init>(Landroid/app/Activity;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object v0
.end method

.method public static b(Landroid/content/Context;)Lcom/google/android/gms/common/moduleinstall/c;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/moduleinstall/internal/a0;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method
