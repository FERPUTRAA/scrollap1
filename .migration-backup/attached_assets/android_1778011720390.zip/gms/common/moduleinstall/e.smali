.class public final Lcom/google/android/gms/common/moduleinstall/e;
.super Lcom/google/android/gms/common/api/h;


# static fields
.field public static final t:I = 0x0

.field public static final u:I = 0xb3b0

.field public static final v:I = 0xb3b1

.field public static final w:I = 0xb3b2

.field public static final x:I = 0xb3b3


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/api/h;-><init>()V

    const/4 v0, 0x1

    shr-int/2addr v1, v0

    return-void
.end method

.method public static a(I)Ljava/lang/String;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o~s~o@m~.@@b ~~y@l i  @ f@b/co~@~/lfK ~@a ~@4u~~  i@otb~~d@~so@@~@   @ ~@t~~1MS v~r @@ i-o@ n~~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    packed-switch p0, :pswitch_data_0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/android/gms/common/api/h;->a(I)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0

    :pswitch_0
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    const-string p0, "SFImAFsEIRSCTEONIG_T"

    const-string p0, "FCsGOI_IRTFEANESTNSI"

    const/4 v1, 0x6

    const-string p0, "FREAoGCOIIUS_TTSFNIN"

    const-string p0, "INSUFFICIENT_STORAGE"

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0

    :pswitch_1
    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    const-string p0, "UNOMDbmOULNDOF__"

    const-string p0, "FN_m_MUONLDUOTDO"

    const/4 v1, 0x3

    const-string p0, "DUO_LOuFDENMU_NT"

    const-string p0, "MODULE_NOT_FOUND"

    const/4 v1, 0x4

    const/4 v0, 0x1

    return-object p0

    :pswitch_2
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    const-string p0, "OMU_LAOpTWOLo_LEDD"

    const-string p0, "AUO_o_DOWOMNDLELLT"

    const/4 v1, 0x4

    const-string p0, "DANE_O_LqDEMULOTOW"

    const-string p0, "NOT_ALLOWED_MODULE"

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0

    :pswitch_3
    const/4 v1, 0x1

    const/4 v0, 0x5

    const-string p0, "NLs_bUEODMOUNK"

    const-string p0, "KNOMEbLON_UUND"

    const/4 v1, 0x0

    const-string p0, "NDWmKNEOUNOUM_"

    const-string p0, "UNKNOWN_MODULE"

    const/4 v1, 0x5

    const/4 v0, 0x3

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0xb3b0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
