.class public final Lcom/google/android/gms/common/moduleinstall/j;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "~vs~~~ ~~@@l@r~~4i@ s@@Sbu ta    @b~@i@~fy~ ~ ~   @c  K@od/@@~ob~/i~~@@l~~@~  m o-o@fnM@o1~@@o.~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x1

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v1, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v2, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    move v4, v1

    move v4, v1

    const/4 v10, 0x7

    move v4, v1

    move v4, v1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    move v5, v4

    move v5, v4

    const/4 v10, 0x5

    move v5, v4

    move v5, v4

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    move v8, v5

    move v8, v5

    const/4 v10, 0x3

    move v8, v5

    move v8, v5

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    if-ge v1, v0, :cond_5

    const/4 v10, 0x6

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {v1}, Lh4/a;->O(I)I

    move-result v2

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v3, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-eq v2, v3, :cond_4

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    const/4 v3, 0x2

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-eq v2, v3, :cond_3

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    const/4 v3, 0x3

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-eq v2, v3, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    const/4 v3, 0x4

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-eq v2, v3, :cond_1

    const/4 v10, 0x7

    const/4 v3, 0x0

    const/4 v10, 0x0

    const/4 v3, 0x5

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-eq v2, v3, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-static {p1, v1}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    goto :goto_0

    :cond_0
    const/4 v9, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v8

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    goto :goto_0

    :cond_1
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {p1, v1}, Lh4/a;->d0(Landroid/os/Parcel;I)Ljava/lang/Long;

    move-result-object v7

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    goto :goto_0

    :cond_2
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {p1, v1}, Lh4/a;->d0(Landroid/os/Parcel;I)Ljava/lang/Long;

    move-result-object v6

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    goto :goto_0

    :cond_3
    const/4 v10, 0x3

    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v5

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    goto :goto_0

    :cond_4
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v4

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto/16 :goto_0

    :cond_5
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    new-instance p1, Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-direct/range {v3 .. v8}, Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;-><init>(IILjava/lang/Long;Ljava/lang/Long;I)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    return-object p1
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    new-array p1, p1, [Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method
