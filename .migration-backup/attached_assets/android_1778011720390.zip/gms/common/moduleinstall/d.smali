.class public final Lcom/google/android/gms/common/moduleinstall/d;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/moduleinstall/d$a;
    }
.end annotation


# instance fields
.field private final a:Ljava/util/List;

.field private final b:Lcom/google/android/gms/common/moduleinstall/a;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final c:Ljava/util/concurrent/Executor;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method synthetic constructor <init>(Ljava/util/List;Lcom/google/android/gms/common/moduleinstall/a;Ljava/util/concurrent/Executor;ZLcom/google/android/gms/common/moduleinstall/h;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    const-string p4, " ssnul Its t.meob unPA"

    const-string/jumbo p4, "nus mAIls b t.ePsnout "

    const/4 v1, 0x2

    const-string p4, " uomnnues .Pl ttbIsl A"

    const-string p4, "APIs must not be null."

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p1, p4}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p4

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    xor-int/lit8 p4, p4, 0x1

    const/4 v1, 0x0

    const-string/jumbo p5, "t m otA smmyt Ppeen.bsI"

    const-string/jumbo p5, "tt.mA    sePmmtnyspeIob"

    const/4 v1, 0x1

    const-string/jumbo p5, "tetpPbeb I A mnuysso.mt"

    const-string p5, "APIs must not be empty."

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p4, p5}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-eqz p3, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    const-string/jumbo p4, "issteeun  x oirsettuncln rs isoh tn.t eleo lentmewLurb u"

    const-string/jumbo p4, "letboesu lt .e r  esnn ereLsuottc ehne ioiwmlrnut sixstn"

    const/4 v1, 0x7

    const-string p4, "e nsul prs.teemxn wulerl t usent h oteibctsLrtoee e nnsi"

    const-string p4, "Listener must not be null when listener executor is set."

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p2, p4}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/moduleinstall/d;->a:Ljava/util/List;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/d;->b:Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p3, p0, Lcom/google/android/gms/common/moduleinstall/d;->c:Ljava/util/concurrent/Executor;

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-void
.end method

.method public static d()Lcom/google/android/gms/common/moduleinstall/d$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "a~oM1~ oq@@@ b~-b~@n@ @ o~l  ~ ~@@/oi@@~ 4~d  i~@/~ ~@~Ksb@@.c@@ ~~tu ivy~@t@~ffo~~ ~ rm @o~~lS@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/d$a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/common/moduleinstall/d$a;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public a()Ljava/util/List;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/android/gms/common/api/n;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/moduleinstall/d;->a:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public b()Lcom/google/android/gms/common/moduleinstall/a;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/moduleinstall/d;->b:Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public c()Ljava/util/concurrent/Executor;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/moduleinstall/d;->c:Ljava/util/concurrent/Executor;

    const/4 v2, 0x3

    return-object v0
.end method
