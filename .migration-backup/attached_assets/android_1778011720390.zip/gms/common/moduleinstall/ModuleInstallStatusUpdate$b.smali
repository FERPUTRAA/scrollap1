.class public Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field private final a:J

.field private final b:J


# direct methods
.method constructor <init>(JJ)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p3, p4}, Lcom/google/android/gms/common/internal/v;->v(J)J

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate$b;->a:J

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-wide p3, p0, Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate$b;->b:J

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ns d@~~~bb~~a@/~b  - ~ oo~@@ @~4cS o@~~t~s.i  @ ~~u@~ili@K~@/  @~@f  vr~@@lt@1 @o fo@~ o~@@~@ym"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate$b;->a:J

    const/4 v3, 0x5

    const/4 v2, 0x0

    return-wide v0
.end method

.method public b()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate$b;->b:J

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-wide v0
.end method
