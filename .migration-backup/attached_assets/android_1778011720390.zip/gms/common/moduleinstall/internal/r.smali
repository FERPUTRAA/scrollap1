.class public final synthetic Lcom/google/android/gms/common/moduleinstall/internal/r;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/v;


# instance fields
.field public final synthetic a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

.field public final synthetic b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/moduleinstall/internal/r;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/r;->b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ns~bld~o~/ f o~ ~  r~oo@lK @c~4@@b~i/M@m~@@a@f  @ v~ @io@s-@ @~@~ ~@t~~@bui~ @1t~~ @ o~.~~S ~@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/b0;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    check-cast p2, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/u;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/r;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0, v1, p2}, Lcom/google/android/gms/common/moduleinstall/internal/u;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/e;->getService()Landroid/os/IInterface;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/h;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/r;->b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, v0, p2, v1}, Lcom/google/android/gms/common/moduleinstall/internal/h;->c(Lcom/google/android/gms/common/moduleinstall/internal/g;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;Lcom/google/android/gms/common/moduleinstall/internal/j;)V

    const/4 v2, 0x2

    or-int/2addr v3, v2

    return-void
.end method
