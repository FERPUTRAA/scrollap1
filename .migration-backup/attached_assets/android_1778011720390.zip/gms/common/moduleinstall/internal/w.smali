.class final Lcom/google/android/gms/common/moduleinstall/internal/w;
.super Lcom/google/android/gms/common/moduleinstall/internal/a;


# instance fields
.field final synthetic a:Ljava/util/concurrent/atomic/AtomicReference;

.field final synthetic b:Lcom/google/android/gms/tasks/TaskCompletionSource;

.field final synthetic c:Lcom/google/android/gms/common/moduleinstall/a;

.field final synthetic d:Lcom/google/android/gms/common/moduleinstall/internal/a0;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Ljava/util/concurrent/atomic/AtomicReference;Lcom/google/android/gms/tasks/TaskCompletionSource;Lcom/google/android/gms/common/moduleinstall/a;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/moduleinstall/internal/w;->d:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/w;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p3, p0, Lcom/google/android/gms/common/moduleinstall/internal/w;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p4, p0, Lcom/google/android/gms/common/moduleinstall/internal/w;->c:Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/common/moduleinstall/internal/a;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final a0(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/common/moduleinstall/ModuleInstallResponse;)V
    .locals 4
    .param p2    # Lcom/google/android/gms/common/moduleinstall/ModuleInstallResponse;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  s~~y~@fl~~  fM d  ~~~aboc~1K~v~o~@@~S@@-  @~ ~t4@@@@@  @~~ ~o~/ ~@ilb @bi@~@@mt@n. o~@ors@/ iu"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    if-eqz p2, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/moduleinstall/internal/w;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/w;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/common/api/internal/b0;->d(Lcom/google/android/gms/common/api/Status;Ljava/lang/Object;Lcom/google/android/gms/tasks/TaskCompletionSource;)Z

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/Status;->E2()Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz p1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz p2, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p2}, Lcom/google/android/gms/common/moduleinstall/ModuleInstallResponse;->A2()Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_2
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/moduleinstall/internal/w;->d:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/w;->c:Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-class v0, Lcom/google/android/gms/common/moduleinstall/a;

    const-class v0, Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v3, 0x3

    const-class v0, Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p2, v0}, Lcom/google/android/gms/common/api/internal/o;->c(Ljava/lang/Object;Ljava/lang/String;)Lcom/google/android/gms/common/api/internal/n$a;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/16 v0, 0x6aaa

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, p2, v0}, Lcom/google/android/gms/common/api/k;->doUnregisterEventListener(Lcom/google/android/gms/common/api/internal/n$a;I)Lcom/google/android/gms/tasks/Task;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method
