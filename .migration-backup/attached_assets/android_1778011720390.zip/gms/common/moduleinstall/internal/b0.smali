.class public final Lcom/google/android/gms/common/moduleinstall/internal/b0;
.super Lcom/google/android/gms/common/internal/j;


# direct methods
.method protected constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/16 v3, 0x134

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V

    const/4 v8, 0x6

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ syf io S~d@@ ~@~~ @ lb-@a~~4@@ ~ t~  ~   @r@oit~~~@u@o l1@~ vb@Kbm@~@@@/~n~o~/@i~@~~ .Ms ~fc~o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v0, "mImmgollsasollMnovnlnalorItg.cdemltieSmlo..icerndmngoeasiooriu.une.tds..ac"

    const-string/jumbo v0, "i.s.lmnncdIeenvIslamairmgmlotiouldion.oocdu.l.aelordsSnmonagl.esMetgclotr."

    const/4 v3, 0x1

    const-string/jumbo v0, "ontno.rmasggmMnao.sll.o.iordgdietseedlnd.oouunmnma.cameIelSIccvotelril.lil"

    const-string v0, "com.google.android.gms.common.moduleinstall.internal.IModuleInstallService"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    instance-of v1, v0, Lcom/google/android/gms/common/moduleinstall/internal/h;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/h;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/h;

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/h;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    return-object p1
.end method

.method public final getApiFeatures()[Lcom/google/android/gms/common/Feature;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/google/android/gms/internal/base/zav;->zab:[Lcom/google/android/gms/common/Feature;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x7

    const v0, 0x1110e58

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string/jumbo v0, "roooobg.tslluortmdenengonm..licdldvamacMrgl.oca.nintin.Ismmloedeliual.meIe"

    const-string v0, ".oom.lcIi.lo.slllosodeernn.umedgtnilncoovi.dIemtalomn.mgurmMisaaacdeetlnrg"

    const/4 v2, 0x2

    const-string/jumbo v0, "gau.ceualnnrmmcirSeoddn.tItmaot.ldn...olleIeolelomeiaomlussMvriinnog.loscg"

    const-string v0, "com.google.android.gms.common.moduleinstall.internal.IModuleInstallService"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string/jumbo v0, "vaae.lrpalRo.TrMnl.iS.legdamhoSsidgosretmcsIladuTenon.rodcmntllotncmAeiu.oeg.oiie"

    const-string v0, "ed.lomaorllmsIAov.cds..neomaiucdhSRsil.neggaMaoteeTcornold.oirtunmein.eTllriaS.gt"

    const/4 v2, 0x4

    const-string/jumbo v0, "lSeTioSnqm....lrA.ohau.etRuTtsigaIid.oroenagddalsnlelminsnaMleecodrgvotr.mccoleim"

    const-string v0, "com.google.android.gms.chimera.container.moduleinstall.ModuleInstallService.START"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method protected final getUseDynamicLookup()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public final usesClientTelemetry()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method
