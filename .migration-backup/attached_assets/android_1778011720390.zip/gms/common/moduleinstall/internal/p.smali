.class public final synthetic Lcom/google/android/gms/common/moduleinstall/internal/p;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/v;


# instance fields
.field public final synthetic a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

.field public final synthetic b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V
    .locals 2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/moduleinstall/internal/p;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/p;->b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s~ oy @~~M~nl@~@bo~@.~@ r@o@@b @@v-  c~@o~ sual @@m ~d~~@@~ if~ i  /~~@i  1~@ot@~4t@oKbS/f ~~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/b0;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    check-cast p2, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/y;

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/p;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {v0, v1, p2}, Lcom/google/android/gms/common/moduleinstall/internal/y;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/e;->getService()Landroid/os/IInterface;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/h;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/p;->b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-virtual {p1, v0, p2}, Lcom/google/android/gms/common/moduleinstall/internal/h;->b(Lcom/google/android/gms/common/moduleinstall/internal/g;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method
