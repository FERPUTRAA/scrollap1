.class public final synthetic Lcom/google/android/gms/common/moduleinstall/internal/l;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/v;


# instance fields
.field public final synthetic a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

.field public final synthetic b:Lcom/google/android/gms/common/moduleinstall/internal/c;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/common/moduleinstall/internal/c;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/moduleinstall/internal/l;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/l;->b:Lcom/google/android/gms/common/moduleinstall/internal/c;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "nts~@~/~@mf@lu. @ @~@-v1~@~ b~y 4~ d~fo  /io@l ~ @o i~@K@rs@~~~ti~~~~b~  oa~ @@M@b@ @@@oS~ c~  @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/b0;

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast p2, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/x;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/l;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v0, v1, p2}, Lcom/google/android/gms/common/moduleinstall/internal/x;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/e;->getService()Landroid/os/IInterface;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/h;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/l;->b:Lcom/google/android/gms/common/moduleinstall/internal/c;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1, v0, p2}, Lcom/google/android/gms/common/moduleinstall/internal/h;->o0(Lcom/google/android/gms/common/api/internal/k;Lcom/google/android/gms/common/moduleinstall/internal/j;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method
