.class final Lcom/google/android/gms/common/moduleinstall/internal/u;
.super Lcom/google/android/gms/common/moduleinstall/internal/a;


# instance fields
.field final synthetic a:Lcom/google/android/gms/tasks/TaskCompletionSource;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/tasks/TaskCompletionSource;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/u;->a:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/common/moduleinstall/internal/a;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final f0(Lcom/google/android/gms/common/api/Status;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "S@sl~ ~@~  M@~i@@@ @~~~~b~u~f/@s@. ~ birb@v-~@~@~o~t@~ ~/@tm~~f~o c@o  @ do oo n@y@K ~l~ 4@@ 1i "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/u;->a:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x7

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/common/api/internal/b0;->d(Lcom/google/android/gms/common/api/Status;Ljava/lang/Object;Lcom/google/android/gms/tasks/TaskCompletionSource;)Z

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method
