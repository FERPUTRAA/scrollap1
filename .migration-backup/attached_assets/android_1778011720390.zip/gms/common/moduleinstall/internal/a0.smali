.class public final Lcom/google/android/gms/common/moduleinstall/internal/a0;
.super Lcom/google/android/gms/common/api/k;

# interfaces
.implements Lcom/google/android/gms/common/moduleinstall/c;


# static fields
.field private static final d:Lcom/google/android/gms/common/api/a$g;

.field private static final e:Lcom/google/android/gms/common/api/a$a;

.field private static final f:Lcom/google/android/gms/common/api/a;

.field public static final synthetic g:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Lcom/google/android/gms/common/api/a$g;

    invoke-direct {v0}, Lcom/google/android/gms/common/api/a$g;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    sput-object v0, Lcom/google/android/gms/common/moduleinstall/internal/a0;->d:Lcom/google/android/gms/common/api/a$g;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance v1, Lcom/google/android/gms/common/moduleinstall/internal/s;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {v1}, Lcom/google/android/gms/common/moduleinstall/internal/s;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    sput-object v1, Lcom/google/android/gms/common/moduleinstall/internal/a0;->e:Lcom/google/android/gms/common/api/a$a;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-instance v2, Lcom/google/android/gms/common/api/a;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v3, "Ids.tlnllsseaAoIP"

    const-string/jumbo v3, "tlsPlldAoanIIe.sM"

    const/4 v5, 0x4

    const-string v3, "MltmnloP.euaIsIAd"

    const-string v3, "ModuleInstall.API"

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {v2, v3, v1, v0}, Lcom/google/android/gms/common/api/a;-><init>(Ljava/lang/String;Lcom/google/android/gms/common/api/a$a;Lcom/google/android/gms/common/api/a$g;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    sput-object v2, Lcom/google/android/gms/common/moduleinstall/internal/a0;->f:Lcom/google/android/gms/common/api/a;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/app/Activity;)V
    .locals 5

    const/4 v4, 0x5

    sget-object v0, Lcom/google/android/gms/common/moduleinstall/internal/a0;->f:Lcom/google/android/gms/common/api/a;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object v1, Lcom/google/android/gms/common/api/a$d;->j0:Lcom/google/android/gms/common/api/a$d$d;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    sget-object v2, Lcom/google/android/gms/common/api/k$a;->c:Lcom/google/android/gms/common/api/k$a;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {p0, p1, v0, v1, v2}, Lcom/google/android/gms/common/api/k;-><init>(Landroid/app/Activity;Lcom/google/android/gms/common/api/a;Lcom/google/android/gms/common/api/a$d;Lcom/google/android/gms/common/api/k$a;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget-object v0, Lcom/google/android/gms/common/moduleinstall/internal/a0;->f:Lcom/google/android/gms/common/api/a;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    sget-object v1, Lcom/google/android/gms/common/api/a$d;->j0:Lcom/google/android/gms/common/api/a$d$d;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v2, Lcom/google/android/gms/common/api/k$a;->c:Lcom/google/android/gms/common/api/k$a;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {p0, p1, v0, v1, v2}, Lcom/google/android/gms/common/api/k;-><init>(Landroid/content/Context;Lcom/google/android/gms/common/api/a;Lcom/google/android/gms/common/api/a$d;Lcom/google/android/gms/common/api/k$a;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method

.method static final varargs m(Z[Lcom/google/android/gms/common/api/n;)Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " @K o~mt/b~~~ly~v@r@f@ @@oauf@~@ ~@~@cb@ @~  tnio@~ ~@S4sb.~@d~1o~~/~i ~ M@ ~ ~o@li~~   o ~@o -@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    const-string v0, " le qb nsbts. IueemulAoesdRmttPn"

    const-string/jumbo v0, "uRlmneomses tsbe.lt e tI udnqP A"

    const/4 v5, 0x6

    const-string/jumbo v0, "tuIAbtu n eteo m lRude.u nesssqP"

    const-string v0, "Requested APIs must not be null."

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    array-length v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-lez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    move v2, v1

    move v2, v1

    const/4 v5, 0x6

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v3, " nldteiptPia lrl.oMt aniu peOoA edsvaoeploaees"

    const-string v3, "Please provide at least one OptionalModuleApi."

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v2, v3}, Lcom/google/android/gms/common/internal/v;->b(ZLjava/lang/Object;)V

    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-ge v1, v0, :cond_1

    const/4 v5, 0x3

    aget-object v2, p1, v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v3, " Aoe l.eqeb mntIstRq oludsP utn"

    const-string/jumbo v3, "stttoePqRlu  eA.  bd sInoenuelm"

    const/4 v5, 0x3

    const-string/jumbo v3, "nAs.stbldeqPntIRe t    uuulemos"

    const-string v3, "Requested API must not be null."

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v2, v3}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p1, p0}, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->A2(Ljava/util/List;Z)Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object p0
.end method


# virtual methods
.method public final c(Lcom/google/android/gms/common/moduleinstall/a;)Lcom/google/android/gms/tasks/Task;
    .locals 3
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/moduleinstall/a;",
            ")",
            "Lcom/google/android/gms/tasks/Task<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-class v0, Lcom/google/android/gms/common/moduleinstall/a;

    const-class v0, Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v2, 0x0

    const-class v0, Lcom/google/android/gms/common/moduleinstall/a;

    const-class v0, Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/google/android/gms/common/api/internal/o;->c(Ljava/lang/Object;Ljava/lang/String;)Lcom/google/android/gms/common/api/internal/n$a;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/16 v0, 0x6aaa

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/google/android/gms/common/api/k;->doUnregisterEventListener(Lcom/google/android/gms/common/api/internal/n$a;I)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p1
.end method

.method public final varargs e([Lcom/google/android/gms/common/api/n;)Lcom/google/android/gms/tasks/Task;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lcom/google/android/gms/common/api/n;",
            ")",
            "Lcom/google/android/gms/tasks/Task<",
            "Lcom/google/android/gms/common/moduleinstall/ModuleInstallIntentResponse;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/a0;->m(Z[Lcom/google/android/gms/common/api/n;)Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->z2()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    new-instance p1, Lcom/google/android/gms/common/moduleinstall/ModuleInstallIntentResponse;

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x6

    shr-int/2addr v4, v0

    const/4 v5, 0x0

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/moduleinstall/ModuleInstallIntentResponse;-><init>(Landroid/app/PendingIntent;)V

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    invoke-static {p1}, Lcom/google/android/gms/tasks/Tasks;->forResult(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-object p1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/android/gms/common/api/internal/a0;->a()Lcom/google/android/gms/common/api/internal/a0$a;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-array v0, v0, [Lcom/google/android/gms/common/Feature;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object v3, Lcom/google/android/gms/internal/base/zav;->zaa:Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x5

    move v5, v4

    aput-object v3, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->e([Lcom/google/android/gms/common/Feature;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/16 v0, 0x6aab

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->f(I)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/p;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/p;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->c(Lcom/google/android/gms/common/api/internal/v;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/internal/a0$a;->a()Lcom/google/android/gms/common/api/internal/a0;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/k;->doRead(Lcom/google/android/gms/common/api/internal/a0;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    return-object p1
.end method

.method public final varargs f([Lcom/google/android/gms/common/api/n;)Lcom/google/android/gms/tasks/Task;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lcom/google/android/gms/common/api/n;",
            ")",
            "Lcom/google/android/gms/tasks/Task<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x5

    invoke-static {v0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/a0;->m(Z[Lcom/google/android/gms/common/api/n;)Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->z2()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 p1, 0x0

    move v5, p1

    invoke-static {p1}, Lcom/google/android/gms/tasks/Tasks;->forResult(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {}, Lcom/google/android/gms/common/api/internal/a0;->a()Lcom/google/android/gms/common/api/internal/a0$a;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-array v2, v2, [Lcom/google/android/gms/common/Feature;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget-object v3, Lcom/google/android/gms/internal/base/zav;->zaa:Lcom/google/android/gms/common/Feature;

    const/4 v5, 0x3

    aput-object v3, v2, v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Lcom/google/android/gms/common/api/internal/a0$a;->e([Lcom/google/android/gms/common/Feature;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/16 v2, 0x6aa7

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Lcom/google/android/gms/common/api/internal/a0$a;->f(I)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->d(Z)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/o;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/o;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->c(Lcom/google/android/gms/common/api/internal/v;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/internal/a0$a;->a()Lcom/google/android/gms/common/api/internal/a0;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/k;->doRead(Lcom/google/android/gms/common/api/internal/a0;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-object p1
.end method

.method public final varargs g([Lcom/google/android/gms/common/api/n;)Lcom/google/android/gms/tasks/Task;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lcom/google/android/gms/common/api/n;",
            ")",
            "Lcom/google/android/gms/tasks/Task<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/a0;->m(Z[Lcom/google/android/gms/common/api/n;)Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->z2()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p1}, Lcom/google/android/gms/tasks/Tasks;->forResult(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    invoke-static {}, Lcom/google/android/gms/common/api/internal/a0;->a()Lcom/google/android/gms/common/api/internal/a0$a;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-array v2, v2, [Lcom/google/android/gms/common/Feature;

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    sget-object v3, Lcom/google/android/gms/internal/base/zav;->zaa:Lcom/google/android/gms/common/Feature;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    aput-object v3, v2, v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Lcom/google/android/gms/common/api/internal/a0$a;->e([Lcom/google/android/gms/common/Feature;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/16 v2, 0x6aa6

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Lcom/google/android/gms/common/api/internal/a0$a;->f(I)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->d(Z)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/r;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/r;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->c(Lcom/google/android/gms/common/api/internal/v;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/internal/a0$a;->a()Lcom/google/android/gms/common/api/internal/a0;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/k;->doRead(Lcom/google/android/gms/common/api/internal/a0;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object p1
.end method

.method public final h(Lcom/google/android/gms/common/moduleinstall/d;)Lcom/google/android/gms/tasks/Task;
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/moduleinstall/d;",
            ")",
            "Lcom/google/android/gms/tasks/Task<",
            "Lcom/google/android/gms/common/moduleinstall/ModuleInstallResponse;",
            ">;"
        }
    .end annotation

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->y2(Lcom/google/android/gms/common/moduleinstall/d;)Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    move-result-object v4

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/moduleinstall/d;->b()Lcom/google/android/gms/common/moduleinstall/a;

    move-result-object v3

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/common/moduleinstall/d;->c()Ljava/util/concurrent/Executor;

    move-result-object p1

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-virtual {v4}, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->z2()Ljava/util/List;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x7

    const/4 v6, 0x0

    const/4 v11, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x4

    if-eqz v0, :cond_0

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    new-instance p1, Lcom/google/android/gms/common/moduleinstall/ModuleInstallResponse;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-direct {p1, v6}, Lcom/google/android/gms/common/moduleinstall/ModuleInstallResponse;-><init>(I)V

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-static {p1}, Lcom/google/android/gms/tasks/Tasks;->forResult(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x5

    goto/16 :goto_1

    :cond_0
    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v7, 0x1

    move v12, v7

    const/4 v11, 0x2

    shr-int/2addr v12, v11

    if-nez v3, :cond_1

    const/4 v12, 0x1

    const/4 v11, 0x0

    invoke-static {}, Lcom/google/android/gms/common/api/internal/a0;->a()Lcom/google/android/gms/common/api/internal/a0$a;

    move-result-object p1

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x6

    new-array v0, v7, [Lcom/google/android/gms/common/Feature;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    sget-object v1, Lcom/google/android/gms/internal/base/zav;->zaa:Lcom/google/android/gms/common/Feature;

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    aput-object v1, v0, v6

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->e([Lcom/google/android/gms/common/Feature;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-virtual {p1, v7}, Lcom/google/android/gms/common/api/internal/a0$a;->d(Z)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    const/16 v0, 0x6aa8

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->f(I)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x7

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/q;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-direct {v0, p0, v4}, Lcom/google/android/gms/common/moduleinstall/internal/q;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->c(Lcom/google/android/gms/common/api/internal/v;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/a0$a;->a()Lcom/google/android/gms/common/api/internal/a0;

    move-result-object p1

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/k;->doRead(Lcom/google/android/gms/common/api/internal/a0;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x7

    goto/16 :goto_1

    :cond_1
    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-static {v3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const-class v0, Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v12, 0x1

    const-class v0, Lcom/google/android/gms/common/moduleinstall/a;

    const-class v0, Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x3

    if-nez p1, :cond_2

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {p0, v3, p1}, Lcom/google/android/gms/common/api/k;->registerListener(Ljava/lang/Object;Ljava/lang/String;)Lcom/google/android/gms/common/api/internal/n;

    move-result-object p1

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    goto :goto_0

    :cond_2
    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-static {v3, p1, v0}, Lcom/google/android/gms/common/api/internal/o;->b(Ljava/lang/Object;Ljava/util/concurrent/Executor;Ljava/lang/String;)Lcom/google/android/gms/common/api/internal/n;

    move-result-object p1

    :goto_0
    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    new-instance v8, Lcom/google/android/gms/common/moduleinstall/internal/c;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-direct {v8, p1}, Lcom/google/android/gms/common/moduleinstall/internal/c;-><init>(Lcom/google/android/gms/common/api/internal/n;)V

    const/4 v12, 0x7

    const/4 v11, 0x6

    new-instance v9, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-direct {v9}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x6

    new-instance v10, Lcom/google/android/gms/common/moduleinstall/internal/k;

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, v9

    move-object v2, v9

    move-object v2, v9

    move-object v2, v9

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/moduleinstall/internal/k;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Ljava/util/concurrent/atomic/AtomicReference;Lcom/google/android/gms/common/moduleinstall/a;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;Lcom/google/android/gms/common/moduleinstall/internal/c;)V

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/l;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-direct {v0, p0, v8}, Lcom/google/android/gms/common/moduleinstall/internal/l;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/common/moduleinstall/internal/c;)V

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-static {}, Lcom/google/android/gms/common/api/internal/u;->a()Lcom/google/android/gms/common/api/internal/u$a;

    move-result-object v1

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v1, p1}, Lcom/google/android/gms/common/api/internal/u$a;->h(Lcom/google/android/gms/common/api/internal/n;)Lcom/google/android/gms/common/api/internal/u$a;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x2

    new-array p1, v7, [Lcom/google/android/gms/common/Feature;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x3

    sget-object v2, Lcom/google/android/gms/internal/base/zav;->zaa:Lcom/google/android/gms/common/Feature;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    aput-object v2, p1, v6

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {v1, p1}, Lcom/google/android/gms/common/api/internal/u$a;->e([Lcom/google/android/gms/common/Feature;)Lcom/google/android/gms/common/api/internal/u$a;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-virtual {v1, v7}, Lcom/google/android/gms/common/api/internal/u$a;->d(Z)Lcom/google/android/gms/common/api/internal/u$a;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-virtual {v1, v10}, Lcom/google/android/gms/common/api/internal/u$a;->c(Lcom/google/android/gms/common/api/internal/v;)Lcom/google/android/gms/common/api/internal/u$a;

    const/4 v12, 0x7

    const/4 v11, 0x1

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/u$a;->g(Lcom/google/android/gms/common/api/internal/v;)Lcom/google/android/gms/common/api/internal/u$a;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x7

    const/16 p1, 0x6aa9

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-virtual {v1, p1}, Lcom/google/android/gms/common/api/internal/u$a;->f(I)Lcom/google/android/gms/common/api/internal/u$a;

    const/4 v12, 0x6

    const/4 v11, 0x2

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/internal/u$a;->a()Lcom/google/android/gms/common/api/internal/u;

    move-result-object p1

    const/4 v12, 0x5

    const/4 v11, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/k;->doRegisterEventListener(Lcom/google/android/gms/common/api/internal/u;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x7

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/m;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-direct {v0, v9}, Lcom/google/android/gms/common/moduleinstall/internal/m;-><init>(Ljava/util/concurrent/atomic/AtomicReference;)V

    const/4 v12, 0x4

    const/4 v11, 0x3

    invoke-virtual {p1, v0}, Lcom/google/android/gms/tasks/Task;->onSuccessTask(Lcom/google/android/gms/tasks/SuccessContinuation;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    :goto_1
    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    return-object p1
.end method

.method public final varargs i([Lcom/google/android/gms/common/api/n;)Lcom/google/android/gms/tasks/Task;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lcom/google/android/gms/common/api/n;",
            ")",
            "Lcom/google/android/gms/tasks/Task<",
            "Lcom/google/android/gms/common/moduleinstall/ModuleAvailabilityResponse;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/a0;->m(Z[Lcom/google/android/gms/common/api/n;)Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->z2()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x1

    move v5, v2

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    new-instance p1, Lcom/google/android/gms/common/moduleinstall/ModuleAvailabilityResponse;

    const/4 v5, 0x7

    invoke-direct {p1, v2, v0}, Lcom/google/android/gms/common/moduleinstall/ModuleAvailabilityResponse;-><init>(ZI)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/google/android/gms/tasks/Tasks;->forResult(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-object p1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Lcom/google/android/gms/common/api/internal/a0;->a()Lcom/google/android/gms/common/api/internal/a0$a;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-array v2, v2, [Lcom/google/android/gms/common/Feature;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    sget-object v3, Lcom/google/android/gms/internal/base/zav;->zaa:Lcom/google/android/gms/common/Feature;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    aput-object v3, v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Lcom/google/android/gms/common/api/internal/a0$a;->e([Lcom/google/android/gms/common/Feature;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/16 v2, 0x6aa5

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Lcom/google/android/gms/common/api/internal/a0$a;->f(I)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->d(Z)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/n;

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/n;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/api/internal/a0$a;->c(Lcom/google/android/gms/common/api/internal/v;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/internal/a0$a;->a()Lcom/google/android/gms/common/api/internal/a0;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/k;->doRead(Lcom/google/android/gms/common/api/internal/a0;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object p1
.end method
