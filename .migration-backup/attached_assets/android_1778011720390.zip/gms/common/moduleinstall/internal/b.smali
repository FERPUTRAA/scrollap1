.class final Lcom/google/android/gms/common/moduleinstall/internal/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/n$b;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/moduleinstall/internal/c;Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/b;->a:Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@os@@~~o~@ ts/@vobc1fal@@  o@by~ ~i~~    .~@~rd~ i 4fb~S@-~Mo~u@~nt/m~@l i @@ ~@~~~~ ~~@@@@ K@o "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/moduleinstall/internal/b;->a:Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {p1, v0}, Lcom/google/android/gms/common/moduleinstall/a;->a(Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public final b()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method
