.class final Lcom/google/android/gms/common/moduleinstall/internal/c;
.super Lcom/google/android/gms/common/moduleinstall/internal/i;


# instance fields
.field private final a:Lcom/google/android/gms/common/api/internal/n;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/internal/n;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/common/moduleinstall/internal/i;-><init>()V

    const/4 v0, 0x1

    shr-int/2addr v1, v0

    iput-object p1, p0, Lcom/google/android/gms/common/moduleinstall/internal/c;->a:Lcom/google/android/gms/common/api/internal/n;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final e0(Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s~a@~ o@l@~~~s@lto~m @ @@ @/~@@~ @u@ ~~K~or@~b ov ~c~ @~ i~4 ~~f@.do/ii@@Sf@~yo~1-tM @n ~b   b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/b;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/b;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/c;Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/moduleinstall/internal/c;->a:Lcom/google/android/gms/common/api/internal/n;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/api/internal/n;->d(Lcom/google/android/gms/common/api/internal/n$b;)V

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method
