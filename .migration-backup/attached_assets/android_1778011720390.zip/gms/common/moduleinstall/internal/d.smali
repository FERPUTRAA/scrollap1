.class public final synthetic Lcom/google/android/gms/common/moduleinstall/internal/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# static fields
.field public static final synthetic a:Lcom/google/android/gms/common/moduleinstall/internal/d;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/d;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/common/moduleinstall/internal/d;-><init>()V

    const/4 v2, 0x3

    sput-object v0, Lcom/google/android/gms/common/moduleinstall/internal/d;->a:Lcom/google/android/gms/common/moduleinstall/internal/d;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method private synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s yS @ o@n~~f@~-/@~@~d@@~ia@o~@~i~im @K~o~Mo@ ~ @bs~@ 1/~@v4  f@~l~l@@o@o~r     @@t~b .~ub ~tc"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    check-cast p1, Lcom/google/android/gms/common/Feature;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast p2, Lcom/google/android/gms/common/Feature;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/Feature;->y2()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p2}, Lcom/google/android/gms/common/Feature;->y2()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/google/android/gms/common/Feature;->y2()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p2}, Lcom/google/android/gms/common/Feature;->y2()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/Feature;->z2()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/common/Feature;->z2()J

    move-result-wide p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    cmp-long p1, v0, p1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return p1
.end method
