.class final Lcom/google/android/gms/common/moduleinstall/internal/z;
.super Lcom/google/android/gms/common/api/internal/k$a;


# instance fields
.field final synthetic a:Lcom/google/android/gms/tasks/TaskCompletionSource;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/tasks/TaskCompletionSource;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/z;->a:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v0, 0x1

    and-int/2addr v1, v0

    invoke-direct {p0}, Lcom/google/android/gms/common/api/internal/k$a;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final onResult(Lcom/google/android/gms/common/api/Status;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s~-~/ii~@~~ .~ ~~@ nrl  ~4@@~@v@u~@ais~Mobmyo~/  @K  @1~@@bb c o~o@ @~~@o @@S~@d@~ ~f~  @t@lto"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/z;->a:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x7

    move v3, v2

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/common/api/internal/b0;->d(Lcom/google/android/gms/common/api/Status;Ljava/lang/Object;Lcom/google/android/gms/tasks/TaskCompletionSource;)Z

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method
