.class public Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "ApiFeatureRequestCreator"
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;",
            ">;"
        }
    .end annotation
.end field

.field private static final e:Ljava/util/Comparator;


# instance fields
.field private final a:Ljava/util/List;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getApiFeatures"
        id = 0x1
    .end annotation
.end field

.field private final b:Z
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getIsUrgent"
        id = 0x2
    .end annotation
.end field

.field private final c:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getFeatureRequestSessionId"
        id = 0x3
    .end annotation
.end field

.field private final d:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getCallingPackage"
        id = 0x4
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/e;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/common/moduleinstall/internal/e;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    sput-object v0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/common/moduleinstall/internal/d;->a:Lcom/google/android/gms/common/moduleinstall/internal/d;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->e:Ljava/util/Comparator;

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Ljava/util/List;ZLjava/lang/String;Ljava/lang/String;)V
    .locals 2
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation

        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # Z
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation

        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation

        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x4
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->a:Ljava/util/List;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-boolean p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->b:Z

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->c:Ljava/lang/String;

    const/4 v0, 0x0

    xor-int/2addr v1, v0

    iput-object p4, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->d:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method static A2(Ljava/util/List;Z)Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@Msof ~@sld@o ~~~ ~uy f@o~o @@ @ ni@b~  @ ~~  @@ -@cor @ ~~~~ta~/~@@.~~~o@ i@bb~@~v~@il/4 S@~K1t"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    new-instance v0, Ljava/util/TreeSet;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object v1, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->e:Ljava/util/Comparator;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/util/TreeSet;-><init>(Ljava/util/Comparator;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v1, Lcom/google/android/gms/common/api/n;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {v1}, Lcom/google/android/gms/common/api/n;->a()[Lcom/google/android/gms/common/Feature;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0, v1}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    new-instance p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v3, 0x7

    const/4 v2, 0x5

    new-instance v1, Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0, v1, p1, v0, v0}, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;-><init>(Ljava/util/List;ZLjava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p0
.end method

.method public static y2(Lcom/google/android/gms/common/moduleinstall/d;)Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;
    .locals 3
    .param p0    # Lcom/google/android/gms/common/moduleinstall/d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/common/moduleinstall/d;->a()Ljava/util/List;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->A2(Ljava/util/List;Z)Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x2

    if-nez p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    instance-of v1, p1, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    return v0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v4, 0x2

    iget-boolean v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->b:Z

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-boolean v2, p1, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->b:Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-ne v1, v2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->a:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v2, p1, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->a:Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v1, v2}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->c:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v2, p1, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->c:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v1, v2}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->d:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->d:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v1, p1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz p1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    return p1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x7

    return v0
.end method

.method public final hashCode()I
    .locals 5

    const/4 v4, 0x4

    const/4 v0, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x6

    move v4, v3

    iget-boolean v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->b:Z

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v2, 0x0

    xor-int/2addr v4, v2

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    aput-object v1, v0, v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->a:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->c:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v1, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->d:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    aput-object v2, v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/google/android/gms/common/internal/t;->c([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 5
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->z2()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p1, v1, v0, v2}, Lh4/b;->d0(Landroid/os/Parcel;ILjava/util/List;Z)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v0, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x0

    iget-boolean v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->b:Z

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p1, v0, v1}, Lh4/b;->g(Landroid/os/Parcel;IZ)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v0, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->c:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p1, v0, v1, v2}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v0, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->d:Ljava/lang/String;

    const/4 v3, 0x4

    move v4, v3

    invoke-static {p1, v0, v1, v2}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v3, 0x4

    and-int/2addr v4, v3

    invoke-static {p1, p2}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void
.end method

.method public z2()Ljava/util/List;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/android/gms/common/Feature;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;->a:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method
