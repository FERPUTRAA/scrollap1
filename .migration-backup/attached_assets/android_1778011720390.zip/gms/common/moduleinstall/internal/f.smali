.class public abstract Lcom/google/android/gms/common/moduleinstall/internal/f;
.super Lcom/google/android/gms/internal/base/zab;

# interfaces
.implements Lcom/google/android/gms/common/moduleinstall/internal/g;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string/jumbo v0, "gnsl.onIimnm.lcdgnrldmMaabemnim.Colotl.aooradsltlsos.odksceuegoleaiIs.c.ulal"

    const-string v0, "dasrldnam.dmd.Cmo.golbamanmgtag.tcln.urlilcIisMoakIoonsol.icel.uloenlsesleno"

    const/4 v2, 0x7

    const-string v0, ".anmtmod.oidcnaleeooomasleiltnonIoIdllcln..Caa.n.lslm.meiMtusbrruksocggdlgal"

    const-string v0, "com.google.android.gms.common.moduleinstall.internal.IModuleInstallCallbacks"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/base/zab;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method protected final zaa(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@bK~onb~ ~ibo ~ c ~to@~i~1Mv@rSu/ @~~l@os -t4~~@~ @  ~o~  ~@@@@ ~/ y~@i~f fm@@o @@~a@l @ ~o~.d@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    const/4 p3, 0x1

    const/4 v1, 0x0

    if-eq p1, p3, :cond_3

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p4, 0x2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    if-eq p1, p4, :cond_2

    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p4, 0x3

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    if-eq p1, p4, :cond_1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 p4, 0x4

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    if-eq p1, p4, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    return p1

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    sget-object p1, Lcom/google/android/gms/common/api/Status;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p2, p1}, Lcom/google/android/gms/internal/base/zac;->zaa(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    check-cast p1, Lcom/google/android/gms/common/api/Status;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p2}, Lcom/google/android/gms/internal/base/zac;->zab(Landroid/os/Parcel;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-interface {p0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/g;->f0(Lcom/google/android/gms/common/api/Status;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    goto/16 :goto_0

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    sget-object p1, Lcom/google/android/gms/common/api/Status;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p2, p1}, Lcom/google/android/gms/internal/base/zac;->zaa(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    check-cast p1, Lcom/google/android/gms/common/api/Status;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    sget-object p4, Lcom/google/android/gms/common/moduleinstall/ModuleInstallIntentResponse;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x3

    invoke-static {p2, p4}, Lcom/google/android/gms/internal/base/zac;->zaa(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p4

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    check-cast p4, Lcom/google/android/gms/common/moduleinstall/ModuleInstallIntentResponse;

    const/4 v0, 0x7

    move v1, v0

    invoke-static {p2}, Lcom/google/android/gms/internal/base/zac;->zab(Landroid/os/Parcel;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-interface {p0, p1, p4}, Lcom/google/android/gms/common/moduleinstall/internal/g;->j(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/common/moduleinstall/ModuleInstallIntentResponse;)V

    const/4 v1, 0x5

    goto :goto_0

    :cond_2
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    sget-object p1, Lcom/google/android/gms/common/api/Status;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p2, p1}, Lcom/google/android/gms/internal/base/zac;->zaa(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    check-cast p1, Lcom/google/android/gms/common/api/Status;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    sget-object p4, Lcom/google/android/gms/common/moduleinstall/ModuleInstallResponse;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p2, p4}, Lcom/google/android/gms/internal/base/zac;->zaa(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p4

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    check-cast p4, Lcom/google/android/gms/common/moduleinstall/ModuleInstallResponse;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p2}, Lcom/google/android/gms/internal/base/zac;->zab(Landroid/os/Parcel;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-interface {p0, p1, p4}, Lcom/google/android/gms/common/moduleinstall/internal/g;->a0(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/common/moduleinstall/ModuleInstallResponse;)V

    const/4 v1, 0x4

    goto :goto_0

    :cond_3
    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    sget-object p1, Lcom/google/android/gms/common/api/Status;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p2, p1}, Lcom/google/android/gms/internal/base/zac;->zaa(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    check-cast p1, Lcom/google/android/gms/common/api/Status;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    sget-object p4, Lcom/google/android/gms/common/moduleinstall/ModuleAvailabilityResponse;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {p2, p4}, Lcom/google/android/gms/internal/base/zac;->zaa(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p4

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    check-cast p4, Lcom/google/android/gms/common/moduleinstall/ModuleAvailabilityResponse;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p2}, Lcom/google/android/gms/internal/base/zac;->zab(Landroid/os/Parcel;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-interface {p0, p1, p4}, Lcom/google/android/gms/common/moduleinstall/internal/g;->b0(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/common/moduleinstall/ModuleAvailabilityResponse;)V

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x3

    return p3
.end method
