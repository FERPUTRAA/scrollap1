.class public final synthetic Lcom/google/android/gms/common/moduleinstall/internal/o;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/v;


# instance fields
.field public final synthetic a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

.field public final synthetic b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/moduleinstall/internal/o;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/o;->b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v0, 0x0

    shl-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ s@ @ @~S ~fb @ K/~@of~~/@ 4t@ t o~@c~v @~@ ~i@ibd~.@b1~ao~ si~ Ml~~ ~@r~o ~ml@~@o@@ny ~~@-~o @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/b0;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast p2, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/z;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/o;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, v1, p2}, Lcom/google/android/gms/common/moduleinstall/internal/z;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/e;->getService()Landroid/os/IInterface;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/h;

    const/4 v2, 0x3

    or-int/2addr v3, v2

    iget-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/o;->b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, v0, p2}, Lcom/google/android/gms/common/moduleinstall/internal/h;->X(Lcom/google/android/gms/common/api/internal/k;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V

    const/4 v2, 0x2

    move v3, v2

    return-void
.end method
