.class public final synthetic Lcom/google/android/gms/common/moduleinstall/internal/k;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/v;


# instance fields
.field public final synthetic a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

.field public final synthetic b:Ljava/util/concurrent/atomic/AtomicReference;

.field public final synthetic c:Lcom/google/android/gms/common/moduleinstall/a;

.field public final synthetic d:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

.field public final synthetic e:Lcom/google/android/gms/common/moduleinstall/internal/c;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Ljava/util/concurrent/atomic/AtomicReference;Lcom/google/android/gms/common/moduleinstall/a;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;Lcom/google/android/gms/common/moduleinstall/internal/c;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/moduleinstall/internal/k;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/k;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput-object p3, p0, Lcom/google/android/gms/common/moduleinstall/internal/k;->c:Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p4, p0, Lcom/google/android/gms/common/moduleinstall/internal/k;->d:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p5, p0, Lcom/google/android/gms/common/moduleinstall/internal/k;->e:Lcom/google/android/gms/common/moduleinstall/internal/c;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "l1s ~~@t~f-  @i~s~ @~@a~~St@ f@ K~~@~ ~@vy@@~uom~o ~n@r @@ b~ d/@bo ~~i~o@cM@ ~/lb~~@o .  oi@ 4@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/b0;

    const/4 v4, 0x5

    move v5, v4

    check-cast p2, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/w;

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/k;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/google/android/gms/common/moduleinstall/internal/k;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v3, p0, Lcom/google/android/gms/common/moduleinstall/internal/k;->c:Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {v0, v1, v2, p2, v3}, Lcom/google/android/gms/common/moduleinstall/internal/w;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Ljava/util/concurrent/atomic/AtomicReference;Lcom/google/android/gms/tasks/TaskCompletionSource;Lcom/google/android/gms/common/moduleinstall/a;)V

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/e;->getService()Landroid/os/IInterface;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/h;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/k;->d:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/k;->e:Lcom/google/android/gms/common/moduleinstall/internal/c;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1, v0, p2, v1}, Lcom/google/android/gms/common/moduleinstall/internal/h;->c(Lcom/google/android/gms/common/moduleinstall/internal/g;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;Lcom/google/android/gms/common/moduleinstall/internal/j;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void
.end method
