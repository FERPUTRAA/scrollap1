.class public abstract Lcom/google/android/gms/common/moduleinstall/internal/i;
.super Lcom/google/android/gms/internal/base/zab;

# interfaces
.implements Lcom/google/android/gms/common/moduleinstall/internal/j;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string/jumbo v0, "mIsursoe.ladamscgdcer.lm.eonnidlisrie.algomta.en.aootMlgustemtlsntinl.LnSoIltdoos"

    const-string/jumbo v0, "l.sgrodLstoi.tmISintmd.merincoMegdlarnegcslundoni.smlootuea.taImtossaoauelllnl.e."

    const/4 v2, 0x2

    const-string v0, "com.google.android.gms.common.moduleinstall.internal.IModuleInstallStatusListener"

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/base/zab;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method protected final zaa(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "oidmv.m/@ron~@ ~@~f~ o@ufKi@@@a~o@@~4~@S1sb ~y~~~~ ~ @ @@ @~@~o l~ ~  @  ~tt o~l~~b-ic @ ~@ @b/M"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 p3, 0x1

    move v1, p3

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    if-ne p1, p3, :cond_0

    const/4 v0, 0x2

    or-int/2addr v1, v0

    sget-object p1, Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p2, p1}, Lcom/google/android/gms/internal/base/zac;->zaa(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p2}, Lcom/google/android/gms/internal/base/zac;->zab(Landroid/os/Parcel;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-interface {p0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/j;->e0(Lcom/google/android/gms/common/moduleinstall/ModuleInstallStatusUpdate;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p3

    :cond_0
    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    return p1
.end method
