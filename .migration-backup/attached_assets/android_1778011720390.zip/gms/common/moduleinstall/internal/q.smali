.class public final synthetic Lcom/google/android/gms/common/moduleinstall/internal/q;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/v;


# instance fields
.field public final synthetic a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

.field public final synthetic b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/moduleinstall/internal/q;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/q;->b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~stoo/d @io~ yo @~4@@@ ~~@m@ ~    .~c~~boMn~o@ Sl@~-bf K@@~@@i~ b@~ a@~i@~1l r@~~ /v~~@  ~@u@st"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/b0;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast p2, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x0

    move v3, v2

    new-instance v0, Lcom/google/android/gms/common/moduleinstall/internal/v;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/internal/q;->a:Lcom/google/android/gms/common/moduleinstall/internal/a0;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, v1, p2}, Lcom/google/android/gms/common/moduleinstall/internal/v;-><init>(Lcom/google/android/gms/common/moduleinstall/internal/a0;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/e;->getService()Landroid/os/IInterface;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast p1, Lcom/google/android/gms/common/moduleinstall/internal/h;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p2, p0, Lcom/google/android/gms/common/moduleinstall/internal/q;->b:Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;

    const/4 v3, 0x7

    const/4 v1, 0x0

    move v2, v1

    move v2, v1

    invoke-virtual {p1, v0, p2, v1}, Lcom/google/android/gms/common/moduleinstall/internal/h;->c(Lcom/google/android/gms/common/moduleinstall/internal/g;Lcom/google/android/gms/common/moduleinstall/internal/ApiFeatureRequest;Lcom/google/android/gms/common/moduleinstall/internal/j;)V

    const/4 v2, 0x2

    move v3, v2

    return-void
.end method
