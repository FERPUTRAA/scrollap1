.class public Lcom/google/android/gms/common/moduleinstall/d$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/moduleinstall/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private final a:Ljava/util/List;

.field private b:Lcom/google/android/gms/common/moduleinstall/a;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private c:Ljava/util/concurrent/Executor;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/gms/common/moduleinstall/d$a;->a:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/gms/common/api/n;)Lcom/google/android/gms/common/moduleinstall/d$a;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/api/n;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/moduleinstall/d$a;->a:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x7

    move v2, v1

    return-object p0
.end method

.method public b()Lcom/google/android/gms/common/moduleinstall/d;
    .locals 9
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    new-instance v6, Lcom/google/android/gms/common/moduleinstall/d;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/moduleinstall/d$a;->a:Ljava/util/List;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-object v2, p0, Lcom/google/android/gms/common/moduleinstall/d$a;->b:Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object v3, p0, Lcom/google/android/gms/common/moduleinstall/d$a;->c:Ljava/util/concurrent/Executor;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v4, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v5, 0x0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x5

    const/4 v7, 0x5

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/moduleinstall/d;-><init>(Ljava/util/List;Lcom/google/android/gms/common/moduleinstall/a;Ljava/util/concurrent/Executor;ZLcom/google/android/gms/common/moduleinstall/h;)V

    const/4 v8, 0x6

    return-object v6
.end method

.method public c(Lcom/google/android/gms/common/moduleinstall/a;)Lcom/google/android/gms/common/moduleinstall/d$a;
    .locals 3
    .param p1    # Lcom/google/android/gms/common/moduleinstall/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/google/android/gms/common/moduleinstall/d$a;->d(Lcom/google/android/gms/common/moduleinstall/a;Ljava/util/concurrent/Executor;)Lcom/google/android/gms/common/moduleinstall/d$a;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p1
.end method

.method public d(Lcom/google/android/gms/common/moduleinstall/a;Ljava/util/concurrent/Executor;)Lcom/google/android/gms/common/moduleinstall/d$a;
    .locals 2
    .param p1    # Lcom/google/android/gms/common/moduleinstall/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/moduleinstall/d$a;->b:Lcom/google/android/gms/common/moduleinstall/a;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/gms/common/moduleinstall/d$a;->c:Ljava/util/concurrent/Executor;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method
