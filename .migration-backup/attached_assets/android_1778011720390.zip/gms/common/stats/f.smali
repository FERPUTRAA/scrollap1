.class public final Lcom/google/android/gms/common/stats/f;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 26

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    invoke-static/range {p1 .. p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    move v8, v2

    move v8, v2

    move v8, v2

    move v8, v2

    move v11, v8

    move v11, v8

    move v11, v8

    move v11, v8

    move v13, v11

    move v13, v11

    move v13, v11

    move/from16 v18, v13

    move/from16 v18, v13

    move/from16 v18, v13

    move/from16 v18, v13

    move/from16 v25, v18

    move/from16 v25, v18

    move/from16 v25, v18

    move/from16 v25, v18

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    move-object v14, v12

    move-object v14, v12

    move-object v14, v12

    move-object v15, v14

    move-object v15, v14

    move-object/from16 v19, v15

    move-object/from16 v19, v15

    move-object/from16 v19, v15

    move-object/from16 v20, v19

    move-object/from16 v20, v19

    move-object/from16 v24, v20

    move-object/from16 v24, v20

    move-object/from16 v24, v20

    move-object/from16 v24, v20

    move-wide v9, v4

    move-wide/from16 v16, v9

    move-wide/from16 v22, v16

    move/from16 v21, v6

    move/from16 v21, v6

    move/from16 v21, v6

    move/from16 v21, v6

    :goto_0
    invoke-virtual/range {p1 .. p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    if-ge v2, v1, :cond_0

    invoke-static/range {p1 .. p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v2

    invoke-static {v2}, Lh4/a;->O(I)I

    move-result v3

    packed-switch v3, :pswitch_data_0

    :pswitch_0
    invoke-static {v0, v2}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    goto :goto_0

    :pswitch_1
    invoke-static {v0, v2}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v2

    move/from16 v25, v2

    move/from16 v25, v2

    move/from16 v25, v2

    move/from16 v25, v2

    goto :goto_0

    :pswitch_2
    invoke-static {v0, v2}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v24, v2

    move-object/from16 v24, v2

    move-object/from16 v24, v2

    goto :goto_0

    :pswitch_3
    invoke-static {v0, v2}, Lh4/a;->c0(Landroid/os/Parcel;I)J

    move-result-wide v2

    move-wide/from16 v22, v2

    goto :goto_0

    :pswitch_4
    invoke-static {v0, v2}, Lh4/a;->V(Landroid/os/Parcel;I)F

    move-result v2

    move/from16 v21, v2

    move/from16 v21, v2

    move/from16 v21, v2

    move/from16 v21, v2

    goto :goto_0

    :pswitch_5
    invoke-static {v0, v2}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    move/from16 v18, v2

    move/from16 v18, v2

    move/from16 v18, v2

    move/from16 v18, v2

    goto :goto_0

    :pswitch_6
    invoke-static {v0, v2}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v20, v2

    move-object/from16 v20, v2

    move-object/from16 v20, v2

    move-object/from16 v20, v2

    goto :goto_0

    :pswitch_7
    invoke-static {v0, v2}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    move-object v15, v2

    move-object v15, v2

    move-object v15, v2

    move-object v15, v2

    goto :goto_0

    :pswitch_8
    invoke-static {v0, v2}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    move v11, v2

    move v11, v2

    move v11, v2

    move v11, v2

    goto :goto_0

    :pswitch_9
    invoke-static {v0, v2}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v19, v2

    move-object/from16 v19, v2

    move-object/from16 v19, v2

    move-object/from16 v19, v2

    goto :goto_0

    :pswitch_a
    invoke-static {v0, v2}, Lh4/a;->c0(Landroid/os/Parcel;I)J

    move-result-wide v2

    move-wide/from16 v16, v2

    goto :goto_0

    :pswitch_b
    invoke-static {v0, v2}, Lh4/a;->I(Landroid/os/Parcel;I)Ljava/util/ArrayList;

    move-result-object v2

    move-object v14, v2

    move-object v14, v2

    move-object v14, v2

    move-object v14, v2

    goto/16 :goto_0

    :pswitch_c
    invoke-static {v0, v2}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    move v13, v2

    move v13, v2

    move v13, v2

    move v13, v2

    goto/16 :goto_0

    :pswitch_d
    invoke-static {v0, v2}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    move-object v12, v2

    move-object v12, v2

    goto/16 :goto_0

    :pswitch_e
    invoke-static {v0, v2}, Lh4/a;->c0(Landroid/os/Parcel;I)J

    move-result-wide v2

    move-wide v9, v2

    goto/16 :goto_0

    :pswitch_f
    invoke-static {v0, v2}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    move v8, v2

    move v8, v2

    move v8, v2

    goto/16 :goto_0

    :cond_0
    invoke-static {v0, v1}, Lh4/a;->N(Landroid/os/Parcel;I)V

    new-instance v0, Lcom/google/android/gms/common/stats/WakeLockEvent;

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    invoke-direct/range {v7 .. v25}, Lcom/google/android/gms/common/stats/WakeLockEvent;-><init>(IJILjava/lang/String;ILjava/util/List;Ljava/lang/String;JILjava/lang/String;Ljava/lang/String;FJLjava/lang/String;Z)V

    return-object v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_f
        :pswitch_e
        :pswitch_0
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_0
        :pswitch_a
        :pswitch_0
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "/.s~Kds ~@~~o~  o~ @l~ @@~/yu@~~f ~ o@  ii~bSo@ o~@m~~@@~a~i@@~o4 t-@~b@b@r  @ 1~c@f@ l  @M~nv@t"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    new-array p1, p1, [Lcom/google/android/gms/common/stats/WakeLockEvent;

    const/4 v1, 0x2

    return-object p1
.end method
