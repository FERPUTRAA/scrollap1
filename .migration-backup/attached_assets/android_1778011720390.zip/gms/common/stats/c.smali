.class public final Lcom/google/android/gms/common/stats/c;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "WAKE_LOCK_KEY"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final b:Landroid/content/ComponentName;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v0, Landroid/content/ComponentName;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const-string v1, "dmsscolgmd.giergon.soo"

    const-string/jumbo v1, "gnsmlo.deagidcgosroom."

    const/4 v4, 0x0

    const-string/jumbo v1, "olnmmsor..gidam.odgoce"

    const-string v1, "com.google.android.gms"

    const/4 v3, 0x2

    const-string/jumbo v2, "oor.og.leivcttmoSsiSaomn.t...toroomraenemgeGgmscsaCsmdc"

    const-string v2, "ccommc.t.isaGotog.tooneseSmo.tomvmrgdSlren.Cidrmag.aess"

    const/4 v4, 0x0

    const-string/jumbo v2, "s.orsboSgsnmGclisoC.etoeam.d.ectSnomrregtgmsoa.dtavm.ci"

    const-string v2, "com.google.android.gms.common.stats.GmsCoreStatsService"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    sput-object v0, Lcom/google/android/gms/common/stats/c;->b:Landroid/content/ComponentName;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method
