.class public Lcom/google/android/gms/common/stats/b;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static final b:Ljava/lang/Object;

.field private static volatile c:Lcom/google/android/gms/common/stats/b;
    .annotation runtime Lv7/h;
    .end annotation
.end field


# instance fields
.field public final a:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    sput-object v0, Lcom/google/android/gms/common/stats/b;->b:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/stats/b;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public static b()Lcom/google/android/gms/common/stats/b;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget-object v0, Lcom/google/android/gms/common/stats/b;->c:Lcom/google/android/gms/common/stats/b;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v0, Lcom/google/android/gms/common/stats/b;->b:Ljava/lang/Object;

    const/4 v3, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    sget-object v1, Lcom/google/android/gms/common/stats/b;->c:Lcom/google/android/gms/common/stats/b;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v1, Lcom/google/android/gms/common/stats/b;

    const/4 v2, 0x5

    move v3, v2

    invoke-direct {v1}, Lcom/google/android/gms/common/stats/b;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-object v1, Lcom/google/android/gms/common/stats/b;->c:Lcom/google/android/gms/common/stats/b;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    throw v1

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/common/stats/b;->c:Lcom/google/android/gms/common/stats/b;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0
.end method

.method private static f(Landroid/content/Context;Landroid/content/ServiceConnection;)V
    .locals 2

    :try_start_0
    const/4 v0, 0x1

    invoke-virtual {p0, p1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/NoSuchElementException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method private final g(Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;Landroid/content/ServiceConnection;IZLjava/util/concurrent/Executor;)Z
    .locals 5
    .param p7    # Ljava/util/concurrent/Executor;
        .annotation runtime Lv7/h;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p3}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object p6

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo v0, "rnsctsieooeacnkCT"

    const-string v0, "coseoieCnnnrtcakT"

    const/4 v4, 0x2

    const-string v0, "ecnmTiortaCcokenn"

    const-string v0, "ConnectionTracker"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-nez p6, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p6}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object p6

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v2, "cigrod.m.alnsgom.dgeoo"

    const-string/jumbo v2, "midm.gcageo.m.ogsnorld"

    const/4 v4, 0x0

    const-string v2, "com.google.android.gms"

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-virtual {v2, p6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/wrappers/d;->a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v2, p6, v1}, Lcom/google/android/gms/common/wrappers/c;->c(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p6

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget p6, p6, Landroid/content/pm/ApplicationInfo;->flags:I
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/high16 v2, 0x200000

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    and-int/2addr p6, v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz p6, :cond_1

    const/4 v4, 0x0

    const-string p1, "a deoPttvO T paSAmg tapP .inEcoteo  sbr  inektiaedce"

    const-string/jumbo p1, "m peebg PsOciadtitt  Ep cniovbaToak r .aeeSn tDetd A"

    const-string p1, "Attempted to bind to a service in a STOPPED package."

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v1

    :catch_0
    :cond_1
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p4}, Lcom/google/android/gms/common/stats/b;->h(Landroid/content/ServiceConnection;)Z

    move-result p6

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz p6, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object p6, p0, Lcom/google/android/gms/common/stats/b;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p6, p4, p4}, Ljava/util/concurrent/ConcurrentHashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p6

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    check-cast p6, Landroid/content/ServiceConnection;

    const/4 v4, 0x3

    const/4 v3, 0x2

    if-eqz p6, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eq p4, p6, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 p6, 0x3

    move v4, p6

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-array p6, p6, [Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    aput-object p4, p6, v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x0

    aput-object p2, p6, v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 p2, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p3}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    aput-object v2, p6, p2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string p2, " iiehtuimvuCn oedt h a,pSsonbrnt.c nn,cs%bg iec a lsDe%ie%t:se"

    const-string p2, " cls:beS,a,mupCco bo  e e.stneit%hst%rviisniein t%iceD ghdna n"

    const/4 v4, 0x5

    const-string/jumbo p2, "hc% ,s pdvmneasi nt  e%csniinntSo:eawucoDgsletrtbpiCe%eh, ii  "

    const-string p2, "Duplicate binding with the same ServiceConnection: %s, %s, %s."

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p2, p6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p1, p3, p4, p5, p7}, Lcom/google/android/gms/common/stats/b;->i(Landroid/content/Context;Landroid/content/Intent;Landroid/content/ServiceConnection;ILjava/util/concurrent/Executor;)Z

    move-result p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz p1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_1

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/stats/b;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, p4, p4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    return v1

    :catchall_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object p2, p0, Lcom/google/android/gms/common/stats/b;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p2, p4, p4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    throw p1

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p1, p3, p4, p5, p7}, Lcom/google/android/gms/common/stats/b;->i(Landroid/content/Context;Landroid/content/Intent;Landroid/content/ServiceConnection;ILjava/util/concurrent/Executor;)Z

    move-result p1

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    return p1
.end method

.method private static h(Landroid/content/ServiceConnection;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    instance-of p0, p0, Lcom/google/android/gms/common/internal/j2;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    if-nez p0, :cond_0

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p0, 0x1

    const/4 v1, 0x2

    return p0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p0, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p0
.end method

.method private static final i(Landroid/content/Context;Landroid/content/Intent;Landroid/content/ServiceConnection;ILjava/util/concurrent/Executor;)Z
    .locals 3
    .param p4    # Ljava/util/concurrent/Executor;
        .annotation runtime Lv7/h;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez p4, :cond_0

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    const/4 p4, 0x0

    move v2, p4

    :cond_0
    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/common/util/v;->p()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz p4, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p0, p1, p3, p4, p2}, Lcom/google/android/gms/common/stats/a;->a(Landroid/content/Context;Landroid/content/Intent;ILjava/util/concurrent/Executor;Landroid/content/ServiceConnection;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p0

    :cond_1
    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2, p3}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    return p0
.end method


# virtual methods
.method public a(Landroid/content/Context;Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z
    .locals 11
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/content/ServiceConnection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    const/4 v7, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    const/4 v8, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v10, 0x5

    const/4 v9, 0x0

    move v6, p4

    move v6, p4

    move v6, p4

    move v6, p4

    const/4 v10, 0x5

    invoke-direct/range {v1 .. v8}, Lcom/google/android/gms/common/stats/b;->g(Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;Landroid/content/ServiceConnection;IZLjava/util/concurrent/Executor;)Z

    move-result p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    return p1
.end method

.method public c(Landroid/content/Context;Landroid/content/ServiceConnection;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/ServiceConnection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p2}, Lcom/google/android/gms/common/stats/b;->h(Landroid/content/ServiceConnection;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/stats/b;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p2}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/stats/b;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-virtual {v0, p2}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast v0, Landroid/content/ServiceConnection;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/google/android/gms/common/stats/b;->f(Landroid/content/Context;Landroid/content/ServiceConnection;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/stats/b;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1, p2}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/stats/b;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p2}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    throw p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1, p2}, Lcom/google/android/gms/common/stats/b;->f(Landroid/content/Context;Landroid/content/ServiceConnection;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public d(Landroid/content/Context;Landroid/content/ServiceConnection;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/ServiceConnection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    :try_start_0
    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/common/stats/b;->c(Landroid/content/Context;Landroid/content/ServiceConnection;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public final e(Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;Landroid/content/ServiceConnection;ILjava/util/concurrent/Executor;)Z
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/content/ServiceConnection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p6    # Ljava/util/concurrent/Executor;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v8, 0x1

    const/16 v5, 0x1081

    const/4 v8, 0x6

    const/4 v6, 0x1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v7, p6

    move-object v7, p6

    move-object v7, p6

    move-object v7, p6

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v7}, Lcom/google/android/gms/common/stats/b;->g(Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;Landroid/content/ServiceConnection;IZLjava/util/concurrent/Executor;)Z

    move-result p1

    const/4 v8, 0x4

    return p1
.end method
