.class public final Lcom/google/android/gms/common/stats/WakeLockEvent;
.super Lcom/google/android/gms/common/stats/StatsEvent;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "WakeLockEventCreator"
.end annotation

.annotation build Lf4/a;
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/stats/WakeLockEvent;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field final a:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$h;
        id = 0x1
    .end annotation
.end field

.field private final b:J
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getTimeMillis"
        id = 0x2
    .end annotation
.end field

.field private final c:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getEventType"
        id = 0xb
    .end annotation
.end field

.field private final d:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getWakeLockName"
        id = 0x4
    .end annotation
.end field

.field private final e:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getSecondaryWakeLockName"
        id = 0xa
    .end annotation
.end field

.field private final f:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getCodePackage"
        id = 0x11
    .end annotation
.end field

.field private final g:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getWakeLockType"
        id = 0x5
    .end annotation
.end field

.field private final h:Ljava/util/List;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getCallingPackages"
        id = 0x6
    .end annotation

    .annotation runtime Lv7/h;
    .end annotation
.end field

.field private final i:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getEventKey"
        id = 0xc
    .end annotation
.end field

.field private final j:J
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getElapsedRealtime"
        id = 0x8
    .end annotation
.end field

.field private final k:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getDeviceState"
        id = 0xe
    .end annotation
.end field

.field private final l:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getHostPackage"
        id = 0xd
    .end annotation
.end field

.field private final m:F
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getBeginPowerPercentage"
        id = 0xf
    .end annotation
.end field

.field private final n:J
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getTimeout"
        id = 0x10
    .end annotation
.end field

.field private final o:Z
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getAcquiredWithTimeout"
        id = 0x12
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    new-instance v0, Lcom/google/android/gms/common/stats/f;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/common/stats/f;-><init>()V

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x7

    return-void
.end method

.method constructor <init>(IJILjava/lang/String;ILjava/util/List;Ljava/lang/String;JILjava/lang/String;Ljava/lang/String;FJLjava/lang/String;Z)V
    .locals 3
    .param p1    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # J
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .param p4    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0xb
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x4
        .end annotation
    .end param
    .param p6    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x5
        .end annotation
    .end param
    .param p7    # Ljava/util/List;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x6
        .end annotation

        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .param p8    # Ljava/lang/String;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0xc
        .end annotation
    .end param
    .param p9    # J
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x8
        .end annotation
    .end param
    .param p11    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0xe
        .end annotation
    .end param
    .param p12    # Ljava/lang/String;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0xa
        .end annotation
    .end param
    .param p13    # Ljava/lang/String;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0xd
        .end annotation
    .end param
    .param p14    # F
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0xf
        .end annotation
    .end param
    .param p15    # J
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x10
        .end annotation
    .end param
    .param p17    # Ljava/lang/String;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x11
        .end annotation
    .end param
    .param p18    # Z
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x12
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    invoke-direct {p0}, Lcom/google/android/gms/common/stats/StatsEvent;-><init>()V

    move v1, p1

    move v1, p1

    move v1, p1

    move v1, p1

    iput v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->a:I

    move-wide v1, p2

    iput-wide v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->b:J

    move v1, p4

    move v1, p4

    move v1, p4

    move v1, p4

    iput v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->c:I

    move-object v1, p5

    move-object v1, p5

    move-object v1, p5

    iput-object v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->d:Ljava/lang/String;

    move-object v1, p12

    move-object v1, p12

    move-object v1, p12

    iput-object v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->e:Ljava/lang/String;

    move-object/from16 v1, p17

    move-object/from16 v1, p17

    move-object/from16 v1, p17

    move-object/from16 v1, p17

    iput-object v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->f:Ljava/lang/String;

    move v1, p6

    move v1, p6

    move v1, p6

    move v1, p6

    iput v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->g:I

    move-object v1, p7

    move-object v1, p7

    move-object v1, p7

    move-object v1, p7

    iput-object v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->h:Ljava/util/List;

    move-object v1, p8

    move-object v1, p8

    move-object v1, p8

    move-object v1, p8

    iput-object v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->i:Ljava/lang/String;

    move-wide v1, p9

    iput-wide v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->j:J

    move v1, p11

    move v1, p11

    move v1, p11

    move v1, p11

    iput v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->k:I

    move-object/from16 v1, p13

    move-object/from16 v1, p13

    move-object/from16 v1, p13

    move-object/from16 v1, p13

    iput-object v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->l:Ljava/lang/String;

    move/from16 v1, p14

    move/from16 v1, p14

    move/from16 v1, p14

    move/from16 v1, p14

    iput v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->m:F

    move-wide/from16 v1, p15

    iput-wide v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->n:J

    move/from16 v1, p18

    move/from16 v1, p18

    move/from16 v1, p18

    iput-boolean v1, v0, Lcom/google/android/gms/common/stats/WakeLockEvent;->o:Z

    return-void
.end method


# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 7
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~ s@@/@nltdcK@~~@~~  M @@ ~@ @@o~ablS @@t@  o~o~@y~~4i1~@~~ bof~~ ~ ~ i~-v@@rs~i ~ of~ /o@m. b@@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result p2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v0, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->a:I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p1, v0, v1}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v0, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-wide v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->b:J

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {p1, v0, v1, v2}, Lh4/b;->K(Landroid/os/Parcel;IJ)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->d:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v1, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {p1, v1, v0, v2}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v0, 0x5

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->g:I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {p1, v0, v1}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v0, 0x6

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->h:Ljava/util/List;

    const/4 v6, 0x6

    const/4 v5, 0x7

    invoke-static {p1, v0, v1, v2}, Lh4/b;->a0(Landroid/os/Parcel;ILjava/util/List;Z)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/16 v0, 0x8

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-wide v3, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->j:J

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {p1, v0, v3, v4}, Lh4/b;->K(Landroid/os/Parcel;IJ)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/16 v0, 0xa

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->e:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {p1, v0, v1, v2}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/16 v0, 0xb

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->c:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {p1, v0, v1}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/16 v0, 0xc

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->i:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p1, v0, v1, v2}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/16 v0, 0xd

    const/4 v5, 0x1

    shl-int/2addr v6, v5

    iget-object v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->l:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {p1, v0, v1, v2}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/16 v0, 0xe

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->k:I

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-static {p1, v0, v1}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/16 v0, 0xf

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->m:F

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p1, v0, v1}, Lh4/b;->w(Landroid/os/Parcel;IF)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/16 v0, 0x10

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-wide v3, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->n:J

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {p1, v0, v3, v4}, Lh4/b;->K(Landroid/os/Parcel;IJ)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/16 v0, 0x11

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->f:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {p1, v0, v1, v2}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/16 v0, 0x12

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-boolean v1, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->o:Z

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {p1, v0, v1}, Lh4/b;->g(Landroid/os/Parcel;IZ)V

    const/4 v6, 0x5

    invoke-static {p1, p2}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    return-void
.end method

.method public final y2()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->c:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    return v0
.end method

.method public final z2()Ljava/lang/String;
    .locals 14
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->h:Ljava/util/List;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x3

    if-nez v0, :cond_0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x4

    goto :goto_0

    :cond_0
    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x6

    const-string v2, ","

    const-string v2, ","

    const/4 v13, 0x1

    const-string v2, ","

    const-string v2, ","

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-static {v2, v0}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v0

    :goto_0
    const/4 v13, 0x6

    const/4 v12, 0x4

    iget v2, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->k:I

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x7

    iget-object v3, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->e:Ljava/lang/String;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x2

    iget-object v4, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->l:Ljava/lang/String;

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x5

    iget v5, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->m:F

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x4

    iget-object v6, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->f:Ljava/lang/String;

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x1

    iget v7, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->g:I

    const/4 v13, 0x7

    const/4 v12, 0x2

    iget-object v8, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->d:Ljava/lang/String;

    const/4 v12, 0x7

    move v13, v12

    iget-boolean v9, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->o:Z

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x7

    new-instance v10, Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x6

    const-string v11, "/t"

    const-string v11, "/t"

    const-string/jumbo v11, "t/"

    const-string v11, "\t"

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x0

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x3

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v13, 0x3

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x5

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x4

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x1

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x4

    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x7

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x2

    if-nez v3, :cond_1

    move-object v3, v1

    move-object v3, v1

    :cond_1
    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x5

    invoke-virtual {v10, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    move v13, v12

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x7

    if-nez v4, :cond_2

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    :cond_2
    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x2

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x1

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x6

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x2

    if-nez v6, :cond_3

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x7

    goto :goto_1

    :cond_3
    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    :goto_1
    const/4 v13, 0x1

    const/4 v12, 0x6

    invoke-virtual {v10, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x6

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x4

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x0

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x6

    const/4 v12, 0x5

    return-object v0
.end method

.method public final zzb()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/google/android/gms/common/stats/WakeLockEvent;->b:J

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-wide v0
.end method
