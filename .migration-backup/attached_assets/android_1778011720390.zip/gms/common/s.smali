.class public final Lcom/google/android/gms/common/s;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "profile"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "email"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final c:Ljava/lang/String; = "openid"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final d:Ljava/lang/String; = "https://www.googleapis.com/auth/userinfo.profile"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final e:Ljava/lang/String; = "https://www.googleapis.com/auth/userinfo.email"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final f:Ljava/lang/String; = "https://www.googleapis.com/auth/plus.login"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final g:Ljava/lang/String; = "https://www.googleapis.com/auth/plus.me"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final h:Ljava/lang/String; = "https://www.googleapis.com/auth/games"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final i:Ljava/lang/String; = "https://www.googleapis.com/auth/games_lite"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final j:Ljava/lang/String; = "https://www.googleapis.com/auth/datastoremobile"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final k:Ljava/lang/String; = "https://www.googleapis.com/auth/appstate"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final l:Ljava/lang/String; = "https://www.googleapis.com/auth/drive.file"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final m:Ljava/lang/String; = "https://www.googleapis.com/auth/drive.appdata"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final n:Ljava/lang/String; = "https://www.googleapis.com/auth/drive"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final o:Ljava/lang/String; = "https://www.googleapis.com/auth/drive.apps"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    return-void
.end method
