.class public final synthetic Lcom/google/android/gms/common/e;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;Ljava/lang/CharSequence;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ss l@@@@i~ @@@b~1  ~@~~@K~~~uy~i@bo~o @f~t~ /~ ~M~~a/o@.@ @-@  cnvdS~~ob @  lr o t~~o@4i~m@ f@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/app/NotificationChannel;->setName(Ljava/lang/CharSequence;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method
