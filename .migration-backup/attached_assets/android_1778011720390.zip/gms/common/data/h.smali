.class public final Lcom/google/android/gms/common/data/h;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "next_page_token"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "prev_page_token"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public static a(Lcom/google/android/gms/common/data/b;)Ljava/util/ArrayList;
    .locals 5
    .param p0    # Lcom/google/android/gms/common/data/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "E::",
            "Lcom/google/android/gms/common/data/j<",
            "TT;>;>(",
            "Lcom/google/android/gms/common/data/b<",
            "TE;>;)",
            "Ljava/util/ArrayList<",
            "TT;>;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p0}, Lcom/google/android/gms/common/data/b;->getCount()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p0}, Lcom/google/android/gms/common/data/b;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    check-cast v2, Lcom/google/android/gms/common/data/j;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v2}, Lcom/google/android/gms/common/data/j;->b()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {p0}, Lcom/google/android/gms/common/data/b;->close()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {p0}, Lcom/google/android/gms/common/data/b;->close()V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    throw v0
.end method

.method public static b(Lcom/google/android/gms/common/data/b;)Z
    .locals 2
    .param p0    # Lcom/google/android/gms/common/data/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/data/b<",
            "*>;)Z"
        }
    .end annotation

    const/4 v1, 0x3

    if-eqz p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-interface {p0}, Lcom/google/android/gms/common/data/b;->getCount()I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    if-lez p0, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 p0, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    return p0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 p0, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p0
.end method

.method public static c(Lcom/google/android/gms/common/data/b;)Z
    .locals 3
    .param p0    # Lcom/google/android/gms/common/data/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/data/b<",
            "*>;)Z"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {p0}, Lcom/google/android/gms/common/data/b;->getMetadata()Landroid/os/Bundle;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-string/jumbo v0, "nns_otpesxag_et"

    const-string v0, "e_snkgaxnotpte_"

    const/4 v2, 0x3

    const-string v0, "akom_gnn_pxtete"

    const-string/jumbo v0, "next_page_token"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p0
.end method

.method public static d(Lcom/google/android/gms/common/data/b;)Z
    .locals 3
    .param p0    # Lcom/google/android/gms/common/data/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/data/b<",
            "*>;)Z"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {p0}, Lcom/google/android/gms/common/data/b;->getMetadata()Landroid/os/Bundle;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string/jumbo v0, "r_taonepegmpek_"

    const-string v0, "eanmekgrt_p_epo"

    const/4 v2, 0x2

    const-string/jumbo v0, "oaerebvgp_t_kep"

    const-string/jumbo v0, "prev_page_token"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v1, 0x7

    shr-int/2addr v2, v1

    const/4 p0, 0x1

    shr-int/2addr v2, p0

    const/4 v1, 0x1

    or-int/2addr v2, v1

    return p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p0
.end method
