.class public Lcom/google/android/gms/common/data/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "TT;>;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field protected final a:Lcom/google/android/gms/common/data/b;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field protected b:I


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/data/b;)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/data/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    check-cast p1, Lcom/google/android/gms/common/data/b;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/data/c;->a:Lcom/google/android/gms/common/data/b;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p1, -0x1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/gms/common/data/c;->b:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@os  @ ~~~~ @~~/bK i@~~~~~@ ~~S-o  i.@~@da~  ~s@t~~n frml~l  @@bb/i@ @u@o  t1co@~~oo@@@v@fM4@y~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/data/c;->a:Lcom/google/android/gms/common/data/b;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/gms/common/data/c;->b:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {v0}, Lcom/google/android/gms/common/data/b;->getCount()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-ge v1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return v0

    :cond_0
    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return v0
.end method

.method public next()Ljava/lang/Object;
    .locals 6
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/common/data/c;->hasNext()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/data/c;->a:Lcom/google/android/gms/common/data/b;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v1, p0, Lcom/google/android/gms/common/data/c;->b:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    iput v1, p0, Lcom/google/android/gms/common/data/c;->b:I

    const/4 v5, 0x5

    invoke-interface {v0, v1}, Lcom/google/android/gms/common/data/b;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-object v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget v1, p0, Lcom/google/android/gms/common/data/c;->b:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string/jumbo v3, "te mroan Ct  c nonhanrttoadeisbayve"

    const-string/jumbo v3, "nisettvaheadcnr by aanCoeo  tnert o"

    const/4 v5, 0x7

    const-string/jumbo v3, "tennododea ty  antraetoerbCia hn vc"

    const-string v3, "Cannot advance the iterator beyond "

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final remove()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v1, "t efobmrseereumlota faefBeCnmnrntaarr vt  amIotD"

    const-string/jumbo v1, "fm meaaaDtetIo nmoretrvs a eteerueot lfrannfrBmC"

    const/4 v3, 0x3

    const-string v1, " ntoanuesleofeartB taeaffme CtoDuem avnrrtror me"

    const-string v1, "Cannot remove elements from a DataBufferIterator"

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
