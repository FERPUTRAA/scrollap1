.class final Lcom/google/android/gms/common/data/n;
.super Lcom/google/android/gms/common/data/DataHolder$a;


# direct methods
.method constructor <init>([Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 p2, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p2}, Lcom/google/android/gms/common/data/DataHolder$a;-><init>([Ljava/lang/String;Ljava/lang/String;Lcom/google/android/gms/common/data/o;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final c(Landroid/content/ContentValues;)Lcom/google/android/gms/common/data/DataHolder$a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "utsyv ~@M /m@~ S~o@ ~ ~~ ~  b ~@ ical@@ ~~@4@-r@onK~i~b@~@@@f@~o t@~io@l~~o /f do~~1 ~@@ ~@b .@s"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string/jumbo v0, "ndsd tb  alCret odetiuaat mdnoay"

    const/4 v2, 0x1

    const-string/jumbo v0, "tpdme l aoytano anetddCidb amu r"

    const-string v0, "Cannot add data to empty builder"

    const/4 v1, 0x6

    move v2, v1

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    throw p1
.end method

.method public final d(Ljava/util/HashMap;)Lcom/google/android/gms/common/data/DataHolder$a;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, "d tm udela opdCnrya ittband moea"

    const/4 v2, 0x6

    const-string v0, "Cn aoreatodialo endtdttb  mp adu"

    const-string v0, "Cannot add data to empty builder"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    throw p1
.end method
