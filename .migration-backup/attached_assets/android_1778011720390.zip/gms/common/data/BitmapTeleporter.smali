.class public Lcom/google/android/gms/common/data/BitmapTeleporter;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;

# interfaces
.implements Lcom/google/android/gms/common/internal/ReflectedParcelable;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "BitmapTeleporterCreator"
.end annotation

.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/data/BitmapTeleporter;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field


# instance fields
.field final a:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$h;
        id = 0x1
    .end annotation
.end field

.field b:Landroid/os/ParcelFileDescriptor;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        id = 0x2
    .end annotation
.end field

.field final c:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        id = 0x3
    .end annotation
.end field

.field private d:Landroid/graphics/Bitmap;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private e:Z

.field private f:Ljava/io/File;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/gms/common/data/m;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/google/android/gms/common/data/m;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/gms/common/data/BitmapTeleporter;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x4

    move v2, v1

    return-void
.end method

.method constructor <init>(ILandroid/os/ParcelFileDescriptor;I)V
    .locals 2
    .param p1    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # Landroid/os/ParcelFileDescriptor;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .param p3    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->b:Landroid/os/ParcelFileDescriptor;

    const/4 v1, 0x1

    const/4 v0, 0x3

    iput p3, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->c:I

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x7

    move v0, p1

    move v0, p1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->d:Landroid/graphics/Bitmap;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->e:Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/graphics/Bitmap;)V
    .locals 4
    .param p1    # Landroid/graphics/Bitmap;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->a:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->b:Landroid/os/ParcelFileDescriptor;

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    move v3, v2

    iput v1, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->c:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->d:Landroid/graphics/Bitmap;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-boolean v0, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->e:Z

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method private static final A2(Ljava/io/Closeable;)V
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " Msomd/fc @~ @~oK o@t~~ o i@~bba@~~ ~~.v-@~~@i4~~@~ @n@@y~@ui r@@~ @ 1~So~l  ~  ~l@@ o@fs ~@b@t~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x4

    const/4 v2, 0x7

    return-void

    :catch_0
    move-exception p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v0, "TrmmtstoilBepepa"

    const-string v0, "eBsamettorpplriT"

    const/4 v3, 0x7

    const-string v0, "eTeiolertmarpBpt"

    const-string v0, "BitmapTeleporter"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, "el mCnacl do rtsuootms"

    const/4 v3, 0x7

    const-string/jumbo v1, "s Cltbm souca oortndle"

    const-string v1, "Could not close stream"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0, v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method


# virtual methods
.method public release()V
    .locals 5
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-boolean v0, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->e:Z

    const/4 v4, 0x5

    const/4 v3, 0x7

    if-nez v0, :cond_0

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->b:Landroid/os/ParcelFileDescriptor;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    check-cast v0, Landroid/os/ParcelFileDescriptor;

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void

    :catch_0
    move-exception v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v1, "eropitulmetpaTor"

    const-string v1, "ToBeoprilmpttaer"

    const-string v1, "BitmapTeleporter"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v2, "oFuoDlnpC tco sedPl"

    const-string v2, "Could not close PFD"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 8
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->b:Landroid/os/ParcelFileDescriptor;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-nez v0, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->d:Landroid/graphics/Bitmap;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    check-cast v0, Landroid/graphics/Bitmap;

    const/4 v7, 0x2

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getRowBytes()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    mul-int/2addr v1, v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {v1}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Landroid/graphics/Bitmap;->copyPixelsToBuffer(Ljava/nio/Buffer;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    new-instance v2, Ljava/io/BufferedOutputStream;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->f:Ljava/io/File;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v3, :cond_0

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string/jumbo v4, "trpbteeeqo"

    const-string/jumbo v4, "rptrobetee"

    const/4 v7, 0x2

    const-string/jumbo v4, "lesttoeprr"

    const-string/jumbo v4, "teleporter"

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string v5, ".tmp"

    const-string/jumbo v5, "tmp."

    const/4 v7, 0x5

    const-string/jumbo v5, "ptm."

    const-string v5, ".tmp"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v4, v5, v3}, Ljava/io/File;->createTempFile(Ljava/lang/String;Ljava/lang/String;Ljava/io/File;)Ljava/io/File;

    move-result-object v3
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2

    :try_start_1
    const/4 v7, 0x0

    const/4 v6, 0x4

    new-instance v4, Ljava/io/FileOutputStream;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-direct {v4, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/high16 v5, 0x10000000

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v3, v5}, Landroid/os/ParcelFileDescriptor;->open(Ljava/io/File;I)Landroid/os/ParcelFileDescriptor;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput-object v5, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->b:Landroid/os/ParcelFileDescriptor;
    :try_end_1
    .catch Ljava/io/FileNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {v2, v4}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-instance v3, Ljava/io/DataOutputStream;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-direct {v3, v2}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    :try_start_2
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    array-length v2, v1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v3, v2}, Ljava/io/DataOutputStream;->writeInt(I)V

    const/4 v6, 0x4

    and-int/2addr v7, v6

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v3, v2}, Ljava/io/DataOutputStream;->writeInt(I)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v3, v2}, Ljava/io/DataOutputStream;->writeInt(I)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v0}, Landroid/graphics/Bitmap;->getConfig()Landroid/graphics/Bitmap$Config;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v3, v0}, Ljava/io/DataOutputStream;->writeUTF(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v3, v1}, Ljava/io/OutputStream;->write([B)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v3}, Lcom/google/android/gms/common/data/BitmapTeleporter;->A2(Ljava/io/Closeable;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    :try_start_3
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    new-instance p2, Ljava/lang/IllegalStateException;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string/jumbo v0, "uo mn eu ldttfienwn i tledrlinoiCu"

    const-string/jumbo v0, "tunod u  tllfoneewoilrtuCin diein "

    const/4 v7, 0x4

    const-string v0, "Could not write into unlinked file"

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {p2, v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x1

    const/4 v6, 0x0

    throw p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {v3}, Lcom/google/android/gms/common/data/BitmapTeleporter;->A2(Ljava/io/Closeable;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    throw p1

    :catch_1
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const-string/jumbo p2, "ps to o aaolmiedpeeme rerdreaolwhlyy Tdfe"

    const-string p2, "aomwTdepyody a rleteer hif eopieadmserll "

    const/4 v7, 0x1

    const-string p2, "dtTelbyapmee oseiel serfiadlearyrmdoo   h"

    const-string p2, "Temporary file is somehow already deleted"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    throw p1

    :catch_2
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-instance p2, Ljava/lang/IllegalStateException;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string/jumbo v0, "pedtCrumlnflotitrq  ea  rouayee"

    const-string v0, "cedrtataqi oeu lr e oplCtyfmenr"

    const/4 v7, 0x3

    const-string v0, " dyrlrrppnem   Cofleaooueaetttc"

    const-string v0, "Could not create temporary file"

    const/4 v6, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct {p2, v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x0

    throw p2

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string/jumbo p2, "l  lcouoqhppertb irjcgbee ns D eesimaTt)wfoectlaritt aeeibrds t s("

    const-string p2, "efserDtsat srjbp(lpei nrrwatditttcgo lh emocusmeblao  i Tce)eie  b"

    const/4 v7, 0x3

    const-string p2, "btspt jeif ieweo  osmteb(esDa )eletat cd romicri lhebr alstcpun rg"

    const-string/jumbo p2, "setTempDir() must be called before writing this object to a parcel"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    throw p1

    :cond_1
    :goto_1
    const/4 v6, 0x2

    move v7, v6

    const/4 v0, 0x1

    or-int/2addr v7, v0

    const/4 v6, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    or-int/2addr p2, v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget v2, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->a:I

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {p1, v0, v2}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->b:Landroid/os/ParcelFileDescriptor;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x5

    move v7, v6

    const/4 v3, 0x2

    shl-int/2addr v7, v3

    const/4 v6, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {p1, v3, v0, p2, v2}, Lh4/b;->S(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/4 p2, 0x3

    const/4 v7, 0x0

    const/4 v6, 0x2

    iget v0, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->c:I

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {p1, p2, v0}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-static {p1, v1}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 p1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->b:Landroid/os/ParcelFileDescriptor;

    const/4 v6, 0x0

    or-int/2addr v7, v6

    return-void
.end method

.method public y2()Landroid/graphics/Bitmap;
    .locals 7
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-boolean v0, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->e:Z

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-nez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    new-instance v0, Ljava/io/DataInputStream;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance v1, Landroid/os/ParcelFileDescriptor$AutoCloseInputStream;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->b:Landroid/os/ParcelFileDescriptor;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    check-cast v2, Landroid/os/ParcelFileDescriptor;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v1, v2}, Landroid/os/ParcelFileDescriptor$AutoCloseInputStream;-><init>(Landroid/os/ParcelFileDescriptor;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {v0, v1}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-array v1, v1, [B

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/io/DataInputStream;->readInt()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/io/DataInputStream;->readUTF()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v4}, Landroid/graphics/Bitmap$Config;->valueOf(Ljava/lang/String;)Landroid/graphics/Bitmap$Config;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Ljava/io/DataInputStream;->read([B)I
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/data/BitmapTeleporter;->A2(Ljava/io/Closeable;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v2, v3, v4}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1, v0}, Landroid/graphics/Bitmap;->copyPixelsFromBuffer(Ljava/nio/Buffer;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput-object v1, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->d:Landroid/graphics/Bitmap;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v0, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    iput-boolean v0, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->e:Z

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    goto :goto_1

    :catchall_0
    move-exception v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    goto :goto_0

    :catch_0
    move-exception v1

    :try_start_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v2, Ljava/lang/IllegalStateException;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v3, "Cnfm omoifa  ritesea ldrdooerecpllmdp u rr"

    const-string/jumbo v3, "irempC corr lerfarnue imd  o dteolaolscfpd"

    const/4 v6, 0x5

    const-string v3, " ltpo fareeerlicdciCdopfdtuesa lo omror n "

    const-string v3, "Could not read from parcel file descriptor"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {v2, v3, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    throw v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/data/BitmapTeleporter;->A2(Ljava/io/Closeable;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    throw v1

    :cond_0
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->d:Landroid/graphics/Bitmap;

    const/4 v6, 0x4

    return-object v0
.end method

.method public z2(Ljava/io/File;)V
    .locals 3
    .param p1    # Ljava/io/File;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/data/BitmapTeleporter;->f:Ljava/io/File;

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string/jumbo v0, "ul trbatotonlpsCnid  noercyetm"

    const-string/jumbo v0, "tlteodconiousCanrt  p remyelnt"

    const/4 v2, 0x6

    const-string v0, "ao ecluopit  etlru terysnCnmnd"

    const-string v0, "Cannot set null temp directory"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    throw p1
.end method
