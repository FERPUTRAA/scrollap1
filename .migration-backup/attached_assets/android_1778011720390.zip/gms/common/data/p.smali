.class public final Lcom/google/android/gms/common/data/p;
.super Ljava/lang/RuntimeException;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    const-string p1, " lsh nlbguC norl meeo Wcnr.ee.aahh urC vno itiouudatzunerhlaaaaiaywn   w  whwvt sWTot rfdasodsenlereaod d  et do aC"

    const-string p1, "Could not add the value to a new CursorWindow. The size of value may be larger than what a CursorWindow can handle."

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method
