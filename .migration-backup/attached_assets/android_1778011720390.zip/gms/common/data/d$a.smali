.class public interface abstract Lcom/google/android/gms/common/data/d$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/data/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation


# virtual methods
.method public abstract c(Lcom/google/android/gms/common/data/d;)V
    .param p1    # Lcom/google/android/gms/common/data/d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract d(Lcom/google/android/gms/common/data/d;)V
    .param p1    # Lcom/google/android/gms/common/data/d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method
