.class public final Lcom/google/android/gms/common/data/DataHolder;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;

# interfaces
.implements Ljava/io/Closeable;


# annotations
.annotation build Lcom/google/android/gms/common/annotation/KeepName;
.end annotation

.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "DataHolderCreator"
    validate = true
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/data/DataHolder$a;
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/data/DataHolder;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field private static final k:Lcom/google/android/gms/common/data/DataHolder$a;


# instance fields
.field final a:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$h;
        id = 0x3e8
    .end annotation
.end field

.field private final b:[Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getColumns"
        id = 0x1
    .end annotation
.end field

.field c:Landroid/os/Bundle;

.field private final d:[Landroid/database/CursorWindow;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getWindows"
        id = 0x2
    .end annotation
.end field

.field private final e:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getStatusCode"
        id = 0x3
    .end annotation
.end field

.field private final f:Landroid/os/Bundle;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getMetadata"
        id = 0x4
    .end annotation
.end field

.field g:[I

.field h:I

.field i:Z

.field private j:Z


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v0, Lcom/google/android/gms/common/data/r;

    const/4 v4, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/common/data/r;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    sput-object v0, Lcom/google/android/gms/common/data/DataHolder;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v0, Lcom/google/android/gms/common/data/n;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-array v1, v1, [Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/android/gms/common/data/n;-><init>([Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    sput-object v0, Lcom/google/android/gms/common/data/DataHolder;->k:Lcom/google/android/gms/common/data/DataHolder$a;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void
.end method

.method constructor <init>(I[Ljava/lang/String;[Landroid/database/CursorWindow;ILandroid/os/Bundle;)V
    .locals 3
    .param p1    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3e8
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p3    # [Landroid/database/CursorWindow;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .param p4    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3
        .end annotation
    .end param
    .param p5    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation

        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x4
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-boolean v0, p0, Lcom/google/android/gms/common/data/DataHolder;->i:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/google/android/gms/common/data/DataHolder;->j:Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/gms/common/data/DataHolder;->a:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p2, p0, Lcom/google/android/gms/common/data/DataHolder;->b:[Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p3, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput p4, p0, Lcom/google/android/gms/common/data/DataHolder;->e:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p5, p0, Lcom/google/android/gms/common/data/DataHolder;->f:Landroid/os/Bundle;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/database/Cursor;ILandroid/os/Bundle;)V
    .locals 9
    .param p1    # Landroid/database/Cursor;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v8, 0x6

    new-instance v0, Li4/a;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {v0, p1}, Li4/a;-><init>(Landroid/database/Cursor;)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v0}, Landroid/database/CursorWrapper;->getColumnNames()[Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance v1, Ljava/util/ArrayList;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v0}, Landroid/database/CursorWrapper;->getCount()I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0}, Li4/a;->getWindow()Landroid/database/CursorWindow;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v8, 0x1

    const/4 v5, 0x0

    const/4 v8, 0x4

    xor-int/2addr v7, v5

    const/4 v8, 0x0

    if-eqz v3, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v3}, Landroid/database/CursorWindow;->getStartPosition()I

    move-result v6

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-nez v6, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v3}, Landroid/database/sqlite/SQLiteClosable;->acquireReference()V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0, v4}, Li4/a;->a(Landroid/database/CursorWindow;)V

    const/4 v8, 0x6

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v3}, Landroid/database/CursorWindow;->getNumRows()I

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    goto :goto_0

    :cond_0
    const/4 v8, 0x4

    move v3, v5

    move v3, v5

    const/4 v8, 0x5

    move v3, v5

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-ge v3, v2, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v0, v3}, Landroid/database/CursorWrapper;->moveToPosition(I)Z

    move-result v6

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eqz v6, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0}, Li4/a;->getWindow()Landroid/database/CursorWindow;

    move-result-object v6

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eqz v6, :cond_1

    const/4 v7, 0x1

    and-int/2addr v8, v7

    invoke-virtual {v6}, Landroid/database/sqlite/SQLiteClosable;->acquireReference()V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v0, v4}, Li4/a;->a(Landroid/database/CursorWindow;)V

    const/4 v8, 0x1

    goto :goto_1

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-instance v6, Landroid/database/CursorWindow;

    const/4 v7, 0x4

    xor-int/2addr v8, v7

    invoke-direct {v6, v5}, Landroid/database/CursorWindow;-><init>(Z)V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v6, v3}, Landroid/database/CursorWindow;->setStartPosition(I)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v0, v3, v6}, Li4/a;->fillWindow(ILandroid/database/CursorWindow;)V

    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v6}, Landroid/database/CursorWindow;->getNumRows()I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-nez v3, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto :goto_2

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v6}, Landroid/database/CursorWindow;->getStartPosition()I

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v6}, Landroid/database/CursorWindow;->getNumRows()I

    move-result v6
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    add-int/2addr v3, v6

    goto :goto_0

    :cond_3
    :goto_2
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v0}, Landroid/database/CursorWrapper;->close()V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    new-array v0, v0, [Landroid/database/CursorWindow;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    check-cast v0, [Landroid/database/CursorWindow;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-direct {p0, p1, v0, p2, p3}, Lcom/google/android/gms/common/data/DataHolder;-><init>([Ljava/lang/String;[Landroid/database/CursorWindow;ILandroid/os/Bundle;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v0}, Landroid/database/CursorWrapper;->close()V

    const/4 v7, 0x1

    move v8, v7

    throw p1
.end method

.method private constructor <init>(Lcom/google/android/gms/common/data/DataHolder$a;ILandroid/os/Bundle;)V
    .locals 3
    .param p3    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/data/DataHolder$a;->f(Lcom/google/android/gms/common/data/DataHolder$a;)[Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/google/android/gms/common/data/DataHolder;->O2(Lcom/google/android/gms/common/data/DataHolder$a;I)[Landroid/database/CursorWindow;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0, p3, p1, p2, v0}, Lcom/google/android/gms/common/data/DataHolder;-><init>([Ljava/lang/String;[Landroid/database/CursorWindow;ILandroid/os/Bundle;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/gms/common/data/DataHolder$a;ILandroid/os/Bundle;ILcom/google/android/gms/common/data/q;)V
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    invoke-static {p1}, Lcom/google/android/gms/common/data/DataHolder$a;->f(Lcom/google/android/gms/common/data/DataHolder$a;)[Ljava/lang/String;

    move-result-object p4

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    const/4 p5, -0x1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p1, p5}, Lcom/google/android/gms/common/data/DataHolder;->O2(Lcom/google/android/gms/common/data/DataHolder$a;I)[Landroid/database/CursorWindow;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p4, p1, p2, p3}, Lcom/google/android/gms/common/data/DataHolder;-><init>([Ljava/lang/String;[Landroid/database/CursorWindow;ILandroid/os/Bundle;)V

    const/4 v1, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/gms/common/data/DataHolder$a;ILandroid/os/Bundle;Lcom/google/android/gms/common/data/q;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 p3, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/gms/common/data/DataHolder;-><init>(Lcom/google/android/gms/common/data/DataHolder$a;ILandroid/os/Bundle;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    return-void
.end method

.method public constructor <init>([Ljava/lang/String;[Landroid/database/CursorWindow;ILandroid/os/Bundle;)V
    .locals 3
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Landroid/database/CursorWindow;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    iput-boolean v0, p0, Lcom/google/android/gms/common/data/DataHolder;->i:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/google/android/gms/common/data/DataHolder;->j:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/gms/common/data/DataHolder;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast p1, [Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/data/DataHolder;->b:[Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast p1, [Landroid/database/CursorWindow;

    const/4 v2, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput p3, p0, Lcom/google/android/gms/common/data/DataHolder;->e:I

    const/4 v2, 0x2

    iput-object p4, p0, Lcom/google/android/gms/common/data/DataHolder;->f:Landroid/os/Bundle;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/common/data/DataHolder;->M2()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method private final N2(Ljava/lang/String;I)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  s  ~@~~b@u@/@@l~. @ ~ti~f~~ ~ ~~~oo~@fi/~@ v4 r@ @sloc@~@~mbo ~o ~ db ~~ t@@@@n-@o@Sy@a~MK i@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    if-eqz v0, :cond_2

    const/4 v1, 0x5

    or-int/2addr v2, v1

    invoke-virtual {p0}, Lcom/google/android/gms/common/data/DataHolder;->isClosed()Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-ltz p2, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget p1, p0, Lcom/google/android/gms/common/data/DataHolder;->h:I

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-ge p2, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance p1, Landroid/database/CursorIndexOutOfBoundsException;

    const/4 v1, 0x2

    move v2, v1

    iget v0, p0, Lcom/google/android/gms/common/data/DataHolder;->h:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p1, p2, v0}, Landroid/database/CursorIndexOutOfBoundsException;-><init>(II)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    throw p1

    :cond_1
    const/4 v2, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const-string/jumbo p2, "fdsm esic.el Brsf"

    const-string/jumbo p2, "rese.Bf disu cslf"

    const/4 v2, 0x6

    const-string/jumbo p2, "s iBoldescfu.froe"

    const-string p2, "Buffer is closed."

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    throw p1

    :cond_2
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    new-instance p2, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo v0, "hol ubcm n c:sNm"

    const-string v0, ":n mNcl su uhocm"

    const/4 v2, 0x0

    const-string/jumbo v0, "um  lou cshno:uc"

    const-string v0, "No such column: "

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    throw p2
.end method

.method private static O2(Lcom/google/android/gms/common/data/DataHolder$a;I)[Landroid/database/CursorWindow;
    .locals 13

    invoke-static {p0}, Lcom/google/android/gms/common/data/DataHolder$a;->f(Lcom/google/android/gms/common/data/DataHolder$a;)[Ljava/lang/String;

    move-result-object p1

    array-length p1, p1

    const/4 v0, 0x0

    if-nez p1, :cond_0

    new-array p0, v0, [Landroid/database/CursorWindow;

    return-object p0

    :cond_0
    invoke-static {p0}, Lcom/google/android/gms/common/data/DataHolder$a;->e(Lcom/google/android/gms/common/data/DataHolder$a;)Ljava/util/ArrayList;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    new-instance v2, Landroid/database/CursorWindow;

    invoke-direct {v2, v0}, Landroid/database/CursorWindow;-><init>(Z)V

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-static {p0}, Lcom/google/android/gms/common/data/DataHolder$a;->f(Lcom/google/android/gms/common/data/DataHolder$a;)[Ljava/lang/String;

    move-result-object v4

    array-length v4, v4

    invoke-virtual {v2, v4}, Landroid/database/CursorWindow;->setNumColumns(I)Z

    move v4, v0

    move v4, v0

    move v4, v0

    move v4, v0

    move v5, v4

    move v5, v4

    move v5, v4

    move v5, v4

    :goto_0
    if-ge v4, v1, :cond_f

    :try_start_0
    invoke-virtual {v2}, Landroid/database/CursorWindow;->allocRow()Z

    move-result v6
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const-string v7, "DataHolder"

    if-nez v6, :cond_1

    :try_start_1
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "ientA rpeadglnwoai(d   diofcdrt act  orlsswaolwaorn uarli ot"

    const-string v6, "Allocating additional cursor window for large data set (row "

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, ")"

    const-string v6, ")"

    const-string v6, ")"

    const-string v6, ")"

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v7, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance v2, Landroid/database/CursorWindow;

    invoke-direct {v2, v0}, Landroid/database/CursorWindow;-><init>(Z)V

    invoke-virtual {v2, v4}, Landroid/database/CursorWindow;->setStartPosition(I)V

    invoke-static {p0}, Lcom/google/android/gms/common/data/DataHolder$a;->f(Lcom/google/android/gms/common/data/DataHolder$a;)[Ljava/lang/String;

    move-result-object v6

    array-length v6, v6

    invoke-virtual {v2, v6}, Landroid/database/CursorWindow;->setNumColumns(I)Z

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2}, Landroid/database/CursorWindow;->allocRow()Z

    move-result v6

    if-nez v6, :cond_1

    const-string/jumbo p0, "ooeblaltqUw  l eorta.toatno c adh ld"

    const-string p0, "Unable to allocate row to hold data."

    invoke-static {v7, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result p0

    new-array p0, p0, [Landroid/database/CursorWindow;

    invoke-virtual {v3, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Landroid/database/CursorWindow;

    return-object p0

    :cond_1
    invoke-interface {p1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/util/Map;

    const/4 v8, 0x1

    move v9, v0

    move v9, v0

    move v9, v0

    move v9, v0

    move v10, v8

    move v10, v8

    move v10, v8

    move v10, v8

    :goto_1
    invoke-static {p0}, Lcom/google/android/gms/common/data/DataHolder$a;->f(Lcom/google/android/gms/common/data/DataHolder$a;)[Ljava/lang/String;

    move-result-object v11

    array-length v11, v11

    if-ge v9, v11, :cond_b

    if-eqz v10, :cond_c

    invoke-static {p0}, Lcom/google/android/gms/common/data/DataHolder$a;->f(Lcom/google/android/gms/common/data/DataHolder$a;)[Ljava/lang/String;

    move-result-object v10

    aget-object v10, v10, v9

    invoke-interface {v6, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    if-nez v11, :cond_2

    invoke-virtual {v2, v4, v9}, Landroid/database/CursorWindow;->putNull(II)Z

    move-result v10

    goto/16 :goto_3

    :cond_2
    instance-of v12, v11, Ljava/lang/String;

    if-eqz v12, :cond_3

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v2, v11, v4, v9}, Landroid/database/CursorWindow;->putString(Ljava/lang/String;II)Z

    move-result v10

    goto :goto_3

    :cond_3
    instance-of v12, v11, Ljava/lang/Long;

    if-eqz v12, :cond_4

    check-cast v11, Ljava/lang/Long;

    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    invoke-virtual {v2, v10, v11, v4, v9}, Landroid/database/CursorWindow;->putLong(JII)Z

    move-result v10

    goto :goto_3

    :cond_4
    instance-of v12, v11, Ljava/lang/Integer;

    if-eqz v12, :cond_5

    check-cast v11, Ljava/lang/Integer;

    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    move-result v10

    int-to-long v10, v10

    invoke-virtual {v2, v10, v11, v4, v9}, Landroid/database/CursorWindow;->putLong(JII)Z

    move-result v10

    goto :goto_3

    :cond_5
    instance-of v12, v11, Ljava/lang/Boolean;

    if-eqz v12, :cond_7

    check-cast v11, Ljava/lang/Boolean;

    invoke-virtual {v11}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v10

    if-eq v8, v10, :cond_6

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    goto :goto_2

    :cond_6
    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    :goto_2
    invoke-virtual {v2, v10, v11, v4, v9}, Landroid/database/CursorWindow;->putLong(JII)Z

    move-result v10

    goto :goto_3

    :cond_7
    instance-of v12, v11, [B

    if-eqz v12, :cond_8

    check-cast v11, [B

    invoke-virtual {v2, v11, v4, v9}, Landroid/database/CursorWindow;->putBlob([BII)Z

    move-result v10

    goto :goto_3

    :cond_8
    instance-of v12, v11, Ljava/lang/Double;

    if-eqz v12, :cond_9

    check-cast v11, Ljava/lang/Double;

    invoke-virtual {v11}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v10

    invoke-virtual {v2, v10, v11, v4, v9}, Landroid/database/CursorWindow;->putDouble(DII)Z

    move-result v10

    goto :goto_3

    :cond_9
    instance-of v12, v11, Ljava/lang/Float;

    if-eqz v12, :cond_a

    check-cast v11, Ljava/lang/Float;

    invoke-virtual {v11}, Ljava/lang/Float;->floatValue()F

    move-result v10

    float-to-double v10, v10

    invoke-virtual {v2, v10, v11, v4, v9}, Landroid/database/CursorWindow;->putDouble(DII)Z

    move-result v10

    :goto_3
    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_1

    :cond_a
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v11}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "prsueoetnoco fnd m Ubjlsurcotp"

    const-string v2, "Unsupported object for column "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ": "

    const-string v2, ": "

    const-string v2, " :"

    const-string v2, ": "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_b
    if-eqz v10, :cond_c

    move v5, v0

    move v5, v0

    move v5, v0

    goto :goto_4

    :cond_c
    if-nez v5, :cond_d

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "  omwalotuo oadoaCel/ wwtirdr tud fpnon"

    const-string/jumbo v6, "oanloluCp w  tw/eootrwtr dduooifd aa/n "

    const-string/jumbo v6, "tCoaonrudwnt p efw lopadud /oar/o lot w"

    const-string v6, "Couldn\'t populate window data for row "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v6, "oown b.wdn lilacn-igea w "

    const-string v6, " - allocating new window."

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v7, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v2}, Landroid/database/CursorWindow;->freeLastRow()V

    new-instance v2, Landroid/database/CursorWindow;

    invoke-direct {v2, v0}, Landroid/database/CursorWindow;-><init>(Z)V

    invoke-virtual {v2, v4}, Landroid/database/CursorWindow;->setStartPosition(I)V

    invoke-static {p0}, Lcom/google/android/gms/common/data/DataHolder$a;->f(Lcom/google/android/gms/common/data/DataHolder$a;)[Ljava/lang/String;

    move-result-object v5

    array-length v5, v5

    invoke-virtual {v2, v5}, Landroid/database/CursorWindow;->setNumColumns(I)Z

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, -0x1

    move v5, v8

    move v5, v8

    move v5, v8

    move v5, v8

    :goto_4
    add-int/2addr v4, v8

    goto/16 :goto_0

    :cond_d
    const-string/jumbo p0, "wmernoulnt euev al uiwodn  ahfdaC.eahrhs  c C .Wrawor toweaedsnd uT  ulb  ier d vtoozaheaio dtnohut lyrlgna WCea bn"

    const-string p0, " dontbladuz haedsaen gw a nuhwu re  tvluoCoieo yarasrWna arao evntoc ui  rh eteWe n mlaf wo dlonCrC.bwaltTd. h hide"

    const-string p0, " esendap admodahW nawu  tWel ooCnledtunro hvoneoliw a efi roaoate.haatwehs r ebvu  yzudrTnir tsc C lC.ru d hl a awg"

    const-string p0, "Could not add the value to a new CursorWindow. The size of value may be larger than what a CursorWindow can handle."

    new-instance p1, Lcom/google/android/gms/common/data/p;

    invoke-direct {p1, p0}, Lcom/google/android/gms/common/data/p;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    move-exception p0

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result p1

    :goto_5
    if-ge v0, p1, :cond_e

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/database/CursorWindow;

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteClosable;->close()V

    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    :cond_e
    throw p0

    :cond_f
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result p0

    new-array p0, p0, [Landroid/database/CursorWindow;

    invoke-virtual {v3, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Landroid/database/CursorWindow;

    return-object p0
.end method

.method public static y2([Ljava/lang/String;)Lcom/google/android/gms/common/data/DataHolder$a;
    .locals 4
    .param p0    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/common/data/DataHolder$a;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v0, p0, v1, v1}, Lcom/google/android/gms/common/data/DataHolder$a;-><init>([Ljava/lang/String;Ljava/lang/String;Lcom/google/android/gms/common/data/o;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public static z2(I)Lcom/google/android/gms/common/data/DataHolder;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v0, Lcom/google/android/gms/common/data/DataHolder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    sget-object v1, Lcom/google/android/gms/common/data/DataHolder;->k:Lcom/google/android/gms/common/data/DataHolder$a;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    invoke-direct {v0, v1, p0, v2}, Lcom/google/android/gms/common/data/DataHolder;-><init>(Lcom/google/android/gms/common/data/DataHolder$a;ILandroid/os/Bundle;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v0
.end method


# virtual methods
.method public A2(Ljava/lang/String;II)Z
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/data/DataHolder;->N2(Ljava/lang/String;I)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v3, 0x1

    aget-object p3, v0, p3

    const/4 v2, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p3, p2, p1}, Landroid/database/CursorWindow;->getLong(II)J

    move-result-wide p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x5

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    cmp-long p1, p1, v0

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    return p1
.end method

.method public B2(Ljava/lang/String;II)[B
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/data/DataHolder;->N2(Ljava/lang/String;I)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    aget-object p3, v0, p3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p3, p2, p1}, Landroid/database/CursorWindow;->getBlob(II)[B

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p1
.end method

.method public C2(Ljava/lang/String;II)I
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/data/DataHolder;->N2(Ljava/lang/String;I)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    aget-object p3, v0, p3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p3, p2, p1}, Landroid/database/CursorWindow;->getInt(II)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p1
.end method

.method public D2(Ljava/lang/String;II)J
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/data/DataHolder;->N2(Ljava/lang/String;I)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    aget-object p3, v0, p3

    const/4 v2, 0x3

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p3, p2, p1}, Landroid/database/CursorWindow;->getLong(II)J

    move-result-wide p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-wide p1
.end method

.method public E2()I
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x6

    move v2, v1

    iget v0, p0, Lcom/google/android/gms/common/data/DataHolder;->e:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public F2(Ljava/lang/String;II)Ljava/lang/String;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/data/DataHolder;->N2(Ljava/lang/String;I)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v2, 0x1

    const/4 v1, 0x0

    aget-object p3, v0, p3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p3, p2, p1}, Landroid/database/CursorWindow;->getString(II)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p1
.end method

.method public G2(I)I
    .locals 5
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x6

    if-ltz p1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/android/gms/common/data/DataHolder;->h:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-ge p1, v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    move v1, v0

    move v1, v0

    const/4 v4, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->x(Z)V

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/data/DataHolder;->g:[I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    array-length v2, v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-ge v0, v2, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    aget v1, v1, v0

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ge p1, v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_2

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-ne v0, v2, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x1

    add-int/lit8 v0, v0, -0x1

    :cond_3
    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    return v0
.end method

.method public H2(Ljava/lang/String;)Z
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p1
.end method

.method public I2(Ljava/lang/String;II)Z
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/data/DataHolder;->N2(Ljava/lang/String;I)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    aget-object p3, v0, p3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-virtual {p3, p2, p1}, Landroid/database/CursorWindow;->isNull(II)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return p1
.end method

.method public final J2(Ljava/lang/String;II)D
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/data/DataHolder;->N2(Ljava/lang/String;I)V

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v2, 0x1

    aget-object p3, v0, p3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p3, p2, p1}, Landroid/database/CursorWindow;->getDouble(II)D

    move-result-wide p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-wide p1
.end method

.method public final K2(Ljava/lang/String;II)F
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/data/DataHolder;->N2(Ljava/lang/String;I)V

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    aget-object p3, v0, p3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-virtual {p3, p2, p1}, Landroid/database/CursorWindow;->getFloat(II)F

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return p1
.end method

.method public final L2(Ljava/lang/String;IILandroid/database/CharArrayBuffer;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/database/CharArrayBuffer;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/data/DataHolder;->N2(Ljava/lang/String;I)V

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    aget-object p3, v0, p3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-virtual {p3, p2, p1, p4}, Landroid/database/CursorWindow;->copyStringToBuffer(IILandroid/database/CharArrayBuffer;)V

    const/4 v2, 0x5

    return-void
.end method

.method public final M2()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v4, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    move v1, v0

    move v1, v0

    const/4 v5, 0x0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/data/DataHolder;->b:[Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    array-length v3, v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-ge v1, v3, :cond_0

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/google/android/gms/common/data/DataHolder;->c:Landroid/os/Bundle;

    const/4 v5, 0x3

    aget-object v2, v2, v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v3, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    array-length v1, v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-array v1, v1, [I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput-object v1, p0, Lcom/google/android/gms/common/data/DataHolder;->g:[I

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    move v1, v0

    move v1, v0

    const/4 v5, 0x5

    move v1, v0

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    array-length v3, v2

    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-ge v0, v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v3, p0, Lcom/google/android/gms/common/data/DataHolder;->g:[I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    aput v1, v3, v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    aget-object v2, v2, v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v2}, Landroid/database/CursorWindow;->getStartPosition()I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    sub-int v2, v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v3, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    aget-object v3, v3, v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v3}, Landroid/database/CursorWindow;->getNumRows()I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    sub-int/2addr v3, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    add-int/2addr v1, v3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    iput v1, p0, Lcom/google/android/gms/common/data/DataHolder;->h:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void
.end method

.method public close()V
    .locals 5
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-boolean v0, p0, Lcom/google/android/gms/common/data/DataHolder;->i:Z

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v0, 0x4

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v4, 0x4

    iput-boolean v0, p0, Lcom/google/android/gms/common/data/DataHolder;->i:Z

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v4, 0x3

    array-length v2, v1

    const/4 v3, 0x5

    move v4, v3

    if-ge v0, v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    aget-object v1, v1, v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-virtual {v1}, Landroid/database/sqlite/SQLiteClosable;->close()V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x4

    shl-int/2addr v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    monitor-exit p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    throw v0
.end method

.method protected final finalize()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-boolean v0, p0, Lcom/google/android/gms/common/data/DataHolder;->j:Z

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    array-length v0, v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-lez v0, :cond_0

    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {p0}, Lcom/google/android/gms/common/data/DataHolder;->isClosed()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/common/data/DataHolder;->close()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string v0, "aDfBuftrqu"

    const-string/jumbo v0, "uBraftufaD"

    const/4 v5, 0x6

    const-string/jumbo v0, "fusafarBeD"

    const-string v0, "DataBuffer"

    const/4 v5, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v3, " eimrafneafheli eoa oall  f  eputndrn coerennaac(enatoeeelt xeeptDf!t  Bx taBelake t  tiliaBdwhobwe  ret hlorddumsaih)eon na n.De tttbca nsice sdgeyaue ec : jblr tyic lwu(rjttIj"

    const-string/jumbo v3, "jt a oipek cmeutdjct:ueBeexneewe pe a anabl(oetrheo h r)ua  w arenIt  jle idy nnuleiebi nwcB xnd  rattg r! ltth t yfo lsadoio teBiil DncedDaaeehscraa ffbaal(ete. colnntserftettl"

    const/4 v5, 0x2

    const-string v3, "ce  o  nsjwon ent l e area otuee B (dtesttofaltu:foIiuaa aknn ilrrcbeceytit Bwjd yemtleue p  attbe.jhgn(e ra i tlaectlo wcdlifrbeBah eifhdnlDntoaax!eh e dDlsleeit one xaanc )etr"

    const-string v3, "Internal data leak within a DataBuffer object detected!  Be sure to explicitly call release() on all DataBuffer extending objects when you are done with them. (internal object: "

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v1, ")"

    const-string v1, ")"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v5, 0x4

    invoke-super {p0}, Ljava/lang/Object;->finalize()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void

    :catchall_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-super {p0}, Ljava/lang/Object;->finalize()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    throw v0
.end method

.method public getCount()I
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/common/data/DataHolder;->h:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public getMetadata()Landroid/os/Bundle;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->f:Landroid/os/Bundle;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public isClosed()Z
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/google/android/gms/common/data/DataHolder;->i:Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    throw v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 7
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder;->b:[Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {p1, v2, v0, v3}, Lh4/b;->Z(Landroid/os/Parcel;I[Ljava/lang/String;Z)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v0, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v4, p0, Lcom/google/android/gms/common/data/DataHolder;->d:[Landroid/database/CursorWindow;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {p1, v0, v4, p2, v3}, Lh4/b;->c0(Landroid/os/Parcel;I[Landroid/os/Parcelable;IZ)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v0, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/common/data/DataHolder;->E2()I

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {p1, v0, v4}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v0, 0x4

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/common/data/DataHolder;->getMetadata()Landroid/os/Bundle;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {p1, v0, v4, v3}, Lh4/b;->k(Landroid/os/Parcel;ILandroid/os/Bundle;Z)V

    const/4 v6, 0x7

    const/16 v0, 0x3e8

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget v3, p0, Lcom/google/android/gms/common/data/DataHolder;->a:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {p1, v0, v3}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v6, 0x2

    invoke-static {p1, v1}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v6, 0x4

    and-int/lit8 p1, p2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz p1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/data/DataHolder;->close()V

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-void
.end method
