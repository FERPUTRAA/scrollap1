.class public Lcom/google/android/gms/common/data/l;
.super Lcom/google/android/gms/common/data/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/android/gms/common/data/c<",
        "TT;>;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field private c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/data/b;)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/data/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/data/c;-><init>(Lcom/google/android/gms/common/data/b;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final next()Ljava/lang/Object;
    .locals 6
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "o@s r ~ ~~@bS/@to~~f @ ~@ib t1@@ y  @~~ @ ~~o@f@~@~~ o@~@dl.@~cbsKno@@-mi@v @~M  i~/u~o~~al~4@  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/data/c;->hasNext()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/android/gms/common/data/c;->b:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    iput v0, p0, Lcom/google/android/gms/common/data/c;->b:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/data/c;->a:Lcom/google/android/gms/common/data/b;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v0, v1}, Lcom/google/android/gms/common/data/b;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/google/android/gms/common/data/l;->c:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    instance-of v1, v0, Lcom/google/android/gms/common/data/f;

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    new-instance v1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v3, "fcemyBoe tsapra r  feternefuf"

    const-string/jumbo v3, "etse rtefer ua p corfaefeyBnf"

    const/4 v5, 0x6

    const-string/jumbo v3, "tua oBfeeyrD ff acfeepntoer r"

    const-string v3, "DataBuffer reference of type "

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo v0, "lms abvbeo ti o"

    const-string v0, " is not movable"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    throw v1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/data/l;->c:Ljava/lang/Object;

    const/4 v4, 0x6

    move v5, v4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    check-cast v0, Lcom/google/android/gms/common/data/f;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v1, p0, Lcom/google/android/gms/common/data/c;->b:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/data/f;->n(I)V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/data/l;->c:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-object v0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget v1, p0, Lcom/google/android/gms/common/data/c;->b:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v3, "avnnttu   mtayetdhedneecCnorb  aaio"

    const-string v3, "aCbm t  r vaeottnetaonee rnihdnyacd"

    const-string v3, " tee tapirnatcaonbvtn eorhnaCedd yo"

    const-string v3, "Cannot advance the iterator beyond "

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    throw v0
.end method
