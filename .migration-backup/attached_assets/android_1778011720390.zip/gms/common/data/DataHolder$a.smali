.class public Lcom/google/android/gms/common/data/DataHolder$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/data/DataHolder;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field private final a:[Ljava/lang/String;

.field private final b:Ljava/util/ArrayList;

.field private final c:Ljava/util/HashMap;


# direct methods
.method synthetic constructor <init>([Ljava/lang/String;Ljava/lang/String;Lcom/google/android/gms/common/data/o;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    check-cast p1, [Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/data/DataHolder$a;->a:[Ljava/lang/String;

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    new-instance p1, Ljava/util/ArrayList;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/data/DataHolder$a;->b:Ljava/util/ArrayList;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    new-instance p1, Ljava/util/HashMap;

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/data/DataHolder$a;->c:Ljava/util/HashMap;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method static bridge synthetic e(Lcom/google/android/gms/common/data/DataHolder$a;)Ljava/util/ArrayList;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, ". slvM ~aio@i/@ol~@~o u ~  o~nf4/~ ~d@o ~~~@@@~@1@f @K@b b t ~~~@~s@@~r@~bt@@@~~~ c@ ~  my~i oS@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/gms/common/data/DataHolder$a;->b:Ljava/util/ArrayList;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method static bridge synthetic f(Lcom/google/android/gms/common/data/DataHolder$a;)[Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/gms/common/data/DataHolder$a;->a:[Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method


# virtual methods
.method public a(I)Lcom/google/android/gms/common/data/DataHolder;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/gms/common/data/DataHolder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1, v1, v1}, Lcom/google/android/gms/common/data/DataHolder;-><init>(Lcom/google/android/gms/common/data/DataHolder$a;ILandroid/os/Bundle;Lcom/google/android/gms/common/data/q;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0
.end method

.method public b(ILandroid/os/Bundle;)Lcom/google/android/gms/common/data/DataHolder;
    .locals 9
    .param p2    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    new-instance v6, Lcom/google/android/gms/common/data/DataHolder;

    const/4 v7, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v4, -0x1

    const/4 v7, 0x5

    move v8, v7

    const/4 v5, 0x0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    move v2, p1

    move v2, p1

    const/4 v8, 0x3

    move v2, p1

    move v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/data/DataHolder;-><init>(Lcom/google/android/gms/common/data/DataHolder$a;ILandroid/os/Bundle;ILcom/google/android/gms/common/data/q;)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    return-object v6
.end method

.method public c(Landroid/content/ContentValues;)Lcom/google/android/gms/common/data/DataHolder$a;
    .locals 5
    .param p1    # Landroid/content/ContentValues;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/d;->c(Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/content/ContentValues;->size()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/content/ContentValues;->valueSet()Ljava/util/Set;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v3, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast v2, Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/data/DataHolder$a;->d(Ljava/util/HashMap;)Lcom/google/android/gms/common/data/DataHolder$a;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object p1
.end method

.method public d(Ljava/util/HashMap;)Lcom/google/android/gms/common/data/DataHolder$a;
    .locals 3
    .param p1    # Ljava/util/HashMap;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/internal/d;->c(Ljava/lang/Object;)V

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/data/DataHolder$a;->b:Ljava/util/ArrayList;

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method
