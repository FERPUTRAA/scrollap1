.class public abstract Lcom/google/android/gms/common/data/i;
.super Lcom/google/android/gms/common/data/a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/android/gms/common/data/a<",
        "TT;>;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field private b:Z

.field private c:Ljava/util/ArrayList;


# direct methods
.method protected constructor <init>(Lcom/google/android/gms/common/data/DataHolder;)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/data/DataHolder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/data/a;-><init>(Lcom/google/android/gms/common/data/DataHolder;)V

    const/4 v0, 0x4

    move v1, v0

    const/4 p1, 0x0

    move v1, p1

    const/4 v0, 0x3

    move v1, v0

    iput-boolean p1, p0, Lcom/google/android/gms/common/data/i;->b:Z

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method private final f()V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~4s~  @~ ~@~~l~v@ ~b@@@~sS/r@1t ~~o~.b/K ~- ofii  @ @@@b@~@t@~f ~~o~ M~i da@u ~~ @oo@my c o~@n@@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget-boolean v0, p0, Lcom/google/android/gms/common/data/i;->b:Z

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-nez v0, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/data/a;->a:Lcom/google/android/gms/common/data/DataHolder;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    check-cast v0, Lcom/google/android/gms/common/data/DataHolder;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/common/data/DataHolder;->getCount()I

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    new-instance v1, Ljava/util/ArrayList;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    iput-object v1, p0, Lcom/google/android/gms/common/data/i;->c:Ljava/util/ArrayList;

    const/4 v8, 0x7

    const/4 v2, 0x1

    const/4 v8, 0x4

    const/4 v2, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-lez v0, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/4 v3, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x2

    const/4 v7, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/common/data/i;->d()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object v4, p0, Lcom/google/android/gms/common/data/a;->a:Lcom/google/android/gms/common/data/DataHolder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v4, v3}, Lcom/google/android/gms/common/data/DataHolder;->G2(I)I

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object v5, p0, Lcom/google/android/gms/common/data/a;->a:Lcom/google/android/gms/common/data/DataHolder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v5, v1, v3, v4}, Lcom/google/android/gms/common/data/DataHolder;->F2(Ljava/lang/String;II)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    move v4, v2

    move v4, v2

    const/4 v8, 0x4

    move v4, v2

    move v4, v2

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-ge v4, v0, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v5, p0, Lcom/google/android/gms/common/data/a;->a:Lcom/google/android/gms/common/data/DataHolder;

    const/4 v7, 0x4

    move v8, v7

    invoke-virtual {v5, v4}, Lcom/google/android/gms/common/data/DataHolder;->G2(I)I

    move-result v5

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object v6, p0, Lcom/google/android/gms/common/data/a;->a:Lcom/google/android/gms/common/data/DataHolder;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v6, v1, v4, v5}, Lcom/google/android/gms/common/data/DataHolder;->F2(Ljava/lang/String;II)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz v6, :cond_1

    invoke-virtual {v6, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-nez v5, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget-object v3, p0, Lcom/google/android/gms/common/data/i;->c:Ljava/util/ArrayList;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object v3, v6

    move-object v3, v6

    move-object v3, v6

    move-object v3, v6

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string/jumbo v3, "nlsmueCre i sfaiu omk :nMrmgarlv"

    const-string v3, " nsleafnas ovk:Mrrglimu Cs meriu"

    const/4 v8, 0x7

    const-string v3, "Missing value for markerColumn: "

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string v1, ",o aom:r  "

    const-string v1, "ar:mo, t  "

    const/4 v8, 0x2

    const-string v1, ", at row: "

    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string/jumbo v1, "ofdr boin:ww, "

    const-string/jumbo v1, "rfwoo: d,oniw "

    const/4 v8, 0x5

    const-string v1, " ,n fou :idrow"

    const-string v1, ", for window: "

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    throw v0

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    iput-boolean v2, p0, Lcom/google/android/gms/common/data/i;->b:Z

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    monitor-exit p0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x4

    const/4 v8, 0x1

    throw v0
.end method


# virtual methods
.method protected a()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method protected abstract b(II)Ljava/lang/Object;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)TT;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end method

.method protected abstract d()Ljava/lang/String;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end method

.method final e(I)I
    .locals 5

    const/4 v4, 0x5

    if-ltz p1, :cond_0

    const/4 v3, 0x3

    or-int/2addr v4, v3

    iget-object v0, p0, Lcom/google/android/gms/common/data/i;->c:Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-ge p1, v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/data/i;->c:Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    check-cast p1, Ljava/lang/Integer;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    return p1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo v2, "ioniosbpt"

    const-string/jumbo v2, "onts boii"

    const/4 v4, 0x2

    const-string v2, "P ontosiq"

    const-string v2, "Position "

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    shl-int/2addr v4, v3

    const-string/jumbo p1, "husotunsur eb otfoifi ofs udr   s"

    const-string p1, "buo ufuufoti    feionss fro rdhst"

    const/4 v4, 0x0

    const-string/jumbo p1, "hubmi sfr  d te u fos sffirbouoon"

    const-string p1, " is out of bounds for this buffer"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    throw v0
.end method

.method public final get(I)Ljava/lang/Object;
    .locals 8
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TT;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/common/data/i;->f()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/data/i;->e(I)I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-ltz p1, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/data/i;->c:Ljava/util/ArrayList;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    if-ne p1, v2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto/16 :goto_1

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/data/i;->c:Ljava/util/ArrayList;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    add-int/lit8 v2, v2, -0x1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-ne p1, v2, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/google/android/gms/common/data/a;->a:Lcom/google/android/gms/common/data/DataHolder;

    const/4 v7, 0x5

    const/4 v6, 0x6

    invoke-static {v2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    check-cast v2, Lcom/google/android/gms/common/data/DataHolder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v2}, Lcom/google/android/gms/common/data/DataHolder;->getCount()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v3, p0, Lcom/google/android/gms/common/data/i;->c:Ljava/util/ArrayList;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    check-cast v3, Ljava/lang/Integer;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/google/android/gms/common/data/i;->c:Ljava/util/ArrayList;

    const/4 v7, 0x6

    add-int/lit8 v3, p1, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    check-cast v2, Ljava/lang/Integer;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v3, p0, Lcom/google/android/gms/common/data/i;->c:Ljava/util/ArrayList;

    const/4 v7, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x3

    check-cast v3, Ljava/lang/Integer;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    sub-int/2addr v2, v3

    const/4 v6, 0x0

    move v7, v6

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x1

    if-ne v2, v3, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/data/i;->e(I)I

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/google/android/gms/common/data/a;->a:Lcom/google/android/gms/common/data/DataHolder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    invoke-static {v2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    check-cast v2, Lcom/google/android/gms/common/data/DataHolder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v2, p1}, Lcom/google/android/gms/common/data/DataHolder;->G2(I)I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/common/data/i;->a()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz v4, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x1

    iget-object v5, p0, Lcom/google/android/gms/common/data/a;->a:Lcom/google/android/gms/common/data/DataHolder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v5, v4, p1, v2}, Lcom/google/android/gms/common/data/DataHolder;->F2(Ljava/lang/String;II)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-nez p1, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x3

    goto :goto_1

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    move v1, v3

    move v1, v3

    const/4 v7, 0x7

    move v1, v3

    move v1, v3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto :goto_1

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    move v1, v2

    move v1, v2

    const/4 v7, 0x2

    move v1, v2

    move v1, v2

    :cond_4
    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p0, v0, v1}, Lcom/google/android/gms/common/data/i;->b(II)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-object p1
.end method

.method public getCount()I
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/common/data/i;->f()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/data/i;->c:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method
