.class final Lcom/google/android/gms/common/w0;
.super Lcom/google/android/gms/common/y0;


# instance fields
.field private final f:Ljava/util/concurrent/Callable;


# direct methods
.method synthetic constructor <init>(Ljava/util/concurrent/Callable;Lcom/google/android/gms/common/v0;)V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v1, 0x0

    move v8, v1

    const/4 v2, 0x0

    const/4 v8, 0x5

    const/4 v2, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/4 v3, 0x5

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/4 v4, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v5, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v6, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/y0;-><init>(ZIILjava/lang/String;Ljava/lang/Throwable;Lcom/google/android/gms/common/x0;)V

    const/4 v8, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/w0;->f:Ljava/util/concurrent/Callable;

    const/4 v7, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    return-void
.end method


# virtual methods
.method final a()Ljava/lang/String;
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "-~s@@s~~~  @n b@@ @o~oo ~~ ~f@i~~d~@@b@@i ~f /1~o~ly@u@~t  r~MoK/S@ 4l  vm@~ac~i@~t~ ~o. ~@@@@ b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/w0;->f:Ljava/util/concurrent/Callable;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :catch_0
    move-exception v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    throw v1
.end method
