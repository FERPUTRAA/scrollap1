.class final Lcom/google/android/gms/common/x;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field final synthetic a:Landroid/app/Activity;

.field final synthetic b:I

.field final synthetic c:Landroidx/activity/result/h;

.field final synthetic d:Lcom/google/android/gms/common/f;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/f;Landroid/app/Activity;ILandroidx/activity/result/h;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/x;->d:Lcom/google/android/gms/common/f;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/android/gms/common/x;->a:Landroid/app/Activity;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p3, p0, Lcom/google/android/gms/common/x;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p4, p0, Lcom/google/android/gms/common/x;->c:Landroidx/activity/result/h;

    const/4 v0, 0x4

    xor-int/2addr v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " fs~~@~y~ar  ~ @1/@  -obbs@ot@~o@@~/lu ~@.im~co 4@viiS  Mnb~ @ o@@l ~~~@@o@@t~~@~~~~@df ~~@~   @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/x;->d:Lcom/google/android/gms/common/f;

    const/4 v2, 0x7

    move v3, v2

    iget-object p2, p0, Lcom/google/android/gms/common/x;->a:Landroid/app/Activity;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/android/gms/common/x;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1, p2, v0, v1}, Lcom/google/android/gms/common/f;->f(Landroid/content/Context;II)Landroid/app/PendingIntent;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    new-instance p2, Landroidx/activity/result/IntentSenderRequest$a;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p2, p1}, Landroidx/activity/result/IntentSenderRequest$a;-><init>(Landroid/content/IntentSender;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2}, Landroidx/activity/result/IntentSenderRequest$a;->a()Landroidx/activity/result/IntentSenderRequest;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/google/android/gms/common/x;->c:Landroidx/activity/result/h;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p2, p1}, Landroidx/activity/result/h;->b(Ljava/lang/Object;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method
