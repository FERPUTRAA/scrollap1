.class public Lcom/google/android/gms/common/g;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final a:I
    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "com.google.android.gms"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final c:Ljava/lang/String; = "com.android.vending"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field static final d:Ljava/lang/String; = "d"
    .annotation build Lf4/a;
    .end annotation
.end field

.field static final e:Ljava/lang/String; = "n"
    .annotation build Lf4/a;
    .end annotation
.end field

.field private static final f:Lcom/google/android/gms/common/g;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    sget v0, Lcom/google/android/gms/common/k;->a:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    sput v0, Lcom/google/android/gms/common/g;->a:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/gms/common/g;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/google/android/gms/common/g;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    sput-object v0, Lcom/google/android/gms/common/g;->f:Lcom/google/android/gms/common/g;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method constructor <init>()V
    .locals 2
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static i()Lcom/google/android/gms/common/g;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/common/g;->f:Lcom/google/android/gms/common/g;

    const/4 v2, 0x5

    const/4 v1, 0x2

    return-object v0
.end method


# virtual methods
.method public a(Landroid/content/Context;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/k;->a(Landroid/content/Context;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-void
.end method

.method public b(Landroid/content/Context;)I
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/k;->d(Landroid/content/Context;)I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p1
.end method

.method public c(Landroid/content/Context;)I
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/k;->e(Landroid/content/Context;)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p1
.end method

.method public d(I)Landroid/content/Intent;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, v0, p1, v0}, Lcom/google/android/gms/common/g;->e(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1
.end method

.method public e(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v1, "oasmsoggroie..cnmslgdd"

    const-string/jumbo v1, "nosirocamgdgom.les.god"

    const/4 v4, 0x1

    const-string v1, "com.google.android.gms"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eq p2, v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v0, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eq p2, v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 p1, 0x3

    shr-int/2addr v4, p1

    const/4 v3, 0x5

    move v4, v3

    const/4 p3, 0x2

    const/4 p3, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eq p2, p1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object p3

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string p1, "aeammck"

    const-string/jumbo p1, "kcameag"

    const/4 v4, 0x0

    const-string p1, "agapock"

    const-string/jumbo p1, "package"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p1, v1, p3}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance p2, Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo p3, "oOitEbi_CEsPaAITPTLIAID.LonrtNeTsGd_.SngSTINd"

    const-string p3, "ITn.oSoaT_tPAIsCgEsELi.riPTTS_ItedLNnAOAdDING"

    const/4 v4, 0x4

    const-string p3, "CTO.eduIALSaNPLNPSIESAiGtoi_En_.ATItIsTrsdDgn"

    const-string p3, "android.settings.APPLICATION_DETAILS_SETTINGS"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p2, p3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p2, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p2

    :cond_1
    const/4 v3, 0x7

    const/4 v3, 0x4

    if-eqz p1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/util/l;->m(Landroid/content/Context;)Z

    move-result p2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez p2, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_2
    new-instance p1, Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo p2, "o_oEP_cprd.lOD.oageoERCeTkIAoR.T_DAUbmrDood.mAilkNgOA.hncwcN"

    const-string/jumbo p2, "mlEkabnO.h_g.IgAEo.CkloAdNUeRP.roWidDAowc.Oceo_AomoDrcR_NTTD"

    const/4 v4, 0x1

    const-string p2, "com.google.android.clockwork.home.UPDATE_ANDROID_WEAR_ACTION"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string p2, ".ad.llcwqgiaobmpaaoo.rperdoegen"

    const-string p2, "com.google.android.wearable.app"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x7

    return-object p1

    :cond_3
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo v0, "rusgec"

    const-string/jumbo v0, "ugcero"

    const/4 v4, 0x3

    const-string v0, "_ocmer"

    const-string/jumbo v0, "gcore_"

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    sget v0, Lcom/google/android/gms/common/g;->a:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v0, "-"

    const-string v0, "-"

    const/4 v4, 0x2

    const-string v0, "-"

    const-string v0, "-"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-nez v2, :cond_4

    const/4 v4, 0x3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_4
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    if-eqz p1, :cond_5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_5
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz p1, :cond_6

    :try_start_0
    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/wrappers/d;->a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object p3

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p3, p1, v0}, Lcom/google/android/gms/common/wrappers/c;->f(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget p1, p1, Landroid/content/pm/PackageInfo;->versionCode:I

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_6
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance p2, Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string p3, "..nioparIeic.EntoditWotdnn"

    const-string/jumbo p3, "oEdnin.pIi..tVcWnrdniteato"

    const/4 v4, 0x0

    const-string p3, ".tirnbtnWioicEadV.eaoIn.tn"

    const-string p3, "android.intent.action.VIEW"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p2, p3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string p3, "ak/:ttuma/qslier"

    const-string/jumbo p3, "l/tmir:kqe/aadts"

    const/4 v4, 0x3

    const-string/jumbo p3, "se/tradpkmlaet/i"

    const-string/jumbo p3, "market://details"

    const/4 v4, 0x7

    invoke-static {p3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p3

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p3}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object p3

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v0, "id"

    const-string/jumbo v0, "id"

    const/4 v4, 0x7

    const-string/jumbo v0, "id"

    const-string/jumbo v0, "id"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p3, v0, v1}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p3

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-nez v0, :cond_7

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v0, "iiapcnagqmp"

    const-string/jumbo v0, "pcampaignid"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p3, v0, p1}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    :cond_7
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p3}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p2, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v4, 0x2

    const-string/jumbo p1, "m.snodvrd.isdagiceo"

    const-string/jumbo p1, "irso.adeni.cddgnvom"

    const/4 v4, 0x6

    const-string p1, "adnmvgcoei.mirn.odn"

    const-string p1, "com.android.vending"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p2, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/high16 p1, 0x80000

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {p2, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object p2
.end method

.method public f(Landroid/content/Context;II)Landroid/app/PendingIntent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2, p3, v0}, Lcom/google/android/gms/common/g;->g(Landroid/content/Context;IILjava/lang/String;)Landroid/app/PendingIntent;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p1
.end method

.method public g(Landroid/content/Context;IILjava/lang/String;)Landroid/app/PendingIntent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1, p2, p4}, Lcom/google/android/gms/common/g;->e(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget p4, Lcom/google/android/gms/internal/common/zzd;->zza:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/high16 v0, 0x8000000

    const/4 v2, 0x3

    const/4 v1, 0x1

    or-int/2addr p4, v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1, p3, p2, p4}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1
.end method

.method public h(I)Ljava/lang/String;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/k;->g(I)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    return-object p1
.end method

.method public j(Landroid/content/Context;)I
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/m;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget v0, Lcom/google/android/gms/common/g;->a:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/android/gms/common/g;->k(Landroid/content/Context;I)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return p1
.end method

.method public k(Landroid/content/Context;I)I
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lcom/google/android/gms/common/k;->m(Landroid/content/Context;I)I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lcom/google/android/gms/common/k;->o(Landroid/content/Context;I)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/16 p1, 0x12

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return p1

    :cond_0
    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    return p2
.end method

.method public l(Landroid/content/Context;I)Z
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p1, p2}, Lcom/google/android/gms/common/k;->o(Landroid/content/Context;I)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    return p1
.end method

.method public m(Landroid/content/Context;I)Z
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lcom/google/android/gms/common/k;->p(Landroid/content/Context;I)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p1
.end method

.method public n(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-static {p1, p2}, Lcom/google/android/gms/common/k;->u(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return p1
.end method

.method public o(I)Z
    .locals 2
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/k;->s(I)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    return p1
.end method

.method public p(Landroid/content/Context;I)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/i;,
            Lcom/google/android/gms/common/h;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lcom/google/android/gms/common/k;->c(Landroid/content/Context;I)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method
