.class public Lcom/google/android/gms/common/providers/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/providers/a$a;
    }
.end annotation

.annotation build Lf4/a;
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field private static a:Lcom/google/android/gms/common/providers/a$a;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public static declared-synchronized a()Lcom/google/android/gms/common/providers/a$a;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-class v0, Lcom/google/android/gms/common/providers/a;

    const-class v0, Lcom/google/android/gms/common/providers/a;

    const/4 v3, 0x3

    const-class v0, Lcom/google/android/gms/common/providers/a;

    const-class v0, Lcom/google/android/gms/common/providers/a;

    const/4 v3, 0x3

    const/4 v2, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v1, Lcom/google/android/gms/common/providers/a;->a:Lcom/google/android/gms/common/providers/a$a;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v1, Lcom/google/android/gms/common/providers/b;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v1}, Lcom/google/android/gms/common/providers/b;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    sput-object v1, Lcom/google/android/gms/common/providers/a;->a:Lcom/google/android/gms/common/providers/a$a;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    sget-object v1, Lcom/google/android/gms/common/providers/a;->a:Lcom/google/android/gms/common/providers/a$a;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    move v3, v2

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x0

    throw v1
.end method
