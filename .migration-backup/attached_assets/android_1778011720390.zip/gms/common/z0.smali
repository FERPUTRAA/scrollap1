.class final Lcom/google/android/gms/common/z0;
.super Ljava/lang/Object;


# direct methods
.method static a(I)I
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "M~sio~  ~b~~v ~@~@@@@~@ fS~@@i tlo ~ Ks4@@~@~o b ~imo~ @~b~@~@c - .yo@/a~f1~l@ d/~n @tr~u  o@~@@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    const/4 v0, 0x6

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    new-array v1, v0, [I

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    fill-array-data v1, :array_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-ge v2, v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    aget v3, v1, v2

    const/4 v5, 0x4

    move v6, v5

    add-int/lit8 v4, v3, -0x1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v3, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-ne v4, p0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    return v3

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 p0, 0x0

    move v6, p0

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    throw p0

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 p0, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    return p0

    :array_0
    .array-data 4
        0x1
        0x2
        0x3
        0x4
        0x5
        0x6
    .end array-data
.end method
