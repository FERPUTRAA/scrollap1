.class public final Lcom/google/android/gms/common/zzs;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "GoogleCertificatesQueryCreator"
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/zzs;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getCallingPackage"
        id = 0x1
    .end annotation
.end field

.field private final b:Lcom/google/android/gms/common/n0;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getCallingCertificateBinder"
        id = 0x2
        type = "android.os.IBinder"
    .end annotation

    .annotation runtime Lv7/h;
    .end annotation
.end field

.field private final c:Z
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getAllowTestKeys"
        id = 0x3
    .end annotation
.end field

.field private final d:Z
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        defaultValue = "false"
        getter = "getIgnoreTestKeysOverride"
        id = 0x4
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Lcom/google/android/gms/common/u0;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/google/android/gms/common/u0;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/gms/common/zzs;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Landroid/os/IBinder;ZZ)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # Landroid/os/IBinder;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation

        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .param p3    # Z
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3
        .end annotation
    .end param
    .param p4    # Z
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x4
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v0, " Csud esetrft uwiponilnrcoat"

    const-string/jumbo v0, "ewst tnCorocei fpritda lnucu"

    const/4 v3, 0x6

    const-string/jumbo v0, "utdm r eaoeotltricpcwinfaC n"

    const-string v0, "Could not unwrap certificate"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "rrQGoteitseCfegmulaeooc"

    const-string v1, "aoimfosturCeGlreQteecig"

    const/4 v3, 0x6

    const-string/jumbo v1, "fioGcbrsrygeQtatueilCeo"

    const-string v1, "GoogleCertificatesQuery"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/zzs;->a:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x6

    if-nez p2, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_1

    :cond_0
    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p2}, Lcom/google/android/gms/common/internal/p2;->a(Landroid/os/IBinder;)Lcom/google/android/gms/common/internal/g1;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {p2}, Lcom/google/android/gms/common/internal/g1;->zzd()Lcom/google/android/gms/dynamic/d;

    move-result-object p2
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez p2, :cond_1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p2}, Lcom/google/android/gms/dynamic/f;->b(Lcom/google/android/gms/dynamic/d;)Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast p2, [B

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz p2, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance p1, Lcom/google/android/gms/common/o0;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/o0;-><init>([B)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_1

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_1

    :catch_0
    move-exception p2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v1, v0, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/zzs;->b:Lcom/google/android/gms/common/n0;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-boolean p3, p0, Lcom/google/android/gms/common/zzs;->c:Z

    const/4 v3, 0x6

    const/4 v2, 0x4

    iput-boolean p4, p0, Lcom/google/android/gms/common/zzs;->d:Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Lcom/google/android/gms/common/n0;ZZ)V
    .locals 2
    .param p2    # Lcom/google/android/gms/common/n0;
        .annotation runtime Lv7/h;
        .end annotation
    .end param

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/zzs;->a:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/android/gms/common/zzs;->b:Lcom/google/android/gms/common/n0;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-boolean p3, p0, Lcom/google/android/gms/common/zzs;->c:Z

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-boolean p4, p0, Lcom/google/android/gms/common/zzs;->d:Z

    const/4 v0, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "ilii@~uK@ b~@@r~ o@@~ ~@ 4fy ~s@~ o  u @~l~ @~1t@c~bbo /~oon~~d.ovfa@ ~  ~@@@@~m-@~ ~~~M~t@/@@  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object p2, p0, Lcom/google/android/gms/common/zzs;->a:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p1, v1, p2, v2}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object p2, p0, Lcom/google/android/gms/common/zzs;->b:Lcom/google/android/gms/common/n0;

    const/4 v4, 0x0

    if-nez p2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo p2, "oceiletpifsteoyQGgreoau"

    const-string/jumbo p2, "iogtooetuirGQcyfsleeeaC"

    const/4 v4, 0x4

    const-string/jumbo p2, "iefesiouqgelCaecQyrtrtG"

    const-string p2, "GoogleCertificatesQuery"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v1, "rbscsenefacilbrutiti  nlde"

    const-string/jumbo v1, "lter bscdlbuiecaf nit ienr"

    const/4 v4, 0x4

    const-string/jumbo v1, "liambesicd e rnfirnietul t"

    const-string v1, "certificate binder is null"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p2, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 p2, 0x0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v1, 0x2

    const/4 v4, 0x7

    invoke-static {p1, v1, p2, v2}, Lh4/b;->B(Landroid/os/Parcel;ILandroid/os/IBinder;Z)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 p2, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x7

    iget-boolean v1, p0, Lcom/google/android/gms/common/zzs;->c:Z

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {p1, p2, v1}, Lh4/b;->g(Landroid/os/Parcel;IZ)V

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 p2, 0x4

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-boolean v1, p0, Lcom/google/android/gms/common/zzs;->d:Z

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1, p2, v1}, Lh4/b;->g(Landroid/os/Parcel;IZ)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p1, v0}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method
