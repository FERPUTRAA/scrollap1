.class public Lcom/google/android/gms/common/wrappers/d;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static final b:Lcom/google/android/gms/common/wrappers/d;


# instance fields
.field private a:Lcom/google/android/gms/common/wrappers/c;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Lcom/google/android/gms/common/wrappers/d;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/common/wrappers/d;-><init>()V

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/gms/common/wrappers/d;->b:Lcom/google/android/gms/common/wrappers/d;

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/gms/common/wrappers/d;->a:Lcom/google/android/gms/common/wrappers/c;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/gms/common/wrappers/d;->b:Lcom/google/android/gms/common/wrappers/d;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/wrappers/d;->b(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method


# virtual methods
.method public final declared-synchronized b(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/wrappers/d;->a:Lcom/google/android/gms/common/wrappers/c;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/gms/common/wrappers/c;

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/wrappers/c;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/wrappers/d;->a:Lcom/google/android/gms/common/wrappers/c;

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/wrappers/d;->a:Lcom/google/android/gms/common/wrappers/c;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x5

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    throw p1
.end method
