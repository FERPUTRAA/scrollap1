.class public Lcom/google/android/gms/common/wrappers/a;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static a:Landroid/content/Context;

.field private static b:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public static declared-synchronized a(Landroid/content/Context;)Z
    .locals 6
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "K~s~~~ ~4@ryb-t bo 1~~~Mi~~si@~o of .@~~@S~ v@lo@@ u@~ bt@ @@/@on ~ @@ oa @/~f~ licd @@@@ m@~ ~~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    const-class v0, Lcom/google/android/gms/common/wrappers/a;

    const-class v0, Lcom/google/android/gms/common/wrappers/a;

    const/4 v5, 0x3

    const-class v0, Lcom/google/android/gms/common/wrappers/a;

    const-class v0, Lcom/google/android/gms/common/wrappers/a;

    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-object v2, Lcom/google/android/gms/common/wrappers/a;->a:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget-object v3, Lcom/google/android/gms/common/wrappers/a;->b:Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eq v2, v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    return p0

    :cond_1
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v2, 0x0

    :try_start_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    sput-object v2, Lcom/google/android/gms/common/wrappers/a;->b:Ljava/lang/Boolean;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {}, Lcom/google/android/gms/common/util/v;->n()Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p0}, Lcom/appsflyer/internal/f;->a(Landroid/content/pm/PackageManager;)Z

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    sput-object p0, Lcom/google/android/gms/common/wrappers/a;->b:Ljava/lang/Boolean;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto :goto_1

    :cond_2
    :try_start_2
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v2, "l.imtt.oosntdsginnpmoectgvImRiedpn.rapp.aAiassopanueors.usrn"

    const-string v2, "com.google.android.instantapps.supervisor.InstantAppsRuntime"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0, v2}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    sput-object p0, Lcom/google/android/gms/common/wrappers/a;->b:Ljava/lang/Boolean;
    :try_end_2
    .catch Ljava/lang/ClassNotFoundException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_1

    :catch_0
    :try_start_3
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    sput-object p0, Lcom/google/android/gms/common/wrappers/a;->b:Ljava/lang/Boolean;

    :goto_1
    const/4 v4, 0x4

    const/4 v5, 0x3

    sput-object v1, Lcom/google/android/gms/common/wrappers/a;->a:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    sget-object p0, Lcom/google/android/gms/common/wrappers/a;->b:Ljava/lang/Boolean;

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    return p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    throw p0
.end method
