.class public final synthetic Lcom/google/android/gms/common/wrappers/b;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/PackageManager;Ljava/lang/String;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "aos~o ~~b~ofKf  i@@ ~~~~@41@@@ds l  @~ ~@S~@~lt @ /-v@ @~o~b@@~~@y.bu@@@~  ~@i ~~ ~/cm nioM r~@t"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroid/content/pm/PackageManager;->isInstantApp(Ljava/lang/String;)Z

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p0
.end method
