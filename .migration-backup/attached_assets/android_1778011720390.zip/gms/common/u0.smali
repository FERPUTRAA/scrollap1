.class public final Lcom/google/android/gms/common/u0;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~~s@ ~ @~b~  c@.~/@yvt-@u nil@tfo~o~@f 1K ~@~i~@ @~@~b~o  @b~@~@~@m/@@~oo r~ds @ @o a~SM  ~@l~i "

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x5

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    const/4 v1, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    const/4 v2, 0x0

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    move v2, v1

    move v2, v1

    const/4 v9, 0x6

    move v2, v1

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v5

    const/4 v9, 0x5

    const/4 v8, 0x2

    if-ge v5, v0, :cond_4

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v5}, Lh4/a;->O(I)I

    move-result v6

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    const/4 v7, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-eq v6, v7, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/4 v7, 0x2

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-eq v6, v7, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v7, 0x3

    const/4 v9, 0x1

    if-eq v6, v7, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/4 v7, 0x4

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-eq v6, v7, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {p1, v5}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    goto :goto_0

    :cond_0
    const/4 v9, 0x4

    invoke-static {p1, v5}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v2

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    goto :goto_0

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {p1, v5}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    goto :goto_0

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {p1, v5}, Lh4/a;->Y(Landroid/os/Parcel;I)Landroid/os/IBinder;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    goto :goto_0

    :cond_3
    const/4 v9, 0x6

    const/4 v8, 0x7

    invoke-static {p1, v5}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    goto :goto_0

    :cond_4
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-instance p1, Lcom/google/android/gms/common/zzs;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-direct {p1, v3, v4, v1, v2}, Lcom/google/android/gms/common/zzs;-><init>(Ljava/lang/String;Landroid/os/IBinder;ZZ)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    return-object p1
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    new-array p1, p1, [Lcom/google/android/gms/common/zzs;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method
