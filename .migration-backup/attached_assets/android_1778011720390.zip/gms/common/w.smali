.class public final synthetic Lcom/google/android/gms/common/w;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/tasks/SuccessContinuation;


# static fields
.field public static final synthetic a:Lcom/google/android/gms/common/w;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Lcom/google/android/gms/common/w;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/common/w;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    sput-object v0, Lcom/google/android/gms/common/w;->a:Lcom/google/android/gms/common/w;

    const/4 v1, 0x0

    move v2, v1

    return-void
.end method

.method private synthetic constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final then(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "i st~l@@1yMio @@t~b @@~@d/@~~@4@oK   ~i @~ @~ @~  @r.b~ @bo~@-of@l~~@ f~u@~as~~S~~v~n/ ocmo ~@ ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    check-cast p1, Ljava/util/Map;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    sget p1, Lcom/google/android/gms/common/f;->h:I

    const/4 v0, 0x0

    or-int/2addr v1, v0

    const/4 p1, 0x0

    or-int/2addr v1, p1

    const/4 v0, 0x2

    move v1, v0

    invoke-static {p1}, Lcom/google/android/gms/tasks/Tasks;->forResult(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method
