.class final Lcom/google/android/gms/common/c0;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Lcom/google/android/gms/common/p;


# direct methods
.method constructor <init>(Ljava/lang/String;Lcom/google/android/gms/common/p;)V
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/p;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/c0;->a:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/android/gms/common/c0;->b:Lcom/google/android/gms/common/p;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method static bridge synthetic a(Lcom/google/android/gms/common/c0;)Lcom/google/android/gms/common/p;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " isr@tS~@b  m ~b~fnc o i~ ~/Kt ~o @@ @~M~ s~@~@~bu~@@@@~ 1do~ oay~.~ @@~4/@ @@lo~@i@~ o~ v-~fl@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/gms/common/c0;->b:Lcom/google/android/gms/common/p;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method static bridge synthetic b(Lcom/google/android/gms/common/c0;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/android/gms/common/c0;->a:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p0
.end method
