.class public final Lcom/google/android/gms/common/server/converter/zaa;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "ConverterWrapperCreator"
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/server/converter/zaa;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field final a:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$h;
        id = 0x1
    .end annotation
.end field

.field private final b:Lcom/google/android/gms/common/server/converter/StringToIntConverter;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getStringToIntConverter"
        id = 0x2
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/gms/common/server/converter/a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/common/server/converter/a;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    sput-object v0, Lcom/google/android/gms/common/server/converter/zaa;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method constructor <init>(ILcom/google/android/gms/common/server/converter/StringToIntConverter;)V
    .locals 2
    .param p1    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/server/converter/StringToIntConverter;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/gms/common/server/converter/zaa;->a:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/gms/common/server/converter/zaa;->b:Lcom/google/android/gms/common/server/converter/StringToIntConverter;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method private constructor <init>(Lcom/google/android/gms/common/server/converter/StringToIntConverter;)V
    .locals 3

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/gms/common/server/converter/zaa;->a:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/server/converter/zaa;->b:Lcom/google/android/gms/common/server/converter/StringToIntConverter;

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    return-void
.end method

.method public static y2(Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)Lcom/google/android/gms/common/server/converter/zaa;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "K@s~~v mu@d~@@i@ ~b i~c i lnS@~~/~~ f~  @~@.@M  ~t ro- ~t~41o~o@~~@b@@@~~@@ y/~ o~@s@a@~ of@ lob"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    instance-of v0, p0, Lcom/google/android/gms/common/server/converter/StringToIntConverter;

    const/4 v1, 0x7

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/server/converter/zaa;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    check-cast p0, Lcom/google/android/gms/common/server/converter/StringToIntConverter;

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/server/converter/zaa;-><init>(Lcom/google/android/gms/common/server/converter/StringToIntConverter;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0

    :cond_0
    const/4 v2, 0x1

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x1

    const-string v0, " psmdprrple Uftet uea.flo ssvnlcisaneocreab eelrda"

    const-string v0, "Unsupported safe parcelable field converter class."

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    throw p0
.end method


# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget v0, p0, Lcom/google/android/gms/common/server/converter/zaa;->a:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result v1

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v5, 0x5

    and-int/2addr v4, v2

    const/4 v5, 0x0

    invoke-static {p1, v2, v0}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/server/converter/zaa;->b:Lcom/google/android/gms/common/server/converter/StringToIntConverter;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v3, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p1, v3, v0, p2, v2}, Lh4/b;->S(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p1, v1}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-void
.end method

.method public final z2()Lcom/google/android/gms/common/server/response/FastJsonResponse$a;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/server/converter/zaa;->b:Lcom/google/android/gms/common/server/converter/StringToIntConverter;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v1, "o sroC dwcp pptrvetoeni reTrrhtpenserernvhwnoara ees Wi."

    const-string/jumbo v1, "ptsvenoshr  naerrr iecdrwe t. nntpahrvWeoprsrep i CwoeeT"

    const/4 v3, 0x7

    const-string/jumbo v1, "wepv becCevr r tdphi  ewsaWrraa rotpniroren.entnohe sreT"

    const-string v1, "There was no converter wrapped in this ConverterWrapper."

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    throw v0
.end method
