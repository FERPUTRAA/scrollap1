.class public final Lcom/google/android/gms/common/server/response/n;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "l@s~ @@yo@i~ nv@~~o  ~d~~fr t~a.@ f@MSbo/@~~/K~obs@@@  t b ~@ ~~ u- 1~~@l@   ~@ ~4m~~@o~i@c@@io~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x4

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/4 v1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v2, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    move v3, v2

    move v3, v2

    const/4 v8, 0x7

    move v3, v2

    move v3, v2

    move-object v2, v1

    move-object v2, v1

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x7

    if-ge v4, v0, :cond_3

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v4}, Lh4/a;->O(I)I

    move-result v5

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v6, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-eq v5, v6, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v6, 0x2

    const/4 v8, 0x1

    if-eq v5, v6, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    const/4 v6, 0x3

    const/4 v8, 0x5

    if-eq v5, v6, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {p1, v4}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v8, 0x0

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    sget-object v2, Lcom/google/android/gms/common/server/response/zam;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {p1, v4, v2}, Lh4/a;->L(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    goto :goto_0

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {p1, v4}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x3

    goto :goto_0

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {p1, v4}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    goto :goto_0

    :cond_3
    const/4 v7, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance p1, Lcom/google/android/gms/common/server/response/zal;

    const/4 v8, 0x5

    invoke-direct {p1, v3, v1, v2}, Lcom/google/android/gms/common/server/response/zal;-><init>(ILjava/lang/String;Ljava/util/ArrayList;)V

    const/4 v7, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    return-object p1
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    new-array p1, p1, [Lcom/google/android/gms/common/server/response/zal;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method
