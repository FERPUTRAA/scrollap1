.class public Lcom/google/android/gms/common/server/response/a;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/server/response/a$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Lcom/google/android/gms/common/server/response/FastJsonResponse;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field private static final g:[C

.field private static final h:[C

.field private static final i:[C

.field private static final j:[C

.field private static final k:[C

.field private static final l:[C

.field private static final m:Lcom/google/android/gms/common/server/response/j;

.field private static final n:Lcom/google/android/gms/common/server/response/j;

.field private static final o:Lcom/google/android/gms/common/server/response/j;

.field private static final p:Lcom/google/android/gms/common/server/response/j;

.field private static final q:Lcom/google/android/gms/common/server/response/j;

.field private static final r:Lcom/google/android/gms/common/server/response/j;

.field private static final s:Lcom/google/android/gms/common/server/response/j;

.field private static final t:Lcom/google/android/gms/common/server/response/j;


# instance fields
.field private final a:[C

.field private final b:[C

.field private final c:[C

.field private final d:Ljava/lang/StringBuilder;

.field private final e:Ljava/lang/StringBuilder;

.field private final f:Ljava/util/Stack;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x7

    const/4 v0, 0x3

    const/4 v4, 0x7

    new-array v1, v0, [C

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    fill-array-data v1, :array_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    sput-object v1, Lcom/google/android/gms/common/server/response/a;->g:[C

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-array v0, v0, [C

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    fill-array-data v0, :array_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->h:[C

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v0, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-array v1, v0, [C

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    fill-array-data v1, :array_2

    const/4 v4, 0x3

    sput-object v1, Lcom/google/android/gms/common/server/response/a;->i:[C

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-array v0, v0, [C

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    fill-array-data v0, :array_3

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->j:[C

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-array v0, v0, [C

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    fill-array-data v0, :array_4

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->k:[C

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    new-array v0, v0, [C

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/16 v2, 0xa

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    aput-char v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->l:[C

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v0, Lcom/google/android/gms/common/server/response/b;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/common/server/response/b;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->m:Lcom/google/android/gms/common/server/response/j;

    const/4 v4, 0x5

    new-instance v0, Lcom/google/android/gms/common/server/response/c;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/common/server/response/c;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->n:Lcom/google/android/gms/common/server/response/j;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Lcom/google/android/gms/common/server/response/d;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/common/server/response/d;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->o:Lcom/google/android/gms/common/server/response/j;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance v0, Lcom/google/android/gms/common/server/response/e;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/common/server/response/e;-><init>()V

    const/4 v3, 0x3

    move v4, v3

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->p:Lcom/google/android/gms/common/server/response/j;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance v0, Lcom/google/android/gms/common/server/response/f;

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/common/server/response/f;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->q:Lcom/google/android/gms/common/server/response/j;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v0, Lcom/google/android/gms/common/server/response/g;

    const/4 v3, 0x4

    or-int/2addr v4, v3

    invoke-direct {v0}, Lcom/google/android/gms/common/server/response/g;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->r:Lcom/google/android/gms/common/server/response/j;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v0, Lcom/google/android/gms/common/server/response/h;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/common/server/response/h;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->s:Lcom/google/android/gms/common/server/response/j;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v0, Lcom/google/android/gms/common/server/response/i;

    const/4 v3, 0x5

    shl-int/2addr v4, v3

    invoke-direct {v0}, Lcom/google/android/gms/common/server/response/i;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    sput-object v0, Lcom/google/android/gms/common/server/response/a;->t:Lcom/google/android/gms/common/server/response/j;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-void

    :array_0
    .array-data 2
        0x75s
        0x6cs
        0x6cs
    .end array-data

    nop

    :array_1
    .array-data 2
        0x72s
        0x75s
        0x65s
    .end array-data

    nop

    :array_2
    .array-data 2
        0x72s
        0x75s
        0x65s
        0x22s
    .end array-data

    :array_3
    .array-data 2
        0x61s
        0x6cs
        0x73s
        0x65s
    .end array-data

    :array_4
    .array-data 2
        0x61s
        0x6cs
        0x73s
        0x65s
        0x22s
    .end array-data
.end method

.method public constructor <init>()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-array v0, v0, [C

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/server/response/a;->a:[C

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/16 v0, 0x20

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-array v1, v0, [C

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/google/android/gms/common/server/response/a;->b:[C

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/16 v1, 0x400

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-array v2, v1, [C

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-object v2, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object v2, p0, Lcom/google/android/gms/common/server/response/a;->d:Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/google/android/gms/common/server/response/a;->e:Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Ljava/util/Stack;

    const/4 v3, 0x4

    move v4, v3

    invoke-direct {v0}, Ljava/util/Stack;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method

.method private final A(Ljava/io/BufferedReader;Z)Z
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "tos~~~~ ~@m t~  @o@~r -@4id  b@f/@  @~bl@os~@@ni@~~l y@~~~ @a@K~1  iboco @  ~~@vM~S@~@@f/@~~. o~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/16 v1, 0x22

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eq v0, v1, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/16 v1, 0x66

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eq v0, v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/16 v1, 0x6e

    const/4 v5, 0x1

    const/4 v4, 0x2

    if-eq v0, v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/16 v1, 0x74

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-ne v0, v1, :cond_1

    if-eqz p2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    sget-object p2, Lcom/google/android/gms/common/server/response/a;->i:[C

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget-object p2, Lcom/google/android/gms/common/server/response/a;->h:[C

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/server/response/a;->z(Ljava/io/BufferedReader;[C)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    return v2

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string v1, "Uc:mkdne teoe setx"

    const-string v1, " es:ndepte kxocUte"

    const/4 v5, 0x6

    const-string v1, "Unexpected token: "

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    throw p1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget-object p2, Lcom/google/android/gms/common/server/response/a;->g:[C

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/server/response/a;->z(Ljava/io/BufferedReader;[C)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v3

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz p2, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    sget-object p2, Lcom/google/android/gms/common/server/response/a;->k:[C

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_1

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget-object p2, Lcom/google/android/gms/common/server/response/a;->j:[C

    :goto_1
    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/server/response/a;->z(Ljava/io/BufferedReader;[C)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    return v3

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez p2, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {p0, p1, v2}, Lcom/google/android/gms/common/server/response/a;->A(Ljava/io/BufferedReader;Z)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    return p1

    :cond_6
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const-string/jumbo p2, "so foNnuietn v   uardoaeoillbnon"

    const-string/jumbo p2, "lvnmft oar n eiobounealdunis No "

    const/4 v5, 0x3

    const-string/jumbo p2, "ndstgba  eofo n linru iNanoleubo"

    const-string p2, "No boolean value found in string"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    throw p1
.end method

.method private final B(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/FastJsonResponse;)Z
    .locals 16
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    const-string v3, " bst nuriticoaoEntr intjgranener"

    const-string/jumbo v3, "tnrioE ieaotiga nbrj tnencosrrtn"

    const-string v3, "anr bnnptrtanojtr egnsceiitiirE "

    const-string v3, "Error instantiating inner object"

    invoke-virtual/range {p2 .. p2}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->getFieldMappings()Ljava/util/Map;

    move-result-object v4

    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->s(Ljava/io/BufferedReader;)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x1

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    if-eqz v5, :cond_1a

    :goto_0
    if-eqz v5, :cond_19

    invoke-interface {v4, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    if-nez v5, :cond_0

    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->t(Ljava/io/BufferedReader;)Ljava/lang/String;

    move-result-object v5

    goto :goto_0

    :cond_0
    iget-object v9, v1, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v10, 0x4

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v9, v11}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    iget v9, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->b:I

    const/16 v11, 0x7b

    const/16 v12, 0x2c

    const/16 v13, 0x7d

    const/16 v14, 0x6e

    const/4 v15, 0x0

    packed-switch v9, :pswitch_data_0

    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "iildntIfq a e vypdl"

    const-string v3, "Invalid field type "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_0
    iget-boolean v9, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    if-eqz v9, :cond_3

    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v9

    if-ne v9, v14, :cond_1

    sget-object v9, Lcom/google/android/gms/common/server/response/a;->g:[C

    invoke-direct {v1, v0, v9}, Lcom/google/android/gms/common/server/response/a;->z(Ljava/io/BufferedReader;[C)V

    iget-object v9, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->f:Ljava/lang/String;

    invoke-virtual {v2, v5, v9, v15}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->addConcreteTypeArrayInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V

    goto :goto_1

    :cond_1
    iget-object v11, v1, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v14, 0x5

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-virtual {v11, v14}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v11, 0x5b

    if-ne v9, v11, :cond_2

    iget-object v9, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->f:Ljava/lang/String;

    invoke-direct {v1, v0, v5}, Lcom/google/android/gms/common/server/response/a;->x(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v2, v5, v9, v11}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->addConcreteTypeArrayInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V

    goto :goto_1

    :cond_2
    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    const-string/jumbo v2, "trsyaptcasrerate E x"

    const-string v2, "Expected array start"

    invoke-direct {v0, v2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3
    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v9

    if-ne v9, v14, :cond_4

    sget-object v9, Lcom/google/android/gms/common/server/response/a;->g:[C

    invoke-direct {v1, v0, v9}, Lcom/google/android/gms/common/server/response/a;->z(Ljava/io/BufferedReader;[C)V

    iget-object v9, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->f:Ljava/lang/String;

    invoke-virtual {v2, v5, v9, v15}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->addConcreteTypeInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Lcom/google/android/gms/common/server/response/FastJsonResponse;)V

    :goto_1
    move v5, v10

    move v5, v10

    move v5, v10

    move v5, v10

    goto/16 :goto_5

    :cond_4
    iget-object v14, v1, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    invoke-virtual {v14, v8}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    if-ne v9, v11, :cond_5

    :try_start_0
    invoke-virtual {v5}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->O2()Lcom/google/android/gms/common/server/response/FastJsonResponse;

    move-result-object v9

    invoke-direct {v1, v0, v9}, Lcom/google/android/gms/common/server/response/a;->B(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/FastJsonResponse;)Z

    iget-object v11, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->f:Ljava/lang/String;

    invoke-virtual {v2, v5, v11, v9}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->addConcreteTypeInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Lcom/google/android/gms/common/server/response/FastJsonResponse;)V
    :try_end_0
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    new-instance v2, Lcom/google/android/gms/common/server/response/a$a;

    invoke-direct {v2, v3, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v2

    :catch_1
    move-exception v0

    new-instance v2, Lcom/google/android/gms/common/server/response/a$a;

    invoke-direct {v2, v3, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v2

    :cond_5
    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    const-string/jumbo v2, "etfm etbcotacxobr pdesjE"

    const-string/jumbo v2, "ftpdebbeas rctEtx ocoje "

    const-string/jumbo v2, "ptrsoe Et ofct jaectxdob"

    const-string v2, "Expected start of object"

    invoke-direct {v0, v2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_1
    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v9

    if-ne v9, v14, :cond_6

    sget-object v9, Lcom/google/android/gms/common/server/response/a;->g:[C

    invoke-direct {v1, v0, v9}, Lcom/google/android/gms/common/server/response/a;->z(Ljava/io/BufferedReader;[C)V

    move-object v9, v15

    move-object v9, v15

    move-object v9, v15

    goto :goto_3

    :cond_6
    if-ne v9, v11, :cond_e

    iget-object v9, v1, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    invoke-virtual {v9, v8}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v9, Ljava/util/HashMap;

    invoke-direct {v9}, Ljava/util/HashMap;-><init>()V

    :goto_2
    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v11

    if-eqz v11, :cond_d

    const/16 v14, 0x22

    if-eq v11, v14, :cond_8

    if-eq v11, v13, :cond_7

    goto :goto_2

    :cond_7
    invoke-direct {v1, v7}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    goto :goto_3

    :cond_8
    iget-object v11, v1, Lcom/google/android/gms/common/server/response/a;->b:[C

    iget-object v10, v1, Lcom/google/android/gms/common/server/response/a;->d:Ljava/lang/StringBuilder;

    invoke-static {v0, v11, v10, v15}, Lcom/google/android/gms/common/server/response/a;->b(Ljava/io/BufferedReader;[CLjava/lang/StringBuilder;[C)Ljava/lang/String;

    move-result-object v10

    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v11

    const/16 v6, 0x3a

    if-ne v11, v6, :cond_c

    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v6

    if-ne v6, v14, :cond_b

    iget-object v6, v1, Lcom/google/android/gms/common/server/response/a;->b:[C

    iget-object v11, v1, Lcom/google/android/gms/common/server/response/a;->d:Ljava/lang/StringBuilder;

    invoke-static {v0, v6, v11, v15}, Lcom/google/android/gms/common/server/response/a;->b(Ljava/io/BufferedReader;[CLjava/lang/StringBuilder;[C)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v9, v10, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v6

    if-eq v6, v12, :cond_a

    if-ne v6, v13, :cond_9

    invoke-direct {v1, v7}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    :goto_3
    invoke-virtual {v2, v5, v9}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaB(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/util/Map;)V

    goto/16 :goto_4

    :cond_9
    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "pswalbetUgritapig hxccnheuerepar t: ie c rsadnm"

    const-string/jumbo v3, "rlp mUuacnewad  it:pietn rheeagcg sr ctherxpasi"

    const-string v3, "acrtasu wrhl : ericpmgtaneUrp eehnp gendcsiaxt "

    const-string v3, "Unexpected character while parsing string map: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a
    const/4 v10, 0x4

    goto :goto_2

    :cond_b
    invoke-static {v10}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Lcom/google/android/gms/common/server/response/a$a;

    const-string v3, "a eve epS grkntlio  pxEdryftpc"

    const-string/jumbo v3, "vil eappeugreESttkd rycn xf  o"

    const-string/jumbo v3, "reaigvfoqeteuxteyrcSp  l Edn k"

    const-string v3, "Expected String value for key "

    invoke-virtual {v3, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_c
    invoke-static {v10}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Lcom/google/android/gms/common/server/response/a$a;

    const-string/jumbo v3, "rysood om nfa  upaleefk quN"

    const-string/jumbo v3, "laeoua rqe po n  oudkymNvff"

    const-string v3, "Ne myu aedmorok f nfa vopul"

    const-string v3, "No map value found for key "

    invoke-virtual {v3, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_d
    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    const-string/jumbo v2, "nsEFop eUtOxec"

    const-string/jumbo v2, "xps FtnOEeceUe"

    const-string v2, "UeOxnbdeetcFpE"

    const-string v2, "Unexpected EOF"

    invoke-direct {v0, v2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_e
    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    const-string/jumbo v2, "settxjubod o eaaE m rmccaptft "

    const-string/jumbo v2, "f emdateto op ajmcEcbptras tx "

    const-string v2, "Expected start of a map object"

    invoke-direct {v0, v2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_2
    iget-object v6, v1, Lcom/google/android/gms/common/server/response/a;->c:[C

    iget-object v9, v1, Lcom/google/android/gms/common/server/response/a;->e:Ljava/lang/StringBuilder;

    sget-object v10, Lcom/google/android/gms/common/server/response/a;->l:[C

    invoke-direct {v1, v0, v6, v9, v10}, Lcom/google/android/gms/common/server/response/a;->r(Ljava/io/BufferedReader;[CLjava/lang/StringBuilder;[C)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/google/android/gms/common/util/c;->b(Ljava/lang/String;)[B

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;[B)V

    goto :goto_4

    :pswitch_3
    iget-object v6, v1, Lcom/google/android/gms/common/server/response/a;->c:[C

    iget-object v9, v1, Lcom/google/android/gms/common/server/response/a;->e:Ljava/lang/StringBuilder;

    sget-object v10, Lcom/google/android/gms/common/server/response/a;->l:[C

    invoke-direct {v1, v0, v6, v9, v10}, Lcom/google/android/gms/common/server/response/a;->r(Ljava/io/BufferedReader;[CLjava/lang/StringBuilder;[C)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/google/android/gms/common/util/c;->a(Ljava/lang/String;)[B

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;[B)V

    :goto_4
    const/4 v5, 0x4

    goto/16 :goto_5

    :pswitch_4
    iget-boolean v6, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    if-eqz v6, :cond_f

    sget-object v6, Lcom/google/android/gms/common/server/response/a;->r:Lcom/google/android/gms/common/server/response/j;

    invoke-direct {v1, v0, v6}, Lcom/google/android/gms/common/server/response/a;->w(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/j;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaC(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/util/ArrayList;)V

    goto :goto_4

    :cond_f
    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->q(Ljava/io/BufferedReader;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaA(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;)V

    goto :goto_4

    :pswitch_5
    iget-boolean v6, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    if-eqz v6, :cond_10

    sget-object v6, Lcom/google/android/gms/common/server/response/a;->q:Lcom/google/android/gms/common/server/response/j;

    invoke-direct {v1, v0, v6}, Lcom/google/android/gms/common/server/response/a;->w(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/j;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaj(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/util/ArrayList;)V

    goto :goto_4

    :cond_10
    const/4 v6, 0x0

    invoke-direct {v1, v0, v6}, Lcom/google/android/gms/common/server/response/a;->A(Ljava/io/BufferedReader;Z)Z

    move-result v9

    invoke-virtual {v2, v5, v9}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zai(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Z)V

    goto :goto_4

    :pswitch_6
    iget-boolean v6, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    if-eqz v6, :cond_11

    sget-object v6, Lcom/google/android/gms/common/server/response/a;->t:Lcom/google/android/gms/common/server/response/j;

    invoke-direct {v1, v0, v6}, Lcom/google/android/gms/common/server/response/a;->w(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/j;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zac(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/util/ArrayList;)V

    goto :goto_4

    :cond_11
    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->u(Ljava/io/BufferedReader;)Ljava/math/BigDecimal;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaa(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/math/BigDecimal;)V

    goto :goto_4

    :pswitch_7
    iget-boolean v6, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    if-eqz v6, :cond_12

    sget-object v6, Lcom/google/android/gms/common/server/response/a;->p:Lcom/google/android/gms/common/server/response/j;

    invoke-direct {v1, v0, v6}, Lcom/google/android/gms/common/server/response/a;->w(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/j;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zao(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/util/ArrayList;)V

    goto :goto_4

    :cond_12
    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->l(Ljava/io/BufferedReader;)D

    move-result-wide v9

    invoke-virtual {v2, v5, v9, v10}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zam(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;D)V

    goto :goto_4

    :pswitch_8
    iget-boolean v6, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    if-eqz v6, :cond_13

    sget-object v6, Lcom/google/android/gms/common/server/response/a;->o:Lcom/google/android/gms/common/server/response/j;

    invoke-direct {v1, v0, v6}, Lcom/google/android/gms/common/server/response/a;->w(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/j;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zas(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/util/ArrayList;)V

    goto :goto_4

    :cond_13
    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->m(Ljava/io/BufferedReader;)F

    move-result v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaq(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;F)V

    goto :goto_4

    :pswitch_9
    iget-boolean v6, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    if-eqz v6, :cond_14

    sget-object v6, Lcom/google/android/gms/common/server/response/a;->n:Lcom/google/android/gms/common/server/response/j;

    invoke-direct {v1, v0, v6}, Lcom/google/android/gms/common/server/response/a;->w(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/j;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zay(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/util/ArrayList;)V

    goto :goto_4

    :cond_14
    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->p(Ljava/io/BufferedReader;)J

    move-result-wide v9

    invoke-virtual {v2, v5, v9, v10}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zax(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;J)V

    goto/16 :goto_4

    :pswitch_a
    iget-boolean v6, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    if-eqz v6, :cond_15

    sget-object v6, Lcom/google/android/gms/common/server/response/a;->s:Lcom/google/android/gms/common/server/response/j;

    invoke-direct {v1, v0, v6}, Lcom/google/android/gms/common/server/response/a;->w(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/j;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zag(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/util/ArrayList;)V

    goto/16 :goto_4

    :cond_15
    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->v(Ljava/io/BufferedReader;)Ljava/math/BigInteger;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zae(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/math/BigInteger;)V

    goto/16 :goto_4

    :pswitch_b
    iget-boolean v6, v5, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    if-eqz v6, :cond_16

    sget-object v6, Lcom/google/android/gms/common/server/response/a;->m:Lcom/google/android/gms/common/server/response/j;

    invoke-direct {v1, v0, v6}, Lcom/google/android/gms/common/server/response/a;->w(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/j;)Ljava/util/ArrayList;

    move-result-object v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zav(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/util/ArrayList;)V

    goto/16 :goto_4

    :cond_16
    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->n(Ljava/io/BufferedReader;)I

    move-result v6

    invoke-virtual {v2, v5, v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zau(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;I)V

    goto/16 :goto_4

    :goto_5
    invoke-direct {v1, v5}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 v5, 0x2

    invoke-direct {v1, v5}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v5

    if-eq v5, v12, :cond_18

    if-ne v5, v13, :cond_17

    move-object v5, v15

    move-object v5, v15

    move-object v5, v15

    move-object v5, v15

    goto/16 :goto_0

    :cond_17
    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, " f nxreptdtpiee,o btuurlcaddojto :es aen bopf ro oedc "

    const-string v3, "dtpfottarna ,   oroe  cebuldpei: besdExde fcounoertjo "

    const-string v3, "efref edq n t tj b:bsopduocdaaritoot  no cfd eEuprlexe"

    const-string v3, "Expected end of object or field separator, but found: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_18
    invoke-direct/range {p0 .. p1}, Lcom/google/android/gms/common/server/response/a;->s(Ljava/io/BufferedReader;)Ljava/lang/String;

    move-result-object v5

    goto/16 :goto_0

    :cond_19
    invoke-direct {v1, v7}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    return v7

    :cond_1a
    invoke-direct {v1, v7}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 v0, 0x0

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private static final b(Ljava/io/BufferedReader;[CLjava/lang/StringBuilder;[C)Ljava/lang/String;
    .locals 10
    .param p3    # [C
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v0, 0x0

    const/4 v9, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->setLength(I)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    array-length v1, p1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {p0, v1}, Ljava/io/BufferedReader;->mark(I)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    move v1, v0

    move v1, v0

    const/4 v9, 0x6

    move v1, v0

    move v1, v0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    move v2, v1

    move v2, v1

    const/4 v9, 0x0

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {p0, p1}, Ljava/io/Reader;->read([C)I

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v4, 0x0

    const/4 v4, -0x1

    const/4 v9, 0x0

    if-eq v3, v4, :cond_6

    const/4 v9, 0x5

    move v4, v0

    move v4, v0

    move v4, v0

    move v4, v0

    :goto_1
    const/4 v8, 0x3

    move v9, v8

    if-ge v4, v3, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    aget-char v5, p1, v4

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v5}, Ljava/lang/Character;->isISOControl(C)Z

    move-result v6

    const/4 v9, 0x6

    const/4 v8, 0x4

    if-eqz v6, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-eqz p3, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    aget-char v6, p3, v0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-ne v6, v5, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    goto :goto_2

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance p0, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v9, 0x6

    const-string/jumbo p1, "nrsetgpcee xr b d swechoihocealticrrlUtta nnaredg"

    const-string/jumbo p1, "etihrbihlgoccecltc r Ueee rseann ripgad rxntadotw"

    const/4 v9, 0x7

    const-string/jumbo p1, "tgnmx Utrgsrhhtcn  i erp ocoacerlnteiedeniclreawd"

    const-string p1, "Unexpected control character while reading string"

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    throw p0

    :cond_1
    :goto_2
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    add-int/lit8 v6, v4, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/16 v7, 0x22

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-ne v5, v7, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-nez v1, :cond_4

    const/4 v8, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p2, p1, v0, v4}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x2

    invoke-virtual {p0}, Ljava/io/BufferedReader;->reset()V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    int-to-long v0, v6

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p0, v0, v1}, Ljava/io/BufferedReader;->skip(J)J

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-eqz v2, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/util/r;->c(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    return-object p0

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    return-object p0

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/16 v4, 0x5c

    const/4 v9, 0x7

    if-ne v5, v4, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    xor-int/lit8 v1, v1, 0x1

    const/4 v9, 0x7

    const/4 v2, 0x7

    const/4 v9, 0x0

    const/4 v2, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    goto :goto_3

    :cond_4
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    move v1, v0

    const/4 v9, 0x6

    move v1, v0

    move v1, v0

    :goto_3
    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    move v4, v6

    move v4, v6

    goto/16 :goto_1

    :cond_5
    const/4 v8, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {p2, p1, v0, v3}, Ljava/lang/StringBuilder;->append([CII)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    array-length v3, p1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p0, v3}, Ljava/io/BufferedReader;->mark(I)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    goto/16 :goto_0

    :cond_6
    const/4 v9, 0x6

    const/4 v8, 0x0

    new-instance p0, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string/jumbo p1, "i eeogictxlOewid  rnrnthFpsEae Usgu"

    const-string p1, " grexUuicg eeewsiE tnOinFhdsalptrn "

    const/4 v9, 0x4

    const-string p1, " Eiasbrscneepde lhUrtg nniFei gtOpw"

    const-string p1, "Unexpected EOF while parsing string"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    throw p0
.end method

.method static bridge synthetic c(Lcom/google/android/gms/common/server/response/a;Ljava/io/BufferedReader;)D
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->l(Ljava/io/BufferedReader;)D

    move-result-wide p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-wide p0
.end method

.method static bridge synthetic d(Lcom/google/android/gms/common/server/response/a;Ljava/io/BufferedReader;)F
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->m(Ljava/io/BufferedReader;)F

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return p0
.end method

.method static bridge synthetic e(Lcom/google/android/gms/common/server/response/a;Ljava/io/BufferedReader;)I
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->n(Ljava/io/BufferedReader;)I

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x2

    return p0
.end method

.method static bridge synthetic f(Lcom/google/android/gms/common/server/response/a;Ljava/io/BufferedReader;)J
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->p(Ljava/io/BufferedReader;)J

    move-result-wide p0

    const/4 v1, 0x4

    return-wide p0
.end method

.method static bridge synthetic g(Lcom/google/android/gms/common/server/response/a;Ljava/io/BufferedReader;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->q(Ljava/io/BufferedReader;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-object p0
.end method

.method static bridge synthetic h(Lcom/google/android/gms/common/server/response/a;Ljava/io/BufferedReader;)Ljava/math/BigDecimal;
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->u(Ljava/io/BufferedReader;)Ljava/math/BigDecimal;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method static bridge synthetic i(Lcom/google/android/gms/common/server/response/a;Ljava/io/BufferedReader;)Ljava/math/BigInteger;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->v(Ljava/io/BufferedReader;)Ljava/math/BigInteger;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method static bridge synthetic j(Lcom/google/android/gms/common/server/response/a;Ljava/io/BufferedReader;Z)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p2, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/server/response/a;->A(Ljava/io/BufferedReader;Z)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    return p0
.end method

.method private final k(Ljava/io/BufferedReader;)C
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->a:[C

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Ljava/io/Reader;->read([C)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v2, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eq v0, v2, :cond_2

    :cond_0
    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->a:[C

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    aget-char v0, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/lang/Character;->isWhitespace(C)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->a:[C

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Ljava/io/Reader;->read([C)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-ne v0, v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/server/response/a;->a:[C

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    aget-char p1, p1, v1

    return p1

    :cond_2
    :goto_0
    const/4 v3, 0x1

    const/4 v4, 0x1

    return v1
.end method

.method private final l(Ljava/io/BufferedReader;)D
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/server/response/a;->o(Ljava/io/BufferedReader;[C)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x2

    const-wide/16 v0, 0x0

    const/4 v4, 0x7

    return-wide v0

    :cond_0
    const/4 v3, 0x5

    move v4, v3

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v1, v0, v2, p1}, Ljava/lang/String;-><init>([CII)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v1}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-wide v0
.end method

.method private final m(Ljava/io/BufferedReader;)F
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    const/4 v3, 0x5

    move v4, v3

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/server/response/a;->o(Ljava/io/BufferedReader;[C)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-nez p1, :cond_0

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    const/4 p1, 0x0

    const/4 p1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    return p1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v1, v0, v2, p1}, Ljava/lang/String;-><init>([CII)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-static {v1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    return p1
.end method

.method private final n(Ljava/io/BufferedReader;)I
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/server/response/a;->o(Ljava/io/BufferedReader;[C)I

    move-result p1

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x3

    const/4 v0, 0x0

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x6

    if-nez p1, :cond_0

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    return v0

    :cond_0
    const/4 v12, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    if-lez p1, :cond_b

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x5

    aget-char v2, v1, v0

    const/4 v11, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x6

    const/16 v3, 0x2d

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x7

    if-ne v2, v3, :cond_1

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x5

    const/high16 v4, -0x80000000

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x6

    goto :goto_0

    :cond_1
    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x0

    const v4, -0x7fffffff

    :goto_0
    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    const/4 v5, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x0

    if-ne v2, v3, :cond_2

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x1

    move v2, v5

    move v2, v5

    const/4 v12, 0x1

    move v2, v5

    move v2, v5

    const/4 v12, 0x2

    goto :goto_1

    :cond_2
    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x2

    move v2, v0

    move v2, v0

    const/4 v12, 0x1

    move v2, v0

    move v2, v0

    :goto_1
    const/4 v12, 0x4

    const-string v3, "drp-tcunapthinexg rtcioaeUecen"

    const-string/jumbo v3, "i-arghUp cptnntenaxd eitocerce"

    const/4 v12, 0x0

    const-string/jumbo v3, "thac-xppedngcc naorirnietetd e"

    const-string v3, "Unexpected non-digit character"

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x4

    const/16 v6, 0xa

    const/4 v12, 0x0

    const/4 v11, 0x1

    if-ge v2, p1, :cond_4

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    add-int/lit8 v0, v2, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    aget-char v7, v1, v2

    const/4 v12, 0x4

    const/4 v11, 0x3

    invoke-static {v7, v6}, Ljava/lang/Character;->digit(CI)I

    move-result v7

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x0

    if-ltz v7, :cond_3

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    neg-int v7, v7

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x0

    goto :goto_2

    :cond_3
    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-direct {p1, v3}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    throw p1

    :cond_4
    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x0

    move v7, v0

    move v7, v0

    const/4 v12, 0x6

    move v7, v0

    const/4 v12, 0x4

    const/4 v11, 0x4

    move v0, v2

    move v0, v2

    const/4 v12, 0x4

    move v0, v2

    move v0, v2

    :goto_2
    const/4 v12, 0x7

    if-ge v0, p1, :cond_8

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    add-int/lit8 v8, v0, 0x1

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    aget-char v0, v1, v0

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-static {v0, v6}, Ljava/lang/Character;->digit(CI)I

    move-result v0

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-ltz v0, :cond_7

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x2

    const v9, -0xccccccc

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    const-string v10, " oum tgbqqNreral"

    const-string/jumbo v10, "tmerrl gqo uobNa"

    const/4 v12, 0x3

    const-string v10, " esbrtlreouam oN"

    const-string v10, "Number too large"

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x5

    if-lt v7, v9, :cond_6

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    mul-int/lit8 v7, v7, 0xa

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    add-int v9, v4, v0

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x5

    if-lt v7, v9, :cond_5

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x5

    sub-int/2addr v7, v0

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x1

    move v0, v8

    const/4 v12, 0x2

    move v0, v8

    move v0, v8

    const/4 v12, 0x3

    goto :goto_2

    :cond_5
    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x0

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v11, 0x3

    shr-int/2addr v12, v11

    invoke-direct {p1, v10}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    throw p1

    :cond_6
    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x3

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-direct {p1, v10}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    throw p1

    :cond_7
    const/4 v11, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x0

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-direct {p1, v3}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x4

    throw p1

    :cond_8
    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    if-eqz v2, :cond_a

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    if-le v0, v5, :cond_9

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x5

    goto :goto_3

    :cond_9
    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x2

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    const-string v0, " s meopsdaogtisNit"

    const-string/jumbo v0, "etso pigo ssiatNdr"

    const/4 v12, 0x2

    const-string v0, "No digits to parse"

    const/4 v12, 0x3

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    throw p1

    :cond_a
    const/4 v11, 0x6

    const/4 v12, 0x1

    neg-int v7, v7

    :goto_3
    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x6

    return v7

    :cond_b
    const/4 v12, 0x2

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x4

    const-string/jumbo v0, "nrueomsober pa  Nt"

    const-string v0, "a bmorpeots  ueNnr"

    const/4 v12, 0x3

    const-string/jumbo v0, "sprmnbrNabteou  eo"

    const-string v0, "No number to parse"

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x5

    throw p1
.end method

.method private final o(Ljava/io/BufferedReader;[C)I
    .locals 12
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v0

    const/4 v11, 0x6

    const/4 v10, 0x5

    const-string v1, "eeF ncuUdpExOe"

    const-string v1, "Unexpected EOF"

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-eqz v0, :cond_b

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/16 v2, 0x2c

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x1

    if-eq v0, v2, :cond_a

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/16 v3, 0x6e

    const/4 v10, 0x5

    const/4 v11, 0x0

    const/4 v4, 0x0

    const/4 v11, 0x5

    if-ne v0, v3, :cond_0

    const/4 v11, 0x2

    sget-object p2, Lcom/google/android/gms/common/server/response/a;->g:[C

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/server/response/a;->z(Ljava/io/BufferedReader;[C)V

    const/4 v11, 0x0

    return v4

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x4

    const/16 v3, 0x400

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {p1, v3}, Ljava/io/BufferedReader;->mark(I)V

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    const/16 v5, 0x22

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    const/4 v6, -0x1

    const/4 v11, 0x4

    const/4 v7, 0x1

    const/4 v11, 0x3

    move v10, v7

    move v10, v7

    const/4 v11, 0x4

    if-ne v0, v5, :cond_5

    const/4 v11, 0x6

    move v0, v4

    move v0, v4

    const/4 v11, 0x5

    move v0, v4

    move v0, v4

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x1

    move v2, v0

    move v2, v0

    const/4 v11, 0x4

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x6

    if-ge v0, v3, :cond_8

    const/4 v10, 0x2

    xor-int/2addr v11, v10

    invoke-virtual {p1, p2, v0, v7}, Ljava/io/BufferedReader;->read([CII)I

    move-result v8

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-eq v8, v6, :cond_8

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    aget-char v8, p2, v0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-static {v8}, Ljava/lang/Character;->isISOControl(C)Z

    move-result v9

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-nez v9, :cond_4

    const/4 v11, 0x0

    const/4 v10, 0x4

    add-int/lit8 v9, v0, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    if-ne v8, v5, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-eqz v2, :cond_1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    goto :goto_1

    :cond_1
    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {p1}, Ljava/io/BufferedReader;->reset()V

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    int-to-long v1, v9

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {p1, v1, v2}, Ljava/io/BufferedReader;->skip(J)J

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    return v0

    :cond_2
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    const/16 v0, 0x5c

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x1

    if-ne v8, v0, :cond_3

    const/4 v10, 0x2

    xor-int/2addr v11, v10

    xor-int/lit8 v0, v2, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x7

    move v2, v0

    move v2, v0

    const/4 v11, 0x7

    move v2, v0

    move v2, v0

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v11, 0x6

    const/4 v10, 0x3

    move v2, v4

    move v2, v4

    const/4 v11, 0x7

    move v2, v4

    move v2, v4

    :goto_2
    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    move v0, v9

    const/4 v11, 0x2

    move v0, v9

    move v0, v9

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    goto :goto_0

    :cond_4
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const-string p2, "ee eaoepxiltnshthacUgterwc go ln icordc rannprtri"

    const-string p2, " trao nopntwrscrrehi thxUgtarcnioedad g ielclceen"

    const/4 v11, 0x1

    const-string/jumbo p2, "ort ndreqhwng o naiUlepeieear xhertnrdctc aiccltg"

    const-string p2, "Unexpected control character while reading string"

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    throw p1

    :cond_5
    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    aput-char v0, p2, v4

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    move v0, v7

    move v0, v7

    const/4 v11, 0x2

    move v0, v7

    move v0, v7

    :goto_3
    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-ge v0, v3, :cond_8

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {p1, p2, v0, v7}, Ljava/io/BufferedReader;->read([CII)I

    move-result v5

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-eq v5, v6, :cond_8

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    aget-char v5, p2, v0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/16 v8, 0x7d

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    if-eq v5, v8, :cond_7

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    if-eq v5, v2, :cond_7

    const/4 v10, 0x4

    and-int/2addr v11, v10

    invoke-static {v5}, Ljava/lang/Character;->isWhitespace(C)Z

    move-result v5

    const/4 v11, 0x2

    const/4 v10, 0x3

    if-nez v5, :cond_7

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    aget-char v5, p2, v0

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    const/16 v8, 0x5d

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-ne v5, v8, :cond_6

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    goto :goto_4

    :cond_6
    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    goto :goto_3

    :cond_7
    :goto_4
    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {p1}, Ljava/io/BufferedReader;->reset()V

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    add-int/lit8 v1, v0, -0x1

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x4

    int-to-long v1, v1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {p1, v1, v2}, Ljava/io/BufferedReader;->skip(J)J

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    aput-char v4, p2, v0

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    return v0

    :cond_8
    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x5

    if-ne v0, v3, :cond_9

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    const-string/jumbo p2, "sos lur lnbbulgAvay"

    const-string/jumbo p2, "la yoblgurlb vundAs"

    const/4 v11, 0x5

    const-string/jumbo p2, "yndm  elvaluAuglrso"

    const-string p2, "Absurdly long value"

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    throw p1

    :cond_9
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-direct {p1, v1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    throw p1

    :cond_a
    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x3

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v10, 0x4

    or-int/2addr v11, v10

    const-string/jumbo p2, "vgiaousn sieM"

    const-string p2, " sveMiuinuags"

    const/4 v11, 0x4

    const-string/jumbo p2, "s liMbegsinvu"

    const-string p2, "Missing value"

    const/4 v10, 0x1

    move v11, v10

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    throw p1

    :cond_b
    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-direct {p1, v1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    move v11, v10

    throw p1
.end method

.method private final p(Ljava/io/BufferedReader;)J
    .locals 17
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    iget-object v1, v0, Lcom/google/android/gms/common/server/response/a;->c:[C

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    invoke-direct {v0, v2, v1}, Lcom/google/android/gms/common/server/response/a;->o(Ljava/io/BufferedReader;[C)I

    move-result v1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    if-nez v1, :cond_0

    return-wide v2

    :cond_0
    iget-object v4, v0, Lcom/google/android/gms/common/server/response/a;->c:[C

    if-lez v1, :cond_b

    const/4 v5, 0x0

    aget-char v6, v4, v5

    const/16 v7, 0x2d

    if-ne v6, v7, :cond_1

    const-wide/high16 v8, -0x8000000000000000L

    const-wide/high16 v8, -0x8000000000000000L

    const-wide/high16 v8, -0x8000000000000000L

    const-wide/high16 v8, -0x8000000000000000L

    goto :goto_0

    :cond_1
    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    const-wide v8, -0x7fffffffffffffffL    # -4.9E-324

    :goto_0
    const/4 v10, 0x1

    if-ne v6, v7, :cond_2

    move v5, v10

    move v5, v10

    move v5, v10

    move v5, v10

    :cond_2
    const-string/jumbo v6, "rihpenuce eg-to etndtacUcxndri"

    const-string v6, "Unexpected non-digit character"

    const/16 v7, 0xa

    if-ge v5, v1, :cond_4

    add-int/lit8 v2, v5, 0x1

    aget-char v3, v4, v5

    invoke-static {v3, v7}, Ljava/lang/Character;->digit(CI)I

    move-result v3

    if-ltz v3, :cond_3

    neg-int v3, v3

    int-to-long v11, v3

    goto :goto_1

    :cond_3
    new-instance v1, Lcom/google/android/gms/common/server/response/a$a;

    invoke-direct {v1, v6}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_4
    move-wide v11, v2

    move v2, v5

    move v2, v5

    move v2, v5

    :goto_1
    if-ge v2, v1, :cond_8

    add-int/lit8 v3, v2, 0x1

    aget-char v2, v4, v2

    invoke-static {v2, v7}, Ljava/lang/Character;->digit(CI)I

    move-result v2

    if-ltz v2, :cond_7

    const-wide v13, -0xcccccccccccccccL

    const-wide v13, -0xcccccccccccccccL

    const-wide v13, -0xcccccccccccccccL

    const-wide v13, -0xcccccccccccccccL

    cmp-long v13, v11, v13

    const-string/jumbo v14, "tum bropar ogpel"

    const-string/jumbo v14, "loaNbgrpeoutmr  "

    const-string/jumbo v14, "tulNrg eqaemorb "

    const-string v14, "Number too large"

    if-ltz v13, :cond_6

    const-wide/16 v15, 0xa

    const-wide/16 v15, 0xa

    const-wide/16 v15, 0xa

    const-wide/16 v15, 0xa

    mul-long/2addr v11, v15

    move/from16 p1, v1

    move/from16 p1, v1

    move/from16 p1, v1

    move/from16 p1, v1

    int-to-long v0, v2

    add-long v15, v8, v0

    cmp-long v2, v11, v15

    if-ltz v2, :cond_5

    sub-long/2addr v11, v0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v1, p1

    move/from16 v1, p1

    move/from16 v1, p1

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    goto :goto_1

    :cond_5
    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    invoke-direct {v0, v14}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_6
    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    invoke-direct {v0, v14}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_7
    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    invoke-direct {v0, v6}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_8
    if-eqz v5, :cond_a

    if-le v2, v10, :cond_9

    goto :goto_2

    :cond_9
    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    const-string v1, " terdsoaqgNtsioi  "

    const-string v1, " ostoi rsia Ngsdet"

    const-string v1, "No digits to parse"

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a
    neg-long v11, v11

    :goto_2
    return-wide v11

    :cond_b
    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    const-string/jumbo v1, "maumsopob erNerst "

    const-string/jumbo v1, "pus o orretbmasNne"

    const-string v1, " mr outabeernNopso"

    const-string v1, "No number to parse"

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private final q(Ljava/io/BufferedReader;)Ljava/lang/String;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->b:[C

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/server/response/a;->d:Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p0, p1, v0, v1, v2}, Lcom/google/android/gms/common/server/response/a;->r(Ljava/io/BufferedReader;[CLjava/lang/StringBuilder;[C)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object p1
.end method

.method private final r(Ljava/io/BufferedReader;[CLjava/lang/StringBuilder;[C)Ljava/lang/String;
    .locals 4
    .param p4    # [C
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/16 v1, 0x22

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eq v0, v1, :cond_1

    const/4 v3, 0x6

    const/16 p2, 0x6e

    const/4 v3, 0x3

    const/4 v2, 0x1

    if-ne v0, p2, :cond_0

    const/4 v2, 0x5

    and-int/2addr v3, v2

    sget-object p2, Lcom/google/android/gms/common/server/response/a;->g:[C

    const/4 v3, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/server/response/a;->z(Ljava/io/BufferedReader;[C)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo p2, "smcepbtregit En"

    const-string/jumbo p2, "teim pgscnxEert"

    const/4 v3, 0x7

    const-string/jumbo p2, "in pEdutexegtcr"

    const-string p2, "Expected string"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    throw p1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p1, p2, p3, p4}, Lcom/google/android/gms/common/server/response/a;->b(Ljava/io/BufferedReader;[CLjava/lang/StringBuilder;[C)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object p1
.end method

.method private final s(Ljava/io/BufferedReader;)Ljava/lang/String;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v4, 0x2

    xor-int/2addr v5, v4

    const/4 v1, 0x2

    xor-int/2addr v5, v1

    const/4 v4, 0x0

    move v5, v4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/16 v2, 0x22

    const/4 v4, 0x1

    move v5, v4

    const/4 v3, 0x0

    move v5, v3

    const/4 v4, 0x1

    or-int/2addr v5, v4

    if-eq v0, v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/16 p1, 0x5d

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eq v0, p1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/16 p1, 0x7d

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ne v0, p1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-direct {p0, v1}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-object v3

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v2, "o nekeUpt pednxc:t"

    const-string v2, "Unexpected token: "

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    throw p1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {p0, v1}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 p1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 p1, 0x5

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-object v3

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v1, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->b:[C

    const/4 v5, 0x5

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/server/response/a;->d:Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p1, v0, v2, v3}, Lcom/google/android/gms/common/server/response/a;->b(Ljava/io/BufferedReader;[CLjava/lang/StringBuilder;[C)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p0, v1}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/16 v1, 0x3a

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-ne p1, v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-object v0

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v0, "pev /oaeqrltEkarpystoaexuede"

    const-string/jumbo v0, "yuetosave ae/xErelppaordtekc"

    const/4 v5, 0x3

    const-string/jumbo v0, "pysaEdcluxt oaepkrer aeteves"

    const-string v0, "Expected key/value separator"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    throw p1
.end method

.method private final t(Ljava/io/BufferedReader;)Ljava/lang/String;
    .locals 14
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/16 v0, 0x400

    invoke-virtual {p1, v0}, Ljava/io/BufferedReader;->mark(I)V

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v0

    const/16 v1, 0x5c

    const-string v2, "entmdpbUee ceo xn"

    const-string v2, " ece bxneopdtUetn"

    const-string/jumbo v2, "kpetoxoeUtc nnede"

    const-string v2, "Unexpected token "

    const/16 v3, 0x7d

    const/16 v4, 0x2c

    const/16 v5, 0x22

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eq v0, v5, :cond_10

    if-eq v0, v4, :cond_f

    const/16 v8, 0x20

    const/16 v9, 0x5b

    if-eq v0, v9, :cond_4

    const/16 v1, 0x7b

    if-eq v0, v1, :cond_0

    invoke-virtual {p1}, Ljava/io/BufferedReader;->reset()V

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/server/response/a;->o(Ljava/io/BufferedReader;[C)I

    goto/16 :goto_2

    :cond_0
    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p1, v8}, Ljava/io/BufferedReader;->mark(I)V

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v0

    if-ne v0, v3, :cond_1

    invoke-direct {p0, v7}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    goto/16 :goto_2

    :cond_1
    if-ne v0, v5, :cond_3

    invoke-virtual {p1}, Ljava/io/BufferedReader;->reset()V

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->s(Ljava/io/BufferedReader;)Ljava/lang/String;

    :cond_2
    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->t(Ljava/io/BufferedReader;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_2

    invoke-direct {p0, v7}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    goto/16 :goto_2

    :cond_3
    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_4
    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v10, 0x5

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p1, v8}, Ljava/io/BufferedReader;->mark(I)V

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v0

    const/16 v8, 0x5d

    if-ne v0, v8, :cond_5

    invoke-direct {p0, v10}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    goto/16 :goto_2

    :cond_5
    invoke-virtual {p1}, Ljava/io/BufferedReader;->reset()V

    move v0, v6

    move v0, v6

    move v0, v6

    move v11, v0

    move v11, v0

    move v11, v0

    move v11, v0

    :goto_0
    if-lez v7, :cond_e

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v12

    if-eqz v12, :cond_d

    invoke-static {v12}, Ljava/lang/Character;->isISOControl(C)Z

    move-result v13

    if-nez v13, :cond_c

    if-ne v12, v5, :cond_7

    if-nez v11, :cond_6

    xor-int/lit8 v0, v0, 0x1

    :cond_6
    move v12, v5

    move v12, v5

    move v12, v5

    move v12, v5

    :cond_7
    if-ne v12, v9, :cond_9

    if-nez v0, :cond_8

    add-int/lit8 v7, v7, 0x1

    :cond_8
    move v12, v9

    move v12, v9

    :cond_9
    if-ne v12, v8, :cond_a

    if-nez v0, :cond_a

    add-int/lit8 v7, v7, -0x1

    :cond_a
    if-ne v12, v1, :cond_b

    if-eqz v0, :cond_b

    xor-int/lit8 v11, v11, 0x1

    goto :goto_0

    :cond_b
    move v11, v6

    move v11, v6

    move v11, v6

    goto :goto_0

    :cond_c
    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const-string v0, "anerebouartoaigltilctay eee Ucr pwre drrnx cdhnh"

    const-string v0, " nr truegtr piiacedr hdUnyot calxhnarleeearcaweo"

    const-string/jumbo v0, "neccclu xU drtgaotar  erdhylro reeaiawnpenhritec"

    const-string v0, "Unexpected control character while reading array"

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_d
    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const-string v0, "arErOeFp gahrnwpiypale en spidte x"

    const-string v0, " xptr UpFpd iEeiahylraOeg nnewrsea"

    const-string v0, "eaFr ra qxUahlgpnnEOewptysicre ide"

    const-string v0, "Unexpected EOF while parsing array"

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_e
    invoke-direct {p0, v10}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    goto :goto_2

    :cond_f
    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const-string/jumbo v0, "gssiMuelna iq"

    const-string v0, "Mnusegslq aii"

    const-string v0, " inmeigsvausl"

    const-string v0, "Missing value"

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_10
    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->a:[C

    invoke-virtual {p1, v0}, Ljava/io/Reader;->read([C)I

    move-result v0

    const-string v8, " EnioglUhitssnga ietcdpenOerrxFws p"

    const-string/jumbo v8, "tnsiFcs seegediiExOthpgwlU  nrernap"

    const-string v8, "e  Ftbip shpadnenOiUrsetwx gEgelcir"

    const-string v8, "Unexpected EOF while parsing string"

    const/4 v9, -0x1

    if-eq v0, v9, :cond_18

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->a:[C

    aget-char v0, v0, v6

    move v10, v6

    move v10, v6

    move v10, v6

    move v10, v6

    :goto_1
    if-ne v0, v5, :cond_14

    if-eqz v10, :cond_11

    move v0, v5

    move v0, v5

    move v0, v5

    move v0, v5

    move v10, v7

    move v10, v7

    move v10, v7

    move v10, v7

    goto :goto_3

    :cond_11
    :goto_2
    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v0

    const/4 v1, 0x2

    if-eq v0, v4, :cond_13

    if-ne v0, v3, :cond_12

    invoke-direct {p0, v1}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 p1, 0x0

    return-object p1

    :cond_12
    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_13
    invoke-direct {p0, v1}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->s(Ljava/io/BufferedReader;)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_14
    :goto_3
    if-ne v0, v1, :cond_15

    xor-int/lit8 v0, v10, 0x1

    move v10, v0

    move v10, v0

    move v10, v0

    move v10, v0

    goto :goto_4

    :cond_15
    move v10, v6

    move v10, v6

    move v10, v6

    :goto_4
    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->a:[C

    invoke-virtual {p1, v0}, Ljava/io/Reader;->read([C)I

    move-result v0

    if-eq v0, v9, :cond_17

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->a:[C

    aget-char v0, v0, v6

    invoke-static {v0}, Ljava/lang/Character;->isISOControl(C)Z

    move-result v11

    if-nez v11, :cond_16

    goto :goto_1

    :cond_16
    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const-string/jumbo v0, "lerrctuaaleinni tcc heonUopiw  dxnghdeer rmsagtce"

    const-string/jumbo v0, "tnnmsiahtpetcodenrgwecUhi  rree nacrdlxcorage i l"

    const-string v0, "Unexpected control character while reading string"

    invoke-direct {p1, v0}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_17
    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    invoke-direct {p1, v8}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_18
    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    invoke-direct {p1, v8}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private final u(Ljava/io/BufferedReader;)Ljava/math/BigDecimal;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    const/4 v4, 0x3

    shl-int/2addr v5, v4

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/server/response/a;->o(Ljava/io/BufferedReader;[C)I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    if-nez p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 p1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object p1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v1, Ljava/math/BigDecimal;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {v2, v0, v3, p1}, Ljava/lang/String;-><init>([CII)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {v1, v2}, Ljava/math/BigDecimal;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object v1
.end method

.method private final v(Ljava/io/BufferedReader;)Ljava/math/BigInteger;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/server/response/a;->o(Ljava/io/BufferedReader;[C)I

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez p1, :cond_0

    const/4 v5, 0x2

    const/4 p1, 0x5

    const/4 v5, 0x2

    const/4 p1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-object p1

    :cond_0
    const/4 v4, 0x5

    move v5, v4

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->c:[C

    const/4 v5, 0x7

    new-instance v1, Ljava/math/BigInteger;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v2, Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v2, v0, v3, p1}, Ljava/lang/String;-><init>([CII)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v1, v2}, Ljava/math/BigInteger;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-object v1
.end method

.method private final w(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/j;)Ljava/util/ArrayList;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/16 v1, 0x6e

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-ne v0, v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    sget-object p2, Lcom/google/android/gms/common/server/response/a;->g:[C

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/server/response/a;->z(Ljava/io/BufferedReader;[C)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x6

    const/4 v4, 0x1

    return-object p1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/16 v1, 0x5b

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-ne v0, v1, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v1, 0x5

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :cond_1
    :goto_0
    const/4 v4, 0x7

    move v5, v4

    const/16 v2, 0x400

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1, v2}, Ljava/io/BufferedReader;->mark(I)V

    const/4 v4, 0x5

    shr-int/2addr v5, v4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v2, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/16 v3, 0x2c

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eq v2, v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/16 v3, 0x5d

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eq v2, v3, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/io/BufferedReader;->reset()V

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-interface {p2, p0, p1}, Lcom/google/android/gms/common/server/response/j;->a(Lcom/google/android/gms/common/server/response/a;Ljava/io/BufferedReader;)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {p0, v1}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 v4, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object v0

    :cond_3
    const/4 v5, 0x2

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const-string/jumbo p2, "pFe ectpdUOEnx"

    const-string p2, "Unexpected EOF"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    throw p1

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string p2, "aterEoypqrea fctors  ad"

    const-string p2, " sy oaftreetdrEprta aco"

    const/4 v5, 0x6

    const-string p2, "caso a etrfd yEtesrtpax"

    const-string p2, "Expected start of array"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    throw p1
.end method

.method private final x(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)Ljava/util/ArrayList;
    .locals 11
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    const-string v0, " namn cg btrEetiirojnitanrrbient"

    const-string/jumbo v0, "itacrbitesginj  notEtinbr neranr"

    const/4 v10, 0x1

    const-string v0, " t torioaininrnEeisrcatbt gnrneo"

    const-string v0, "Error instantiating inner object"

    const/4 v9, 0x1

    const/4 v9, 0x7

    new-instance v1, Ljava/util/ArrayList;

    const/4 v9, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v2

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    const/16 v3, 0x5d

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/4 v4, 0x5

    const/4 v10, 0x1

    const/4 v9, 0x0

    if-eq v2, v3, :cond_6

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/16 v5, 0x6e

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eq v2, v5, :cond_5

    const/4 v10, 0x3

    const/4 v9, 0x3

    const-string v5, " ot:ebencdee tnkpu"

    const-string v5, "eUte eu:pednt knco"

    const/4 v10, 0x3

    const-string v5, "Unexpected token: "

    const/4 v10, 0x5

    const/16 v6, 0x7b

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-ne v2, v6, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    iget-object v2, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/4 v7, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v2, v8}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_0
    :try_start_0
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p2}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->O2()Lcom/google/android/gms/common/server/response/FastJsonResponse;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-direct {p0, p1, v2}, Lcom/google/android/gms/common/server/response/a;->B(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/FastJsonResponse;)Z

    move-result v8

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-eqz v8, :cond_3

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v2

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/16 v8, 0x2c

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-eq v2, v8, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-ne v2, v3, :cond_0

    const/4 v10, 0x4

    invoke-direct {p0, v4}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    return-object v1

    :cond_0
    const/4 v10, 0x0

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    throw p1

    :cond_1
    const/4 v10, 0x5

    const/4 v9, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result v2

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-ne v2, v6, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget-object v2, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v2, v8}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x6

    move v10, v9

    goto :goto_0

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-string/jumbo p2, "taecceuxafy   exsd t roE injnbatetpopr"

    const-string p2, " cjpetnp o sndiarearbetyt xoxreaf c Et"

    const/4 v10, 0x1

    const-string/jumbo p2, "trpEfeapoc einndbyr jtra   oxettetasx "

    const-string p2, "Expected start of next object in array"

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    throw p1

    :cond_3
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    return-object v1

    :catch_0
    move-exception p1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    new-instance p2, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v9, 0x0

    move v10, v9

    invoke-direct {p2, v0, p1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    throw p2

    :catch_1
    move-exception p1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    new-instance p2, Lcom/google/android/gms/common/server/response/a$a;

    invoke-direct {p2, v0, p1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    throw p2

    :cond_4
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v10, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    move v10, v9

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x1

    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    throw p1

    :cond_5
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    sget-object p2, Lcom/google/android/gms/common/server/response/a;->g:[C

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/server/response/a;->z(Ljava/io/BufferedReader;[C)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-direct {p0, v4}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 v10, 0x7

    const/4 p1, 0x0

    const/4 v10, 0x2

    shl-int/2addr v9, p1

    return-object p1

    :cond_6
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-direct {p0, v4}, Lcom/google/android/gms/common/server/response/a;->y(I)V

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    return-object v1
.end method

.method private final y(I)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string v1, "deaxep  qecEtst"

    const-string/jumbo v1, "tcdp e eqEtexsa"

    const/4 v5, 0x3

    const-string v1, "axstep teEte dc"

    const-string v1, "Expected state "

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/util/Stack;->pop()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    check-cast v0, Ljava/lang/Integer;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-ne v0, p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v2, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v5, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string p1, "dbsm  ut "

    const-string p1, " bstd a u"

    const-string/jumbo p1, "u dboht  "

    const-string p1, " but had "

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v2, p1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    throw v2

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance v0, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const-string p1, "edcbabtma shtky   up"

    const-string/jumbo p1, "tmkma  ey utb hsdapc"

    const/4 v5, 0x7

    const-string/jumbo p1, "umh ytuks acd at tbe"

    const-string p1, " but had empty stack"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    throw v0
.end method

.method private final z(Ljava/io/BufferedReader;[C)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v0, 0x0

    const/4 v7, 0x2

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    array-length v2, p2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-ge v1, v2, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v3, p0, Lcom/google/android/gms/common/server/response/a;->b:[C

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    sub-int/2addr v2, v1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p1, v3, v0, v2}, Ljava/io/BufferedReader;->read([CII)I

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v3, -0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eq v2, v3, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    move v3, v0

    const/4 v7, 0x5

    move v3, v0

    move v3, v0

    :goto_1
    const/4 v6, 0x7

    const/4 v6, 0x6

    if-ge v3, v2, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    add-int v4, v3, v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    aget-char v4, p2, v4

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v5, p0, Lcom/google/android/gms/common/server/response/a;->b:[C

    const/4 v7, 0x2

    const/4 v6, 0x1

    aget-char v5, v5, v3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-ne v4, v5, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    goto :goto_1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const-string p2, "enhrcrtpdoU eacptxca"

    const-string/jumbo p2, "thp odntceacrUeeraxc"

    const/4 v7, 0x7

    const-string p2, "caecehntqrexrepcadUt"

    const-string p2, "Unexpected character"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    throw p1

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    add-int/2addr v1, v2

    const/4 v7, 0x6

    goto :goto_0

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-string/jumbo p2, "pesOEebFced xn"

    const-string p2, "FcnxOb edtEeep"

    const/4 v7, 0x3

    const-string p2, "etEmOneeUxpdc "

    const-string p2, "Unexpected EOF"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    throw p1

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    return-void
.end method


# virtual methods
.method public a(Ljava/io/InputStream;Lcom/google/android/gms/common/server/response/FastJsonResponse;)V
    .locals 8
    .param p1    # Ljava/io/InputStream;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/server/response/FastJsonResponse;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/InputStream;",
            "TT;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/common/server/response/a$a;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string/jumbo v0, "oeaioileirsle.Fuwohrdarse nl   adtepc"

    const-string/jumbo v0, "ots o uipa .rd aFwldsenr ialeieerelhc"

    const/4 v7, 0x5

    const-string v0, "de rpb  aFehriartnloow ldagesi sel.ic"

    const-string v0, "Failed to close reader while parsing."

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string/jumbo v1, "pFsPeautrs"

    const-string/jumbo v1, "rrstFespPa"

    const/4 v7, 0x7

    const-string v1, "Prasetspar"

    const-string v1, "FastParser"

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-instance v2, Ljava/io/BufferedReader;

    const/4 v7, 0x2

    const/4 v6, 0x5

    new-instance v3, Ljava/io/InputStreamReader;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct {v3, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/16 p1, 0x400

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v2, v3, p1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;I)V

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v6, 0x4

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p1, v4}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x1

    invoke-direct {p0, v2}, Lcom/google/android/gms/common/server/response/a;->k(Ljava/io/BufferedReader;)C

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz p1, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/16 v4, 0x5b

    const/4 v7, 0x7

    const/4 v5, 0x1

    move v6, v5

    const/4 v7, 0x4

    if-eq p1, v4, :cond_1

    const/4 v7, 0x0

    const/16 v4, 0x7b

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-ne p1, v4, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1, v4}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x0

    shl-int/2addr v7, v6

    invoke-direct {p0, v2, p2}, Lcom/google/android/gms/common/server/response/a;->B(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/FastJsonResponse;)Z

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto/16 :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    new-instance p2, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v4, "p:k nnctq texedeeo"

    const-string v4, "Unexpected token: "

    const/4 v7, 0x0

    const/4 v6, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {p2, p1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    throw p2

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/server/response/a;->f:Ljava/util/Stack;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v4, 0x5

    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p1, v4}, Ljava/util/Stack;->push(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p2}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->getFieldMappings()Ljava/util/Map;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-ne v4, v5, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    check-cast p1, Ljava/util/Map$Entry;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    check-cast p1, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {p0, v2, p1}, Lcom/google/android/gms/common/server/response/a;->x(Ljava/io/BufferedReader;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)Ljava/util/ArrayList;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v5, p1, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->f:Ljava/lang/String;

    const/4 v7, 0x3

    invoke-virtual {p2, p1, v5, v4}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->addConcreteTypeArrayInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V

    :goto_0
    const/4 v7, 0x1

    invoke-direct {p0, v3}, Lcom/google/android/gms/common/server/response/a;->y(I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-void

    :catch_0
    const/4 v7, 0x3

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    return-void

    :cond_2
    :try_start_2
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v7, 0x4

    const-string/jumbo p2, "rys  berita lesgdrh maesoej steOsFe  scslnnulaaa ivc"

    const-string p2, "absmr a qtae  njsyldgs seOcectahuleeviioln s sF arre"

    const/4 v7, 0x2

    const-string/jumbo p2, "tssmu aoOFsnjsdalecn cs ahrrem  e isapgeyilevealbrt "

    const-string p2, "Object array response class must have a single Field"

    const/4 v7, 0x4

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    throw p1

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x6

    new-instance p1, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string/jumbo p2, "st Noep oodtra a"

    const-string p2, " ossptNetaa  dor"

    const/4 v7, 0x3

    const-string p2, "Ne o badott psaa"

    const-string p2, "No data to parse"

    const/4 v7, 0x1

    const/4 v6, 0x6

    invoke-direct {p1, p2}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    throw p1
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_1

    :catch_1
    move-exception p1

    :try_start_3
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    new-instance p2, Lcom/google/android/gms/common/server/response/a$a;

    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-direct {p2, p1}, Lcom/google/android/gms/common/server/response/a$a;-><init>(Ljava/lang/Throwable;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    throw p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :goto_1
    :try_start_4
    const/4 v7, 0x7

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto :goto_2

    :catch_2
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :goto_2
    const/4 v7, 0x6

    throw p1
.end method
