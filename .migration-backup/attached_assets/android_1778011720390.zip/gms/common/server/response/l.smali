.class public final Lcom/google/android/gms/common/server/response/l;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@fs@ io1i~ ~@aun S o- @KlM@@l~~~   ~~.t d@~i/r~b~o~@~~@b@~@t@ f@~v  ~b@ ~~~@y  mc/~@@o@s@@~~o 4o"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x5

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v2, 0x0

    const/4 v7, 0x7

    const/4 v7, 0x3

    move v3, v2

    move v3, v2

    const/4 v8, 0x2

    move v3, v2

    move v3, v2

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v4

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-ge v4, v0, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v4

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {v4}, Lh4/a;->O(I)I

    move-result v5

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-eq v5, v6, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/4 v6, 0x2

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eq v5, v6, :cond_1

    const/4 v8, 0x7

    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v6, 0x3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-eq v5, v6, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {p1, v4}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x6

    sget-object v2, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->CREATOR:Lcom/google/android/gms/common/server/response/k;

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {p1, v4, v2}, Lh4/a;->C(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    check-cast v2, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    goto :goto_0

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {p1, v4}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    goto :goto_0

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-static {p1, v4}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v3

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    goto :goto_0

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    new-instance p1, Lcom/google/android/gms/common/server/response/zam;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-direct {p1, v3, v1, v2}, Lcom/google/android/gms/common/server/response/zam;-><init>(ILjava/lang/String;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    return-object p1
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    new-array p1, p1, [Lcom/google/android/gms/common/server/response/zam;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p1
.end method
