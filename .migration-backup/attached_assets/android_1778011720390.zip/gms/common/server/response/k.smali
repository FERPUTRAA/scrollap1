.class public final Lcom/google/android/gms/common/server/response/k;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 14

    const-string/jumbo v13, "i@smb@~o@ b@@~~v1fo~@@o~ / @@~@~lof @~ @.@yc~i nr/~d-~~~@~s~KM  i @~b@@o S~l~  @~~ ~ @t4~t@oua  "

    const-string v13, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v13, 0x4

    const/4 v1, 0x0

    const/4 v13, 0x1

    const/4 v2, 0x0

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v11, v9

    move-object v11, v9

    move-object v11, v9

    move-object v11, v9

    move-object v12, v11

    move-object v12, v11

    move-object v12, v11

    move-object v12, v11

    const/4 v13, 0x0

    move v4, v2

    move v4, v2

    move v4, v2

    move v4, v2

    move v5, v4

    const/4 v13, 0x7

    move v6, v5

    move v6, v5

    move v6, v5

    move v6, v5

    const/4 v13, 0x2

    move v7, v6

    move v7, v6

    move v7, v6

    move v7, v6

    const/4 v13, 0x1

    move v8, v7

    move v8, v7

    move v8, v7

    move v8, v7

    move v10, v8

    move v10, v8

    move v10, v8

    move v10, v8

    :goto_0
    const/4 v13, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    const/4 v13, 0x1

    if-ge v1, v0, :cond_0

    const/4 v13, 0x7

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v1

    const/4 v13, 0x1

    invoke-static {v1}, Lh4/a;->O(I)I

    move-result v2

    const/4 v13, 0x3

    packed-switch v2, :pswitch_data_0

    const/4 v13, 0x6

    invoke-static {p1, v1}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v13, 0x0

    goto :goto_0

    :pswitch_0
    sget-object v2, Lcom/google/android/gms/common/server/converter/zaa;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v13, 0x0

    invoke-static {p1, v1, v2}, Lh4/a;->C(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v1

    move-object v12, v1

    move-object v12, v1

    const/4 v13, 0x0

    check-cast v12, Lcom/google/android/gms/common/server/converter/zaa;

    const/4 v13, 0x1

    goto :goto_0

    :pswitch_1
    const/4 v13, 0x3

    invoke-static {p1, v1}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v11

    const/4 v13, 0x5

    goto :goto_0

    :pswitch_2
    const/4 v13, 0x2

    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v10

    const/4 v13, 0x5

    goto :goto_0

    :pswitch_3
    const/4 v13, 0x2

    invoke-static {p1, v1}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x5

    goto :goto_0

    :pswitch_4
    const/4 v13, 0x7

    invoke-static {p1, v1}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v8

    const/4 v13, 0x2

    goto :goto_0

    :pswitch_5
    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v7

    const/4 v13, 0x4

    goto :goto_0

    :pswitch_6
    const/4 v13, 0x6

    invoke-static {p1, v1}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v6

    const/4 v13, 0x4

    goto :goto_0

    :pswitch_7
    const/4 v13, 0x2

    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v5

    const/4 v13, 0x4

    goto :goto_0

    :pswitch_8
    const/4 v13, 0x0

    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v4

    const/4 v13, 0x5

    goto :goto_0

    :cond_0
    const/4 v13, 0x2

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    const/4 v13, 0x5

    new-instance p1, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v13, 0x3

    invoke-direct/range {v3 .. v12}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IIZIZLjava/lang/String;ILjava/lang/String;Lcom/google/android/gms/common/server/converter/zaa;)V

    const/4 v13, 0x2

    return-object p1

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x4

    const/4 v1, 0x2

    new-array p1, p1, [Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1
.end method
