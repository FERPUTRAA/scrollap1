.class public final Lcom/google/android/gms/common/server/response/zan;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "FieldMappingDictionaryCreator"
.end annotation

.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/server/response/zan;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field final a:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$h;
        id = 0x1
    .end annotation
.end field

.field private final b:Ljava/util/HashMap;

.field private final c:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getRootClassName"
        id = 0x3
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/gms/common/server/response/m;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/common/server/response/m;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/gms/common/server/response/zan;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x4

    return-void
.end method

.method constructor <init>(ILjava/util/ArrayList;Ljava/lang/String;)V
    .locals 12
    .param p1    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # Ljava/util/ArrayList;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    iput p1, p0, Lcom/google/android/gms/common/server/response/zan;->a:I

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x4

    new-instance p1, Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    const/4 v1, 0x0

    const/4 v10, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    move v2, v1

    move v2, v1

    const/4 v11, 0x3

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    if-ge v2, v0, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x5

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    check-cast v3, Lcom/google/android/gms/common/server/response/zal;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    iget-object v4, v3, Lcom/google/android/gms/common/server/response/zal;->b:Ljava/lang/String;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    new-instance v5, Ljava/util/HashMap;

    const/4 v11, 0x1

    const/4 v10, 0x7

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x1

    iget-object v6, v3, Lcom/google/android/gms/common/server/response/zal;->c:Ljava/util/ArrayList;

    const/4 v11, 0x2

    const/4 v10, 0x3

    invoke-static {v6}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    check-cast v6, Ljava/util/ArrayList;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    move-result v6

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    move v7, v1

    move v7, v1

    const/4 v11, 0x0

    move v7, v1

    move v7, v1

    :goto_1
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-ge v7, v6, :cond_0

    const/4 v11, 0x5

    iget-object v8, v3, Lcom/google/android/gms/common/server/response/zal;->c:Ljava/util/ArrayList;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    check-cast v8, Lcom/google/android/gms/common/server/response/zam;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    iget-object v9, v8, Lcom/google/android/gms/common/server/response/zam;->b:Ljava/lang/String;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    iget-object v8, v8, Lcom/google/android/gms/common/server/response/zam;->c:Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x7

    const/4 v10, 0x0

    invoke-virtual {v5, v9, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x7

    add-int/lit8 v7, v7, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    goto :goto_1

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {p1, v4, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    goto :goto_0

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v11, 0x4

    const/4 v10, 0x2

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    check-cast p1, Ljava/lang/String;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/zan;->c:Ljava/lang/String;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/common/server/response/zan;->B2()V

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    return-void
.end method

.method public constructor <init>(Ljava/lang/Class;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v0, 0x1

    or-int/2addr v2, v0

    const/4 v1, 0x0

    or-int/2addr v2, v1

    iput v0, p0, Lcom/google/android/gms/common/server/response/zan;->a:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    check-cast p1, Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/zan;->c:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public final A2()V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~@s~ il@~ ~ r~o~~d@oiv@@f~@u4t~m a~ ~   b ~@ oi~~ft @~@o~o @b@@yK@-l@@ c@~ 1/.@n@ ~ob~S/s@ M~ ~@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-eqz v1, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v2, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    check-cast v2, Ljava/util/Map;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-instance v3, Ljava/util/HashMap;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-interface {v2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v8, 0x4

    if-eqz v5, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    check-cast v5, Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-interface {v2, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    check-cast v6, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v7, 0x3

    move v8, v7

    invoke-virtual {v6}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->M2()Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    move-result-object v6

    const/4 v8, 0x2

    const/4 v7, 0x5

    invoke-virtual {v3, v5, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    goto :goto_1

    :cond_0
    const/4 v8, 0x0

    iget-object v2, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v7, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v2, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto :goto_0

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    return-void
.end method

.method public final B2()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    check-cast v1, Ljava/util/Map;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    check-cast v3, Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    check-cast v3, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v3, p0}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->T2(Lcom/google/android/gms/common/server/response/zan;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    move v5, v4

    return-void
.end method

.method public final C2(Ljava/lang/Class;Ljava/util/Map;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast p1, Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public final D2(Ljava/lang/Class;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p1
.end method

.method public final toString()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v1}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v2, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    check-cast v2, Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v3, ":/n"

    const-string v3, "/:n"

    const-string v3, "/n:"

    const-string v3, ":\n"

    const/4 v6, 0x6

    or-int/2addr v7, v6

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    invoke-virtual {v3, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x5

    check-cast v2, Ljava/util/Map;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {v2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v4, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    check-cast v4, Ljava/lang/String;

    const/4 v7, 0x0

    const-string v5, "  "

    const/4 v7, 0x1

    const-string v5, "  "

    const-string v5, "  "

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const-string v5, " :"

    const-string v5, " :"

    const/4 v7, 0x1

    const-string v5, " :"

    const-string v5, ": "

    const/4 v6, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 7

    const/4 v6, 0x5

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result p2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v0, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    iget v1, p0, Lcom/google/android/gms/common/server/response/zan;->a:I

    const/4 v5, 0x3

    move v6, v5

    invoke-static {p1, v0, v1}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x2

    or-int/2addr v6, v5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v2, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    check-cast v2, Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    new-instance v4, Lcom/google/android/gms/common/server/response/zal;

    invoke-virtual {v3, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    check-cast v3, Ljava/util/Map;

    const/4 v6, 0x7

    invoke-direct {v4, v2, v3}, Lcom/google/android/gms/common/server/response/zal;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v1, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {p1, v1, v0, v2}, Lh4/b;->d0(Landroid/os/Parcel;ILjava/util/List;Z)V

    const/4 v6, 0x0

    const/4 v0, 0x3

    const/4 v6, 0x7

    move v5, v0

    move v5, v0

    iget-object v1, p0, Lcom/google/android/gms/common/server/response/zan;->c:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {p1, v0, v1, v2}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {p1, p2}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-void
.end method

.method public final y2()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/zan;->c:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public final z2(Ljava/lang/String;)Ljava/util/Map;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/zan;->b:Ljava/util/HashMap;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast p1, Ljava/util/Map;

    const/4 v2, 0x2

    return-object p1
.end method
