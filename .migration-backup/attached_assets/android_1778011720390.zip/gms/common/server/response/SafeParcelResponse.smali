.class public Lcom/google/android/gms/common/server/response/SafeParcelResponse;
.super Lcom/google/android/gms/common/server/response/FastSafeParcelableJsonResponse;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "SafeParcelResponseCreator"
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/server/response/SafeParcelResponse;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field


# instance fields
.field private final a:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$h;
        getter = "getVersionCode"
        id = 0x1
    .end annotation
.end field

.field private final b:Landroid/os/Parcel;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getParcel"
        id = 0x2
    .end annotation
.end field

.field private final c:I

.field private final d:Lcom/google/android/gms/common/server/response/zan;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getFieldMappingDictionary"
        id = 0x3
    .end annotation
.end field

.field private final e:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private f:I

.field private g:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/gms/common/server/response/o;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/common/server/response/o;-><init>()V

    const/4 v2, 0x6

    sput-object v0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method constructor <init>(ILandroid/os/Parcel;Lcom/google/android/gms/common/server/response/zan;)V
    .locals 2
    .param p1    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # Landroid/os/Parcel;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .param p3    # Lcom/google/android/gms/common/server/response/zan;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/common/server/response/FastSafeParcelableJsonResponse;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->a:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    check-cast p1, Landroid/os/Parcel;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->c:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->d:Lcom/google/android/gms/common/server/response/zan;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    if-nez p3, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    const/4 p2, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p3}, Lcom/google/android/gms/common/server/response/zan;->y2()Ljava/lang/String;

    move-result-object p2

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->e:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->f:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method private constructor <init>(Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;Lcom/google/android/gms/common/server/response/zan;Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/common/server/response/FastSafeParcelableJsonResponse;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v0, 0x1

    iput v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->a:I

    const/4 v4, 0x7

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {p1, v1, v2}, Landroid/os/Parcelable;->writeToParcel(Landroid/os/Parcel;I)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->c:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    check-cast p1, Lcom/google/android/gms/common/server/response/zan;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->d:Lcom/google/android/gms/common/server/response/zan;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    check-cast p1, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->e:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 p1, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput p1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->f:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>(Lcom/google/android/gms/common/server/response/zan;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/common/server/response/FastSafeParcelableJsonResponse;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->a:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast p1, Lcom/google/android/gms/common/server/response/zan;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->d:Lcom/google/android/gms/common/server/response/zan;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast p1, Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->e:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->f:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public static e(Lcom/google/android/gms/common/server/response/FastJsonResponse;)Lcom/google/android/gms/common/server/response/SafeParcelResponse;
    .locals 5
    .param p0    # Lcom/google/android/gms/common/server/response/FastJsonResponse;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse;",
            ":",
            "Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;",
            ">(TT;)",
            "Lcom/google/android/gms/common/server/response/SafeParcelResponse;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x5

    new-instance v1, Lcom/google/android/gms/common/server/response/zan;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Lcom/google/android/gms/common/server/response/zan;-><init>(Ljava/lang/Class;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-static {v1, p0}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->h(Lcom/google/android/gms/common/server/response/zan;Lcom/google/android/gms/common/server/response/FastJsonResponse;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Lcom/google/android/gms/common/server/response/zan;->A2()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1}, Lcom/google/android/gms/common/server/response/zan;->B2()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    new-instance v2, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    check-cast p0, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v2, p0, v1, v0}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;-><init>(Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;Lcom/google/android/gms/common/server/response/zan;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object v2
.end method

.method private static h(Lcom/google/android/gms/common/server/response/zan;Lcom/google/android/gms/common/server/response/FastJsonResponse;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/server/response/zan;->D2(Ljava/lang/Class;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->getFieldMappings()Ljava/util/Map;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0, v0, p1}, Lcom/google/android/gms/common/server/response/zan;->C2(Ljava/lang/Class;Ljava/util/Map;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast v1, Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p1, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    check-cast v1, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v2, v1, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->h:Ljava/lang/Class;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    check-cast v2, Lcom/google/android/gms/common/server/response/FastJsonResponse;

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-static {p0, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->h(Lcom/google/android/gms/common/server/response/zan;Lcom/google/android/gms/common/server/response/FastJsonResponse;)V
    :try_end_0
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object p1, v1, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->h:Ljava/lang/Class;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    check-cast p1, Ljava/lang/Class;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string v1, "  seotelbCt stoafyec cpc sdnojo "

    const/4 v4, 0x3

    const-string/jumbo v1, "t syuoodbfnoes tcsoec pt lcea  j"

    const-string v1, "Could not access object of type "

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v0, p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    throw v0

    :catch_1
    move-exception p0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object p1, v1, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->h:Ljava/lang/Class;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    check-cast p1, Ljava/lang/Class;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string/jumbo v1, "stemp oun i ednyfjtneataontoi t Combtac "

    const-string/jumbo v1, "fiymnoeojctCend stn attoa ua b   tinotep"

    const/4 v4, 0x4

    const-string/jumbo v1, "tbC oijstafonnettl y p dt enon ioc oaeut"

    const-string v1, "Could not instantiate an object of type "

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0, p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x6

    throw v0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method private final i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V
    .locals 4

    const/4 v3, 0x5

    iget p1, p1, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->g:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eq p1, v0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v2, 0x2

    or-int/2addr v3, v2

    if-eqz p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->f:I

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string v0, "ce r bwa ofo.NoahssJeet raya ots itettdeef lA aatPSieewdiptj ehelOilmtRt handalt asdbSprc "

    const-string v0, "dpsdoadjht ctetinyoPfrieb rS  lll hoS eOweaiia aattehcseaes atp RepAt  f.sdatJoewrtNmtle a"

    const/4 v3, 0x5

    const-string v0, "Attempted to parse JSON with a SafeParcelResponse object that is already filled with data."

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    throw p1

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput p1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->g:I

    const/4 v2, 0x0

    move v3, v2

    iput v1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->f:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v0, "s ecr ul.anoeacjltnbie  luIPtlr"

    const-string v0, "Internal Parcel object is null."

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    throw p1

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "saipef pfli sl. edtaile aelovaheoerai vddd Fd b l nec"

    const-string v0, "dide b aeadleahviitaseFde slr opilde l.fveobfac  nl  "

    const/4 v3, 0x2

    const-string/jumbo v0, "le sh feqFalce vbvnodp  ddelf aalai.ad  e rlsoidaiite"

    const-string v0, "Field does not have a valid safe parcelable field id."

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    throw p1
.end method

.method private final k(Ljava/lang/StringBuilder;Ljava/util/Map;Landroid/os/Parcel;)V
    .locals 12

    const/4 v11, 0x0

    const/4 v10, 0x3

    new-instance v0, Landroid/util/SparseArray;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-interface {p2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p2

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eqz v1, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    check-cast v2, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {v2}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result v2

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v0, v2, v1}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    goto :goto_0

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    const/16 p2, 0x7b

    const/4 v11, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-static {p3}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result p2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    const/4 v1, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    move v2, v1

    move v2, v1

    const/4 v11, 0x0

    move v2, v1

    move v2, v1

    :cond_1
    :goto_1
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {p3}, Landroid/os/Parcel;->dataPosition()I

    move-result v3

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x4

    if-ge v3, p2, :cond_a

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {p3}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v3

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static {v3}, Lh4/a;->O(I)I

    move-result v4

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v0, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    check-cast v4, Ljava/util/Map$Entry;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-eqz v4, :cond_1

    const/4 v11, 0x3

    const/4 v10, 0x4

    const-string v5, ","

    const-string v5, ","

    const/4 v11, 0x2

    const-string v5, ","

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-eqz v2, :cond_2

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v10, 0x1

    or-int/2addr v11, v10

    check-cast v2, Ljava/lang/String;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x3

    check-cast v4, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    const-string v6, "//"

    const-string v6, "//"

    const/4 v11, 0x2

    const-string v6, "//"

    const-string v6, "\""

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x2

    const-string v2, "//:"

    const-string v2, "://"

    const-string v2, "\":"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {v4}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->U2()Z

    move-result v2

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    const/4 v7, 0x1

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x3

    if-eqz v2, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget v2, v4, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->d:I

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    packed-switch v2, :pswitch_data_0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    xor-int/2addr v11, v10

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    const-string p3, "Uus wy=n  in fet dltkoonp"

    const-string p3, "Unknown field out type = "

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    xor-int/2addr v11, v10

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x2

    const/4 v10, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x3

    throw p1

    :pswitch_0
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    const-string/jumbo p2, "h.umttpededc ten Moaceto poo crese yc"

    const-string/jumbo p2, "tecsopudtoea eMhteccreeo  pntyot .d c"

    const/4 v11, 0x6

    const-string/jumbo p2, "n.o opdttccn etctepMoer y cesoeeda to"

    const-string p2, "Method does not accept concrete type."

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x4

    throw p1

    :pswitch_1
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-static {p3, v3}, Lh4/a;->g(Landroid/os/Parcel;I)Landroid/os/Bundle;

    move-result-object v2

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    new-instance v3, Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x2

    invoke-direct {v3}, Ljava/util/HashMap;-><init>()V

    const/4 v10, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v2}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v5

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_2
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v11, 0x1

    const/4 v10, 0x3

    if-eqz v6, :cond_3

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x0

    const/4 v10, 0x2

    check-cast v6, Ljava/lang/String;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {v2, v6}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x1

    move v11, v10

    invoke-static {v8}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    check-cast v8, Ljava/lang/String;

    const/4 v11, 0x4

    invoke-virtual {v3, v6, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x3

    move v11, v10

    goto :goto_2

    :cond_3
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-static {v4, v3}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaD(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {p1, v4, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->o(Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V

    goto/16 :goto_3

    :pswitch_2
    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-static {p3, v3}, Lh4/a;->h(Landroid/os/Parcel;I)[B

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {v4, v2}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaD(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-static {p1, v4, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->o(Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V

    const/4 v11, 0x5

    const/4 v10, 0x5

    goto/16 :goto_3

    :pswitch_3
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {p3, v3}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-static {v4, v2}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaD(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-static {p1, v4, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->o(Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    goto/16 :goto_3

    :pswitch_4
    const/4 v11, 0x1

    invoke-static {p3, v3}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v2

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-static {v4, v2}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaD(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static {p1, v4, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->o(Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    goto/16 :goto_3

    :pswitch_5
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-static {p3, v3}, Lh4/a;->a(Landroid/os/Parcel;I)Ljava/math/BigDecimal;

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-static {v4, v2}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaD(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-static {p1, v4, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->o(Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    goto/16 :goto_3

    :pswitch_6
    const/4 v11, 0x5

    invoke-static {p3, v3}, Lh4/a;->T(Landroid/os/Parcel;I)D

    move-result-wide v2

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-static {v4, v2}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaD(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-static {p1, v4, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->o(Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    goto :goto_3

    :pswitch_7
    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {p3, v3}, Lh4/a;->V(Landroid/os/Parcel;I)F

    move-result v2

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {v4, v2}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaD(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-static {p1, v4, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->o(Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x6

    goto :goto_3

    :pswitch_8
    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-static {p3, v3}, Lh4/a;->c0(Landroid/os/Parcel;I)J

    move-result-wide v2

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-static {v4, v2}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaD(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {p1, v4, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->o(Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V

    const/4 v11, 0x3

    goto :goto_3

    :pswitch_9
    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-static {p3, v3}, Lh4/a;->c(Landroid/os/Parcel;I)Ljava/math/BigInteger;

    move-result-object v2

    const/4 v11, 0x6

    const/4 v10, 0x4

    invoke-static {v4, v2}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaD(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x1

    invoke-static {p1, v4, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->o(Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V

    const/4 v11, 0x2

    const/4 v10, 0x2

    goto :goto_3

    :pswitch_a
    const/4 v10, 0x7

    move v11, v10

    invoke-static {p3, v3}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-static {v4, v2}, Lcom/google/android/gms/common/server/response/FastJsonResponse;->zaD(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static {p1, v4, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->o(Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V

    :goto_3
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    move v2, v7

    move v2, v7

    const/4 v11, 0x7

    move v2, v7

    move v2, v7

    const/4 v10, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    goto/16 :goto_1

    :cond_4
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    iget-boolean v2, v4, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->e:Z

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-eqz v2, :cond_7

    const/4 v11, 0x3

    const/4 v10, 0x0

    const-string v2, "["

    const-string v2, "["

    const/4 v11, 0x0

    const-string v2, "["

    const-string v2, "["

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    iget v2, v4, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->d:I

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    packed-switch v2, :pswitch_data_1

    const/4 v11, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    const-string/jumbo p2, "t lyob Untdeiowep punnf"

    const-string p2, ".ed tuwpio nfontUep ynl"

    const/4 v11, 0x0

    const-string/jumbo p2, "od wf.unelptUteiynn u o"

    const-string p2, "Unknown field type out."

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    throw p1

    :pswitch_b
    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-static {p3, v3}, Lh4/a;->z(Landroid/os/Parcel;I)[Landroid/os/Parcel;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x2

    array-length v3, v2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    move v6, v1

    move v6, v1

    const/4 v11, 0x0

    move v6, v1

    move v6, v1

    :goto_4
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    if-ge v6, v3, :cond_6

    const/4 v11, 0x2

    if-lez v6, :cond_5

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_5
    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    aget-object v8, v2, v6

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v8, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v4}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->S2()Ljava/util/Map;

    move-result-object v8

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x4

    aget-object v9, v2, v6

    const/4 v11, 0x4

    const/4 v10, 0x4

    invoke-direct {p0, p1, v8, v9}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->k(Ljava/lang/StringBuilder;Ljava/util/Map;Landroid/os/Parcel;)V

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    add-int/lit8 v6, v6, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    goto :goto_4

    :pswitch_c
    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    const-string/jumbo p2, "siPSpI,ptMR pEBoL 6osf6yAr _ES_At NSSE44eUtporstF  GL_, TnRquBAAiedo"

    const-string p2, "6fptyt Sqr4A_sSe SFE URAEMpIrGtpBio _ontsBsedT 4 L,SNo_i6uRPLAEA  ,o"

    const/4 v11, 0x5

    const-string p2, "R Str i qeLiIotEBso_ERUpL6sSpPyAo4u 6 s pSA , F oB4_S_trEdGTtfNeMn,A"

    const-string p2, "List of type BASE64, BASE64_URL_SAFE, or STRING_MAP is not supported"

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    throw p1

    :pswitch_d
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {p3, v3}, Lh4/a;->H(Landroid/os/Parcel;I)[Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {p1, v2}, Lcom/google/android/gms/common/util/b;->p(Ljava/lang/StringBuilder;[Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    goto :goto_5

    :pswitch_e
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {p3, v3}, Lh4/a;->e(Landroid/os/Parcel;I)[Z

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-static {p1, v2}, Lcom/google/android/gms/common/util/b;->o(Ljava/lang/StringBuilder;[Z)V

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    goto :goto_5

    :pswitch_f
    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {p3, v3}, Lh4/a;->b(Landroid/os/Parcel;I)[Ljava/math/BigDecimal;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {p1, v2}, Lcom/google/android/gms/common/util/b;->n(Ljava/lang/StringBuilder;[Ljava/lang/Object;)V

    const/4 v11, 0x0

    goto :goto_5

    :pswitch_10
    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {p3, v3}, Lh4/a;->l(Landroid/os/Parcel;I)[D

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-static {p1, v2}, Lcom/google/android/gms/common/util/b;->j(Ljava/lang/StringBuilder;[D)V

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    goto :goto_5

    :pswitch_11
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {p3, v3}, Lh4/a;->o(Landroid/os/Parcel;I)[F

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x1

    invoke-static {p1, v2}, Lcom/google/android/gms/common/util/b;->k(Ljava/lang/StringBuilder;[F)V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x1

    goto :goto_5

    :pswitch_12
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {p3, v3}, Lh4/a;->w(Landroid/os/Parcel;I)[J

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-static {p1, v2}, Lcom/google/android/gms/common/util/b;->m(Ljava/lang/StringBuilder;[J)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    goto :goto_5

    :pswitch_13
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-static {p3, v3}, Lh4/a;->d(Landroid/os/Parcel;I)[Ljava/math/BigInteger;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {p1, v2}, Lcom/google/android/gms/common/util/b;->n(Ljava/lang/StringBuilder;[Ljava/lang/Object;)V

    const/4 v11, 0x5

    goto :goto_5

    :pswitch_14
    const/4 v11, 0x6

    const/4 v10, 0x5

    invoke-static {p3, v3}, Lh4/a;->u(Landroid/os/Parcel;I)[I

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-static {p1, v2}, Lcom/google/android/gms/common/util/b;->l(Ljava/lang/StringBuilder;[I)V

    :cond_6
    :goto_5
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    const-string v2, "]"

    const-string v2, "]"

    const-string v2, "]"

    const-string v2, "]"

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    goto/16 :goto_3

    :cond_7
    const/4 v10, 0x2

    move v11, v10

    iget v2, v4, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->d:I

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    packed-switch v2, :pswitch_data_2

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v11, 0x6

    const-string/jumbo p2, "n stye leoUnnftsidpwu "

    const-string/jumbo p2, "tns e funo dwtyiopnUel"

    const/4 v11, 0x6

    const-string p2, " ktmneo fwodputeln yin"

    const-string p2, "Unknown field type out"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    throw p1

    :pswitch_15
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {p3, v3}, Lh4/a;->y(Landroid/os/Parcel;I)Landroid/os/Parcel;

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v2, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v4}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->S2()Ljava/util/Map;

    move-result-object v3

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-direct {p0, p1, v3, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->k(Ljava/lang/StringBuilder;Ljava/util/Map;Landroid/os/Parcel;)V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    goto/16 :goto_3

    :pswitch_16
    const/4 v11, 0x1

    const/4 v10, 0x5

    invoke-static {p3, v3}, Lh4/a;->g(Landroid/os/Parcel;I)Landroid/os/Bundle;

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v2}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v3

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    const-string/jumbo v4, "{"

    const-string/jumbo v4, "{"

    const/4 v11, 0x1

    const-string/jumbo v4, "{"

    const-string/jumbo v4, "{"

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    move v4, v7

    const/4 v11, 0x6

    move v4, v7

    move v4, v7

    :goto_6
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    const/4 v11, 0x0

    const/4 v10, 0x3

    if-eqz v8, :cond_9

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x2

    check-cast v8, Ljava/lang/String;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-nez v4, :cond_8

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_8
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    const-string v4, "//:mo"

    const-string v4, "/:/m/"

    const/4 v11, 0x3

    const-string v4, "b//:/"

    const-string v4, "\":\""

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v2, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {v4}, Lcom/google/android/gms/common/util/r;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x0

    move v4, v1

    move v4, v1

    const/4 v11, 0x6

    move v4, v1

    move v4, v1

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    goto :goto_6

    :cond_9
    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    const-string/jumbo v2, "}"

    const-string/jumbo v2, "}"

    const/4 v11, 0x3

    const-string/jumbo v2, "}"

    const-string/jumbo v2, "}"

    const/4 v11, 0x0

    const/4 v10, 0x5

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    goto/16 :goto_3

    :pswitch_17
    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {p3, v3}, Lh4/a;->h(Landroid/os/Parcel;I)[B

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {v2}, Lcom/google/android/gms/common/util/c;->e([B)Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x5

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    goto/16 :goto_3

    :pswitch_18
    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {p3, v3}, Lh4/a;->h(Landroid/os/Parcel;I)[B

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-static {v2}, Lcom/google/android/gms/common/util/c;->d([B)Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    goto/16 :goto_3

    :pswitch_19
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {p3, v3}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-static {v2}, Lcom/google/android/gms/common/util/r;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x2

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    goto/16 :goto_3

    :pswitch_1a
    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-static {p3, v3}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    goto/16 :goto_3

    :pswitch_1b
    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-static {p3, v3}, Lh4/a;->a(Landroid/os/Parcel;I)Ljava/math/BigDecimal;

    move-result-object v2

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    goto/16 :goto_3

    :pswitch_1c
    const/4 v11, 0x7

    invoke-static {p3, v3}, Lh4/a;->T(Landroid/os/Parcel;I)D

    move-result-wide v2

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {p1, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto/16 :goto_3

    :pswitch_1d
    const/4 v11, 0x3

    invoke-static {p3, v3}, Lh4/a;->V(Landroid/os/Parcel;I)F

    move-result v2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x2

    goto/16 :goto_3

    :pswitch_1e
    const/4 v11, 0x0

    invoke-static {p3, v3}, Lh4/a;->c0(Landroid/os/Parcel;I)J

    move-result-wide v2

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {p1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    goto/16 :goto_3

    :pswitch_1f
    const/4 v11, 0x6

    const/4 v10, 0x3

    invoke-static {p3, v3}, Lh4/a;->c(Landroid/os/Parcel;I)Ljava/math/BigInteger;

    move-result-object v2

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    goto/16 :goto_3

    :pswitch_20
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-static {p3, v3}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x0

    goto/16 :goto_3

    :cond_a
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p3}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-ne v0, p2, :cond_b

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x3

    const/16 p2, 0x7d

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    return-void

    :cond_b
    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    new-instance p1, Lh4/a$a;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    const-string/jumbo v1, "ra=Owruvleddese lizaoodn e"

    const-string v1, " ozrolr=le nddeevOad eaiws"

    const/4 v11, 0x3

    const-string/jumbo v1, "zn dreepsaed wielearvd=O l"

    const-string v1, "Overread allowed size end="

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-direct {p1, p2, p3}, Lh4/a$a;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    throw p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_c
        :pswitch_c
        :pswitch_b
    .end packed-switch

    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
    .end packed-switch
.end method

.method private static final n(Ljava/lang/StringBuilder;ILjava/lang/Object;)V
    .locals 3
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, "//"

    const-string v0, "//"

    const/4 v2, 0x0

    const-string v0, "//"

    const-string v0, "\""

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    packed-switch p1, :pswitch_data_0

    const/4 v1, 0x0

    move v2, v1

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    move v2, v1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string/jumbo v0, "ypntbnonqkU= ew"

    const-string v0, "= nUebtyonnpwk "

    const/4 v2, 0x1

    const-string v0, "Unknown type = "

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    throw p0

    :pswitch_0
    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string p1, "caseochostdepocMp tteeyt  dtco nue. n"

    const-string p1, "eoos tu .tdadcotp eroMcep enccehty tn"

    const/4 v2, 0x4

    const-string/jumbo p1, "netm reehotd.cep   deacet sontypccotM"

    const-string p1, "Method does not accept concrete type."

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    throw p0

    :pswitch_1
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    check-cast p1, Ljava/util/HashMap;

    const/4 v2, 0x1

    invoke-static {p0, p1}, Lcom/google/android/gms/common/util/s;->a(Ljava/lang/StringBuilder;Ljava/util/HashMap;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void

    :pswitch_2
    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x5

    check-cast p2, [B

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p2}, Lcom/google/android/gms/common/util/c;->e([B)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void

    :pswitch_3
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast p2, [B

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p2}, Lcom/google/android/gms/common/util/c;->d([B)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void

    :pswitch_4
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/util/r;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    return-void

    :pswitch_5
    const/4 v2, 0x1

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private static final o(Ljava/lang/StringBuilder;Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/Object;)V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x5

    iget-boolean v0, p1, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    check-cast p2, Ljava/util/ArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const-string v0, "["

    const-string v0, "["

    const/4 v5, 0x5

    const-string v0, "["

    const-string v0, "["

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-ge v1, v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const-string v2, ","

    const-string v2, ","

    const/4 v5, 0x5

    const-string v2, ","

    const-string v2, ","

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget v2, p1, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->b:I

    const/4 v4, 0x2

    and-int/2addr v5, v4

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {p0, v2, v3}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->n(Ljava/lang/StringBuilder;ILjava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string p1, "]"

    const-string p1, "]"

    const/4 v5, 0x7

    const-string p1, "]"

    const-string p1, "]"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-void

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget p1, p1, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->b:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p0, p1, p2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->n(Ljava/lang/StringBuilder;ILjava/lang/Object;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void
.end method


# virtual methods
.method public final addConcreteTypeArrayInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 5
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/ArrayList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse;",
            ">(",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-instance p2, Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast v0, Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-ge v1, v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {p3, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    check-cast v2, Lcom/google/android/gms/common/server/response/FastJsonResponse;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v2, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->g()Landroid/os/Parcel;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p2, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object p3, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x6

    invoke-static {p3, p1, p2, v0}, Lh4/b;->Q(Landroid/os/Parcel;ILjava/util/List;Z)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method public final addConcreteTypeInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Lcom/google/android/gms/common/server/response/FastJsonResponse;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/gms/common/server/response/FastJsonResponse;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse;",
            ">(",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;",
            "Ljava/lang/String;",
            "TT;)V"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v2, 0x1

    check-cast p3, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p3}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->g()Landroid/os/Parcel;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object p3, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p3, p1, p2, v0}, Lh4/b;->O(Landroid/os/Parcel;ILandroid/os/Parcel;Z)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public final g()Landroid/os/Parcel;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->f:I

    const/4 v3, 0x5

    move v4, v3

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eq v0, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->g:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v0, v2}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v4, 0x1

    iput v1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->f:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v0}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->g:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-static {v2, v0}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput v1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->f:I

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object v0
.end method

.method public final getFieldMappings()Ljava/util/Map;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "**>;>;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->d:Lcom/google/android/gms/common/server/response/zan;

    const/4 v3, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->e:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast v1, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/server/response/zan;->z2(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method public final getValueObject(Ljava/lang/String;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x4

    const-string/jumbo v0, "vii o nruCnqtnOSe.horidegNt sedtp tJ sro  omhooe"

    const-string/jumbo v0, "tq isiCp do SgNenrihooJ nheuostreedrOovmn t.t e "

    const/4 v2, 0x6

    const-string/jumbo v0, "hotonbm.hnue   teC qed roi eNgiJreSiOvntt otsosd"

    const-string v0, "Converting to JSON does not require this method."

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    throw p1
.end method

.method public final isPrimitiveFieldSet(Ljava/lang/String;)Z
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string v0, " i nOtuoeoerro htdtvJSus h nsiqd .eCqtn mrgteoNo"

    const-string/jumbo v0, "gdmnstNtq  eutos d .v tr eeeroOio oChnohiteSnrJq"

    const/4 v2, 0x6

    const-string/jumbo v0, "thudtrgpnhtri vesNoei tOnomeCsqS.oJri ote deo n "

    const-string v0, "Converting to JSON does not require this method."

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    throw p1
.end method

.method protected final setBooleanInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Z)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "**>;",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p2, p1, p3}, Lh4/b;->g(Landroid/os/Parcel;IZ)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method protected final setDecodedBytesInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;[B)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # [B
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "**>;",
            "Ljava/lang/String;",
            "[B)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p2, p1, p3, v0}, Lh4/b;->m(Landroid/os/Parcel;I[BZ)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method protected final setIntegerInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;I)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "**>;",
            "Ljava/lang/String;",
            "I)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {p2, p1, p3}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method protected final setLongInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;J)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "**>;",
            "Ljava/lang/String;",
            "J)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v1, 0x4

    const/4 v0, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p2, p1, p3, p4}, Lh4/b;->K(Landroid/os/Parcel;IJ)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method protected final setStringInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "**>;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p2, p1, p3, v0}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method protected final setStringMapInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/Map;)V
    .locals 5
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "**>;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance p2, Landroid/os/Bundle;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    check-cast v0, Ljava/util/Map;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {p3, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    check-cast v2, Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p2, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object p3, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x1

    move v4, v0

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p3, p1, p2, v0}, Lh4/b;->k(Landroid/os/Parcel;ILandroid/os/Bundle;Z)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void
.end method

.method protected final setStringsInternal(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 5
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/ArrayList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "**>;",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    check-cast p2, Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-array v0, p2, [Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-ge v1, p2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v2, Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    aput-object v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 p3, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p2, p1, v0, p3}, Lh4/b;->Z(Landroid/os/Parcel;I[Ljava/lang/String;Z)V

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void
.end method

.method public final toString()Ljava/lang/String;
    .locals 6
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->d:Lcom/google/android/gms/common/server/response/zan;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string v1, "  tnoJvnqs Oalise. tStdnrCoc tnoiNene "

    const-string v1, "cisntCntlnJOoni  eNro.ad tSv eeoos t n"

    const/4 v5, 0x2

    const-string/jumbo v1, "evs. S l rtOnCdetcon Ntenioson  oacJit"

    const-string v1, "Cannot convert to JSON on client side."

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->g()Landroid/os/Parcel;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/16 v2, 0x64

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->e:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    check-cast v2, Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v3, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->d:Lcom/google/android/gms/common/server/response/zan;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v3, v2}, Lcom/google/android/gms/common/server/response/zan;->z2(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    check-cast v2, Ljava/util/Map;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {p0, v1, v2, v0}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->k(Ljava/lang/StringBuilder;Ljava/util/Map;Landroid/os/Parcel;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 7
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->a:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p1, v2, v0}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->g()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v3, 0x2

    shl-int/2addr v6, v3

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {p1, v3, v0, v4}, Lh4/b;->O(Landroid/os/Parcel;ILandroid/os/Parcel;Z)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->c:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eq v0, v2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->d:Lcom/google/android/gms/common/server/response/zan;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->d:Lcom/google/android/gms/common/server/response/zan;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v2, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p1, v2, v0, p2, v4}, Lh4/b;->S(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {p1, v1}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-void
.end method

.method protected final zab(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/math/BigDecimal;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/math/BigDecimal;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p2, p1, p3, v0}, Lh4/b;->c(Landroid/os/Parcel;ILjava/math/BigDecimal;Z)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method protected final zad(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 5
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/ArrayList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    check-cast p2, Ljava/util/ArrayList;

    const/4 v4, 0x7

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-array v0, p2, [Ljava/math/BigDecimal;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-ge v1, p2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v2, Ljava/math/BigDecimal;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 p3, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p2, p1, v0, p3}, Lh4/b;->d(Landroid/os/Parcel;I[Ljava/math/BigDecimal;Z)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method protected final zaf(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/math/BigInteger;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/math/BigInteger;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p2, p1, p3, v0}, Lh4/b;->e(Landroid/os/Parcel;ILjava/math/BigInteger;Z)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method protected final zah(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 5
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/ArrayList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    check-cast p2, Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x7

    new-array v0, p2, [Ljava/math/BigInteger;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x0

    move v4, v3

    if-ge v1, p2, :cond_0

    const/4 v4, 0x1

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    check-cast v2, Ljava/math/BigInteger;

    const/4 v4, 0x0

    const/4 v3, 0x6

    aput-object v2, v0, v1

    const/4 v4, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 p3, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p2, p1, v0, p3}, Lh4/b;->f(Landroid/os/Parcel;I[Ljava/math/BigInteger;Z)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method

.method protected final zak(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 5
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/ArrayList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v4, 0x3

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x2

    check-cast p2, Ljava/util/ArrayList;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    new-array v0, p2, [Z

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-ge v1, p2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast v2, Ljava/lang/Boolean;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    aput-boolean v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 p3, 0x1

    invoke-static {p2, p1, v0, p3}, Lh4/b;->h(Landroid/os/Parcel;I[ZZ)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method

.method protected final zan(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;D)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v0, 0x1

    and-int/2addr v1, v0

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p2, p1, p3, p4}, Lh4/b;->r(Landroid/os/Parcel;ID)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method protected final zap(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 6
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/ArrayList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x6

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast p2, Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-array v0, p2, [D

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x0

    if-ge v1, p2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    check-cast v2, Ljava/lang/Double;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    aput-wide v2, v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 p3, 0x1

    const/4 v4, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p2, p1, v0, p3}, Lh4/b;->s(Landroid/os/Parcel;I[DZ)V

    const/4 v5, 0x3

    return-void
.end method

.method protected final zar(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;F)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p2, p1, p3}, Lh4/b;->w(Landroid/os/Parcel;IF)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method protected final zat(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 5
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/ArrayList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x6

    check-cast p2, Ljava/util/ArrayList;

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-array v0, p2, [F

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-ge v1, p2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    check-cast v2, Ljava/lang/Float;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v2}, Ljava/lang/Float;->floatValue()F

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    aput v2, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 p3, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {p2, p1, v0, p3}, Lh4/b;->x(Landroid/os/Parcel;I[FZ)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method protected final zaw(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 5
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/ArrayList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    check-cast p2, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-array v0, p2, [I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-ge v1, p2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    check-cast v2, Ljava/lang/Integer;

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    aput v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 p3, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p2, p1, v0, p3}, Lh4/b;->G(Landroid/os/Parcel;I[IZ)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method

.method protected final zaz(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 6
    .param p1    # Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/ArrayList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->i(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    check-cast p2, Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-array v0, p2, [J

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ge v1, p2, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    check-cast v2, Ljava/lang/Long;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    aput-wide v2, v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;->b:Landroid/os/Parcel;

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 p3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p2, p1, v0, p3}, Lh4/b;->L(Landroid/os/Parcel;I[JZ)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-void
.end method
