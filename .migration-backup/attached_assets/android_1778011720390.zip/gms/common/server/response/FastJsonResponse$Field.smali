.class public Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "FieldCreator"
.end annotation

.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/server/response/FastJsonResponse;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Field"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<I:",
        "Ljava/lang/Object;",
        "O:",
        "Ljava/lang/Object;",
        ">",
        "Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final CREATOR:Lcom/google/android/gms/common/server/response/k;


# instance fields
.field private final a:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$h;
        getter = "getVersionCode"
        id = 0x1
    .end annotation
.end field

.field protected final b:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getTypeIn"
        id = 0x2
    .end annotation
.end field

.field protected final c:Z
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "isTypeInArray"
        id = 0x3
    .end annotation
.end field

.field protected final d:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getTypeOut"
        id = 0x4
    .end annotation
.end field

.field protected final e:Z
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "isTypeOutArray"
        id = 0x5
    .end annotation
.end field

.field protected final f:Ljava/lang/String;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getOutputFieldName"
        id = 0x6
    .end annotation
.end field

.field protected final g:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getSafeParcelableFieldId"
        id = 0x7
    .end annotation
.end field

.field protected final h:Ljava/lang/Class;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field protected final i:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getConcreteTypeName"
        id = 0x8
    .end annotation
.end field

.field private j:Lcom/google/android/gms/common/server/response/zan;

.field private final k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getWrappedConverter"
        id = 0x9
        type = "com.google.android.gms.common.server.converter.ConverterWrapper"
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    new-instance v0, Lcom/google/android/gms/common/server/response/k;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/common/server/response/k;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->CREATOR:Lcom/google/android/gms/common/server/response/k;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method constructor <init>(IIZIZLjava/lang/String;ILjava/lang/String;Lcom/google/android/gms/common/server/converter/zaa;)V
    .locals 2
    .param p1    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .param p3    # Z
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3
        .end annotation
    .end param
    .param p4    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x4
        .end annotation
    .end param
    .param p5    # Z
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x5
        .end annotation
    .end param
    .param p6    # Ljava/lang/String;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x6
        .end annotation
    .end param
    .param p7    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x7
        .end annotation
    .end param
    .param p8    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation

        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x8
        .end annotation
    .end param
    .param p9    # Lcom/google/android/gms/common/server/converter/zaa;
        .annotation build Landroidx/annotation/q0;
        .end annotation

        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x9
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->a:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    iput p2, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-boolean p3, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p4, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->d:I

    const/4 v1, 0x7

    iput-boolean p5, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->e:Z

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p6, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->f:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p7, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->g:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 p1, 0x0

    move v1, p1

    const/4 v0, 0x1

    move v1, v0

    if-nez p8, :cond_0

    const/4 v0, 0x6

    shr-int/2addr v1, v0

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->h:Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->i:Ljava/lang/String;

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x6

    const-class p2, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const-class p2, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const/4 v1, 0x1

    const-class p2, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const-class p2, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->h:Ljava/lang/Class;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p8, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->i:Ljava/lang/String;

    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    if-nez p9, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void

    :cond_1
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p9}, Lcom/google/android/gms/common/server/converter/zaa;->z2()Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method protected constructor <init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V
    .locals 3
    .param p5    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p7    # Ljava/lang/Class;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p8    # Lcom/google/android/gms/common/server/response/FastJsonResponse$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->a:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->b:I

    const/4 v2, 0x2

    iput-boolean p2, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p3, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->d:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-boolean p4, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->e:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    iput-object p5, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->f:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput p6, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->g:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object p7, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->h:Ljava/lang/Class;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-nez p7, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->i:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p7}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->i:Ljava/lang/String;

    :goto_0
    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p8, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public static A2(Ljava/lang/String;ILjava/lang/Class;)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 12
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Class;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse;",
            ">(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/Class<",
            "TT;>;)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "TT;TT;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x0

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    const/4 v2, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    const/16 v3, 0xb

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    const/4 v4, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    const/4 v8, 0x0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    move v1, v3

    move v1, v3

    const/4 v11, 0x0

    move v1, v3

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    move v6, p1

    move v6, p1

    move v6, p1

    move v6, p1

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    return-object v9
.end method

.method public static B2(Ljava/lang/String;ILjava/lang/Class;)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 12
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Class;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse;",
            ">(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/Class<",
            "TT;>;)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "Ljava/util/ArrayList<",
            "TT;>;",
            "Ljava/util/ArrayList<",
            "TT;>;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    const/4 v2, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    const/16 v3, 0xb

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    const/4 v8, 0x0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    move v1, v3

    move v1, v3

    const/4 v11, 0x2

    move v1, v3

    move v1, v3

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x4

    move v6, p1

    move v6, p1

    const/4 v11, 0x5

    move v6, p1

    move v6, p1

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v11, 0x5

    const/4 v10, 0x6

    return-object v9
.end method

.method public static C2(Ljava/lang/String;I)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 12
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "Ljava/lang/Double;",
            "Ljava/lang/Double;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x7

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v10, 0x3

    move v11, v10

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    const/4 v2, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/4 v3, 0x4

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    const/4 v4, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    const/4 v7, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    const/4 v8, 0x0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    move v6, p1

    move v6, p1

    const/4 v11, 0x1

    move v6, p1

    move v6, p1

    const/4 v11, 0x6

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v10, 0x3

    move v11, v10

    return-object v9
.end method

.method public static D2(Ljava/lang/String;I)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 12
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "Ljava/lang/Float;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x7

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v1, 0x3

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    const/4 v2, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    const/4 v3, 0x3

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    const/4 v4, 0x0

    const/4 v10, 0x1

    and-int/2addr v11, v10

    const/4 v7, 0x0

    and-int/2addr v11, v7

    const/4 v10, 0x1

    shr-int/2addr v11, v10

    const/4 v8, 0x0

    move v11, v8

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x5

    const/4 v10, 0x5

    move v6, p1

    move v6, p1

    const/4 v11, 0x4

    move v6, p1

    move v6, p1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v11, 0x7

    return-object v9
.end method

.method public static E2(Ljava/lang/String;I)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 12
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    const/4 v1, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    const/4 v3, 0x0

    const/4 v10, 0x6

    const/4 v10, 0x0

    const/4 v4, 0x0

    move v11, v4

    const/4 v10, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    const/4 v7, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    const/4 v8, 0x0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    move v6, p1

    move v6, p1

    const/4 v11, 0x2

    move v6, p1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    return-object v9
.end method

.method public static F2(Ljava/lang/String;I)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 12
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "Ljava/lang/Long;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x7

    const/4 v1, 0x1

    const/4 v11, 0x4

    const/4 v1, 0x2

    const/4 v10, 0x6

    const/4 v10, 0x6

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/4 v4, 0x0

    const/4 v10, 0x7

    move v11, v10

    const/4 v7, 0x0

    move v11, v7

    const/4 v10, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    const/4 v8, 0x0

    move-object v0, v9

    move-object v0, v9

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    move v6, p1

    move v6, p1

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    return-object v9
.end method

.method public static G2(Ljava/lang/String;I)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 12
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x1

    const/4 v2, 0x0

    const/4 v11, 0x7

    shl-int/2addr v10, v2

    const/4 v3, 0x6

    move v11, v3

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    const/4 v4, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/4 v7, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/4 v8, 0x0

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    move v1, v3

    move v1, v3

    const/4 v11, 0x0

    move v1, v3

    move v1, v3

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    move v6, p1

    move v6, p1

    const/4 v11, 0x7

    move v6, p1

    move v6, p1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x5

    return-object v9
.end method

.method public static H2(Ljava/lang/String;I)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 12
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    const/4 v2, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    const/16 v3, 0xa

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/4 v4, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    const/4 v7, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    const/4 v8, 0x0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    move v1, v3

    move v1, v3

    move v1, v3

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    move v6, p1

    move v6, p1

    const/4 v11, 0x6

    move v6, p1

    const/4 v11, 0x1

    const/4 v10, 0x2

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    return-object v9
.end method

.method public static I2(Ljava/lang/String;I)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 12
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x3

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x4

    const/4 v2, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    const/4 v4, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v7, 0x0

    move v11, v7

    const/4 v10, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    const/4 v8, 0x0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    move v1, v3

    move v1, v3

    const/4 v11, 0x7

    move v1, v3

    move v1, v3

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    move v6, p1

    const/4 v11, 0x4

    move v6, p1

    move v6, p1

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    return-object v9
.end method

.method public static K2(Ljava/lang/String;ILcom/google/android/gms/common/server/response/FastJsonResponse$a;Z)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 11
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/server/response/FastJsonResponse$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$a<",
            "**>;Z)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v10, 0x1

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v10, 0x6

    invoke-interface {p2}, Lcom/google/android/gms/common/server/response/FastJsonResponse$a;->d()I

    const/4 v10, 0x2

    invoke-interface {p2}, Lcom/google/android/gms/common/server/response/FastJsonResponse$a;->e()I

    const/4 v10, 0x4

    const/4 v1, 0x7

    const/4 v10, 0x3

    const/4 v3, 0x0

    const/4 v10, 0x1

    const/4 v4, 0x0

    const/4 v10, 0x4

    const/4 v7, 0x0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v10, 0x2

    move v2, p3

    move v2, p3

    move v2, p3

    move v2, p3

    move-object v5, p0

    move-object v5, p0

    const/4 v10, 0x7

    move v6, p1

    move v6, p1

    move v6, p1

    move v6, p1

    move-object v8, p2

    move-object v8, p2

    move-object v8, p2

    move-object v8, p2

    const/4 v10, 0x7

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v10, 0x7

    return-object v9
.end method

.method static bridge synthetic N2(Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;)Lcom/google/android/gms/common/server/response/FastJsonResponse$a;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    iget-object p0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method public static y2(Ljava/lang/String;I)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 12
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "[B[B>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x1

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    const/4 v2, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    const/16 v3, 0x8

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    const/4 v4, 0x0

    const/4 v11, 0x5

    const/4 v7, 0x0

    const/4 v11, 0x2

    const/4 v7, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x1

    const/4 v8, 0x0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x4

    const/4 v10, 0x4

    move v1, v3

    const/4 v11, 0x6

    move v1, v3

    move v1, v3

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x7

    move v6, p1

    const/4 v11, 0x5

    move v6, p1

    move v6, p1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    return-object v9
.end method

.method public static z2(Ljava/lang/String;I)Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 12
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Lcom/google/android/gms/common/server/response/FastJsonResponse$Field<",
            "Ljava/lang/Boolean;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    new-instance v9, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x0

    const/4 v2, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    const/4 v3, 0x6

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    const/4 v4, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/4 v7, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x6

    const/4 v8, 0x0

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    move v1, v3

    const/4 v11, 0x4

    move v1, v3

    move v1, v3

    move-object v5, p0

    move-object v5, p0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    move v6, p1

    move v6, p1

    const/4 v11, 0x3

    move v6, p1

    move v6, p1

    const/4 v11, 0x4

    const/4 v10, 0x6

    invoke-direct/range {v0 .. v8}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IZIZLjava/lang/String;ILjava/lang/Class;Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)V

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    return-object v9
.end method


# virtual methods
.method public J2()I
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->g:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method final L2()Lcom/google/android/gms/common/server/converter/zaa;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    return-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/server/converter/zaa;->y2(Lcom/google/android/gms/common/server/response/FastJsonResponse$a;)Lcom/google/android/gms/common/server/converter/zaa;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public final M2()Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;
    .locals 13
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    new-instance v10, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget v1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->a:I

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget v2, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->b:I

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x2

    iget-boolean v3, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x6

    iget v4, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->d:I

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget-boolean v5, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->e:Z

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x7

    iget-object v6, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->f:Ljava/lang/String;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x5

    iget v7, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->g:I

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget-object v8, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->i:Ljava/lang/String;

    const/4 v12, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->L2()Lcom/google/android/gms/common/server/converter/zaa;

    move-result-object v9

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-direct/range {v0 .. v9}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;-><init>(IIZIZLjava/lang/String;ILjava/lang/String;Lcom/google/android/gms/common/server/converter/zaa;)V

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    return-object v10
.end method

.method public final O2()Lcom/google/android/gms/common/server/response/FastJsonResponse;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InstantiationException;,
            Ljava/lang/IllegalAccessException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->h:Ljava/lang/Class;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->h:Ljava/lang/Class;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const-class v1, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const-class v1, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const/4 v4, 0x7

    const-class v1, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const-class v1, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const/4 v3, 0x5

    or-int/2addr v4, v3

    if-ne v0, v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->i:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->j:Lcom/google/android/gms/common/server/response/zan;

    const/4 v3, 0x0

    or-int/2addr v4, v3

    const-string v1, "  sstyscatreun soS ef Tt bcjan mdechcsRple ehetrd inaipgioto  p.cPeeb  taeepys fiaelinteifemr"

    const-string v1, "adst  smyaeei   a r b.iecernuptft o heateos nmescliftchStfe pijetosycei pgnTsRdb pelPinee acr"

    const/4 v4, 0x6

    const-string v1, "aimmecibt an bip eciRfmcnTPuafnsoctgepSrs. rsst peer yejtheepe id tfd iesctahyeae to n le o l"

    const-string v1, "The field mapping dictionary must be set if the concrete type is a SafeParcelResponse object."

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    shl-int/2addr v4, v3

    new-instance v0, Lcom/google/android/gms/common/server/response/SafeParcelResponse;

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->j:Lcom/google/android/gms/common/server/response/zan;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->i:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x0

    invoke-direct {v0, v1, v2}, Lcom/google/android/gms/common/server/response/SafeParcelResponse;-><init>(Lcom/google/android/gms/common/server/response/zan;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    check-cast v0, Lcom/google/android/gms/common/server/response/FastJsonResponse;

    const/4 v4, 0x1

    return-object v0
.end method

.method public final P2(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$a;->p1(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method public final Q2(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/server/response/FastJsonResponse$a;->j1(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p1
.end method

.method final R2()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->i:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x0

    move v1, v0

    move v1, v0

    :cond_0
    const/4 v2, 0x1

    return-object v0
.end method

.method public final S2()Ljava/util/Map;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->i:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->j:Lcom/google/android/gms/common/server/response/zan;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->j:Lcom/google/android/gms/common/server/response/zan;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->i:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/server/response/zan;->z2(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    check-cast v0, Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0
.end method

.method public final T2(Lcom/google/android/gms/common/server/response/zan;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->j:Lcom/google/android/gms/common/server/response/zan;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public final U2()Z
    .locals 3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/google/android/gms/common/internal/t;->d(Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->a:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo v2, "nidvoerosCm"

    const-string/jumbo v2, "nrsmdoveCei"

    const/4 v4, 0x3

    const-string v2, "eivoCbrndos"

    const-string/jumbo v2, "versionCode"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v2, v1}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->b:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v2, "uopnet"

    const-string/jumbo v2, "ntpeoy"

    const/4 v4, 0x1

    const-string/jumbo v2, "typeIn"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v2, v1}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-boolean v1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v2, "aebynprprAt"

    const-string/jumbo v2, "rpAeybratIn"

    const/4 v4, 0x1

    const-string/jumbo v2, "yIpnyaerqtA"

    const-string/jumbo v2, "typeInArray"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v2, v1}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->d:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const-string/jumbo v2, "tesutuy"

    const-string/jumbo v2, "tepuytu"

    const/4 v4, 0x1

    const-string/jumbo v2, "tOtmuey"

    const-string/jumbo v2, "typeOut"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v2, v1}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-boolean v1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->e:Z

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v2, "ptpuoaOyyrAt"

    const-string/jumbo v2, "yrraOtuptpAy"

    const-string/jumbo v2, "patyybtOrAeu"

    const-string/jumbo v2, "typeOutArray"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v2, v1}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v1, "udmietuotqpaNul"

    const-string v1, "eNtdatliqpmuuoe"

    const/4 v4, 0x4

    const-string/jumbo v1, "outputFieldName"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->f:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->g:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string v2, "FliededpaIlearsPc"

    const-string v2, "ePslidaedFeclraIs"

    const/4 v4, 0x4

    const-string v2, "PeaslldfqaiFdceeI"

    const-string/jumbo v2, "safeParcelFieldId"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v2, v1}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v1, "aosetmNrncymeTce"

    const-string/jumbo v1, "rNemtmnceoTeaecy"

    const/4 v4, 0x2

    const-string/jumbo v1, "oycmtcnrNeaeTeem"

    const-string v1, "concreteTypeName"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->R2()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->h:Ljava/lang/Class;

    const/4 v4, 0x2

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo v2, "neo.oTlsesoaprctyc"

    const-string v2, "eTesosaocp.nltyccr"

    const/4 v4, 0x3

    const-string/jumbo v2, "ypseeb.Tlcretsnacc"

    const-string v2, "concreteType.class"

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v2, v1}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->k:Lcom/google/android/gms/common/server/response/FastJsonResponse$a;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v2, "meroetubcevNn"

    const-string/jumbo v2, "oaNenbretmevc"

    const-string v2, "erneectpvoNma"

    const-string v2, "converterName"

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v2, v1}, Lcom/google/android/gms/common/internal/t$a;->a(Ljava/lang/String;Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/t$a;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 6
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->a:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {p1, v2, v0}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v0, 0x2

    xor-int/2addr v5, v0

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget v2, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->b:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p1, v0, v2}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v0, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-boolean v2, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->c:Z

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p1, v0, v2}, Lh4/b;->g(Landroid/os/Parcel;IZ)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v0, 0x4

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->d:I

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-static {p1, v0, v2}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v0, 0x5

    const/4 v0, 0x5

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-boolean v2, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->e:Z

    const/4 v4, 0x1

    move v5, v4

    invoke-static {p1, v0, v2}, Lh4/b;->g(Landroid/os/Parcel;IZ)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->f:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v2, 0x6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    move v5, v4

    invoke-static {p1, v2, v0, v3}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v0, 0x7

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->J2()I

    move-result v2

    const/4 v5, 0x2

    invoke-static {p1, v0, v2}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/16 v0, 0x8

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->R2()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {p1, v0, v2, v3}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/16 v0, 0x9

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/common/server/response/FastJsonResponse$Field;->L2()Lcom/google/android/gms/common/server/converter/zaa;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p1, v0, v2, p2, v3}, Lh4/b;->S(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v5, 0x3

    invoke-static {p1, v1}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-void
.end method
