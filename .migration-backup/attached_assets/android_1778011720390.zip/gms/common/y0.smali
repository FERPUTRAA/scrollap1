.class Lcom/google/android/gms/common/y0;
.super Ljava/lang/Object;


# annotations
.annotation runtime Ly4/b;
.end annotation


# static fields
.field private static final e:Lcom/google/android/gms/common/y0;


# instance fields
.field final a:Z

.field final b:Ljava/lang/String;
    .annotation runtime Lv7/h;
    .end annotation
.end field

.field final c:Ljava/lang/Throwable;
    .annotation runtime Lv7/h;
    .end annotation
.end field

.field final d:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-instance v6, Lcom/google/android/gms/common/y0;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v1, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v2, 0x3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v3, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v4, 0x0

    const/4 v7, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v5, 0x0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/y0;-><init>(ZIILjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    sput-object v6, Lcom/google/android/gms/common/y0;->e:Lcom/google/android/gms/common/y0;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    return-void
.end method

.method private constructor <init>(ZIILjava/lang/String;Ljava/lang/Throwable;)V
    .locals 2
    .param p4    # Ljava/lang/String;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .param p5    # Ljava/lang/Throwable;
        .annotation runtime Lv7/h;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    shr-int/2addr v1, v0

    iput-boolean p1, p0, Lcom/google/android/gms/common/y0;->a:Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p2, p0, Lcom/google/android/gms/common/y0;->d:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p4, p0, Lcom/google/android/gms/common/y0;->b:Ljava/lang/String;

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p5, p0, Lcom/google/android/gms/common/y0;->c:Ljava/lang/Throwable;

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method

.method synthetic constructor <init>(ZIILjava/lang/String;Ljava/lang/Throwable;Lcom/google/android/gms/common/x0;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    const/4 p2, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 p3, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 p4, 0x5

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 p5, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p6, 0x0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct/range {p1 .. p6}, Lcom/google/android/gms/common/y0;-><init>(ZIILjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method static b()Lcom/google/android/gms/common/y0;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~Ks~ a @/-lo@btm  u~/ @@~@@~ o @o brfo@@~i .i ~bl~@@~@M~ ~tvc~@syi~@ n@~  @doS@ ~ ~f~~@~1~~@~4o@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/common/y0;->e:Lcom/google/android/gms/common/y0;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method static c(Ljava/lang/String;)Lcom/google/android/gms/common/y0;
    .locals 9
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x3

    const/4 v7, 0x5

    new-instance v6, Lcom/google/android/gms/common/y0;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v2, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 v3, 0x5

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/4 v5, 0x0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/y0;-><init>(ZIILjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x1

    return-object v6
.end method

.method static d(Ljava/lang/String;Ljava/lang/Throwable;)Lcom/google/android/gms/common/y0;
    .locals 9
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Throwable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    new-instance v6, Lcom/google/android/gms/common/y0;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v1, 0x0

    const/4 v7, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 v2, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v3, 0x5

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/y0;-><init>(ZIILjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    return-object v6
.end method

.method static f(I)Lcom/google/android/gms/common/y0;
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x3

    new-instance v6, Lcom/google/android/gms/common/y0;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v1, 0x1

    or-int/2addr v8, v1

    const/4 v7, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/4 v4, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/4 v5, 0x0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    move v2, p0

    move v2, p0

    const/4 v8, 0x4

    move v2, p0

    const/4 v7, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/y0;-><init>(ZIILjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    return-object v6
.end method

.method static g(IILjava/lang/String;Ljava/lang/Throwable;)Lcom/google/android/gms/common/y0;
    .locals 9
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Throwable;
        .annotation runtime Lv7/h;
        .end annotation
    .end param

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    new-instance v6, Lcom/google/android/gms/common/y0;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v1, 0x0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    move v2, p0

    move v2, p0

    move v2, p0

    move v2, p0

    const/4 v8, 0x0

    const/4 v7, 0x4

    move v3, p1

    move v3, p1

    move v3, p1

    move v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/y0;-><init>(ZIILjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    return-object v6
.end method


# virtual methods
.method a()Ljava/lang/String;
    .locals 3
    .annotation runtime Lv7/h;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/y0;->b:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method final e()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-boolean v0, p0, Lcom/google/android/gms/common/y0;->a:Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v0, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v1, "strmatisfoieoglGtReeCc"

    const-string v1, "GoogleCertificatesRslt"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/y0;->c:Ljava/lang/Throwable;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/y0;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/android/gms/common/y0;->c:Ljava/lang/Throwable;

    const/4 v3, 0x2

    move v4, v3

    invoke-static {v1, v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/y0;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void
.end method
