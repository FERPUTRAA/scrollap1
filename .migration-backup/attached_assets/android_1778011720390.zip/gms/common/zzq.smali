.class public final Lcom/google/android/gms/common/zzq;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "GoogleCertificatesLookupResponseCreator"
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/zzq;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Z
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getResult"
        id = 0x1
    .end annotation
.end field

.field private final b:Ljava/lang/String;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getErrorMessage"
        id = 0x2
    .end annotation

    .annotation runtime Lv7/h;
    .end annotation
.end field

.field private final c:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getStatusValue"
        id = 0x3
    .end annotation
.end field

.field private final d:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getFirstPartyStatusValue"
        id = 0x4
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Lcom/google/android/gms/common/t0;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/google/android/gms/common/t0;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    sput-object v0, Lcom/google/android/gms/common/zzq;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method constructor <init>(ZLjava/lang/String;II)V
    .locals 2
    .param p1    # Z
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .param p3    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3
        .end annotation
    .end param
    .param p4    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x4
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/google/android/gms/common/zzq;->a:Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/android/gms/common/zzq;->b:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x7

    invoke-static {p3}, Lcom/google/android/gms/common/z0;->a(I)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/gms/common/zzq;->c:I

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p4}, Lcom/google/android/gms/common/h0;->a(I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput p1, p0, Lcom/google/android/gms/common/zzq;->d:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final A2()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s  f~c@~n~b @@o ~s- rK4~@.~i @~S  @ ~@ty@@M~a~@~o~~~1~i~v~~@@@@ /~@u ~/@b@ood@ fm~ t~ @l io lb"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/common/zzq;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/z0;->a(I)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result p2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x0

    iget-boolean v1, p0, Lcom/google/android/gms/common/zzq;->a:Z

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1, v0, v1}, Lh4/b;->g(Landroid/os/Parcel;IZ)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/zzq;->b:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    xor-int/2addr v4, v2

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p1, v2, v0, v1}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v0, 0x3

    const/4 v4, 0x7

    iget v1, p0, Lcom/google/android/gms/common/zzq;->c:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p1, v0, v1}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x0

    iget v1, p0, Lcom/google/android/gms/common/zzq;->d:I

    const/4 v4, 0x4

    invoke-static {p1, v0, v1}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p1, p2}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method public final y2()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/gms/common/zzq;->a:Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public final z2()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/gms/common/zzq;->d:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/h0;->a(I)I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public final zza()Ljava/lang/String;
    .locals 3
    .annotation runtime Lv7/h;
    .end annotation

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/zzq;->b:Ljava/lang/String;

    const/4 v1, 0x7

    move v2, v1

    return-object v0
.end method
