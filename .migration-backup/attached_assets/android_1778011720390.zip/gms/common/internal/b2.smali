.class public final Lcom/google/android/gms/common/internal/b2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "@@s~bf~~~~@ o t@~ml~o~K .@i1/~a S@@~c~y@o~ ~- ~i@@@db@~@@M~ o  t bnlf~/~~@@@i~o @~ @   u4v~ os r"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x4

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    const/4 v1, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    const/4 v2, 0x0

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v9, v7

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    move v5, v2

    move v5, v2

    const/4 v11, 0x1

    move v5, v2

    move v5, v2

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    move v6, v5

    move v6, v5

    const/4 v11, 0x2

    move v6, v5

    move v6, v5

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    move v8, v6

    move v8, v6

    const/4 v11, 0x0

    move v8, v6

    move v8, v6

    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-ge v1, v0, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v1

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-static {v1}, Lh4/a;->O(I)I

    move-result v2

    const/4 v11, 0x0

    const/4 v10, 0x1

    packed-switch v2, :pswitch_data_0

    const/4 v10, 0x5

    or-int/2addr v11, v10

    invoke-static {p1, v1}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    goto :goto_0

    :pswitch_0
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-static {p1, v1}, Lh4/a;->u(Landroid/os/Parcel;I)[I

    move-result-object v9

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x7

    goto :goto_0

    :pswitch_1
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v8

    const/4 v11, 0x4

    const/4 v10, 0x0

    goto :goto_0

    :pswitch_2
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {p1, v1}, Lh4/a;->u(Landroid/os/Parcel;I)[I

    move-result-object v7

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x7

    goto :goto_0

    :pswitch_3
    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {p1, v1}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v6

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    goto :goto_0

    :pswitch_4
    const/4 v11, 0x5

    invoke-static {p1, v1}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v5

    const/4 v11, 0x2

    const/4 v10, 0x1

    goto :goto_0

    :pswitch_5
    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    sget-object v2, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {p1, v1, v2}, Lh4/a;->C(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    check-cast v4, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    goto :goto_0

    :cond_0
    const/4 v11, 0x6

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    new-instance p1, Lcom/google/android/gms/common/internal/ConnectionTelemetryConfiguration;

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-direct/range {v3 .. v9}, Lcom/google/android/gms/common/internal/ConnectionTelemetryConfiguration;-><init>(Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;ZZ[II[I)V

    const/4 v10, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    return-object p1

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    new-array p1, p1, [Lcom/google/android/gms/common/internal/ConnectionTelemetryConfiguration;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p1
.end method
