.class public final Lcom/google/android/gms/common/internal/t;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/internal/t$a;
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo v1, "ntsenUiisnbaas"

    const-string v1, "ansnnUabeitlsi"

    const/4 v3, 0x0

    const-string v1, "aitmatliUnbsne"

    const-string v1, "Uninstantiable"

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    throw v0
.end method

.method public static a(Landroid/os/Bundle;Landroid/os/Bundle;)Z
    .locals 7
    .param p0    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@~  o~bf o@~i.b @nr~ @  4-v  ~@~@a@~di1~ bol@lcs@~~~~~@@u m~~@ K@o~/S@~ y /~@@@t~f@Mo ~o@~ i@o~t"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    const/4 v0, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz p0, :cond_5

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez p1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/os/BaseBundle;->size()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/os/BaseBundle;->size()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eq v2, v3, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    return v1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v2, v3}, Ljava/util/Set;->containsAll(Ljava/util/Collection;)Z

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-nez v3, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    return v1

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_3
    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v3, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    check-cast v3, Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p0, v3}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1, v3}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v4, v3}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-nez v3, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x2

    return v1

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    return v0

    :cond_5
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-ne p0, p1, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    return v0

    :cond_6
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    return v1
.end method

.method public static b(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eq p0, p1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz p0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    return v1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    move v0, v1

    move v0, v1

    const/4 v3, 0x2

    move v0, v1

    move v0, v1

    :cond_2
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    return v0
.end method

.method public static varargs c([Ljava/lang/Object;)I
    .locals 2
    .param p0    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return p0
.end method

.method public static d(Ljava/lang/Object;)Lcom/google/android/gms/common/internal/t$a;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/common/internal/t$a;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {v0, p0, v1}, Lcom/google/android/gms/common/internal/t$a;-><init>(Ljava/lang/Object;Lcom/google/android/gms/common/internal/o1;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0
.end method
