.class public final Lcom/google/android/gms/common/internal/q1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@ s 1mo.b b@f~isy@ooa~~d@~ ~ @ ~v~~~@~f~~ @@4c~or@~ M@bn t@   ol~@@@@@ ~~Si@~  ~@u  @~o-i~lK/t/@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-ge v2, v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v2}, Lh4/a;->O(I)I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v4, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    if-eq v3, v4, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {p1, v2}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p1, v2}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-instance p1, Lcom/google/android/gms/common/internal/zzak;

    invoke-direct {p1, v1}, Lcom/google/android/gms/common/internal/zzak;-><init>(I)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    return-object p1
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    new-array p1, p1, [Lcom/google/android/gms/common/internal/zzak;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method
