.class public abstract Lcom/google/android/gms/common/internal/l1;
.super Lcom/google/android/gms/internal/common/zzb;

# interfaces
.implements Lcom/google/android/gms/common/internal/m1;


# direct methods
.method public static a(Landroid/os/IBinder;)Lcom/google/android/gms/common/internal/m1;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~stl-vty~ @fb o@f~@b~obo@@ o~~@ o  rln@a ~@ @4/~ i/@i@@o ius Md~~@~~@~ ~@~   m1~~~~@.~@KcS @@ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v0, ".gimgpCem.i.sec.r.itaAnrreninoemmdiatcmscaoollslIoGndooo.ofge"

    const-string/jumbo v0, "insadnegoif.lmtoolga.Ceoog.Gmeig.iArnomes.nctcrs.rocdpaIleiom"

    const/4 v3, 0x1

    const-string/jumbo v0, "iosnoaeceordnifm.o.locgmCiaentooglGcoIpsm.mlr.aArt.igedeoi.nt"

    const-string v0, "com.google.android.gms.common.internal.IGoogleCertificatesApi"

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    instance-of v1, v0, Lcom/google/android/gms/common/internal/m1;

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Lcom/google/android/gms/common/internal/m1;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/common/internal/k1;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/internal/k1;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0
.end method
