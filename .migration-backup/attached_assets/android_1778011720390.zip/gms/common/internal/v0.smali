.class public final Lcom/google/android/gms/common/internal/v0;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 19

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    invoke-static/range {p1 .. p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v1

    const/4 v2, -0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    move/from16 v18, v2

    move/from16 v18, v2

    move/from16 v18, v2

    move/from16 v18, v2

    move v8, v3

    move v8, v3

    move v8, v3

    move v8, v3

    move v9, v8

    move v9, v8

    move v9, v8

    move v10, v9

    move v10, v9

    move v10, v9

    move v10, v9

    move/from16 v17, v10

    move/from16 v17, v10

    move/from16 v17, v10

    move/from16 v17, v10

    move-object v15, v4

    move-object v15, v4

    move-object v15, v4

    move-object v15, v4

    move-object/from16 v16, v15

    move-object/from16 v16, v15

    move-object/from16 v16, v15

    move-wide v11, v5

    move-wide v13, v11

    :goto_0
    invoke-virtual/range {p1 .. p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v2

    if-ge v2, v1, :cond_0

    invoke-static/range {p1 .. p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v2

    invoke-static {v2}, Lh4/a;->O(I)I

    move-result v3

    packed-switch v3, :pswitch_data_0

    invoke-static {v0, v2}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    goto :goto_0

    :pswitch_0
    invoke-static {v0, v2}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    move/from16 v18, v2

    move/from16 v18, v2

    move/from16 v18, v2

    goto :goto_0

    :pswitch_1
    invoke-static {v0, v2}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    move/from16 v17, v2

    move/from16 v17, v2

    move/from16 v17, v2

    move/from16 v17, v2

    goto :goto_0

    :pswitch_2
    invoke-static {v0, v2}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v16, v2

    move-object/from16 v16, v2

    move-object/from16 v16, v2

    goto :goto_0

    :pswitch_3
    invoke-static {v0, v2}, Lh4/a;->G(Landroid/os/Parcel;I)Ljava/lang/String;

    move-result-object v2

    move-object v15, v2

    move-object v15, v2

    goto :goto_0

    :pswitch_4
    invoke-static {v0, v2}, Lh4/a;->c0(Landroid/os/Parcel;I)J

    move-result-wide v2

    move-wide v13, v2

    goto :goto_0

    :pswitch_5
    invoke-static {v0, v2}, Lh4/a;->c0(Landroid/os/Parcel;I)J

    move-result-wide v2

    move-wide v11, v2

    goto :goto_0

    :pswitch_6
    invoke-static {v0, v2}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    move v10, v2

    move v10, v2

    move v10, v2

    move v10, v2

    goto :goto_0

    :pswitch_7
    invoke-static {v0, v2}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    move v9, v2

    move v9, v2

    move v9, v2

    move v9, v2

    goto :goto_0

    :pswitch_8
    invoke-static {v0, v2}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    move v8, v2

    move v8, v2

    move v8, v2

    goto :goto_0

    :cond_0
    invoke-static {v0, v1}, Lh4/a;->N(Landroid/os/Parcel;I)V

    new-instance v0, Lcom/google/android/gms/common/internal/MethodInvocation;

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    invoke-direct/range {v7 .. v18}, Lcom/google/android/gms/common/internal/MethodInvocation;-><init>(IIIJJLjava/lang/String;Ljava/lang/String;II)V

    return-object v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ st@@y~ ~lo@v d@4o@ @ S~~ ~~M~ @/r@~~~im@f@. ~Kb@@~ ~~@b@ n@@ /o@~@~l otb o~ ~~1~@as ~foci@ u i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    new-array p1, p1, [Lcom/google/android/gms/common/internal/MethodInvocation;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method
