.class public Lcom/google/android/gms/common/internal/s;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field private static final b:Lcom/google/android/gms/common/internal/l;

.field private static final c:Lcom/google/android/gms/common/internal/s;


# instance fields
.field private final a:Ljava/util/concurrent/ConcurrentHashMap;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/common/internal/l;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string/jumbo v1, "rysVaeLiorirns"

    const-string/jumbo v1, "rLsniarseVroyi"

    const/4 v4, 0x7

    const-string/jumbo v1, "iVrmsenirybraL"

    const-string v1, "LibraryVersion"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/android/gms/common/internal/l;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    sput-object v0, Lcom/google/android/gms/common/internal/s;->b:Lcom/google/android/gms/common/internal/l;

    new-instance v0, Lcom/google/android/gms/common/internal/s;

    const/4 v4, 0x2

    invoke-direct {v0}, Lcom/google/android/gms/common/internal/s;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    sput-object v0, Lcom/google/android/gms/common/internal/s;->c:Lcom/google/android/gms/common/internal/s;

    const/4 v3, 0x0

    move v4, v3

    return-void
.end method

.method protected constructor <init>()V
    .locals 3
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/common/internal/s;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public static a()Lcom/google/android/gms/common/internal/s;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/common/internal/s;->c:Lcom/google/android/gms/common/internal/s;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public b(Ljava/lang/String;)Ljava/lang/String;
    .locals 10
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-string/jumbo v0, "oprmtaeml radseapt rNl:gnF oeoyeii fiv abr "

    const/4 v9, 0x3

    const-string v0, " rNFoeoepnrbey glmieo: rasaod  ptfl trv iia"

    const-string v0, "Failed to get app version for libraryName: "

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string/jumbo v1, "niViebbyLoarrs"

    const-string/jumbo v1, "iaLsoynierVrob"

    const/4 v9, 0x6

    const-string v1, "VynireurorLbsa"

    const-string v1, "LibraryVersion"

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string/jumbo v2, "lbaeevPp riebNlr  sed rplaiymovaai"

    const-string/jumbo v2, "oPl  baeeNsveeidbaar  lyvpdmraliir"

    const/4 v9, 0x1

    const-string/jumbo v2, "vaaal voqid Nd a Pleyrieirerspebma"

    const-string v2, "Please provide a valid libraryName"

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {p1, v2}, Lcom/google/android/gms/common/internal/v;->m(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v2, p0, Lcom/google/android/gms/common/internal/s;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v2, p1}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-eqz v2, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x0

    check-cast p1, Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    return-object p1

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    new-instance v2, Ljava/util/Properties;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {v2}, Ljava/util/Properties;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    const/4 v3, 0x0

    :try_start_0
    const/4 v9, 0x6

    const/4 v8, 0x6

    const-string/jumbo v4, "tsspir%u/osep."

    const-string v4, "eropisute/.s%p"

    const/4 v9, 0x3

    const-string/jumbo v4, "prsm.ts%roep/i"

    const-string v4, "/%s.properties"

    const/4 v9, 0x0

    const/4 v5, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    const/4 v6, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    aput-object p1, v5, v6

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-class v5, Lcom/google/android/gms/common/internal/s;

    const-class v5, Lcom/google/android/gms/common/internal/s;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v5, v4}, Ljava/lang/Class;->getResourceAsStream(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v4
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-eqz v4, :cond_1

    :try_start_1
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v2, v4}, Ljava/util/Properties;->load(Ljava/io/InputStream;)V

    const/4 v8, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string/jumbo v5, "vniporo"

    const-string/jumbo v5, "peiornv"

    const/4 v9, 0x1

    const-string v5, "esinrbv"

    const-string/jumbo v5, "version"

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v2, v5, v3}, Ljava/util/Properties;->getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    sget-object v2, Lcom/google/android/gms/common/internal/s;->b:Lcom/google/android/gms/common/internal/l;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string/jumbo v6, "nr sseuv q i"

    const-string v6, " ssrie  qvin"

    const/4 v9, 0x6

    const-string v6, "es i iopns v"

    const-string v6, " version is "

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v2, v1, v5}, Lcom/google/android/gms/common/internal/l;->l(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto/16 :goto_1

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    sget-object v2, Lcom/google/android/gms/common/internal/s;->b:Lcom/google/android/gms/common/internal/l;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    move v9, v8

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v2, v1, v5}, Lcom/google/android/gms/common/internal/l;->n(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_1

    :catchall_0
    move-exception p1

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    goto/16 :goto_2

    :catch_0
    move-exception v2

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v4, v3

    move-object v4, v3

    move-object v3, v7

    move-object v3, v7

    move-object v3, v7

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto :goto_0

    :catchall_1
    move-exception p1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    goto :goto_2

    :catch_1
    move-exception v2

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :goto_0
    :try_start_2
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    sget-object v5, Lcom/google/android/gms/common/internal/s;->b:Lcom/google/android/gms/common/internal/l;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x4

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v5, v1, v0, v2}, Lcom/google/android/gms/common/internal/l;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v3, v7

    move-object v3, v7

    :goto_1
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    if-eqz v4, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {v4}, Lcom/google/android/gms/common/util/q;->b(Ljava/io/Closeable;)V

    :cond_2
    const/4 v8, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-nez v3, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    sget-object v0, Lcom/google/android/gms/common/internal/s;->b:Lcom/google/android/gms/common/internal/l;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string v2, " eev oniq e .geareeonlsle lrtisa eeryeti r eplelesg sea-dober  cpoodrc unieerlssrauean wi sxtois.lddfrespher rlnooneaidtridGl i rtpiic sur pu biplFpt urpdaitsag "

    const-string/jumbo v2, "u soaa     drdrslGr lxptlleuiaioaegvrredlbpitrea er s etgl rtole elhiese usa obeisp-d niriecfrepst neolrenre.c peueela stisdrortn. ro dcipnoip ie yngespausiwdigF"

    const/4 v9, 0x7

    const-string/jumbo v2, "urse wrup aixendlsoi r oloet btifrceriedi gr  oor-iac poii pintsleneppoaled.stde t s snlao  ipieurh.e epgedevresr sial aabiadreneselelgysrcl rp n uFtrgs erGldeue"

    const-string v2, ".properties file is dropped during release process. Failure to read app version is expected during Google internal testing where locally-built libraries are used"

    const/4 v9, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/common/internal/l;->c(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const-string/jumbo v3, "mNWmKNU"

    const-string v3, "KONmNUW"

    const/4 v9, 0x4

    const-string v3, "ONNNoKW"

    const-string v3, "UNKNOWN"

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s;->a:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v0, p1, v3}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    return-object v3

    :goto_2
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v3, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {v3}, Lcom/google/android/gms/common/util/q;->b(Ljava/io/Closeable;)V

    :cond_4
    const/4 v8, 0x4

    const/4 v9, 0x0

    throw p1
.end method
