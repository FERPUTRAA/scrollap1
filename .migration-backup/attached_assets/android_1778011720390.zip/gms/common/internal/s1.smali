.class public abstract Lcom/google/android/gms/common/internal/s1;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/Object;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private b:Z

.field final synthetic c:Lcom/google/android/gms/common/internal/e;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/internal/e;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/internal/s1;->c:Lcom/google/android/gms/common/internal/e;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/android/gms/common/internal/s1;->a:Ljava/lang/Object;

    const/4 v0, 0x6

    xor-int/2addr v1, v0

    const/4 p1, 0x0

    move v1, p1

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/gms/common/internal/s1;->b:Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected abstract a(Ljava/lang/Object;)V
.end method

.method protected abstract b()V
.end method

.method public final c()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@ s4im@~@@fi/yf@ i@M~v~bta@.~@/~~~@~  ~~ oo 1@~ ~~ o~ @~l  o~  n@~~u@-@@~@obo@@l~ ~c~b tr S@ @ds"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s1;->a:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-boolean v1, p0, Lcom/google/android/gms/common/internal/s1;->b:Z

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x0

    const-string/jumbo v1, "tCsmmleiG"

    const-string/jumbo v1, "lCssetmiG"

    const/4 v6, 0x0

    const-string v1, "GsitoCnml"

    const-string v1, "GmsClient"

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string/jumbo v4, "lbxmyaCokr lac "

    const/4 v6, 0x0

    const-string v4, "alkyxb caorlb p"

    const-string v4, "Callback proxy "

    const/4 v5, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v2, "erg   us i o. nuesibneishfTe.ato"

    const-string v2, " iinos  .eeu sifno tseahsbT.rge "

    const/4 v6, 0x6

    const-string/jumbo v2, "sT.i.gnps dunaoistbie   eeehr  s"

    const-string v2, " being reused. This is not safe."

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    or-int/2addr v6, v5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/internal/s1;->a(Ljava/lang/Object;)V

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    monitor-enter p0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v0, 0x7

    const/4 v0, 0x1

    :try_start_1
    const/4 v6, 0x6

    const/4 v5, 0x0

    iput-boolean v0, p0, Lcom/google/android/gms/common/internal/s1;->b:Z

    const/4 v6, 0x6

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/s1;->e()V

    const/4 v6, 0x4

    return-void

    :catchall_0
    move-exception v0

    :try_start_2
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    throw v0

    :catchall_1
    move-exception v0

    :try_start_3
    const/4 v6, 0x2

    const/4 v5, 0x1

    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    throw v0
.end method

.method public final d()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    monitor-enter p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/common/internal/s1;->a:Ljava/lang/Object;

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    throw v0
.end method

.method public final e()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/s1;->d()V

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s1;->c:Lcom/google/android/gms/common/internal/e;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/e;->zzf(Lcom/google/android/gms/common/internal/e;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s1;->c:Lcom/google/android/gms/common/internal/e;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/internal/e;->zzf(Lcom/google/android/gms/common/internal/e;)Ljava/util/ArrayList;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void

    :catchall_0
    move-exception v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw v1
.end method
