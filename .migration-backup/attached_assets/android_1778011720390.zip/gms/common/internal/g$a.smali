.class public final Lcom/google/android/gms/common/internal/g$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/internal/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field private a:Landroid/accounts/Account;
    .annotation runtime Lv7/h;
    .end annotation
.end field

.field private b:Landroidx/collection/c;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private final e:Lcom/google/android/gms/signin/a;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/signin/a;->j:Lcom/google/android/gms/signin/a;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/internal/g$a;->e:Lcom/google/android/gms/signin/a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public a()Lcom/google/android/gms/common/internal/g;
    .locals 13
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    new-instance v10, Lcom/google/android/gms/common/internal/g;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/internal/g$a;->a:Landroid/accounts/Account;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/internal/g$a;->b:Landroidx/collection/c;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    const/4 v3, 0x0

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    const/4 v4, 0x0

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x7

    iget-object v6, p0, Lcom/google/android/gms/common/internal/g$a;->c:Ljava/lang/String;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x1

    iget-object v7, p0, Lcom/google/android/gms/common/internal/g$a;->d:Ljava/lang/String;

    const/4 v11, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x1

    iget-object v8, p0, Lcom/google/android/gms/common/internal/g$a;->e:Lcom/google/android/gms/signin/a;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x6

    const/4 v9, 0x0

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-direct/range {v0 .. v9}, Lcom/google/android/gms/common/internal/g;-><init>(Landroid/accounts/Account;Ljava/util/Set;Ljava/util/Map;ILandroid/view/View;Ljava/lang/String;Ljava/lang/String;Lcom/google/android/gms/signin/a;Z)V

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x2

    return-object v10
.end method

.method public b(Ljava/lang/String;)Lcom/google/android/gms/common/internal/g$a;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/internal/g$a;->c:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method public final c(Ljava/util/Collection;)Lcom/google/android/gms/common/internal/g$a;
    .locals 3
    .param p1    # Ljava/util/Collection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g$a;->b:Landroidx/collection/c;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x5

    new-instance v0, Landroidx/collection/c;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0}, Landroidx/collection/c;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/internal/g$a;->b:Landroidx/collection/c;

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g$a;->b:Landroidx/collection/c;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroidx/collection/c;->addAll(Ljava/util/Collection;)Z

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public final d(Landroid/accounts/Account;)Lcom/google/android/gms/common/internal/g$a;
    .locals 2
    .param p1    # Landroid/accounts/Account;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/internal/g$a;->a:Landroid/accounts/Account;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method public final e(Ljava/lang/String;)Lcom/google/android/gms/common/internal/g$a;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/internal/g$a;->d:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x1

    return-object p0
.end method
