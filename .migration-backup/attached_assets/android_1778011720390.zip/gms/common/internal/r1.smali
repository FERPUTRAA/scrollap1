.class final Lcom/google/android/gms/common/internal/r1;
.super Lcom/google/android/gms/internal/common/zzi;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/internal/e;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/internal/e;Landroid/os/Looper;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v0, 0x0

    or-int/2addr v1, v0

    invoke-direct {p0, p2}, Lcom/google/android/gms/internal/common/zzi;-><init>(Landroid/os/Looper;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method private static final a(Landroid/os/Message;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ms l.~~ ~bo@i~o bc @ @ i~od@S~~~ @@ ~@bu@@M oK~i@@-@~o @tr~@n~~~@f~f@/ @  l/ ~@ao4 @~ ~1~yt ~v~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p0, p0, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v0, 0x7

    move v1, v0

    check-cast p0, Lcom/google/android/gms/common/internal/s1;

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/s1;->b()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/s1;->e()V

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method

.method private static final b(Landroid/os/Message;)Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget p0, p0, Landroid/os/Message;->what:I

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x3

    move v2, v0

    move v2, v0

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x6

    move v2, v1

    move v2, v1

    const/4 v3, 0x7

    if-eq p0, v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eq p0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x7

    if-ne p0, v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    return p0

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    return v1
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x1

    const/4 v7, 0x0

    iget-object v0, v0, Lcom/google/android/gms/common/internal/e;->zzd:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v7, 0x6

    shr-int/2addr v8, v7

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget v1, p1, Landroid/os/Message;->arg1:I

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eq v0, v1, :cond_1

    const/4 v8, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/internal/r1;->b(Landroid/os/Message;)Z

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-eqz v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/r1;->a(Landroid/os/Message;)V

    :cond_0
    const/4 v7, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    return-void

    :cond_1
    const/4 v7, 0x1

    move v8, v7

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v1, 0x4

    const/4 v8, 0x7

    const/4 v2, 0x1

    const/4 v8, 0x0

    shr-int/2addr v7, v2

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v8, 0x2

    const/4 v3, 0x5

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eq v0, v2, :cond_3

    const/4 v7, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v4, 0x7

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eq v0, v4, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-ne v0, v1, :cond_2

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/e;->enableLocalFallback()Z

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-eqz v0, :cond_3

    :cond_2
    const/4 v8, 0x4

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-ne v0, v3, :cond_4

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/e;->isConnecting()Z

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-eqz v0, :cond_12

    :cond_4
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/16 v4, 0x8

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v5, 0x7

    const/4 v5, 0x3

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-ne v0, v1, :cond_8

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget p1, p1, Landroid/os/Message;->arg2:I

    const/4 v8, 0x2

    invoke-direct {v1, p1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(I)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/e;->zzg(Lcom/google/android/gms/common/internal/e;Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/e;->zzo(Lcom/google/android/gms/common/internal/e;)Z

    move-result p1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    if-eqz p1, :cond_6

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/internal/e;->zzm(Lcom/google/android/gms/common/internal/e;)Z

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-eqz v0, :cond_5

    const/4 v8, 0x0

    goto :goto_0

    :cond_5
    const/4 v8, 0x3

    invoke-static {p1, v5, v6}, Lcom/google/android/gms/common/internal/e;->zzi(Lcom/google/android/gms/common/internal/e;ILandroid/os/IInterface;)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-void

    :cond_6
    :goto_0
    const/4 v8, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/e;->zza(Lcom/google/android/gms/common/internal/e;)Lcom/google/android/gms/common/ConnectionResult;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-eqz v0, :cond_7

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/e;->zza(Lcom/google/android/gms/common/internal/e;)Lcom/google/android/gms/common/ConnectionResult;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    goto :goto_1

    :cond_7
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    new-instance p1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {p1, v4}, Lcom/google/android/gms/common/ConnectionResult;-><init>(I)V

    :goto_1
    const/4 v8, 0x4

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object v0, v0, Lcom/google/android/gms/common/internal/e;->zzc:Lcom/google/android/gms/common/internal/e$c;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/internal/e$c;->a(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/e;->onConnectionFailed(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v7, 0x5

    const/4 v8, 0x2

    return-void

    :cond_8
    const/4 v7, 0x7

    move v8, v7

    if-ne v0, v3, :cond_a

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/internal/e;->zza(Lcom/google/android/gms/common/internal/e;)Lcom/google/android/gms/common/ConnectionResult;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v0, :cond_9

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/internal/e;->zza(Lcom/google/android/gms/common/internal/e;)Lcom/google/android/gms/common/ConnectionResult;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    goto :goto_2

    :cond_9
    const/4 v7, 0x5

    move v8, v7

    new-instance p1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v8, 0x3

    const/4 v7, 0x4

    invoke-direct {p1, v4}, Lcom/google/android/gms/common/ConnectionResult;-><init>(I)V

    :goto_2
    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v0, v0, Lcom/google/android/gms/common/internal/e;->zzc:Lcom/google/android/gms/common/internal/e$c;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/internal/e$c;->a(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/e;->onConnectionFailed(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    return-void

    :cond_a
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-ne v0, v5, :cond_c

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    instance-of v1, v0, Landroid/app/PendingIntent;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v1, :cond_b

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    check-cast v6, Landroid/app/PendingIntent;

    :cond_b
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    new-instance v0, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v8, 0x0

    iget p1, p1, Landroid/os/Message;->arg2:I

    const/4 v7, 0x0

    move v8, v7

    invoke-direct {v0, p1, v6}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v7, 0x5

    xor-int/2addr v8, v7

    iget-object p1, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object p1, p1, Lcom/google/android/gms/common/internal/e;->zzc:Lcom/google/android/gms/common/internal/e$c;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-interface {p1, v0}, Lcom/google/android/gms/common/internal/e$c;->a(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/internal/e;->onConnectionFailed(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v8, 0x5

    return-void

    :cond_c
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v1, 0x6

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-ne v0, v1, :cond_e

    const/4 v8, 0x6

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {v0, v3, v6}, Lcom/google/android/gms/common/internal/e;->zzi(Lcom/google/android/gms/common/internal/e;ILandroid/os/IInterface;)V

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/e;->zzb(Lcom/google/android/gms/common/internal/e;)Lcom/google/android/gms/common/internal/e$a;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-eqz v1, :cond_d

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/e;->zzb(Lcom/google/android/gms/common/internal/e;)Lcom/google/android/gms/common/internal/e$a;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget v1, p1, Landroid/os/Message;->arg2:I

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-interface {v0, v1}, Lcom/google/android/gms/common/internal/e$a;->b(I)V

    :cond_d
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget p1, p1, Landroid/os/Message;->arg2:I

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/e;->onConnectionSuspended(I)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {p1, v3, v2, v6}, Lcom/google/android/gms/common/internal/e;->zzn(Lcom/google/android/gms/common/internal/e;IILandroid/os/IInterface;)Z

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    return-void

    :cond_e
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v1, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-ne v0, v1, :cond_10

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/internal/r1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/e;->isConnected()Z

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eqz v0, :cond_f

    const/4 v8, 0x5

    goto :goto_3

    :cond_f
    const/4 v7, 0x2

    move v8, v7

    invoke-static {p1}, Lcom/google/android/gms/common/internal/r1;->a(Landroid/os/Message;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    return-void

    :cond_10
    :goto_3
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/internal/r1;->b(Landroid/os/Message;)Z

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eqz v0, :cond_11

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    check-cast p1, Lcom/google/android/gms/common/internal/s1;

    const/4 v8, 0x0

    const/4 v7, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/s1;->c()V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    return-void

    :cond_11
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget p1, p1, Landroid/os/Message;->what:I

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const-string v1, "a lmsshee:tDoktg  /nnoadowsn wo m/e"

    const-string/jumbo v1, "ets nwesso wo o:hnn meda golkahD//t"

    const/4 v8, 0x3

    const-string v1, "eo mowtelnnehDastg hno/ /okdoaw  s "

    const-string v1, "Don\'t know how to handle message: "

    const/4 v7, 0x4

    xor-int/2addr v8, v7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-instance v0, Ljava/lang/Exception;

    const/4 v8, 0x0

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    const/4 v8, 0x7

    const-string/jumbo v1, "tlnGebsmi"

    const-string/jumbo v1, "ilGmnetsm"

    const/4 v8, 0x0

    const-string/jumbo v1, "nGCsmtuli"

    const-string v1, "GmsClient"

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {v1, p1, v0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    return-void

    :cond_12
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/internal/r1;->a(Landroid/os/Message;)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    return-void
.end method
