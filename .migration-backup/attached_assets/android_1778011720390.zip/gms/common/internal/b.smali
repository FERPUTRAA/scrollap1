.class public final Lcom/google/android/gms/common/internal/b;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "com.google"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final b:[Ljava/lang/String;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v3, 0x1

    move v4, v3

    const-string v0, ".osomsgko.celwg"

    const-string/jumbo v0, "omsw.oogegk.lco"

    const/4 v4, 0x3

    const-string/jumbo v0, "kr.m.wlegcogmoo"

    const-string v0, "com.google.work"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v1, "egomngo.l"

    const/4 v4, 0x4

    const-string v1, "c.noooelg"

    const-string v1, "cn.google"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo v2, "mg.oobcoel"

    const-string/jumbo v2, "ocogolo.me"

    const/4 v4, 0x1

    const-string v2, ".logoeugco"

    const-string v2, "com.google"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    sput-object v0, Lcom/google/android/gms/common/internal/b;->b:[Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method
