.class final Lcom/google/android/gms/common/internal/f2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;
.implements Lcom/google/android/gms/common/internal/j2;


# instance fields
.field private final a:Ljava/util/Map;

.field private b:I

.field private c:Z

.field private f:Landroid/os/IBinder;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final g:Lcom/google/android/gms/common/internal/d2;

.field private h:Landroid/content/ComponentName;

.field final synthetic i:Lcom/google/android/gms/common/internal/i2;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/internal/i2;Lcom/google/android/gms/common/internal/d2;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/android/gms/common/internal/f2;->g:Lcom/google/android/gms/common/internal/d2;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    new-instance p1, Ljava/util/HashMap;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/internal/f2;->a:Ljava/util/Map;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    const/4 p1, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/gms/common/internal/f2;->b:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " fs~@S@ -@@moo ~o@u@@~@ @o@ly~~ c~  @M.b@~1/~/~@r~ ~b 4@@ ~o~ t@~@@o ~ib ldv~i@~  t~iK~@s~ f ~a~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/gms/common/internal/f2;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    return v0
.end method

.method public final b()Landroid/content/ComponentName;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/internal/f2;->h:Landroid/content/ComponentName;

    const/4 v1, 0x1

    move v2, v1

    return-object v0
.end method

.method public final c()Landroid/os/IBinder;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/f2;->f:Landroid/os/IBinder;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public final d(Landroid/content/ServiceConnection;Landroid/content/ServiceConnection;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    iget-object p3, p0, Lcom/google/android/gms/common/internal/f2;->a:Ljava/util/Map;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-interface {p3, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public final e(Ljava/lang/String;Ljava/util/concurrent/Executor;)V
    .locals 11
    .param p2    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v0, 0x3

    move v10, v0

    iput v0, p0, Lcom/google/android/gms/common/internal/f2;->b:I

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {}, Landroid/os/StrictMode;->getVmPolicy()Landroid/os/StrictMode$VmPolicy;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {}, Lcom/google/android/gms/common/util/v;->r()Z

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz v1, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    new-instance v1, Landroid/os/StrictMode$VmPolicy$Builder;

    const/4 v10, 0x2

    const/4 v9, 0x4

    invoke-direct {v1, v0}, Landroid/os/StrictMode$VmPolicy$Builder;-><init>(Landroid/os/StrictMode$VmPolicy;)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-static {v1}, Lcom/google/android/gms/common/internal/e2;->a(Landroid/os/StrictMode$VmPolicy$Builder;)Landroid/os/StrictMode$VmPolicy$Builder;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v1}, Landroid/os/StrictMode$VmPolicy$Builder;->build()Landroid/os/StrictMode$VmPolicy;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-static {v1}, Landroid/os/StrictMode;->setVmPolicy(Landroid/os/StrictMode$VmPolicy;)V

    :cond_0
    :try_start_0
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-static {v1}, Lcom/google/android/gms/common/internal/i2;->r(Lcom/google/android/gms/common/internal/i2;)Lcom/google/android/gms/common/stats/b;

    move-result-object v2

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/internal/i2;->p(Lcom/google/android/gms/common/internal/i2;)Landroid/content/Context;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-object v4, p0, Lcom/google/android/gms/common/internal/f2;->g:Lcom/google/android/gms/common/internal/d2;

    const/4 v10, 0x5

    invoke-static {v1}, Lcom/google/android/gms/common/internal/i2;->p(Lcom/google/android/gms/common/internal/i2;)Landroid/content/Context;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v4, v1}, Lcom/google/android/gms/common/internal/d2;->b(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v5

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/16 v7, 0x1081

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v8, p2

    move-object v8, p2

    move-object v8, p2

    move-object v8, p2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual/range {v2 .. v8}, Lcom/google/android/gms/common/stats/b;->e(Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;Landroid/content/ServiceConnection;ILjava/util/concurrent/Executor;)Z

    move-result p1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    iput-boolean p1, p0, Lcom/google/android/gms/common/internal/f2;->c:Z

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-eqz p1, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v10, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/internal/i2;->q(Lcom/google/android/gms/common/internal/i2;)Landroid/os/Handler;

    move-result-object p1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget-object p2, p0, Lcom/google/android/gms/common/internal/f2;->g:Lcom/google/android/gms/common/internal/d2;

    const/4 v9, 0x5

    shr-int/2addr v10, v9

    const/4 v1, 0x1

    const/4 v9, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p1, v1, p2}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget-object p2, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {p2}, Lcom/google/android/gms/common/internal/i2;->q(Lcom/google/android/gms/common/internal/i2;)Landroid/os/Handler;

    move-result-object p2

    const/4 v10, 0x2

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/internal/i2;->o(Lcom/google/android/gms/common/internal/i2;)J

    move-result-wide v1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p2, p1, v1, v2}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    goto :goto_0

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    const/4 p1, 0x2

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    iput p1, p0, Lcom/google/android/gms/common/internal/f2;->b:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/internal/i2;->r(Lcom/google/android/gms/common/internal/i2;)Lcom/google/android/gms/common/stats/b;

    move-result-object p2

    const/4 v10, 0x5

    const/4 v9, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/i2;->p(Lcom/google/android/gms/common/internal/i2;)Landroid/content/Context;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p2, p1, p0}, Lcom/google/android/gms/common/stats/b;->c(Landroid/content/Context;Landroid/content/ServiceConnection;)V
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {v0}, Landroid/os/StrictMode;->setVmPolicy(Landroid/os/StrictMode$VmPolicy;)V

    const/4 v9, 0x5

    move v10, v9

    return-void

    :catchall_0
    move-exception p1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-static {v0}, Landroid/os/StrictMode;->setVmPolicy(Landroid/os/StrictMode$VmPolicy;)V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    throw p1
.end method

.method public final f(Landroid/content/ServiceConnection;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    iget-object p2, p0, Lcom/google/android/gms/common/internal/f2;->a:Ljava/util/Map;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-interface {p2, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public final g(Ljava/lang/String;)V
    .locals 4

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/internal/f2;->g:Lcom/google/android/gms/common/internal/d2;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/i2;->q(Lcom/google/android/gms/common/internal/i2;)Landroid/os/Handler;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/internal/i2;->r(Lcom/google/android/gms/common/internal/i2;)Lcom/google/android/gms/common/stats/b;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/internal/i2;->p(Lcom/google/android/gms/common/internal/i2;)Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, p1, p0}, Lcom/google/android/gms/common/stats/b;->c(Landroid/content/Context;Landroid/content/ServiceConnection;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-boolean p1, p0, Lcom/google/android/gms/common/internal/f2;->c:Z

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput p1, p0, Lcom/google/android/gms/common/internal/f2;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method public final h(Landroid/content/ServiceConnection;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/f2;->a:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1
.end method

.method public final i()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/internal/f2;->a:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public final j()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/gms/common/internal/f2;->c:Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public final onBindingDied(Landroid/content/ComponentName;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/internal/f2;->onServiceDisconnected(Landroid/content/ComponentName;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/i2;->s(Lcom/google/android/gms/common/internal/i2;)Ljava/util/HashMap;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v1}, Lcom/google/android/gms/common/internal/i2;->q(Lcom/google/android/gms/common/internal/i2;)Landroid/os/Handler;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/google/android/gms/common/internal/f2;->g:Lcom/google/android/gms/common/internal/d2;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v1, v3, v2}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput-object p2, p0, Lcom/google/android/gms/common/internal/f2;->f:Landroid/os/IBinder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/internal/f2;->h:Landroid/content/ComponentName;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/internal/f2;->a:Ljava/util/Map;

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    check-cast v2, Landroid/content/ServiceConnection;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v2, p1, p2}, Landroid/content/ServiceConnection;->onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    iput v3, p0, Lcom/google/android/gms/common/internal/f2;->b:I

    const/4 v4, 0x5

    move v5, v4

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    throw p1
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v4, 0x5

    move v5, v4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/i2;->s(Lcom/google/android/gms/common/internal/i2;)Ljava/util/HashMap;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/internal/f2;->i:Lcom/google/android/gms/common/internal/i2;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/google/android/gms/common/internal/i2;->q(Lcom/google/android/gms/common/internal/i2;)Landroid/os/Handler;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/android/gms/common/internal/f2;->g:Lcom/google/android/gms/common/internal/d2;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v3, 0x1

    shr-int/2addr v5, v3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v1, v3, v2}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput-object v1, p0, Lcom/google/android/gms/common/internal/f2;->f:Landroid/os/IBinder;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/internal/f2;->h:Landroid/content/ComponentName;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/internal/f2;->a:Ljava/util/Map;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    check-cast v2, Landroid/content/ServiceConnection;

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-interface {v2, p1}, Landroid/content/ServiceConnection;->onServiceDisconnected(Landroid/content/ComponentName;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    move v5, v4

    const/4 p1, 0x7

    const/4 p1, 0x2

    const/4 v5, 0x3

    iput p1, p0, Lcom/google/android/gms/common/internal/f2;->b:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    throw p1
.end method
