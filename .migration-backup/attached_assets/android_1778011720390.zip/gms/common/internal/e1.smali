.class public final Lcom/google/android/gms/common/internal/e1;
.super Lcom/google/android/gms/dynamic/h;


# static fields
.field private static final c:Lcom/google/android/gms/common/internal/e1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance v0, Lcom/google/android/gms/common/internal/e1;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/google/android/gms/common/internal/e1;-><init>()V

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput-object v0, Lcom/google/android/gms/common/internal/e1;->c:Lcom/google/android/gms/common/internal/e1;

    const/4 v2, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const-string/jumbo v0, "misanC.detegtosnuIa.iBgr.umSsomogl.nrn.ptmIcromno.dologi"

    const-string v0, "IisctmsInoggomCi.rBumdoeug.mnoe..mrtSralnl.oignnadptoo.c"

    const/4 v2, 0x1

    const-string/jumbo v0, "ndnmouoi.orl.eimnitSo.ngItapmlroaoBo.rtoIcmgCu..emsmggnd"

    const-string v0, "com.google.android.gms.common.ui.SignInButtonCreatorImpl"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/gms/dynamic/h;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public static c(Landroid/content/Context;II)Landroid/view/View;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/dynamic/h$a;
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ b o  ~~~ m ~/ob@~ @ol@M~/@ @a~~@~~f.K4 @f@t@lyto~ -~r o@@v@n~~ ~@c@~ ~~iuisidS1~~@@ b~@ o@ ~o "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    sget-object v0, Lcom/google/android/gms/common/internal/e1;->c:Lcom/google/android/gms/common/internal/e1;

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v1, Lcom/google/android/gms/common/internal/zax;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x3

    invoke-direct {v1, v2, p1, p2, v3}, Lcom/google/android/gms/common/internal/zax;-><init>(III[Lcom/google/android/gms/common/api/Scope;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/google/android/gms/dynamic/f;->c(Ljava/lang/Object;)Lcom/google/android/gms/dynamic/d;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, p0}, Lcom/google/android/gms/dynamic/h;->b(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast p0, Lcom/google/android/gms/common/internal/u0;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0, v2, v1}, Lcom/google/android/gms/common/internal/u0;->a(Lcom/google/android/gms/dynamic/d;Lcom/google/android/gms/common/internal/zax;)Lcom/google/android/gms/dynamic/d;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/google/android/gms/dynamic/f;->b(Lcom/google/android/gms/dynamic/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast p0, Landroid/view/View;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-object p0

    :catch_0
    move-exception p0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance v0, Lcom/google/android/gms/dynamic/h$a;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const-string/jumbo v2, "g ud beotsttoinmwzobh l untit C"

    const-string/jumbo v2, "zt msntedtitou    ehtnoCulobiwg"

    const-string/jumbo v2, "zt i uutsul nCbigotho od wentte"

    const-string v2, "Could not get button with size "

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo p1, "oan odrc lo"

    const/4 v5, 0x5

    const-string p1, " d carnpol "

    const-string p1, " and color "

    const/4 v5, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v0, p1, p0}, Lcom/google/android/gms/dynamic/h$a;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    throw v0
.end method


# virtual methods
.method public final synthetic a(Landroid/os/IBinder;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v0, "gtmCosSrqdrntoerrm.noaBoogniItgeinbc.net..gdinc.oauoalom.ln"

    const-string/jumbo v0, "odo.abmntrrooncgegC.gmortIncimo.SBtauo...glneorndieanltnism"

    const/4 v3, 0x0

    const-string v0, "com.google.android.gms.common.internal.ISignInButtonCreator"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    instance-of v1, v0, Lcom/google/android/gms/common/internal/u0;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast p1, Lcom/google/android/gms/common/internal/u0;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/internal/u0;

    const/4 v3, 0x4

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/internal/u0;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object p1
.end method
