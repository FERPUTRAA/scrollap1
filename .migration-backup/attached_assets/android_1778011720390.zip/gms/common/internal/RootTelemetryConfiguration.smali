.class public Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "RootTelemetryConfigurationCreator"
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field


# instance fields
.field private final a:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getVersion"
        id = 0x1
    .end annotation
.end field

.field private final b:Z
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getMethodInvocationTelemetryEnabled"
        id = 0x2
    .end annotation
.end field

.field private final c:Z
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getMethodTimingTelemetryEnabled"
        id = 0x3
    .end annotation
.end field

.field private final d:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getBatchPeriodMillis"
        id = 0x4
    .end annotation
.end field

.field private final e:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getMaxMethodInvocationsInBatch"
        id = 0x5
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/gms/common/internal/p1;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/common/internal/p1;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    sput-object v0, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    return-void
.end method

.method public constructor <init>(IZZII)V
    .locals 2
    .param p1    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # Z
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .param p3    # Z
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3
        .end annotation
    .end param
    .param p4    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x4
        .end annotation
    .end param
    .param p5    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x5
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->a:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-boolean p2, p0, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->b:Z

    const/4 v0, 0x5

    move v1, v0

    iput-boolean p3, p0, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->c:Z

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput p4, p0, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->d:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p5, p0, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->e:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public A2()Z
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " nsv@l@ot@@ ~@~  ~~@~~@l~ S/~m~K@~@o   d@biy~~o @t~~~~oosb@@ b ~/u  ~i@f~@a@~r4-io M.f1@ c@ @~~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->b:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public B2()Z
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->c:Z

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public getVersion()I
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->a:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 4
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->getVersion()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p1, v0, v1}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x2

    or-int/2addr v3, v0

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->A2()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p1, v0, v1}, Lh4/b;->g(Landroid/os/Parcel;IZ)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->B2()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p1, v0, v1}, Lh4/b;->g(Landroid/os/Parcel;IZ)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->y2()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1, v0, v1}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x5

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->z2()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p1, v0, v1}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1, p2}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method public y2()I
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->d:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    return v0
.end method

.method public z2()I
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    iget v0, p0, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->e:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method
