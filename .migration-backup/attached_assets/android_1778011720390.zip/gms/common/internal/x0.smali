.class final Lcom/google/android/gms/common/internal/x0;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/p$a;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/api/p;

.field final synthetic b:Lcom/google/android/gms/tasks/TaskCompletionSource;

.field final synthetic c:Lcom/google/android/gms/common/internal/u$a;

.field final synthetic d:Lcom/google/android/gms/common/internal/a1;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/p;Lcom/google/android/gms/tasks/TaskCompletionSource;Lcom/google/android/gms/common/internal/u$a;Lcom/google/android/gms/common/internal/a1;)V
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/internal/x0;->a:Lcom/google/android/gms/common/api/p;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/android/gms/common/internal/x0;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p3, p0, Lcom/google/android/gms/common/internal/x0;->c:Lcom/google/android/gms/common/internal/u$a;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p4, p0, Lcom/google/android/gms/common/internal/x0;->d:Lcom/google/android/gms/common/internal/a1;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/common/api/Status;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  s@@Kdb@o i~t@~b~~ @f1Mn~~s@@ @ y~o@i~v -~ ~ ~l ~4~io@ l@tb~ @~~oS ~ ~@m/o ofca@ur ~~~ @@@~/@.@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/Status;->E2()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/internal/x0;->a:Lcom/google/android/gms/common/api/p;

    const/4 v4, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, v0, v1, v2}, Lcom/google/android/gms/common/api/p;->await(JLjava/util/concurrent/TimeUnit;)Lcom/google/android/gms/common/api/v;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/x0;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/internal/x0;->c:Lcom/google/android/gms/common/internal/u$a;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {v1, p1}, Lcom/google/android/gms/common/internal/u$a;->a(Lcom/google/android/gms/common/api/v;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setResult(Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/x0;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/internal/c;->a(Lcom/google/android/gms/common/api/Status;)Lcom/google/android/gms/common/api/b;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setException(Ljava/lang/Exception;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void
.end method
