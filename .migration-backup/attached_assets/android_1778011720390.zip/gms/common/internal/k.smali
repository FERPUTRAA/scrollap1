.class public abstract Lcom/google/android/gms/common/internal/k;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static final a:Ljava/lang/Object;

.field private static b:Lcom/google/android/gms/common/internal/i2;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field static c:Landroid/os/HandlerThread;
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static d:Ljava/util/concurrent/Executor;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static e:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/Object;

    const/4 v1, 0x5

    move v2, v1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    move v2, v1

    sput-object v0, Lcom/google/android/gms/common/internal/k;->a:Ljava/lang/Object;

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public static d()I
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "y~s i. @~~@ /~l~bd~ o~ib ~oon-m  ~t @@@@@v~ @@ @4~auM~~~ ~~Ssbfcto o~ @l/f~@ ~@@r@K@ @ @o~ @~i~1"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const/16 v0, 0x1081

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public static e(Landroid/content/Context;)Lcom/google/android/gms/common/internal/k;
    .locals 6
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget-object v0, Lcom/google/android/gms/common/internal/k;->a:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget-object v1, Lcom/google/android/gms/common/internal/k;->b:Lcom/google/android/gms/common/internal/i2;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v1, Lcom/google/android/gms/common/internal/i2;

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    sget-boolean v3, Lcom/google/android/gms/common/internal/k;->e:Z

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {}, Lcom/google/android/gms/common/internal/k;->f()Landroid/os/HandlerThread;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getMainLooper()Landroid/os/Looper;

    move-result-object p0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    sget-object v3, Lcom/google/android/gms/common/internal/k;->d:Ljava/util/concurrent/Executor;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v1, v2, p0, v3}, Lcom/google/android/gms/common/internal/i2;-><init>(Landroid/content/Context;Landroid/os/Looper;Ljava/util/concurrent/Executor;)V

    const/4 v5, 0x1

    sput-object v1, Lcom/google/android/gms/common/internal/k;->b:Lcom/google/android/gms/common/internal/i2;

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    sget-object p0, Lcom/google/android/gms/common/internal/k;->b:Lcom/google/android/gms/common/internal/i2;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    throw p0
.end method

.method public static f()Landroid/os/HandlerThread;
    .locals 6
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget-object v0, Lcom/google/android/gms/common/internal/k;->a:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    sget-object v1, Lcom/google/android/gms/common/internal/k;->c:Landroid/os/HandlerThread;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object v1

    :cond_0
    const/4 v4, 0x3

    move v5, v4

    new-instance v1, Landroid/os/HandlerThread;

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v2, "HAdmllGesgpeioon"

    const-string v2, "aosoellgHGndipeA"

    const/4 v5, 0x3

    const-string v2, "enGHoeloiplgorAa"

    const-string v2, "GoogleApiHandler"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/16 v3, 0x9

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v1, v2, v3}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    sput-object v1, Lcom/google/android/gms/common/internal/k;->c:Landroid/os/HandlerThread;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    sget-object v1, Lcom/google/android/gms/common/internal/k;->c:Landroid/os/HandlerThread;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x0

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    throw v1
.end method

.method public static g(I)Landroid/os/HandlerThread;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    sget-object v0, Lcom/google/android/gms/common/internal/k;->a:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    sget-object v1, Lcom/google/android/gms/common/internal/k;->c:Landroid/os/HandlerThread;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object v1

    :cond_0
    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v1, Landroid/os/HandlerThread;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v2, "nilGpbHgAeoamder"

    const-string/jumbo v2, "lAlmperneodaHgiG"

    const/4 v4, 0x3

    const-string/jumbo v2, "peielaurloodngAG"

    const-string v2, "GoogleApiHandler"

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-direct {v1, v2, p0}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    sput-object v1, Lcom/google/android/gms/common/internal/k;->c:Landroid/os/HandlerThread;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    sget-object p0, Lcom/google/android/gms/common/internal/k;->c:Landroid/os/HandlerThread;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    throw p0
.end method

.method public static h(Ljava/util/concurrent/Executor;)V
    .locals 4
    .param p0    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lcom/google/android/gms/common/internal/k;->a:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v1, Lcom/google/android/gms/common/internal/k;->b:Lcom/google/android/gms/common/internal/i2;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    invoke-virtual {v1, p0}, Lcom/google/android/gms/common/internal/i2;->t(Ljava/util/concurrent/Executor;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    sput-object p0, Lcom/google/android/gms/common/internal/k;->d:Ljava/util/concurrent/Executor;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    throw p0
.end method

.method public static i()V
    .locals 5
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget-object v0, Lcom/google/android/gms/common/internal/k;->a:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x5

    sget-object v1, Lcom/google/android/gms/common/internal/k;->b:Lcom/google/android/gms/common/internal/i2;

    const/4 v4, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    move v4, v3

    sget-boolean v2, Lcom/google/android/gms/common/internal/k;->e:Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-nez v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/android/gms/common/internal/k;->f()Landroid/os/HandlerThread;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v2}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Lcom/google/android/gms/common/internal/i2;->u(Landroid/os/Looper;)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    sput-boolean v1, Lcom/google/android/gms/common/internal/k;->e:Z

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    throw v1
.end method


# virtual methods
.method public a(Landroid/content/ComponentName;Landroid/content/ServiceConnection;Ljava/lang/String;)Z
    .locals 4
    .param p1    # Landroid/content/ComponentName;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/ServiceConnection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/common/internal/d2;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/16 v1, 0x1081

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0, p1, v1}, Lcom/google/android/gms/common/internal/d2;-><init>(Landroid/content/ComponentName;I)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v0, p2, p3, p1}, Lcom/google/android/gms/common/internal/k;->n(Lcom/google/android/gms/common/internal/d2;Landroid/content/ServiceConnection;Ljava/lang/String;Ljava/util/concurrent/Executor;)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p1
.end method

.method public b(Landroid/content/ComponentName;Landroid/content/ServiceConnection;Ljava/lang/String;Ljava/util/concurrent/Executor;)Z
    .locals 4
    .param p1    # Landroid/content/ComponentName;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/ServiceConnection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/gms/common/internal/d2;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/16 v1, 0x1081

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, p1, v1}, Lcom/google/android/gms/common/internal/d2;-><init>(Landroid/content/ComponentName;I)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, v0, p2, p3, p4}, Lcom/google/android/gms/common/internal/k;->n(Lcom/google/android/gms/common/internal/d2;Landroid/content/ServiceConnection;Ljava/lang/String;Ljava/util/concurrent/Executor;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    return p1
.end method

.method public c(Ljava/lang/String;Landroid/content/ServiceConnection;Ljava/lang/String;)Z
    .locals 5
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/ServiceConnection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Lcom/google/android/gms/common/internal/d2;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/16 v1, 0x1081

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x3

    invoke-direct {v0, p1, v1, v2}, Lcom/google/android/gms/common/internal/d2;-><init>(Ljava/lang/String;IZ)V

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 p1, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0, v0, p2, p3, p1}, Lcom/google/android/gms/common/internal/k;->n(Lcom/google/android/gms/common/internal/d2;Landroid/content/ServiceConnection;Ljava/lang/String;Ljava/util/concurrent/Executor;)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    return p1
.end method

.method public j(Landroid/content/ComponentName;Landroid/content/ServiceConnection;Ljava/lang/String;)V
    .locals 4
    .param p1    # Landroid/content/ComponentName;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/ServiceConnection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/gms/common/internal/d2;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/16 v1, 0x1081

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, p1, v1}, Lcom/google/android/gms/common/internal/d2;-><init>(Landroid/content/ComponentName;I)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, v0, p2, p3}, Lcom/google/android/gms/common/internal/k;->l(Lcom/google/android/gms/common/internal/d2;Landroid/content/ServiceConnection;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method public k(Ljava/lang/String;Landroid/content/ServiceConnection;Ljava/lang/String;)V
    .locals 5
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/ServiceConnection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v0, Lcom/google/android/gms/common/internal/d2;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/16 v1, 0x1081

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {v0, p1, v1, v2}, Lcom/google/android/gms/common/internal/d2;-><init>(Ljava/lang/String;IZ)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0, v0, p2, p3}, Lcom/google/android/gms/common/internal/k;->l(Lcom/google/android/gms/common/internal/d2;Landroid/content/ServiceConnection;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method

.method protected abstract l(Lcom/google/android/gms/common/internal/d2;Landroid/content/ServiceConnection;Ljava/lang/String;)V
.end method

.method public final m(Ljava/lang/String;Ljava/lang/String;ILandroid/content/ServiceConnection;Ljava/lang/String;Z)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/content/ServiceConnection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance p3, Lcom/google/android/gms/common/internal/d2;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/16 v0, 0x1081

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p3, p1, p2, v0, p6}, Lcom/google/android/gms/common/internal/d2;-><init>(Ljava/lang/String;Ljava/lang/String;IZ)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0, p3, p4, p5}, Lcom/google/android/gms/common/internal/k;->l(Lcom/google/android/gms/common/internal/d2;Landroid/content/ServiceConnection;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method protected abstract n(Lcom/google/android/gms/common/internal/d2;Landroid/content/ServiceConnection;Ljava/lang/String;Ljava/util/concurrent/Executor;)Z
    .param p4    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
.end method
