.class public final Lcom/google/android/gms/common/internal/d1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~~s~~~~b~@@l1 ~~4~ @~@@@@l @i-@~b@M~~~  ~ o@@ cb~mo a@dS@iot.r~@  @uy@s~@ o/K/v fi~@o~@   fo~ nt"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x7

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v1, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 v2, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    move v3, v2

    move v3, v2

    const/4 v9, 0x1

    move v3, v2

    move v3, v2

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    move v4, v3

    move v4, v3

    const/4 v9, 0x2

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v9, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v5

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-ge v5, v0, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v5

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {v5}, Lh4/a;->O(I)I

    move-result v6

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    const/4 v7, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eq v6, v7, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v7, 0x2

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-eq v6, v7, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v7, 0x3

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-eq v6, v7, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    shr-int/2addr v9, v8

    if-eq v6, v7, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {p1, v5}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v8, 0x4

    sget-object v1, Lcom/google/android/gms/common/api/Scope;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {p1, v5, v1}, Lh4/a;->K(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)[Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    check-cast v1, [Lcom/google/android/gms/common/api/Scope;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto :goto_0

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {p1, v5}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    goto :goto_0

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static {p1, v5}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v3

    const/4 v9, 0x0

    const/4 v8, 0x2

    goto :goto_0

    :cond_3
    const/4 v8, 0x6

    move v9, v8

    invoke-static {p1, v5}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_0

    :cond_4
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    new-instance p1, Lcom/google/android/gms/common/internal/zax;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-direct {p1, v2, v3, v4, v1}, Lcom/google/android/gms/common/internal/zax;-><init>(III[Lcom/google/android/gms/common/api/Scope;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    return-object p1
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    new-array p1, p1, [Lcom/google/android/gms/common/internal/zax;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method
