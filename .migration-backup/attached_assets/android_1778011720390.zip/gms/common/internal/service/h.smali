.class abstract Lcom/google/android/gms/common/internal/service/h;
.super Lcom/google/android/gms/common/api/internal/e$a;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/l;)V
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object v0, Lcom/google/android/gms/common/internal/service/a;->b:Lcom/google/android/gms/common/api/a;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, v0, p1}, Lcom/google/android/gms/common/api/internal/e$a;-><init>(Lcom/google/android/gms/common/api/a;Lcom/google/android/gms/common/api/l;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method
