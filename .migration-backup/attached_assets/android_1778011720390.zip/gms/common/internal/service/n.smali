.class public final synthetic Lcom/google/android/gms/common/internal/service/n;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/internal/v;


# instance fields
.field public final synthetic a:Lcom/google/android/gms/common/internal/TelemetryData;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/common/internal/TelemetryData;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/internal/service/n;->a:Lcom/google/android/gms/common/internal/TelemetryData;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@soS~Mfs. ~o~~b~o@~~ ~ @@/o~iu~@by~i@~ n@~m  ~~dal-o~@ @@v~@~t@@ o  ~ i4f~ rb@tK@    1@c@l@/~ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    check-cast p1, Lcom/google/android/gms/common/internal/service/q;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast p2, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget v0, Lcom/google/android/gms/common/internal/service/p;->g:I

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/e;->getService()Landroid/os/IInterface;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast p1, Lcom/google/android/gms/common/internal/service/j;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/internal/service/n;->a:Lcom/google/android/gms/common/internal/TelemetryData;

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-virtual {p1, v0}, Lcom/google/android/gms/common/internal/service/j;->a(Lcom/google/android/gms/common/internal/TelemetryData;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p2, p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setResult(Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method
