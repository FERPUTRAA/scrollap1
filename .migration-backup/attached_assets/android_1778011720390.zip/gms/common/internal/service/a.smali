.class public final Lcom/google/android/gms/common/internal/service/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Lcom/google/android/gms/common/api/a$g;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/gms/common/api/a$g<",
            "Lcom/google/android/gms/common/internal/service/i;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final b:Lcom/google/android/gms/common/api/a;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/gms/common/api/a<",
            "Lcom/google/android/gms/common/api/a$d$d;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field private static final c:Lcom/google/android/gms/common/api/a$a;

.field public static final d:Lcom/google/android/gms/common/internal/service/f;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v0, Lcom/google/android/gms/common/api/a$g;

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/common/api/a$g;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    sput-object v0, Lcom/google/android/gms/common/internal/service/a;->a:Lcom/google/android/gms/common/api/a$g;

    const/4 v4, 0x6

    move v5, v4

    new-instance v1, Lcom/google/android/gms/common/internal/service/c;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {v1}, Lcom/google/android/gms/common/internal/service/c;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    sput-object v1, Lcom/google/android/gms/common/internal/service/a;->c:Lcom/google/android/gms/common/api/a$a;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v2, Lcom/google/android/gms/common/api/a;

    const-string v3, "IssoACmonP"

    const-string v3, "PosmoACInm"

    const/4 v5, 0x2

    const-string v3, ".AImPoonmC"

    const-string v3, "Common.API"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {v2, v3, v1, v0}, Lcom/google/android/gms/common/api/a;-><init>(Ljava/lang/String;Lcom/google/android/gms/common/api/a$a;Lcom/google/android/gms/common/api/a$g;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    sput-object v2, Lcom/google/android/gms/common/internal/service/a;->b:Lcom/google/android/gms/common/api/a;

    const/4 v5, 0x4

    new-instance v0, Lcom/google/android/gms/common/internal/service/f;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {v0}, Lcom/google/android/gms/common/internal/service/f;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    sput-object v0, Lcom/google/android/gms/common/internal/service/a;->d:Lcom/google/android/gms/common/internal/service/f;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method
