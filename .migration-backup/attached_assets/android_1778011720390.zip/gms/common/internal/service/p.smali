.class public final Lcom/google/android/gms/common/internal/service/p;
.super Lcom/google/android/gms/common/api/k;

# interfaces
.implements Lcom/google/android/gms/common/internal/c0;


# static fields
.field private static final d:Lcom/google/android/gms/common/api/a$g;

.field private static final e:Lcom/google/android/gms/common/api/a$a;

.field private static final f:Lcom/google/android/gms/common/api/a;

.field public static final synthetic g:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    new-instance v0, Lcom/google/android/gms/common/api/a$g;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v0}, Lcom/google/android/gms/common/api/a$g;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    sput-object v0, Lcom/google/android/gms/common/internal/service/p;->d:Lcom/google/android/gms/common/api/a$g;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v1, Lcom/google/android/gms/common/internal/service/o;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {v1}, Lcom/google/android/gms/common/internal/service/o;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    sput-object v1, Lcom/google/android/gms/common/internal/service/p;->e:Lcom/google/android/gms/common/api/a$a;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-instance v2, Lcom/google/android/gms/common/api/a;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const-string/jumbo v3, "etsyteemlrTPCilnIA."

    const/4 v5, 0x2

    const-string v3, "emsItA.CtineerlPelT"

    const-string v3, "ClientTelemetry.API"

    const/4 v5, 0x2

    invoke-direct {v2, v3, v1, v0}, Lcom/google/android/gms/common/api/a;-><init>(Ljava/lang/String;Lcom/google/android/gms/common/api/a$a;Lcom/google/android/gms/common/api/a$g;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    sput-object v2, Lcom/google/android/gms/common/internal/service/p;->f:Lcom/google/android/gms/common/api/a;

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/google/android/gms/common/internal/d0;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object v0, Lcom/google/android/gms/common/internal/service/p;->f:Lcom/google/android/gms/common/api/a;

    const/4 v3, 0x1

    sget-object v1, Lcom/google/android/gms/common/api/k$a;->c:Lcom/google/android/gms/common/api/k$a;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0, p1, v0, p2, v1}, Lcom/google/android/gms/common/api/k;-><init>(Landroid/content/Context;Lcom/google/android/gms/common/api/a;Lcom/google/android/gms/common/api/a$d;Lcom/google/android/gms/common/api/k$a;)V

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method


# virtual methods
.method public final b(Lcom/google/android/gms/common/internal/TelemetryData;)Lcom/google/android/gms/tasks/Task;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/internal/TelemetryData;",
            ")",
            "Lcom/google/android/gms/tasks/Task<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~~om nb~l~odc @1~o~  M@i~@@@u@ a@r@ft@~t/ ~K~@@@ ~@~~ oo~b ~f@~v i ol@~-y ~~@~s .m/i~ @~@@@ 4 S "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    invoke-static {}, Lcom/google/android/gms/common/api/internal/a0;->a()Lcom/google/android/gms/common/api/internal/a0$a;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-array v1, v1, [Lcom/google/android/gms/common/Feature;

    const/4 v5, 0x2

    const/4 v4, 0x3

    sget-object v2, Lcom/google/android/gms/internal/base/zaf;->zaa:Lcom/google/android/gms/common/Feature;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    aput-object v2, v1, v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/api/internal/a0$a;->e([Lcom/google/android/gms/common/Feature;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v3}, Lcom/google/android/gms/common/api/internal/a0$a;->d(Z)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v1, Lcom/google/android/gms/common/internal/service/n;

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-direct {v1, p1}, Lcom/google/android/gms/common/internal/service/n;-><init>(Lcom/google/android/gms/common/internal/TelemetryData;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/api/internal/a0$a;->c(Lcom/google/android/gms/common/api/internal/v;)Lcom/google/android/gms/common/api/internal/a0$a;

    const/4 v4, 0x3

    shr-int/2addr v5, v4

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/internal/a0$a;->a()Lcom/google/android/gms/common/api/internal/a0;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/api/k;->doBestEffortWrite(Lcom/google/android/gms/common/api/internal/a0;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-object p1
.end method
