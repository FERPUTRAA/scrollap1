.class public abstract Lcom/google/android/gms/common/internal/service/k;
.super Lcom/google/android/gms/internal/base/zab;

# interfaces
.implements Lcom/google/android/gms/common/internal/service/l;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    const-string v0, "bns.nomCsio.dre.cllo.aog.arnmCngmgeriodi.oeI.sksmsmamtcvacoonel"

    const-string v0, "eosIelg.d.cmoscnanrimannaCl..gmredisbcvm.oooraCoksi.gto.olemmln"

    const/4 v2, 0x5

    const-string v0, "cvcmebmglnaomioiedmro.mss.IlrmenmrCognocooga.it.eklClc.sna.an.d"

    const-string v0, "com.google.android.gms.common.internal.service.ICommonCallbacks"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/base/zab;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method protected final zaa(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "v  ~o@~o anl~@~o@  M~ 1 ibKo or@/~o~~m@/@ ~~b~~lu@s @ b i@@~dyf~~~~@ @ @it- ~.~f@o@~~ @t@ @@@Sc~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    const/4 p3, 0x1

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    if-ne p1, p3, :cond_0

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p2}, Lcom/google/android/gms/internal/base/zac;->zab(Landroid/os/Parcel;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    invoke-interface {p0, p1}, Lcom/google/android/gms/common/internal/service/l;->U(I)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return p3

    :cond_0
    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p1
.end method
