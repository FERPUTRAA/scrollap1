.class public final Lcom/google/android/gms/common/internal/service/q;
.super Lcom/google/android/gms/common/internal/j;


# instance fields
.field private final a:Lcom/google/android/gms/common/internal/d0;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/internal/d0;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/16 v3, 0x10e

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    iput-object p4, p0, Lcom/google/android/gms/common/internal/service/q;->a:Lcom/google/android/gms/common/internal/d0;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/@sm4~io Kbn @@dolvr~~b~s~@~~ @ S-ta@b~i. u@ t c@~~@/@~~~ i @~~~@~ @@@@@@Mff@~~ l~@ o1oy ~  oo~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 p1, 0x1

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v0, "vlsmt.CemaciyneIgeSorscniedarneio..oec.errtirTng.mgv.oesdmmolcom.lltei"

    const-string/jumbo v0, "oesorimmol.lriC.cm.aecn.ceeoeleIrnsc.ntrnoSmlrseeegdvtmietiiToayg.g.dv"

    const/4 v3, 0x7

    const-string v0, ".eeno.ilnocar.CtTIaet.oemoSgio.rnervieeml.doe.lslnmvrimegcientrcsygmoc"

    const-string v0, "com.google.android.gms.common.internal.service.IClientTelemetryService"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    instance-of v1, v0, Lcom/google/android/gms/common/internal/service/j;

    const/4 v2, 0x4

    move v3, v2

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast p1, Lcom/google/android/gms/common/internal/service/j;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/common/internal/service/j;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/internal/service/j;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p1
.end method

.method public final getApiFeatures()[Lcom/google/android/gms/common/Feature;
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    sget-object v0, Lcom/google/android/gms/internal/base/zaf;->zab:[Lcom/google/android/gms/common/Feature;

    const/4 v2, 0x5

    return-object v0
.end method

.method protected final getGetServiceRequestExtraArgs()Landroid/os/Bundle;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/service/q;->a:Lcom/google/android/gms/common/internal/d0;

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/d0;->b()Landroid/os/Bundle;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public final getMinApkVersion()I
    .locals 3

    const/4 v2, 0x5

    const v0, 0xc1fa340

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string/jumbo v0, "vt.debrac.ec.leoTriimmeatmnintmeslcceiCenmgoogveyo.nmd.r.oilSreoIsnlr."

    const-string/jumbo v0, "ienmgnircteomvgalert.o.oIasniC.virnd.meTrdS..tiolmcoeclcmegnmo.yeelers"

    const-string/jumbo v0, "stgi..uonerdTir.cil.eocaeSelslmii.no.rtaeoennoetvmeelmCgmn.cgreryoIcmv"

    const-string v0, "com.google.android.gms.common.internal.service.IClientTelemetryService"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method protected final getStartServiceAction()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string v0, "eonarg.pRe.timt.yeomsTloo.mmoo.vcee.deggsrmroAdclSiTc"

    const-string/jumbo v0, "gArto..goms.lTndtS..e.melirorocyeonmmTocRdemaegoecvis"

    const/4 v2, 0x3

    const-string v0, "dAcnreilqrormSo..eTn.eRce.oost.meo..Tcmoamvggytelgisd"

    const-string v0, "com.google.android.gms.common.telemetry.service.START"

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-object v0
.end method

.method protected final getUseDynamicLookup()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method
