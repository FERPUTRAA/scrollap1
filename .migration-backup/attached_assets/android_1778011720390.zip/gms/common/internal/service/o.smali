.class final Lcom/google/android/gms/common/internal/service/o;
.super Lcom/google/android/gms/common/api/a$a;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/android/gms/common/api/a$a;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final synthetic buildClient(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Ljava/lang/Object;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)Lcom/google/android/gms/common/api/a$f;
    .locals 9

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    const/4 v8, 0x4

    const-string v7, "biso@~/1 i~~~o@@ M  a@f~@~/m~~~~ou lc@@- f~  @~@~ S~b@@~~~ ~yd@~to@@.K@nrvl@ @bos@4 o   ~@ ~t@i~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x5

    check-cast v4, Lcom/google/android/gms/common/internal/d0;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    new-instance p4, Lcom/google/android/gms/common/internal/service/q;

    move-object v0, p4

    move-object v0, p4

    move-object v0, p4

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v6, p6

    move-object v6, p6

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/service/q;-><init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/internal/d0;Lcom/google/android/gms/common/api/internal/f;Lcom/google/android/gms/common/api/internal/q;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    return-object p4
.end method
