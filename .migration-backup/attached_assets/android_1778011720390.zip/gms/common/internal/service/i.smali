.class public final Lcom/google/android/gms/common/internal/service/i;
.super Lcom/google/android/gms/common/internal/j;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/gms/common/internal/j<",
        "Lcom/google/android/gms/common/internal/service/m;",
        ">;"
    }
.end annotation


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V
    .locals 9

    const/4 v8, 0x0

    const/16 v3, 0x27

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct/range {v0 .. v6}, Lcom/google/android/gms/common/internal/j;-><init>(Landroid/content/Context;Landroid/os/Looper;ILcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    return-void
.end method


# virtual methods
.method protected final synthetic createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~bs~~@~~ M1~t. @it a ~ @d@/f @i@ooK  @s@il4 obr f/@ ~~n@m@@ ~~~Sl@ vu ~~@ @-c~@~ ~~o~@o@~@ ~~oby"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string/jumbo v0, "neomoiemdS.iacir.svoca.ocgmlno.deIem.m.g.rnemocilmnvroerongCs"

    const-string v0, "com.google.android.gms.common.internal.service.ICommonService"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    instance-of v1, v0, Lcom/google/android/gms/common/internal/service/m;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast p1, Lcom/google/android/gms/common/internal/service/m;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/common/internal/service/m;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/internal/service/m;-><init>(Landroid/os/IBinder;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p1
.end method

.method protected final getServiceDescriptor()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string/jumbo v0, "sc.Sos.dgtmc..ngcmlmoercr.imonom.dee.soeaerglomevriooIovnnnCi"

    const-string/jumbo v0, "rrsmgnr.Icmieva.igo.oidoCclcno.nemsmtgroveneneoeomdlm.isc..oS"

    const/4 v2, 0x2

    const-string/jumbo v0, "n.o.cb.cdatireSni.mm.smgsgComrvnolm.emaioeecelgdeovornconior."

    const-string v0, "com.google.android.gms.common.internal.service.ICommonService"

    const/4 v2, 0x0

    return-object v0
.end method

.method public final getStartServiceAction()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string v0, ".eaoosu.ommo..emggndocgTirno.edSTcrs.lAcvmi"

    const-string v0, ".srmmmc.rogAgnoSianT.mcds.eT.ooigcoldemeov."

    const/4 v2, 0x7

    const-string v0, "am.n.oRpgTgeriersdd.ncTmoogiccASlm..o.osveo"

    const-string v0, "com.google.android.gms.common.service.START"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method
