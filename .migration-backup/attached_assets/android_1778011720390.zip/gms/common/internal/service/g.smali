.class abstract Lcom/google/android/gms/common/internal/service/g;
.super Lcom/google/android/gms/common/internal/service/h;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/l;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/internal/service/h;-><init>(Lcom/google/android/gms/common/api/l;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFailedResult(Lcom/google/android/gms/common/api/Status;)Lcom/google/android/gms/common/api/v;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @s ~1@~f~f@b~v@b~i.a @S @oyK~@~@ ~i /  @ ~@ on~t~ ~4 @-oio/dol@l~~~  @@ bo ~@@~@c~~r~@@~~Ms umt"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    return-object p1
.end method
