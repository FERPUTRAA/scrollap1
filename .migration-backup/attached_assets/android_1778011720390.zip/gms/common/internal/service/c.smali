.class final Lcom/google/android/gms/common/internal/service/c;
.super Lcom/google/android/gms/common/api/a$a;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/common/api/a$a;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final synthetic buildClient(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Ljava/lang/Object;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)Lcom/google/android/gms/common/api/a$f;
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@~s ~~ ftoMa@ ~~@o @b~~o~bmo~n ~ itic@i@ ~   @ s~ 1@S~@@4o~ l@@@~~o~y.~~fl u-/@@@@@/K~ rb d~@v @"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p4, Lcom/google/android/gms/common/api/a$d$d;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance p4, Lcom/google/android/gms/common/internal/service/i;

    move-object v0, p4

    move-object v0, p4

    move-object v0, p4

    move-object v0, p4

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v4, p5

    move-object v4, p5

    move-object v4, p5

    move-object v4, p5

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/internal/service/i;-><init>(Landroid/content/Context;Landroid/os/Looper;Lcom/google/android/gms/common/internal/g;Lcom/google/android/gms/common/api/l$b;Lcom/google/android/gms/common/api/l$c;)V

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    return-object p4
.end method
