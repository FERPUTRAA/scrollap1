.class final Lcom/google/android/gms/common/internal/service/e;
.super Lcom/google/android/gms/common/internal/service/b;


# instance fields
.field private final a:Lcom/google/android/gms/common/api/internal/e$b;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/api/internal/e$b;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/service/b;-><init>()V

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/internal/service/e;->a:Lcom/google/android/gms/common/api/internal/e$b;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final U(I)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s@o .@ o @y f r@ d @@~c ~@f@vb~~tl - K~~~~~b@~~  o@~@  Mo~~~@~l @1~~/~@@u/is~@i@oib ~o@a@nS m4"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/gms/common/api/Status;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/api/Status;-><init>(I)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/gms/common/internal/service/e;->a:Lcom/google/android/gms/common/api/internal/e$b;

    const/4 v1, 0x0

    move v2, v1

    invoke-interface {p1, v0}, Lcom/google/android/gms/common/api/internal/e$b;->setResult(Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method
