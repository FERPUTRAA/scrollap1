.class public final Lcom/google/android/gms/common/internal/l2;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final b:Ljava/lang/String;

.field private final c:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;ZIZ)V
    .locals 2
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/internal/l2;->b:Ljava/lang/String;

    const/4 v0, 0x0

    move v1, v0

    iput-object p2, p0, Lcom/google/android/gms/common/internal/l2;->a:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-boolean p5, p0, Lcom/google/android/gms/common/internal/l2;->c:Z

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method final a()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~1s@-v@fyS~@ ~o~@ut@o~ib~ or~@4@ ~~ i/~~.@@b~@f ~ ~M@~ slt~c o @@~a i@~o~@@@nbm~l~  o @ @@~ K d/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/l2;->b:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method final b()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/internal/l2;->a:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method final c()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/gms/common/internal/l2;->c:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method
