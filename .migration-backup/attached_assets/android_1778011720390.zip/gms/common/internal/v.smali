.class public final Lcom/google/android/gms/common/internal/v;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v1, "nssebaitnitsnl"

    const-string/jumbo v1, "tnsibnntUsalie"

    const/4 v3, 0x6

    const-string/jumbo v1, "seamaUtbnitnin"

    const-string v1, "Uninstantiable"

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw v0
.end method

.method static varargs A(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    add-int/lit8 v0, v0, 0x30

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/4 v0, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    move v2, v0

    move v2, v0

    const/4 v8, 0x4

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 v3, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-ge v0, v3, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string v4, "%s"

    const-string/jumbo v4, "s%"

    const/4 v8, 0x7

    const-string v4, "%s"

    const-string v4, "%s"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p0, v4, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v5, -0x1

    const/4 v8, 0x3

    if-ne v4, v5, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x2

    goto :goto_1

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {p0, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    add-int/lit8 v2, v0, 0x1

    const/4 v7, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    aget-object v0, p1, v0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    add-int/lit8 v0, v4, 0x2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    move v6, v2

    move v6, v2

    const/4 v8, 0x3

    const/4 v7, 0x4

    move v2, v0

    move v2, v0

    const/4 v8, 0x4

    move v2, v0

    move v2, v0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    move v0, v6

    move v0, v6

    const/4 v8, 0x3

    move v0, v6

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-ge v0, v3, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string p0, "[ "

    const-string p0, " ["

    const/4 v8, 0x3

    const-string p0, "[ "

    const-string p0, " ["

    const/4 v7, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    add-int/lit8 p0, v0, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    aget-object v0, p1, v0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    :goto_2
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-ge p0, v3, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string v0, ", "

    const-string v0, ", "

    const/4 v8, 0x7

    const-string v0, ", "

    const-string v0, ", "

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    add-int/lit8 v0, p0, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    aget-object p0, p1, p0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    move p0, v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    goto :goto_2

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string p0, "]"

    const-string p0, "]"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    return-object p0
.end method

.method public static a(Z)V
    .locals 2
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eqz p0, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    throw p0
.end method

.method public static b(ZLjava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x1

    if-eqz p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v0, 0x7

    xor-int/2addr v1, v0

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    throw p0
.end method

.method public static varargs c(ZLjava/lang/String;[Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    if-eqz p0, :cond_0

    const/4 v0, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p1, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    throw p0
.end method

.method public static d(DDDLjava/lang/String;)D
    .locals 7
    .param p6    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    cmpg-double v0, p0, p2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v1, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x3

    const/4 v6, 0x1

    if-ltz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    cmpl-double v0, p0, p4

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-gtz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    return-wide p0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-array p1, v4, [Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    aput-object p6, p1, v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    aput-object p2, p1, v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {p4, p5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    aput-object p2, p1, v1

    const/4 v6, 0x2

    const-string/jumbo p2, "o ieogf osf o,( %o i [%mo h%f rta]) ufngh"

    const-string/jumbo p2, "ousmf ofhfo]egt )h ns%  r o a%o i (g%,fi["

    const/4 v6, 0x0

    const-string/jumbo p2, "o]%r b sogotag fso  onift ih,ffu[ %)  h%("

    const-string p2, "%s is out of range of [%f, %f] (too high)"

    const/4 v6, 0x1

    const/4 v5, 0x2

    invoke-static {p2, p1}, Lcom/google/android/gms/common/internal/v;->A(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    throw p0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-array p1, v4, [Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    aput-object p6, p1, v3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    aput-object p2, p1, v2

    const/4 v6, 0x5

    invoke-static {p4, p5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    aput-object p2, p1, v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string p2, "(w% o u,toorn]if% u%os  so) lf[ teaoffg "

    const-string p2, "% w ot%,of([fsof r is]ol egao  tno %u) f"

    const/4 v6, 0x1

    const-string p2, " w e fspo %oafl%i , [noroo(f  )%s u]ttfg"

    const-string p2, "%s is out of range of [%f, %f] (too low)"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p2, p1}, Lcom/google/android/gms/common/internal/v;->A(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    throw p0
.end method

.method public static e(FFFLjava/lang/String;)F
    .locals 7
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    cmpg-float v0, p0, p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v1, 0x2

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/4 v4, 0x3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-ltz v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    cmpl-float v0, p0, p2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-gtz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    return p0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-array v0, v4, [Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    aput-object p3, v0, v3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    aput-object p1, v0, v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    aput-object p1, v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string p1, ",)h ioifqf  oo(efs gfo  %btr[n% hgot ]usa"

    const-string p1, "[og,hb% ff(% ohft in e stoogor ia )su f] "

    const/4 v6, 0x4

    const-string/jumbo p1, "fos%fn hsf iosea%g o,%ugt  ) o ]h i[tf ro"

    const-string p1, "%s is out of range of [%f, %f] (too high)"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->A(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    move v6, v5

    throw p0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x0

    new-array v0, v4, [Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    aput-object p3, v0, v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    aput-object p1, v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {p2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    aput-object p1, v0, v1

    const-string p1, ",s m)ouis%o ]% ft%fl o(wnof f  rutog[  o"

    const-string p1, " t %) ug oo(f%,]esot i[fsf ow foouln r %"

    const/4 v6, 0x4

    const-string p1, " o sow( asnt[iffo f%  ru,eogl  )%tf ]ooo"

    const-string p1, "%s is out of range of [%f, %f] (too low)"

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->A(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    throw p0
.end method

.method public static f(IIILjava/lang/String;)I
    .locals 6
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v0, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x3

    move v5, v3

    const/4 v4, 0x4

    and-int/2addr v5, v4

    if-lt p0, p1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    if-gt p0, p2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    return p0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    aput-object p3, v3, v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    aput-object p1, v3, v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    aput-object p1, v3, v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo p1, "o[ %]bt%(  ai gsr,ie  uo sdhngot  po)hdff"

    const-string/jumbo p1, "n t %hup %irgtgoi,s (  h%af soe]of o )[dd"

    const/4 v5, 0x7

    const-string p1, "  ) %guuonf%o  [da ,ferogi tsh idtohs]o( "

    const-string p1, "%s is out of range of [%d, %d] (too high)"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p1, v3}, Lcom/google/android/gms/common/internal/v;->A(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    throw p0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    aput-object p3, v3, v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    aput-object p1, v3, v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    aput-object p1, v3, v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string p1, "%nf osfp oou]di( g  a,wq)r%[odtt l %os e"

    const-string/jumbo p1, "o) ol  ,qoo%]owgtud%n  o (%fa [iesfdsr t"

    const/4 v5, 0x0

    const-string p1, "e  gi%u%qwol]af   sdoof) odo,sot t(% [r "

    const-string p1, "%s is out of range of [%d, %d] (too low)"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {p1, v3}, Lcom/google/android/gms/common/internal/v;->A(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    throw p0
.end method

.method public static g(JJJLjava/lang/String;)J
    .locals 7
    .param p6    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x6

    const/4 v6, 0x3

    cmp-long v0, p0, p2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v1, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v2, 0x1

    move v6, v2

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x2

    const/4 v4, 0x3

    const/4 v6, 0x2

    shl-int/2addr v5, v4

    const/4 v6, 0x5

    if-ltz v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    cmp-long v0, p0, p4

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-gtz v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-wide p0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    new-array p1, v4, [Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    aput-object p6, p1, v3

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    aput-object p2, p1, v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {p4, p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    aput-object p2, p1, v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo p2, "h[sr efgd%d(% o  ) fogtas ou]% t is iho,n"

    const/4 v6, 0x2

    const-string p2, "%s is out of range of [%d, %d] (too high)"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p2, p1}, Lcom/google/android/gms/common/internal/v;->A(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    throw p0

    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-array p1, v4, [Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    aput-object p6, p1, v3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    aput-object p2, p1, v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-static {p4, p5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x2

    aput-object p2, p1, v1

    const/4 v5, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo p2, "o%s u  odn%ol e([% a g  f sm]toosfo,)irt"

    const-string/jumbo p2, "lsomo %ofn%d]t % o[tfio)  a, u  g dsroe("

    const/4 v6, 0x7

    const-string/jumbo p2, "ow%ms lo[  snua to%  od,o erft ]%(fiog) "

    const-string p2, "%s is out of range of [%d, %d] (too low)"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p2, p1}, Lcom/google/android/gms/common/internal/v;->A(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    throw p0
.end method

.method public static h(Landroid/os/Handler;)V
    .locals 6
    .param p0    # Landroid/os/Handler;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eq v0, v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v0, "cnruo lrronult eolp"

    const-string/jumbo v0, "orulortponr lnl uec"

    const/4 v5, 0x0

    const-string/jumbo v0, "null current looper"

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const-string v3, "Mt  nbbsleal eoc b"

    const-string/jumbo v3, "oeMtbb c e asln lu"

    const/4 v5, 0x7

    const-string v3, "atbln u soMeucl e "

    const-string v3, "Must be called on "

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v4, 0x5

    const-string/jumbo p0, "ot,du tpb   argut"

    const-string p0, "d b routt u et,ag"

    const/4 v5, 0x5

    const-string p0, "ar  tht q, deougt"

    const-string p0, " thread, but got "

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string p0, "."

    const-string p0, "."

    const/4 v5, 0x6

    const-string p0, "."

    const-string p0, "."

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {v1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    throw v1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    return-void
.end method

.method public static i(Landroid/os/Handler;Ljava/lang/String;)V
    .locals 3
    .param p0    # Landroid/os/Handler;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-ne v0, p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    throw p0
.end method

.method public static j()V
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string v0, "easldhpa  oelit Mamelsbepc  pnrttaudn otiachn"

    const-string/jumbo v0, "laidisdpttm p  upa eooeaMahbthe ealc ncinrltn"

    const/4 v2, 0x0

    const-string v0, "Must be called on the main application thread"

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->k(Ljava/lang/String;)V

    const/4 v2, 0x4

    return-void
.end method

.method public static k(Ljava/lang/String;)V
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/common/util/f0;->a()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    throw v0
.end method

.method public static l(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Lq9/d;
        value = {
            "#1"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-string v0, " evm ininlsyi npt oqGlSrtre g"

    const-string/jumbo v0, "rivmyltnqseS tinpi go G  lrne"

    const/4 v2, 0x7

    const-string/jumbo v0, "tyllope imer utnnGoisgv niS r"

    const-string v0, "Given String is empty or null"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    throw p0
.end method

.method public static m(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Lq9/d;
        value = {
            "#1"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v1, 0x5

    move v2, v1

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    move v2, v1

    throw p0
.end method

.method public static n()V
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string/jumbo v0, "lA.utbron eedoaeeltHnpc itdnsodaghers la GM ol"

    const-string v0, " usHpighlctn M drer eetoltaasonlado Aee.dlnoG "

    const/4 v2, 0x2

    const-string v0, ".nd lbuo aicr gM uh  dtApeseHlltoeoGatnerloeda"

    const-string v0, "Must not be called on GoogleApiHandler thread."

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->o(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public static o(Ljava/lang/String;)V
    .locals 4
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, "egGoeoHplArnapdm"

    const-string v1, "GHgmrlaeepldnoAo"

    const/4 v3, 0x2

    const-string/jumbo v1, "gpirlAGlqonoadHe"

    const-string v1, "GoogleApiHandler"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eq v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw v0

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public static p()V
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string v0, "eesomshlidaerabt  ttnoapo  na   tdcpcnioneh Mlilu"

    const-string v0, " itao mcr ieoiteMtnnabunt pl d n eohdelahls pocaa"

    const/4 v2, 0x6

    const-string/jumbo v0, "u om noMisna d ppno ne leetr tcelhchabtdialtmai a"

    const-string v0, "Must not be called on the main application thread"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->q(Ljava/lang/String;)V

    const/4 v2, 0x1

    return-void
.end method

.method public static q(Ljava/lang/String;)V
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/common/util/f0;->a()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    throw v0
.end method

.method public static r(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p0    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;)TT;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Lq9/d;
        value = {
            "#1"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-object p0

    :cond_0
    const/4 v1, 0x3

    move v2, v1

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string v0, "cu noerlelrefe"

    const-string/jumbo v0, "null reference"

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    throw p0
.end method

.method public static s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p0    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Lq9/d;
        value = {
            "#1"
        }
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    if-eqz p0, :cond_0

    return-object p0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    throw p0
.end method

.method public static t(I)I
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x4

    const-string/jumbo v0, "zbi IbnGrt seienv eog"

    const-string v0, "egv Ibe ior sznirntGe"

    const/4 v2, 0x5

    const-string v0, "e oetzuveGnesri i Igr"

    const-string v0, "Given Integer is zero"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    throw p0
.end method

.method public static u(ILjava/lang/Object;)I
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    if-eqz p0, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    throw p0
.end method

.method public static v(J)J
    .locals 4
    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    cmp-long v0, p0, v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-wide p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string p1, "Given Long is zero"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    throw p0
.end method

.method public static w(JLjava/lang/Object;)J
    .locals 4
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    cmp-long v0, p0, v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-wide p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    throw p0
.end method

.method public static x(Z)V
    .locals 2
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    if-eqz p0, :cond_0

    const/4 v1, 0x5

    return-void

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v1, 0x2

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/IllegalStateException;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    throw p0
.end method

.method public static y(ZLjava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    if-eqz p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    throw p0
.end method

.method public static varargs z(ZLjava/lang/String;[Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation

        .annotation build Ly4/i;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    .annotation build Ly4/h;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-eqz p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p1, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    throw p0
.end method
