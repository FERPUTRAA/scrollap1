.class final Lcom/google/android/gms/common/internal/w0;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/a1;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method
