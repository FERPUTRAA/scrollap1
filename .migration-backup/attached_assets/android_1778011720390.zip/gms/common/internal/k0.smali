.class public final Lcom/google/android/gms/common/internal/k0;
.super Ljava/lang/Object;


# static fields
.field private static final a:Landroidx/collection/m;
    .annotation build Lz4/a;
        value = "cache"
    .end annotation
.end field

.field private static b:Ljava/util/Locale;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lz4/a;
        value = "cache"
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Landroidx/collection/m;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0}, Landroidx/collection/m;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    sput-object v0, Lcom/google/android/gms/common/internal/k0;->a:Landroidx/collection/m;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "onsm~4~@l~@S fi~oo~a~1f/ @ tKv~@~@@ @~~~@i ~/ l~~@b@@~u@od @b~c@~sMb@y ~  ~ ~ @@ r~-@.@iot @  o "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/google/android/gms/common/wrappers/d;->a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-virtual {v1, v0}, Lcom/google/android/gms/common/wrappers/c;->d(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object p0

    :catch_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object p0, p0, Landroid/content/pm/ApplicationInfo;->name:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v2, 0x7

    move v3, v2

    return-object p0
.end method

.method public static b(Landroid/content/Context;I)Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eq p1, v0, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eq p1, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eq p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    const p1, 0x104000a

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget p1, Lcom/google/android/gms/base/R$string;->common_google_play_services_enable_button:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget p1, Lcom/google/android/gms/base/R$string;->common_google_play_services_update_button:I

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-object p0

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget p1, Lcom/google/android/gms/base/R$string;->common_google_play_services_install_button:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public static c(Landroid/content/Context;I)Ljava/lang/String;
    .locals 7
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p0}, Lcom/google/android/gms/common/internal/k0;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v3, 0x1

    const/4 v6, 0x6

    if-eq p1, v3, :cond_7

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v4, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x2

    if-eq p1, v4, :cond_5

    const/4 v6, 0x3

    const/4 v4, 0x3

    const/4 v6, 0x2

    shl-int/2addr v5, v4

    const/4 v6, 0x0

    if-eq p1, v4, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v4, 0x5

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eq p1, v4, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v4, 0x7

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eq p1, v4, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/16 v4, 0x9

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eq p1, v4, :cond_1

    const/4 v6, 0x5

    const/16 v4, 0x14

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eq p1, v4, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    packed-switch p1, :pswitch_data_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    sget p0, Lcom/google/android/gms/common/R$string;->common_google_play_services_unknown_issue:I

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-array p1, v3, [Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    aput-object v1, p1, v2

    const/4 v6, 0x4

    invoke-virtual {v0, p0, p1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-object p0

    :pswitch_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    sget p0, Lcom/google/android/gms/base/R$string;->common_google_play_services_updating_text:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-array p1, v3, [Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    aput-object v1, p1, v2

    const/4 v6, 0x0

    invoke-virtual {v0, p0, p1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    return-object p0

    :pswitch_1
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string/jumbo p1, "on_mopgefiesastgmlglo_oyirmce__lde_nv_sx_cieita"

    const-string/jumbo p1, "gismxif_t__nl_crosvi_sgogapia_deloenmtcl_eoyees"

    const/4 v6, 0x4

    const-string p1, "common_google_play_services_sign_in_failed_text"

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {p0, p1, v1}, Lcom/google/android/gms/common/internal/k0;->g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    return-object p0

    :pswitch_2
    const/4 v6, 0x0

    const-string/jumbo p1, "r_byovmot_aceme_aostagllxgasn_vmno_clppaiieouee_"

    const-string/jumbo p1, "oinmoagle__oaeemgo_vpcx_c_vsiiueysettnr_lbmalapa"

    const/4 v6, 0x0

    const-string/jumbo p1, "ey_iebemaocptte_lovsaioo_xncneramb_al_gil_pulvsa"

    const-string p1, "common_google_play_services_api_unavailable_text"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p0, p1, v1}, Lcom/google/android/gms/common/internal/k0;->g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-object p0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string p1, "_o_eggu_rresooocecosirxlntease_rtv_mtcfitleepy_mpdo"

    const-string p1, "_s_eoo_xtcely_rnglirmocptgslo_eoaeesdr_termcfvtoiep"

    const/4 v6, 0x7

    const-string p1, "common_google_play_services_restricted_profile_text"

    const/4 v6, 0x3

    invoke-static {p0, p1, v1}, Lcom/google/android/gms/common/internal/k0;->g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-object p0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    sget p0, Lcom/google/android/gms/base/R$string;->common_google_play_services_unsupported_text:I

    new-array p1, v3, [Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    aput-object v1, p1, v2

    const/4 v5, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v0, p0, p1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-object p0

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo p1, "gceeebveolyilrgokmsmror___nxrtoopeoenctt__sawr"

    const/4 v6, 0x4

    const-string/jumbo p1, "otvisrnpo_eooeykcagc_ntgeelre___pw_trmoxormrls"

    const-string p1, "common_google_play_services_network_error_text"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {p0, p1, v1}, Lcom/google/android/gms/common/internal/k0;->g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-object p0

    :cond_3
    const-string p1, "eecoviuiqttcelnamol_ynpde_ggstsa__vmoonicxl_uroc"

    const-string/jumbo p1, "gpxdm_uioeo_oeeg_amcl_escotlrlctcnnsynvotiiav__u"

    const-string p1, "ansxc_c_oye_peleisltlcotmtorov_indgem_aic_vnogas"

    const-string p1, "common_google_play_services_invalid_account_text"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p0, p1, v1}, Lcom/google/android/gms/common/internal/k0;->g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-object p0

    :cond_4
    const/4 v6, 0x2

    sget p0, Lcom/google/android/gms/base/R$string;->common_google_play_services_enable_text:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-array p1, v3, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    aput-object v1, p1, v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v0, p0, p1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-object p0

    :cond_5
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->m(Landroid/content/Context;)Z

    move-result p0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz p0, :cond_6

    const/4 v5, 0x5

    shr-int/2addr v6, v5

    sget p0, Lcom/google/android/gms/base/R$string;->common_google_play_services_wear_update_text:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-object p0

    :cond_6
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    sget p0, Lcom/google/android/gms/base/R$string;->common_google_play_services_update_text:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-array p1, v3, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    aput-object v1, p1, v2

    const/4 v6, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, p0, p1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-object p0

    :cond_7
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    sget p0, Lcom/google/android/gms/base/R$string;->common_google_play_services_install_text:I

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    new-array p1, v3, [Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    aput-object v1, p1, v2

    const/4 v6, 0x4

    invoke-virtual {v0, p0, p1}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-object p0

    :pswitch_data_0
    .packed-switch 0x10
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static d(Landroid/content/Context;I)Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x6

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eq p1, v0, :cond_1

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    const/16 v0, 0x13

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-ne p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, p1}, Lcom/google/android/gms/common/internal/k0;->c(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/internal/k0;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string/jumbo v0, "pxom_nlosoirnmg_grloy_sriovt_eqeccarepeltetdiem_su_o"

    const-string v0, "_eygegoptt_mqmerecoiocslotvl_uiodann_rr_resxlioee_ps"

    const/4 v2, 0x1

    const-string v0, "_i_eomonyraxslemlgstgvsooee_drnui__oopleectcru_oietq"

    const-string v0, "common_google_play_services_resolution_required_text"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p0, v0, p1}, Lcom/google/android/gms/common/internal/k0;->g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public static e(Landroid/content/Context;I)Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v0, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x6

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-ne p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo p1, "s_o_pbtlseea_lredmtiiuooq_tgmoelecolne_ry_rgvuioicres"

    const-string p1, "common_google_play_services_resolution_required_title"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0, p1}, Lcom/google/android/gms/common/internal/k0;->h(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    invoke-static {p0, p1}, Lcom/google/android/gms/common/internal/k0;->f(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget p1, Lcom/google/android/gms/base/R$string;->common_google_play_services_notification_ticker:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    return-object p0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p1
.end method

.method public static f(Landroid/content/Context;I)Ljava/lang/String;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v2, "iivqlluAbiaGliyotogea"

    const-string/jumbo v2, "tgieGlvaqboipiolaAily"

    const/4 v4, 0x3

    const-string/jumbo v2, "liiAoaipgpaGovlebylit"

    const-string v2, "GoogleApiAvailability"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    packed-switch p1, :pswitch_data_0

    :pswitch_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo v0, "rxrceroeqddcneeeU o ps"

    const-string v0, "c sp Uxeddneeercrero o"

    const/4 v4, 0x3

    const-string v0, "Unexpected error code "

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object v1

    :pswitch_1
    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string p1, " fsuuur ht dedeTeamrtcoleosautdrer ta to  dcueissccenrsst af uee epl.rnintni eri"

    const-string p1, "cpumn e eitsreerir.eldtulsente nnhrTtcudtduaf a hciotera   arorusfsue eo stie cd"

    const/4 v4, 0x5

    const-string/jumbo p1, "usemifterpteasladdirdiestc oe nuu hc hst t uclenta trofucr T.re rasoeetnn idre e"

    const-string p1, "The current user profile is restricted and could not use authenticated features."

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo p1, "igsooc_vt_merlre_ioe_eee_prtloinslol_eofairdytsctocp"

    const-string/jumbo p1, "sd_ronyoo__fcmlcsti_rmtoeltgelepcoap_ee_vlsretriiieo"

    const/4 v4, 0x0

    const-string/jumbo p1, "v_tetbgtr_oosgscocip_tidnelesemeoylclpf_mr_lrai_eire"

    const-string p1, "common_google_play_services_restricted_profile_title"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p0, p1}, Lcom/google/android/gms/common/internal/k0;->h(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object p0

    :pswitch_2
    const/4 v4, 0x6

    const-string p1, "d.tnhcuaecoce eloibneii bspdnetugi   scou ndT"

    const-string/jumbo p1, "ntcesboep eehcbci.l tng dunao dTu  iii ndecso"

    const/4 v4, 0x2

    const-string p1, "c oi guptle  Toecn hnn.ees eidbddc niiosfpcau"

    const-string p1, "The specified account could not be signed in."

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x2

    const-string p1, "_vlnl__rqifcmsloetes_iigolsi_enicyten__pgdoaeoma"

    const-string p1, "common_google_play_services_sign_in_failed_title"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p0, p1}, Lcom/google/android/gms/common/internal/k0;->h(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object p0

    :pswitch_3
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string p0, "elslonnte  Oi ocy btpsteAoni net.vu oeaedncptac Itatn mau  of  stPmtooe"

    const-string p0, "  Omoeune  faecoI ot tyic nieev  .maopn o  tnaboptPotletnotatsedclAnstu"

    const/4 v4, 0x6

    const-string/jumbo p0, "sntmcbaon  lcc t meliotPtmAoep eep.ene stthatv     onIoadoOifayounott n"

    const-string p0, "One of the API components you attempted to connect to is not available."

    const/4 v4, 0x1

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object v1

    :pswitch_4
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo p0, "on tose ei ih ean uttndtaiT soesl plceiphocr"

    const-string p0, "ci irlspi pnetothoTeeu e opsthcil  dsate nan"

    const/4 v4, 0x1

    const-string/jumbo p0, "iei  baunoeeo ptlticiena s t hoTrs.hndtcsep "

    const-string p0, "The application is not licensed to the user."

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x6

    return-object v1

    :pswitch_5
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string p0, " ifloau sse dloane.r  e eteo aoreDrmdtero Pglfocrereporvdenlqiersc"

    const-string p0, "dace oerqPemotrrie d e  posa doioauloDrlnsvetf senrrfergecr e.oell"

    const/4 v4, 0x2

    const-string p0, "e serooprProira fl.lgi lodren dseeecesnerdi otarmet vleofr uaDep o"

    const-string p0, "Developer error occurred. Please see logs for detailed information"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object v1

    :pswitch_6
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo p0, "rv.r Cdiql oe iosiraiaol.Pegeneclns on saGtv cse"

    const-string p0, ".lsnenl iisgeets .nieaaorCld c vroiyaeP rocGv so"

    const/4 v4, 0x3

    const-string p0, "P sly  iroclnann.vsiero Gdvgva otaeieeoeicrClss "

    const-string p0, "Google Play services is invalid. Cannot recover."

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v1

    :pswitch_7
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo p0, "mnemotgoef on.dalrrmotenerseel er ssar  inrcfdiraorllPu tIaie  ed"

    const-string p0, "elnmdtsrner  sef eruioreaeoieonPatondmosdrfora.airrtg l l  eeI cl"

    const/4 v4, 0x2

    const-string p0, "er ooafirss ecorocPrenlmnlrigdsfoioentIrdrlne et eoue a aae . dtr"

    const-string p0, "Internal error occurred. Please see logs for detailed information"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v1

    :pswitch_8
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo p1, "r otqbe  ealeturuelNreotraPr.e.r rckseyc reo tdsror"

    const-string/jumbo p1, "rsueorqyrte.dke rrc erelNt taooo leaersrrec eu.Pr t"

    const/4 v4, 0x5

    const-string/jumbo p1, "reselruwareotr.rNrr.Pr leoe  q toekaurycee esrtc dt"

    const-string p1, "Network error occurred. Please retry request later."

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo p1, "tleoo_ppgroevlmrektocnce_wri_yoaetrbngerom___ss"

    const-string/jumbo p1, "retmcbasynocwegeon__erovp_iirroge_okm_lse_rtotl"

    const/4 v4, 0x7

    const-string/jumbo p1, "ire_pgeeqwnno_oy_olesm_toererlrttkgiomv_coa_lrc"

    const-string p1, "common_google_play_services_network_error_title"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p0, p1}, Lcom/google/android/gms/common/internal/k0;->h(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object p0

    :pswitch_9
    const/4 v4, 0x5

    const-string/jumbo p1, "nvspiaahcerenngi ccaueceucna ood. avvniicf  apta det  wPe.slondst uinwle  sdiincl"

    const-string/jumbo p1, "rou c uai eieinsa epdpcgvisdn i eehd aw ulca naaonoi eodciv.lvwaln.cectnstPnnct f"

    const/4 v4, 0x5

    const-string/jumbo p1, "lncmhtcirees. .seindtpalcva   afca ane  dcicole  tweinwiAoievPgdoiuudapnvc na osn"

    const-string p1, "An invalid account was specified when connecting. Please provide a valid account."

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string p1, "cesvo_ipda_aolpsilce_gonmvoayo_tegolnrmc_tutii_cn"

    const-string/jumbo p1, "otictaspeudcvocl__nl_gy_a_nopnoaeceivlltmr_iosmgi"

    const/4 v4, 0x0

    const-string/jumbo p1, "vtolnbecotiirai_gci_cvgyl_atosuanemcls_o_oemn_ple"

    const-string p1, "common_google_play_services_invalid_account_title"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p0, p1}, Lcom/google/android/gms/common/internal/k0;->h(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object p0

    :pswitch_a
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object v1

    :pswitch_b
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    sget p0, Lcom/google/android/gms/base/R$string;->common_google_play_services_enable_title:I

    const/4 v3, 0x1

    move v4, v3

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object p0

    :pswitch_c
    const/4 v4, 0x2

    sget p0, Lcom/google/android/gms/base/R$string;->common_google_play_services_update_title:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object p0

    :pswitch_d
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget p0, Lcom/google/android/gms/base/R$string;->common_google_play_services_install_title:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_a
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_3
        :pswitch_2
        :pswitch_a
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method private static g(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lcom/google/android/gms/common/internal/k0;->h(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x2

    sget p0, Lcom/google/android/gms/common/R$string;->common_google_play_services_unknown_issue:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object p1, p1, Landroid/content/res/Configuration;->locale:Ljava/util/Locale;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    aput-object p2, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1, p0, v0}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object p0
.end method

.method private static h(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    sget-object v0, Lcom/google/android/gms/common/internal/k0;->a:Landroidx/collection/m;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v1}, Landroidx/core/os/d;->a(Landroid/content/res/Configuration;)Landroidx/core/os/j;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Landroidx/core/os/j;->d(I)Ljava/util/Locale;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    sget-object v2, Lcom/google/android/gms/common/internal/k0;->b:Ljava/util/Locale;

    const/4 v5, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/util/Locale;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroidx/collection/m;->clear()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    sput-object v1, Lcom/google/android/gms/common/internal/k0;->b:Ljava/util/Locale;

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object v1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p0}, Lcom/google/android/gms/common/j;->j(Landroid/content/Context;)Landroid/content/res/Resources;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-nez p0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-object v1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo v2, "urqtis"

    const-string/jumbo v2, "srqtig"

    const/4 v5, 0x7

    const-string/jumbo v2, "rpsign"

    const-string/jumbo v2, "string"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v3, "sddgemgoqm.olgsrac.i.o"

    const-string v3, "dmsog.ago.lc.ndisogrme"

    const/4 v5, 0x6

    const-string/jumbo v3, "gdsreamomogscio..nolgd"

    const-string v3, "com.google.android.gms"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0, p1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v2, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const-string p0, "aGlmgbmieioAilpvtyail"

    const-string p0, "bavmgilGpealiloiAtoiy"

    const/4 v5, 0x4

    const-string p0, "aoiyotivGpliebAlglAoi"

    const-string p0, "GoogleApiAvailability"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v3, "iooisbrn ru eeMgsc"

    const-string/jumbo v3, "sMnroeo :i greicsu"

    const-string/jumbo v3, "ursniMuse sgice:r "

    const-string v3, "Missing resource: "

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-static {p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x7

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-object v1

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    if-eqz v2, :cond_4

    const/4 v5, 0x6

    const-string p0, "bGAtollpvaoaAbigyilii"

    const-string/jumbo p0, "iolaybiAgobivtiGaAlel"

    const/4 v5, 0x3

    const-string/jumbo p0, "oiaivpyAqligaoeilAtbl"

    const-string p0, "GoogleApiAvailability"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v3, " :sreumsooeerp  uyct"

    const-string v3, " : ueoumopcG yetserr"

    const/4 v5, 0x3

    const-string v3, "  mmep ryte:cGuoroes"

    const-string v3, "Got empty resource: "

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    return-object v1

    :cond_4
    const/4 v5, 0x5

    invoke-virtual {v0, p1, p0}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    throw p0
.end method
