.class public final Lcom/google/android/gms/common/internal/x;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static b:Lcom/google/android/gms/common/internal/x;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static final c:Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;


# instance fields
.field private a:Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    new-instance v6, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 v1, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/4 v2, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v3, 0x0

    or-int/2addr v8, v3

    const/4 v7, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/4 v4, 0x0

    const/4 v7, 0x7

    and-int/2addr v8, v7

    const/4 v5, 0x0

    move v8, v5

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x5

    invoke-direct/range {v0 .. v5}, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;-><init>(IZZII)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    sput-object v6, Lcom/google/android/gms/common/internal/x;->c:Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public static declared-synchronized b()Lcom/google/android/gms/common/internal/x;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-class v0, Lcom/google/android/gms/common/internal/x;

    const-class v0, Lcom/google/android/gms/common/internal/x;

    const/4 v3, 0x3

    const-class v0, Lcom/google/android/gms/common/internal/x;

    const-class v0, Lcom/google/android/gms/common/internal/x;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object v1, Lcom/google/android/gms/common/internal/x;->b:Lcom/google/android/gms/common/internal/x;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v1, Lcom/google/android/gms/common/internal/x;

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-direct {v1}, Lcom/google/android/gms/common/internal/x;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    sput-object v1, Lcom/google/android/gms/common/internal/x;->b:Lcom/google/android/gms/common/internal/x;

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v1, Lcom/google/android/gms/common/internal/x;->b:Lcom/google/android/gms/common/internal/x;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    throw v1
.end method


# virtual methods
.method public a()Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/x;->a:Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public final declared-synchronized c(Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;)V
    .locals 4
    .param p1    # Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    monitor-enter p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez p1, :cond_0

    :try_start_0
    const/4 v2, 0x5

    sget-object p1, Lcom/google/android/gms/common/internal/x;->c:Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;

    const/4 v3, 0x3

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/internal/x;->a:Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_0
    :try_start_1
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/x;->a:Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->getVersion()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;->getVersion()I

    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-ge v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    monitor-exit p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void

    :cond_2
    :goto_0
    :try_start_2
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/internal/x;->a:Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    monitor-exit p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    throw p1
.end method
