.class public final Lcom/google/android/gms/common/internal/u1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# annotations
.annotation build Landroidx/annotation/k1;
.end annotation


# instance fields
.field private final a:I

.field final synthetic b:Lcom/google/android/gms/common/internal/e;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/internal/e;I)V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/internal/u1;->b:Lcom/google/android/gms/common/internal/e;

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p2, p0, Lcom/google/android/gms/common/internal/u1;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "oKs@b~t@@@i@~ ~@av@n~ b t~ o~ulio@-~c y1/s@ 4o   ~~/r @~~~@d~f oM.~So~~i~~l@@@~@  @f@~m~@ b@ @  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/internal/u1;->b:Lcom/google/android/gms/common/internal/e;

    const/4 v3, 0x3

    and-int/2addr v4, v3

    if-nez p2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/16 p2, 0x10

    const/4 v3, 0x1

    shl-int/2addr v4, v3

    invoke-static {p1, p2}, Lcom/google/android/gms/common/internal/e;->zzk(Lcom/google/android/gms/common/internal/e;I)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/internal/e;->zzd(Lcom/google/android/gms/common/internal/e;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    monitor-enter p1

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/u1;->b:Lcom/google/android/gms/common/internal/e;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v1, "Bmrm..cdov..gldaSimreoonesrrcmnsmisgtIoeeramong.lnieo.kc"

    const-string/jumbo v1, "ogsIgnrlg..nnkeoomtvcmmmnecBmeadoS.rdosier..arciliooer.s"

    const/4 v4, 0x2

    const-string/jumbo v1, "lcmnoBm..veiacnaomdsoScetiorg.mgg.olnmeserdrro..nIoGoier"

    const-string v1, "com.google.android.gms.common.internal.IGmsServiceBroker"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {p2, v1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    instance-of v2, v1, Lcom/google/android/gms/common/internal/q;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v2, :cond_1

    const/4 v3, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    check-cast v1, Lcom/google/android/gms/common/internal/q;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v1, Lcom/google/android/gms/common/internal/j1;

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-direct {v1, p2}, Lcom/google/android/gms/common/internal/j1;-><init>(Landroid/os/IBinder;)V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/e;->zzh(Lcom/google/android/gms/common/internal/e;Lcom/google/android/gms/common/internal/q;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/internal/u1;->b:Lcom/google/android/gms/common/internal/e;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 p2, 0x0

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/android/gms/common/internal/u1;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1, v1, p2, v0}, Lcom/google/android/gms/common/internal/e;->zzl(ILandroid/os/Bundle;I)V

    const/4 v4, 0x1

    return-void

    :catchall_0
    move-exception p2

    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    throw p2
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/internal/u1;->b:Lcom/google/android/gms/common/internal/e;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/internal/e;->zzd(Lcom/google/android/gms/common/internal/e;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    monitor-enter p1

    :try_start_0
    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/internal/u1;->b:Lcom/google/android/gms/common/internal/e;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/e;->zzh(Lcom/google/android/gms/common/internal/e;Lcom/google/android/gms/common/internal/q;)V

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/android/gms/common/internal/u1;->b:Lcom/google/android/gms/common/internal/e;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/android/gms/common/internal/u1;->a:I

    const/4 v4, 0x4

    iget-object p1, p1, Lcom/google/android/gms/common/internal/e;->zzb:Landroid/os/Handler;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x6

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, v1, v0, v2}, Landroid/os/Handler;->obtainMessage(III)Landroid/os/Message;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    throw v0
.end method
