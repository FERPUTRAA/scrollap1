.class public abstract Lcom/google/android/gms/common/internal/DowngradeableSafeParcel;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;

# interfaces
.implements Lcom/google/android/gms/common/internal/ReflectedParcelable;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static final b:Ljava/lang/Object;


# instance fields
.field private a:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/gms/common/internal/DowngradeableSafeParcel;->b:Ljava/lang/Object;

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    iput-boolean v0, p0, Lcom/google/android/gms/common/internal/DowngradeableSafeParcel;->a:Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method protected static y2(Ljava/lang/String;)Z
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object p0, Lcom/google/android/gms/common/internal/DowngradeableSafeParcel;->b:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return p0

    :catchall_0
    move-exception v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    throw v0
.end method

.method protected static z2()Ljava/lang/Integer;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object v0, Lcom/google/android/gms/common/internal/DowngradeableSafeParcel;->b:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :catchall_0
    move-exception v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    throw v1
.end method


# virtual methods
.method protected abstract A2(I)Z
    .annotation build Lf4/a;
    .end annotation
.end method

.method public B2(Z)V
    .locals 2
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/gms/common/internal/DowngradeableSafeParcel;->a:Z

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method protected C2()Z
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/gms/common/internal/DowngradeableSafeParcel;->a:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method
