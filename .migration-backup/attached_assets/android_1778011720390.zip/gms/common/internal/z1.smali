.class final Lcom/google/android/gms/common/internal/z1;
.super Ljava/lang/Object;


# static fields
.field static final a:Ljava/util/concurrent/ExecutorService;


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {}, Lcom/google/android/gms/internal/common/zzh;->zza()Lcom/google/android/gms/internal/common/zze;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    new-instance v7, Lcom/google/android/gms/common/util/concurrent/b;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-string v0, "cssaxoltbCeElcku"

    const-string v0, "ClstloEbxcckerau"

    const/4 v10, 0x3

    const-string/jumbo v0, "lxumaerCackbcotE"

    const-string v0, "CallbackExecutor"

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-direct {v7, v0}, Lcom/google/android/gms/common/util/concurrent/b;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    new-instance v8, Ljava/util/concurrent/ThreadPoolExecutor;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    const/4 v1, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v2, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-wide/16 v3, 0x3c

    const-wide/16 v3, 0x3c

    const/4 v10, 0x7

    const-wide/16 v3, 0x3c

    const-wide/16 v3, 0x3c

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    new-instance v6, Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-direct {v6}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-direct/range {v0 .. v7}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    const/4 v9, 0x5

    shr-int/2addr v10, v9

    const/4 v0, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {v8, v0}, Ljava/util/concurrent/ThreadPoolExecutor;->allowCoreThreadTimeOut(Z)V

    const/4 v9, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {v8}, Ljava/util/concurrent/Executors;->unconfigurableExecutorService(Ljava/util/concurrent/ExecutorService;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    sput-object v0, Lcom/google/android/gms/common/internal/z1;->a:Ljava/util/concurrent/ExecutorService;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    return-void
.end method
