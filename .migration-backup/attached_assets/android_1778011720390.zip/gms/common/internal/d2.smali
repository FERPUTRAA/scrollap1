.class public final Lcom/google/android/gms/common/internal/d2;
.super Ljava/lang/Object;


# static fields
.field private static final f:Landroid/net/Uri;


# instance fields
.field private final a:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final b:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final c:Landroid/content/ComponentName;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final d:I

.field private final e:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    new-instance v0, Landroid/net/Uri$Builder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0}, Landroid/net/Uri$Builder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string v1, "cosnstn"

    const-string/jumbo v1, "ttscnon"

    const/4 v3, 0x7

    const-string/jumbo v1, "oncmttn"

    const-string v1, "content"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v1, "idgmo.r.adles.momengciragmooho"

    const-string/jumbo v1, "lsgmnoigaricmromogmad.he.cedo."

    const/4 v3, 0x6

    const-string v1, ".nooib.d.csoihoemggar.agrdmmle"

    const-string v1, "com.google.android.gms.chimera"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    sput-object v0, Lcom/google/android/gms/common/internal/d2;->f:Landroid/net/Uri;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/ComponentName;I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 p2, 0x0

    const/4 v1, 0x2

    move v0, p2

    move v0, p2

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/gms/common/internal/d2;->a:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/android/gms/common/internal/d2;->b:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/internal/d2;->c:Landroid/content/ComponentName;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/16 p1, 0x1081

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/common/internal/d2;->d:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/google/android/gms/common/internal/d2;->e:Z

    const/4 v0, 0x5

    shl-int/2addr v1, v0

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;IZ)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 p2, 0x1081

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p3, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string v0, ".smirouodgg.eoo.adocln"

    const-string v0, "dl.ao.on.mdcoregsimgoo"

    const/4 v2, 0x1

    const-string/jumbo v0, "mdgod.npgie.oc.mslooga"

    const-string v0, "com.google.android.gms"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, p1, v0, p2, p3}, Lcom/google/android/gms/common/internal/d2;-><init>(Ljava/lang/String;Ljava/lang/String;IZ)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;IZ)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/internal/d2;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x7

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->l(Ljava/lang/String;)Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/gms/common/internal/d2;->b:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/internal/d2;->c:Landroid/content/ComponentName;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/16 p1, 0x1081

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/gms/common/internal/d2;->d:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-boolean p4, p0, Lcom/google/android/gms/common/internal/d2;->e:Z

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final a()Landroid/content/ComponentName;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@o~@~ @~qr/~l@~ @ fSt  ~~i.f~M@y@o~s ud l~ ~ @~ a@v bmnb~~@  ~~~@K4@coo-~@o@b@t@@ ~ /~@@ ii 1o@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/d2;->c:Landroid/content/ComponentName;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public final b(Landroid/content/Context;)Landroid/content/Intent;
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string/jumbo v0, "nossgnnnSitoifbtoceCat"

    const-string/jumbo v0, "itiaobnnoCnSgettocfsCn"

    const/4 v6, 0x1

    const-string v0, "SComtnntCisecnuifgnaot"

    const-string v0, "ConnectionStatusConfig"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/internal/d2;->a:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-boolean v1, p0, Lcom/google/android/gms/common/internal/d2;->e:Z

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    new-instance v1, Landroid/os/Bundle;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/google/android/gms/common/internal/d2;->a:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v4, "enBdorcoleeuiynKcvsetA"

    const-string/jumbo v4, "serviceActionBundleKey"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v1, v4, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    sget-object v3, Lcom/google/android/gms/common/internal/d2;->f:Landroid/net/Uri;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string/jumbo v4, "ueelvbcaIlnetinst"

    const-string/jumbo v4, "nsveIcultitaeleCn"

    const/4 v6, 0x2

    const-string v4, "caCresunnletvtiel"

    const-string/jumbo v4, "serviceIntentCall"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p1, v3, v4, v2, v1}, Landroid/content/ContentResolver;->call(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v1, "ieislaeptminta nle r:oidfuptco  Dn"

    const-string v1, "aumrai pn:eiy f tettlnsiodeconi lD"

    const/4 v6, 0x4

    const-string v1, "ele:itdfqi ma nteans urlntoiy cDni"

    const-string v1, "Dynamic intent resolution failed: "

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-nez p1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    goto :goto_1

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string/jumbo v1, "oisqeensetevenscreItpRKn"

    const-string/jumbo v1, "netveepsqIcesoterKeiRnsn"

    const/4 v6, 0x5

    const-string/jumbo v1, "vynmoKtneRscsentespereIi"

    const-string/jumbo v1, "serviceResponseIntentKey"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    check-cast p1, Landroid/content/Intent;

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez v2, :cond_1

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/internal/d2;->a:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v1, "a scooytpor  ktedinDnflom afnr enuoia:o t iic"

    const-string v1, "afs:rroianoealtlkiinpntcu fm t ooce id  n Dyo"

    const/4 v6, 0x5

    const-string/jumbo v1, "rm aibi loe  cfo cy teuoknn:oDirptfnnot falia"

    const-string v1, "Dynamic lookup for intent failed for action: "

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-nez v2, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/internal/d2;->a:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance v0, Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {v0, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/internal/d2;->b:Ljava/lang/String;

    const/4 v5, 0x0

    shr-int/2addr v6, v5

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    return-object p1

    :cond_2
    const/4 v6, 0x6

    new-instance p1, Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {p1}, Landroid/content/Intent;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/internal/d2;->c:Landroid/content/ComponentName;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v2

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-object v2
.end method

.method public final c()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/internal/d2;->b:Ljava/lang/String;

    const/4 v2, 0x4

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-ne p0, p1, :cond_0

    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    return v0

    :cond_0
    const/4 v5, 0x1

    instance-of v1, p1, Lcom/google/android/gms/common/internal/d2;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    if-nez v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    return v2

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    check-cast p1, Lcom/google/android/gms/common/internal/d2;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/internal/d2;->a:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v3, p1, Lcom/google/android/gms/common/internal/d2;->a:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v1, v3}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v1, :cond_2

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/internal/d2;->b:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v3, p1, Lcom/google/android/gms/common/internal/d2;->b:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v1, v3}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/internal/d2;->c:Landroid/content/ComponentName;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v3, p1, Lcom/google/android/gms/common/internal/d2;->c:Landroid/content/ComponentName;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v1, v3}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-boolean v1, p0, Lcom/google/android/gms/common/internal/d2;->e:Z

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-boolean p1, p1, Lcom/google/android/gms/common/internal/d2;->e:Z

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-ne v1, p1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    return v0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v2
.end method

.method public final hashCode()I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/d2;->a:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v1, 0x5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    aput-object v0, v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/internal/d2;->b:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    aput-object v2, v1, v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v0, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/android/gms/common/internal/d2;->c:Landroid/content/ComponentName;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    aput-object v2, v1, v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/16 v0, 0x1081

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v2, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    aput-object v0, v1, v2

    const/4 v4, 0x7

    iget-boolean v0, p0, Lcom/google/android/gms/common/internal/d2;->e:Z

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x4

    const/4 v4, 0x3

    const/4 v3, 0x6

    aput-object v0, v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/google/android/gms/common/internal/t;->c([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x5

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/d2;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/internal/d2;->c:Landroid/content/ComponentName;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/d2;->c:Landroid/content/ComponentName;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/content/ComponentName;->flattenToString()Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method
