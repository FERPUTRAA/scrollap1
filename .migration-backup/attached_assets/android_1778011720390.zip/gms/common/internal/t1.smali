.class public final Lcom/google/android/gms/common/internal/t1;
.super Lcom/google/android/gms/common/internal/i1;


# annotations
.annotation build Landroidx/annotation/k1;
.end annotation


# instance fields
.field private a:Lcom/google/android/gms/common/internal/e;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final b:I


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/internal/e;I)V
    .locals 2
    .param p1    # Lcom/google/android/gms/common/internal/e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/i1;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/internal/t1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p2, p0, Lcom/google/android/gms/common/internal/t1;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final Q(ILandroid/os/Bundle;)V
    .locals 3
    .param p2    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/g;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@~ im~r. @~l @i~@~4~t~~ ~@~@  ~o~~o@ @fo@MKtb~sf@ y~c~@o/@  oub~ o@l@ 1@@~/ ni @ av- ~@@d~b@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/Exception;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/lang/Exception;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const-string p2, "GmimCntes"

    const-string p2, "eistmCsGn"

    const/4 v2, 0x0

    const-string/jumbo p2, "tsieomlCG"

    const-string p2, "GmsClient"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string/jumbo v0, "kuiCcbblreidnroaa meeAdopacclnteenioi,leancgogcivt co epamV ernddt"

    const-string/jumbo v0, "oalmi,dpeCnctengaocoontdkoeigvdltiiccc eadcueV nenA areerilalrp mb"

    const/4 v2, 0x2

    const-string/jumbo v0, "received deprecated onAccountValidationComplete callback, ignoring"

    const/4 v2, 0x0

    invoke-static {p2, v0, p1}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v2, 0x4

    return-void
.end method

.method public final l0(ILandroid/os/IBinder;Lcom/google/android/gms/common/internal/zzk;)V
    .locals 4
    .param p2    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/gms/common/internal/zzk;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/g;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/internal/t1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v1, " aetveueoptpoo e iannteidoRCtontottlce tCaoleclnSymnbIhnPrio elolccr  enolnfisnI egemocW"

    const-string v1, "Ca  otWmnlncSmlpny nrlocPotinef tCno eRreotavtoltg cicnio shndeInoelceIelbtieoea eopeeot"

    const/4 v3, 0x7

    const-string/jumbo v1, "ttneoeaptl nmtoono iepoIcnreIcmeoselgWf eCtl eCaeecieylo lro hclPntnnodnSnRpte bvi actic"

    const-string/jumbo v1, "onPostInitCompleteWithConnectionInfo can be called only once per call togetRemoteService"

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0, p3}, Lcom/google/android/gms/common/internal/e;->zzj(Lcom/google/android/gms/common/internal/e;Lcom/google/android/gms/common/internal/zzk;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object p3, p3, Lcom/google/android/gms/common/internal/zzk;->a:Landroid/os/Bundle;

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/gms/common/internal/t1;->p(ILandroid/os/IBinder;Landroid/os/Bundle;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method public final p(ILandroid/os/IBinder;Landroid/os/Bundle;)V
    .locals 4
    .param p2    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/g;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/internal/t1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v1, "icpanep qelot b ingeltndrts cetccoerbee ly loaRlovaCScmtIto omeneln e o"

    const-string v1, "Rtlytb pmococoniCtelsevaene c tnlcIltaret o ndlm e gaeeoPcerpiobS no le"

    const/4 v3, 0x6

    const-string v1, "Clstg tleleninccnes pntR laoeerePo ecoycI eobtevedioS reatmtl lao  mpcn"

    const-string/jumbo v1, "onPostInitComplete can be called only once per call to getRemoteService"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/t1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/android/gms/common/internal/t1;->b:I

    const/4 v3, 0x4

    invoke-virtual {v0, p1, p2, p3, v1}, Lcom/google/android/gms/common/internal/e;->onPostInitHandler(ILandroid/os/IBinder;Landroid/os/Bundle;I)V

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/internal/t1;->a:Lcom/google/android/gms/common/internal/e;

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method
