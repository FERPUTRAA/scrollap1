.class final Lcom/google/android/gms/common/internal/l0;
.super Lcom/google/android/gms/common/internal/o0;


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Landroid/app/Activity;

.field final synthetic c:I


# direct methods
.method constructor <init>(Landroid/content/Intent;Landroid/app/Activity;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/internal/l0;->a:Landroid/content/Intent;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/google/android/gms/common/internal/l0;->b:Landroid/app/Activity;

    iput p3, p0, Lcom/google/android/gms/common/internal/l0;->c:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/o0;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "n@sro~yo ~ .o @l~/o f~~~ @K~4 oso~@~@@i@-@ @u @@i~c b~~ i@ @M@@~~ m~@at@ ~v~~/bl~ @@~ ~@Sf1 ~d b"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/google/android/gms/common/internal/l0;->a:Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    shr-int/2addr v4, v3

    iget-object v1, p0, Lcom/google/android/gms/common/internal/l0;->b:Landroid/app/Activity;

    const/4 v4, 0x7

    iget v2, p0, Lcom/google/android/gms/common/internal/l0;->c:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, v0, v2}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method
