.class public final Lcom/google/android/gms/common/internal/w1;
.super Lcom/google/android/gms/common/internal/f1;


# instance fields
.field final synthetic g:Lcom/google/android/gms/common/internal/e;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/internal/e;ILandroid/os/Bundle;)V
    .locals 2
    .param p2    # I
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/g;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/internal/w1;->g:Lcom/google/android/gms/common/internal/e;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 p3, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/gms/common/internal/f1;-><init>(Lcom/google/android/gms/common/internal/e;ILandroid/os/Bundle;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected final f(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "f s~~@iu y@n~@ b ~@~~@i@~~//f~  mt@@to ~l1  Si~@b 4 @s-@a K@oco rd~~b~ @~@ v@@~~Moo@~~ ~l@ @.~o~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/w1;->g:Lcom/google/android/gms/common/internal/e;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/e;->enableLocalFallback()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/internal/w1;->g:Lcom/google/android/gms/common/internal/e;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/e;->zzo(Lcom/google/android/gms/common/internal/e;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/internal/w1;->g:Lcom/google/android/gms/common/internal/e;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/16 v0, 0x10

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/e;->zzk(Lcom/google/android/gms/common/internal/e;I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/w1;->g:Lcom/google/android/gms/common/internal/e;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, v0, Lcom/google/android/gms/common/internal/e;->zzc:Lcom/google/android/gms/common/internal/e$c;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/internal/e$c;->a(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/w1;->g:Lcom/google/android/gms/common/internal/e;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/e;->onConnectionFailed(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method protected final g()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/w1;->g:Lcom/google/android/gms/common/internal/e;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, v0, Lcom/google/android/gms/common/internal/e;->zzc:Lcom/google/android/gms/common/internal/e$c;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object v1, Lcom/google/android/gms/common/ConnectionResult;->C:Lcom/google/android/gms/common/ConnectionResult;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Lcom/google/android/gms/common/internal/e$c;->a(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    return v0
.end method
