.class public final Lcom/google/android/gms/common/internal/v1;
.super Lcom/google/android/gms/common/internal/f1;


# instance fields
.field public final g:Landroid/os/IBinder;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field final synthetic h:Lcom/google/android/gms/common/internal/e;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/internal/e;ILandroid/os/IBinder;Landroid/os/Bundle;)V
    .locals 2
    .param p2    # I
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/g;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2, p4}, Lcom/google/android/gms/common/internal/f1;-><init>(Lcom/google/android/gms/common/internal/e;ILandroid/os/Bundle;)V

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/google/android/gms/common/internal/v1;->g:Landroid/os/IBinder;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected final f(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "fos1v@mc~d@~@ ~/ ~bs~  @4@ n~~~~o ~ i@~Sifb~ @ob@@@ l~/~o@ @~a @~t@u.-@@~~Mo @~ ~r~K@ yo~l@t i  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/e;->zzc(Lcom/google/android/gms/common/internal/e;)Lcom/google/android/gms/common/internal/e$b;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/android/gms/common/internal/e;->zzc(Lcom/google/android/gms/common/internal/e;)Lcom/google/android/gms/common/internal/e$b;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lcom/google/android/gms/common/internal/e$b;->c(Lcom/google/android/gms/common/ConnectionResult;)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/internal/e;->onConnectionFailed(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method protected final g()Z
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v0, "ssimlGeCm"

    const-string/jumbo v0, "itsseCGlm"

    const/4 v7, 0x4

    const-string/jumbo v0, "mleCotnGi"

    const-string v0, "GmsClient"

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x3

    move v6, v1

    move v6, v1

    :try_start_0
    const/4 v7, 0x5

    iget-object v2, p0, Lcom/google/android/gms/common/internal/v1;->g:Landroid/os/IBinder;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v2}, Landroid/os/IBinder;->getInterfaceDescriptor()Ljava/lang/String;

    move-result-object v2
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v3, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v7, 0x2

    const/4 v6, 0x1

    invoke-virtual {v3}, Lcom/google/android/gms/common/internal/e;->getServiceDescriptor()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-nez v3, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v3}, Lcom/google/android/gms/common/internal/e;->getServiceDescriptor()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string/jumbo v5, "s icebmrisp:vademc teorcsimt "

    const-string/jumbo v5, "s  mmrrest:pdcvmo sriitieecca"

    const/4 v7, 0x5

    const-string/jumbo v5, "p tdceu iemcirmrrsistes :vahc"

    const-string/jumbo v5, "service descriptor mismatch: "

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string v3, " vpso"

    const-string/jumbo v3, "vs  o"

    const/4 v7, 0x1

    const-string v3, "  vq."

    const-string v3, " vs. "

    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x0

    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x0

    move v7, v6

    return v1

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/internal/v1;->g:Landroid/os/IBinder;

    const/4 v6, 0x0

    shl-int/2addr v7, v6

    invoke-virtual {v0, v2}, Lcom/google/android/gms/common/internal/e;->createServiceInterface(Landroid/os/IBinder;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v0, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/4 v3, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v4, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v2, v3, v4, v0}, Lcom/google/android/gms/common/internal/e;->zzn(Lcom/google/android/gms/common/internal/e;IILandroid/os/IInterface;)Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-nez v2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v3, 0x3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v2, v3, v4, v0}, Lcom/google/android/gms/common/internal/e;->zzn(Lcom/google/android/gms/common/internal/e;IILandroid/os/IInterface;)Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v0, :cond_3

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/e;->zzg(Lcom/google/android/gms/common/internal/e;Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/e;->getConnectionHint()Landroid/os/Bundle;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/e;->zzb(Lcom/google/android/gms/common/internal/e;)Lcom/google/android/gms/common/internal/e$a;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v0, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/v1;->h:Lcom/google/android/gms/common/internal/e;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/internal/e;->zzb(Lcom/google/android/gms/common/internal/e;)Lcom/google/android/gms/common/internal/e$a;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-interface {v0, v1}, Lcom/google/android/gms/common/internal/e$a;->a(Landroid/os/Bundle;)V

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 v0, 0x1

    const/4 v7, 0x5

    return v0

    :cond_3
    const/4 v7, 0x0

    return v1

    :catch_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v2, " sslay pevbbddiorebre"

    const-string/jumbo v2, "iir dbvlrde esybopaeb"

    const/4 v7, 0x5

    const-string v2, " svmrrpbe cadodieiyle"

    const-string/jumbo v2, "service probably died"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    return v1
.end method
