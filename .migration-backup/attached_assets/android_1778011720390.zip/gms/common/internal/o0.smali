.class public abstract Lcom/google/android/gms/common/internal/o0;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    return-void
.end method

.method public static b(Landroid/app/Activity;Landroid/content/Intent;I)Lcom/google/android/gms/common/internal/o0;
    .locals 3
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s~@o ~i @o~@~@d@~@~@@ ~@ ~tu4 bof ~i@~~@f~   y@@b/ir~ t1~/ ~nc.a@ ~s~ l-@~@ ~~@MKo@~l S~bv@ oo"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Lcom/google/android/gms/common/internal/l0;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0, p1, p0, p2}, Lcom/google/android/gms/common/internal/l0;-><init>(Landroid/content/Intent;Landroid/app/Activity;I)V

    const/4 v2, 0x1

    return-object v0
.end method

.method public static c(Landroidx/fragment/app/Fragment;Landroid/content/Intent;I)Lcom/google/android/gms/common/internal/o0;
    .locals 3
    .param p0    # Landroidx/fragment/app/Fragment;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance v0, Lcom/google/android/gms/common/internal/m0;

    const/4 v2, 0x2

    invoke-direct {v0, p1, p0, p2}, Lcom/google/android/gms/common/internal/m0;-><init>(Landroid/content/Intent;Landroidx/fragment/app/Fragment;I)V

    const/4 v2, 0x2

    return-object v0
.end method

.method public static d(Lcom/google/android/gms/common/api/internal/m;Landroid/content/Intent;I)Lcom/google/android/gms/common/internal/o0;
    .locals 3
    .param p0    # Lcom/google/android/gms/common/api/internal/m;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance p2, Lcom/google/android/gms/common/internal/n0;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-direct {p2, p1, p0, v0}, Lcom/google/android/gms/common/internal/n0;-><init>(Landroid/content/Intent;Lcom/google/android/gms/common/api/internal/m;I)V

    const/4 v1, 0x0

    or-int/2addr v2, v1

    return-object p2
.end method


# virtual methods
.method protected abstract a()V
.end method

.method public final onClick(Landroid/content/DialogInterface;I)V
    .locals 6

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/o0;->a()V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    goto :goto_0

    :catchall_0
    move-exception p2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto :goto_1

    :catch_0
    move-exception p2

    :try_start_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string v0, " romnett uetF.trslianio silatdotns"

    const-string/jumbo v0, "t sltdet.aornuieont Fto ssatr inil"

    const/4 v5, 0x7

    const-string/jumbo v0, "ineion unisa lt.r dtaerlesoto Ftto"

    const-string v0, "Failed to start resolution intent."

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo v1, "sn ssb oolSu r Ab at esomgn sv itucroFPe tellhcsrnia huyotGlesgnth looleirao. us oT wP sieetPerlnmawyn  toecueeltiiedes itrtgoGcenooa oco i aomIrG.tgitonv  ys n"

    const-string v1, "e cmnrieodeevauePs sg egoist ShosianGogtlt ceo ygrwei.nhnlscv Gc oes et oomttytro  IutAsbeinTneoct   alrs ueG.iyol nmtesPli unltlFo  lo so  wooruraatohnliPi asr"

    const/4 v5, 0x0

    const-string v1, "eonln.uola nto gr u hr w m htisnin Goeuvmeitsu  osyhseu  Togtglco l ltb wui en rgreessoaFoIlolnen ePel latoiysroAotiG oaiey doctstcrsarceS ovPnsioeet tnG .cPits"

    const-string v1, "Failed to start resolution intent. This may occur when resolving Google Play services connection issues on emulators with Google APIs but not Google Play Store."

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    sget-object v2, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v3, "eenrogi"

    const/4 v5, 0x0

    const-string/jumbo v3, "pnireeg"

    const-string/jumbo v3, "generic"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-ne v3, v2, :cond_0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v1, "eRgletbDqcadii"

    const-string v1, "DidcebioRlaegt"

    const-string/jumbo v1, "gosdeilRicateD"

    const-string v1, "DialogRedirect"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v1, v0, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    const/4 v5, 0x2

    return-void

    :goto_1
    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    const/4 v5, 0x0

    throw p2
.end method
