.class public abstract Lcom/google/android/gms/common/internal/p2;
.super Lcom/google/android/gms/internal/common/zzb;

# interfaces
.implements Lcom/google/android/gms/common/internal/g1;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string/jumbo v0, "gmsg.rCneogoo.iis.radmm.ntselce.dDnamtoa.crlotIa"

    const-string v0, ".dsmotgelomagmnangar.iI.nro..rdolteoit.DoasCeccm"

    const/4 v2, 0x1

    const-string v0, ".inmceo.mmC.otoamDcmendgar.drlelgo.Iagoottn.snai"

    const-string v0, "com.google.android.gms.common.internal.ICertData"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/common/zzb;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public static a(Landroid/os/IBinder;)Lcom/google/android/gms/common/internal/g1;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~~oo@d/~~Mbsu~ @ @@r  ~f @@@o@~  @f@ /~4 ~o@onSy@-~~ ~o i~@ lm~ iK~~ob~~v@@@ @b~c@ l1t a~~i@~.t"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    const-string v0, ".Cacnbo.sndDnmagogl.edr.oaanm.ocoemtIrtomgmt.eli"

    const-string v0, ".nomadogrrIcecirt..amg.aedgmn.nootmsloD.mtaoCnel"

    const/4 v3, 0x4

    const-string v0, "eetnotuaim.rmer.ooaarst.ogDl.mnCcacmodinnI.lo.gd"

    const-string v0, "com.google.android.gms.common.internal.ICertData"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    instance-of v1, v0, Lcom/google/android/gms/common/internal/g1;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast v0, Lcom/google/android/gms/common/internal/g1;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/common/internal/o2;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/internal/o2;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0
.end method


# virtual methods
.method protected final zza(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p2, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eq p1, p2, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    const/4 p4, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x0

    if-eq p1, p4, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x6

    return p1

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x0

    invoke-interface {p0}, Lcom/google/android/gms/common/internal/g1;->zzc()I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    goto :goto_0

    :cond_1
    const/4 v1, 0x3

    invoke-interface {p0}, Lcom/google/android/gms/common/internal/g1;->zzd()Lcom/google/android/gms/dynamic/d;

    move-result-object p1

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p3, p1}, Lcom/google/android/gms/internal/common/zzc;->zze(Landroid/os/Parcel;Landroid/os/IInterface;)V

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p2
.end method
