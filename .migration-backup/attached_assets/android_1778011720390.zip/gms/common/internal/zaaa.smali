.class public final Lcom/google/android/gms/common/internal/zaaa;
.super Landroid/widget/Button;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p2, 0x0

    const/4 v2, 0x2

    const v0, 0x1010048

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2, v0}, Landroid/widget/Button;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method private static final b(IIII)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @si@d ~tu~y@.  ~i~ fi/o@m~/ ~c4@~@lo@~   @b~r@@@ ~l~1@Mo @~@~b~~~@~  t~~ona@~@ ~ fv@K-s@o@  b~o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    if-eqz p0, :cond_2

    const/4 v1, 0x5

    const/4 p1, 0x1

    const/4 v1, 0x6

    const/4 p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    if-eq p0, p1, :cond_1

    const/4 v0, 0x2

    move v1, v0

    const/4 p1, 0x1

    const/4 p1, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    if-ne p0, p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p3

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    const-string/jumbo p3, "wnem cl: mssUorhnkooen"

    const-string/jumbo p3, "lcsnocn ore on:kUwhesm"

    const-string p3, ":r komenswnooelnoU ch "

    const-string p3, "Unknown color scheme: "

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    throw p1

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return p2

    :cond_2
    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p1
.end method


# virtual methods
.method public final a(Landroid/content/res/Resources;II)V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    sget-object v0, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/high16 v0, 0x41600000    # 14.0f

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    const/4 v5, 0x5

    xor-int/2addr v6, v5

    const/high16 v1, 0x42400000    # 48.0f

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    mul-float/2addr v0, v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/high16 v1, 0x3f000000    # 0.5f

    const/4 v6, 0x4

    const/4 v5, 0x7

    add-float/2addr v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    float-to-int v0, v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setMinHeight(I)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Landroid/widget/TextView;->setMinWidth(I)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    sget v0, Lcom/google/android/gms/base/R$drawable;->common_google_signin_btn_icon_dark:I

    const/4 v5, 0x0

    move v6, v5

    sget v1, Lcom/google/android/gms/base/R$drawable;->common_google_signin_btn_icon_light:I

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p3, v0, v1, v1}, Lcom/google/android/gms/common/internal/zaaa;->b(IIII)I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    sget v1, Lcom/google/android/gms/base/R$drawable;->common_google_signin_btn_text_dark:I

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    sget v2, Lcom/google/android/gms/base/R$drawable;->common_google_signin_btn_text_light:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p3, v1, v2, v2}, Lcom/google/android/gms/common/internal/zaaa;->b(IIII)I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo v2, "i sUobonb k ztnnwume:"

    const-string v2, " oumtbwnnzi  kneso:Un"

    const/4 v6, 0x4

    const-string v2, "Uz nkbu :woueios tnnt"

    const-string v2, "Unknown button size: "

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v3, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v4, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz p2, :cond_1

    const/4 v6, 0x3

    if-eq p2, v4, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-ne p2, v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    move v6, v5

    throw p1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    move v0, v1

    move v0, v1

    const/4 v6, 0x0

    move v0, v1

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v0}, Landroidx/core/graphics/drawable/d;->r(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    sget v1, Lcom/google/android/gms/base/R$color;->common_google_signin_btn_tint:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p1, v1}, Landroid/content/res/Resources;->getColorStateList(I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v0, v1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget-object v1, Landroid/graphics/PorterDuff$Mode;->SRC_ATOP:Landroid/graphics/PorterDuff$Mode;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0, v1}, Landroidx/core/graphics/drawable/d;->p(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v6, 0x4

    sget v0, Lcom/google/android/gms/base/R$color;->common_google_signin_btn_text_dark:I

    const/4 v5, 0x5

    move v6, v5

    sget v1, Lcom/google/android/gms/base/R$color;->common_google_signin_btn_text_light:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {p3, v0, v1, v1}, Lcom/google/android/gms/common/internal/zaaa;->b(IIII)I

    move-result p3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1, p3}, Landroid/content/res/Resources;->getColorStateList(I)Landroid/content/res/ColorStateList;

    move-result-object p3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    check-cast p3, Landroid/content/res/ColorStateList;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0, p3}, Landroid/widget/TextView;->setTextColor(Landroid/content/res/ColorStateList;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 p3, 0x5

    const/4 p3, 0x0

    const/4 v5, 0x6

    or-int/2addr v6, v5

    if-eqz p2, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eq p2, v4, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-ne p2, v3, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p0, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto :goto_1

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v5, 0x4

    invoke-virtual {p3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    throw p1

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    sget p2, Lcom/google/android/gms/base/R$string;->common_signin_button_text_long:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    goto :goto_1

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    sget p2, Lcom/google/android/gms/base/R$string;->common_signin_button_text:I

    const/4 v6, 0x6

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :goto_1
    const/4 v6, 0x6

    invoke-virtual {p0, p3}, Landroid/widget/TextView;->setTransformationMethod(Landroid/text/method/TransformationMethod;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/util/l;->l(Landroid/content/Context;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz p1, :cond_5

    const/4 v6, 0x1

    const/16 p1, 0x13

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setGravity(I)V

    :cond_5
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-void
.end method
