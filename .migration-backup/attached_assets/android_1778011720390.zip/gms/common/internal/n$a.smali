.class public abstract Lcom/google/android/gms/common/internal/n$a;
.super Lcom/google/android/gms/internal/common/zzb;

# interfaces
.implements Lcom/google/android/gms/common/internal/n;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/internal/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const-string/jumbo v0, "noscIanorcdncoAi.ms.edsnts.o.ugomeocort.ggcalri.mclsnAm"

    const-string/jumbo v0, "nesnIsAotcelggioAr..sgcocndomm..cmdmnalccrineu.tso.oaro"

    const/4 v2, 0x5

    const-string v0, "doamom.iimn.rrcnudrgoIoleegloc.asnotsgmocc.neocn.mcs.At"

    const-string v0, "com.google.android.gms.common.internal.IAccountAccessor"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/common/zzb;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public static a(Landroid/os/IBinder;)Lcom/google/android/gms/common/internal/n;
    .locals 4
    .param p0    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@~ o~~ot@oa/l1t@ ~@@ fl~ d~/ ~ @ @@b ~@.@f-@@o~ 4b~ii~@urS K o~@ c@@y~bm~@n~~@~~sv@~   oMo@~  ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const-string/jumbo v0, "ileccb..umIlocanosoeceanintAmrgdmmnosrtocAm.g.og.cnods."

    const-string/jumbo v0, "oanmeonu.nlncloeccom.dnomtgrmI.acs.cstAecorgsidio.gm.oA"

    const/4 v3, 0x3

    const-string v0, "eAlnolunoA.cmocmcgmtdoreoo.mrnncessnsac.idi.cogoaut.r.g"

    const-string v0, "com.google.android.gms.common.internal.IAccountAccessor"

    const/4 v2, 0x1

    move v3, v2

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    instance-of v1, v0, Lcom/google/android/gms/common/internal/n;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Lcom/google/android/gms/common/internal/n;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_1
    const/4 v2, 0x1

    move v3, v2

    new-instance v0, Lcom/google/android/gms/common/internal/m2;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/internal/m2;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x3

    return-object v0
.end method


# virtual methods
.method protected final zza(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 2
    .param p2    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 p2, 0x2

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    if-ne p1, p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-interface {p0}, Lcom/google/android/gms/common/internal/n;->zzb()Landroid/accounts/Account;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p3, p1}, Lcom/google/android/gms/internal/common/zzc;->zzd(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    const/4 v0, 0x6

    xor-int/2addr v1, v0

    const/4 p1, 0x2

    const/4 p1, 0x1

    const/4 v1, 0x4

    return p1

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v0, 0x7

    shr-int/2addr v1, v0

    return p1
.end method
