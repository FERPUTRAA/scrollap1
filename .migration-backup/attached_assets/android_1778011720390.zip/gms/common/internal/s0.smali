.class public final Lcom/google/android/gms/common/internal/s0;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Handler$Callback;


# instance fields
.field private final a:Lcom/google/android/gms/common/internal/r0;
    .annotation runtime Lm9/c;
    .end annotation
.end field

.field private final b:Ljava/util/ArrayList;

.field final c:Ljava/util/ArrayList;
    .annotation build Landroidx/annotation/k1;
    .end annotation
.end field

.field private final f:Ljava/util/ArrayList;

.field private volatile g:Z

.field private final h:Ljava/util/concurrent/atomic/AtomicInteger;

.field private i:Z

.field private final j:Landroid/os/Handler;

.field private final k:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/os/Looper;Lcom/google/android/gms/common/internal/r0;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/android/gms/common/internal/s0;->b:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/internal/s0;->c:Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/gms/common/internal/s0;->f:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-boolean v0, p0, Lcom/google/android/gms/common/internal/s0;->g:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/google/android/gms/common/internal/s0;->h:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/google/android/gms/common/internal/s0;->i:Z

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/internal/s0;->k:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object p2, p0, Lcom/google/android/gms/common/internal/s0;->a:Lcom/google/android/gms/common/internal/r0;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance p2, Lcom/google/android/gms/internal/base/zau;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p2, p1, p0}, Lcom/google/android/gms/internal/base/zau;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object p2, p0, Lcom/google/android/gms/common/internal/s0;->j:Landroid/os/Handler;

    const/4 v3, 0x2

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/google/android/gms/common/internal/s0;->g:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->h:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public final b()V
    .locals 3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/google/android/gms/common/internal/s0;->g:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public final c(Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 7
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->j:Landroid/os/Handler;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string/jumbo v1, "tdsandsaou e  lc eaeneetFrCncubieono nholtrlthlald nrsyoH mne"

    const-string v1, "edscrut a Fnde auhlnnterost oceohtyoiaC n nrebdonHmeelna  lll"

    const/4 v6, 0x5

    const-string/jumbo v1, "onConnectionFailure must only be called on the Handler thread"

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->i(Landroid/os/Handler;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->j:Landroid/os/Handler;

    const/4 v6, 0x2

    const/4 v1, 0x4

    const/4 v6, 0x4

    const/4 v1, 0x1

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->k:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v1, Ljava/util/ArrayList;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/google/android/gms/common/internal/s0;->f:Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/google/android/gms/common/internal/s0;->h:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v3, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    check-cast v3, Lcom/google/android/gms/common/api/l$c;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-boolean v4, p0, Lcom/google/android/gms/common/internal/s0;->g:Z

    const/4 v6, 0x7

    const/4 v5, 0x6

    if-eqz v4, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v4, p0, Lcom/google/android/gms/common/internal/s0;->h:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eq v4, v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_1

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x2

    iget-object v4, p0, Lcom/google/android/gms/common/internal/s0;->f:Ljava/util/ArrayList;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v4, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-interface {v3, p1}, Lcom/google/android/gms/common/api/internal/q;->c(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    return-void

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    throw p1
.end method

.method public final d(Landroid/os/Bundle;)V
    .locals 7
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->j:Landroid/os/Handler;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string/jumbo v1, "nmlmr ntsntHuscaoi cmocceroSo ednneytolsah hu Ceednlta nel eb"

    const-string/jumbo v1, "tndmcercstoto bdthhrluoeeilHemy oCaSnnsaa  eeslclec  nnnd nuo"

    const/4 v6, 0x0

    const-string/jumbo v1, "t  ootnecsnlanonrce l  ss etiSrdbalheCcehaudy nldeeon ncoHutm"

    const-string/jumbo v1, "onConnectionSuccess must only be called on the Handler thread"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->i(Landroid/os/Handler;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->k:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-boolean v1, p0, Lcom/google/android/gms/common/internal/s0;->i:Z

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    xor-int/2addr v1, v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->x(Z)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s0;->j:Landroid/os/Handler;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    iput-boolean v2, p0, Lcom/google/android/gms/common/internal/s0;->i:Z

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s0;->c:Ljava/util/ArrayList;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->x(Z)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-instance v1, Ljava/util/ArrayList;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/google/android/gms/common/internal/s0;->b:Ljava/util/ArrayList;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/internal/s0;->h:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v3, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    check-cast v3, Lcom/google/android/gms/common/api/l$b;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-boolean v4, p0, Lcom/google/android/gms/common/internal/s0;->g:Z

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v4, :cond_2

    const/4 v6, 0x2

    iget-object v4, p0, Lcom/google/android/gms/common/internal/s0;->a:Lcom/google/android/gms/common/internal/r0;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v4}, Lcom/google/android/gms/common/internal/r0;->isConnected()Z

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v4, :cond_2

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/google/android/gms/common/internal/s0;->h:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eq v4, v2, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/google/android/gms/common/internal/s0;->c:Ljava/util/ArrayList;

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-nez v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-interface {v3, p1}, Lcom/google/android/gms/common/api/internal/f;->a(Landroid/os/Bundle;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/internal/s0;->c:Ljava/util/ArrayList;

    const/4 v5, 0x6

    move v6, v5

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 p1, 0x0

    const/4 v6, 0x1

    iput-boolean p1, p0, Lcom/google/android/gms/common/internal/s0;->i:Z

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    monitor-exit v0

    const/4 v6, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    throw p1
.end method

.method public final e(I)V
    .locals 7
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->j:Landroid/os/Handler;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo v1, "ottyrbeonrt  cinntndUien httdebl D anelnlemoiluonne aoiodH hcasnecloa "

    const-string/jumbo v1, "iconoetntn aymduateD ol Utesonnrolhn haie d b dlHsn ceotnolinnieelactr"

    const/4 v6, 0x0

    const-string/jumbo v1, "tlil lum n ne lid tncntnh taleoiborndr cceeehHo eaaeuintsoUydsononntna"

    const-string/jumbo v1, "onUnintentionalDisconnection must only be called on the Handler thread"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v0, v1}, Lcom/google/android/gms/common/internal/v;->i(Landroid/os/Handler;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->j:Landroid/os/Handler;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->k:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput-boolean v1, p0, Lcom/google/android/gms/common/internal/s0;->i:Z

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    new-instance v1, Ljava/util/ArrayList;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/google/android/gms/common/internal/s0;->b:Ljava/util/ArrayList;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/google/android/gms/common/internal/s0;->h:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v3, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    check-cast v3, Lcom/google/android/gms/common/api/l$b;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-boolean v4, p0, Lcom/google/android/gms/common/internal/s0;->g:Z

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v4, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v4, p0, Lcom/google/android/gms/common/internal/s0;->h:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x3

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eq v4, v2, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto :goto_1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v4, p0, Lcom/google/android/gms/common/internal/s0;->b:Ljava/util/ArrayList;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v4, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {v3, p1}, Lcom/google/android/gms/common/api/internal/f;->b(I)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/internal/s0;->c:Ljava/util/ArrayList;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 p1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput-boolean p1, p0, Lcom/google/android/gms/common/internal/s0;->i:Z

    const/4 v6, 0x4

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    throw p1
.end method

.method public final f(Lcom/google/android/gms/common/api/l$b;)V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->k:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s0;->b:Ljava/util/ArrayList;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v1, "eisGlbCpnestmnE"

    const-string v1, "GetnEbCsmvnseli"

    const/4 v6, 0x1

    const-string/jumbo v1, "smtviteEqnnselC"

    const-string v1, "GmsClientEvents"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string/jumbo v4, "lCsnistbnrt:sieet e)ak(rirceCe gncllanso"

    const-string/jumbo v4, "rgne tutbklictCosas:csn)rlreiee(ianCl en"

    const/4 v6, 0x6

    const-string/jumbo v4, "lcsmktisoenonsecn el:ia(gCr tebl)rrniCet"

    const-string/jumbo v4, "registerConnectionCallbacks(): listener "

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string v2, "dgeiosr resadi yaee tp"

    const-string v2, "diyar epialeest  ersgd"

    const/4 v6, 0x1

    const-string v2, "edaetbrleisa i ysdg re"

    const-string v2, " is already registered"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v1, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s0;->b:Ljava/util/ArrayList;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->a:Lcom/google/android/gms/common/internal/r0;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v0}, Lcom/google/android/gms/common/internal/r0;->isConnected()Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->j:Landroid/os/Handler;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    throw p1
.end method

.method public final g(Lcom/google/android/gms/common/api/l$c;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->k:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s0;->f:Ljava/util/ArrayList;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const-string/jumbo v1, "siEGntlvqnesmCe"

    const/4 v5, 0x0

    const-string v1, "EnesmnulietCGvs"

    const-string v1, "GmsClientEvents"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string/jumbo v3, "ries(ntpiLr)dltontoenr ecteinseianFrs Ci:esel"

    const-string/jumbo v3, "l)sdeL(Ct insneotegiie:aoriteeFslnrser nncrit"

    const/4 v5, 0x5

    const-string/jumbo v3, "tsiner(:qtrrneace  seslinFrtneCLt)neloeiogeii"

    const-string/jumbo v3, "registerConnectionFailedListener(): listener "

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string p1, "easaelstgyidiee md rrs"

    const-string p1, "agdmlidest aryiere e s"

    const/4 v5, 0x7

    const-string/jumbo p1, "gdemlerta  i assdeirry"

    const-string p1, " is already registered"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s0;->f:Ljava/util/ArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    throw p1
.end method

.method public final h(Lcom/google/android/gms/common/api/l$b;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->k:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s0;->b:Ljava/util/ArrayList;

    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-nez v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v1, "lCeoonGEiemstnt"

    const-string v1, "CeEnonslittsGme"

    const/4 v5, 0x4

    const-string/jumbo v1, "nnsvlbGtmCieEse"

    const-string v1, "GmsClientEvents"

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo v3, "lnsnonunbi Ceb tliekttc:)Cslacgsn(reeirera"

    const-string/jumbo v3, "negcebll(u cnstiranktirleC rno)as:nesCtieb"

    const/4 v5, 0x5

    const-string v3, "cltnn:lpCnrs irieuctCois latea)nsgeo(kbeen"

    const-string/jumbo v3, "unregisterConnectionCallbacks(): listener "

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo p1, "oo utfnuqd"

    const-string p1, " tfnodunuo"

    const/4 v5, 0x4

    const-string p1, "  sdountno"

    const-string p1, " not found"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-boolean v1, p0, Lcom/google/android/gms/common/internal/s0;->i:Z

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s0;->c:Ljava/util/ArrayList;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    throw p1
.end method

.method public final handleMessage(Landroid/os/Message;)Z
    .locals 5

    const/4 v4, 0x1

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x1

    move v3, v1

    move v3, v1

    const/4 v4, 0x0

    if-ne v0, v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x0

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    check-cast p1, Lcom/google/android/gms/common/api/l$b;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/google/android/gms/common/internal/s0;->k:Ljava/lang/Object;

    const/4 v3, 0x4

    move v4, v3

    monitor-enter v2

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    iget-boolean v0, p0, Lcom/google/android/gms/common/internal/s0;->g:Z

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->a:Lcom/google/android/gms/common/internal/r0;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v0}, Lcom/google/android/gms/common/internal/r0;->isConnected()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->b:Ljava/util/ArrayList;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    move v4, v3

    const/4 v0, 0x0

    shr-int/2addr v4, v0

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    invoke-interface {p1, v0}, Lcom/google/android/gms/common/api/internal/f;->a(Landroid/os/Bundle;)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    monitor-exit v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    return v1

    :catchall_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    throw p1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v1, "/oDmokhgssm/wlea :e  p dne oow nant"

    const-string/jumbo v1, "ksolDdop  en o/ona wgwnas: tete/ mh"

    const/4 v4, 0x0

    const-string v1, " : nohownsa/t /lmeh a oksowetdnDo g"

    const-string v1, "Don\'t know how to handle message: "

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/Exception;

    const/4 v3, 0x3

    move v4, v3

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v1, "ntvmnbqeiEseGCs"

    const-string v1, "EenmnGstqlvesiC"

    const/4 v4, 0x5

    const-string/jumbo v1, "innvteuCGessEtm"

    const-string v1, "GmsClientEvents"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v1, p1, v0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x5

    shr-int/2addr v3, p1

    const/4 v4, 0x7

    return p1
.end method

.method public final i(Lcom/google/android/gms/common/api/l$c;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->k:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s0;->f:Ljava/util/ArrayList;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-nez v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v1, "EilesCspesvnntt"

    const-string/jumbo v1, "vmsnlnteEsCstie"

    const/4 v5, 0x1

    const-string/jumbo v1, "iGEevntnqlsmets"

    const-string v1, "GmsClientEvents"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string v3, ":esc  grnne)selerralsLtitneontitueeoiFrni(Ciesn"

    const-string/jumbo v3, "unregisterConnectionFailedListener(): listener "

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string p1, "doumo m nf"

    const-string/jumbo p1, "f umodonn "

    const/4 v5, 0x6

    const-string/jumbo p1, "ouonofn td"

    const-string p1, " not found"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    const/4 v5, 0x1

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    throw p1
.end method

.method public final j(Lcom/google/android/gms/common/api/l$b;)Z
    .locals 4

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->k:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s0;->b:Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    throw p1
.end method

.method public final k(Lcom/google/android/gms/common/api/l$c;)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/s0;->k:Ljava/lang/Object;

    const/4 v3, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/internal/s0;->f:Ljava/util/ArrayList;

    const/4 v3, 0x7

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    return p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    throw p1
.end method
