.class final Lcom/google/android/gms/common/internal/i2;
.super Lcom/google/android/gms/common/internal/k;


# instance fields
.field private final f:Ljava/util/HashMap;
    .annotation build Lz4/a;
        value = "connectionStatus"
    .end annotation
.end field

.field private final g:Landroid/content/Context;

.field private volatile h:Landroid/os/Handler;

.field private final i:Lcom/google/android/gms/common/internal/h2;

.field private final j:Lcom/google/android/gms/common/stats/b;

.field private final k:J

.field private final l:J

.field private volatile m:Ljava/util/concurrent/Executor;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/os/Looper;Ljava/util/concurrent/Executor;)V
    .locals 4
    .param p3    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/k;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/internal/i2;->f:Ljava/util/HashMap;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/gms/common/internal/h2;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p0, v1}, Lcom/google/android/gms/common/internal/h2;-><init>(Lcom/google/android/gms/common/internal/i2;Lcom/google/android/gms/common/internal/g2;)V

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/gms/common/internal/i2;->i:Lcom/google/android/gms/common/internal/h2;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/internal/i2;->g:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance p1, Lcom/google/android/gms/internal/common/zzi;

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-direct {p1, p2, v0}, Lcom/google/android/gms/internal/common/zzi;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/internal/i2;->h:Landroid/os/Handler;

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/android/gms/common/stats/b;->b()Lcom/google/android/gms/common/stats/b;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/internal/i2;->j:Lcom/google/android/gms/common/stats/b;

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-wide/16 p1, 0x1388

    const-wide/16 p1, 0x1388

    const/4 v3, 0x2

    const-wide/16 p1, 0x1388

    const-wide/16 p1, 0x1388

    const/4 v3, 0x6

    const/4 v2, 0x6

    iput-wide p1, p0, Lcom/google/android/gms/common/internal/i2;->k:J

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-wide/32 p1, 0x493e0

    const-wide/32 p1, 0x493e0

    const/4 v3, 0x7

    const-wide/32 p1, 0x493e0

    const-wide/32 p1, 0x493e0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-wide p1, p0, Lcom/google/android/gms/common/internal/i2;->l:J

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object p3, p0, Lcom/google/android/gms/common/internal/i2;->m:Ljava/util/concurrent/Executor;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method static bridge synthetic o(Lcom/google/android/gms/common/internal/i2;)J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s4/m@~~M1 @itv@@o~@@l~oa @-~u  ~~@/@ybs~  .@o~~o@~~@@So o  @~K  ~nr@ci ~~ ~bd@t~  @  ~b@~~i@lf"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/google/android/gms/common/internal/i2;->l:J

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-wide v0
.end method

.method static bridge synthetic p(Lcom/google/android/gms/common/internal/i2;)Landroid/content/Context;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/gms/common/internal/i2;->g:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0
.end method

.method static bridge synthetic q(Lcom/google/android/gms/common/internal/i2;)Landroid/os/Handler;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/android/gms/common/internal/i2;->h:Landroid/os/Handler;

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method static bridge synthetic r(Lcom/google/android/gms/common/internal/i2;)Lcom/google/android/gms/common/stats/b;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    iget-object p0, p0, Lcom/google/android/gms/common/internal/i2;->j:Lcom/google/android/gms/common/stats/b;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method static bridge synthetic s(Lcom/google/android/gms/common/internal/i2;)Ljava/util/HashMap;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/gms/common/internal/i2;->f:Ljava/util/HashMap;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method


# virtual methods
.method protected final l(Lcom/google/android/gms/common/internal/d2;Landroid/content/ServiceConnection;Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo v0, "tnsbomornlcei tnuntSs ucie nC eoev"

    const/4 v4, 0x1

    const-string/jumbo v0, "neomlecitunntl ioe  bemtCv nScusno"

    const-string v0, "ServiceConnection must not be null"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p2, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/i2;->f:Ljava/util/HashMap;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/internal/i2;->f:Ljava/util/HashMap;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    check-cast v1, Lcom/google/android/gms/common/internal/f2;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, p2}, Lcom/google/android/gms/common/internal/f2;->h(Landroid/content/ServiceConnection;)Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, p2, p3}, Lcom/google/android/gms/common/internal/f2;->f(Landroid/content/ServiceConnection;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/common/internal/f2;->i()Z

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz p2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object p2, p0, Lcom/google/android/gms/common/internal/i2;->h:Landroid/os/Handler;

    const/4 v3, 0x7

    move v4, v3

    const/4 p3, 0x0

    move v4, p3

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {p2, p3, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/google/android/gms/common/internal/i2;->h:Landroid/os/Handler;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/google/android/gms/common/internal/i2;->k:J

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p2, p1, v1, v2}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance p2, Ljava/lang/IllegalStateException;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v1, "d g=osni ceiumnsetub in nnnftb  or.mGdtcoriao TaoaowenvyCcrie bo t etS nngfh"

    const-string v1, "anCm cyc i boein es tg d rwnhnirGvto=gnsi  dcbnfburaeeioftea uT.tSn tooo nmn"

    const/4 v4, 0x6

    const-string/jumbo v1, "otorabm ndge nirs cT o.icuivgeewt dcenioooohnsa bfbnai tby rfS Cn  t=nu enGn"

    const-string v1, "Trying to unbind a GmsServiceConnection  that was not bound before.  config="

    const/4 v4, 0x6

    const/4 v3, 0x2

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    throw p2

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance p2, Ljava/lang/IllegalStateException;

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v1, "ogx nouifevtiinntreanec s:cseots  tcrsueN ct ofoin"

    const-string v1, " vecosticonfog nixteu stntn:iNsci o en crostreofae"

    const/4 v4, 0x1

    const-string/jumbo v1, "vcirnt p cst oNutcoifrni: onastosxocnsnneft eee gi"

    const-string v1, "Nonexistent connection status for service config: "

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    or-int/2addr v4, v3

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    throw p2

    :catchall_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    throw p1
.end method

.method protected final n(Lcom/google/android/gms/common/internal/d2;Landroid/content/ServiceConnection;Ljava/lang/String;Ljava/util/concurrent/Executor;)Z
    .locals 6
    .param p4    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v0, "  uebnnoqtvne ccnmilt CuoortlibSse"

    const-string/jumbo v0, "lretubent CscnStbe nliuoco  veiomn"

    const/4 v5, 0x3

    const-string v0, "Cosn enbiiuemolruo cStnetcvne  nsl"

    const-string v0, "ServiceConnection must not be null"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {p2, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/i2;->f:Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/internal/i2;->f:Ljava/util/HashMap;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    check-cast v1, Lcom/google/android/gms/common/internal/f2;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-nez p4, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object p4, p0, Lcom/google/android/gms/common/internal/i2;->m:Ljava/util/concurrent/Executor;

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v1, Lcom/google/android/gms/common/internal/f2;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v1, p0, p1}, Lcom/google/android/gms/common/internal/f2;-><init>(Lcom/google/android/gms/common/internal/i2;Lcom/google/android/gms/common/internal/d2;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, p2, p2, p3}, Lcom/google/android/gms/common/internal/f2;->d(Landroid/content/ServiceConnection;Landroid/content/ServiceConnection;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1, p3, p4}, Lcom/google/android/gms/common/internal/f2;->e(Ljava/lang/String;Ljava/util/concurrent/Executor;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/google/android/gms/common/internal/i2;->f:Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p2, p1, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/internal/i2;->h:Landroid/os/Handler;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v2, v3, p1}, Landroid/os/Handler;->removeMessages(ILjava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1, p2}, Lcom/google/android/gms/common/internal/f2;->h(Landroid/content/ServiceConnection;)Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-nez v2, :cond_4

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {v1, p2, p2, p3}, Lcom/google/android/gms/common/internal/f2;->d(Landroid/content/ServiceConnection;Landroid/content/ServiceConnection;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/google/android/gms/common/internal/f2;->a()I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    if-eq p1, v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 p2, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eq p1, p2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1, p3, p4}, Lcom/google/android/gms/common/internal/f2;->e(Ljava/lang/String;Ljava/util/concurrent/Executor;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_0

    :cond_3
    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1}, Lcom/google/android/gms/common/internal/f2;->b()Landroid/content/ComponentName;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1}, Lcom/google/android/gms/common/internal/f2;->c()Landroid/os/IBinder;

    move-result-object p3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-interface {p2, p1, p3}, Landroid/content/ServiceConnection;->onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V

    :goto_0
    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v1}, Lcom/google/android/gms/common/internal/f2;->j()Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    return p1

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance p2, Ljava/lang/IllegalStateException;

    const/4 v5, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string/jumbo p4, "tb=aanua gdccsrgonireTis clSnefewnrttnde rtoeoaob n.netfy vy  nioo aGei  d ceciCm"

    const/4 v5, 0x5

    const-string/jumbo p4, "gtcml arfineirnt  ndyeo taa neonisn SfT  vioit nndbet argsrhecGyC. cwaeoeoe=ccdbo"

    const-string p4, "Trying to bind a GmsServiceConnection that was already connected before.  config="

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    throw p2

    :catchall_0
    move-exception p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    throw p1
.end method

.method final t(Ljava/util/concurrent/Executor;)V
    .locals 3
    .param p1    # Ljava/util/concurrent/Executor;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/internal/i2;->f:Ljava/util/HashMap;

    const/4 v2, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/internal/i2;->m:Ljava/util/concurrent/Executor;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    monitor-exit v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    throw p1
.end method

.method final u(Landroid/os/Looper;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/i2;->f:Ljava/util/HashMap;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x2

    new-instance v1, Lcom/google/android/gms/internal/common/zzi;

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/android/gms/common/internal/i2;->i:Lcom/google/android/gms/common/internal/h2;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v1, p1, v2}, Lcom/google/android/gms/internal/common/zzi;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-object v1, p0, Lcom/google/android/gms/common/internal/i2;->h:Landroid/os/Handler;

    const/4 v4, 0x5

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    throw p1
.end method
