.class public final Lcom/google/android/gms/common/internal/n1;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/Object;

.field private static b:Z
    .annotation build Lz4/a;
        value = "lock"
    .end annotation
.end field

.field private static c:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static d:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    sput-object v0, Lcom/google/android/gms/common/internal/n1;->a:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public static a(Landroid/content/Context;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "s s~@l ~@o @i ~u~M~~@/d ~a-1~ @i@@b~~~bo~S@f @@~@r~~ ~~@@4om y@ n vl.~o @  o@iKt~ ~@@c/@~fb @o t"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/google/android/gms/common/internal/n1;->c(Landroid/content/Context;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    sget p0, Lcom/google/android/gms/common/internal/n1;->d:I

    const/4 v1, 0x3

    return p0
.end method

.method public static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 2
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/android/gms/common/internal/n1;->c(Landroid/content/Context;)V

    const/4 v0, 0x2

    move v1, v0

    sget-object p0, Lcom/google/android/gms/common/internal/n1;->c:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method private static c(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    sget-object v0, Lcom/google/android/gms/common/internal/n1;->a:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-boolean v1, Lcom/google/android/gms/common/internal/n1;->b:Z

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    monitor-exit v0

    const/4 v3, 0x4

    move v4, v3

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    sput-boolean v1, Lcom/google/android/gms/common/internal/n1;->b:Z

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/wrappers/d;->a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/16 v2, 0x80

    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0, v1, v2}, Lcom/google/android/gms/common/wrappers/c;->c(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object p0, p0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez p0, :cond_1

    :try_start_2
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    return-void

    :cond_1
    :try_start_3
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v1, "gipmpcges.dolmao."

    const-string v1, ".osg.galc.pomiped"

    const/4 v4, 0x6

    const-string/jumbo v1, "o.aoo.lgg.podmcep"

    const-string v1, "com.google.app.id"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    sput-object v1, Lcom/google/android/gms/common/internal/n1;->c:Ljava/lang/String;

    const/4 v4, 0x5

    const-string/jumbo v1, "oos.mbicgrmosa.giorgnndmde.loe"

    const-string/jumbo v1, "gommoddrsaoroom.nvsn..iceglegi"

    const/4 v4, 0x0

    const-string/jumbo v1, "sgoosiugogormalnidmdce.rvo.ne."

    const-string v1, "com.google.android.gms.version"

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    sput p0, Lcom/google/android/gms/common/internal/n1;->d:I
    :try_end_3
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    goto :goto_0

    :catch_0
    move-exception p0

    :try_start_4
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v1, "adRaelepoeadruttaVa"

    const-string/jumbo v1, "lreaoaMedaaVetRatud"

    const/4 v4, 0x2

    const-string v1, "MrduetRaqlaaedeaeVa"

    const-string v1, "MetadataValueReader"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v2, ". snipsehbpTushnl eeohav "

    const-string v2, "adhu.biple envsopTh esnh "

    const/4 v4, 0x0

    const-string/jumbo v2, "hpnmpe uT an ev.elisshdoh"

    const-string v2, "This should never happen."

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v1, v2, p0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    throw p0
.end method
