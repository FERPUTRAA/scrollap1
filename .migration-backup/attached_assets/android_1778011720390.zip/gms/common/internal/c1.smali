.class public final Lcom/google/android/gms/common/internal/c1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, " vs~~ib@-@~ ~o   ~o b~u@~@l@~ ~@~@@o~S~t cKamM~@~~@@/i~ dr@@t ~@4  o.l@@~~@/@io@ nb  @ ff1~~s~ y"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x7

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v1, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    const/4 v2, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    move v4, v1

    move v4, v1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    move v7, v4

    move v7, v4

    const/4 v10, 0x1

    move v7, v4

    move v7, v4

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    move v8, v7

    move v8, v7

    const/4 v10, 0x3

    move v8, v7

    move v8, v7

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-ge v1, v0, :cond_5

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {v1}, Lh4/a;->O(I)I

    move-result v2

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v3, 0x1

    shl-int/2addr v10, v3

    const/4 v9, 0x0

    move v10, v9

    if-eq v2, v3, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    const/4 v3, 0x2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-eq v2, v3, :cond_3

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/4 v3, 0x3

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eq v2, v3, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    const/4 v3, 0x4

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-eq v2, v3, :cond_1

    const/4 v9, 0x1

    move v10, v9

    const/4 v3, 0x5

    move v10, v3

    const/4 v9, 0x6

    move v10, v9

    if-eq v2, v3, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {p1, v1}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    goto :goto_0

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {p1, v1}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v8

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    goto :goto_0

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {p1, v1}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v7

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    goto :goto_0

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    sget-object v2, Lcom/google/android/gms/common/ConnectionResult;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {p1, v1, v2}, Lh4/a;->C(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    check-cast v6, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v10, 0x5

    goto :goto_0

    :cond_3
    const/4 v10, 0x7

    const/4 v9, 0x2

    invoke-static {p1, v1}, Lh4/a;->Y(Landroid/os/Parcel;I)Landroid/os/IBinder;

    move-result-object v5

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto/16 :goto_0

    :cond_4
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v4

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    goto/16 :goto_0

    :cond_5
    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    new-instance p1, Lcom/google/android/gms/common/internal/zav;

    move-object v3, p1

    move-object v3, p1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-direct/range {v3 .. v8}, Lcom/google/android/gms/common/internal/zav;-><init>(ILandroid/os/IBinder;Lcom/google/android/gms/common/ConnectionResult;ZZ)V

    const/4 v9, 0x6

    move v10, v9

    return-object p1
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    new-array p1, p1, [Lcom/google/android/gms/common/internal/zav;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p1
.end method
