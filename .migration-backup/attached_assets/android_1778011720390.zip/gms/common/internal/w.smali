.class public final Lcom/google/android/gms/common/internal/w;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static final a:Landroid/net/Uri;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    new-instance v0, Landroid/net/Uri$Builder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v0}, Landroid/net/Uri$Builder;-><init>()V

    const/4 v2, 0x5

    shl-int/2addr v3, v2

    const-string v1, "crsareosddsuir.n"

    const-string/jumbo v1, "oasdisc.reerrndu"

    const/4 v3, 0x6

    const-string/jumbo v1, "i.dmoeaurerondrs"

    const-string v1, "android.resource"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string v1, ".oolongodd.ms.ioamermc"

    const-string/jumbo v1, "ld.mier.mc.gamsoodnoog"

    const/4 v3, 0x3

    const-string/jumbo v1, "sm.gabrcigmloodgooe.dn"

    const-string v1, "com.google.android.gms"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string v1, "edwalbuo"

    const-string v1, "derlobaw"

    const/4 v3, 0x5

    const-string v1, "elrabwap"

    const-string v1, "drawable"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->appendPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/gms/common/internal/w;->a:Landroid/net/Uri;

    const/4 v3, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method
