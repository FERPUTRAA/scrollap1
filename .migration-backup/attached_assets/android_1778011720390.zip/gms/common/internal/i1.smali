.class public abstract Lcom/google/android/gms/common/internal/i1;
.super Lcom/google/android/gms/internal/common/zzb;

# interfaces
.implements Lcom/google/android/gms/common/internal/p;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const-string/jumbo v0, "lkssIldmgcnildo.aCcoonasommginmmabo.s.rG.laegst.n.or"

    const-string v0, "bgsllssdIn..okena.mmodrr..smtoaanoiogi.CcmnGoecmlagl"

    const/4 v2, 0x3

    const-string/jumbo v0, "lcmmc.g.lgb.Cao.omsenrooslo.mg.iiomaareImlscGnknddta"

    const-string v0, "com.google.android.gms.common.internal.IGmsCallbacks"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/common/zzb;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method protected final zza(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "1@@foi~~4S  is~of~c@/ ~o@on@ b~@~u @ @~/ ~o@ ll  ~ob@ i~@@ ~.vm~M@o@@ ~@ @rb~~~y@-~K @t~a~~  td@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    const/4 p4, 0x1

    const/4 v3, 0x5

    if-eq p1, p4, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eq p1, v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x7

    if-eq p1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 p1, 0x0

    xor-int/2addr v3, p1

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    return p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object v1, Lcom/google/android/gms/common/internal/zzk;->CREATOR:Landroid/os/Parcelable$Creator;

    invoke-static {p2, v1}, Lcom/google/android/gms/internal/common/zzc;->zza(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v1, Lcom/google/android/gms/common/internal/zzk;

    const/4 v2, 0x6

    or-int/2addr v3, v2

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzb(Landroid/os/Parcel;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {p0, p1, v0, v1}, Lcom/google/android/gms/common/internal/p;->l0(ILandroid/os/IBinder;Lcom/google/android/gms/common/internal/zzk;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object v0, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p2, v0}, Lcom/google/android/gms/internal/common/zzc;->zza(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    check-cast v0, Landroid/os/Bundle;

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzb(Landroid/os/Parcel;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p0, p1, v0}, Lcom/google/android/gms/common/internal/p;->Q(ILandroid/os/Bundle;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p2, v1}, Lcom/google/android/gms/internal/common/zzc;->zza(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    check-cast v1, Landroid/os/Bundle;

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-static {p2}, Lcom/google/android/gms/internal/common/zzc;->zzb(Landroid/os/Parcel;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {p0, p1, v0, v1}, Lcom/google/android/gms/common/internal/p;->p(ILandroid/os/IBinder;Landroid/os/Bundle;)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v3, 0x7

    return p4
.end method
