.class final Lcom/google/android/gms/common/internal/n0;
.super Lcom/google/android/gms/common/internal/o0;


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Lcom/google/android/gms/common/api/internal/m;


# direct methods
.method constructor <init>(Landroid/content/Intent;Lcom/google/android/gms/common/api/internal/m;I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/internal/n0;->a:Landroid/content/Intent;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/google/android/gms/common/internal/n0;->b:Lcom/google/android/gms/common/api/internal/m;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/o0;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "ttso@ ~@@v ~Mfmoyoi- @~i.~~bb  S@o l~@K @@@@@~/ ~ c @~~f~o~@~u    r~~~a@/~s~@~@b@n~ ~@@i1do l4~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/n0;->a:Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/internal/n0;->b:Lcom/google/android/gms/common/api/internal/m;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v2, 0x2

    invoke-interface {v1, v0, v2}, Lcom/google/android/gms/common/api/internal/m;->startActivityForResult(Landroid/content/Intent;I)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void
.end method
