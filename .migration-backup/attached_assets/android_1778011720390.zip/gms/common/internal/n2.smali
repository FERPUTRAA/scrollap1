.class public final Lcom/google/android/gms/common/internal/n2;
.super Lcom/google/android/gms/internal/common/zza;

# interfaces
.implements Lcom/google/android/gms/common/internal/o;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const-string/jumbo v0, "irsdlesIneocggo.naoC.lone..oodaanlimT.ng.remmocmtck"

    const/4 v2, 0x1

    const-string v0, "TdseleccInotgcra.knCaoiimo.ao.om.nlndrgelomg.nemons"

    const-string v0, "com.google.android.gms.common.internal.ICancelToken"

    const/4 v2, 0x2

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/internal/common/zza;-><init>(Landroid/os/IBinder;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public final cancel()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @Sm~@a4 fi.c ~/ r ~~@1@ o@~l/o~ob  @  ~~t@@l@bvM -onK~y~ d~o ts@ib@~~~  i@~ou@@~@~~ @~@~ m@f~~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    const/4 v0, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/internal/common/zza;->zza()Landroid/os/Parcel;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1}, Lcom/google/android/gms/internal/common/zza;->zzD(ILandroid/os/Parcel;)V

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method
