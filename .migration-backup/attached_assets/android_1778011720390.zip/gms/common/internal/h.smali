.class public final Lcom/google/android/gms/common/internal/h;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "gms_error_code"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "networkToUse"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final c:Ljava/lang/String; = "com.google.android.gms.common.images.LOAD_IMAGE"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final d:Ljava/lang/String; = "com.google.android.gms.extras.uri"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final e:Ljava/lang/String; = "com.google.android.gms.extras.resultReceiver"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final f:Ljava/lang/String; = "com.google.android.gms.extras.priority"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    shl-int/2addr v1, v0

    return-void
.end method
