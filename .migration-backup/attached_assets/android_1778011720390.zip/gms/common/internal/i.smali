.class public abstract Lcom/google/android/gms/common/internal/i;
.super Lcom/google/android/gms/common/internal/q$a;


# annotations
.annotation build Lf4/a;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/q$a;-><init>()V

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method
