.class public abstract Lcom/google/android/gms/common/internal/o$a;
.super Lcom/google/android/gms/internal/common/zzb;

# interfaces
.implements Lcom/google/android/gms/common/internal/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/internal/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const-string v0, "easagcndanketCnoolg.cnssmmmcloiroI.mie.T.no.lnoedo."

    const-string v0, "Tns.orocmtlgsan.Cmmaklnecmieneao.cI.doe.nlgnd.iogoo"

    const/4 v2, 0x2

    const-string/jumbo v0, "geom.kicIon.rgCemddln.lotoeioconnra.mmlos.a.geTcmna"

    const-string v0, "com.google.android.gms.common.internal.ICancelToken"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/android/gms/internal/common/zzb;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public static a(Landroid/os/IBinder;)Lcom/google/android/gms/common/internal/o;
    .locals 4
    .param p0    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@o  b@1~~o~@ ~l~~ y@S@ @. o4m~r@if@oo~@~@f@K~@~n @@a b ~/~ u@ @@@t@  vt c@~o~M l~bd~~~/~soi-i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const-string v0, "Coimo.satengomo.aoce.droIm..r.onklngamlgncnneciTedm"

    const/4 v3, 0x2

    const-string v0, "com.google.android.gms.common.internal.ICancelToken"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    instance-of v1, v0, Lcom/google/android/gms/common/internal/o;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    check-cast v0, Lcom/google/android/gms/common/internal/o;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/gms/common/internal/n2;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/internal/n2;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method protected final zza(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 2
    .param p2    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    const/4 p2, 0x2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-ne p1, p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-interface {p0}, Lcom/google/android/gms/common/internal/o;->cancel()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p1

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p1
.end method
