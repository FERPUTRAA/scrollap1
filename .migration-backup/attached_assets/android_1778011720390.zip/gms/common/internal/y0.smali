.class final Lcom/google/android/gms/common/internal/y0;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/internal/u$a;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/api/u;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/api/u;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/internal/y0;->a:Lcom/google/android/gms/common/api/u;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final bridge synthetic a(Lcom/google/android/gms/common/api/v;)Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s~@@~@ S~  /@s ~1 ml b~@~y~b~~ ~  r i@vb @~~@@ @lMo u~.d@ @i~~4~@/o@@a~~t@@@ Kt~ff-ooon~co i@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/y0;->a:Lcom/google/android/gms/common/api/u;

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/api/u;->b(Lcom/google/android/gms/common/api/v;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/internal/y0;->a:Lcom/google/android/gms/common/api/u;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p1
.end method
