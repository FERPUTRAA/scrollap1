.class abstract Lcom/google/android/gms/common/internal/f1;
.super Lcom/google/android/gms/common/internal/s1;


# instance fields
.field public final d:I

.field public final e:Landroid/os/Bundle;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field final synthetic f:Lcom/google/android/gms/common/internal/e;


# direct methods
.method protected constructor <init>(Lcom/google/android/gms/common/internal/e;ILandroid/os/Bundle;)V
    .locals 3
    .param p2    # I
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/g;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/internal/f1;->f:Lcom/google/android/gms/common/internal/e;

    const/4 v2, 0x2

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/common/internal/s1;-><init>(Lcom/google/android/gms/common/internal/e;Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput p2, p0, Lcom/google/android/gms/common/internal/f1;->d:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p3, p0, Lcom/google/android/gms/common/internal/f1;->e:Landroid/os/Bundle;

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method protected final bridge synthetic a(Ljava/lang/Object;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "Sos@1~~@o ~/m ~d~s@@/b@ f~ @ ~v yo~Mull @ @n@@ ~o @~ba@@~@i~@ ~~~f@4@ Kb~ @  .~ @~c~-~otr@ii~~to"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget p1, p0, Lcom/google/android/gms/common/internal/f1;->d:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x4

    if-nez p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/f1;->g()Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x4

    move v3, v2

    iget-object p1, p0, Lcom/google/android/gms/common/internal/f1;->f:Lcom/google/android/gms/common/internal/e;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/common/internal/e;->zzi(Lcom/google/android/gms/common/internal/e;ILandroid/os/IInterface;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance p1, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/16 v0, 0x8

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p1, v0, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/internal/f1;->f(Lcom/google/android/gms/common/ConnectionResult;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/google/android/gms/common/internal/f1;->f:Lcom/google/android/gms/common/internal/e;

    const/4 v3, 0x6

    invoke-static {p1, v0, v1}, Lcom/google/android/gms/common/internal/e;->zzi(Lcom/google/android/gms/common/internal/e;ILandroid/os/IInterface;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/internal/f1;->e:Landroid/os/Bundle;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v0, "Ittmeespnnnng"

    const-string v0, "eespgniItnntn"

    const/4 v3, 0x4

    const-string/jumbo v0, "pendingIntent"

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    move-object v1, p1

    move-object v1, p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast v1, Landroid/app/PendingIntent;

    :cond_2
    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget p1, p0, Lcom/google/android/gms/common/internal/f1;->d:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0, p1, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/internal/f1;->f(Lcom/google/android/gms/common/ConnectionResult;)V

    const/4 v3, 0x3

    return-void
.end method

.method protected final b()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method protected abstract f(Lcom/google/android/gms/common/ConnectionResult;)V
.end method

.method protected abstract g()Z
.end method
