.class public Lcom/google/android/gms/common/internal/ClientIdentity;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "ClientIdentityCreator"
.end annotation

.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$g;
    value = {
        0x3e8
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/internal/ClientIdentity;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field


# instance fields
.field public final a:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        defaultValueUnchecked = "0"
        id = 0x1
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public final b:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        defaultValueUnchecked = "null"
        id = 0x2
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Lcom/google/android/gms/common/internal/f0;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/common/internal/f0;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    sput-object v0, Lcom/google/android/gms/common/internal/ClientIdentity;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(ILjava/lang/String;)V
    .locals 2
    .param p1    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation

        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/gms/common/internal/ClientIdentity;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/android/gms/common/internal/ClientIdentity;->b:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@s@~ ~~~~io@~yvd./ 4is1~ -@  ~fc@ @K~M l~u@o~t ~ o~bo@~io~ m@  @~~@@@~l o/@b @~@@ S~@~b nf@@rat"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    if-ne p1, p0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    return v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    instance-of v1, p1, Lcom/google/android/gms/common/internal/ClientIdentity;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-nez v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    return v2

    :cond_1
    const/4 v4, 0x4

    move v5, v4

    check-cast p1, Lcom/google/android/gms/common/internal/ClientIdentity;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget v1, p1, Lcom/google/android/gms/common/internal/ClientIdentity;->a:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget v3, p0, Lcom/google/android/gms/common/internal/ClientIdentity;->a:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-ne v1, v3, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object p1, p1, Lcom/google/android/gms/common/internal/ClientIdentity;->b:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/internal/ClientIdentity;->b:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {p1, v1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz p1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    return v0

    :cond_2
    const/4 v5, 0x5

    return v2
.end method

.method public final hashCode()I
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/common/internal/ClientIdentity;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/android/gms/common/internal/ClientIdentity;->a:I

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, ":"

    const-string v1, ":"

    const/4 v3, 0x7

    const-string v1, ":"

    const-string v1, ":"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/internal/ClientIdentity;->b:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 5
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x2

    iget p2, p0, Lcom/google/android/gms/common/internal/ClientIdentity;->a:I

    const/4 v4, 0x7

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1, v1, p2}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object p2, p0, Lcom/google/android/gms/common/internal/ClientIdentity;->b:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-static {p1, v2, p2, v1}, Lh4/b;->Y(Landroid/os/Parcel;ILjava/lang/String;Z)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p1, v0}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method
