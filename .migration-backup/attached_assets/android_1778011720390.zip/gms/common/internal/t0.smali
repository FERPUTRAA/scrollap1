.class public final Lcom/google/android/gms/common/internal/t0;
.super Ljava/lang/Object;


# instance fields
.field private final a:Landroid/util/SparseIntArray;

.field private b:Lcom/google/android/gms/common/g;


# direct methods
.method public constructor <init>()V
    .locals 3

    invoke-static {}, Lcom/google/android/gms/common/f;->x()Lcom/google/android/gms/common/f;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/internal/t0;-><init>(Lcom/google/android/gms/common/g;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>(Lcom/google/android/gms/common/g;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Landroid/util/SparseIntArray;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Landroid/util/SparseIntArray;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/internal/t0;->a:Landroid/util/SparseIntArray;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/internal/t0;->b:Lcom/google/android/gms/common/g;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;I)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@dsm@@@~ @M-i~ c@ tooa@ vi4./~ uo@~t~ ~@~ / @ ~So~@b 1l~ ~ ~ b fl~ Ky@o~@ri~ n@@o~@@~~ ~~@f~s@~b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/internal/t0;->a:Landroid/util/SparseIntArray;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p1, p2, v0}, Landroid/util/SparseIntArray;->get(II)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return p1
.end method

.method public final b(Landroid/content/Context;Lcom/google/android/gms/common/api/a$f;)I
    .locals 7
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/api/a$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-interface {p2}, Lcom/google/android/gms/common/api/a$f;->requiresGooglePlayServices()Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    return v1

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-interface {p2}, Lcom/google/android/gms/common/api/a$f;->getMinApkVersion()I

    move-result p2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/common/internal/t0;->a(Landroid/content/Context;I)I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 v2, -0x1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eq v0, v2, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_3

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    move v0, v1

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/google/android/gms/common/internal/t0;->a:Landroid/util/SparseIntArray;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3}, Landroid/util/SparseIntArray;->size()I

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-ge v0, v3, :cond_3

    const/4 v6, 0x5

    iget-object v3, p0, Lcom/google/android/gms/common/internal/t0;->a:Landroid/util/SparseIntArray;

    const/4 v6, 0x2

    const/4 v5, 0x0

    invoke-virtual {v3, v0}, Landroid/util/SparseIntArray;->keyAt(I)I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-le v3, p2, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v4, p0, Lcom/google/android/gms/common/internal/t0;->a:Landroid/util/SparseIntArray;

    const/4 v6, 0x1

    invoke-virtual {v4, v3}, Landroid/util/SparseIntArray;->get(I)I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v3, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_1

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x0

    move v6, v5

    goto :goto_0

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    move v1, v2

    move v1, v2

    const/4 v6, 0x3

    move v1, v2

    :goto_1
    const/4 v6, 0x6

    if-ne v1, v2, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/t0;->b:Lcom/google/android/gms/common/g;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0, p1, p2}, Lcom/google/android/gms/common/g;->k(Landroid/content/Context;I)I

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    move v0, p1

    move v0, p1

    move v0, p1

    move v0, p1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto :goto_2

    :cond_4
    const/4 v5, 0x7

    move v6, v5

    move v0, v1

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    :goto_2
    const/4 v6, 0x2

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/google/android/gms/common/internal/t0;->a:Landroid/util/SparseIntArray;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1, p2, v0}, Landroid/util/SparseIntArray;->put(II)V

    :goto_3
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    return v0
.end method

.method public final c()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/internal/t0;->a:Landroid/util/SparseIntArray;

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-virtual {v0}, Landroid/util/SparseIntArray;->clear()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method
