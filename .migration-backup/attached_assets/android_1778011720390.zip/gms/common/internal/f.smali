.class public final Lcom/google/android/gms/common/internal/f;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public static a()Ljava/util/concurrent/ExecutorService;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/common/internal/z1;->a:Ljava/util/concurrent/ExecutorService;

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-object v0
.end method
