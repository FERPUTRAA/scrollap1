.class final Lcom/google/android/gms/common/internal/h2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Handler$Callback;


# instance fields
.field final synthetic a:Lcom/google/android/gms/common/internal/i2;


# direct methods
.method synthetic constructor <init>(Lcom/google/android/gms/common/internal/i2;Lcom/google/android/gms/common/internal/g2;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/internal/h2;->a:Lcom/google/android/gms/common/internal/i2;

    const/4 v0, 0x6

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)Z
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x0

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v8, 0x5

    const/4 v1, 0x1

    const/4 v8, 0x7

    move v7, v1

    move v7, v1

    const/4 v8, 0x2

    if-eqz v0, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eq v0, v1, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 p1, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    return p1

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/internal/h2;->a:Lcom/google/android/gms/common/internal/i2;

    const/4 v7, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/internal/i2;->s(Lcom/google/android/gms/common/internal/i2;)Ljava/util/HashMap;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x4

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x7

    check-cast p1, Lcom/google/android/gms/common/internal/d2;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object v2, p0, Lcom/google/android/gms/common/internal/h2;->a:Lcom/google/android/gms/common/internal/i2;

    const/4 v8, 0x4

    const/4 v7, 0x1

    invoke-static {v2}, Lcom/google/android/gms/common/internal/i2;->s(Lcom/google/android/gms/common/internal/i2;)Ljava/util/HashMap;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    check-cast v2, Lcom/google/android/gms/common/internal/f2;

    const/4 v8, 0x1

    if-eqz v2, :cond_3

    const/4 v7, 0x1

    move v8, v7

    invoke-virtual {v2}, Lcom/google/android/gms/common/internal/f2;->a()I

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v4, 0x3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-ne v3, v4, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string/jumbo v3, "pCslnSesrsGvmsoritu"

    const-string/jumbo v3, "ilsmtneoupGseCrSvsr"

    const-string/jumbo v3, "smtmepsunirrCeGilSo"

    const-string v3, "GmsClientSupervisor"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x7

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string/jumbo v6, "mnneotm anicaocenoeScC oaiT  ilreiculiw fgtvtok"

    const-string/jumbo v6, "tnfmcoounrlic iiol mekabtSigtaneea iwcc n TevCo"

    const/4 v8, 0x4

    const-string v6, "cwtrmb tbeTkaonaicfiaioncl ieo vneigu cnrel CSt"

    const-string v6, "Timeout waiting for ServiceConnection callback "

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    new-instance v5, Ljava/lang/Exception;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-direct {v5}, Ljava/lang/Exception;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {v3, v4, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x2

    const/4 v7, 0x2

    invoke-virtual {v2}, Lcom/google/android/gms/common/internal/f2;->b()Landroid/content/ComponentName;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-nez v3, :cond_1

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/d2;->a()Landroid/content/ComponentName;

    move-result-object v3

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-nez v3, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    new-instance v3, Landroid/content/ComponentName;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/internal/d2;->c()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string/jumbo v4, "onnknou"

    const-string/jumbo v4, "nknnowo"

    const/4 v8, 0x2

    const-string/jumbo v4, "pnnkown"

    const-string/jumbo v4, "unknown"

    const/4 v8, 0x5

    invoke-direct {v3, p1, v4}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v2, v3}, Lcom/google/android/gms/common/internal/f2;->onServiceDisconnected(Landroid/content/ComponentName;)V

    :cond_3
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    monitor-exit v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    return v1

    :catchall_0
    move-exception p1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x6

    const/4 v7, 0x4

    throw p1

    :cond_4
    const/4 v8, 0x4

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/internal/h2;->a:Lcom/google/android/gms/common/internal/i2;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/i2;->s(Lcom/google/android/gms/common/internal/i2;)Ljava/util/HashMap;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    monitor-enter v0

    :try_start_1
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    check-cast p1, Lcom/google/android/gms/common/internal/d2;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object v2, p0, Lcom/google/android/gms/common/internal/h2;->a:Lcom/google/android/gms/common/internal/i2;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {v2}, Lcom/google/android/gms/common/internal/i2;->s(Lcom/google/android/gms/common/internal/i2;)Ljava/util/HashMap;

    move-result-object v2

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    check-cast v2, Lcom/google/android/gms/common/internal/f2;

    const/4 v8, 0x3

    if-eqz v2, :cond_6

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v2}, Lcom/google/android/gms/common/internal/f2;->i()Z

    move-result v3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-eqz v3, :cond_6

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v2}, Lcom/google/android/gms/common/internal/f2;->j()Z

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-eqz v3, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string/jumbo v3, "obepveilqGitmsCsurn"

    const-string/jumbo v3, "soitpbumsvlernCGrei"

    const/4 v8, 0x3

    const-string/jumbo v3, "lisrrvCSmitponGeess"

    const-string v3, "GmsClientSupervisor"

    const/4 v8, 0x4

    invoke-virtual {v2, v3}, Lcom/google/android/gms/common/internal/f2;->g(Ljava/lang/String;)V

    :cond_5
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/internal/h2;->a:Lcom/google/android/gms/common/internal/i2;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {v2}, Lcom/google/android/gms/common/internal/i2;->s(Lcom/google/android/gms/common/internal/i2;)Ljava/util/HashMap;

    move-result-object v2

    const/4 v8, 0x7

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_6
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    monitor-exit v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    return v1

    :catchall_1
    move-exception p1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    throw p1
.end method
