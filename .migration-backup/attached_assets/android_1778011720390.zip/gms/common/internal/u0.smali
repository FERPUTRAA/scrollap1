.class public final Lcom/google/android/gms/common/internal/u0;
.super Lcom/google/android/gms/internal/base/zaa;

# interfaces
.implements Landroid/os/IInterface;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string v0, "assnn.nrtmdlor.otng.mIiu.neS.icroodggclInmoigaon.eBseotCroa"

    const-string/jumbo v0, "ggsil..uranaeo.rorInttonn.cloieaSogBon.mmemIroongstdcnimd.C"

    const/4 v2, 0x1

    const-string/jumbo v0, "msgm.i.ig.onoocooBIdnergulmerrtmciaalrdS.n.nCnmogenttooInat"

    const-string v0, "com.google.android.gms.common.internal.ISignInButtonCreator"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lcom/google/android/gms/internal/base/zaa;-><init>(Landroid/os/IBinder;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final a(Lcom/google/android/gms/dynamic/d;Lcom/google/android/gms/common/internal/zax;)Lcom/google/android/gms/dynamic/d;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b~~@of@~ @~@  ~@@~~~ @o~ @Sbv ~~oul@id/@ytmKo ~~ c     o~~oa sl@~rt~ fi@~~~~@ M@@o./@~b@ @@@41-n"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/internal/base/zaa;->zaa()Landroid/os/Parcel;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-static {v0, p1}, Lcom/google/android/gms/internal/base/zac;->zad(Landroid/os/Parcel;Landroid/os/IInterface;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {v0, p2}, Lcom/google/android/gms/internal/base/zac;->zac(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    const/4 v2, 0x7

    const/4 p1, 0x7

    const/4 v2, 0x1

    const/4 p1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/google/android/gms/internal/base/zaa;->zab(ILandroid/os/Parcel;)Landroid/os/Parcel;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-static {p2}, Lcom/google/android/gms/dynamic/d$a;->a(Landroid/os/IBinder;)Lcom/google/android/gms/dynamic/d;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->recycle()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p2
.end method
