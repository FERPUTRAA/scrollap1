.class public Lcom/google/android/gms/common/internal/u;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/internal/u$a;
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field private static final a:Lcom/google/android/gms/common/internal/a1;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/gms/common/internal/w0;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/android/gms/common/internal/w0;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    sput-object v0, Lcom/google/android/gms/common/internal/u;->a:Lcom/google/android/gms/common/internal/a1;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public static a(Lcom/google/android/gms/common/api/p;Lcom/google/android/gms/common/api/u;)Lcom/google/android/gms/tasks/Task;
    .locals 3
    .param p0    # Lcom/google/android/gms/common/api/p;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/gms/common/api/u;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R::",
            "Lcom/google/android/gms/common/api/v;",
            "T:",
            "Lcom/google/android/gms/common/api/u<",
            "TR;>;>(",
            "Lcom/google/android/gms/common/api/p<",
            "TR;>;TT;)",
            "Lcom/google/android/gms/tasks/Task<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance v0, Lcom/google/android/gms/common/internal/y0;

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/internal/y0;-><init>(Lcom/google/android/gms/common/api/u;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/u;->b(Lcom/google/android/gms/common/api/p;Lcom/google/android/gms/common/internal/u$a;)Lcom/google/android/gms/tasks/Task;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public static b(Lcom/google/android/gms/common/api/p;Lcom/google/android/gms/common/internal/u$a;)Lcom/google/android/gms/tasks/Task;
    .locals 5
    .param p0    # Lcom/google/android/gms/common/api/p;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/gms/common/internal/u$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R::",
            "Lcom/google/android/gms/common/api/v;",
            "T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/android/gms/common/api/p<",
            "TR;>;",
            "Lcom/google/android/gms/common/internal/u$a<",
            "TR;TT;>;)",
            "Lcom/google/android/gms/tasks/Task<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    sget-object v0, Lcom/google/android/gms/common/internal/u;->a:Lcom/google/android/gms/common/internal/a1;

    const/4 v4, 0x7

    new-instance v1, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-direct {v1}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v2, Lcom/google/android/gms/common/internal/x0;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v2, p0, v1, p1, v0}, Lcom/google/android/gms/common/internal/x0;-><init>(Lcom/google/android/gms/common/api/p;Lcom/google/android/gms/tasks/TaskCompletionSource;Lcom/google/android/gms/common/internal/u$a;Lcom/google/android/gms/common/internal/a1;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0, v2}, Lcom/google/android/gms/common/api/p;->addStatusListener(Lcom/google/android/gms/common/api/p$a;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object p0
.end method

.method public static c(Lcom/google/android/gms/common/api/p;)Lcom/google/android/gms/tasks/Task;
    .locals 3
    .param p0    # Lcom/google/android/gms/common/api/p;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R::",
            "Lcom/google/android/gms/common/api/v;",
            ">(",
            "Lcom/google/android/gms/common/api/p<",
            "TR;>;)",
            "Lcom/google/android/gms/tasks/Task<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Lcom/google/android/gms/common/internal/z0;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/android/gms/common/internal/z0;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/u;->b(Lcom/google/android/gms/common/api/p;Lcom/google/android/gms/common/internal/u$a;)Lcom/google/android/gms/tasks/Task;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method
