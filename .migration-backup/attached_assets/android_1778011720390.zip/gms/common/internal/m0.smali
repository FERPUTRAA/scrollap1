.class final Lcom/google/android/gms/common/internal/m0;
.super Lcom/google/android/gms/common/internal/o0;


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Landroidx/fragment/app/Fragment;

.field final synthetic c:I


# direct methods
.method constructor <init>(Landroid/content/Intent;Landroidx/fragment/app/Fragment;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/internal/m0;->a:Landroid/content/Intent;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/android/gms/common/internal/m0;->b:Landroidx/fragment/app/Fragment;

    const/4 v1, 0x7

    iput p3, p0, Lcom/google/android/gms/common/internal/m0;->c:I

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/o0;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " ls@Si@@~@~s ~o ~@ @v@@ 4  ~@~~f~~or~@bn a@tb@ @Md@ c@o~@ib Kuy~o ~~~o@ ~   t1~~@~-/ ~@lom.f~~i/"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/internal/m0;->a:Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/internal/m0;->b:Landroidx/fragment/app/Fragment;

    const/4 v4, 0x1

    iget v2, p0, Lcom/google/android/gms/common/internal/m0;->c:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v1, v0, v2}, Landroidx/fragment/app/Fragment;->startActivityForResult(Landroid/content/Intent;I)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method
