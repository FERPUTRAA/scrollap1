.class public Lcom/google/android/gms/common/internal/d0;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/api/a$d$f;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/internal/d0$a;
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field public static final b:Lcom/google/android/gms/common/internal/d0;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# instance fields
.field private final a:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/android/gms/common/internal/d0;->a()Lcom/google/android/gms/common/internal/d0$a;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/gms/common/internal/d0$a;->a()Lcom/google/android/gms/common/internal/d0;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/gms/common/internal/d0;->b:Lcom/google/android/gms/common/internal/d0;

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method synthetic constructor <init>(Ljava/lang/String;Lcom/google/android/gms/common/internal/i0;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/internal/d0;->a:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public static a()Lcom/google/android/gms/common/internal/d0$a;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/gms/common/internal/d0$a;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/internal/d0$a;-><init>(Lcom/google/android/gms/common/internal/h0;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0
.end method


# virtual methods
.method public final b()Landroid/os/Bundle;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x4

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/internal/d0;->a:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string v2, "aip"

    const-string/jumbo v2, "pai"

    const/4 v4, 0x6

    const-string/jumbo v2, "pia"

    const-string v2, "api"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-ne p1, p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v1, 0x6

    move v2, v1

    return p1

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    instance-of v0, p1, Lcom/google/android/gms/common/internal/d0;

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p1, Lcom/google/android/gms/common/internal/d0;

    iget-object v0, p0, Lcom/google/android/gms/common/internal/d0;->a:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p1, p1, Lcom/google/android/gms/common/internal/d0;->a:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p1
.end method

.method public final hashCode()I
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/internal/d0;->a:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    aput-object v0, v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/google/android/gms/common/internal/t;->c([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    return v0
.end method
