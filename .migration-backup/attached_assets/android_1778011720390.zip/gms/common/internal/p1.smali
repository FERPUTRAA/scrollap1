.class public final Lcom/google/android/gms/common/internal/p1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final bridge synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "M~sl@@ @~o~~@-~ ~o t@oi~@ ~~ @~~ n~K 1@i@~ @mf ~i@ ob@v@sf ~@@4/. ~ l@r~@@@oa u ~ycbd/S~t~@~  o~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x4

    invoke-static {p1}, Lh4/a;->i0(Landroid/os/Parcel;)I

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/4 v1, 0x0

    const/4 v9, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    move v3, v1

    move v3, v1

    const/4 v10, 0x0

    move v3, v1

    move v3, v1

    move v4, v3

    move v4, v3

    const/4 v10, 0x0

    move v4, v3

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    move v5, v4

    move v5, v4

    const/4 v10, 0x4

    move v5, v4

    move v5, v4

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    move v6, v5

    move v6, v5

    const/4 v10, 0x3

    move v6, v5

    const/4 v10, 0x0

    const/4 v9, 0x4

    move v7, v6

    move v7, v6

    const/4 v10, 0x3

    move v7, v6

    move v7, v6

    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    if-ge v1, v0, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {p1}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {v1}, Lh4/a;->O(I)I

    move-result v2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    const/4 v8, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eq v2, v8, :cond_4

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/4 v8, 0x2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    if-eq v2, v8, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    const/4 v8, 0x3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-eq v2, v8, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v8, 0x4

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-eq v2, v8, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/4 v8, 0x5

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-eq v2, v8, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {p1, v1}, Lh4/a;->h0(Landroid/os/Parcel;I)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    goto :goto_0

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v7

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    goto :goto_0

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v6

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    goto :goto_0

    :cond_2
    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-static {p1, v1}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v5

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto :goto_0

    :cond_3
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-static {p1, v1}, Lh4/a;->P(Landroid/os/Parcel;I)Z

    move-result v4

    const/4 v10, 0x2

    const/4 v9, 0x6

    goto :goto_0

    :cond_4
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {p1, v1}, Lh4/a;->Z(Landroid/os/Parcel;I)I

    move-result v3

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    goto/16 :goto_0

    :cond_5
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {p1, v0}, Lh4/a;->N(Landroid/os/Parcel;I)V

    const/4 v10, 0x0

    const/4 v9, 0x5

    new-instance p1, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-direct/range {v2 .. v7}, Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;-><init>(IZZII)V

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    return-object p1
.end method

.method public final synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    new-array p1, p1, [Lcom/google/android/gms/common/internal/RootTelemetryConfiguration;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method
