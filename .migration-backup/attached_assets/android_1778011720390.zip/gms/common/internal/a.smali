.class public Lcom/google/android/gms/common/internal/a;
.super Lcom/google/android/gms/common/internal/n$a;


# direct methods
.method public static b(Lcom/google/android/gms/common/internal/n;)Landroid/accounts/Account;
    .locals 6
    .param p0    # Lcom/google/android/gms/common/internal/n;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x3

    const-string v4, " ~s@r~ @tK~~lSy ao@~oum~~@bd ~fob~ ~~ o@@ ~toM @ .-~i ~c@  @/ @ovs~i/@~~~~ ~@~ ~ nl@ @@@1@i@@b@f"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {p0}, Lcom/google/android/gms/common/internal/n;->zzb()Landroid/accounts/Account;

    move-result-object v0
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_2

    :catchall_0
    move-exception p0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_1

    :catch_0
    :try_start_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo p0, "runmAeccsscoAso"

    const-string/jumbo p0, "snsecAoccuAcsro"

    const/4 v5, 0x5

    const-string p0, "csocorcuAntAsoe"

    const-string p0, "AccountAccessor"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v3, "bomcabbcir oomRee nteucelpd stoacyd a"

    const-string v3, "eoemnblpac cc eetbo mrautidrasydcR oo"

    const/4 v5, 0x0

    const-string/jumbo v3, "y onaoueesorsmttarcaeibodeRl d c pucc"

    const-string v3, "Remote account accessor probably died"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_0

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    throw p0

    :cond_0
    :goto_2
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-object v0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x5

    throw p1
.end method

.method public final zzb()Landroid/accounts/Account;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x2

    throw v0
.end method
