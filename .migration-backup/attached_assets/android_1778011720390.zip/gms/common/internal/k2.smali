.class public final Lcom/google/android/gms/common/internal/k2;
.super Ljava/lang/Object;


# static fields
.field private static final a:Landroid/net/Uri;

.field private static final b:Landroid/net/Uri;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo v0, "m/sooh:gs/s/e.solt.cppgl"

    const-string v0, "/:slgoc.ptmgsh/tes.op/lo"

    const/4 v3, 0x0

    const-string/jumbo v0, "lohmtot/ugmle/g/pospsc.."

    const-string/jumbo v0, "https://plus.google.com/"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/gms/common/internal/k2;->a:Landroid/net/Uri;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo v1, "rimcosl"

    const-string/jumbo v1, "slemcir"

    const/4 v3, 0x6

    const-string v1, "ccislbe"

    const-string v1, "circles"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->appendPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo v1, "nfdi"

    const-string v1, "dinf"

    const/4 v3, 0x0

    const-string/jumbo v1, "fidn"

    const-string/jumbo v1, "find"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/net/Uri$Builder;->appendPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    sput-object v0, Lcom/google/android/gms/common/internal/k2;->b:Landroid/net/Uri;

    const/4 v3, 0x4

    return-void
.end method
