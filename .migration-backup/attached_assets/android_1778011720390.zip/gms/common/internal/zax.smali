.class public final Lcom/google/android/gms/common/internal/zax;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "SignInButtonConfigCreator"
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/internal/zax;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field final a:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$h;
        id = 0x1
    .end annotation
.end field

.field private final b:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getButtonSize"
        id = 0x2
    .end annotation
.end field

.field private final c:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getColorScheme"
        id = 0x3
    .end annotation
.end field

.field private final d:[Lcom/google/android/gms/common/api/Scope;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getScopes"
        id = 0x4
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    new-instance v0, Lcom/google/android/gms/common/internal/d1;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/google/android/gms/common/internal/d1;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/gms/common/internal/zax;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method constructor <init>(III[Lcom/google/android/gms/common/api/Scope;)V
    .locals 2
    .param p1    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .param p3    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3
        .end annotation
    .end param
    .param p4    # [Lcom/google/android/gms/common/api/Scope;
        .annotation build Landroidx/annotation/q0;
        .end annotation

        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x4
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/gms/common/internal/zax;->a:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p2, p0, Lcom/google/android/gms/common/internal/zax;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p3, p0, Lcom/google/android/gms/common/internal/zax;->c:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p4, p0, Lcom/google/android/gms/common/internal/zax;->d:[Lcom/google/android/gms/common/api/Scope;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ so@~~ @ @~@bc@ b .~1i/@r/ lf~@o@ atd~@~o ov@fi~@@oi~~ 4~~~b@yl@  S @ ~~ ~ms @~~@o~~ @~-utK M~n"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    iget v0, p0, Lcom/google/android/gms/common/internal/zax;->a:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p1, v2, v0}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v5, 0x4

    iget v2, p0, Lcom/google/android/gms/common/internal/zax;->b:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p1, v0, v2}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v0, 0x3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget v2, p0, Lcom/google/android/gms/common/internal/zax;->c:I

    const/4 v5, 0x4

    invoke-static {p1, v0, v2}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/internal/zax;->d:[Lcom/google/android/gms/common/api/Scope;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v3, 0x4

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p1, v3, v0, p2, v2}, Lh4/b;->c0(Landroid/os/Parcel;I[Landroid/os/Parcelable;IZ)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p1, v1}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void
.end method
