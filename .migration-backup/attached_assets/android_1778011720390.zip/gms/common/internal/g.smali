.class public final Lcom/google/android/gms/common/internal/g;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/internal/g$a;
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# instance fields
.field private final a:Landroid/accounts/Account;
    .annotation runtime Lv7/h;
    .end annotation
.end field

.field private final b:Ljava/util/Set;

.field private final c:Ljava/util/Set;

.field private final d:Ljava/util/Map;

.field private final e:I

.field private final f:Landroid/view/View;
    .annotation runtime Lv7/h;
    .end annotation
.end field

.field private final g:Ljava/lang/String;

.field private final h:Ljava/lang/String;

.field private final i:Lcom/google/android/gms/signin/a;

.field private j:Ljava/lang/Integer;


# direct methods
.method public constructor <init>(Landroid/accounts/Account;Ljava/util/Set;Ljava/util/Map;ILandroid/view/View;Ljava/lang/String;Ljava/lang/String;Lcom/google/android/gms/signin/a;)V
    .locals 10
    .param p1    # Landroid/accounts/Account;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/Set;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Landroid/view/View;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .param p6    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p7    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p8    # Lcom/google/android/gms/signin/a;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/accounts/Account;",
            "Ljava/util/Set<",
            "Lcom/google/android/gms/common/api/Scope;",
            ">;",
            "Ljava/util/Map<",
            "Lcom/google/android/gms/common/api/a<",
            "*>;",
            "Lcom/google/android/gms/common/internal/j0;",
            ">;I",
            "Landroid/view/View;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lcom/google/android/gms/signin/a;",
            ")V"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v9, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move v4, p4

    move v4, p4

    move v4, p4

    move v4, p4

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object/from16 v6, p6

    move-object/from16 v6, p6

    move-object/from16 v6, p6

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    move-object/from16 v7, p7

    move-object/from16 v7, p7

    move-object/from16 v7, p7

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    invoke-direct/range {v0 .. v9}, Lcom/google/android/gms/common/internal/g;-><init>(Landroid/accounts/Account;Ljava/util/Set;Ljava/util/Map;ILandroid/view/View;Ljava/lang/String;Ljava/lang/String;Lcom/google/android/gms/signin/a;Z)V

    return-void
.end method

.method public constructor <init>(Landroid/accounts/Account;Ljava/util/Set;Ljava/util/Map;ILandroid/view/View;Ljava/lang/String;Ljava/lang/String;Lcom/google/android/gms/signin/a;Z)V
    .locals 2
    .param p1    # Landroid/accounts/Account;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .param p2    # Ljava/util/Set;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/Map;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Landroid/view/View;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .param p6    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p7    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p8    # Lcom/google/android/gms/signin/a;
        .annotation runtime Lv7/h;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/internal/g;->a:Landroid/accounts/Account;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-nez p2, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p2}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object p1

    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/internal/g;->b:Ljava/util/Set;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    if-nez p3, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object p3

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/google/android/gms/common/internal/g;->d:Ljava/util/Map;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p5, p0, Lcom/google/android/gms/common/internal/g;->f:Landroid/view/View;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput p4, p0, Lcom/google/android/gms/common/internal/g;->e:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p6, p0, Lcom/google/android/gms/common/internal/g;->g:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p7, p0, Lcom/google/android/gms/common/internal/g;->h:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    if-nez p8, :cond_2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    sget-object p8, Lcom/google/android/gms/signin/a;->j:Lcom/google/android/gms/signin/a;

    :cond_2
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p8, p0, Lcom/google/android/gms/common/internal/g;->i:Lcom/google/android/gms/signin/a;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    new-instance p2, Ljava/util/HashSet;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p2, p1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-interface {p3}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1
    const/4 v1, 0x2

    const/4 v0, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    const/4 v1, 0x1

    const/4 v0, 0x0

    if-eqz p3, :cond_3

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    check-cast p3, Lcom/google/android/gms/common/internal/j0;

    const/4 v1, 0x4

    iget-object p3, p3, Lcom/google/android/gms/common/internal/j0;->a:Ljava/util/Set;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-interface {p2, p3}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    goto :goto_1

    :cond_3
    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p2}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/internal/g;->c:Ljava/util/Set;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/google/android/gms/common/internal/g;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/gms/common/api/l$a;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/api/l$a;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/common/api/l$a;->p()Lcom/google/android/gms/common/internal/g;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    return-object p0
.end method


# virtual methods
.method public b()Landroid/accounts/Account;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->a:Landroid/accounts/Account;

    const/4 v2, 0x0

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->a:Landroid/accounts/Account;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    move v2, v1

    iget-object v0, v0, Landroid/accounts/Account;->name:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public d()Landroid/accounts/Account;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->a:Landroid/accounts/Account;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v0, Landroid/accounts/Account;

    const/4 v3, 0x2

    move v4, v3

    const-string v1, "c<sed utnlau<sa>>fo"

    const-string/jumbo v1, "ltscau>fd>n< ceao<u"

    const/4 v4, 0x7

    const-string v1, "<<default account>>"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v2, "ocgmm.meoo"

    const-string v2, "eogmcmo.og"

    const/4 v4, 0x3

    const-string v2, ".omooeocgl"

    const-string v2, "com.google"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2}, Landroid/accounts/Account;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object v0
.end method

.method public e()Ljava/util/Set;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Lcom/google/android/gms/common/api/Scope;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->c:Ljava/util/Set;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public f(Lcom/google/android/gms/common/api/a;)Ljava/util/Set;
    .locals 4
    .param p1    # Lcom/google/android/gms/common/api/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/a<",
            "*>;)",
            "Ljava/util/Set<",
            "Lcom/google/android/gms/common/api/Scope;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->d:Ljava/util/Map;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    check-cast p1, Lcom/google/android/gms/common/internal/j0;

    const/4 v2, 0x6

    move v3, v2

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p1, Lcom/google/android/gms/common/internal/j0;->a:Ljava/util/Set;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->b:Ljava/util/Set;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v1, Ljava/util/HashSet;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v1, v0}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object p1, p1, Lcom/google/android/gms/common/internal/j0;->a:Ljava/util/Set;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v1, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v3, 0x6

    return-object v1

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/gms/common/internal/g;->b:Ljava/util/Set;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p1
.end method

.method public g()I
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/gms/common/internal/g;->e:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public h()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->g:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public i()Ljava/util/Set;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Lcom/google/android/gms/common/api/Scope;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->b:Ljava/util/Set;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public j()Landroid/view/View;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->f:Landroid/view/View;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public final k()Lcom/google/android/gms/signin/a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->i:Lcom/google/android/gms/signin/a;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public final l()Ljava/lang/Integer;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->j:Ljava/lang/Integer;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public final m()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->h:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public final n()Ljava/util/Map;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/internal/g;->d:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public final o(Ljava/lang/Integer;)V
    .locals 2
    .param p1    # Ljava/lang/Integer;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/internal/g;->j:Ljava/lang/Integer;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method
