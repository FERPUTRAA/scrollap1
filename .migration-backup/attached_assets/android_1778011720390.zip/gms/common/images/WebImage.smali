.class public final Lcom/google/android/gms/common/images/WebImage;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;


# annotations
.annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$a;
    creator = "WebImageCreator"
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/google/android/gms/common/images/WebImage;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field final a:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$h;
        id = 0x1
    .end annotation
.end field

.field private final b:Landroid/net/Uri;
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getUrl"
        id = 0x2
    .end annotation
.end field

.field private final c:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getWidth"
        id = 0x3
    .end annotation
.end field

.field private final d:I
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$c;
        getter = "getHeight"
        id = 0x4
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/images/i;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/android/gms/common/images/i;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    sput-object v0, Lcom/google/android/gms/common/images/WebImage;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method constructor <init>(ILandroid/net/Uri;II)V
    .locals 2
    .param p1    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x1
        .end annotation
    .end param
    .param p2    # Landroid/net/Uri;
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x2
        .end annotation
    .end param
    .param p3    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x3
        .end annotation
    .end param
    .param p4    # I
        .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$e;
            id = 0x4
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable$b;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/gms/common/images/WebImage;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/android/gms/common/images/WebImage;->b:Landroid/net/Uri;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p3, p0, Lcom/google/android/gms/common/images/WebImage;->c:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p4, p0, Lcom/google/android/gms/common/images/WebImage;->d:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/net/Uri;)V
    .locals 3
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, p1, v0, v0}, Lcom/google/android/gms/common/images/WebImage;-><init>(Landroid/net/Uri;II)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/net/Uri;II)V
    .locals 3
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    invoke-direct {p0, v0, p1, p2, p3}, Lcom/google/android/gms/common/images/WebImage;-><init>(ILandroid/net/Uri;II)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    if-eqz p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-ltz p2, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-ltz p3, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string/jumbo p2, "mss twnvn geautndaehihiebot htite g d"

    const-string/jumbo p2, "hesbha theewd dugvn nagmtoie i  inttt"

    const/4 v2, 0x4

    const-string p2, " nhmhteewde ave thto iuaindbmgts tgni"

    const-string/jumbo p2, "width and height must not be negative"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    throw p1

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x1

    const-string p2, " r nolt luocbnamle"

    const-string p2, " nlmlrn luanb cteo"

    const/4 v2, 0x5

    const-string/jumbo p2, "l ounbtcreuall nnb"

    const-string/jumbo p2, "url cannot be null"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    throw p1
.end method

.method public constructor <init>(Lorg/json/JSONObject;)V
    .locals 6
    .param p1    # Lorg/json/JSONObject;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget-object v0, Landroid/net/Uri;->EMPTY:Landroid/net/Uri;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v1, "rul"

    const-string/jumbo v1, "ulr"

    const/4 v5, 0x3

    const-string/jumbo v1, "rlu"

    const-string/jumbo v1, "url"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v2, :cond_0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v1, "hudwt"

    const-string/jumbo v1, "wtdho"

    const/4 v5, 0x3

    const-string/jumbo v1, "wipht"

    const-string/jumbo v1, "width"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const-string/jumbo v3, "geqthi"

    const-string/jumbo v3, "gthieb"

    const/4 v5, 0x2

    const-string/jumbo v3, "htshge"

    const-string/jumbo v3, "height"

    const/4 v5, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1, v3, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {p0, v0, v1, p1}, Lcom/google/android/gms/common/images/WebImage;-><init>(Landroid/net/Uri;II)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-void
.end method


# virtual methods
.method public b()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o~~m@@~  4@@n~/y@  art~~ @@b@ i~K t@lli  @~ ~  i@ b@u~~ -~@~@bfo@M o~~o~~/~m@.sodf@@o 1~~@cS~v@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/gms/common/images/WebImage;->d:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-ne p0, p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    instance-of v2, p1, Lcom/google/android/gms/common/images/WebImage;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    check-cast p1, Lcom/google/android/gms/common/images/WebImage;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/google/android/gms/common/images/WebImage;->b:Landroid/net/Uri;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v3, p1, Lcom/google/android/gms/common/images/WebImage;->b:Landroid/net/Uri;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v2, v3}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget v2, p0, Lcom/google/android/gms/common/images/WebImage;->c:I

    const/4 v4, 0x6

    move v5, v4

    iget v3, p1, Lcom/google/android/gms/common/images/WebImage;->c:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-ne v2, v3, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget v2, p0, Lcom/google/android/gms/common/images/WebImage;->d:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget p1, p1, Lcom/google/android/gms/common/images/WebImage;->d:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-ne v2, p1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x7

    return v0

    :cond_2
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    return v1
.end method

.method public f()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/gms/common/images/WebImage;->c:I

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    return v0
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/images/WebImage;->b:Landroid/net/Uri;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v1, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x5

    shr-int/2addr v4, v3

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    aput-object v0, v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/android/gms/common/images/WebImage;->c:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    aput-object v0, v1, v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/android/gms/common/images/WebImage;->d:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    aput-object v0, v1, v2

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/internal/t;->c([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 6
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v1, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x3

    iget v2, p0, Lcom/google/android/gms/common/images/WebImage;->c:I

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x6

    aput-object v2, v1, v3

    const/4 v5, 0x7

    iget v2, p0, Lcom/google/android/gms/common/images/WebImage;->d:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v3, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    aput-object v2, v1, v3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/images/WebImage;->b:Landroid/net/Uri;

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v3, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x4

    aput-object v2, v1, v3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo v2, "sxgmo dedu%a% "

    const-string v2, " %desguamd% %x"

    const/4 v5, 0x4

    const-string v2, "Igda bd%% e%ms"

    const-string v2, "Image %dx%d %s"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v0, v2, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 6
    .param p1    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget v0, p0, Lcom/google/android/gms/common/images/WebImage;->a:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p1}, Lh4/b;->a(Landroid/os/Parcel;)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x4

    move v5, v4

    invoke-static {p1, v2, v0}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/android/gms/common/images/WebImage;->y2()Landroid/net/Uri;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v3, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {p1, v3, v0, p2, v2}, Lh4/b;->S(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 p2, 0x3

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/common/images/WebImage;->f()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-static {p1, p2, v0}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v5, 0x1

    const/4 p2, 0x4

    const/4 v5, 0x3

    const/4 p2, 0x4

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/common/images/WebImage;->b()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p1, p2, v0}, Lh4/b;->F(Landroid/os/Parcel;II)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p1, v1}, Lh4/b;->b(Landroid/os/Parcel;I)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void
.end method

.method public y2()Landroid/net/Uri;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/images/WebImage;->b:Landroid/net/Uri;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public z2()Lorg/json/JSONObject;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo v1, "lur"

    const-string/jumbo v1, "lru"

    const/4 v4, 0x1

    const-string/jumbo v1, "url"

    const-string/jumbo v1, "url"

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/android/gms/common/images/WebImage;->b:Landroid/net/Uri;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v1, "wuitd"

    const-string v1, "dwpit"

    const/4 v4, 0x5

    const-string/jumbo v1, "hwptd"

    const-string/jumbo v1, "width"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v2, p0, Lcom/google/android/gms/common/images/WebImage;->c:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v1, "tgqhih"

    const-string/jumbo v1, "height"

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/android/gms/common/images/WebImage;->d:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object v0
.end method
