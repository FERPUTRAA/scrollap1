.class final Lcom/google/android/gms/common/images/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final a:Landroid/net/Uri;

.field private final b:Landroid/graphics/Bitmap;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final c:Ljava/util/concurrent/CountDownLatch;

.field final synthetic d:Lcom/google/android/gms/common/images/ImageManager;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/images/ImageManager;Landroid/net/Uri;Landroid/graphics/Bitmap;ZLjava/util/concurrent/CountDownLatch;)V
    .locals 2
    .param p2    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/images/d;->d:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v1, 0x0

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/gms/common/images/d;->a:Landroid/net/Uri;

    const/4 v1, 0x0

    const/4 v0, 0x7

    iput-object p3, p0, Lcom/google/android/gms/common/images/d;->b:Landroid/graphics/Bitmap;

    const/4 v1, 0x6

    const/4 v0, 0x2

    iput-object p5, p0, Lcom/google/android/gms/common/images/d;->c:Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, " is@t~~r@~m@o@@ @ffi@K~~b @~ @b~@~@~~ ~~y o ~~to@@   ~@vo4  ~~ ~@ lo@~@b d @c -S~@/1~su@ln~Mioa/"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x0

    const-string/jumbo v0, "euima On btenu tmunRstsee mbaa xLda mnni eehrldpitthaeodec"

    const-string v0, "disaau t tdeeuarumiexnmpoLetdc Om te nas Rdh enathnibenlbe"

    const-string v0, "BnLeormthR eioshxt diueebdamndbtaantali Oece mdtunn  upea "

    const-string v0, "OnBitmapLoadedRunnable must be executed in the main thread"

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/internal/d;->a(Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/images/d;->d:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v0}, Lcom/google/android/gms/common/images/ImageManager;->n(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/images/d;->a:Landroid/net/Uri;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-interface {v0, v1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    check-cast v0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-eqz v0, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->a(Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    const/4 v2, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    move v3, v2

    move v3, v2

    const/4 v10, 0x1

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-ge v3, v1, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    check-cast v4, Lcom/google/android/gms/common/images/h;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object v5, p0, Lcom/google/android/gms/common/images/d;->b:Landroid/graphics/Bitmap;

    const/4 v10, 0x5

    if-eqz v5, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x5

    iget-object v6, p0, Lcom/google/android/gms/common/images/d;->d:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {v6}, Lcom/google/android/gms/common/images/ImageManager;->g(Lcom/google/android/gms/common/images/ImageManager;)Landroid/content/Context;

    move-result-object v6

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v4, v6, v5, v2}, Lcom/google/android/gms/common/images/h;->c(Landroid/content/Context;Landroid/graphics/Bitmap;Z)V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    goto :goto_1

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-object v5, p0, Lcom/google/android/gms/common/images/d;->d:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v6, p0, Lcom/google/android/gms/common/images/d;->a:Landroid/net/Uri;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-static {v5}, Lcom/google/android/gms/common/images/ImageManager;->l(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;

    move-result-object v5

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v7

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-interface {v5, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object v5, p0, Lcom/google/android/gms/common/images/d;->d:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {v5}, Lcom/google/android/gms/common/images/ImageManager;->g(Lcom/google/android/gms/common/images/ImageManager;)Landroid/content/Context;

    move-result-object v6

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {v5}, Lcom/google/android/gms/common/images/ImageManager;->i(Lcom/google/android/gms/common/images/ImageManager;)Lcom/google/android/gms/internal/base/zam;

    move-result-object v5

    const/4 v10, 0x3

    const/4 v9, 0x2

    invoke-virtual {v4, v6, v5, v2}, Lcom/google/android/gms/common/images/h;->b(Landroid/content/Context;Lcom/google/android/gms/internal/base/zam;Z)V

    :goto_1
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    instance-of v5, v4, Lcom/google/android/gms/common/images/g;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-nez v5, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget-object v5, p0, Lcom/google/android/gms/common/images/d;->d:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {v5}, Lcom/google/android/gms/common/images/ImageManager;->m(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;

    move-result-object v5

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-interface {v5, v4}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    goto/16 :goto_0

    :cond_2
    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/images/d;->c:Ljava/util/concurrent/CountDownLatch;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {}, Lcom/google/android/gms/common/images/ImageManager;->j()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v9, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-static {}, Lcom/google/android/gms/common/images/ImageManager;->k()Ljava/util/HashSet;

    move-result-object v1

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-object v2, p0, Lcom/google/android/gms/common/images/d;->a:Landroid/net/Uri;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v1, v2}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    monitor-exit v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    return-void

    :catchall_0
    move-exception v1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    throw v1
.end method
