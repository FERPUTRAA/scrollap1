.class public abstract Lcom/google/android/gms/common/images/h;
.super Ljava/lang/Object;


# instance fields
.field final a:Lcom/google/android/gms/common/images/e;

.field protected b:I


# direct methods
.method public constructor <init>(Landroid/net/Uri;I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/gms/common/images/h;->b:I

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/gms/common/images/e;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0, p1}, Lcom/google/android/gms/common/images/e;-><init>(Landroid/net/Uri;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/gms/common/images/h;->a:Lcom/google/android/gms/common/images/e;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput p2, p0, Lcom/google/android/gms/common/images/h;->b:I

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method protected abstract a(Landroid/graphics/drawable/Drawable;ZZZ)V
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
.end method

.method final b(Landroid/content/Context;Lcom/google/android/gms/internal/base/zam;Z)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "ots@o  v@~~~~~b~S @ ~~~@@   o / ~@bm ~~s@  @@~noloKo@~ @@~ @~@@tf@/ riu.f~cd~~~1@b@ay~il@ - 4i@M"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget p2, p0, Lcom/google/android/gms/common/images/h;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    if-eqz p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    const/4 p2, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p3, p2, p2}, Lcom/google/android/gms/common/images/h;->a(Landroid/graphics/drawable/Drawable;ZZZ)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method final c(Landroid/content/Context;Landroid/graphics/Bitmap;Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p2}, Lcom/google/android/gms/common/internal/d;->c(Ljava/lang/Object;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    new-instance p3, Landroid/graphics/drawable/BitmapDrawable;

    const/4 v0, 0x1

    move v1, v0

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p3, p1, p2}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 p2, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p3, p1, p1, p2}, Lcom/google/android/gms/common/images/h;->a(Landroid/graphics/drawable/Drawable;ZZZ)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method
