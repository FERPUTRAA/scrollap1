.class public final Lcom/google/android/gms/common/images/g;
.super Lcom/google/android/gms/common/images/h;


# instance fields
.field private final c:Ljava/lang/ref/WeakReference;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/images/ImageManager$a;Landroid/net/Uri;)V
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0, p2, v0}, Lcom/google/android/gms/common/images/h;-><init>(Landroid/net/Uri;I)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/internal/d;->c(Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance p2, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p2, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/google/android/gms/common/images/g;->c:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method protected final a(Landroid/graphics/drawable/Drawable;ZZZ)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "/@s4~o@o@lu@ ro  @cb@b~~S ~@@@@i~ao  @K@@ ~  ~d   @~~n~~i ~fm ~.Mti~sbo~ @@v/~@@-y~~o@t1 ~lf~~@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    if-nez p3, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget-object p2, p0, Lcom/google/android/gms/common/images/g;->c:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    check-cast p2, Lcom/google/android/gms/common/images/ImageManager$a;

    const/4 v1, 0x4

    if-eqz p2, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p3, p0, Lcom/google/android/gms/common/images/h;->a:Lcom/google/android/gms/common/images/e;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget-object p3, p3, Lcom/google/android/gms/common/images/e;->a:Landroid/net/Uri;

    const/4 v0, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-interface {p2, p3, p1, p4}, Lcom/google/android/gms/common/images/ImageManager$a;->a(Landroid/net/Uri;Landroid/graphics/drawable/Drawable;Z)V

    :cond_0
    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v0, 0x1

    const/4 v4, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-ne p0, p1, :cond_0

    const/4 v5, 0x3

    return v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    instance-of v1, p1, Lcom/google/android/gms/common/images/g;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x3

    if-nez v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    return v2

    :cond_1
    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    check-cast p1, Lcom/google/android/gms/common/images/g;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/images/g;->c:Ljava/lang/ref/WeakReference;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast v1, Lcom/google/android/gms/common/images/ImageManager$a;

    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v3, p1, Lcom/google/android/gms/common/images/g;->c:Ljava/lang/ref/WeakReference;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x4

    check-cast v3, Lcom/google/android/gms/common/images/ImageManager$a;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v3, :cond_2

    const/4 v4, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-static {v3, v1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v1, :cond_2

    const/4 v5, 0x1

    iget-object p1, p1, Lcom/google/android/gms/common/images/h;->a:Lcom/google/android/gms/common/images/e;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/images/h;->a:Lcom/google/android/gms/common/images/e;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p1, v1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz p1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    return v0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    return v2
.end method

.method public final hashCode()I
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/images/h;->a:Lcom/google/android/gms/common/images/e;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v2, 0x5

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    aput-object v0, v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v1}, Lcom/google/android/gms/common/internal/t;->c([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0
.end method
