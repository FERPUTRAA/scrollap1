.class public final Lcom/google/android/gms/common/images/a;
.super Ljava/lang/Object;


# instance fields
.field private final a:I

.field private final b:I


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/gms/common/images/a;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p2, p0, Lcom/google/android/gms/common/images/a;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public static c(Ljava/lang/String;)Lcom/google/android/gms/common/images/a;
    .locals 5
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/NumberFormatException;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz p0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/16 v0, 0x2a

    const/4 v4, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-gez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/16 v0, 0x78

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-ltz v0, :cond_1

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    new-instance v1, Lcom/google/android/gms/common/images/a;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0, v2, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v1, v2, v0}, Lcom/google/android/gms/common/images/a;-><init>(II)V
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object v1

    :catch_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/google/android/gms/common/images/a;->d(Ljava/lang/String;)Ljava/lang/NumberFormatException;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    throw p0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/google/android/gms/common/images/a;->d(Ljava/lang/String;)Ljava/lang/NumberFormatException;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    throw p0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v0, "btsutlrnsis  tu lmso ge"

    const-string v0, "e sl bogmnttiu utns rsl"

    const-string/jumbo v0, "string must not be null"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    throw p0
.end method

.method private static d(Ljava/lang/String;)Ljava/lang/NumberFormatException;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/NumberFormatException;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    move v4, v3

    const-string v2, ": Imzindam/ iSe/"

    const-string v2, ":dem/zliiS/a  In"

    const/4 v4, 0x5

    const-string v2, "dI So iiav/nez/:"

    const-string v2, "Invalid Size: \""

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string p0, "//"

    const-string p0, "//"

    const/4 v4, 0x2

    const-string p0, "//"

    const-string p0, "\""

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0, p0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    throw v0
.end method


# virtual methods
.method public a()I
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/gms/common/images/a;->b:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    iget v0, p0, Lcom/google/android/gms/common/images/a;->a:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez p1, :cond_0

    const/4 v5, 0x0

    return v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-ne p0, p1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    return v1

    :cond_1
    const/4 v4, 0x1

    const/4 v5, 0x2

    instance-of v2, p1, Lcom/google/android/gms/common/images/a;

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    check-cast p1, Lcom/google/android/gms/common/images/a;

    const/4 v5, 0x0

    const/4 v4, 0x4

    iget v2, p0, Lcom/google/android/gms/common/images/a;->a:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v3, p1, Lcom/google/android/gms/common/images/a;->a:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-ne v2, v3, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget v2, p0, Lcom/google/android/gms/common/images/a;->b:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget p1, p1, Lcom/google/android/gms/common/images/a;->b:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ne v2, p1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    return v1

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    return v0
.end method

.method public hashCode()I
    .locals 5

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/android/gms/common/images/a;->a:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    shl-int/lit8 v1, v0, 0x10

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    ushr-int/lit8 v0, v0, 0x10

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v2, p0, Lcom/google/android/gms/common/images/a;->b:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    or-int/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    xor-int/2addr v0, v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    move v3, v2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/android/gms/common/images/a;->a:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    const-string/jumbo v1, "x"

    const-string/jumbo v1, "x"

    const/4 v3, 0x6

    const-string/jumbo v1, "x"

    const-string/jumbo v1, "x"

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/gms/common/images/a;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method
