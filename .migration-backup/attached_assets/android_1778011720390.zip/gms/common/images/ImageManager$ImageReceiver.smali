.class final Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;
.super Landroid/os/ResultReceiver;


# annotations
.annotation build Lcom/google/android/gms/common/annotation/KeepName;
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/common/images/ImageManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "ImageReceiver"
.end annotation


# instance fields
.field private final a:Landroid/net/Uri;

.field private final b:Ljava/util/ArrayList;

.field final synthetic c:Lcom/google/android/gms/common/images/ImageManager;


# direct methods
.method constructor <init>(Lcom/google/android/gms/common/images/ImageManager;Landroid/net/Uri;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->c:Lcom/google/android/gms/common/images/ImageManager;

    new-instance p1, Lcom/google/android/gms/internal/base/zau;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Lcom/google/android/gms/internal/base/zau;-><init>(Landroid/os/Looper;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Landroid/os/ResultReceiver;-><init>(Landroid/os/Handler;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p2, p0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->a:Landroid/net/Uri;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance p1, Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->b:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method static bridge synthetic a(Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;)Ljava/util/ArrayList;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "d~sat~~mt@ y@~~@@/@ K~~ o ~~b bS ~v@1 l@4 ~@@~   @l ~@cffor@b@@ ~~@@/so ~Mou. i~@o@ i~@ ~-~o@~in"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->b:Ljava/util/ArrayList;

    const/4 v1, 0x4

    return-object p0
.end method


# virtual methods
.method public final c(Lcom/google/android/gms/common/images/h;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, "agdmtmiu tetaqneRbeaeRrce venlmeieal uh)ms. hc dtgdes (mIIaisd ae"

    const-string v0, "c sael(eta elhteeraumsr eIdtt)v mhee.a dnedca IminsqdRieambgRuig "

    const/4 v2, 0x4

    const-string v0, "aRamodeh  geecuim.dmumetetele (R  r iqa ia)tbtIInselcdegnvhaseade"

    const-string v0, "ImageReceiver.addImageRequest() must be called in the main thread"

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/internal/d;->a(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->b:Ljava/util/ArrayList;

    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public final d(Lcom/google/android/gms/common/images/h;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string/jumbo v0, "eteqRbeadil vIdgaRe(mI umgaseu)rean  elmetcvm itsee ebrehitn arm.ehm"

    const-string/jumbo v0, "mIRmIRtneareaaea  eieeubc(v)mg ie idmu sthe mgcnmteqeesllhtedrev.r a"

    const/4 v2, 0x3

    const-string/jumbo v0, "udevveuenRhureeeim erqtmelInttRe mr(eei)ceeia a ma  otbgmda. sslIacg"

    const-string v0, "ImageReceiver.removeImageRequest() must be called in the main thread"

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/d;->a(Ljava/lang/String;)V

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->b:Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public final e()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo v1, "mDoGasgp.sdIeoaiEmgemgc.id..AAOoMnlmroncL.o_g.o"

    const-string v1, "cgemoDG.M.ags.oO.E_amrAiesgILndg.n.oAmcmoiodolm"

    const/4 v4, 0x4

    const-string/jumbo v1, "gL.gG.msqD_oMmgi.nOeaAgEAoamro.ismleocodomcnd.."

    const-string v1, "com.google.android.gms.common.images.LOAD_IMAGE"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const-string/jumbo v1, "oas.oli.dsoggdmone.mrg"

    const-string v1, "com.google.android.gms"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v1, "d.gmelm.comonagbus.og.x.drisarito"

    const-string/jumbo v1, "ot..rboxdliurosm.og.msenciag.dgea"

    const/4 v4, 0x0

    const-string/jumbo v1, "og.go.dem.raisadoxs.oonicrerl.umg"

    const-string v1, "com.google.android.gms.extras.uri"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->a:Landroid/net/Uri;

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v1, "usxd.b.em.Ru.ggtgteasnereri.rlasooveldoiermc"

    const-string/jumbo v1, "tdsuliugr.oosmrRcisg.erad.ogeer.eo.xnteamlev"

    const/4 v4, 0x5

    const-string/jumbo v1, "g.rigouvdgcrseooailmscaeRxuem.dstlr..eenreo."

    const-string v1, "com.google.android.gms.extras.resultReceiver"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v1, "griiaaxpyolsdg.p.i.etgtoo.rmropocd.rnm"

    const-string/jumbo v1, "raropilpisyecngodoeir..xg..omorgtdmta."

    const/4 v4, 0x4

    const-string v1, ".e.c.tpaqros.aoinlrdiotdo.esxrgiommgyg"

    const-string v1, "com.google.android.gms.extras.priority"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v2, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->c:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/google/android/gms/common/images/ImageManager;->g(Lcom/google/android/gms/common/images/ImageManager;)Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void
.end method

.method public final onReceiveResult(ILandroid/os/Bundle;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string p1, ".rsae.r.nxodeoltgfisgti.mm.eerooocrDpcsgail"

    const-string p1, "com.google.android.gms.extra.fileDescriptor"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    check-cast p1, Landroid/os/ParcelFileDescriptor;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object p2, p0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->c:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->a:Landroid/net/Uri;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p2}, Lcom/google/android/gms/common/images/ImageManager;->o(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/concurrent/ExecutorService;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v2, Lcom/google/android/gms/common/images/b;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v2, p2, v0, p1}, Lcom/google/android/gms/common/images/b;-><init>(Lcom/google/android/gms/common/images/ImageManager;Landroid/net/Uri;Landroid/os/ParcelFileDescriptor;)V

    const/4 v4, 0x7

    invoke-interface {v1, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method
