.class public final Lcom/google/android/gms/common/images/f;
.super Lcom/google/android/gms/common/images/h;


# instance fields
.field private final c:Ljava/lang/ref/WeakReference;


# direct methods
.method public constructor <init>(Landroid/widget/ImageView;I)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Landroid/net/Uri;->EMPTY:Landroid/net/Uri;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0, v0, p2}, Lcom/google/android/gms/common/images/h;-><init>(Landroid/net/Uri;I)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/internal/d;->c(Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p2, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p2, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object p2, p0, Lcom/google/android/gms/common/images/f;->c:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/widget/ImageView;Landroid/net/Uri;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0, p2, v0}, Lcom/google/android/gms/common/images/h;-><init>(Landroid/net/Uri;I)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/d;->c(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance p2, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-direct {p2, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/google/android/gms/common/images/f;->c:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method protected final a(Landroid/graphics/drawable/Drawable;ZZZ)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @s4loml~b@ c @bo   ~@~@~-oK@tt @M~ /@~ony/~@ u~@~i~@ @a @@~i@@sf1@~S~ i~~ @ ~~  ro~fv@~b~o ~~@d"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/images/f;->c:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    check-cast v0, Landroid/widget/ImageView;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_8

    const/4 v2, 0x2

    move v3, v2

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez p3, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez p4, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    instance-of p4, v0, Lcom/google/android/gms/internal/base/zal;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez p4, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    check-cast v0, Lcom/google/android/gms/internal/base/zal;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw v1

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p4, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez p3, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p2, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_1

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 p4, 0x1

    :cond_3
    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz p4, :cond_6

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz p2, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    instance-of p3, p2, Lcom/google/android/gms/internal/base/zak;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz p3, :cond_5

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast p2, Lcom/google/android/gms/internal/base/zak;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p2}, Lcom/google/android/gms/internal/base/zak;->zaa()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_2

    :cond_4
    move-object p2, v1

    move-object p2, v1

    :cond_5
    :goto_2
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance p3, Lcom/google/android/gms/internal/base/zak;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p3, p2, p1}, Lcom/google/android/gms/internal/base/zak;-><init>(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    move-object p1, p3

    move-object p1, p3

    move-object p1, p3

    move-object p1, p3

    :cond_6
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    instance-of p2, v0, Lcom/google/android/gms/internal/base/zal;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-nez p2, :cond_7

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p1, :cond_8

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p4, :cond_8

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast p1, Lcom/google/android/gms/internal/base/zak;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/16 p2, 0xfa

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Lcom/google/android/gms/internal/base/zak;->zab(I)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    return-void

    :cond_7
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast v0, Lcom/google/android/gms/internal/base/zal;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    throw v1

    :cond_8
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-ne p0, p1, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    return v0

    :cond_0
    const/4 v3, 0x5

    move v4, v3

    instance-of v1, p1, Lcom/google/android/gms/common/images/f;

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-nez v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    return v2

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    check-cast p1, Lcom/google/android/gms/common/images/f;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/android/gms/common/images/f;->c:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    check-cast v1, Landroid/widget/ImageView;

    const/4 v4, 0x5

    iget-object p1, p1, Lcom/google/android/gms/common/images/f;->c:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    check-cast p1, Landroid/widget/ImageView;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz p1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_2

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    invoke-static {p1, v1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    return v0

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v2
.end method

.method public final hashCode()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method
