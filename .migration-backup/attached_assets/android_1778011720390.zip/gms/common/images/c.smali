.class final Lcom/google/android/gms/common/images/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final a:Lcom/google/android/gms/common/images/h;

.field final synthetic b:Lcom/google/android/gms/common/images/ImageManager;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/images/ImageManager;Lcom/google/android/gms/common/images/h;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/images/c;->b:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/gms/common/images/c;->a:Lcom/google/android/gms/common/images/h;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "t~s@  @@@@@t 1~ @  K~~b-~a~s ~r/~fSy M@~@niool~~o ~c@@o@~~i@~ vo~~ @  fd@@o  ~m@@ .@/l 4~bu~i~@~"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x7

    const-string/jumbo v0, "neemdagmbdnr abtm hmattnILxtsued  hs ecuneo Raai eoee"

    const-string/jumbo v0, "sesgalmab ximnannudcd etR meabuett  endrt heoh eoIaeL"

    const/4 v9, 0x2

    const-string/jumbo v0, "staeo eeahdLmoetngxmae ce te oRuaIbe ddatuul nrbmn nh"

    const-string v0, "LoadImageRunnable must be executed on the main thread"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/internal/d;->a(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/images/c;->b:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v9, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/images/ImageManager;->m(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/images/c;->a:Lcom/google/android/gms/common/images/h;

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    check-cast v0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-eqz v0, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/images/c;->b:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v9, 0x3

    const/4 v8, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/images/c;->a:Lcom/google/android/gms/common/images/h;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {v1}, Lcom/google/android/gms/common/images/ImageManager;->m(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-interface {v1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x4

    iget-object v1, p0, Lcom/google/android/gms/common/images/c;->a:Lcom/google/android/gms/common/images/h;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v0, v1}, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->d(Lcom/google/android/gms/common/images/h;)V

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/images/c;->a:Lcom/google/android/gms/common/images/h;

    const/4 v9, 0x2

    iget-object v1, v0, Lcom/google/android/gms/common/images/h;->a:Lcom/google/android/gms/common/images/e;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v2, v1, Lcom/google/android/gms/common/images/e;->a:Landroid/net/Uri;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    const/4 v3, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-eqz v2, :cond_6

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/images/c;->b:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/images/ImageManager;->l(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    check-cast v0, Ljava/lang/Long;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-eqz v0, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    sub-long/2addr v4, v6

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-wide/32 v6, 0x36ee80

    const-wide/32 v6, 0x36ee80

    const/4 v9, 0x5

    const-wide/32 v6, 0x36ee80

    const-wide/32 v6, 0x36ee80

    const/4 v8, 0x2

    move v9, v8

    cmp-long v0, v4, v6

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-gez v0, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/images/c;->a:Lcom/google/android/gms/common/images/h;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/images/c;->b:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v9, 0x3

    const/4 v8, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/images/ImageManager;->g(Lcom/google/android/gms/common/images/ImageManager;)Landroid/content/Context;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {v1}, Lcom/google/android/gms/common/images/ImageManager;->i(Lcom/google/android/gms/common/images/ImageManager;)Lcom/google/android/gms/internal/base/zam;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v0, v2, v1, v3}, Lcom/google/android/gms/common/images/h;->b(Landroid/content/Context;Lcom/google/android/gms/internal/base/zam;Z)V

    return-void

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/images/c;->b:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v2, v1, Lcom/google/android/gms/common/images/e;->a:Landroid/net/Uri;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {v0}, Lcom/google/android/gms/common/images/ImageManager;->l(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-interface {v0, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/google/android/gms/common/images/c;->a:Lcom/google/android/gms/common/images/h;

    const/4 v8, 0x3

    move v9, v8

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v0, v2, v4, v3, v4}, Lcom/google/android/gms/common/images/h;->a(Landroid/graphics/drawable/Drawable;ZZZ)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/images/c;->b:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v9, 0x5

    iget-object v2, v1, Lcom/google/android/gms/common/images/e;->a:Landroid/net/Uri;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/images/ImageManager;->n(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    check-cast v0, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-nez v0, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/images/c;->b:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v2, v1, Lcom/google/android/gms/common/images/e;->a:Landroid/net/Uri;

    const/4 v9, 0x7

    const/4 v8, 0x5

    new-instance v3, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-direct {v3, v0, v2}, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;-><init>(Lcom/google/android/gms/common/images/ImageManager;Landroid/net/Uri;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/images/c;->b:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget-object v2, v1, Lcom/google/android/gms/common/images/e;->a:Landroid/net/Uri;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/google/android/gms/common/images/ImageManager;->n(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-interface {v0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x1

    iget-object v2, p0, Lcom/google/android/gms/common/images/c;->a:Lcom/google/android/gms/common/images/h;

    const/4 v9, 0x2

    const/4 v8, 0x0

    invoke-virtual {v0, v2}, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->c(Lcom/google/android/gms/common/images/h;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-object v2, p0, Lcom/google/android/gms/common/images/c;->a:Lcom/google/android/gms/common/images/h;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    instance-of v3, v2, Lcom/google/android/gms/common/images/g;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-nez v3, :cond_4

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v3, p0, Lcom/google/android/gms/common/images/c;->b:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {v3}, Lcom/google/android/gms/common/images/ImageManager;->m(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {v3, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_4
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {}, Lcom/google/android/gms/common/images/ImageManager;->j()Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    monitor-enter v2

    :try_start_0
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {}, Lcom/google/android/gms/common/images/ImageManager;->k()Ljava/util/HashSet;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    iget-object v4, v1, Lcom/google/android/gms/common/images/e;->a:Landroid/net/Uri;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v3, v4}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-nez v3, :cond_5

    const/4 v8, 0x3

    or-int/2addr v9, v8

    invoke-static {}, Lcom/google/android/gms/common/images/ImageManager;->k()Ljava/util/HashSet;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v1, v1, Lcom/google/android/gms/common/images/e;->a:Landroid/net/Uri;

    const/4 v8, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v3, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v0}, Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;->e()V

    :cond_5
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    monitor-exit v2

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    throw v0

    :cond_6
    const/4 v9, 0x5

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/google/android/gms/common/images/c;->b:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/images/ImageManager;->g(Lcom/google/android/gms/common/images/ImageManager;)Landroid/content/Context;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static {v1}, Lcom/google/android/gms/common/images/ImageManager;->i(Lcom/google/android/gms/common/images/ImageManager;)Lcom/google/android/gms/internal/base/zam;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v0, v2, v1, v3}, Lcom/google/android/gms/common/images/h;->b(Landroid/content/Context;Lcom/google/android/gms/internal/base/zam;Z)V

    const/4 v9, 0x6

    return-void
.end method
