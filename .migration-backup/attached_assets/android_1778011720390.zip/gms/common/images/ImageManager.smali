.class public final Lcom/google/android/gms/common/images/ImageManager;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/gms/common/images/ImageManager$a;,
        Lcom/google/android/gms/common/images/ImageManager$ImageReceiver;
    }
.end annotation


# static fields
.field private static final h:Ljava/lang/Object;

.field private static final i:Ljava/util/HashSet;

.field private static j:Lcom/google/android/gms/common/images/ImageManager;


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Landroid/os/Handler;

.field private final c:Ljava/util/concurrent/ExecutorService;

.field private final d:Lcom/google/android/gms/internal/base/zam;

.field private final e:Ljava/util/Map;

.field private final f:Ljava/util/Map;

.field private final g:Ljava/util/Map;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    sput-object v0, Lcom/google/android/gms/common/images/ImageManager;->h:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    sput-object v0, Lcom/google/android/gms/common/images/ImageManager;->i:Ljava/util/HashSet;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Z)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/gms/common/images/ImageManager;->a:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance p1, Lcom/google/android/gms/internal/base/zau;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p1, p2}, Lcom/google/android/gms/internal/base/zau;-><init>(Landroid/os/Looper;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/gms/common/images/ImageManager;->b:Landroid/os/Handler;

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/gms/internal/base/zat;->zaa()Lcom/google/android/gms/internal/base/zaq;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p2, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {p1, p2, v0}, Lcom/google/android/gms/internal/base/zaq;->zab(II)Ljava/util/concurrent/ExecutorService;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/images/ImageManager;->c:Ljava/util/concurrent/ExecutorService;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance p1, Lcom/google/android/gms/internal/base/zam;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p1}, Lcom/google/android/gms/internal/base/zam;-><init>()V

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/images/ImageManager;->d:Lcom/google/android/gms/internal/base/zam;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance p1, Ljava/util/HashMap;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/images/ImageManager;->e:Ljava/util/Map;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance p1, Ljava/util/HashMap;

    const/4 v1, 0x7

    shr-int/2addr v2, v1

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/images/ImageManager;->f:Ljava/util/Map;

    const/4 v2, 0x7

    const/4 v1, 0x0

    new-instance p1, Ljava/util/HashMap;

    const/4 v1, 0x7

    or-int/2addr v2, v1

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/images/ImageManager;->g:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/google/android/gms/common/images/ImageManager;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "K~sbl~@/~~@ @@~/ur~~ @. o~~@~it~ias1 4 @o@S  @c@~~fvb@~@ y@nomi f   tlo~b o@@@-@ M@@ ~d~~~ o~@~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget-object v0, Lcom/google/android/gms/common/images/ImageManager;->j:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Lcom/google/android/gms/common/images/ImageManager;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v0, p0, v1}, Lcom/google/android/gms/common/images/ImageManager;-><init>(Landroid/content/Context;Z)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    sput-object v0, Lcom/google/android/gms/common/images/ImageManager;->j:Lcom/google/android/gms/common/images/ImageManager;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget-object p0, Lcom/google/android/gms/common/images/ImageManager;->j:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    return-object p0
.end method

.method static bridge synthetic g(Lcom/google/android/gms/common/images/ImageManager;)Landroid/content/Context;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/gms/common/images/ImageManager;->a:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method static bridge synthetic h(Lcom/google/android/gms/common/images/ImageManager;)Landroid/os/Handler;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    iget-object p0, p0, Lcom/google/android/gms/common/images/ImageManager;->b:Landroid/os/Handler;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method static bridge synthetic i(Lcom/google/android/gms/common/images/ImageManager;)Lcom/google/android/gms/internal/base/zam;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    iget-object p0, p0, Lcom/google/android/gms/common/images/ImageManager;->d:Lcom/google/android/gms/internal/base/zam;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method static bridge synthetic j()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/gms/common/images/ImageManager;->h:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method static bridge synthetic k()Ljava/util/HashSet;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/gms/common/images/ImageManager;->i:Ljava/util/HashSet;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method static bridge synthetic l(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/gms/common/images/ImageManager;->g:Ljava/util/Map;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method static bridge synthetic m(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/gms/common/images/ImageManager;->e:Ljava/util/Map;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method static bridge synthetic n(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/Map;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/gms/common/images/ImageManager;->f:Ljava/util/Map;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p0
.end method

.method static bridge synthetic o(Lcom/google/android/gms/common/images/ImageManager;)Ljava/util/concurrent/ExecutorService;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/gms/common/images/ImageManager;->c:Ljava/util/concurrent/ExecutorService;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method


# virtual methods
.method public b(Landroid/widget/ImageView;I)V
    .locals 3
    .param p1    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/gms/common/images/f;

    const/4 v2, 0x6

    invoke-direct {v0, p1, p2}, Lcom/google/android/gms/common/images/f;-><init>(Landroid/widget/ImageView;I)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/images/ImageManager;->p(Lcom/google/android/gms/common/images/h;)V

    const/4 v2, 0x2

    return-void
.end method

.method public c(Landroid/widget/ImageView;Landroid/net/Uri;)V
    .locals 3
    .param p1    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x7

    new-instance v0, Lcom/google/android/gms/common/images/f;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0, p1, p2}, Lcom/google/android/gms/common/images/f;-><init>(Landroid/widget/ImageView;Landroid/net/Uri;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/images/ImageManager;->p(Lcom/google/android/gms/common/images/h;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public d(Landroid/widget/ImageView;Landroid/net/Uri;I)V
    .locals 3
    .param p1    # Landroid/widget/ImageView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/gms/common/images/f;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0, p1, p2}, Lcom/google/android/gms/common/images/f;-><init>(Landroid/widget/ImageView;Landroid/net/Uri;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    iput p3, v0, Lcom/google/android/gms/common/images/h;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/images/ImageManager;->p(Lcom/google/android/gms/common/images/h;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public e(Lcom/google/android/gms/common/images/ImageManager$a;Landroid/net/Uri;)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/images/ImageManager$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x6

    new-instance v0, Lcom/google/android/gms/common/images/g;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {v0, p1, p2}, Lcom/google/android/gms/common/images/g;-><init>(Lcom/google/android/gms/common/images/ImageManager$a;Landroid/net/Uri;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/images/ImageManager;->p(Lcom/google/android/gms/common/images/h;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public f(Lcom/google/android/gms/common/images/ImageManager$a;Landroid/net/Uri;I)V
    .locals 3
    .param p1    # Lcom/google/android/gms/common/images/ImageManager$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/gms/common/images/g;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {v0, p1, p2}, Lcom/google/android/gms/common/images/g;-><init>(Lcom/google/android/gms/common/images/ImageManager$a;Landroid/net/Uri;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    iput p3, v0, Lcom/google/android/gms/common/images/h;->b:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/images/ImageManager;->p(Lcom/google/android/gms/common/images/h;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public final p(Lcom/google/android/gms/common/images/h;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string v0, "ed mae.igh e)anetltouasm iedsag  ahan(m rec nrgladlembMImI"

    const-string v0, "ahsad(elgng esdm eaaeiIohmn gtm.ell aM tir au nembrIt)cade"

    const/4 v2, 0x2

    const-string/jumbo v0, "gtldogsemhtmaa Me  hermlem iadbIcauIoaal int.ee(r)a aegn n"

    const-string v0, "ImageManager.loadImage() must be called in the main thread"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/gms/common/internal/d;->a(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/images/c;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/images/c;-><init>(Lcom/google/android/gms/common/images/ImageManager;Lcom/google/android/gms/common/images/h;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method
