.class final Lcom/google/android/gms/common/images/b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final a:Landroid/net/Uri;

.field private final b:Landroid/os/ParcelFileDescriptor;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field final synthetic c:Lcom/google/android/gms/common/images/ImageManager;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/images/ImageManager;Landroid/net/Uri;Landroid/os/ParcelFileDescriptor;)V
    .locals 2
    .param p2    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/images/b;->c:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/gms/common/images/b;->a:Landroid/net/Uri;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/google/android/gms/common/images/b;->b:Landroid/os/ParcelFileDescriptor;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 14

    const-string v13, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v12, "~vs~~ ~f  ~t@s@@@u~. d~o~ 1 ~~~  o~@-cb@@M~y@@ifK@@@ ~o o@ol ~ t@/4@ b~~@o~n~lm~ ~ b@i@i  /@aSr@"

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v13, 0x0

    const-string v0, " ism emRdFnaxeL ebldencamatbtatrenrt nDnpuui hsme d/aktaiBo/oce "

    const-string/jumbo v0, "nissaetdBdtnLe /   mtbebtF uem ui/eaelRhdoo kteDmcxraranciapiann"

    const/4 v13, 0x7

    const-string/jumbo v0, "sRmuoD Fera ceat tn Bodemedn/p ekuetdtxianLharhlcobiia/btima n e"

    const-string v0, "LoadBitmapFromDiskRunnable can\'t be executed in the main thread"

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/d;->b(Ljava/lang/String;)V

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/images/b;->b:Landroid/os/ParcelFileDescriptor;

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x5

    const/4 v1, 0x1

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x0

    const/4 v2, 0x0

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v3, 0x0

    shr-int/2addr v13, v3

    const/4 v12, 0x5

    move v13, v12

    const-string/jumbo v4, "gMeenbmrmaIg"

    const-string v4, "eMmmengaraIg"

    const/4 v13, 0x1

    const-string/jumbo v4, "mageMnugIera"

    const-string v4, "ImageManager"

    const/4 v13, 0x6

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x1

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object v0

    const/4 v13, 0x2

    const/4 v12, 0x2

    invoke-static {v0}, Landroid/graphics/BitmapFactory;->decodeFileDescriptor(Ljava/io/FileDescriptor;)Landroid/graphics/Bitmap;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x0

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x3

    iget-object v2, p0, Lcom/google/android/gms/common/images/b;->a:Landroid/net/Uri;

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x2

    const-string v5, "epr  map oiiMntObou : whlgfiod lOi"

    const-string v5, "ei:looo Or  iuprbi aMOnmhfwti dl g"

    const/4 v13, 0x5

    const-string v5, "OOM while loading bitmap for uri: "

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-virtual {v5, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x5

    const/4 v12, 0x0

    invoke-static {v4, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x7

    move v2, v1

    move v2, v1

    const/4 v13, 0x3

    move v2, v1

    move v2, v1

    :goto_0
    :try_start_1
    const/4 v13, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/images/b;->b:Landroid/os/ParcelFileDescriptor;

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x1

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x1

    goto :goto_1

    :catch_1
    move-exception v0

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x3

    const-string/jumbo v5, "ilcsbeelqadfd"

    const-string/jumbo v5, "oadfcbeidlsel"

    const/4 v13, 0x1

    const-string/jumbo v5, "lescdeaolsdif"

    const-string v5, "closed failed"

    const/4 v13, 0x4

    invoke-static {v4, v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    :goto_1
    const/4 v13, 0x6

    move v10, v2

    move v10, v2

    const/4 v13, 0x1

    move v10, v2

    move v10, v2

    move-object v9, v3

    move-object v9, v3

    const/4 v13, 0x7

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v12, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x4

    iget-object v7, p0, Lcom/google/android/gms/common/images/b;->c:Lcom/google/android/gms/common/images/ImageManager;

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x2

    iget-object v8, p0, Lcom/google/android/gms/common/images/b;->a:Landroid/net/Uri;

    const/4 v13, 0x7

    invoke-static {v7}, Lcom/google/android/gms/common/images/ImageManager;->h(Lcom/google/android/gms/common/images/ImageManager;)Landroid/os/Handler;

    move-result-object v1

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x6

    new-instance v2, Lcom/google/android/gms/common/images/d;

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v11, v0

    move-object v11, v0

    move-object v11, v0

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x5

    invoke-direct/range {v6 .. v11}, Lcom/google/android/gms/common/images/d;-><init>(Lcom/google/android/gms/common/images/ImageManager;Landroid/net/Uri;Landroid/graphics/Bitmap;ZLjava/util/concurrent/CountDownLatch;)V

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :try_start_2
    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->await()V
    :try_end_2
    .catch Ljava/lang/InterruptedException; {:try_start_2 .. :try_end_2} :catch_2

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x2

    return-void

    :catch_2
    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/images/b;->a:Landroid/net/Uri;

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x0

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x3

    const-string/jumbo v1, "rL mnu weeeipts hldi ttrthnucapg"

    const-string/jumbo v1, "ptLgh uc ihn se nrrudielatetwpot"

    const/4 v13, 0x4

    const-string/jumbo v1, "oci oenuhitpeeLri trtwasngl dht "

    const-string v1, "Latch interrupted while posting "

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x1

    invoke-static {v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v13, 0x4

    const/4 v12, 0x4

    return-void
.end method
