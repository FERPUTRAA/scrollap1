.class final Lcom/google/android/gms/common/b0;
.super Ljava/lang/Object;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Lcom/google/android/gms/internal/common/zzag;

.field private final c:Lcom/google/android/gms/internal/common/zzag;


# direct methods
.method synthetic constructor <init>(Ljava/lang/String;JLcom/google/android/gms/internal/common/zzag;Lcom/google/android/gms/internal/common/zzag;Lcom/google/android/gms/common/a0;)V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/b0;->a:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p4, p0, Lcom/google/android/gms/common/b0;->b:Lcom/google/android/gms/internal/common/zzag;

    iput-object p5, p0, Lcom/google/android/gms/common/b0;->c:Lcom/google/android/gms/internal/common/zzag;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method
