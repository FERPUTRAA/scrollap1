.class public Lcom/google/android/gms/common/b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# annotations
.annotation build Lf4/a;
.end annotation


# instance fields
.field a:Z

.field private final b:Ljava/util/concurrent/BlockingQueue;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/google/android/gms/common/b;->a:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/b;->b:Ljava/util/concurrent/BlockingQueue;

    const/4 v2, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a()Landroid/os/IBinder;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InterruptedException;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string v0, " nsrman( Bdceetti)vkdSrlgogoseCr cl nvceoenciniaiSaecitnohee"

    const-string/jumbo v0, "rvsnliee ioSB ilirddghoatntenoiconc)taeaekcSvcnng(le c rmeeC"

    const/4 v3, 0x5

    const-string/jumbo v0, "nneme ldSvci(it) oogaeke.ie nlCacmaec oShginBnoldvtrriccrnet"

    const-string v0, "BlockingServiceConnection.getService() called on main thread"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->q(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-boolean v0, p0, Lcom/google/android/gms/common/b;->a:Z

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/google/android/gms/common/b;->a:Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/gms/common/b;->b:Ljava/util/concurrent/BlockingQueue;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/BlockingQueue;->take()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast v0, Landroid/os/IBinder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v1, "lr oohgec mn n eoatnolCthnicnot neocctaaietmnn s "

    const-string v1, "a rmelonninothgl tmcteC  oonncocitcnaheet a osn n"

    const/4 v3, 0x4

    const-string v1, "e ec botnsatro cinm hnloloncet  gtnahoC onicnaen "

    const-string v1, "Cannot call get on this connection more than once"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    throw v0
.end method

.method public b(JLjava/util/concurrent/TimeUnit;)Landroid/os/IBinder;
    .locals 3
    .param p3    # Ljava/util/concurrent/TimeUnit;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InterruptedException;,
            Ljava/util/concurrent/TimeoutException;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string/jumbo v0, "iclvtiuuStkieeahSBmc Wrienit .c (eegoveotohllanomie)d TeeCcoinrndtcrang"

    const-string v0, "BlockingServiceConnection.getServiceWithTimeout() called on main thread"

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->q(Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/gms/common/b;->a:Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-boolean v0, p0, Lcom/google/android/gms/common/b;->a:Z

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/b;->b:Ljava/util/concurrent/BlockingQueue;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0, p1, p2, p3}, Ljava/util/concurrent/BlockingQueue;->poll(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    check-cast p1, Landroid/os/IBinder;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x3

    new-instance p1, Ljava/util/concurrent/TimeoutException;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string p2, "ctodiuhpnosiotfaeeciwc e migvtnTto n ei o er"

    const-string p2, "dfoeotoeuc iht  ti conceigewi m esnnvaTrtion"

    const/4 v2, 0x4

    const-string p2, "e id eniqiwTur fehitoontreco tcivmn ecaosntg"

    const-string p2, "Timed out waiting for the service connection"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p1, p2}, Ljava/util/concurrent/TimeoutException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    throw p1

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string/jumbo p2, "r senncnagClnoltna c es cthatnhiooontemt  o  eonc"

    const-string/jumbo p2, "to o b ccC amt cta oherchenniota sloetnn nlnneong"

    const/4 v2, 0x7

    const-string/jumbo p2, "oonmlecog nc a   nrcnenaot cmtCae tlhs ihntnoeion"

    const-string p2, "Cannot call get on this connection more than once"

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    throw p1
.end method

.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 2
    .param p1    # Landroid/content/ComponentName;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/google/android/gms/common/b;->b:Ljava/util/concurrent/BlockingQueue;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-interface {p1, p2}, Ljava/util/concurrent/BlockingQueue;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 2
    .param p1    # Landroid/content/ComponentName;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method
