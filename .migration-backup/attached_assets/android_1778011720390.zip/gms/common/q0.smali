.class final Lcom/google/android/gms/common/q0;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/k1;
.end annotation


# static fields
.field static final a:[Lcom/google/android/gms/common/n0;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v0, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x3

    new-array v0, v0, [Lcom/google/android/gms/common/n0;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v2, Lcom/google/android/gms/common/r0;->c:Lcom/google/android/gms/common/p0;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    aput-object v2, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v2, Lcom/google/android/gms/common/r0;->d:Lcom/google/android/gms/common/p0;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    aput-object v2, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    sput-object v0, Lcom/google/android/gms/common/q0;->a:[Lcom/google/android/gms/common/n0;

    const/4 v4, 0x3

    const/4 v3, 0x7

    return-void
.end method
