.class public Lcom/google/android/gms/common/l;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation runtime Lcom/google/errorprone/annotations/RestrictedInheritance;
    allowedOnPath = ".*java.*/com/google/android/gms/common/testing/.*"
    explanation = "Sub classing of GMS Core\'s APIs are restricted to testing fakes."
    link = "go/gmscore-restrictedinheritance"
.end annotation

.annotation build Lf4/a;
.end annotation

.annotation runtime Ly4/b;
.end annotation


# static fields
.field private static c:Lcom/google/android/gms/common/l;
    .annotation runtime Lv7/h;
    .end annotation
.end field

.field private static volatile d:Ljava/util/Set;
    .annotation runtime Lv7/h;
    .end annotation
.end field


# instance fields
.field private final a:Landroid/content/Context;

.field private volatile b:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/gms/common/l;->a:Landroid/content/Context;

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/google/android/gms/common/l;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x2

    const-class v0, Lcom/google/android/gms/common/l;

    const-class v0, Lcom/google/android/gms/common/l;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v1, Lcom/google/android/gms/common/l;->c:Lcom/google/android/gms/common/l;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/google/android/gms/common/r0;->e(Landroid/content/Context;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v1, Lcom/google/android/gms/common/l;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/google/android/gms/common/l;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    sput-object v1, Lcom/google/android/gms/common/l;->c:Lcom/google/android/gms/common/l;

    :cond_0
    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object p0, Lcom/google/android/gms/common/l;->c:Lcom/google/android/gms/common/l;

    const/4 v3, 0x4

    const/4 v2, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    throw p0
.end method

.method static final varargs e(Landroid/content/pm/PackageInfo;[Lcom/google/android/gms/common/n0;)Lcom/google/android/gms/common/n0;
    .locals 5
    .annotation runtime Lv7/h;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    array-length v0, v0

    const/4 v4, 0x3

    const/4 v2, 0x5

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eq v0, v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string p0, "VesgSrgtarGifsoeoiunerl"

    const-string p0, "ersriGeeVnroSogafuielgt"

    const-string p0, "eonmilutfGVieraeeoigrgS"

    const-string p0, "GoogleSignatureVerifier"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string p1, " camoo etsenh.ae aat kuhrnmr Poaesgi"

    const-string p1, "ckemse omonghh ePnaei aas uttra.gar "

    const/4 v4, 0x0

    const-string/jumbo p1, "oaansb .e erthki  aourhnentaPmsge cg"

    const-string p1, "Package has more than one signature."

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object v1

    :cond_1
    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v0, Lcom/google/android/gms/common/o0;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    aget-object p0, p0, v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v0, p0}, Lcom/google/android/gms/common/o0;-><init>([B)V

    :goto_0
    const/4 v4, 0x7

    array-length p0, p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-ge v2, p0, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    aget-object p0, p1, v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/n0;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz p0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    aget-object p0, p1, v2

    const/4 v4, 0x6

    return-object p0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object v1
.end method

.method public static final f(Landroid/content/pm/PackageInfo;Z)Z
    .locals 6
    .param p0    # Landroid/content/pm/PackageInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x0

    move v4, v0

    move v4, v0

    const/4 v5, 0x6

    const/4 v1, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x3

    if-eqz p1, :cond_4

    const/4 v5, 0x5

    if-eqz p0, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v2, "doeagiun.mdiocvordn"

    const-string/jumbo v2, "odvnodir.edamng.oic"

    const/4 v5, 0x5

    const-string/jumbo v2, "i.e.ndipdngaorovdnm"

    const-string v2, "com.android.vending"

    const/4 v5, 0x0

    const/4 v4, 0x6

    iget-object v3, p0, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-nez v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v2, p0, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    const/4 v4, 0x2

    move v5, v4

    const-string/jumbo v3, "i.olgaseqmoodobg.cmd.g"

    const-string/jumbo v3, "migo.bemr.asooocgl.ddg"

    const/4 v5, 0x4

    const-string/jumbo v3, "ogsrgieo.smgl.coda.dom"

    const-string v3, "com.google.android.gms"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v2, :cond_4

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object p1, p0, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-nez p1, :cond_2

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    move p1, v1

    move p1, v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget p1, p1, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    and-int/lit16 p1, p1, 0x81

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz p1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    move p1, v0

    move p1, v0

    const/4 v5, 0x7

    move p1, v0

    move p1, v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_1

    :cond_4
    :goto_0
    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz p0, :cond_6

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object p0, v2, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz p0, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz p1, :cond_5

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    sget-object p0, Lcom/google/android/gms/common/q0;->a:[Lcom/google/android/gms/common/n0;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v2, p0}, Lcom/google/android/gms/common/l;->e(Landroid/content/pm/PackageInfo;[Lcom/google/android/gms/common/n0;)Lcom/google/android/gms/common/n0;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_2

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-array p0, v0, [Lcom/google/android/gms/common/n0;

    const/4 v5, 0x3

    const/4 v4, 0x7

    sget-object p1, Lcom/google/android/gms/common/q0;->a:[Lcom/google/android/gms/common/n0;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    aget-object p1, p1, v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    aput-object p1, p0, v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v2, p0}, Lcom/google/android/gms/common/l;->e(Landroid/content/pm/PackageInfo;[Lcom/google/android/gms/common/n0;)Lcom/google/android/gms/common/n0;

    move-result-object p0

    :goto_2
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz p0, :cond_6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    return v0

    :cond_6
    const/4 v4, 0x6

    const/4 v5, 0x6

    return v1
.end method

.method private final g(Ljava/lang/String;ZZ)Lcom/google/android/gms/common/y0;
    .locals 7
    .param p1    # Ljava/lang/String;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "PackageManagerGetSignatures"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string/jumbo p2, "n umlgkl"

    const-string/jumbo p2, "null pkg"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-nez p1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p2}, Lcom/google/android/gms/common/y0;->c(Ljava/lang/String;)Lcom/google/android/gms/common/y0;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-object p1

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object p3, p0, Lcom/google/android/gms/common/l;->b:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez p3, :cond_7

    const/4 v6, 0x5

    invoke-static {}, Lcom/google/android/gms/common/r0;->g()Z

    move-result p3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v0, 0x0

    move v6, v0

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz p3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object p2, p0, Lcom/google/android/gms/common/l;->a:Landroid/content/Context;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {p2}, Lcom/google/android/gms/common/k;->k(Landroid/content/Context;)Z

    move-result p2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p1, p2, v0, v0}, Lcom/google/android/gms/common/r0;->b(Ljava/lang/String;ZZZ)Lcom/google/android/gms/common/y0;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto/16 :goto_1

    :cond_1
    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object p3, p0, Lcom/google/android/gms/common/l;->a:Landroid/content/Context;

    const/4 v5, 0x4

    or-int/2addr v6, v5

    invoke-virtual {p3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p3

    const/4 v6, 0x1

    const/16 v1, 0x40

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p3, p1, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p3
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/l;->a:Landroid/content/Context;

    const/4 v6, 0x4

    invoke-static {v1}, Lcom/google/android/gms/common/k;->k(Landroid/content/Context;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    if-nez p3, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {p2}, Lcom/google/android/gms/common/y0;->c(Ljava/lang/String;)Lcom/google/android/gms/common/y0;

    move-result-object p2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto/16 :goto_1

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object p2, p3, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz p2, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    array-length p2, p2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v2, 0x1

    move v6, v2

    const/4 v5, 0x6

    move v6, v5

    if-eq p2, v2, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_0

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    new-instance p2, Lcom/google/android/gms/common/o0;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v3, p3, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v6, 0x2

    aget-object v3, v3, v0

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    invoke-virtual {v3}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {p2, v3}, Lcom/google/android/gms/common/o0;-><init>([B)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v3, p3, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v3, p2, v1, v0}, Lcom/google/android/gms/common/r0;->a(Ljava/lang/String;Lcom/google/android/gms/common/n0;ZZ)Lcom/google/android/gms/common/y0;

    move-result-object v1

    const/4 v6, 0x5

    iget-boolean v4, v1, Lcom/google/android/gms/common/y0;->a:Z

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v4, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object p3, p3, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz p3, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget p3, p3, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    and-int/lit8 p3, p3, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x7

    if-eqz p3, :cond_4

    const/4 v5, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v3, p2, v0, v2}, Lcom/google/android/gms/common/r0;->a(Ljava/lang/String;Lcom/google/android/gms/common/n0;ZZ)Lcom/google/android/gms/common/y0;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-boolean p2, p2, Lcom/google/android/gms/common/y0;->a:Z

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz p2, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string p2, "beecod ga trlejaeglaepbep r eescderu"

    const-string/jumbo p2, "geleebur paaepgecleej sra dtcerdb et"

    const/4 v6, 0x6

    const-string p2, "bg dabsebdtere upergpaeeeecjealt l c"

    const-string p2, "debuggable release cert app rejected"

    const/4 v5, 0x2

    move v6, v5

    invoke-static {p2}, Lcom/google/android/gms/common/y0;->c(Ljava/lang/String;)Lcom/google/android/gms/common/y0;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    goto :goto_1

    :cond_4
    move-object p2, v1

    move-object p2, v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto :goto_1

    :cond_5
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string/jumbo p2, "rteeeiue ludrricq ns"

    const-string/jumbo p2, "single cert required"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {p2}, Lcom/google/android/gms/common/y0;->c(Ljava/lang/String;)Lcom/google/android/gms/common/y0;

    move-result-object p2

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-boolean p3, p2, Lcom/google/android/gms/common/y0;->a:Z

    const/4 v5, 0x1

    xor-int/2addr v6, v5

    if-eqz p3, :cond_6

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/l;->b:Ljava/lang/String;

    :cond_6
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-object p2

    :catch_0
    move-exception p2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo p3, "pnpg kp"

    const-string/jumbo p3, "pngk po"

    const/4 v6, 0x2

    const-string p3, " qknpog"

    const-string/jumbo p3, "no pkg "

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p3, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p1, p2}, Lcom/google/android/gms/common/y0;->d(Ljava/lang/String;Ljava/lang/Throwable;)Lcom/google/android/gms/common/y0;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-object p1

    :cond_7
    const/4 v6, 0x2

    invoke-static {}, Lcom/google/android/gms/common/y0;->b()Lcom/google/android/gms/common/y0;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-object p1
.end method


# virtual methods
.method public b(Landroid/content/pm/PackageInfo;)Z
    .locals 5
    .param p1    # Landroid/content/pm/PackageInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez p1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    return v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lcom/google/android/gms/common/l;->f(Landroid/content/pm/PackageInfo;Z)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    return v2

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-static {p1, v2}, Lcom/google/android/gms/common/l;->f(Landroid/content/pm/PackageInfo;Z)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz p1, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/gms/common/l;->a:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/k;->k(Landroid/content/Context;)Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    return v2

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo p1, "rueiGSeiqalrrtiogfnogeV"

    const-string/jumbo p1, "olsiiVrnaigreGfeugrtSeo"

    const-string p1, "GoogleSignatureVerifier"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string v1, "a/omr.ii st btde utpTcy/se-seendeklac  ht"

    const-string/jumbo v1, "htsees .ptncdri/eeilay bsto/T d tn-c aeku"

    const/4 v4, 0x3

    const-string v1, " ttao  eeocysT  hbekl-sstn/enadr/tcudpi.e"

    const-string v1, "Test-keys aren\'t accepted on this build."

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p1, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v0
.end method

.method public c(Ljava/lang/String;)Z
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0, p1, v0, v0}, Lcom/google/android/gms/common/l;->g(Ljava/lang/String;ZZ)Lcom/google/android/gms/common/y0;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/android/gms/common/y0;->e()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-boolean p1, p1, Lcom/google/android/gms/common/y0;->a:Z

    const/4 v2, 0x4

    return p1
.end method

.method public d(I)Z
    .locals 7
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/gms/common/l;->a:Landroid/content/Context;

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Landroid/content/pm/PackageManager;->getPackagesForUid(I)[Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz p1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    array-length v0, p1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto :goto_1

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    move v3, v1

    move v3, v1

    const/4 v6, 0x3

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    if-ge v3, v0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    aget-object v2, p1, v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-direct {p0, v2, v1, v1}, Lcom/google/android/gms/common/l;->g(Ljava/lang/String;ZZ)Lcom/google/android/gms/common/y0;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-boolean v4, v2, Lcom/google/android/gms/common/y0;->a:Z

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v4, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_2

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_0

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v6, 0x2

    const-string/jumbo p1, "snom bp"

    const-string/jumbo p1, "pksmno "

    const/4 v6, 0x1

    const-string/jumbo p1, "gsknopu"

    const-string/jumbo p1, "no pkgs"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/y0;->c(Ljava/lang/String;)Lcom/google/android/gms/common/y0;

    move-result-object v2

    :goto_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/google/android/gms/common/y0;->e()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-boolean p1, v2, Lcom/google/android/gms/common/y0;->a:Z

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    return p1
.end method
