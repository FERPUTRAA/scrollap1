.class final Lcom/google/android/gms/common/o0;
.super Lcom/google/android/gms/common/n0;


# instance fields
.field private final b:[B


# direct methods
.method constructor <init>([B)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 v1, 0x19

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1, v0, v1}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/gms/common/n0;-><init>([B)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/google/android/gms/common/o0;->b:[B

    const/4 v3, 0x4

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method final c()[B
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "oSsl@@f~o ~~u@o~o  @b~~~@4@~yc@~s @Ktb @  ~ @~dtv  l-@~~f/.~~~oM o@~  n@@~r m~~@@/i ~ ib@~@@a1@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/gms/common/o0;->b:[B

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method
