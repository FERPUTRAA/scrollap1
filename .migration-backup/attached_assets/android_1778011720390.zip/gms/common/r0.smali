.class final Lcom/google/android/gms/common/r0;
.super Ljava/lang/Object;


# annotations
.annotation runtime Ly4/b;
.end annotation


# static fields
.field static final a:Lcom/google/android/gms/common/p0;

.field static final b:Lcom/google/android/gms/common/p0;

.field static final c:Lcom/google/android/gms/common/p0;

.field static final d:Lcom/google/android/gms/common/p0;

.field private static volatile e:Lcom/google/android/gms/common/internal/m1;

.field private static final f:Ljava/lang/Object;

.field private static g:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/common/j0;

    const/4 v2, 0x4

    move v3, v2

    const-string/jumbo v1, "u0s/8/000u00u00u01/uu/38/00u0001uu050ef9000/0u/u/00002uu08/u00u0028a00//00/2/0/s43c00u/088e000/0Q2/0b0000u0/a/02/e1su00u"

    const-string v1, "0us380000/uu8000e0///2/u0u00/0c/u2u00u1000012u08u0e//0uu/0/0000005f30/90/004/1280ue008u/000/s08u00/0uaQ0/00auubu02d0/0/0"

    const-string v1, "00um/00030800u0u/00u8000/00/0000u8/4002/220s//0008//0d//000Q0110u0euc/0828/0e0uf0500u30ua/0uu1a/u0u90b//0u00/000/u2ueuu0"

    const-string v1, "0\u0082\u0005\u00c80\u0082\u0003\u00b0\u00a0\u0003\u0002\u0001\u0002\u0002\u0014\u0010\u008ae\u0008s\u00f9/\u008eQ\u00ed"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v1}, Lcom/google/android/gms/common/n0;->b(Ljava/lang/String;)[B

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/j0;-><init>([B)V

    const/4 v3, 0x4

    sput-object v0, Lcom/google/android/gms/common/r0;->a:Lcom/google/android/gms/common/p0;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/gms/common/k0;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v1, "10u0oau8/cm0//000//00/u/3/30c000000/0u/260u000u010uu000e00u/u02r002uuu7u0e0000000020u4u000uu2e0d0//0//0kaau/0bu840020/00c/u3a/130/"

    const-string v1, "04um8aaau2/0000ucu000300uua0kuu012u0/0u000u00/00e1302300/u0c0/0e/u0u/c00160u0/030bu00r0/ue8/00///00/000/0u///u2u0/00/007u0400/d220"

    const/4 v3, 0x2

    const-string v1, "/1u/ab00uu0u03//u/0ub/7/00d00000020/u0e0/e/000u/u20302/03rk/6002uu8uu3c21a00c0e000/0000u00400ua/000/80u/00u000410u0u/0/000a/c0udu2"

    const-string v1, "0\u0082\u0006\u00040\u0082\u0003\u00ec\u00a0\u0003\u0002\u0001\u0002\u0002\u0014\u0003\u00a3\u00b2\u00ad\u00d7\u00e1r\u00cak\u00ec"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v1}, Lcom/google/android/gms/common/n0;->b(Ljava/lang/String;)[B

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/k0;-><init>([B)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    sput-object v0, Lcom/google/android/gms/common/r0;->b:Lcom/google/android/gms/common/p0;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/common/l0;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v1, "2J0t00uu0ud800/u00uu0/0300201/002/00c8ou0000/00e80u/00udu/0ua00/0043/+uF700u2/0820C000u000/0//20uu//0"

    const-string v1, "0/00o0u308cu2e00+0duut/80uau001uu002/008/u///00F/0d4/0/80J0u00023000000u70/u00/0/uu000200/0u20002/00C"

    const/4 v3, 0x4

    const-string v1, "020uu/0p3820u32000C10/u200/00/F00u8a0+000/ud000u20000u/e/u0Ju02u/0//0uu040/00t/0//0000u00/7dcu0800/00"

    const-string v1, "0\u0082\u0004C0\u0082\u0003+\u00a0\u0003\u0002\u0001\u0002\u0002\t\u0000\u00c2\u00e0\u0087FdJ0\u008d0"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/google/android/gms/common/n0;->b(Ljava/lang/String;)[B

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/l0;-><init>([B)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/gms/common/r0;->c:Lcom/google/android/gms/common/p0;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/gms/common/m0;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v1, "u85u0f00q0N08002020t00a0//u/ubu/u0ud0//08u000300ua30/0u00005}0//u000b//080u/0/50/200u430dlu010/20000/800090//2uuuu00"

    const-string v1, "0//00b00u0//0058/l0u0d/00010/0/08ub202/u00005/0/0fdu08u0uu000t03u2//u0Nauu040u32000u52//0000u00030800//}0u8u9000au0/"

    const-string v1, "20s000200/0/bu0080u0lud0/0/u/fu/0030u00000t8//80/390040a0u0}/00u/u080u500/5u0u0N0/0/00u0a2/u000/05u182uu3/0ud0/0/002"

    const-string v1, "0\u0082\u0004\u00a80\u0082\u0003\u0090\u00a0\u0003\u0002\u0001\u0002\u0002\t\u0000\u00d5\u0085\u00b8l}\u00d3N\u00f50"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/n0;->b(Ljava/lang/String;)[B

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/android/gms/common/m0;-><init>([B)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-object v0, Lcom/google/android/gms/common/r0;->d:Lcom/google/android/gms/common/p0;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    sput-object v0, Lcom/google/android/gms/common/r0;->f:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method static a(Ljava/lang/String;Lcom/google/android/gms/common/n0;ZZ)Lcom/google/android/gms/common/y0;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o@ m@@ul@@@ b@@ ~v@ r~~~~/~~yfb~ o~@ o @-~bd~S/~s~~@~@@  @ @t~i.~~c tinlmo@~4Kai~ ~ f  o oM@1 ~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-static {}, Landroid/os/StrictMode;->allowThreadDiskReads()Landroid/os/StrictMode$ThreadPolicy;

    move-result-object v0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-static {p0, p1, p2, p3}, Lcom/google/android/gms/common/r0;->h(Ljava/lang/String;Lcom/google/android/gms/common/n0;ZZ)Lcom/google/android/gms/common/y0;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    throw p0
.end method

.method static b(Ljava/lang/String;ZZZ)Lcom/google/android/gms/common/y0;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/4 p2, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p3, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p0, p1, p2, p2, p3}, Lcom/google/android/gms/common/r0;->i(Ljava/lang/String;ZZZZ)Lcom/google/android/gms/common/y0;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method static c(Ljava/lang/String;ZZZ)Lcom/google/android/gms/common/y0;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p2, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p0, p1, p2, p2, p2}, Lcom/google/android/gms/common/r0;->i(Ljava/lang/String;ZZZZ)Lcom/google/android/gms/common/y0;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic d(ZLjava/lang/String;Lcom/google/android/gms/common/n0;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez p0, :cond_0

    const/4 v5, 0x0

    invoke-static {p1, p2, v0, v1}, Lcom/google/android/gms/common/r0;->h(Ljava/lang/String;Lcom/google/android/gms/common/n0;ZZ)Lcom/google/android/gms/common/y0;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-boolean v2, v2, Lcom/google/android/gms/common/y0;->a:Z

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    move v2, v0

    move v2, v0

    const/4 v5, 0x6

    move v2, v0

    move v2, v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    move v2, v1

    move v2, v1

    const/4 v5, 0x4

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eq v0, v2, :cond_1

    const/4 v4, 0x1

    move v5, v4

    const-string v2, " lwoodenloa"

    const-string v2, " elodounlaw"

    const/4 v5, 0x0

    const-string/jumbo v2, "wal lboeotn"

    const-string/jumbo v2, "not allowed"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v2, "bpudgeudjr eeette r"

    const-string v2, "cegteebprter djd ue"

    const/4 v5, 0x5

    const-string v2, "edred bpeeccruett g"

    const-string v2, "debug cert rejected"

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v3, 0x5

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    aput-object v2, v3, v1

    const/4 v4, 0x3

    move v5, v4

    aput-object p1, v3, v0

    const/4 v4, 0x4

    or-int/2addr v5, v4

    const-string p1, "2qS-H6A"

    const-string p1, "Aq-HS62"

    const/4 v5, 0x5

    const-string p1, "26sA-SH"

    const-string p1, "SHA-256"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/util/a;->b(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {p2}, Lcom/google/android/gms/common/n0;->c()[B

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1, p2}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/google/android/gms/common/util/n;->a([B)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 p2, 0x4

    const/4 p2, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    aput-object p1, v3, p2

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    const/4 p1, 0x3

    and-int/2addr v5, p1

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    aput-object p0, v3, p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 p0, 0x4

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string p1, ".0smef0l01s154"

    const-string p1, ".fs5la01e14s00"

    const/4 v5, 0x3

    const-string p1, "4l01o5afs012.0"

    const-string p1, "12451000.false"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    aput-object p1, v3, p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string p0, "a%v,sb,tk%k=% gse:% =,2=6 sshpss %a=r"

    const-string p0, "%s: pkg=%s, sha256=%s, atk=%s, ver=%s"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p0, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    return-object p0
.end method

.method static declared-synchronized e(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-class v0, Lcom/google/android/gms/common/r0;

    const-class v0, Lcom/google/android/gms/common/r0;

    const/4 v3, 0x6

    const-class v0, Lcom/google/android/gms/common/r0;

    const-class v0, Lcom/google/android/gms/common/r0;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    sget-object v1, Lcom/google/android/gms/common/r0;->g:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x5

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    sput-object p0, Lcom/google/android/gms/common/r0;->g:Landroid/content/Context;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :cond_1
    :try_start_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo p0, "ieclgeumtoarieCfso"

    const-string/jumbo p0, "gtcmseterieoiCaofl"

    const/4 v3, 0x3

    const-string/jumbo p0, "etioaGCpceotgfelis"

    const-string p0, "GoogleCertificates"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v1, "sioie neqsediyidoilechegf ateeaCoaaa tzitnlrG r"

    const-string/jumbo v1, "sdoaoitG e rtei s lacelzaaiyladrehfoineigieCent"

    const/4 v3, 0x5

    const-string/jumbo v1, "lCs r aosdgenifGiaenseyrt eteiaitaebacllihdei o"

    const-string v1, "GoogleCertificates has been initialized already"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v2, 0x2

    const/4 v2, 0x2

    throw p0
.end method

.method static f()Z
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {}, Landroid/os/StrictMode;->allowThreadDiskReads()Landroid/os/StrictMode$ThreadPolicy;

    move-result-object v0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {}, Lcom/google/android/gms/common/r0;->j()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget-object v1, Lcom/google/android/gms/common/r0;->e:Lcom/google/android/gms/common/internal/m1;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {v1}, Lcom/google/android/gms/common/internal/m1;->zzg()Z

    move-result v1
    :try_end_0
    .catch Lcom/google/android/gms/dynamite/DynamiteModule$a; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    goto :goto_1

    :catchall_0
    move-exception v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_2

    :catch_0
    move-exception v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :catch_1
    move-exception v1

    :goto_0
    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v2, "etomfilgoetiGbrsce"

    const-string/jumbo v2, "itesobgCreGectfoli"

    const/4 v5, 0x1

    const-string/jumbo v2, "ietgoCisceGelrfoto"

    const-string v2, "GoogleCertificates"

    const/4 v5, 0x7

    const-string v3, "efmg ouaei drteattoite iclercl gterGo  sooeFf"

    const/4 v5, 0x7

    const-string/jumbo v3, "iFto bftsealtgecti ge ti d raceolroemreoo meG"

    const-string v3, "Failed to get Google certificates from remote"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v1, 0x0

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v1

    :goto_2
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    throw v1
.end method

.method static g()Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {}, Landroid/os/StrictMode;->allowThreadDiskReads()Landroid/os/StrictMode$ThreadPolicy;

    move-result-object v0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {}, Lcom/google/android/gms/common/r0;->j()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v1, Lcom/google/android/gms/common/r0;->e:Lcom/google/android/gms/common/internal/m1;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-interface {v1}, Lcom/google/android/gms/common/internal/m1;->zzi()Z

    move-result v1
    :try_end_0
    .catch Lcom/google/android/gms/dynamite/DynamiteModule$a; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_1

    :catchall_0
    move-exception v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_2

    :catch_0
    move-exception v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_0

    :catch_1
    move-exception v1

    :goto_0
    :try_start_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v2, "trieecuCipaGoeltsf"

    const-string/jumbo v2, "tsCogcepiaGfrilete"

    const/4 v5, 0x6

    const-string/jumbo v2, "reGcislpCfoteatgio"

    const-string v2, "GoogleCertificates"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string v3, "aeet  ooqr ecfFtmqectmas diitloGg ilrere gfot"

    const-string/jumbo v3, "o geect qiamt dorFGe r ltale ctoefsifmorogite"

    const/4 v5, 0x1

    const-string/jumbo v3, "tost tFfaomre gldticresiGeeooemfag c t er eil"

    const-string v3, "Failed to get Google certificates from remote"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v1, 0x0

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    return v1

    :goto_2
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    throw v1
.end method

.method private static h(Ljava/lang/String;Lcom/google/android/gms/common/n0;ZZ)Lcom/google/android/gms/common/y0;
    .locals 6

    const/4 v5, 0x7

    const-string/jumbo v0, "feomaeo iiecsaGFrog d te llc gtrretosfmetome "

    const-string/jumbo v0, "oisfttoegr mmofdorFase aGeg etel rielo tccei "

    const/4 v5, 0x2

    const-string/jumbo v0, "etrooalete todeoGasmicrcei  lf tmio ggtoefe r"

    const-string v0, "Failed to get Google certificates from remote"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v1, "frgmlbGteCicsieeto"

    const-string v1, "aGgmteoiesCrtilcef"

    const-string v1, "GoogleCertificates"

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {}, Lcom/google/android/gms/common/r0;->j()V
    :try_end_0
    .catch Lcom/google/android/gms/dynamite/DynamiteModule$a; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    sget-object v2, Lcom/google/android/gms/common/r0;->g:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v2}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v2, Lcom/google/android/gms/common/zzs;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v2, p0, p1, p2, p3}, Lcom/google/android/gms/common/zzs;-><init>(Ljava/lang/String;Lcom/google/android/gms/common/n0;ZZ)V

    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget-object p3, Lcom/google/android/gms/common/r0;->e:Lcom/google/android/gms/common/internal/m1;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget-object v3, Lcom/google/android/gms/common/r0;->g:Landroid/content/Context;

    const/4 v5, 0x6

    invoke-virtual {v3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v3}, Lcom/google/android/gms/dynamic/f;->c(Ljava/lang/Object;)Lcom/google/android/gms/dynamic/d;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {p3, v2, v3}, Lcom/google/android/gms/common/internal/m1;->H(Lcom/google/android/gms/common/zzs;Lcom/google/android/gms/dynamic/d;)Z

    move-result p3
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz p3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {}, Lcom/google/android/gms/common/y0;->b()Lcom/google/android/gms/common/y0;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-object p0

    :cond_0
    const/4 v4, 0x6

    move v5, v4

    new-instance p3, Lcom/google/android/gms/common/i0;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {p3, p2, p0, p1}, Lcom/google/android/gms/common/i0;-><init>(ZLjava/lang/String;Lcom/google/android/gms/common/n0;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance p0, Lcom/google/android/gms/common/w0;

    const/4 v5, 0x3

    const/4 p1, 0x0

    move v4, p1

    move v4, p1

    const/4 v5, 0x3

    invoke-direct {p0, p3, p1}, Lcom/google/android/gms/common/w0;-><init>(Ljava/util/concurrent/Callable;Lcom/google/android/gms/common/v0;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-object p0

    :catch_0
    move-exception p0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string p1, "e cmluuolla"

    const-string/jumbo p1, "l ulocelaom"

    const/4 v5, 0x6

    const-string p1, "alcmdu pole"

    const-string/jumbo p1, "module call"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p1, p0}, Lcom/google/android/gms/common/y0;->d(Ljava/lang/String;Ljava/lang/Throwable;)Lcom/google/android/gms/common/y0;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x1

    return-object p0

    :catch_1
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string p2, " mebt :nqiluo"

    const-string p2, "e: oubmn tlid"

    const/4 v5, 0x4

    const-string/jumbo p2, "tesimld  inuo"

    const-string/jumbo p2, "module init: "

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p1, p0}, Lcom/google/android/gms/common/y0;->d(Ljava/lang/String;Ljava/lang/Throwable;)Lcom/google/android/gms/common/y0;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object p0
.end method

.method private static i(Ljava/lang/String;ZZZZ)Lcom/google/android/gms/common/y0;
    .locals 10

    const/4 v9, 0x1

    const-string/jumbo p2, "tttmoeFo taeriuc ilmr tdoGago rmesoe l ceeegf"

    const-string/jumbo p2, "mteettulogGciteira ft ooser eoe c loedrmFg fa"

    const-string/jumbo p2, "ido osief lGetregofl rcFotettm i  ateaceormge"

    const-string p2, "Failed to get Google certificates from remote"

    const/4 v9, 0x1

    const-string/jumbo p3, "sitiobGtorgfeclpea"

    const-string/jumbo p3, "fciltGrpaeieosetog"

    const-string/jumbo p3, "iGioeruloteagetcfs"

    const-string p3, "GoogleCertificates"

    const/4 v9, 0x6

    invoke-static {}, Landroid/os/StrictMode;->allowThreadDiskReads()Landroid/os/StrictMode$ThreadPolicy;

    move-result-object v0

    :try_start_0
    const/4 v9, 0x0

    sget-object v1, Lcom/google/android/gms/common/r0;->g:Landroid/content/Context;

    const/4 v9, 0x5

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v9, 0x4

    invoke-static {}, Lcom/google/android/gms/common/r0;->j()V
    :try_end_1
    .catch Lcom/google/android/gms/dynamite/DynamiteModule$a; {:try_start_1 .. :try_end_1} :catch_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v9, 0x2

    new-instance v1, Lcom/google/android/gms/common/zzo;

    const/4 v9, 0x6

    const/4 v5, 0x0

    const/4 v9, 0x7

    sget-object v2, Lcom/google/android/gms/common/r0;->g:Landroid/content/Context;

    const/4 v9, 0x5

    invoke-static {v2}, Lcom/google/android/gms/dynamic/f;->c(Ljava/lang/Object;)Lcom/google/android/gms/dynamic/d;

    move-result-object v6

    const/4 v9, 0x7

    const/4 v7, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    const/4 v9, 0x5

    move v4, p1

    move v4, p1

    const/4 v9, 0x4

    invoke-direct/range {v2 .. v8}, Lcom/google/android/gms/common/zzo;-><init>(Ljava/lang/String;ZZLandroid/os/IBinder;ZZ)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v9, 0x3

    if-eqz p4, :cond_0

    :try_start_3
    const/4 v9, 0x2

    sget-object p0, Lcom/google/android/gms/common/r0;->e:Lcom/google/android/gms/common/internal/m1;

    const/4 v9, 0x0

    invoke-interface {p0, v1}, Lcom/google/android/gms/common/internal/m1;->V(Lcom/google/android/gms/common/zzo;)Lcom/google/android/gms/common/zzq;

    move-result-object p0

    const/4 v9, 0x4

    goto :goto_0

    :cond_0
    const/4 v9, 0x1

    sget-object p0, Lcom/google/android/gms/common/r0;->e:Lcom/google/android/gms/common/internal/m1;

    const/4 v9, 0x1

    invoke-interface {p0, v1}, Lcom/google/android/gms/common/internal/m1;->c0(Lcom/google/android/gms/common/zzo;)Lcom/google/android/gms/common/zzq;

    move-result-object p0
    :try_end_3
    .catch Landroid/os/RemoteException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :goto_0
    :try_start_4
    const/4 v9, 0x1

    invoke-virtual {p0}, Lcom/google/android/gms/common/zzq;->y2()Z

    move-result p1

    const/4 v9, 0x5

    if-eqz p1, :cond_1

    const/4 v9, 0x4

    invoke-virtual {p0}, Lcom/google/android/gms/common/zzq;->z2()I

    move-result p0

    const/4 v9, 0x3

    invoke-static {p0}, Lcom/google/android/gms/common/y0;->f(I)Lcom/google/android/gms/common/y0;

    move-result-object p0

    const/4 v9, 0x3

    goto :goto_2

    :cond_1
    const/4 v9, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/common/zzq;->zza()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/common/zzq;->A2()I

    move-result p2

    const/4 v9, 0x5

    const/4 p3, 0x4

    const/4 v9, 0x4

    if-ne p2, p3, :cond_2

    const/4 v9, 0x0

    new-instance p2, Landroid/content/pm/PackageManager$NameNotFoundException;

    invoke-direct {p2}, Landroid/content/pm/PackageManager$NameNotFoundException;-><init>()V

    goto :goto_1

    :cond_2
    const/4 v9, 0x4

    const/4 p2, 0x0

    :goto_1
    const/4 v9, 0x6

    const-string/jumbo p3, "pgt iieeqhfkei rrkccgoacancetacr e"

    const-string p3, "error checking package certificate"

    const/4 v9, 0x1

    if-nez p1, :cond_3

    move-object p1, p3

    move-object p1, p3

    :cond_3
    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/common/zzq;->z2()I

    move-result p3

    const/4 v9, 0x0

    invoke-virtual {p0}, Lcom/google/android/gms/common/zzq;->A2()I

    move-result p0

    const/4 v9, 0x0

    invoke-static {p3, p0, p1, p2}, Lcom/google/android/gms/common/y0;->g(IILjava/lang/String;Ljava/lang/Throwable;)Lcom/google/android/gms/common/y0;

    move-result-object p0

    const/4 v9, 0x0

    goto :goto_2

    :catch_0
    move-exception p0

    const/4 v9, 0x3

    invoke-static {p3, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v9, 0x7

    const-string/jumbo p1, "odasmcepull"

    const-string/jumbo p1, "ucs lldeoma"

    const-string p1, "acluelmlqd "

    const-string/jumbo p1, "module call"

    const/4 v9, 0x0

    invoke-static {p1, p0}, Lcom/google/android/gms/common/y0;->d(Ljava/lang/String;Ljava/lang/Throwable;)Lcom/google/android/gms/common/y0;

    move-result-object p0

    const/4 v9, 0x2

    goto :goto_2

    :catch_1
    move-exception p0

    const/4 v9, 0x6

    invoke-static {p3, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v9, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const-string p2, "d:sim neltiuo"

    const-string/jumbo p2, "module init: "

    const/4 v9, 0x7

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x5

    invoke-static {p1, p0}, Lcom/google/android/gms/common/y0;->d(Ljava/lang/String;Ljava/lang/Throwable;)Lcom/google/android/gms/common/y0;

    move-result-object p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :goto_2
    const/4 v9, 0x7

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 v9, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v9, 0x2

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 v9, 0x1

    throw p0
.end method

.method private static j()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/android/gms/dynamite/DynamiteModule$a;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v0, Lcom/google/android/gms/common/r0;->e:Lcom/google/android/gms/common/internal/m1;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    return-void

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v0, Lcom/google/android/gms/common/r0;->g:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    sget-object v0, Lcom/google/android/gms/common/r0;->f:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-object v1, Lcom/google/android/gms/common/r0;->e:Lcom/google/android/gms/common/internal/m1;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-nez v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    sget-object v1, Lcom/google/android/gms/common/r0;->g:Landroid/content/Context;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    sget-object v2, Lcom/google/android/gms/dynamite/DynamiteModule;->j:Lcom/google/android/gms/dynamite/DynamiteModule$b;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo v3, "modmt.giieoeegrs.nolo.o.agocfltrgmcidsega"

    const-string v3, "aiema.d.ncotgoliegcsedsceol.rt.mogfogroig"

    const-string/jumbo v3, "oredooeca.ot.sdg.sligrgnii.metmgccagfeolo"

    const-string v3, "com.google.android.gms.googlecertificates"

    const/4 v5, 0x3

    invoke-static {v1, v2, v3}, Lcom/google/android/gms/dynamite/DynamiteModule;->e(Landroid/content/Context;Lcom/google/android/gms/dynamite/DynamiteModule$b;Ljava/lang/String;)Lcom/google/android/gms/dynamite/DynamiteModule;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v2, "m.gnomrlagoIemmsg.e.fdcooiorto.coseGieolcnlaptoCidgm"

    const/4 v5, 0x6

    const-string v2, "ecopsbcgcImeaClofirot.n.o.s.digrlom.tlogGgmoaeieomdm"

    const-string v2, "com.google.android.gms.common.GoogleCertificatesImpl"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Lcom/google/android/gms/dynamite/DynamiteModule;->d(Ljava/lang/String;)Landroid/os/IBinder;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/internal/l1;->a(Landroid/os/IBinder;)Lcom/google/android/gms/common/internal/m1;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    sput-object v1, Lcom/google/android/gms/common/r0;->e:Lcom/google/android/gms/common/internal/m1;

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-void

    :catchall_0
    move-exception v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    throw v1
.end method
