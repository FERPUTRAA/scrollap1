.class public Lcom/google/android/gms/common/o;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation runtime Lcom/google/errorprone/annotations/RestrictedInheritance;
    allowedOnPath = ".*javatests.*/com/google/android/gms/common/.*"
    explanation = "Sub classing of GMS Core\'s APIs are restricted to testing fakes."
    link = "go/gmscore-restrictedinheritance"
.end annotation

.annotation build Lf4/a;
.end annotation

.annotation runtime Ly4/b;
.end annotation


# static fields
.field private static a:Lcom/google/android/gms/common/d0;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field static volatile b:Lcom/google/android/gms/common/c0;
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method private static c(Landroid/content/Context;)Lcom/google/android/gms/common/d0;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    const-class v0, Lcom/google/android/gms/common/o;

    const-class v0, Lcom/google/android/gms/common/o;

    const/4 v3, 0x2

    const-class v0, Lcom/google/android/gms/common/o;

    const-class v0, Lcom/google/android/gms/common/o;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v1, Lcom/google/android/gms/common/o;->a:Lcom/google/android/gms/common/d0;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v1, Lcom/google/android/gms/common/d0;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/google/android/gms/common/d0;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    sput-object v1, Lcom/google/android/gms/common/o;->a:Lcom/google/android/gms/common/d0;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    sget-object p0, Lcom/google/android/gms/common/o;->a:Lcom/google/android/gms/common/d0;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    throw p0
.end method


# virtual methods
.method public a(Landroid/content/Context;Ljava/lang/String;)Lcom/google/android/gms/common/p;
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/k;->k(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/google/android/gms/common/o;->c(Landroid/content/Context;)Lcom/google/android/gms/common/d0;

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-static {}, Lcom/google/android/gms/common/r0;->f()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz v1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eq v1, v0, :cond_0

    const/4 v4, 0x0

    const-string v1, "-0"

    const-string v1, "0-"

    const/4 v4, 0x2

    const-string v1, "-0"

    const-string v1, "-0"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v1, "-1"

    const-string v1, "-1"

    const/4 v4, 0x2

    const-string v1, "1-"

    const-string v1, "-1"

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    sget-object v2, Lcom/google/android/gms/common/o;->b:Lcom/google/android/gms/common/c0;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    sget-object v2, Lcom/google/android/gms/common/o;->b:Lcom/google/android/gms/common/c0;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v2}, Lcom/google/android/gms/common/c0;->b(Lcom/google/android/gms/common/c0;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    sget-object p1, Lcom/google/android/gms/common/o;->b:Lcom/google/android/gms/common/c0;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/c0;->a(Lcom/google/android/gms/common/c0;)Lcom/google/android/gms/common/p;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/o;->c(Landroid/content/Context;)Lcom/google/android/gms/common/d0;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 p1, 0x5

    const/4 p1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {p2, v0, p1, p1}, Lcom/google/android/gms/common/r0;->c(Ljava/lang/String;ZZZ)Lcom/google/android/gms/common/y0;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-boolean v0, p1, Lcom/google/android/gms/common/y0;->a:Z

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget p1, p1, Lcom/google/android/gms/common/y0;->d:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v0, Lcom/google/android/gms/common/c0;

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-static {p2, p1}, Lcom/google/android/gms/common/p;->d(Ljava/lang/String;I)Lcom/google/android/gms/common/p;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, v1, p1}, Lcom/google/android/gms/common/c0;-><init>(Ljava/lang/String;Lcom/google/android/gms/common/p;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    sput-object v0, Lcom/google/android/gms/common/o;->b:Lcom/google/android/gms/common/c0;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    sget-object p1, Lcom/google/android/gms/common/o;->b:Lcom/google/android/gms/common/c0;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/c0;->a(Lcom/google/android/gms/common/c0;)Lcom/google/android/gms/common/p;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_1

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p1, Lcom/google/android/gms/common/y0;->b:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p1, Lcom/google/android/gms/common/y0;->b:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object p1, p1, Lcom/google/android/gms/common/y0;->c:Ljava/lang/Throwable;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {p2, v0, p1}, Lcom/google/android/gms/common/p;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)Lcom/google/android/gms/common/p;

    move-result-object p1

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object p1

    :cond_3
    const/4 v4, 0x1

    new-instance p1, Lcom/google/android/gms/common/e0;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p1}, Lcom/google/android/gms/common/e0;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    throw p1
.end method

.method public b(Landroid/content/Context;Ljava/lang/String;)Lcom/google/android/gms/common/p;
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/common/o;->a(Landroid/content/Context;Ljava/lang/String;)Lcom/google/android/gms/common/p;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/gms/common/p;->b()V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/common/o;->a(Landroid/content/Context;Ljava/lang/String;)Lcom/google/android/gms/common/p;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/p;->c()Z

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo p2, "kaseignfriSugsPiVter"

    const-string/jumbo p2, "utsSVegeiPgnriiefkar"

    const/4 v3, 0x6

    const-string/jumbo p2, "iSemVntriikagugrrfeP"

    const-string p2, "PkgSignatureVerifier"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v1, "iaim  nr apscetcs naiefkoggvu airlleaurefngtdyitGk urt"

    const/4 v3, 0x3

    const-string/jumbo v1, "fturol G ei ptaftirgnvalisnrgaou daystncr euieikkac go"

    const-string v1, "Got flaky result during package signature verification"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p2, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x7

    const/4 v2, 0x3

    return-object p1

    :cond_0
    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0
.end method
