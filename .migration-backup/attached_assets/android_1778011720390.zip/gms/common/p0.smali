.class abstract Lcom/google/android/gms/common/p0;
.super Lcom/google/android/gms/common/n0;


# static fields
.field private static final c:Ljava/lang/ref/WeakReference;


# instance fields
.field private b:Ljava/lang/ref/WeakReference;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v3, 0x1

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/gms/common/p0;->c:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x5

    return-void
.end method

.method constructor <init>([B)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/gms/common/n0;-><init>([B)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    sget-object p1, Lcom/google/android/gms/common/p0;->c:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/gms/common/p0;->b:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method protected abstract X()[B
.end method

.method final c()[B
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~os~~@tfc~t@~ su/o~~ @@v~@lb@ @@/aoiib @M~~~~o  o@@ 1df  o i~- @~4 ~b S@r ~y.~@@~@~~@@~@@mnK   l"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/p0;->b:Ljava/lang/ref/WeakReference;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v0, [B

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/gms/common/p0;->X()[B

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v1, Ljava/lang/ref/WeakReference;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v1, v0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/google/android/gms/common/p0;->b:Ljava/lang/ref/WeakReference;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    throw v0
.end method
