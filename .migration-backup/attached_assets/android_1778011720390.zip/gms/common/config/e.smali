.class final Lcom/google/android/gms/common/config/e;
.super Lcom/google/android/gms/common/config/a;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/Float;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/android/gms/common/config/a;-><init>(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method protected final bridge synthetic k(Ljava/lang/String;)Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, ". s M~o @~@@~/~~~/c@@@n@~b@oo@Kt1u~~ bof@    @t@ ~ @~~b@@  ~i@~i@v@~fdl oyso~ @~  ~rl@i~- S~am4~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/gms/common/config/a;->b:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast v0, Ljava/lang/Float;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    throw p1
.end method
