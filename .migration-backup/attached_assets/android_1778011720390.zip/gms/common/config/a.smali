.class public abstract Lcom/google/android/gms/common/config/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field private static final d:Ljava/lang/Object;


# instance fields
.field protected final a:Ljava/lang/String;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field protected final b:Ljava/lang/Object;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private c:Ljava/lang/Object;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/gms/common/config/a;->d:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method protected constructor <init>(Ljava/lang/String;Ljava/lang/Object;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    iput-object v0, p0, Lcom/google/android/gms/common/config/a;->c:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/gms/common/config/a;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p2, p0, Lcom/google/android/gms/common/config/a;->b:Ljava/lang/Object;

    const/4 v2, 0x3

    return-void
.end method

.method public static c()Z
    .locals 4
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget-object v0, Lcom/google/android/gms/common/config/a;->d:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x7

    move v3, v2

    return v0

    :catchall_0
    move-exception v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    throw v1
.end method

.method public static f(Ljava/lang/String;Ljava/lang/Float;)Lcom/google/android/gms/common/config/a;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Float;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Float;",
            ")",
            "Lcom/google/android/gms/common/config/a<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/config/e;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/config/e;-><init>(Ljava/lang/String;Ljava/lang/Float;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public static g(Ljava/lang/String;Ljava/lang/Integer;)Lcom/google/android/gms/common/config/a;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Integer;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ")",
            "Lcom/google/android/gms/common/config/a<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/gms/common/config/d;

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/config/d;-><init>(Ljava/lang/String;Ljava/lang/Integer;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public static h(Ljava/lang/String;Ljava/lang/Long;)Lcom/google/android/gms/common/config/a;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ")",
            "Lcom/google/android/gms/common/config/a<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Lcom/google/android/gms/common/config/c;

    const/4 v2, 0x1

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/config/c;-><init>(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    return-object v0
.end method

.method public static i(Ljava/lang/String;Ljava/lang/String;)Lcom/google/android/gms/common/config/a;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")",
            "Lcom/google/android/gms/common/config/a<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance v0, Lcom/google/android/gms/common/config/f;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/config/f;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public static j(Ljava/lang/String;Z)Lcom/google/android/gms/common/config/a;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Z)",
            "Lcom/google/android/gms/common/config/a<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/config/b;

    const/4 v2, 0x7

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/config/b;-><init>(Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 6
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/gms/common/config/a;->c:Ljava/lang/Object;

    const/4 v4, 0x6

    move v5, v4

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    return-object v0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {}, Landroid/os/StrictMode;->allowThreadDiskReads()Landroid/os/StrictMode$ThreadPolicy;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v1, Lcom/google/android/gms/common/config/a;->d:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    monitor-enter v1

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    monitor-enter v1

    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/android/gms/common/config/a;->a:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0, v1}, Lcom/google/android/gms/common/config/a;->k(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1
    :try_end_2
    .catch Ljava/lang/SecurityException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    goto :goto_1

    :catch_0
    :try_start_3
    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-static {}, Landroid/os/Binder;->clearCallingIdentity()J

    move-result-wide v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v3, p0, Lcom/google/android/gms/common/config/a;->a:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0, v3}, Lcom/google/android/gms/common/config/a;->k(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :try_start_5
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object v1

    :catchall_1
    move-exception v3

    :try_start_6
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v1, v2}, Landroid/os/Binder;->restoreCallingIdentity(J)V

    const/4 v5, 0x4

    throw v3
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    throw v1

    :catchall_2
    move-exception v0

    :try_start_7
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    monitor-exit v1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    throw v0

    :catchall_3
    move-exception v0

    :try_start_8
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    monitor-exit v1
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    const/4 v4, 0x1

    move v5, v4

    throw v0
.end method

.method public final b()Ljava/lang/Object;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/l;
        replacement = "this.get()"
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/gms/common/config/a;->a()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public d(Ljava/lang/Object;)V
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v0, "sssGluveeaesVc"

    const-string v0, "eescVrsGlaevus"

    const/4 v3, 0x1

    const-string/jumbo v0, "evGmauierssleV"

    const-string v0, "GservicesValue"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v1, "trh ooesryct lG .arlodFVtsmoibn(ovsecatee(aT s:ieli fulvi)rsrstseli)perd "

    const-string/jumbo v1, "n(emvtTdatope tcVe .lbiyohsrtosrv)fseaiee ssGr rrisb:ruiFl)sodt lllia( ce"

    const/4 v3, 0x5

    const-string v1, "Veu lbo:eG(srtTr.nsrpe st cvF e  llsotslbrlaiuire)e(ryfddiicttshovsib)oaa"

    const-string v1, "GservicesValue.override(): test should probably call initForTests() first"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/config/a;->c:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    sget-object p1, Lcom/google/android/gms/common/config/a;->d:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    monitor-enter p1

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    monitor-enter p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    monitor-exit p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void

    :catchall_0
    move-exception v0

    :try_start_3
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    monitor-exit p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    throw v0

    :catchall_1
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    monitor-exit p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v3, 0x4

    throw v0
.end method

.method public e()V
    .locals 3
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/gms/common/config/a;->c:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method protected abstract k(Ljava/lang/String;)Ljava/lang/Object;
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end method
