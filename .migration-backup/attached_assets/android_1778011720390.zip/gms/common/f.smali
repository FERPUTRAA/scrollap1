.class public Lcom/google/android/gms/common/f;
.super Lcom/google/android/gms/common/g;


# annotations
.annotation runtime Lcom/google/errorprone/annotations/RestrictedInheritance;
    allowedOnPath = ".*java.*/com/google/android/gms.*"
    allowlistAnnotations = {
        Lcom/google/android/gms/internal/base/zad;,
        Lcom/google/android/gms/internal/base/zae;
    }
    explanation = "Sub classing of GMS Core\'s APIs are restricted to GMS Core client libs and testing fakes."
    link = "go/gmscore-restrictedinheritance"
.end annotation


# static fields
.field public static final h:I

.field public static final i:Ljava/lang/String; = "com.google.android.gms"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private static final j:Ljava/lang/Object;

.field private static final k:Lcom/google/android/gms/common/f;


# instance fields
.field private g:Ljava/lang/String;
    .annotation build Landroidx/annotation/b0;
        value = "lock"
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    sput-object v0, Lcom/google/android/gms/common/f;->j:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/gms/common/f;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/android/gms/common/f;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    sput-object v0, Lcom/google/android/gms/common/f;->k:Lcom/google/android/gms/common/f;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget v0, Lcom/google/android/gms/common/g;->a:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    sput v0, Lcom/google/android/gms/common/f;->h:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/gms/common/g;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public static final varargs N(Lcom/google/android/gms/common/api/m;[Lcom/google/android/gms/common/api/m;)Lcom/google/android/gms/tasks/Task;
    .locals 6
    .param p0    # Lcom/google/android/gms/common/api/m;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [Lcom/google/android/gms/common/api/m;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "d~sso~b  ~~@1~b~ @@@f ~@ @@~ n- ~or@c@ @~ .if~@u@~lSt@~4 itv@@@@~ma  @M   ~ o~oK~@/ l~oo~~b@~/yi"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    const-string/jumbo v0, "u.umlsneu tsnPsdeI  oqlA tRbeem"

    const-string v0, "buselslq  IAmeetPun dstueRt o.n"

    const/4 v5, 0x5

    const-string v0, "Rse.otousIAlP tenebu   dteumln "

    const-string v0, "Requested API must not be null."

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    array-length v1, p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x0

    if-ge v2, v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    aget-object v3, p1, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-static {v3, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    array-length v1, p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v0, p0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {}, Lcom/google/android/gms/common/api/internal/i;->u()Lcom/google/android/gms/common/api/internal/i;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0, v0}, Lcom/google/android/gms/common/api/internal/i;->x(Ljava/lang/Iterable;)Lcom/google/android/gms/tasks/Task;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-object p0
.end method

.method public static x()Lcom/google/android/gms/common/f;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/gms/common/f;->k:Lcom/google/android/gms/common/f;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public A(Landroid/app/Activity;II)Z
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2, p3, v0}, Lcom/google/android/gms/common/f;->B(Landroid/app/Activity;IILandroid/content/DialogInterface$OnCancelListener;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    return p1
.end method

.method public B(Landroid/app/Activity;IILandroid/content/DialogInterface$OnCancelListener;)Z
    .locals 2
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/google/android/gms/common/f;->t(Landroid/app/Activity;IILandroid/content/DialogInterface$OnCancelListener;)Landroid/app/Dialog;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    if-nez p2, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/4 p1, 0x0

    return p1

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    const-string/jumbo p3, "ogomlvrSersioPlglycDeoeErrGia"

    const-string/jumbo p3, "ilrGebiorllgvcegoErsooaSayPDr"

    const-string p3, "GooglePlayServicesErrorDialog"

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/google/android/gms/common/f;->I(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;Landroid/content/DialogInterface$OnCancelListener;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p1
.end method

.method public C(Landroid/app/Activity;ILandroidx/activity/result/h;Landroid/content/DialogInterface$OnCancelListener;)Z
    .locals 8
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroidx/activity/result/h;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            "I",
            "Landroidx/activity/result/h<",
            "Landroidx/activity/result/IntentSenderRequest;",
            ">;",
            "Landroid/content/DialogInterface$OnCancelListener;",
            ")Z"
        }
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v3, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-instance v5, Lcom/google/android/gms/common/x;

    const/4 v6, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct {v5, p0, p1, p2, p3}, Lcom/google/android/gms/common/x;-><init>(Lcom/google/android/gms/common/f;Landroid/app/Activity;ILandroidx/activity/result/h;)V

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    move v2, p2

    move v2, p2

    move v2, p2

    move-object v4, p4

    move-object v4, p4

    const/4 v7, 0x6

    const/4 v6, 0x6

    invoke-virtual/range {v0 .. v5}, Lcom/google/android/gms/common/f;->F(Landroid/content/Context;ILcom/google/android/gms/common/internal/o0;Landroid/content/DialogInterface$OnCancelListener;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/Dialog;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x5

    if-nez p2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 p1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x2

    return p1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string/jumbo p3, "iPolySuEeeciaGooorDlrgsrlegvr"

    const-string/jumbo p3, "iDEsooeGoSrrleleygvrocogaPlir"

    const/4 v7, 0x7

    const-string/jumbo p3, "orPelaipglrgiDrereGolEcvyaoSo"

    const-string p3, "GooglePlayServicesErrorDialog"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/google/android/gms/common/f;->I(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;Landroid/content/DialogInterface$OnCancelListener;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 p1, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    return p1
.end method

.method public D(Landroid/content/Context;I)V
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string/jumbo v1, "n"

    const-string/jumbo v1, "n"

    const/4 v3, 0x6

    const-string/jumbo v1, "n"

    const-string/jumbo v1, "n"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, p1, p2, v0, v1}, Lcom/google/android/gms/common/g;->g(Landroid/content/Context;IILjava/lang/String;)Landroid/app/PendingIntent;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0, p1, p2, v1, v0}, Lcom/google/android/gms/common/f;->J(Landroid/content/Context;ILjava/lang/String;Landroid/app/PendingIntent;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method public E(Landroid/content/Context;Lcom/google/android/gms/common/ConnectionResult;)V
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/common/f;->w(Landroid/content/Context;Lcom/google/android/gms/common/ConnectionResult;)Landroid/app/PendingIntent;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p2}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2, v1, v0}, Lcom/google/android/gms/common/f;->J(Landroid/content/Context;ILjava/lang/String;Landroid/app/PendingIntent;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method final F(Landroid/content/Context;ILcom/google/android/gms/common/internal/o0;Landroid/content/DialogInterface$OnCancelListener;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/Dialog;
    .locals 7
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/gms/common/internal/o0;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p5    # Landroid/content/DialogInterface$OnClickListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez p2, :cond_0

    const/4 v5, 0x7

    move v6, v5

    return-object v0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-instance v1, Landroid/util/TypedValue;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {v1}, Landroid/util/TypedValue;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const v3, 0x1010309

    const/4 v6, 0x4

    const/4 v4, 0x7

    const/4 v6, 0x5

    const/4 v4, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v2, v3, v1, v4}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget v1, v1, Landroid/util/TypedValue;->resourceId:I

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2, v1}, Landroid/content/res/Resources;->getResourceEntryName(I)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string/jumbo v2, "roegeab.qAmDTltil."

    const-string v2, "T..AebliaDmlhotegr"

    const/4 v6, 0x6

    const-string v2, ".gsriTDlhAmeeetlao"

    const-string v2, "Theme.Dialog.Alert"

    const/4 v6, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz v1, :cond_1

    const/4 v6, 0x5

    new-instance v0, Landroid/app/AlertDialog$Builder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v1, 0x5

    const/4 v6, 0x7

    invoke-direct {v0, p1, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-nez v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-instance v0, Landroid/app/AlertDialog$Builder;

    const/4 v6, 0x2

    invoke-direct {v0, p1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    :cond_2
    const/4 v5, 0x1

    const/4 v5, 0x0

    invoke-static {p1, p2}, Lcom/google/android/gms/common/internal/k0;->c(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz p4, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, p4}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    :cond_3
    const/4 v6, 0x7

    invoke-static {p1, p2}, Lcom/google/android/gms/common/internal/k0;->b(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object p4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz p4, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-nez p3, :cond_4

    move-object p3, p5

    move-object p3, p5

    move-object p3, p5

    move-object p3, p5

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0, p4, p3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    :cond_5
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {p1, p2}, Lcom/google/android/gms/common/internal/k0;->f(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz p1, :cond_6

    invoke-virtual {v0, p1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    :cond_6
    const/4 v6, 0x0

    const/4 v5, 0x6

    new-array p1, v4, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 p3, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v6, 0x3

    aput-object p2, p1, p3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string p2, " aama%eegitsoubsl ns efi uaiivtCoic.iu oaenylelGve=sitCro eacnn slooPgglyRrlstir"

    const-string p2, " s ofgutnaeoby Rv%niaylgoiao lPGtoai  s tCeCnseuilslll.ireoegeisercctvrn aiau=is"

    const/4 v6, 0x0

    const-string/jumbo p2, "sur=oifGagPiaRo tsi%.uen ibsC ondloiiysnoavoC ltl reoarsgte niacv g ialslceetyle"

    const-string p2, "Creating dialog for Google Play services availability issue. ConnectionResult=%s"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {p2, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-instance p2, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x2

    invoke-direct {p2}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string/jumbo p3, "tigapbaApivoilAobelli"

    const-string/jumbo p3, "piAlailpoleiGoigabvtA"

    const/4 v6, 0x5

    const-string/jumbo p3, "voeiaiupllgotAlyiiabG"

    const-string p3, "GoogleApiAvailability"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {p3, p1, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    return-object p1
.end method

.method public final G(Landroid/app/Activity;Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/Dialog;
    .locals 5
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance v0, Landroid/widget/ProgressBar;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const v1, 0x101007a

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0, p1, v2, v1}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setIndeterminate(Z)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v1, Landroid/app/AlertDialog$Builder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v1, p1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/16 v0, 0x12

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/k0;->c(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v1, v0, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v1, "iliavnGpsySUecqeDlartggeliooPogd"

    const-string/jumbo v1, "yglGegDsqiagdetcloraSvioaUeniloP"

    const/4 v4, 0x5

    const-string v1, "ecaogelUqgnPllgisdaDrptaoyoievSi"

    const-string v1, "GooglePlayServicesUpdatingDialog"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0, p1, v0, v1, p2}, Lcom/google/android/gms/common/f;->I(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;Landroid/content/DialogInterface$OnCancelListener;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object v0
.end method

.method public final H(Landroid/content/Context;Lcom/google/android/gms/common/api/internal/b2;)Lcom/google/android/gms/common/api/internal/zabx;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Landroid/content/IntentFilter;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const-string v1, "cKsAAC_.nsdeid.niGotatoD.PtaErnDinD"

    const-string v1, "DKs_d.iiD.rAatctAGCoannden.iEPADont"

    const/4 v3, 0x6

    const-string v1, "DD_m.Gannndt.AEiDottnEacAC.AedKiroi"

    const-string v1, "android.intent.action.PACKAGE_ADDED"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo v1, "gmcaopk"

    const-string v1, "caemgkp"

    const/4 v3, 0x3

    const-string v1, "ekcgaba"

    const-string/jumbo v1, "package"

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addDataScheme(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v1, Lcom/google/android/gms/common/api/internal/zabx;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v1, p2}, Lcom/google/android/gms/common/api/internal/zabx;-><init>(Lcom/google/android/gms/common/api/internal/b2;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p1, v1, v0}, Lcom/google/android/gms/internal/base/zao;->zaa(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v1, p1}, Lcom/google/android/gms/common/api/internal/zabx;->a(Landroid/content/Context;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo v0, "ord.lmudcg.mnogeoaisgo"

    const-string v0, "elm.osdiggdgoa.nr.cmoo"

    const/4 v3, 0x7

    const-string v0, "com.google.android.gms"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, p1, v0}, Lcom/google/android/gms/common/g;->n(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p2}, Lcom/google/android/gms/common/api/internal/b2;->a()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v1}, Lcom/google/android/gms/common/api/internal/zabx;->b()V

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 p1, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v1
.end method

.method final I(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;Landroid/content/DialogInterface$OnCancelListener;)V
    .locals 3
    .param p4    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    instance-of v0, p1, Landroidx/fragment/app/FragmentActivity;
    :try_end_0
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast p1, Landroidx/fragment/app/FragmentActivity;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroidx/fragment/app/FragmentActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p2, p4}, Lcom/google/android/gms/common/t;->f0(Landroid/app/Dialog;Landroid/content/DialogInterface$OnCancelListener;)Lcom/google/android/gms/common/t;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p2, p1, p3}, Lcom/google/android/gms/common/t;->show(Landroidx/fragment/app/FragmentManager;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void

    :catch_0
    :cond_0
    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/app/Activity;->getFragmentManager()Landroid/app/FragmentManager;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p2, p4}, Lcom/google/android/gms/common/ErrorDialogFragment;->b(Landroid/app/Dialog;Landroid/content/DialogInterface$OnCancelListener;)Lcom/google/android/gms/common/ErrorDialogFragment;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p2, p1, p3}, Lcom/google/android/gms/common/ErrorDialogFragment;->show(Landroid/app/FragmentManager;Ljava/lang/String;)V

    const/4 v1, 0x3

    move v2, v1

    return-void
.end method

.method final J(Landroid/content/Context;ILjava/lang/String;Landroid/app/PendingIntent;)V
    .locals 10
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x14
    .end annotation

    const/4 v9, 0x7

    const/4 p3, 0x2

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    new-array v0, p3, [Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v2, 0x5

    const/4 v9, 0x1

    const/4 v2, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    aput-object v1, v0, v2

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    const/4 v1, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v3, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    aput-object v1, v0, v3

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string v1, " ce%bilpsCtasc uAt.org,tiIabvsM oGolS ePnlnt =%Aiaynei"

    const-string v1, "elnotbi%Riab lGuA.Sotne%ygP Ivla Ca se=c,sicMrt iAstno"

    const/4 v9, 0x7

    const-string/jumbo v1, "t lya lAqCInuletG e%ts . niPtaio%ss=,SRbicacinoAe=orvM"

    const-string v1, "GMS core API Availability. ConnectionResult=%s, tag=%s"

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    new-instance v1, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-direct {v1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    const-string/jumbo v4, "lusiAgiylptAbiaooliea"

    const-string/jumbo v4, "llbAoiuAyeopvgliiaait"

    const/4 v9, 0x6

    const-string v4, "AaimbiAvoipGtlieoyagl"

    const-string v4, "GoogleApiAvailability"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {v4, v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/16 v0, 0x12

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-ne p2, v0, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/f;->K(Landroid/content/Context;)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    return-void

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-nez p4, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/4 p1, 0x6

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-ne p2, p1, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string/jumbo p1, "lyAaoiaGiliigeptAbopo"

    const-string p1, "AivAlagpobiaiieloGpty"

    const/4 v9, 0x5

    const-string/jumbo p1, "vpatibelioglGoAbiAial"

    const-string p1, "GoogleApiAvailability"

    const/4 v9, 0x4

    const-string/jumbo p2, "o tUtsupy(StxosvgiMaNToQnrfnE_liDo.)lRlitoCg.t lenEIqNsnuOnLnoto#CCe,Rsceb.nOaAnGracuionfeotoeahlo tiliiiRi R EssioRrrolnAIe tttcUuirEeso ewnCiia"

    const-string/jumbo p2, "isoer ovqnti# f.aUtoiaTluRosstAtpAnrsl ibQngnCiea)ndCn,EEcurgoeCroRtent iccMoelRiG noa.iDoiita_IIiyeS oNhoNxelftUOEtenwo(nlRitu.stOlECRolLis nors"

    const-string/jumbo p2, "giRlosopohtnNoi O_otetaurUNRe iEoCr,unlt#tfgsaCiRouirnceo.lebcalnRtsColisnnIieLtiMd AET).ntxenEQUAr(oowtiSRoO rlDiaslIeeGn.tylsCcEtn ovfioaiisn p"

    const-string p2, "Missing resolution for ConnectionResult.RESOLUTION_REQUIRED. Call GoogleApiAvailability#showErrorNotification(Context, ConnectionResult) instead."

    const/4 v9, 0x3

    const/4 v8, 0x2

    invoke-static {p1, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    return-void

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {p1, p2}, Lcom/google/android/gms/common/internal/k0;->e(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x2

    invoke-static {p1, p2}, Lcom/google/android/gms/common/internal/k0;->d(Landroid/content/Context;I)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    const-string v5, "ancosnfiqtio"

    const-string v5, "aosntfonciii"

    const/4 v9, 0x7

    const-string/jumbo v5, "ofscioinatnt"

    const-string/jumbo v5, "notification"

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p1, v5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {v5}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x3

    check-cast v5, Landroid/app/NotificationManager;

    const/4 v8, 0x5

    xor-int/2addr v9, v8

    new-instance v6, Landroidx/core/app/x1$g;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-direct {v6, p1}, Landroidx/core/app/x1$g;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v6, v3}, Landroidx/core/app/x1$g;->e0(Z)Landroidx/core/app/x1$g;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v6, v3}, Landroidx/core/app/x1$g;->D(Z)Landroidx/core/app/x1$g;

    move-result-object v6

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-virtual {v6, v0}, Landroidx/core/app/x1$g;->P(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    new-instance v6, Landroidx/core/app/x1$e;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-direct {v6}, Landroidx/core/app/x1$e;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v6, v1}, Landroidx/core/app/x1$e;->A(Ljava/lang/CharSequence;)Landroidx/core/app/x1$e;

    move-result-object v6

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v0, v6}, Landroidx/core/app/x1$g;->z0(Landroidx/core/app/x1$q;)Landroidx/core/app/x1$g;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {p1}, Lcom/google/android/gms/common/util/l;->l(Landroid/content/Context;)Z

    move-result v6

    const/4 v9, 0x5

    if-eqz v6, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {}, Lcom/google/android/gms/common/util/v;->i()Z

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->x(Z)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->icon:I

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Landroidx/core/app/x1$g;->t0(I)Landroidx/core/app/x1$g;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v1, p3}, Landroidx/core/app/x1$g;->k0(I)Landroidx/core/app/x1$g;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/util/l;->m(Landroid/content/Context;)Z

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-eqz v1, :cond_3

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    sget v1, Lcom/google/android/gms/base/R$drawable;->common_full_open_on_phone:I

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    sget v6, Lcom/google/android/gms/base/R$string;->common_open_on_phone:I

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v4, v6}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v0, v1, v4, p4}, Landroidx/core/app/x1$g;->a(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroidx/core/app/x1$g;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    goto :goto_0

    :cond_3
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v0, p4}, Landroidx/core/app/x1$g;->N(Landroid/app/PendingIntent;)Landroidx/core/app/x1$g;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    goto :goto_0

    :cond_4
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    const v6, 0x108008a

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v0, v6}, Landroidx/core/app/x1$g;->t0(I)Landroidx/core/app/x1$g;

    move-result-object v6

    const/4 v9, 0x4

    const/4 v8, 0x5

    sget v7, Lcom/google/android/gms/base/R$string;->common_google_play_services_notification_ticker:I

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v4, v7}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v6, v4}, Landroidx/core/app/x1$g;->B0(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v4, v6, v7}, Landroidx/core/app/x1$g;->H0(J)Landroidx/core/app/x1$g;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v4, p4}, Landroidx/core/app/x1$g;->N(Landroid/app/PendingIntent;)Landroidx/core/app/x1$g;

    move-result-object p4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p4, v1}, Landroidx/core/app/x1$g;->O(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {}, Lcom/google/android/gms/common/util/v;->n()Z

    move-result p4

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-nez p4, :cond_5

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto/16 :goto_2

    :cond_5
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {}, Lcom/google/android/gms/common/util/v;->n()Z

    move-result p4

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {p4}, Lcom/google/android/gms/common/internal/v;->x(Z)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    sget-object p4, Lcom/google/android/gms/common/f;->j:Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    monitor-enter p4

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/google/android/gms/common/f;->g:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    monitor-exit p4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-nez v1, :cond_7

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-string/jumbo v1, "m.lmanyedsvi.omirgcdolgoliba..aoamg"

    const-string/jumbo v1, "saomamyodm.arvg.ig.oldcelioi.blniga"

    const-string/jumbo v1, "gsobocnadia.oroyt.lmamei.dgivl.gali"

    const-string v1, "com.google.android.gms.availability"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {v5, v1}, Landroidx/browser/trusted/f;->a(Landroid/app/NotificationManager;Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object p4

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v9, 0x7

    sget v4, Lcom/google/android/gms/base/R$string;->common_google_play_services_notification_channel_name:I

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {p1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-nez p4, :cond_6

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    const/4 p4, 0x4

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {v1, p1, p4}, Landroidx/browser/trusted/j;->a(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x4

    invoke-static {v5, p1}, Landroidx/browser/trusted/e;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    goto :goto_1

    :cond_6
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {p4}, Landroidx/core/app/w0;->a(Landroid/app/NotificationChannel;)Ljava/lang/CharSequence;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {p1, v4}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-nez v4, :cond_7

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {p4, p1}, Lcom/google/android/gms/common/e;->a(Landroid/app/NotificationChannel;Ljava/lang/CharSequence;)V

    const/4 v8, 0x3

    move v9, v8

    invoke-static {v5, p4}, Landroidx/browser/trusted/e;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    :cond_7
    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Landroidx/core/app/x1$g;->H(Ljava/lang/String;)Landroidx/core/app/x1$g;

    :goto_2
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v0}, Landroidx/core/app/x1$g;->h()Landroid/app/Notification;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-eq p2, v3, :cond_8

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-eq p2, p3, :cond_8

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    const/4 p3, 0x3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-eq p2, p3, :cond_8

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    const p2, 0x9b6d

    const/4 v9, 0x3

    goto :goto_3

    :cond_8
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    sget-object p2, Lcom/google/android/gms/common/k;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {p2, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/16 p2, 0x28c4

    :goto_3
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v5, p2, p1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    monitor-exit p4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    throw p1
.end method

.method final K(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v0, Lcom/google/android/gms/common/y;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0, p0, p1}, Lcom/google/android/gms/common/y;-><init>(Lcom/google/android/gms/common/f;Landroid/content/Context;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-wide/32 v1, 0x1d4c0

    const-wide/32 v1, 0x1d4c0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, p1, v1, v2}, Landroid/os/Handler;->sendEmptyMessageDelayed(IJ)Z

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method

.method public final L(Landroid/app/Activity;Lcom/google/android/gms/common/api/internal/m;IILandroid/content/DialogInterface$OnCancelListener;)Z
    .locals 9
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/api/internal/m;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string p4, "d"

    const-string p4, "d"

    const/4 v8, 0x4

    const-string p4, "d"

    const-string p4, "d"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p0, p1, p3, p4}, Lcom/google/android/gms/common/f;->e(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object p4

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v0, 0x2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {p2, p4, v0}, Lcom/google/android/gms/common/internal/o0;->d(Lcom/google/android/gms/common/api/internal/m;Landroid/content/Intent;I)Lcom/google/android/gms/common/internal/o0;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v6, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    move v3, p3

    move v3, p3

    const/4 v8, 0x3

    move v3, p3

    move v3, p3

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual/range {v1 .. v6}, Lcom/google/android/gms/common/f;->F(Landroid/content/Context;ILcom/google/android/gms/common/internal/o0;Landroid/content/DialogInterface$OnCancelListener;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/Dialog;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x1

    if-nez p2, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/4 p1, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    return p1

    :cond_0
    const/4 v7, 0x0

    move v8, v7

    const-string/jumbo p3, "roDscbigEorilaySvlrarolPeeoGo"

    const-string p3, "PeGcorlsSarorvyergaooDiogliEl"

    const/4 v8, 0x7

    const-string p3, "egoDEluGrrilSocelePoraavosyig"

    const-string p3, "GooglePlayServicesErrorDialog"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p0, p1, p2, p3, p5}, Lcom/google/android/gms/common/f;->I(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;Landroid/content/DialogInterface$OnCancelListener;)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 p1, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    return p1
.end method

.method public final M(Landroid/content/Context;Lcom/google/android/gms/common/ConnectionResult;I)Z
    .locals 6
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x0

    move v5, v4

    invoke-static {p1}, Lcom/google/android/gms/common/wrappers/a;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/common/f;->w(Landroid/content/Context;Lcom/google/android/gms/common/ConnectionResult;)Landroid/app/PendingIntent;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p2}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result p2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p1, v0, p3, v2}, Lcom/google/android/gms/common/api/GoogleApiActivity;->a(Landroid/content/Context;Landroid/app/PendingIntent;IZ)Landroid/content/Intent;

    move-result-object p3

    const/4 v5, 0x0

    const/4 v4, 0x1

    sget v0, Lcom/google/android/gms/internal/base/zap;->zaa:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/high16 v3, 0x8000000

    or-int/2addr v0, v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p1, v1, p3, v0}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0, p1, p2, v0, p3}, Lcom/google/android/gms/common/f;->J(Landroid/content/Context;ILjava/lang/String;Landroid/app/PendingIntent;)V

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    return v2

    :cond_1
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    return v1
.end method

.method public c(Landroid/content/Context;)I
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-super {p0, p1}, Lcom/google/android/gms/common/g;->c(Landroid/content/Context;)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return p1
.end method

.method public e(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-super {p0, p1, p2, p3}, Lcom/google/android/gms/common/g;->e(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method public f(Landroid/content/Context;II)Landroid/app/PendingIntent;
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-super {p0, p1, p2, p3}, Lcom/google/android/gms/common/g;->f(Landroid/content/Context;II)Landroid/app/PendingIntent;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p1
.end method

.method public final h(I)Ljava/lang/String;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/android/gms/common/g;->h(I)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method public j(Landroid/content/Context;)I
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/m;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/android/gms/common/g;->j(Landroid/content/Context;)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    return p1
.end method

.method public k(Landroid/content/Context;I)I
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/z;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-super {p0, p1, p2}, Lcom/google/android/gms/common/g;->k(Landroid/content/Context;I)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return p1
.end method

.method public final o(I)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/android/gms/common/g;->o(I)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p1
.end method

.method public varargs q(Lcom/google/android/gms/common/api/k;[Lcom/google/android/gms/common/api/k;)Lcom/google/android/gms/tasks/Task;
    .locals 2
    .param p1    # Lcom/google/android/gms/common/api/k;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Lcom/google/android/gms/common/api/k;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/k<",
            "*>;[",
            "Lcom/google/android/gms/common/api/k<",
            "*>;)",
            "Lcom/google/android/gms/tasks/Task<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lcom/google/android/gms/common/f;->N(Lcom/google/android/gms/common/api/m;[Lcom/google/android/gms/common/api/m;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    sget-object p2, Lcom/google/android/gms/common/w;->a:Lcom/google/android/gms/common/w;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Lcom/google/android/gms/tasks/Task;->onSuccessTask(Lcom/google/android/gms/tasks/SuccessContinuation;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    return-object p1
.end method

.method public varargs r(Lcom/google/android/gms/common/api/m;[Lcom/google/android/gms/common/api/m;)Lcom/google/android/gms/tasks/Task;
    .locals 2
    .param p1    # Lcom/google/android/gms/common/api/m;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Lcom/google/android/gms/common/api/m;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/gms/common/api/m<",
            "*>;[",
            "Lcom/google/android/gms/common/api/m<",
            "*>;)",
            "Lcom/google/android/gms/tasks/Task<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lcom/google/android/gms/common/f;->N(Lcom/google/android/gms/common/api/m;[Lcom/google/android/gms/common/api/m;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    sget-object p2, Lcom/google/android/gms/common/v;->a:Lcom/google/android/gms/common/v;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Lcom/google/android/gms/tasks/Task;->onSuccessTask(Lcom/google/android/gms/tasks/SuccessContinuation;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p1
.end method

.method public s(Landroid/app/Activity;II)Landroid/app/Dialog;
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2, p3, v0}, Lcom/google/android/gms/common/f;->t(Landroid/app/Activity;IILandroid/content/DialogInterface$OnCancelListener;)Landroid/app/Dialog;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p1
.end method

.method public t(Landroid/app/Activity;IILandroid/content/DialogInterface$OnCancelListener;)Landroid/app/Dialog;
    .locals 9
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v7, 0x6

    move v8, v7

    const-string v0, "d"

    const-string v0, "d"

    const/4 v8, 0x3

    const-string v0, "d"

    const-string v0, "d"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/android/gms/common/f;->e(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {p1, v0, p3}, Lcom/google/android/gms/common/internal/o0;->b(Landroid/app/Activity;Landroid/content/Intent;I)Lcom/google/android/gms/common/internal/o0;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/4 v6, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    move v3, p2

    const/4 v8, 0x0

    move v3, p2

    move v3, p2

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual/range {v1 .. v6}, Lcom/google/android/gms/common/f;->F(Landroid/content/Context;ILcom/google/android/gms/common/internal/o0;Landroid/content/DialogInterface$OnCancelListener;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/Dialog;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    return-object p1
.end method

.method public u(Landroidx/fragment/app/Fragment;II)Landroid/app/Dialog;
    .locals 3
    .param p1    # Landroidx/fragment/app/Fragment;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2, p3, v0}, Lcom/google/android/gms/common/f;->v(Landroidx/fragment/app/Fragment;IILandroid/content/DialogInterface$OnCancelListener;)Landroid/app/Dialog;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p1
.end method

.method public v(Landroidx/fragment/app/Fragment;IILandroid/content/DialogInterface$OnCancelListener;)Landroid/app/Dialog;
    .locals 9
    .param p1    # Landroidx/fragment/app/Fragment;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v1, "d"

    const-string v1, "d"

    const/4 v8, 0x5

    const-string v1, "d"

    const-string v1, "d"

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p0, v0, p2, v1}, Lcom/google/android/gms/common/f;->e(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {p1, v0, p3}, Lcom/google/android/gms/common/internal/o0;->c(Landroidx/fragment/app/Fragment;Landroid/content/Intent;I)Lcom/google/android/gms/common/internal/o0;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v6, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    move v3, p2

    move v3, p2

    const/4 v8, 0x5

    move v3, p2

    move v3, p2

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual/range {v1 .. v6}, Lcom/google/android/gms/common/f;->F(Landroid/content/Context;ILcom/google/android/gms/common/internal/o0;Landroid/content/DialogInterface$OnCancelListener;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/Dialog;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    return-object p1
.end method

.method public w(Landroid/content/Context;Lcom/google/android/gms/common/ConnectionResult;)Landroid/app/PendingIntent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/gms/common/ConnectionResult;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p2}, Lcom/google/android/gms/common/ConnectionResult;->B2()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-virtual {p2}, Lcom/google/android/gms/common/ConnectionResult;->A2()Landroid/app/PendingIntent;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {p2}, Lcom/google/android/gms/common/ConnectionResult;->y2()I

    move-result p2

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/android/gms/common/f;->f(Landroid/content/Context;II)Landroid/app/PendingIntent;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p1
.end method

.method public y(Landroid/app/Activity;)Lcom/google/android/gms/tasks/Task;
    .locals 5
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l0;
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Activity;",
            ")",
            "Lcom/google/android/gms/tasks/Task<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    sget v0, Lcom/google/android/gms/common/f;->h:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v1, "leagmolp be semeGca cvkvidlhem etrsb iraetASmahlayaliePr lonou fadt"

    const-string v1, "Aearvbr mhtblem auiolsc s mayecleoianhdrG iavSlte  leotgemPafkldaee"

    const/4 v4, 0x7

    const-string/jumbo v1, "toGeno  qtd mmisivaerPhkgsemaAri t aSdmeleebal hbaecveylalc laorlfe"

    const-string/jumbo v1, "makeGooglePlayServicesAvailable must be called from the main thread"

    const/4 v4, 0x7

    invoke-static {v1}, Lcom/google/android/gms/common/internal/v;->k(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/android/gms/common/f;->k(Landroid/content/Context;I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/google/android/gms/tasks/Tasks;->forResult(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/google/android/gms/common/api/internal/h2;->i(Landroid/app/Activity;)Lcom/google/android/gms/common/api/internal/h2;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v2, Lcom/google/android/gms/common/ConnectionResult;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v2, v0, v1}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1, v2, v0}, Lcom/google/android/gms/common/api/internal/u3;->h(Lcom/google/android/gms/common/ConnectionResult;I)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/h2;->j()Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object p1
.end method

.method public z(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1a
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/gms/common/util/v;->n()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string v0, "cnsiottinfio"

    const-string/jumbo v0, "notification"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast p1, Landroid/app/NotificationManager;

    const/4 v2, 0x0

    invoke-static {p1, p2}, Landroidx/browser/trusted/f;->a(Landroid/app/NotificationManager;Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    sget-object p1, Lcom/google/android/gms/common/f;->j:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    monitor-enter p1

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object p2, p0, Lcom/google/android/gms/common/f;->g:Ljava/lang/String;

    const/4 v2, 0x1

    monitor-exit p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void

    :catchall_0
    move-exception p2

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    throw p2
.end method
