.class abstract Lcom/google/android/gms/common/n0;
.super Lcom/google/android/gms/common/internal/p2;


# instance fields
.field private final a:I


# direct methods
.method protected constructor <init>([B)V
    .locals 4

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/p2;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    array-length v0, p1

    const/4 v3, 0x1

    const/16 v1, 0x19

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->a(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p1}, Ljava/util/Arrays;->hashCode([B)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    iput p1, p0, Lcom/google/android/gms/common/n0;->a:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method protected static b(Ljava/lang/String;)[B
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ soo4 K~~ ~@@f   @@u@ool@~vto~lsS~~.@@tb~@dM~@~/   @n~c~io@f@~1a@@ib ~i~ /@-r ~@ ~@ ~~y @m~b@  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const-string v0, "91ImSOs88-"

    const-string v0, "O8s-S-I189"

    const/4 v2, 0x4

    const-string v0, "O-I5oS8189"

    const-string v0, "ISO-8859-1"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0

    :catch_0
    move-exception p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/AssertionError;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    throw v0
.end method


# virtual methods
.method abstract c()[B
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x7

    const/4 v0, 0x0

    move v3, v0

    move v3, v0

    const/4 v4, 0x6

    if-eqz p1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    instance-of v1, p1, Lcom/google/android/gms/common/internal/g1;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-nez v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    check-cast p1, Lcom/google/android/gms/common/internal/g1;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p1}, Lcom/google/android/gms/common/internal/g1;->zzc()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget v2, p0, Lcom/google/android/gms/common/n0;->a:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eq v1, v2, :cond_1

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    return v0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {p1}, Lcom/google/android/gms/common/internal/g1;->zzd()Lcom/google/android/gms/dynamic/d;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez p1, :cond_2

    const/4 v3, 0x7

    move v4, v3

    return v0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/google/android/gms/dynamic/f;->b(Lcom/google/android/gms/dynamic/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    check-cast p1, [B

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/android/gms/common/n0;->c()[B

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-static {v1, p1}, Ljava/util/Arrays;->equals([B[B)Z

    move-result p1
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    return p1

    :catch_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v1, "tlegsbtiCGmroieeco"

    const-string v1, "ecomtCsgeiGflreito"

    const/4 v4, 0x7

    const-string v1, "GetgosuifrcoeaitlC"

    const-string v1, "GoogleCertificates"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v2, "stoGg rpfleir gmcerlmottt oi oeeite  cfaeFaod"

    const-string/jumbo v2, "oGoloeglc fa eeteteofd actersiigmtirtFom r  o"

    const/4 v4, 0x3

    const-string v2, "Failed to get Google certificates from remote"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v1, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_3
    :goto_0
    const/4 v4, 0x3

    return v0
.end method

.method public final hashCode()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/gms/common/n0;->a:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    return v0
.end method

.method public final zzc()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/gms/common/n0;->a:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public final zzd()Lcom/google/android/gms/dynamic/d;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/gms/common/n0;->c()[B

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/android/gms/dynamic/f;->c(Ljava/lang/Object;)Lcom/google/android/gms/dynamic/d;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method
