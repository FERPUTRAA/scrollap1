.class public final Lcom/google/android/gms/common/h0;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation


# direct methods
.method static a(I)I
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x0

    const/4 v0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v1, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v2, 0x3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    filled-new-array {v0, v1, v2}, [I

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-ge v3, v2, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    aget v4, v1, v3

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    add-int/lit8 v5, v4, -0x1

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v4, :cond_1

    const/4 v6, 0x7

    and-int/2addr v7, v6

    if-ne v5, p0, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    return v4

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 p0, 0x0

    const/4 v6, 0x0

    xor-int/2addr v7, v6

    throw p0

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    return v0
.end method
