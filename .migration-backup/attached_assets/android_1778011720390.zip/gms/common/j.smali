.class public final Lcom/google/android/gms/common/j;
.super Lcom/google/android/gms/common/k;


# static fields
.field public static final k:Ljava/lang/String; = "GooglePlayServicesErrorDialog"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final l:I
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final m:Ljava/lang/String; = "com.google.android.gms"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final n:Ljava/lang/String; = "com.android.vending"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget v0, Lcom/google/android/gms/common/k;->a:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    sput v0, Lcom/google/android/gms/common/j;->l:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/gms/common/k;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public static A(ILandroid/content/Context;)V
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@is~@~ l@o ~~uv~~it b@@l~@or/~@ bKa@4~@@o~@o~@.mc d@~b 1S~~@@  ~syf ~Mn i @ ~@ ~~ @t fo~  ~@@/-~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/android/gms/common/f;->x()Lcom/google/android/gms/common/f;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p1, p0}, Lcom/google/android/gms/common/k;->o(Landroid/content/Context;I)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x6

    invoke-static {p1, p0}, Lcom/google/android/gms/common/k;->p(Landroid/content/Context;I)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, p1, p0}, Lcom/google/android/gms/common/f;->D(Landroid/content/Context;I)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/gms/common/f;->K(Landroid/content/Context;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public static f(ILandroid/content/Context;I)Landroid/app/PendingIntent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/android/gms/common/g;->i()Lcom/google/android/gms/common/g;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p0, p2}, Lcom/google/android/gms/common/g;->f(Landroid/content/Context;II)Landroid/app/PendingIntent;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method public static g(I)Ljava/lang/String;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    invoke-static {p0}, Lcom/google/android/gms/common/k;->g(I)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method public static i(Landroid/content/Context;)Landroid/content/Context;
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/android/gms/common/k;->i(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p0
.end method

.method public static j(Landroid/content/Context;)Landroid/content/res/Resources;
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/google/android/gms/common/k;->j(Landroid/content/Context;)Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method public static l(Landroid/content/Context;)I
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lcom/google/android/gms/common/internal/m;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/android/gms/common/k;->l(Landroid/content/Context;)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p0
.end method

.method public static m(Landroid/content/Context;I)I
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/google/android/gms/common/k;->m(Landroid/content/Context;I)I

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p0
.end method

.method public static s(I)Z
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/android/gms/common/k;->s(I)Z

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p0
.end method

.method public static v(ILandroid/app/Activity;I)Landroid/app/Dialog;
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p0, p1, p2, v0}, Lcom/google/android/gms/common/j;->w(ILandroid/app/Activity;ILandroid/content/DialogInterface$OnCancelListener;)Landroid/app/Dialog;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0
.end method

.method public static w(ILandroid/app/Activity;ILandroid/content/DialogInterface$OnCancelListener;)Landroid/app/Dialog;
    .locals 4
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p1, p0}, Lcom/google/android/gms/common/k;->o(Landroid/content/Context;I)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/16 p0, 0x12

    :cond_0
    const/4 v3, 0x3

    invoke-static {}, Lcom/google/android/gms/common/f;->x()Lcom/google/android/gms/common/f;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p0, p2, p3}, Lcom/google/android/gms/common/f;->t(Landroid/app/Activity;IILandroid/content/DialogInterface$OnCancelListener;)Landroid/app/Dialog;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p0
.end method

.method public static x(ILandroid/app/Activity;I)Z
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p0, p1, p2, v0}, Lcom/google/android/gms/common/j;->y(ILandroid/app/Activity;ILandroid/content/DialogInterface$OnCancelListener;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return p0
.end method

.method public static y(ILandroid/app/Activity;ILandroid/content/DialogInterface$OnCancelListener;)Z
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/l;
        imports = {
            "androidx.fragment.app.Fragment",
            "com.google.android.gms.common.GooglePlayServicesUtil"
        }
        replacement = "GooglePlayServicesUtil.showErrorDialogFragment(errorCode, activity, (Fragment) null, requestCode, cancelListener)"
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p0, p1, v0, p2, p3}, Lcom/google/android/gms/common/j;->z(ILandroid/app/Activity;Landroidx/fragment/app/Fragment;ILandroid/content/DialogInterface$OnCancelListener;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return p0
.end method

.method public static z(ILandroid/app/Activity;Landroidx/fragment/app/Fragment;ILandroid/content/DialogInterface$OnCancelListener;)Z
    .locals 10
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/fragment/app/Fragment;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroid/content/DialogInterface$OnCancelListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {p1, p0}, Lcom/google/android/gms/common/k;->o(Landroid/content/Context;I)Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/4 v1, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-ne v1, v0, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/16 p0, 0x12

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    move v4, p0

    move v4, p0

    const/4 v9, 0x3

    move v4, p0

    move v4, p0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {}, Lcom/google/android/gms/common/f;->x()Lcom/google/android/gms/common/f;

    move-result-object p0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-nez p2, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {p0, p1, v4, p3, p4}, Lcom/google/android/gms/common/f;->B(Landroid/app/Activity;IILandroid/content/DialogInterface$OnCancelListener;)Z

    move-result p0

    const/4 v9, 0x1

    const/4 v8, 0x7

    return p0

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    const-string v0, "d"

    const-string v0, "d"

    const/4 v9, 0x4

    const-string v0, "d"

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {}, Lcom/google/android/gms/common/f;->x()Lcom/google/android/gms/common/f;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v2, p1, v4, v0}, Lcom/google/android/gms/common/f;->e(Landroid/content/Context;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {p2, v0, p3}, Lcom/google/android/gms/common/internal/o0;->c(Landroidx/fragment/app/Fragment;Landroid/content/Intent;I)Lcom/google/android/gms/common/internal/o0;

    move-result-object v5

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual/range {v2 .. v7}, Lcom/google/android/gms/common/f;->F(Landroid/content/Context;ILcom/google/android/gms/common/internal/o0;Landroid/content/DialogInterface$OnCancelListener;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/Dialog;

    move-result-object p2

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-nez p2, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 p0, 0x0

    const/4 v9, 0x6

    return p0

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x0

    const-string/jumbo p3, "slgmolDEiacreragryvilooPoSsGe"

    const-string/jumbo p3, "rssiDiPoyrSGrellcrooaaElgvgeo"

    const/4 v9, 0x5

    const-string/jumbo p3, "gerlollroiPSiogoeyrseovEaGarD"

    const-string p3, "GooglePlayServicesErrorDialog"

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/google/android/gms/common/f;->I(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;Landroid/content/DialogInterface$OnCancelListener;)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    return v1
.end method
