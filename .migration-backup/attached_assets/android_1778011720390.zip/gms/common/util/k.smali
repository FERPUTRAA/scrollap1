.class public Lcom/google/android/gms/common/util/k;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/gms/common/util/g;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static final a:Lcom/google/android/gms/common/util/k;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Lcom/google/android/gms/common/util/k;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/android/gms/common/util/k;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    sput-object v0, Lcom/google/android/gms/common/util/k;->a:Lcom/google/android/gms/common/util/k;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public static d()Lcom/google/android/gms/common/util/g;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/common/util/k;->a:Lcom/google/android/gms/common/util/k;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public final a()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-wide v0
.end method

.method public final b()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Landroid/os/SystemClock;->currentThreadTimeMillis()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    return-wide v0
.end method

.method public final c()J
    .locals 4

    const/4 v2, 0x4

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-wide v0
.end method

.method public final nanoTime()J
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-wide v0
.end method
