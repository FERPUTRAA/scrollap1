.class public Lcom/google/android/gms/common/util/d0;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static final a:I

.field private static final b:Ljava/lang/reflect/Method;

.field private static final c:Ljava/lang/reflect/Method;

.field private static final d:Ljava/lang/reflect/Method;

.field private static final e:Ljava/lang/reflect/Method;

.field private static final f:Ljava/lang/reflect/Method;

.field private static final g:Ljava/lang/reflect/Method;

.field private static final h:Ljava/lang/reflect/Method;

.field private static final i:Ljava/lang/reflect/Method;

.field private static j:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/b0;
        value = "WorkSourceUtil.class"
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 12

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-string v0, "dda"

    const-string v0, "dda"

    const/4 v11, 0x5

    const-string v0, "dad"

    const-string v0, "add"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    const-class v1, Landroid/os/WorkSource;

    const-class v1, Landroid/os/WorkSource;

    const/4 v11, 0x4

    const-class v1, Landroid/os/WorkSource;

    const-class v1, Landroid/os/WorkSource;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v2

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    sput v2, Lcom/google/android/gms/common/util/d0;->a:I

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    const/4 v2, 0x1

    const/4 v11, 0x6

    const/4 v3, 0x0

    const/4 v11, 0x3

    move v10, v3

    move v10, v3

    const/4 v11, 0x3

    const/4 v4, 0x0

    const/4 v11, 0x4

    move v10, v4

    move v10, v4

    :try_start_0
    const/4 v11, 0x1

    new-array v5, v2, [Ljava/lang/Class;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    sget-object v6, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x6

    aput-object v6, v5, v3

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v1, v0, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    goto :goto_0

    :catch_0
    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    :goto_0
    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    sput-object v5, Lcom/google/android/gms/common/util/d0;->b:Ljava/lang/reflect/Method;

    const/4 v11, 0x6

    const/4 v10, 0x4

    invoke-static {}, Lcom/google/android/gms/common/util/v;->g()Z

    move-result v5

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x1

    const-class v6, Ljava/lang/String;

    const-class v6, Ljava/lang/String;

    const/4 v11, 0x7

    const-class v6, Ljava/lang/String;

    const-class v6, Ljava/lang/String;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    const/4 v7, 0x2

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-eqz v5, :cond_0

    :try_start_1
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    new-array v5, v7, [Ljava/lang/Class;

    const/4 v10, 0x1

    and-int/2addr v11, v10

    sget-object v8, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    aput-object v8, v5, v3

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    aput-object v6, v5, v2

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v1, v0, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    goto :goto_1

    :catch_1
    :cond_0
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :goto_1
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    sput-object v0, Lcom/google/android/gms/common/util/d0;->c:Ljava/lang/reflect/Method;

    :try_start_2
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string/jumbo v0, "ezis"

    const-string v0, "eszi"

    const/4 v11, 0x4

    const-string v0, "eisz"

    const-string/jumbo v0, "size"

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    new-array v5, v3, [Ljava/lang/Class;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v1, v0, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    goto :goto_2

    :catch_2
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :goto_2
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    sput-object v0, Lcom/google/android/gms/common/util/d0;->d:Ljava/lang/reflect/Method;

    :try_start_3
    const/4 v11, 0x7

    const-string/jumbo v0, "etg"

    const-string/jumbo v0, "etg"

    const/4 v11, 0x0

    const-string/jumbo v0, "teg"

    const-string/jumbo v0, "get"

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    new-array v5, v2, [Ljava/lang/Class;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    sget-object v8, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    aput-object v8, v5, v3

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v1, v0, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    goto :goto_3

    :catch_3
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :goto_3
    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    sput-object v0, Lcom/google/android/gms/common/util/d0;->e:Ljava/lang/reflect/Method;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-static {}, Lcom/google/android/gms/common/util/v;->g()Z

    move-result v0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-eqz v0, :cond_1

    :try_start_4
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-string v0, "egssmet"

    const-string/jumbo v0, "tmsegeN"

    const/4 v11, 0x2

    const-string v0, "eNematm"

    const-string/jumbo v0, "getName"

    const/4 v10, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    new-array v5, v2, [Ljava/lang/Class;

    const/4 v11, 0x4

    sget-object v8, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    aput-object v8, v5, v3

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v1, v0, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    goto :goto_4

    :catch_4
    :cond_1
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :goto_4
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    sput-object v0, Lcom/google/android/gms/common/util/d0;->f:Ljava/lang/reflect/Method;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {}, Lcom/google/android/gms/common/util/v;->o()Z

    move-result v0

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    const-string v5, "cWSrooriutokme"

    const-string v5, "erlmuocWkrSito"

    const/4 v11, 0x3

    const-string/jumbo v5, "rlStibcreuWkoo"

    const-string v5, "WorkSourceUtil"

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-eqz v0, :cond_2

    :try_start_5
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    const-string v0, "createWorkChain"

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    new-array v8, v3, [Ljava/lang/Class;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {v1, v0, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_5

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto :goto_5

    :catch_5
    move-exception v0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    const-string/jumbo v8, "tisCoe Ahcenh irCrnnaWMrkkii soPaIgao"

    const/4 v11, 0x1

    const-string/jumbo v8, "hrkAenuka C aPtaneicrn gCiosWIMWsoihr"

    const-string v8, "Missing WorkChain API createWorkChain"

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {v5, v8, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_2
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :goto_5
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    sput-object v0, Lcom/google/android/gms/common/util/d0;->g:Ljava/lang/reflect/Method;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {}, Lcom/google/android/gms/common/util/v;->o()Z

    move-result v0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-eqz v0, :cond_3

    :try_start_6
    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    const-string/jumbo v0, "oWiWbdipSrnr.rCeokasd.ruhonoco$"

    const-string/jumbo v0, "oirWebuodsdnorWSa.C.ikon$krocrh"

    const/4 v11, 0x5

    const-string/jumbo v0, "kkdioWC.qrornrooSrasduaniWohc.$"

    const-string v0, "android.os.WorkSource$WorkChain"

    const/4 v11, 0x6

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v11, 0x4

    const/4 v10, 0x4

    const-string v8, "adsudoe"

    const-string v8, "aodeddu"

    const/4 v11, 0x3

    const-string v8, "dNamded"

    const-string v8, "addNode"

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x5

    new-array v7, v7, [Ljava/lang/Class;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x7

    sget-object v9, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    aput-object v9, v7, v3

    const/4 v10, 0x2

    shl-int/2addr v11, v10

    aput-object v6, v7, v2

    const/4 v10, 0x3

    move v11, v10

    invoke-virtual {v0, v8, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_6

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    goto :goto_6

    :catch_6
    move-exception v0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string v6, "MghlossaWc noprCniksisa"

    const-string v6, "aonWlsgpshicaisi CkMrns"

    const/4 v11, 0x1

    const-string/jumbo v6, "nsaagbihs isoiCn rWsclM"

    const-string v6, "Missing WorkChain class"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-static {v5, v6, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_3
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :goto_6
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    sput-object v0, Lcom/google/android/gms/common/util/d0;->h:Ljava/lang/reflect/Method;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {}, Lcom/google/android/gms/common/util/v;->o()Z

    move-result v0

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x1

    if-eqz v0, :cond_4

    :try_start_7
    const/4 v10, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    const-string/jumbo v0, "tyspmqu"

    const-string/jumbo v0, "sqmtpyE"

    const/4 v11, 0x5

    const-string/jumbo v0, "isEmpty"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    new-array v3, v3, [Ljava/lang/Class;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v1, v0, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_7

    :try_start_8
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_8

    const/4 v10, 0x4

    move v11, v10

    goto :goto_7

    :catch_7
    :cond_4
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :catch_8
    :goto_7
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    sput-object v0, Lcom/google/android/gms/common/util/d0;->i:Ljava/lang/reflect/Method;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    sput-object v4, Lcom/google/android/gms/common/util/d0;->j:Ljava/lang/Boolean;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Landroid/os/WorkSource;ILjava/lang/String;)V
    .locals 8
    .param p0    # Landroid/os/WorkSource;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~  @  @pd@v@l~@ @o1t~ ons@~ ~fa~@i @@ /@.~~~~r~ ~ o4b-~~~@@u~~i@yoo@@ ~ S@t ~@b~ @Ki~~ @lMmboc/f"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x7

    sget-object v0, Lcom/google/android/gms/common/util/d0;->c:Ljava/lang/reflect/Method;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v1, " eoW oaeqhhgn grmruinbltSktloaUsbcua  ser"

    const-string v1, "Unable to assign blame through WorkSource"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string/jumbo v2, "ikslcoSoeWruUr"

    const/4 v7, 0x5

    const-string/jumbo v2, "iosclrktuoUWer"

    const-string v2, "WorkSourceUtil"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v3, 0x0

    const/4 v7, 0x3

    const/4 v4, 0x6

    const/4 v7, 0x0

    const/4 v4, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-eqz v0, :cond_1

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    if-nez p2, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-string p2, ""

    const-string p2, ""

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v5, 0x2

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    aput-object p1, v5, v3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    aput-object p2, v5, v4

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v0, p0, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    return-void

    :catch_0
    move-exception p0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v2, v1, p0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    return-void

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    sget-object p2, Lcom/google/android/gms/common/util/d0;->b:Ljava/lang/reflect/Method;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-eqz p2, :cond_2

    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-array v0, v4, [Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    aput-object p1, v0, v3

    const/4 v7, 0x2

    invoke-virtual {p2, p0, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-void

    :catch_1
    move-exception p0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {v2, v1, p0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-void
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;)Landroid/os/WorkSource;
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v0, "itkmWlrooUecmr"

    const-string/jumbo v0, "tUimulorcokrWe"

    const/4 v4, 0x3

    const-string/jumbo v0, "orSWocuotrkUei"

    const-string v0, "WorkSourceUtil"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz p0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz p1, :cond_1

    :try_start_0
    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p0}, Lcom/google/android/gms/common/wrappers/d;->a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, p1, v2}, Lcom/google/android/gms/common/wrappers/c;->c(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string p0, "   u bloppfoaonfktoct:naeicmt a dlganporIgeo"

    const-string/jumbo p0, "mpaooligfIonat oorc n l cnopkfpua: aitee gdt"

    const/4 v4, 0x5

    const-string/jumbo p0, "nfpgooulp  ci:rpoI ekfCtadg uann om ttaoalie"

    const-string p0, "Could not get applicationInfo from package: "

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object v1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance v0, Landroid/os/WorkSource;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0}, Landroid/os/WorkSource;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/android/gms/common/util/d0;->a(Landroid/os/WorkSource;ILjava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    return-object v0

    :catch_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string p0, "bCcd lgpu oa kn:ae ption"

    const-string p0, "  oe bnd:nltaiupak fcCog"

    const/4 v4, 0x3

    const-string/jumbo p0, "oc:  fklqCnnoageu da dtp"

    const-string p0, "Could not find package: "

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object v1
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/os/WorkSource;
    .locals 11
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v0, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x0

    const-string/jumbo v1, "tlskUuirrWcoue"

    const-string v1, "cktoirurlSeuWU"

    const/4 v10, 0x1

    const-string/jumbo v1, "itlmockSWoreUr"

    const-string v1, "WorkSourceUtil"

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-eqz p0, :cond_6

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-eqz v2, :cond_6

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz p2, :cond_6

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-nez p1, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    goto/16 :goto_3

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/4 v2, -0x1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/4 v3, 0x0

    :try_start_0
    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {p0}, Lcom/google/android/gms/common/wrappers/d;->a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object p0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {p0, p1, v3}, Lcom/google/android/gms/common/wrappers/c;->c(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-nez p0, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    const-string p0, "  icopamlgtaopIirtdnc oapl:otopeu anf Cngfko"

    const-string/jumbo p0, "t kurpopoItgp:eeioof aacaogln  ndmilntpfacC "

    const/4 v10, 0x7

    const-string/jumbo p0, "pgduabiptocgm  c oelCr  ooatnnkaffientl:ao p"

    const-string p0, "Could not get applicationInfo from package: "

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    goto :goto_0

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget v2, p0, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto :goto_0

    :catch_0
    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string p0, "co: kgudCdifuql np o aet"

    const-string p0, "d peou kq:l  ifgnoaCdctn"

    const/4 v10, 0x0

    const-string/jumbo p0, "fdo:diapa lkon ptnCgu c "

    const-string p0, "Could not find package: "

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-gez v2, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    return-object v0

    :cond_2
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    new-instance p0, Landroid/os/WorkSource;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-direct {p0}, Landroid/os/WorkSource;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    sget-object v0, Lcom/google/android/gms/common/util/d0;->g:Ljava/lang/reflect/Method;

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-eqz v0, :cond_5

    const/4 v10, 0x7

    sget-object v4, Lcom/google/android/gms/common/util/d0;->h:Ljava/lang/reflect/Method;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-nez v4, :cond_3

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    goto :goto_1

    :cond_3
    :try_start_1
    const/4 v10, 0x1

    const/4 v9, 0x0

    new-array v5, v3, [Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0, p0, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    sget v5, Lcom/google/android/gms/common/util/d0;->a:I

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    const/4 v6, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/4 v7, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-eq v2, v5, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    new-array v8, v7, [Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    aput-object v2, v8, v3

    const/4 v10, 0x7

    const/4 v9, 0x0

    aput-object p1, v8, v6

    const/4 v9, 0x3

    shl-int/2addr v10, v9

    invoke-virtual {v4, v0, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_4
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    new-array p1, v7, [Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    aput-object v2, p1, v3

    const/4 v10, 0x1

    const/4 v9, 0x6

    aput-object p2, p1, v6

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v4, v0, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    goto :goto_2

    :catch_1
    move-exception p1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    const-string p2, " gWot leqrscnha orueeenr ka gbmhsuiaobdSst Uclhoi"

    const-string/jumbo p2, "oSsWo  raleicosUsgernaha ebr u nbtuikhoamtcedhgl "

    const/4 v10, 0x6

    const-string/jumbo p2, "hcshg rncbkhooirnaWltsisabgu a eenomo  UaueeSl dr"

    const-string p2, "Unable to assign chained blame through WorkSource"

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {v1, p2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v10, 0x0

    goto :goto_2

    :cond_5
    :goto_1
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {p0, v2, p1}, Lcom/google/android/gms/common/util/d0;->a(Landroid/os/WorkSource;ILjava/lang/String;)V

    :goto_2
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    return-object p0

    :cond_6
    :goto_3
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    const-string/jumbo p0, "utdmcsellxnnuegrpUmn mea "

    const-string/jumbo p0, "nxemunUna eleucdgmpt lesr"

    const/4 v10, 0x0

    const-string/jumbo p0, "nrclolepeUun suxmna ettdg"

    const-string p0, "Unexpected null arguments"

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x0

    return-object v0
.end method

.method public static d(Landroid/os/WorkSource;I)I
    .locals 5
    .param p0    # Landroid/os/WorkSource;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x7

    sget-object v0, Lcom/google/android/gms/common/util/d0;->e:Ljava/lang/reflect/Method;

    const/4 v3, 0x5

    move v4, v3

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x1

    :try_start_0
    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    aput-object p1, v2, v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast p0, Ljava/lang/Integer;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    return p0

    :catch_0
    move-exception p0

    const/4 v4, 0x0

    const-string/jumbo p1, "rSUitbocouerko"

    const-string/jumbo p1, "etiuokoSrUWocr"

    const/4 v4, 0x5

    const-string/jumbo p1, "rcrUWluokuoiSe"

    const-string p1, "WorkSourceUtil"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const-string v0, " Snocbgr haUtkbsriboluensamuWog  htalro e"

    const-string/jumbo v0, "hm rkWip torlsgrasuboe othga cneabloUuS e"

    const-string v0, "Unable to assign blame through WorkSource"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1, v0, p0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    return v1
.end method

.method public static e(Landroid/os/WorkSource;I)Ljava/lang/String;
    .locals 5
    .param p0    # Landroid/os/WorkSource;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x7

    sget-object v0, Lcom/google/android/gms/common/util/d0;->f:Ljava/lang/reflect/Method;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v1, 0x1

    :try_start_0
    const/4 v4, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x0

    or-int/2addr v4, v2

    const/4 v3, 0x3

    xor-int/2addr v4, v3

    aput-object p1, v1, v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast p0, Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object p0

    :catch_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo p1, "keuolSutcoUWrr"

    const/4 v4, 0x6

    const-string p1, "UrtokociqlSreu"

    const-string p1, "WorkSourceUtil"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v0, "rbsrees brnagsnpuSihlotco k UhmoWatougel "

    const-string/jumbo v0, "ksubSshpeolerebor   u lWmthtna gcnrooUiga"

    const/4 v4, 0x2

    const-string v0, "ahombheinsSoerb nlut Wrosokmea agtc rlU u"

    const-string v0, "Unable to assign blame through WorkSource"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p1, v0, p0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    const/4 v4, 0x1

    const/4 p0, 0x0

    const/4 v4, 0x5

    const/4 p0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-object p0
.end method

.method public static f(Landroid/os/WorkSource;)Ljava/util/List;
    .locals 7
    .param p0    # Landroid/os/WorkSource;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/WorkSource;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-nez p0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    move v2, v1

    move v2, v1

    const/4 v6, 0x4

    move v2, v1

    move v2, v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/util/d0;->i(Landroid/os/WorkSource;)I

    move-result v2

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    if-eqz v2, :cond_2

    :goto_1
    const/4 v5, 0x1

    move v6, v5

    if-ge v1, v2, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p0, v1}, Lcom/google/android/gms/common/util/d0;->e(Landroid/os/WorkSource;I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v3}, Lcom/google/android/gms/common/util/b0;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-nez v4, :cond_1

    const/4 v6, 0x0

    invoke-static {v3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_1

    :cond_2
    const/4 v6, 0x6

    return-object v0
.end method

.method public static declared-synchronized g(Landroid/content/Context;)Z
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-class v0, Lcom/google/android/gms/common/util/d0;

    const-class v0, Lcom/google/android/gms/common/util/d0;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v1, Lcom/google/android/gms/common/util/d0;->j:Ljava/lang/Boolean;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    return p0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-nez p0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    return v1

    :cond_1
    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v2, "drSEoT.qiSiDAVonpEEsdaADTeni_srI.mUTo_"

    const-string v2, "A.dsDEaiqDeEToi_r.TpnATmEoi_nsCVISSrdU"

    const/4 v4, 0x2

    const-string v2, "E.EDsbiT_TAdoEmUDdSIeropnSATrV_isaCni."

    const-string v2, "android.permission.UPDATE_DEVICE_STATS"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p0, v2}, Landroidx/core/content/d;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-nez p0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x1

    :cond_2
    const/4 v4, 0x2

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x3

    sput-object p0, Lcom/google/android/gms/common/util/d0;->j:Ljava/lang/Boolean;

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v4, 0x1

    return p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    throw p0
.end method

.method public static h(Landroid/os/WorkSource;)Z
    .locals 6
    .param p0    # Landroid/os/WorkSource;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    sget-object v0, Lcom/google/android/gms/common/util/d0;->i:Ljava/lang/reflect/Method;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v5, 0x1

    new-array v2, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    check-cast v0, Ljava/lang/Boolean;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    return p0

    :catch_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string/jumbo v2, "okioseurtucrUS"

    const-string/jumbo v2, "rUsckoieSWutor"

    const/4 v5, 0x1

    const-string/jumbo v2, "ktirrlepocSuUo"

    const-string v2, "WorkSourceUtil"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string v3, "blceae iq c ueecm sUonmekrrpnhookStt"

    const-string v3, "ec msh nUnoreboceepttrcilmk  kSaeoWu"

    const/4 v5, 0x4

    const-string v3, " UseccketassoS uepoWetk rinnmrolhe c"

    const-string v3, "Unable to check WorkSource emptiness"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/google/android/gms/common/util/d0;->i(Landroid/os/WorkSource;)I

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-nez p0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 p0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    return p0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    return v1
.end method

.method public static i(Landroid/os/WorkSource;)I
    .locals 5
    .param p0    # Landroid/os/WorkSource;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v0, Lcom/google/android/gms/common/util/d0;->d:Ljava/lang/reflect/Method;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    new-array v2, v1, [Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x0

    check-cast p0, Ljava/lang/Integer;

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    return p0

    :catch_0
    move-exception p0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v0, "WlomuUoStkeroc"

    const-string/jumbo v0, "ueSlooctoWrkrU"

    const/4 v4, 0x6

    const-string v0, "UrceoWorloutkS"

    const-string v0, "WorkSourceUtil"

    const/4 v4, 0x1

    const-string/jumbo v2, "sWmbbboau b kaeecoetUSilshl  unhragoo rtg"

    const-string/jumbo v2, "ierSabeo Uograbe k  rchm nlutWulbotghsoas"

    const/4 v4, 0x0

    const-string v2, "S mgsruuenorlbhhao eaUtgba oets i uWocnlk"

    const-string v2, "Unable to assign blame through WorkSource"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v0, v2, p0}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    return v1
.end method
