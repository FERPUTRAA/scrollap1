.class public final synthetic Lcom/google/android/gms/common/util/f;
.super Ljava/lang/Object;


# direct methods
.method public static a(Lcom/google/android/gms/common/util/g;)J
    .locals 4
    .param p0    # Lcom/google/android/gms/common/util/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "b@s.~@ ~~o@@yr@@@  if@v~ u oc@~dfnl@o~~@i@@ ~~mo~4o~~@~~ ~ @1tsbbi~ o ~@ K@ @@a//~    ~lt @~SM-~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    invoke-static {}, Landroid/os/SystemClock;->currentThreadTimeMillis()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    return-wide v0
.end method
