.class public final Lcom/google/android/gms/common/util/i;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static final a:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v0, ".asvs"

    const-string v0, ".vsaa"

    const/4 v6, 0x0

    const-string/jumbo v0, "vjama"

    const-string/jumbo v0, "java."

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string v1, "aj.mav"

    const/4 v6, 0x2

    const-string v1, ".jxvoa"

    const-string/jumbo v1, "javax."

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v2, "d.doabor"

    const-string v2, ".aidodor"

    const/4 v6, 0x6

    const-string v2, "android."

    const/4 v6, 0x1

    const/4 v5, 0x7

    const-string/jumbo v3, "rmciaouo.bnd"

    const-string/jumbo v3, "i.oombacddnr"

    const/4 v6, 0x5

    const-string/jumbo v3, "o.onmi.prcdd"

    const-string v3, "com.android."

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v4, ".qvkuai"

    const-string v4, "akv.ilu"

    const/4 v6, 0x0

    const-string/jumbo v4, "l.siavd"

    const-string v4, "dalvik."

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    filled-new-array {v2, v3, v4, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    sput-object v0, Lcom/google/android/gms/common/util/i;->a:[Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/Throwable;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Throwable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string/jumbo p1, "hltUisapCs"

    const/4 v2, 0x4

    const-string/jumbo p1, "tsCmrlasih"

    const-string p1, "CrashUtils"

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string v0, " r coEingpDtpoBxr oooeeaion rxtddr"

    const-string/jumbo v0, "xetidD  qrper taxdBnr ooiEongrocop"

    const/4 v2, 0x4

    const-string/jumbo v0, "pooicbn!rox oriEtDrBotder  x pngad"

    const-string v0, "Error adding exception to DropBox!"

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-static {p1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p0
.end method
