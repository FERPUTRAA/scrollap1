.class public Lcom/google/android/gms/common/util/x;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static a:Ljava/lang/String;
    .annotation runtime Lv7/h;
    .end annotation
.end field

.field private static b:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public static a()Ljava/lang/String;
    .locals 7
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    sget-object v0, Lcom/google/android/gms/common/util/x;->a:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-nez v0, :cond_3

    const/4 v5, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/16 v1, 0x1c

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-lt v0, v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {}, Ly2/a;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    sput-object v0, Lcom/google/android/gms/common/util/x;->a:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto/16 :goto_3

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    sget v0, Lcom/google/android/gms/common/util/x;->b:I

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    sput v0, Lcom/google/android/gms/common/util/x;->b:I

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-gtz v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto/16 :goto_2

    :cond_2
    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const-string v3, "//spro"

    const-string/jumbo v3, "r/s/po"

    const/4 v6, 0x7

    const-string v3, "/ocm/r"

    const-string v3, "/proc/"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string/jumbo v0, "ilndomec"

    const-string v0, "/cemnldi"

    const-string v0, "dci/lbmn"

    const-string v0, "/cmdline"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {}, Landroid/os/StrictMode;->allowThreadDiskReads()Landroid/os/StrictMode$ThreadPolicy;

    move-result-object v2
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance v3, Ljava/io/BufferedReader;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance v4, Ljava/io/FileReader;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {v4, v0}, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v3, v4}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v2}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :try_start_3
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_1

    :catchall_0
    move-exception v0

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_0

    :catchall_1
    move-exception v0

    :try_start_4
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v2}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    throw v0
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    :catchall_2
    move-exception v0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v1}, Lcom/google/android/gms/common/util/q;->b(Ljava/io/Closeable;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    throw v0

    :catch_0
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :catch_1
    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v3}, Lcom/google/android/gms/common/util/q;->b(Ljava/io/Closeable;)V

    :goto_2
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    sput-object v1, Lcom/google/android/gms/common/util/x;->a:Ljava/lang/String;

    :cond_3
    :goto_3
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    sget-object v0, Lcom/google/android/gms/common/util/x;->a:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-object v0
.end method
