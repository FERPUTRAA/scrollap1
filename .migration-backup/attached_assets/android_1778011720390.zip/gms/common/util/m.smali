.class public final Lcom/google/android/gms/common/util/m;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field public static final a:I = 0x3e8fa0
    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final b:I = 0x419ce0
    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final c:I = 0x432380
    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final d:I = 0x4c4b40
    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final e:I = 0x5b8d80
    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final f:I = 0x6acfc0
    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final g:I = 0x6ddd00
    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final h:I = 0x7270e0
    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final i:I = 0x7704c0
    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final j:I = 0x7a1200
    .annotation build Lf4/a;
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public static a(I)Z
    .locals 3
    .annotation build Lf4/a;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const v0, 0x30d400

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-lt p0, v0, :cond_0

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return p0

    :cond_0
    const/4 v2, 0x1

    const/4 p0, 0x7

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p0
.end method
