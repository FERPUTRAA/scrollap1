.class final Lcom/google/android/gms/common/util/g0;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/util/regex/Pattern;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string v0, "9}s4a0/-usF[//f]/{-"

    const-string/jumbo v0, "}4s--]0//uA/a[/{f9F"

    const/4 v2, 0x4

    const-string v0, "/u}m/A]//-0-[4{fF-9"

    const-string v0, "\\\\u[0-9a-fA-F]{4}"

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/gms/common/util/g0;->a:Ljava/util/regex/Pattern;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~o@So~ nl~  ~y@ rt@ ~~@lf ~ @   @o@@M@o-@~b@d v @ao u~i~/ic@~ .K~@@i~~ @~/~@m~~bo~t4~  o@@bs~~1@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x6

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-nez v0, :cond_7

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    sget-object v0, Lcom/google/android/gms/common/util/g0;->a:Ljava/util/regex/Pattern;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v1, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 v2, 0x0

    :cond_0
    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz v3, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-nez v1, :cond_1

    const/4 v8, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->start()I

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    move v4, v3

    move v4, v3

    const/4 v8, 0x1

    move v4, v3

    move v4, v3

    :goto_1
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/16 v5, 0x5c

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-ltz v4, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-ne v6, v5, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    add-int/lit8 v4, v4, -0x1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    goto :goto_1

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    sub-int/2addr v3, v4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 v4, 0x2

    const/4 v8, 0x2

    rem-int/2addr v3, v4

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-eqz v3, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/16 v4, 0x10

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v3, v4}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->start()I

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v1, p0, v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-ne v3, v5, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string v2, "////"

    const-string v2, "////"

    const/4 v8, 0x3

    const-string v2, "////"

    const-string v2, "\\\\"

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    goto :goto_2

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {v3}, Ljava/lang/Character;->toChars(I)[C

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append([C)Ljava/lang/StringBuilder;

    :goto_2
    const/4 v8, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->end()I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    goto/16 :goto_0

    :cond_4
    const/4 v7, 0x6

    move v8, v7

    if-nez v1, :cond_5

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    goto :goto_3

    :cond_5
    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->regionEnd()I

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-ge v2, v3, :cond_6

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->regionEnd()I

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v1, p0, v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    :cond_6
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :cond_7
    :goto_3
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    return-object p0
.end method
