.class public final Lcom/google/android/gms/common/util/l;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static a:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static b:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static c:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static d:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static e:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static f:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static g:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static h:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static i:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static j:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static k:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static l:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static m:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private static n:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "b~s@  ~f  Ky@@@~~bo c@~m~ai/@o ~~@~@~@n-r~vs~~o o@~.~ S@4t  ~/lM@ @~ ~@@ l @~~to@~ui@o b~@df1@ i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v0, Lcom/google/android/gms/common/util/l;->j:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/android/gms/common/util/v;->n()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v0, "oeomae.nouiytvaatdpwies.radrhrm."

    const-string v0, ".osduoree.tarwaovead.radmhtipyin"

    const/4 v3, 0x4

    const-string/jumbo v0, "iedaotdamn.uehdwpertoi.oyaovarr."

    const-string v0, "android.hardware.type.automotive"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v1, 0x1

    move v3, v1

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    sput-object p0, Lcom/google/android/gms/common/util/l;->j:Ljava/lang/Boolean;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object p0, Lcom/google/android/gms/common/util/l;->j:Ljava/lang/Boolean;

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return p0
.end method

.method public static b(Landroid/content/Context;)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v0, Lcom/google/android/gms/common/util/l;->m:Ljava/lang/Boolean;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/android/gms/common/util/v;->q()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v0, "ngXtebafEIdcir.aeuo_.loECNgmeropaHE.ylP.odP.RE"

    const-string v0, "com.google.android.play.feature.HPE_EXPERIENCE"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    sput-object p0, Lcom/google/android/gms/common/util/l;->m:Ljava/lang/Boolean;

    :cond_1
    const/4 v2, 0x7

    move v3, v2

    sget-object p0, Lcom/google/android/gms/common/util/l;->m:Ljava/lang/Boolean;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return p0
.end method

.method public static c(Landroid/content/Context;)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v0, Lcom/google/android/gms/common/util/l;->c:Ljava/lang/Boolean;

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const-string/jumbo v0, "usmors"

    const-string/jumbo v0, "normss"

    const/4 v3, 0x5

    const-string/jumbo v0, "sensor"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast p0, Landroid/hardware/SensorManager;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {}, Lcom/google/android/gms/common/util/v;->q()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/16 v0, 0x24

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    sput-object p0, Lcom/google/android/gms/common/util/l;->c:Ljava/lang/Boolean;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object p0, Lcom/google/android/gms/common/util/l;->c:Ljava/lang/Boolean;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return p0
.end method

.method public static d(Landroid/content/Context;)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v0, Lcom/google/android/gms/common/util/l;->g:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v0, "en_l.rupmgcaiofu.vcsdreoodsea.teegodap.tiro"

    const-string/jumbo v0, "ug.aoor.seauvtdpciero_ie.lomdesra.ntrgefdco"

    const/4 v3, 0x4

    const-string v0, "ecorsalgqs.cmaiuoaeo_ugtrtdpd.eer.o.eenvrdi"

    const-string v0, "com.google.android.feature.services_updater"

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v0, "eesvicrs..gcosbolg"

    const-string/jumbo v0, "vn.sgbgceislce.roo"

    const/4 v3, 0x2

    const-string v0, ".vsm.goeirccgelseo"

    const-string v0, "cn.google.services"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    sput-object p0, Lcom/google/android/gms/common/util/l;->g:Ljava/lang/Boolean;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object p0, Lcom/google/android/gms/common/util/l;->g:Ljava/lang/Boolean;

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return p0
.end method

.method public static e(Landroid/content/Context;)Z
    .locals 6
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object v0, Lcom/google/android/gms/common/util/l;->a:Ljava/lang/Boolean;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v0, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->c(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez v0, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->h(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v0, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->l(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v0, :cond_2

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->p(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    sget-object v0, Lcom/google/android/gms/common/util/l;->i:Ljava/lang/Boolean;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v3, "gurhomacrooui.c."

    const-string/jumbo v3, "rcmia.ugrmuocho."

    const/4 v5, 0x1

    const-string/jumbo v3, "iargmbhurcco.m.r"

    const-string/jumbo v3, "org.chromium.arc"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v3}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    sput-object v0, Lcom/google/android/gms/common/util/l;->i:Ljava/lang/Boolean;

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v0, Lcom/google/android/gms/common/util/l;->i:Ljava/lang/Boolean;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->j(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez v0, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v0, Lcom/google/android/gms/common/util/l;->l:Ljava/lang/Boolean;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v3, "EgpRdMuae.uooIP.eloarAEonerXmENiEIgcfAd_.tC"

    const-string/jumbo v3, "rIcurompeClgeinNe.EdooA.dEo_.MtIPXEaagA.ERf"

    const/4 v5, 0x7

    const-string v3, "Aoaloe.pRdErIrIMiP.otA_NE.anEmXueceT.dfECgg"

    const-string v3, "com.google.android.feature.AMATI_EXPERIENCE"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v3}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    sput-object v0, Lcom/google/android/gms/common/util/l;->l:Ljava/lang/Boolean;

    :cond_1
    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object v0, Lcom/google/android/gms/common/util/l;->l:Ljava/lang/Boolean;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_2

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->b(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    if-nez v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->n(Landroid/content/Context;)Z

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-nez p0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    move v1, v2

    move v1, v2

    const/4 v5, 0x5

    move v1, v2

    move v1, v2

    :cond_3
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x5

    sput-object p0, Lcom/google/android/gms/common/util/l;->a:Ljava/lang/Boolean;

    :cond_4
    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    sget-object p0, Lcom/google/android/gms/common/util/l;->a:Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    return p0
.end method

.method public static f(Landroid/content/Context;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->q(Landroid/content/res/Resources;)Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p0
.end method

.method public static g(Landroid/content/Context;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->o(Landroid/content/Context;)Z

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p0
.end method

.method public static h(Landroid/content/Context;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->i(Landroid/content/res/Resources;)Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p0
.end method

.method public static i(Landroid/content/res/Resources;)Z
    .locals 6
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-nez p0, :cond_0

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    return v0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    sget-object v1, Lcom/google/android/gms/common/util/l;->b:Ljava/lang/Boolean;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget v1, v1, Landroid/content/res/Configuration;->screenLayout:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    and-int/lit8 v1, v1, 0xf

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v2, 0x3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v3, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-le v1, v2, :cond_1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    move v0, v3

    const/4 v5, 0x3

    move v0, v3

    move v0, v3

    const/4 v5, 0x2

    const/4 v4, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->q(Landroid/content/res/Resources;)Z

    move-result p0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz p0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    sput-object p0, Lcom/google/android/gms/common/util/l;->b:Ljava/lang/Boolean;

    :cond_3
    const/4 v5, 0x6

    sget-object p0, Lcom/google/android/gms/common/util/l;->b:Ljava/lang/Boolean;

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    return p0
.end method

.method public static j(Landroid/content/Context;)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Lcom/google/android/gms/common/util/l;->k:Ljava/lang/Boolean;

    const/4 v3, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v0, "ooqt.daoqvogegicln.mr"

    const-string/jumbo v0, "grva.cloqneo..dotmogi"

    const/4 v3, 0x3

    const-string/jumbo v0, "tdsmin.g..oegdoarvocl"

    const-string v0, "com.google.android.tv"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v0, "hwnmaite.evelrsnieadytrrdpaosoid"

    const-string/jumbo v0, "pyssdeodnetlirdneiva.reirho.awat"

    const/4 v3, 0x3

    const-string v0, ".inropi.rnywa.tserdhaadeoilevedo"

    const-string v0, "android.hardware.type.television"

    const/4 v2, 0x4

    or-int/2addr v3, v2

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x6

    move v3, v2

    const-string v0, "aiamdb.fnwroolrsbntakdc.e"

    const-string/jumbo v0, "obomctierfddwenrasla..ank"

    const-string/jumbo v0, "tnardaubanao.dcei.wrlesof"

    const-string v0, "android.software.leanback"

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    sput-object p0, Lcom/google/android/gms/common/util/l;->k:Ljava/lang/Boolean;

    :cond_2
    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object p0, Lcom/google/android/gms/common/util/l;->k:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    return p0
.end method

.method public static k()Z
    .locals 4
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget v0, Lcom/google/android/gms/common/k;->a:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo v0, "rsue"

    const-string/jumbo v0, "uers"

    const/4 v3, 0x5

    const-string/jumbo v0, "suer"

    const-string/jumbo v0, "user"

    const/4 v3, 0x4

    sget-object v1, Landroid/os/Build;->TYPE:Ljava/lang/String;

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v0
.end method

.method public static l(Landroid/content/Context;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x14
    .end annotation

    .annotation build Lcom/google/android/apps/common/proguard/SideEffectFree;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->r(Landroid/content/pm/PackageManager;)Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return p0
.end method

.method public static m(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1a
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->l(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/android/gms/common/util/v;->m()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    if-eqz v0, :cond_1

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/google/android/gms/common/util/l;->o(Landroid/content/Context;)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz p0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/android/gms/common/util/v;->n()Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz p0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/gms/common/util/v;->q()Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p0, :cond_2

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 p0, 0x1

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p0

    :cond_2
    const/4 v2, 0x6

    const/4 p0, 0x5

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return p0
.end method

.method public static n(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/gms/common/util/l;->n:Ljava/lang/Boolean;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string/jumbo v0, "oornrsdpi..mtixrw.dresavaeeif"

    const-string/jumbo v0, "oesaomriti.searxwfdmn..vrrdie"

    const/4 v2, 0x0

    const-string/jumbo v0, "vsixmrn.qoorw.dmdersaieeritfa"

    const-string v0, "android.software.xr.immersive"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    sput-object p0, Lcom/google/android/gms/common/util/l;->n:Ljava/lang/Boolean;

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object p0, Lcom/google/android/gms/common/util/l;->n:Ljava/lang/Boolean;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return p0
.end method

.method public static o(Landroid/content/Context;)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lcom/google/android/gms/common/util/l;->f:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/android/gms/common/util/v;->j()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string/jumbo v0, "gcsgoelb."

    const-string/jumbo v0, "lec.gbgno"

    const/4 v3, 0x0

    const-string/jumbo v0, "olgm.gonc"

    const-string v0, "cn.google"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    const/4 v1, 0x7

    const/4 v1, 0x1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    sput-object p0, Lcom/google/android/gms/common/util/l;->f:Ljava/lang/Boolean;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object p0, Lcom/google/android/gms/common/util/l;->f:Ljava/lang/Boolean;

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return p0
.end method

.method public static p(Landroid/content/Context;)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget-object v0, Lcom/google/android/gms/common/util/l;->h:Ljava/lang/Boolean;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v1, "onraoer.rtdiuaep.dhw.yiad"

    const-string/jumbo v1, "iatdhaur.re.da.yotrnewipd"

    const/4 v3, 0x1

    const-string/jumbo v1, "ta.a.btyipnddoridhoeewrra"

    const-string v1, "android.hardware.type.iot"

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v0, "herwtdbpr..aneedddaeapmedy.rdi"

    const/4 v3, 0x2

    const-string v0, "bdddeeumtiao.pedra.dr.eawrdyhe"

    const-string v0, "android.hardware.type.embedded"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x0

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-object p0, Lcom/google/android/gms/common/util/l;->h:Ljava/lang/Boolean;

    :cond_2
    const/4 v3, 0x2

    sget-object p0, Lcom/google/android/gms/common/util/l;->h:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return p0
.end method

.method public static q(Landroid/content/res/Resources;)Z
    .locals 5
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x5

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    sget-object v1, Lcom/google/android/gms/common/util/l;->d:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-nez v1, :cond_2

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v1, p0, Landroid/content/res/Configuration;->screenLayout:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    and-int/lit8 v1, v1, 0xf

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    or-int/2addr v4, v3

    if-gt v1, v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget p0, p0, Landroid/content/res/Configuration;->smallestScreenWidthDp:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/16 v1, 0x258

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-lt p0, v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v0, 0x1

    :cond_1
    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    sput-object p0, Lcom/google/android/gms/common/util/l;->d:Ljava/lang/Boolean;

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object p0, Lcom/google/android/gms/common/util/l;->d:Ljava/lang/Boolean;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    return p0
.end method

.method public static r(Landroid/content/pm/PackageManager;)Z
    .locals 4
    .param p0    # Landroid/content/pm/PackageManager;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x14
    .end annotation

    .annotation build Lcom/google/android/apps/common/proguard/SideEffectFree;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v0, Lcom/google/android/gms/common/util/l;->e:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/android/gms/common/util/v;->i()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo v0, "htwrqntpa.wehrdrdeaoiapc..y"

    const-string v0, "det.pacaqhyorrw.ndht.wriead"

    const/4 v3, 0x6

    const-string v0, "dahyiattqdwp.hordn.arcra.ee"

    const-string v0, "android.hardware.type.watch"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    sput-object p0, Lcom/google/android/gms/common/util/l;->e:Ljava/lang/Boolean;

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object p0, Lcom/google/android/gms/common/util/l;->e:Ljava/lang/Boolean;

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return p0
.end method
