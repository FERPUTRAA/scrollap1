.class public interface abstract Lcom/google/android/gms/common/util/g;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation build Lf4/a;
.end annotation


# virtual methods
.method public abstract a()J
    .annotation build Lf4/a;
    .end annotation
.end method

.method public abstract b()J
    .annotation build Lf4/a;
    .end annotation
.end method

.method public abstract c()J
    .annotation build Lf4/a;
    .end annotation
.end method

.method public abstract nanoTime()J
    .annotation build Lf4/a;
    .end annotation
.end method
