.class public Lcom/google/android/gms/common/util/b0;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static final a:Ljava/util/regex/Pattern;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string v0, "//s/})/?.(/s*{"

    const-string v0, "*/s//?//.)}(/{"

    const/4 v2, 0x7

    const-string v0, "/*{m$/?///.)(/"

    const-string v0, "\\$\\{(.*?)\\}"

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    sput-object v0, Lcom/google/android/gms/common/util/b0;->a:Ljava/util/regex/Pattern;

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const-string/jumbo v1, "~@s o@olm~o~y o~@i1~@~~-o  ~bK~ d@@ ~~f~@i b@~b@f~@~@~4@@@ ~itM n ~~~  S@rv@@a t~  @coo@@~ u l//"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p0, 0x0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public static b(Ljava/lang/String;)Z
    .locals 2
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Lq9/e;
        expression = {
            "#1"
        }
        result = false
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    if-eqz p0, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    if-eqz p0, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    const/4 p0, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return p0

    :cond_1
    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    const/4 p0, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    return p0
.end method
