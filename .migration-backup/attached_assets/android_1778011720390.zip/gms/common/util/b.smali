.class public final Lcom/google/android/gms/common/util/b;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public static varargs a([[Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 8
    .param p0    # [[Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([[TT;)[TT;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    array-length v0, p0

    const/4 v7, 0x1

    const/4 v1, 0x0

    const/4 v7, 0x6

    move v6, v1

    move v6, v1

    if-eqz v0, :cond_2

    move v0, v1

    move v0, v1

    const/4 v7, 0x5

    move v0, v1

    move v0, v1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    move v2, v0

    move v2, v0

    const/4 v7, 0x1

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    array-length v3, p0

    const/4 v7, 0x2

    const/4 v6, 0x7

    if-ge v0, v3, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    aget-object v3, p0, v0

    const/4 v6, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    array-length v3, v3

    const/4 v7, 0x7

    const/4 v6, 0x7

    add-int/2addr v2, v3

    const/4 v7, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    aget-object v0, p0, v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {v0, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    aget-object v2, p0, v1

    const/4 v7, 0x6

    array-length v2, v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v3, 0x1

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    array-length v4, p0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-ge v3, v4, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    aget-object v4, p0, v3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    array-length v5, v4

    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v4, v1, v0, v2, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    add-int/2addr v2, v5

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x0

    move v7, v6

    goto :goto_1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    return-object v0

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {p0, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    check-cast p0, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    return-object p0
.end method

.method public static varargs b([[B)[B
    .locals 8
    .param p0    # [[B
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    array-length v0, p0

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v0, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    move v0, v1

    move v0, v1

    const/4 v7, 0x6

    move v0, v1

    move v0, v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    move v2, v0

    move v2, v0

    const/4 v7, 0x5

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    array-length v3, p0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-ge v0, v3, :cond_0

    const/4 v6, 0x1

    move v7, v6

    aget-object v3, p0, v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    array-length v3, v3

    const/4 v7, 0x4

    const/4 v6, 0x7

    add-int/2addr v2, v3

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x3

    shr-int/2addr v7, v6

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    aget-object v0, p0, v1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v0, v2}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    aget-object v2, p0, v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    array-length v2, v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v3, 0x1

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    array-length v4, p0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-ge v3, v4, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    aget-object v4, p0, v3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    array-length v5, v4

    const/4 v7, 0x3

    const/4 v6, 0x4

    invoke-static {v4, v1, v0, v2, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    add-int/2addr v2, v5

    const/4 v7, 0x3

    const/4 v6, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    goto :goto_1

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    return-object v0

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    new-array p0, v1, [B

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    return-object p0
.end method

.method public static c([II)Z
    .locals 5
    .param p0    # [I
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz p0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    move v1, v0

    move v1, v0

    const/4 v4, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    array-length v2, p0

    const/4 v4, 0x1

    if-ge v1, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    aget v2, p0, v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-ne v2, p1, :cond_0

    const/4 v3, 0x4

    move v4, v3

    const/4 p0, 0x1

    move v4, p0

    const/4 v3, 0x4

    move v4, v3

    return p0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    return v0
.end method

.method public static d([Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 6
    .param p0    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;TT;)Z"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz p0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    array-length v1, p0

    const/4 v5, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    move v1, v0

    move v1, v0

    const/4 v5, 0x7

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    :goto_1
    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ge v2, v1, :cond_2

    const/4 v5, 0x2

    aget-object v3, p0, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v3, p1}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-ltz v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 p0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    return p0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_1

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    return v0
.end method

.method public static e()Ljava/util/ArrayList;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">()",
            "Ljava/util/ArrayList<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public static varargs f([Ljava/lang/Object;[Ljava/lang/Object;)[Ljava/lang/Object;
    .locals 10
    .param p0    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;[TT;)[TT;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v0, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-nez p0, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    return-object v0

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eqz p1, :cond_9

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    array-length v1, p1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-nez v1, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto/16 :goto_3

    :cond_1
    const/4 v8, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    array-length v3, p0

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v2}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v2

    const/4 v9, 0x5

    invoke-static {v2, v3}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    check-cast v2, [Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v4, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    const/4 v5, 0x1

    if-ne v1, v5, :cond_3

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    move v1, v4

    move v1, v4

    move v1, v4

    move v1, v4

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    move v5, v1

    move v5, v1

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-ge v1, v3, :cond_6

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    aget-object v6, p0, v1

    const/4 v8, 0x7

    move v9, v8

    aget-object v7, p1, v4

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {v7, v6}, Lcom/google/android/gms/common/internal/t;->b(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    if-nez v7, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    add-int/lit8 v7, v5, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    aput-object v6, v2, v5

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    move v5, v7

    const/4 v9, 0x6

    move v5, v7

    move v5, v7

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    goto :goto_0

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    move v1, v4

    move v1, v4

    const/4 v9, 0x6

    move v1, v4

    move v1, v4

    :goto_1
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-ge v4, v3, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    aget-object v5, p0, v4

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {p1, v5}, Lcom/google/android/gms/common/util/b;->d([Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-nez v6, :cond_4

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    add-int/lit8 v6, v1, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    aput-object v5, v2, v1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    move v1, v6

    move v1, v6

    const/4 v9, 0x1

    move v1, v6

    move v1, v6

    :cond_4
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x7

    goto :goto_1

    :cond_5
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    move v5, v1

    move v5, v1

    const/4 v9, 0x5

    move v5, v1

    move v5, v1

    :cond_6
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-nez v2, :cond_7

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_2

    :cond_7
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    array-length p0, v2

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-ne v5, p0, :cond_8

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_2
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    return-object v0

    :cond_8
    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {v2, v5}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    const/4 v9, 0x0

    return-object p0

    :cond_9
    :goto_3
    const/4 v8, 0x7

    const/4 v9, 0x6

    array-length p1, p0

    const/4 v9, 0x0

    invoke-static {p0, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    return-object p0
.end method

.method public static g([Ljava/lang/Object;)Ljava/util/ArrayList;
    .locals 6
    .param p0    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)",
            "Ljava/util/ArrayList<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    array-length v0, p0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v1, Ljava/util/ArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v5, 0x4

    if-ge v2, v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    aget-object v3, p0, v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-object v1
.end method

.method public static h(Ljava/util/Collection;)[I
    .locals 6
    .param p0    # Ljava/util/Collection;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "Ljava/lang/Integer;",
            ">;)[I"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x0

    and-int/2addr v5, v0

    const/4 v4, 0x4

    and-int/2addr v5, v4

    if-eqz p0, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_1

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {p0}, Ljava/util/Collection;->size()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-array v1, v1, [I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    check-cast v2, Ljava/lang/Integer;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    add-int/lit8 v3, v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    aput v2, v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    move v0, v3

    move v0, v3

    move v0, v3

    move v0, v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object v1

    :cond_2
    :goto_1
    const/4 v5, 0x2

    new-array p0, v0, [I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object p0
.end method

.method public static i([I)[Ljava/lang/Integer;
    .locals 6
    .param p0    # [I
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-nez p0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 p0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object p0

    :cond_0
    const/4 v5, 0x5

    array-length v0, p0

    const/4 v5, 0x3

    new-array v1, v0, [Ljava/lang/Integer;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-ge v2, v0, :cond_1

    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    aget v3, p0, v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    aput-object v3, v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object v1
.end method

.method public static j(Ljava/lang/StringBuilder;[D)V
    .locals 6
    .param p0    # Ljava/lang/StringBuilder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [D
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x0

    array-length v0, p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-ge v1, v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string v2, ","

    const-string v2, ","

    const/4 v5, 0x7

    const-string v2, ","

    const-string v2, ","

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    aget-wide v2, p1, v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void
.end method

.method public static k(Ljava/lang/StringBuilder;[F)V
    .locals 5
    .param p0    # Ljava/lang/StringBuilder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [F
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    array-length v0, p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-ge v1, v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string v2, ","

    const-string v2, ","

    const/4 v4, 0x0

    const-string v2, ","

    const-string v2, ","

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    aget v2, p1, v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method

.method public static l(Ljava/lang/StringBuilder;[I)V
    .locals 5
    .param p0    # Ljava/lang/StringBuilder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x2

    array-length v0, p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ge v1, v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v2, ","

    const-string v2, ","

    const/4 v4, 0x5

    const-string v2, ","

    const-string v2, ","

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    aget v2, p1, v1

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void
.end method

.method public static m(Ljava/lang/StringBuilder;[J)V
    .locals 6
    .param p0    # Ljava/lang/StringBuilder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [J
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    array-length v0, p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ge v1, v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string v2, ","

    const-string v2, ","

    const/4 v5, 0x3

    const-string v2, ","

    const-string v2, ","

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    aget-wide v2, p1, v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method

.method public static n(Ljava/lang/StringBuilder;[Ljava/lang/Object;)V
    .locals 5
    .param p0    # Ljava/lang/StringBuilder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/StringBuilder;",
            "[TT;)V"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    array-length v0, p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    if-ge v1, v0, :cond_1

    const/4 v3, 0x2

    move v4, v3

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string v2, ","

    const-string v2, ","

    const/4 v4, 0x7

    const-string v2, ","

    const-string v2, ","

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v4, 0x1

    aget-object v2, p1, v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void
.end method

.method public static o(Ljava/lang/StringBuilder;[Z)V
    .locals 5
    .param p0    # Ljava/lang/StringBuilder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [Z
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    array-length v0, p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x2

    move v4, v3

    if-ge v1, v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v2, ","

    const-string v2, ","

    const/4 v4, 0x7

    const-string v2, ","

    const/4 v4, 0x7

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    aget-boolean v2, p1, v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method public static p(Ljava/lang/StringBuilder;[Ljava/lang/String;)V
    .locals 6
    .param p0    # Ljava/lang/StringBuilder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    array-length v0, p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    if-ge v1, v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string v2, ","

    const-string v2, ","

    const/4 v5, 0x5

    const-string v2, ","

    const-string v2, ","

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v5, 0x1

    const-string v2, "//"

    const-string v2, "//"

    const/4 v5, 0x6

    const-string v2, "//"

    const-string v2, "\""

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v4, 0x3

    aget-object v3, p1, v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-void
.end method
