.class final Lcom/google/android/gms/common/util/concurrent/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final a:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/gms/common/util/concurrent/d;->a:Ljava/lang/Runnable;

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  s~ i@@M~a ~@f@d~~~@@~.  ~@~~@li@/K@o  ~@@~@f~b@~ 1 @~yooo@lb    ~~ t@~~4~nsr/@mt@o~~@Su- vb oc"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    iget-object v0, p0, Lcom/google/android/gms/common/util/concurrent/d;->a:Ljava/lang/Runnable;

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    const/4 v2, 0x0

    return-void
.end method
