.class public Lcom/google/android/gms/common/util/concurrent/b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/ThreadFactory;


# annotations
.annotation build Lf4/a;
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/util/concurrent/ThreadFactory;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Ljava/util/concurrent/Executors;->defaultThreadFactory()Ljava/util/concurrent/ThreadFactory;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/gms/common/util/concurrent/b;->b:Ljava/util/concurrent/ThreadFactory;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string v0, "e sl nte uuasmoslNbnm"

    const-string v0, "N s tlmlubsuoemantn e"

    const/4 v2, 0x2

    const-string v0, "Ntlmeoeusu   nmalnbt "

    const-string v0, "Name must not be null"

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/gms/common/util/concurrent/b;->a:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public final newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;
    .locals 4
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "b~@@obn@~~ @-~@~~@ 1c ~M~f  @K~o@a.s~~o   4@y~@~ur~ l@ ~ o~@@i ~  @ib/~oot@@~i/  ~@v @m~lf~oStd@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/gms/common/util/concurrent/d;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, p1, v1}, Lcom/google/android/gms/common/util/concurrent/d;-><init>(Ljava/lang/Runnable;I)V

    const/4 v2, 0x5

    move v3, v2

    iget-object p1, p0, Lcom/google/android/gms/common/util/concurrent/b;->b:Ljava/util/concurrent/ThreadFactory;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {p1, v0}, Ljava/util/concurrent/ThreadFactory;->newThread(Ljava/lang/Runnable;)Ljava/lang/Thread;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/gms/common/util/concurrent/b;->a:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v2, 0x0

    return-object p1
.end method
