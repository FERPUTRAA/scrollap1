.class public final Lcom/google/android/gms/common/util/v;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static a()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0xb
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public static b()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0xc
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public static c()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0xe
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public static d()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0xf
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    move v2, v1

    return v0
.end method

.method public static e()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0x10
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public static f()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0x11
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x2

    return v0
.end method

.method public static g()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0x12
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public static h()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0x13
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x1

    move v2, v0

    return v0
.end method

.method public static i()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0x14
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public static j()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0x15
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    return v0
.end method

.method public static k()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0x16
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v0, 0x1

    or-int/2addr v2, v0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public static l()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0x17
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public static m()Z
    .locals 4
    .annotation build Landroidx/annotation/k;
        api = 0x18
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/16 v1, 0x18

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v0
.end method

.method public static n()Z
    .locals 4
    .annotation build Landroidx/annotation/k;
        api = 0x1a
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 v1, 0x1a

    const/4 v2, 0x2

    move v3, v2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x4

    return v0
.end method

.method public static o()Z
    .locals 4
    .annotation build Landroidx/annotation/k;
        api = 0x1c
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/16 v1, 0x1c

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-lt v0, v1, :cond_0

    const/4 v0, 0x4

    const/4 v0, 0x7

    const/4 v0, 0x1

    move v3, v0

    const/4 v2, 0x3

    and-int/2addr v3, v2

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    return v0
.end method

.method public static p()Z
    .locals 4
    .annotation build Landroidx/annotation/k;
        api = 0x1d
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/16 v1, 0x1d

    const/4 v3, 0x7

    if-lt v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    return v0
.end method

.method public static q()Z
    .locals 4
    .annotation build Landroidx/annotation/k;
        api = 0x1e
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/16 v1, 0x1e

    const/4 v3, 0x5

    if-lt v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    return v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x4

    return v0
.end method

.method public static r()Z
    .locals 4
    .annotation build Landroidx/annotation/k;
        api = 0x1f
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/16 v1, 0x1f

    const/4 v3, 0x2

    const/4 v2, 0x2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v2, 0x6

    move v3, v2

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    return v0
.end method

.method public static s()Z
    .locals 4
    .annotation build Landroidx/annotation/k;
        api = 0x20
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/16 v1, 0x20

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-lt v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    return v0
.end method

.method public static t()Z
    .locals 4
    .annotation build Landroidx/annotation/k;
        api = 0x21
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/16 v1, 0x21

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    return v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v0
.end method

.method public static u()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0x21
        codename = "UpsideDownCake"
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/android/gms/common/util/v;->t()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    return v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {}, Landroidx/core/os/a;->l()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public static v()Z
    .locals 3
    .annotation build Landroidx/annotation/k;
        api = 0x22
        codename = "VanillaIceCream"
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/android/gms/common/util/v;->u()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {}, Landroidx/core/os/a;->isAtLeastV()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method
