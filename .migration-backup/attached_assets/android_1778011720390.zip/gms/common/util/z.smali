.class public final Lcom/google/android/gms/common/util/z;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Ljava/util/Set;)[Ljava/lang/String;
    .locals 5
    .param p0    # Ljava/util/Set;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Lcom/google/android/gms/common/api/Scope;",
            ">;)[",
            "Ljava/lang/String;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v0, "e sapus.// lbsonct ecl"

    const-string/jumbo v0, "t s//.ccplonaes elbu n"

    const/4 v4, 0x5

    const-string v0, " snmccl aben /p.oute/s"

    const-string/jumbo v0, "scopes can\'t be null."

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-array v1, v1, [Lcom/google/android/gms/common/api/Scope;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {p0, v1}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    check-cast p0, [Lcom/google/android/gms/common/api/Scope;

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-static {p0, v0}, Lcom/google/android/gms/common/internal/v;->s(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    array-length v0, p0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-array v0, v0, [Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    array-length v2, p0

    const/4 v4, 0x3

    if-ge v1, v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    aget-object v2, p0, v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v2}, Lcom/google/android/gms/common/api/Scope;->y2()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    aput-object v2, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    return-object v0
.end method
