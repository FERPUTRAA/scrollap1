.class public Lcom/google/android/gms/common/util/p;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static final a:Ljava/util/regex/Pattern;

.field private static final b:Ljava/util/regex/Pattern;

.field private static final c:Ljava/util/regex/Pattern;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, "?]s/0][$|d//]]/2d/dd50//0/)[00-[-2{5[2/?}][(4(0?/)53/-1?d-^2([|]|1|-.5/d4-)/"

    const-string v0, "^(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}$"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput-object v0, Lcom/google/android/gms/common/util/p;->a:Ljava/util/regex/Pattern;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string v0, "^,0mf9$}-f4]AF4-7}?a:{-(]a-91--,{1A[0[:{Fs"

    const-string v0, "-0s1:4Af9]F{]{0,4{-1-}a-?$,F-^)}[A9-7a[:(f"

    const/4 v2, 0x1

    const-string v0, "^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    sput-object v0, Lcom/google/android/gms/common/util/p;->b:Ljava/util/regex/Pattern;

    const/4 v1, 0x0

    move v2, v1

    const-string v0, "A4F:o),4-a]AF-):*-:{(?:[A1F{1-0?)]af(-?-}^,0F:4()$00,?]9m}({}?-A-9a][f?::-:([-f191f})-{-94[,a("

    const-string v0, "({9mA:-)9(4,4-0?{a-a-?*f(]A:-4-?:(?){-A,F[((0:4-$0-,[af9{f}:?)?--]})1-1}))[]FF}0A:^:fF1[91a:],"

    const/4 v2, 0x5

    const-string v0, "){}-9b:[(a[--)a-]:(9f?0:A?[fF::-*Ff1F*$[:9f-9,?{?]A0,--}-{(4a,?}(AA14(4])F))^}{-1?]:41-0:-,0a)"

    const-string v0, "^((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)::((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)$"

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    sput-object v0, Lcom/google/android/gms/common/util/p;->c:Ljava/util/regex/Pattern;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    return-void
.end method

.method public static a(Ljava/net/URI;Ljava/lang/String;)Ljava/util/Map;
    .locals 8
    .param p0    # Ljava/net/URI;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/net/URI;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0}, Ljava/net/URI;->getRawQuery()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz p0, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-lez v1, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    new-instance v0, Ljava/util/HashMap;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/16 v1, 0x3d

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v1}, Lcom/google/android/gms/internal/common/zzo;->zzb(C)Lcom/google/android/gms/internal/common/zzo;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v1}, Lcom/google/android/gms/internal/common/zzx;->zzc(Lcom/google/android/gms/internal/common/zzo;)Lcom/google/android/gms/internal/common/zzx;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/16 v2, 0x26

    const/4 v6, 0x4

    move v7, v6

    invoke-static {v2}, Lcom/google/android/gms/internal/common/zzo;->zzb(C)Lcom/google/android/gms/internal/common/zzo;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {v2}, Lcom/google/android/gms/internal/common/zzx;->zzc(Lcom/google/android/gms/internal/common/zzo;)Lcom/google/android/gms/internal/common/zzx;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v2}, Lcom/google/android/gms/internal/common/zzx;->zzb()Lcom/google/android/gms/internal/common/zzx;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v2, p0}, Lcom/google/android/gms/internal/common/zzx;->zzd(Ljava/lang/CharSequence;)Ljava/lang/Iterable;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v2, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    check-cast v2, Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v1, v2}, Lcom/google/android/gms/internal/common/zzx;->zzf(Ljava/lang/CharSequence;)Ljava/util/List;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-nez v3, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v4, 0x2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-gt v3, v4, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 v3, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    check-cast v3, Ljava/lang/String;

    const/4 v7, 0x6

    invoke-static {v3, p1}, Lcom/google/android/gms/common/util/p;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x1

    if-ne v5, v4, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v4, 0x1

    const/4 v7, 0x5

    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    check-cast v2, Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v2, p1}, Lcom/google/android/gms/common/util/p;->b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto :goto_1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v2, 0x0

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-interface {v0, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x1

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string/jumbo p1, "roebrmu aapat"

    const-string/jumbo p1, "rbrdoaem apat"

    const/4 v7, 0x4

    const-string p1, "a ptrerpaabde"

    const-string p1, "bad parameter"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    throw p0

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-object v0
.end method

.method private static b(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    if-nez p1, :cond_0

    :try_start_0
    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    const-string p1, "OS195-8-qb"

    const-string p1, "-58-1bI9OS"

    const-string p1, "9IsO88-15S"

    const-string p1, "ISO-8859-1"

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p0, p1}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0

    :catch_0
    move-exception p0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V

    const/4 v1, 0x5

    throw p1
.end method
