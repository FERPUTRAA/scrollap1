.class public final Lcom/google/android/gms/common/util/o;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    return-void
.end method

.method public static a([BIIZ)Ljava/lang/String;
    .locals 11
    .param p0    # [B
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v10, 0x6

    if-eqz p0, :cond_e

    const/4 v10, 0x1

    array-length v0, p0

    const/4 v10, 0x0

    if-eqz v0, :cond_e

    const/4 v10, 0x0

    if-ltz p1, :cond_e

    const/4 v10, 0x4

    if-lez p2, :cond_e

    const/4 v10, 0x0

    add-int v1, p1, p2

    const/4 v10, 0x2

    if-le v1, v0, :cond_0

    const/4 v10, 0x3

    goto/16 :goto_6

    :cond_0
    const/4 v10, 0x7

    if-eqz p3, :cond_1

    const/4 v10, 0x0

    const/16 v0, 0x4b

    const/4 v10, 0x5

    goto :goto_0

    :cond_1
    const/4 v10, 0x0

    const/16 v0, 0x39

    :goto_0
    const/4 v10, 0x5

    add-int/lit8 v1, p2, 0xf

    const/4 v10, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/16 v3, 0x10

    const/4 v10, 0x4

    div-int/2addr v1, v3

    const/4 v10, 0x2

    mul-int/2addr v0, v1

    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v10, 0x1

    const/4 v0, 0x0

    const/4 v10, 0x4

    move v1, p2

    move v1, p2

    move v1, p2

    move v1, p2

    const/4 v10, 0x3

    move v4, v0

    move v4, v0

    move v4, v0

    move v4, v0

    move v5, v4

    move v5, v4

    move v5, v4

    move v5, v4

    :goto_1
    const/4 v10, 0x7

    if-lez v1, :cond_d

    const/4 v10, 0x1

    const/16 v6, 0x8

    const/4 v10, 0x4

    const/4 v7, 0x1

    const/4 v10, 0x4

    if-nez v4, :cond_3

    const/4 v10, 0x2

    const/high16 v5, 0x10000

    const/4 v10, 0x6

    if-ge p2, v5, :cond_2

    const/4 v10, 0x0

    new-array v5, v7, [Ljava/lang/Object;

    const/4 v10, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v10, 0x6

    aput-object v8, v5, v0

    const/4 v10, 0x6

    const-string v8, "4ss%X"

    const-string v8, "4:sX%"

    const-string v8, "%04X:"

    invoke-static {v8, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x1

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    goto :goto_2

    :cond_2
    const/4 v10, 0x2

    new-array v5, v7, [Ljava/lang/Object;

    const/4 v10, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v10, 0x1

    aput-object v8, v5, v0

    const/4 v10, 0x4

    const-string/jumbo v8, "mX:m8"

    const-string v8, "%:Xm8"

    const-string v8, "08%:o"

    const-string v8, "%08X:"

    const/4 v10, 0x1

    invoke-static {v8, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x6

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_2
    const/4 v10, 0x6

    move v5, p1

    move v5, p1

    move v5, p1

    move v5, p1

    const/4 v10, 0x1

    goto :goto_3

    :cond_3
    const/4 v10, 0x5

    if-ne v4, v6, :cond_4

    const/4 v10, 0x5

    const-string v8, "- "

    const-string v8, " -"

    const-string v8, " -"

    const-string v8, " -"

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_4
    :goto_3
    new-array v7, v7, [Ljava/lang/Object;

    const/4 v10, 0x5

    aget-byte v8, p0, p1

    const/4 v10, 0x3

    and-int/lit16 v8, v8, 0xff

    const/4 v10, 0x5

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v10, 0x5

    aput-object v8, v7, v0

    const/4 v10, 0x5

    const-string v8, "b %oX"

    const-string v8, "2% Xo"

    const-string v8, "%u0X "

    const-string v8, " %02X"

    const/4 v10, 0x3

    invoke-static {v8, v7}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x3

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    add-int/lit8 v1, v1, -0x1

    const/4 v10, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x0

    if-eqz p3, :cond_a

    const/4 v10, 0x4

    if-eq v4, v3, :cond_5

    if-nez v1, :cond_a

    :cond_5
    const/4 v10, 0x5

    rsub-int/lit8 v7, v4, 0x10

    if-lez v7, :cond_6

    const/4 v10, 0x5

    move v8, v0

    :goto_4
    const/4 v10, 0x0

    if-ge v8, v7, :cond_6

    const/4 v10, 0x3

    const-string v9, "   "

    const-string v9, "   "

    const-string v9, "   "

    const-string v9, "   "

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    add-int/lit8 v8, v8, 0x1

    const/4 v10, 0x6

    goto :goto_4

    :cond_6
    const/4 v10, 0x7

    const-string v8, "  "

    const-string v8, "  "

    const-string v8, "  "

    const-string v8, "  "

    const/4 v10, 0x7

    if-lt v7, v6, :cond_7

    const/4 v10, 0x0

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_7
    const/4 v10, 0x6

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    move v6, v0

    move v6, v0

    move v6, v0

    move v6, v0

    :goto_5
    const/4 v10, 0x1

    if-ge v6, v4, :cond_a

    const/4 v10, 0x7

    add-int v7, v5, v6

    const/4 v10, 0x5

    aget-byte v7, p0, v7

    const/4 v10, 0x2

    int-to-char v7, v7

    const/16 v8, 0x20

    const/4 v10, 0x4

    const/16 v9, 0x2e

    const/4 v10, 0x0

    if-lt v7, v8, :cond_8

    const/4 v10, 0x4

    const/16 v8, 0x7e

    const/4 v10, 0x3

    if-le v7, v8, :cond_9

    :cond_8
    const/4 v10, 0x2

    move v7, v9

    move v7, v9

    move v7, v9

    move v7, v9

    :cond_9
    const/4 v10, 0x4

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    add-int/lit8 v6, v6, 0x1

    const/4 v10, 0x6

    goto :goto_5

    :cond_a
    const/4 v10, 0x6

    if-eq v4, v3, :cond_b

    const/4 v10, 0x7

    if-nez v1, :cond_c

    :cond_b
    const/16 v4, 0xa

    const/4 v10, 0x3

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    move v4, v0

    move v4, v0

    move v4, v0

    move v4, v0

    :cond_c
    const/4 v10, 0x4

    add-int/lit8 p1, p1, 0x1

    const/4 v10, 0x5

    goto/16 :goto_1

    :cond_d
    const/4 v10, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x4

    return-object p0

    :cond_e
    :goto_6
    const/4 v10, 0x5

    const/4 p0, 0x0

    const/4 v10, 0x0

    return-object p0
.end method
