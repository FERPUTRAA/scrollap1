.class public Lcom/google/android/gms/common/util/n;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation build Lf4/a;
.end annotation


# static fields
.field private static final a:[C

.field private static final b:[C


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/16 v0, 0x10

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-array v1, v0, [C

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    fill-array-data v1, :array_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    sput-object v1, Lcom/google/android/gms/common/util/n;->a:[C

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-array v0, v0, [C

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    fill-array-data v0, :array_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    sput-object v0, Lcom/google/android/gms/common/util/n;->b:[C

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void

    nop

    :array_0
    .array-data 2
        0x30s
        0x31s
        0x32s
        0x33s
        0x34s
        0x35s
        0x36s
        0x37s
        0x38s
        0x39s
        0x41s
        0x42s
        0x43s
        0x44s
        0x45s
        0x46s
    .end array-data

    :array_1
    .array-data 2
        0x30s
        0x31s
        0x32s
        0x33s
        0x34s
        0x35s
        0x36s
        0x37s
        0x38s
        0x39s
        0x61s
        0x62s
        0x63s
        0x64s
        0x65s
        0x66s
    .end array-data
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public static a([B)Ljava/lang/String;
    .locals 9
    .param p0    # [B
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    array-length v0, p0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    add-int/2addr v0, v0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    new-array v0, v0, [C

    const/4 v8, 0x2

    const/4 v1, 0x0

    const/4 v8, 0x4

    and-int/2addr v7, v1

    const/4 v8, 0x6

    move v2, v1

    move v2, v1

    const/4 v8, 0x1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    array-length v3, p0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-ge v1, v3, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    aget-byte v3, p0, v1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    and-int/lit16 v3, v3, 0xff

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    add-int/lit8 v4, v2, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    sget-object v5, Lcom/google/android/gms/common/util/n;->b:[C

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    ushr-int/lit8 v6, v3, 0x4

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    aget-char v6, v5, v6

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    aput-char v6, v0, v2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    and-int/lit8 v2, v3, 0xf

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    aget-char v2, v5, v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    aput-char v2, v0, v4

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    add-int/lit8 v2, v4, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x3

    shr-int/2addr v8, v7

    goto :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    new-instance p0, Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {p0, v0}, Ljava/lang/String;-><init>([C)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    return-object p0
.end method

.method public static b([B)Ljava/lang/String;
    .locals 3
    .param p0    # [B
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/google/android/gms/common/util/n;->c([BZ)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public static c([BZ)Ljava/lang/String;
    .locals 7
    .param p0    # [B
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x0

    array-length v0, p0

    const/4 v6, 0x5

    const/4 v5, 0x3

    add-int v1, v0, v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v5, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-ge v1, v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz p1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    add-int/lit8 v3, v0, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-ne v1, v3, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    aget-byte v3, p0, v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v3, :cond_1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    sget-object v3, Lcom/google/android/gms/common/util/n;->a:[C

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    aget-byte v4, p0, v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    and-int/lit16 v4, v4, 0xf0

    const/4 v5, 0x0

    move v6, v5

    ushr-int/lit8 v4, v4, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    aget-char v4, v3, v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    aget-byte v4, p0, v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    and-int/lit8 v4, v4, 0xf

    const/4 v5, 0x6

    or-int/2addr v6, v5

    aget-char v3, v3, v4

    const/4 v6, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-object p0
.end method

.method public static d(Ljava/lang/String;)[B
    .locals 8
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    rem-int/lit8 v1, v0, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-nez v1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    div-int/lit8 v1, v0, 0x2

    const/4 v7, 0x0

    new-array v1, v1, [B

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-ge v2, v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    div-int/lit8 v3, v2, 0x2

    const/4 v7, 0x5

    add-int/lit8 v4, v2, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p0, v2, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/16 v5, 0x10

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v2, v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;I)I

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    int-to-byte v2, v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    aput-byte v2, v1, v3

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    move v2, v4

    move v2, v4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-object v1

    :cond_1
    const/4 v6, 0x5

    move v7, v6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string/jumbo v0, "s sirrueo nca xrgonhmat Hs  edssacdfbre"

    const-string v0, "aassco rH ndgdcerx srt tbmi res ouafneh"

    const/4 v7, 0x4

    const-string v0, "Hex string has odd number of characters"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    throw p0
.end method
