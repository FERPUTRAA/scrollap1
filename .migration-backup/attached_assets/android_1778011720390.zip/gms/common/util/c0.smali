.class public final Lcom/google/android/gms/common/util/c0;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Landroid/content/Context;I)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s~@@f~~  @~@ft4 @~r 1@ lK~/v o d-~@~~ob@s @ tloma~@ iou~.i~b~ @@ M~~ oy @~o@  S@@/~ @@bc~n~~i@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    const-string/jumbo v0, "rosmogco.ed.lism.ggmoa"

    const-string/jumbo v0, "o.sodmoglrgsad..ociegm"

    const/4 v3, 0x2

    const-string/jumbo v0, "nroso.coo.ed.odliaggmg"

    const-string v0, "com.google.android.gms"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p0, p1, v0}, Lcom/google/android/gms/common/util/c0;->b(Landroid/content/Context;ILjava/lang/String;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-nez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/16 v1, 0x40

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p1
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/google/android/gms/common/l;->a(Landroid/content/Context;)Lcom/google/android/gms/common/l;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/gms/common/l;->b(Landroid/content/pm/PackageInfo;)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    return p0

    :catch_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 p0, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo p1, "ireUibmdref"

    const-string p1, "erimrUfedii"

    const/4 v3, 0x0

    const-string/jumbo p1, "ierdriuUieV"

    const-string p1, "UidVerifier"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p1, p0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz p0, :cond_1

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string p0, " pfastspr n s  ga/elg veceoggcofnaarokt imelacdaeigayil nuPekge lacnp o,ea/tf"

    const-string/jumbo p0, "laaioslgekg sekanrsc aogeaae vafea prlmcgepaftgi oa  Pn fcyt gln/ocind/t,e ue"

    const/4 v3, 0x3

    const-string p0, "ef op  cqaf/  nPodier,e oe/mrtssgup caasygdanaletget glngc aeaaigcknakeflv ai"

    const-string p0, "Package manager can\'t find google play services package, defaulting to false"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    return p0
.end method

.method public static b(Landroid/content/Context;ILjava/lang/String;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x13
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/google/android/gms/common/wrappers/d;->a(Landroid/content/Context;)Lcom/google/android/gms/common/wrappers/c;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/android/gms/common/wrappers/c;->h(ILjava/lang/String;)Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return p0
.end method
