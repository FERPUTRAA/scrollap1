.class public final Lcom/google/android/gms/common/util/h;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    const/4 v0, 0x1

    return-void
.end method

.method public static a(Ljava/util/Collection;)Z
    .locals 2
    .param p0    # Ljava/util/Collection;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "*>;)Z"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    if-nez p0, :cond_0

    const/4 v0, 0x1

    move v1, v0

    const/4 p0, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    return p0

    :cond_0
    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p0
.end method

.method public static b()Ljava/util/List;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">()",
            "Ljava/util/List<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/l;
        imports = {
            "java.util.Collections"
        }
        replacement = "Collections.emptyList()"
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static c(Ljava/lang/Object;)Ljava/util/List;
    .locals 2
    .param p0    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;)",
            "Ljava/util/List<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .annotation build Ly4/l;
        imports = {
            "java.util.Collections"
        }
        replacement = "Collections.singletonList(item)"
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method public static varargs d([Ljava/lang/Object;)Ljava/util/List;
    .locals 4
    .param p0    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)",
            "Ljava/util/List<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    array-length v0, p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eq v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    aget-object p0, p0, v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p0
.end method

.method public static e(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(TK;TV;TK;TV;TK;TV;)",
            "Ljava/util/Map<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/google/android/gms/common/util/h;->k(IZ)Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {v0, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    invoke-interface {v0, p4, p5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p0
.end method

.method public static f(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;
    .locals 3
    .param p0    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p6    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p7    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p8    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p9    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p10    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p11    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(TK;TV;TK;TV;TK;TV;TK;TV;TK;TV;TK;TV;)",
            "Ljava/util/Map<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x0

    const/4 v0, 0x6

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0, v1}, Lcom/google/android/gms/common/util/h;->k(IZ)Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x6

    invoke-interface {v0, p0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-interface {v0, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-interface {v0, p4, p5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    invoke-interface {v0, p6, p7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-interface {v0, p8, p9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    invoke-interface {v0, p10, p11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    const/4 v2, 0x7

    return-object p0
.end method

.method public static g([Ljava/lang/Object;[Ljava/lang/Object;)Ljava/util/Map;
    .locals 6
    .param p0    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">([TK;[TV;)",
            "Ljava/util/Map<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    array-length v0, p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    array-length v1, p1

    if-ne v0, v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x0

    const/4 v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eq v0, v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0, v2}, Lcom/google/android/gms/common/util/h;->k(IZ)Ljava/util/Map;

    move-result-object v0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    array-length v1, p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-ge v2, v1, :cond_0

    const/4 v5, 0x4

    aget-object v1, p0, v2

    const/4 v4, 0x6

    xor-int/2addr v5, v4

    aget-object v3, p1, v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {v0, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-object p0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    aget-object p0, p0, v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    aget-object p1, p1, v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p0, p1}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x1

    return-object p0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-object p0

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string v2, "doshlrKy l nn lu stav usrena:ateeeq a ag"

    const-string v2, "Key and values array lengths not equal: "

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v0, " = !"

    const-string v0, "=!  "

    const/4 v5, 0x4

    const-string v0, "! = "

    const-string v0, " != "

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    throw p0
.end method

.method public static h(I)Ljava/util/Set;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(I)",
            "Ljava/util/Set<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance p0, Landroidx/collection/c;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0}, Landroidx/collection/c;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x0

    move v2, v1

    invoke-static {p0, v0}, Lcom/google/android/gms/common/util/h;->l(IZ)Ljava/util/Set;

    move-result-object p0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public static i(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;
    .locals 4
    .param p0    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;TT;TT;)",
            "Ljava/util/Set<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/google/android/gms/common/util/h;->l(IZ)Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {v0, p0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {v0, p2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0
.end method

.method public static varargs j([Ljava/lang/Object;)Ljava/util/Set;
    .locals 8
    .param p0    # [Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)",
            "Ljava/util/Set<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    array-length v0, p0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v0, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v2, 0x0

    const/4 v7, 0x6

    if-eq v0, v1, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v3, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eq v0, v3, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v4, 0x3

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eq v0, v4, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v5, 0x4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eq v0, v5, :cond_0

    const/4 v7, 0x7

    invoke-static {v0, v2}, Lcom/google/android/gms/common/util/h;->l(IZ)Ljava/util/Set;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    invoke-static {v0, p0}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-object p0

    :cond_0
    const/4 v6, 0x1

    aget-object v0, p0, v2

    const/4 v6, 0x3

    move v7, v6

    aget-object v1, p0, v1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    aget-object v3, p0, v3

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    aget-object p0, p0, v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v5, v2}, Lcom/google/android/gms/common/util/h;->l(IZ)Ljava/util/Set;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-interface {v2, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-interface {v2, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    invoke-interface {v2, v3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-interface {v2, p0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-object p0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    aget-object v0, p0, v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    aget-object v1, p0, v1

    const/4 v7, 0x1

    const/4 v6, 0x7

    aget-object p0, p0, v3

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v0, v1, p0}, Lcom/google/android/gms/common/util/h;->i(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    return-object p0

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    aget-object v0, p0, v2

    const/4 v7, 0x4

    const/4 v6, 0x4

    aget-object p0, p0, v1

    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v3, v2}, Lcom/google/android/gms/common/util/h;->l(IZ)Ljava/util/Set;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-interface {v1, p0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableSet(Ljava/util/Set;)Ljava/util/Set;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    return-object p0

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    aget-object p0, p0, v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {p0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    return-object p0

    :cond_4
    const/4 v7, 0x7

    invoke-static {}, Ljava/util/Collections;->emptySet()Ljava/util/Set;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-object p0
.end method

.method private static k(IZ)Ljava/util/Map;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/16 p1, 0x100

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-gt p0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance p1, Landroidx/collection/a;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p1, p0}, Landroidx/collection/a;-><init>(I)V

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-instance p1, Ljava/util/HashMap;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p1, p0, v0}, Ljava/util/HashMap;-><init>(IF)V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p1
.end method

.method private static l(IZ)Ljava/util/Set;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eq v0, p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/16 v1, 0x100

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/16 v1, 0x80

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    if-gt p0, v1, :cond_1

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance p1, Landroidx/collection/c;

    const/4 v3, 0x3

    invoke-direct {p1, p0}, Landroidx/collection/c;-><init>(I)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_2

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eq v0, p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/high16 p1, 0x3f800000    # 1.0f

    const/4 v3, 0x0

    goto :goto_1

    :cond_2
    const/4 v2, 0x7

    const/4 v3, 0x7

    const/high16 p1, 0x3f400000    # 0.75f

    :goto_1
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance v0, Ljava/util/HashSet;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0, p0, p1}, Ljava/util/HashSet;-><init>(IF)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_2
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p1
.end method
