.class public final Lcom/google/android/gms/common/util/q;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/google/android/gms/common/internal/z;
.end annotation

.annotation build Lf4/a;
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Landroid/os/ParcelFileDescriptor;)V
    .locals 2
    .param p0    # Landroid/os/ParcelFileDescriptor;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " os@tl~ uo~ y@b~~@~ d  s~c.~@o~it@r~b~~@~1@n~@~K~of~@ @ ~@v~m Mi@@o/S  ~a/@ @@ @ oi4@@-  f~ ~bl@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public static b(Ljava/io/Closeable;)V
    .locals 2
    .param p0    # Ljava/io/Closeable;
        .annotation runtime Lv7/h;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-interface {p0}, Ljava/io/Closeable;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public static c(Ljava/io/InputStream;Ljava/io/OutputStream;)J
    .locals 4
    .param p0    # Ljava/io/InputStream;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/io/OutputStream;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/16 v1, 0x400

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p0, p1, v0, v1}, Lcom/google/android/gms/common/util/q;->d(Ljava/io/InputStream;Ljava/io/OutputStream;ZI)J

    move-result-wide p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-wide p0
.end method

.method public static d(Ljava/io/InputStream;Ljava/io/OutputStream;ZI)J
    .locals 9
    .param p0    # Ljava/io/InputStream;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/io/OutputStream;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    new-array v0, p3, [B

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v8, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    :goto_0
    const/4 v8, 0x5

    const/4 v3, 0x0

    :try_start_0
    const/4 v8, 0x2

    invoke-virtual {p0, v0, v3, p3}, Ljava/io/InputStream;->read([BII)I

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/4 v5, -0x1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-eq v4, v5, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    int-to-long v5, v4

    const/4 v8, 0x6

    add-long/2addr v1, v5

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p1, v0, v3, v4}, Ljava/io/OutputStream;->write([BII)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz p2, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {p0}, Lcom/google/android/gms/common/util/q;->b(Ljava/io/Closeable;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {p1}, Lcom/google/android/gms/common/util/q;->b(Ljava/io/Closeable;)V

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    return-wide v1

    :catchall_0
    move-exception p3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-nez p2, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto :goto_1

    :cond_2
    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {p0}, Lcom/google/android/gms/common/util/q;->b(Ljava/io/Closeable;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {p1}, Lcom/google/android/gms/common/util/q;->b(Ljava/io/Closeable;)V

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    throw p3
.end method

.method public static e([B)Z
    .locals 5
    .param p0    # [B
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    array-length v0, p0

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x1

    and-int/2addr v3, v1

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x0

    and-int/2addr v3, v2

    if-le v0, v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    aget-byte v0, p0, v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    and-int/lit16 v0, v0, 0xff

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    aget-byte p0, p0, v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    and-int/lit16 p0, p0, 0xff

    const/4 v4, 0x3

    const/4 v3, 0x1

    shl-int/lit8 p0, p0, 0x8

    const/4 v3, 0x4

    const/4 v4, 0x3

    or-int/2addr p0, v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const v0, 0x8b1f

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-ne p0, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    return v2

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    return v1
.end method

.method public static f(Ljava/io/InputStream;)[B
    .locals 3
    .param p0    # Ljava/io/InputStream;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lcom/google/android/gms/common/util/q;->g(Ljava/io/InputStream;Z)[B

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0
.end method

.method public static g(Ljava/io/InputStream;Z)[B
    .locals 4
    .param p0    # Ljava/io/InputStream;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/16 v1, 0x400

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, v0, p1, v1}, Lcom/google/android/gms/common/util/q;->d(Ljava/io/InputStream;Ljava/io/OutputStream;ZI)J

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p0
.end method

.method public static h(Ljava/io/InputStream;)[B
    .locals 6
    .param p0    # Ljava/io/InputStream;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/16 v1, 0x1000

    const/4 v5, 0x5

    new-array v1, v1, [B

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v3, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-ne v2, v3, :cond_0

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-object p0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v3, v2}, Ljava/io/OutputStream;->write([BII)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0
.end method
