.class public final Lcom/google/android/gms/common/util/e0;
.super Ljava/lang/Object;


# direct methods
.method public static a(I)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @su~@nt~t/s @o~ @ ldr~ib@ ~1@ m@a yv S ~b~ M@.@ ~@i  @o~of~~@l@ ~ @~@-@o@~~ @~b@c~@~iK4~~~ fo/o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-ne p0, v0, :cond_0

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    div-int/lit16 p0, p0, 0x3e8

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return p0
.end method
