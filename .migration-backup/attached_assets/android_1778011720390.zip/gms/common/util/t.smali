.class public Lcom/google/android/gms/common/util/t;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method

.method public static a([BIII)I
    .locals 9
    .param p0    # [B
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "v~s @~~i/.~~@@lM@ b@~di~o~o@s@ r~   alt @@1~c@u b ~@~-m ~@o ~@yb / @~~@~Ko@@~~4@~oS~@~fn@f   oti"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x2

    move v0, p1

    move v0, p1

    const/4 v8, 0x3

    move v0, p1

    move v0, p1

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    and-int/lit8 v1, p2, -0x4

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    add-int/2addr v1, p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    const v2, 0x1b873593

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    const v3, -0x3361d2af    # -8.2930312E7f

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-ge v0, v1, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    aget-byte v1, p0, v0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    and-int/lit16 v1, v1, 0xff

    const/4 v8, 0x6

    add-int/lit8 v4, v0, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    aget-byte v4, p0, v4

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    and-int/lit16 v4, v4, 0xff

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    shl-int/lit8 v4, v4, 0x8

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    add-int/lit8 v5, v0, 0x2

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    aget-byte v5, p0, v5

    const/4 v8, 0x7

    const/4 v7, 0x7

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x4

    const/4 v7, 0x2

    shl-int/lit8 v5, v5, 0x10

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    add-int/lit8 v6, v0, 0x3

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    aget-byte v6, p0, v6

    const/4 v8, 0x6

    const/4 v7, 0x2

    shl-int/lit8 v6, v6, 0x18

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    or-int/2addr v1, v4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    or-int/2addr v1, v5

    const/4 v7, 0x1

    xor-int/2addr v8, v7

    or-int/2addr v1, v6

    const/4 v8, 0x1

    mul-int/2addr v1, v3

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    shl-int/lit8 v3, v1, 0xf

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    ushr-int/lit8 v1, v1, 0x11

    or-int/2addr v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x4

    mul-int/2addr v1, v2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    xor-int/2addr p3, v1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    shl-int/lit8 v1, p3, 0xd

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    ushr-int/lit8 p3, p3, 0x13

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    or-int/2addr p3, v1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    mul-int/lit8 p3, p3, 0x5

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    const v1, -0x19ab949c

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    add-int/2addr p3, v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    add-int/lit8 v0, v0, 0x4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    goto/16 :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    and-int/lit8 p1, p2, 0x3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/4 v0, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v4, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eq p1, v4, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v4, 0x2

    const/4 v7, 0x5

    move v8, v7

    if-eq p1, v4, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v0, 0x3

    const/4 v8, 0x4

    if-eq p1, v0, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    goto :goto_1

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x3

    add-int/lit8 p1, v1, 0x2

    const/4 v7, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    aget-byte p1, p0, p1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    and-int/lit16 p1, p1, 0xff

    const/4 v8, 0x4

    shl-int/lit8 v0, p1, 0x10

    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    add-int/lit8 p1, v1, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    aget-byte p1, p0, p1

    and-int/lit16 p1, p1, 0xff

    const/4 v8, 0x7

    shl-int/lit8 p1, p1, 0x8

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    or-int/2addr v0, p1

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    aget-byte p0, p0, v1

    const/4 v7, 0x3

    move v8, v7

    and-int/lit16 p0, p0, 0xff

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    or-int/2addr p0, v0

    const/4 v7, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    mul-int/2addr p0, v3

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    shl-int/lit8 p1, p0, 0xf

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    ushr-int/lit8 p0, p0, 0x11

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    or-int/2addr p0, p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    mul-int/2addr p0, v2

    const/4 v7, 0x3

    move v8, v7

    xor-int/2addr p3, p0

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    xor-int p0, p3, p2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    ushr-int/lit8 p1, p0, 0x10

    const/4 v7, 0x6

    move v8, v7

    xor-int/2addr p0, p1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    const p1, -0x7a143595

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    mul-int/2addr p0, p1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    ushr-int/lit8 p1, p0, 0xd

    const/4 v8, 0x3

    xor-int/2addr p0, p1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    const p1, -0x3d4d51cb

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    mul-int/2addr p0, p1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    ushr-int/lit8 p1, p0, 0x10

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    xor-int/2addr p0, p1

    const/4 v8, 0x0

    return p0
.end method
