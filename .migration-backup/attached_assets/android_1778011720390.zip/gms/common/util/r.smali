.class public final Lcom/google/android/gms/common/util/r;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field private static final a:Ljava/util/regex/Pattern;

.field private static final b:Ljava/util/regex/Pattern;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string v0, "//s./"

    const/4 v2, 0x1

    const-string v0, "\\\\."

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    sput-object v0, Lcom/google/android/gms/common/util/r;->a:Ljava/util/regex/Pattern;

    const/4 v2, 0x1

    const-string v0, "0ust/////c080/[0n/]/0m//ur/"

    const-string v0, "0/0m[nt8//0//u/c//0/0///r]u"

    const/4 v2, 0x3

    const-string/jumbo v0, "u//m80/[/00/r0uc//n0/0/t///"

    const-string v0, "[\\\\\"/\u0008\u000c\n\r\t]"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    sput-object v0, Lcom/google/android/gms/common/util/r;->b:Ljava/util/regex/Pattern;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static a(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 7
    .param p0    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~@bdo@@~-~~ M~@/ @ /so~ m4~tb @S@~u~ ~~f @y @@~ i @o@  i ~~ tollo@@@@@Kof@1~~rac @ ~~~b@ ~~vno~i"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    const/4 v0, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-nez p0, :cond_1

    const/4 v5, 0x5

    shr-int/2addr v6, v5

    if-eqz p1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    return v0

    :cond_1
    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x3

    if-eqz p0, :cond_c

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-nez p1, :cond_2

    const/4 v5, 0x6

    shr-int/2addr v6, v5

    goto/16 :goto_2

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    instance-of v2, p0, Lorg/json/JSONObject;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v2, :cond_7

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    instance-of v2, p1, Lorg/json/JSONObject;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v2, :cond_7

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast p0, Lorg/json/JSONObject;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    check-cast p1, Lorg/json/JSONObject;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0}, Lorg/json/JSONObject;->length()I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1}, Lorg/json/JSONObject;->length()I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eq v2, v3, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    return v1

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p0}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v2

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v3, :cond_6

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    check-cast v3, Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p1, v3}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-nez v4, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x4

    return v1

    :cond_5
    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v3}, Lcom/google/android/gms/common/internal/v;->r(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p0, v3}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p1, v3}, Lorg/json/JSONObject;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {v4, v3}, Lcom/google/android/gms/common/util/r;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v3, :cond_4

    :catch_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    return v1

    :cond_6
    const/4 v6, 0x2

    const/4 v5, 0x7

    return v0

    :cond_7
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    instance-of v2, p0, Lorg/json/JSONArray;

    const/4 v6, 0x1

    if-eqz v2, :cond_b

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    instance-of v2, p1, Lorg/json/JSONArray;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v2, :cond_b

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    check-cast p0, Lorg/json/JSONArray;

    const/4 v6, 0x5

    const/4 v5, 0x5

    check-cast p1, Lorg/json/JSONArray;

    const/4 v6, 0x7

    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-ne v2, v3, :cond_a

    const/4 v5, 0x5

    move v6, v5

    move v2, v1

    move v2, v1

    const/4 v6, 0x1

    move v2, v1

    move v2, v1

    :goto_1
    const/4 v6, 0x5

    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-ge v2, v3, :cond_9

    :try_start_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p0, v2}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1, v2}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v3, v4}, Lcom/google/android/gms/common/util/r;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v3, :cond_8

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto :goto_1

    :catch_1
    :cond_8
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    return v1

    :cond_9
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    return v0

    :cond_a
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    return v1

    :cond_b
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    return p0

    :cond_c
    :goto_2
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    return v1
.end method

.method public static b(Ljava/lang/String;)Ljava/lang/String;
    .locals 6
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-nez v0, :cond_8

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget-object v0, Lcom/google/android/gms/common/util/r;->b:Ljava/util/regex/Pattern;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v2, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/16 v3, 0xc

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eq v2, v3, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/16 v3, 0xd

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eq v2, v3, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/16 v3, 0x22

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eq v2, v3, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/16 v3, 0x2f

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eq v2, v3, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/16 v3, 0x5c

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eq v2, v3, :cond_1

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    packed-switch v2, :pswitch_data_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    goto :goto_0

    :pswitch_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v2, "bn///"

    const-string/jumbo v2, "n///o"

    const/4 v5, 0x4

    const-string/jumbo v2, "nu///"

    const-string v2, "\\\\n"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :pswitch_1
    const/4 v5, 0x0

    const/4 v4, 0x4

    const-string v2, "bt///"

    const/4 v5, 0x7

    const-string v2, "//p/t"

    const-string v2, "\\\\t"

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto/16 :goto_0

    :pswitch_2
    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v2, "/b/qu"

    const-string v2, "/ub//"

    const/4 v5, 0x5

    const-string v2, "//s//"

    const-string v2, "\\\\b"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto/16 :goto_0

    :cond_1
    const/4 v5, 0x0

    const-string v2, "///m////"

    const-string v2, "///////p"

    const/4 v5, 0x7

    const-string v2, "////o///"

    const-string v2, "\\\\\\\\"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto/16 :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string v2, "b////"

    const-string v2, "///q/"

    const/4 v5, 0x4

    const-string v2, "/u///"

    const-string v2, "\\\\/"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto/16 :goto_0

    :cond_3
    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v2, "//s/////"

    const/4 v5, 0x3

    const-string v2, "///////p"

    const-string v2, "\\\\\\\""

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto/16 :goto_0

    :cond_4
    const/4 v4, 0x7

    move v5, v4

    const-string v2, "///qr"

    const-string v2, "///mr"

    const/4 v5, 0x7

    const-string v2, "//sr/"

    const-string v2, "\\\\r"

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v2, "///fo"

    const-string v2, "/f/m/"

    const-string v2, "\\\\f"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_6
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v1, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_1

    :cond_7
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/util/regex/Matcher;->appendTail(Ljava/lang/StringBuffer;)Ljava/lang/StringBuffer;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    :cond_8
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-object p0

    :pswitch_data_0
    .packed-switch 0x8
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static c(Ljava/lang/String;)Ljava/lang/String;
    .locals 6
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-nez v0, :cond_b

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/google/android/gms/common/util/g0;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    sget-object v0, Lcom/google/android/gms/common/util/r;->a:Ljava/util/regex/Pattern;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v2, :cond_9

    const/4 v5, 0x7

    const/4 v4, 0x0

    if-nez v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v4, 0x6

    move v5, v4

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->group()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/16 v3, 0x22

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eq v2, v3, :cond_8

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/16 v3, 0x2f

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eq v2, v3, :cond_7

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/16 v3, 0x5c

    const/4 v5, 0x2

    if-eq v2, v3, :cond_6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/16 v3, 0x62

    const/4 v5, 0x2

    if-eq v2, v3, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/16 v3, 0x66

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eq v2, v3, :cond_4

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/16 v3, 0x6e

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eq v2, v3, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/16 v3, 0x72

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eq v2, v3, :cond_2

    const/4 v5, 0x2

    const/16 v3, 0x74

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-ne v2, v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v2, "t/"

    const-string v2, "/t"

    const/4 v5, 0x2

    const-string v2, "\t"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string v0, "eceeonhe v.ladrteh eahrdnsaocnab  abrouuFs t d t"

    const-string v0, "d nb bvoFsacernea dhesadttrecnp e.ehar l huu tao"

    const/4 v5, 0x3

    const-string v0, "Found an escaped character that should never be."

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    throw p0

    :cond_2
    const/4 v4, 0x0

    move v5, v4

    const-string v2, "/r"

    const-string/jumbo v2, "r/"

    const/4 v5, 0x6

    const-string v2, "/r"

    const-string v2, "\r"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto/16 :goto_0

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v2, "n/"

    const-string/jumbo v2, "n/"

    const/4 v5, 0x1

    const-string/jumbo v2, "n/"

    const-string v2, "\n"

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto/16 :goto_0

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v2, "uuc/0b"

    const-string/jumbo v2, "uc0u0/"

    const/4 v5, 0x7

    const-string/jumbo v2, "u00cu/"

    const-string v2, "\u000c"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto/16 :goto_0

    :cond_5
    const-string v2, "0p8/u0"

    const-string v2, "/p00u0"

    const-string v2, "\u0008"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto/16 :goto_0

    :cond_6
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v2, "////"

    const-string v2, "////"

    const/4 v5, 0x2

    const-string v2, "////"

    const-string v2, "\\\\"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_7
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v2, "/"

    const-string v2, "/"

    const/4 v5, 0x7

    const-string v2, "/"

    const-string v2, "/"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_8
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v2, "//"

    const-string v2, "//"

    const/4 v5, 0x0

    const-string v2, "\""

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/regex/Matcher;->appendReplacement(Ljava/lang/StringBuffer;Ljava/lang/String;)Ljava/util/regex/Matcher;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto/16 :goto_0

    :cond_9
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez v1, :cond_a

    const/4 v5, 0x3

    const/4 v4, 0x5

    return-object p0

    :cond_a
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/util/regex/Matcher;->appendTail(Ljava/lang/StringBuffer;)Ljava/lang/StringBuffer;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    :cond_b
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-object p0
.end method
