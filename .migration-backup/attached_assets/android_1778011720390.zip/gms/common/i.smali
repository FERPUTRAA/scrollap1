.class public Lcom/google/android/gms/common/i;
.super Lcom/google/android/gms/common/u;


# instance fields
.field private final zza:I


# direct methods
.method public constructor <init>(ILjava/lang/String;Landroid/content/Intent;)V
    .locals 2
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x1

    invoke-direct {p0, p2, p3}, Lcom/google/android/gms/common/u;-><init>(Ljava/lang/String;Landroid/content/Intent;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/gms/common/i;->zza:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public b()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o1s~/@~~4b@~@~ @@i~@@ @~l@- c ~o s ~yd~a tu@  vK@~ omiolb@@bn~~@o ~~.~o  r ~~@f ~@ @~~ SMf@~/@@i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/gms/common/i;->zza:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method
