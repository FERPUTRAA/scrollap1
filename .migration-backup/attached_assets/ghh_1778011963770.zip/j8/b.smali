.class public interface abstract Lj8/b;
.super Ljava/lang/Object;

# interfaces
.implements Lj8/c;
