.class public interface abstract Lj8/e;
.super Ljava/lang/Object;

# interfaces
.implements Lj8/b;
