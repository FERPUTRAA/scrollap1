.class public interface abstract Lj8/f;
.super Ljava/lang/Object;

# interfaces
.implements Lj8/d;
