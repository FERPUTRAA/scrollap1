.class public interface abstract Lj8/g$a;
.super Ljava/lang/Object;

# interfaces
.implements Lj8/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lj8/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "a"
.end annotation
