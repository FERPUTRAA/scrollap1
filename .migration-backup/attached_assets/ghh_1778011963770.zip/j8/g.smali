.class public interface abstract Lj8/g;
.super Ljava/lang/Object;

# interfaces
.implements Lj8/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lj8/g$a;
    }
.end annotation
