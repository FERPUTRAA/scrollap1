.class public interface abstract Lj8/c;
.super Ljava/lang/Object;

# interfaces
.implements Lj8/a;
