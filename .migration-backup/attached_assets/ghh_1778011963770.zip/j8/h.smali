.class public interface abstract Lj8/h;
.super Ljava/lang/Object;

# interfaces
.implements Lj8/b;
