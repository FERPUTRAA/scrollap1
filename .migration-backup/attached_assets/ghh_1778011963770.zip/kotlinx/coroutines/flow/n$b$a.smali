.class public final Lkotlinx/coroutines/flow/n$b$a;
.super Lkotlin/coroutines/jvm/internal/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/n$b;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCollect.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Collect.kt\nkotlinx/coroutines/flow/FlowKt__CollectKt$collectIndexed$2$emit$1\n*L\n1#1,118:1\n*E\n"
.end annotation


# instance fields
.field label:I

.field synthetic result:Ljava/lang/Object;

.field final synthetic this$0:Lkotlinx/coroutines/flow/n$b;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/n$b;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/n$b;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/n$b$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/flow/n$b$a;->this$0:Lkotlinx/coroutines/flow/n$b;

    const/4 v1, 0x4

    const/4 v0, 0x2

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/d;-><init>(Lkotlin/coroutines/d;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "o@s1tfy  ~u@r a@  ol @@o@~/  -~~@ ~ @ ~v@ @~ @M/~@@~os~@Ki~~bb~ ~cb@@@oi@~~tnl~~Sm@i.f ~d~@  o~4"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iput-object p1, p0, Lkotlinx/coroutines/flow/n$b$a;->result:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget p1, p0, Lkotlinx/coroutines/flow/n$b$a;->label:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/high16 v0, -0x80000000

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    or-int/2addr p1, v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput p1, p0, Lkotlinx/coroutines/flow/n$b$a;->label:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/n$b$a;->this$0:Lkotlinx/coroutines/flow/n$b;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p1, v0, p0}, Lkotlinx/coroutines/flow/n$b;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p1
.end method
