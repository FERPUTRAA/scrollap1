.class public final Lkotlinx/coroutines/flow/l$d;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/l;->c(Ljava/lang/Iterable;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,112:1\n92#2:113\n93#2,2:115\n95#2:118\n1849#3:114\n1850#3:117\n*S KotlinDebug\n*F\n+ 1 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n*L\n92#1:114\n92#1:117\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/Iterable;


# direct methods
.method public constructor <init>(Ljava/lang/Iterable;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/l$d;->a:Ljava/lang/Iterable;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    instance-of v0, p2, Lkotlinx/coroutines/flow/l$d$a;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    check-cast v0, Lkotlinx/coroutines/flow/l$d$a;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget v1, v0, Lkotlinx/coroutines/flow/l$d$a;->label:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/high16 v2, -0x80000000

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    and-int v3, v1, v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v3, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    sub-int/2addr v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    iput v1, v0, Lkotlinx/coroutines/flow/l$d$a;->label:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    new-instance v0, Lkotlinx/coroutines/flow/l$d$a;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/l$d$a;-><init>(Lkotlinx/coroutines/flow/l$d;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object p2, v0, Lkotlinx/coroutines/flow/l$d$a;->result:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v2, v0, Lkotlinx/coroutines/flow/l$d$a;->label:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x7

    move v6, v5

    if-eqz v2, :cond_2

    const/4 v6, 0x5

    if-ne v2, v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object p1, v0, Lkotlinx/coroutines/flow/l$d$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    check-cast p1, Ljava/util/Iterator;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v2, v0, Lkotlinx/coroutines/flow/l$d$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    check-cast v2, Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p2, v2

    move-object p2, v2

    move-object p2, v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_1

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string p2, "slso/ eovuio/r/owtentciilktem/crb//euh  / soa n e/e"

    const-string p2, "o s//amive t/rew/oo o etrun/ceh/iru onkel lte//isbc"

    const/4 v6, 0x0

    const-string p2, "leumn ra/k/hoouieo sc/b/lm e/i rort o/ iew//ttfcven"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    throw p1

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object p2, p0, Lkotlinx/coroutines/flow/l$d;->a:Ljava/lang/Iterable;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    :cond_3
    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz v2, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    iput-object p2, v0, Lkotlinx/coroutines/flow/l$d$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-object p1, v0, Lkotlinx/coroutines/flow/l$d$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    iput v3, v0, Lkotlinx/coroutines/flow/l$d$a;->label:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {p2, v2, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-ne v2, v1, :cond_3

    const/4 v6, 0x0

    return-object v1

    :cond_4
    const/4 v5, 0x0

    const/4 v6, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-object p1
.end method
