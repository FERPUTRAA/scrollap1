.class public final Lkotlinx/coroutines/flow/a0$g$a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/a0$g;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEmitters.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$1$1\n+ 2 Transform.kt\nkotlinx/coroutines/flow/FlowKt__TransformKt\n*L\n1#1,222:1\n73#2,2:223\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/j;

.field final synthetic b:Li8/p;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/j;Li8/p;)V
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$g$a;->a:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/flow/a0$g$a;->b:Li8/p;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    instance-of v0, p2, Lkotlinx/coroutines/flow/a0$g$a$a;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    check-cast v0, Lkotlinx/coroutines/flow/a0$g$a$a;

    const/4 v6, 0x0

    const/4 v5, 0x2

    iget v1, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->label:I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/high16 v2, -0x80000000

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    and-int v3, v1, v2

    const/4 v5, 0x0

    move v6, v5

    if-eqz v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    sub-int/2addr v1, v2

    const/4 v6, 0x2

    iput v1, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->label:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    new-instance v0, Lkotlinx/coroutines/flow/a0$g$a$a;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/a0$g$a$a;-><init>(Lkotlinx/coroutines/flow/a0$g$a;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object p2, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->result:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget v2, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->label:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v3, 0x2

    const/4 v6, 0x2

    const/4 v4, 0x1

    const/4 v6, 0x7

    move v5, v4

    move v5, v4

    const/4 v6, 0x2

    if-eqz v2, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eq v2, v4, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-ne v2, v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    goto/16 :goto_2

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string p2, " esm/oulcun wtorbt//cs/sef/irhioe  e///oi ak tlrevo"

    const-string p2, "mes wt ec//tnoi/ri ek/ ca//ofuelo/tbr/ vs oheuriole"

    const/4 v6, 0x6

    const-string p2, "rrkmisul/ /oceel/n/ouhtotb/c aiwim  rfo o/v t/eee/n"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    throw p1

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object p1, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v2, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_1

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    iget-object p2, p0, Lkotlinx/coroutines/flow/a0$g$a;->a:Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v2, p0, Lkotlinx/coroutines/flow/a0$g$a;->b:Li8/p;

    const/4 v5, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    iput-object p1, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x2

    iput-object p2, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    iput v4, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->label:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v4, 0x6

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v2, p1, v0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v4, 0x7

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-ne v2, v1, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    return-object v1

    :cond_4
    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 p2, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput-object p2, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-object p2, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput v3, v0, Lkotlinx/coroutines/flow/a0$g$a$a;->label:I

    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-interface {p1, v2, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-ne p1, v1, :cond_5

    const/4 v5, 0x3

    or-int/2addr v6, v5

    return-object v1

    :cond_5
    :goto_2
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-object p1
.end method
