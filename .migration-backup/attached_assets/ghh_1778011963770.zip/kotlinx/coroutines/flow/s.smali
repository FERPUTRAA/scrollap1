.class final synthetic Lkotlinx/coroutines/flow/s;
.super Ljava/lang/Object;


# static fields
.field private static final a:Li8/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/l<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private static final b:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lkotlinx/coroutines/flow/s$b;->a:Lkotlinx/coroutines/flow/s$b;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    sput-object v0, Lkotlinx/coroutines/flow/s;->a:Li8/l;

    const/4 v2, 0x7

    const/4 v1, 0x2

    sget-object v0, Lkotlinx/coroutines/flow/s$a;->a:Lkotlinx/coroutines/flow/s$a;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput-object v0, Lkotlinx/coroutines/flow/s;->b:Li8/p;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public static final a(Lkotlinx/coroutines/flow/i;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    instance-of v0, p0, Lkotlinx/coroutines/flow/t0;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    sget-object v0, Lkotlinx/coroutines/flow/s;->a:Li8/l;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v1, Lkotlinx/coroutines/flow/s;->b:Li8/p;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p0, v0, v1}, Lkotlinx/coroutines/flow/s;->d(Lkotlinx/coroutines/flow/i;Li8/l;Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0
.end method

.method public static final b(Lkotlinx/coroutines/flow/i;Li8/p;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Li8/p<",
            "-TT;-TT;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget-object v0, Lkotlinx/coroutines/flow/s;->a:Li8/l;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v1, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p1, v1}, Lkotlin/jvm/internal/u1;->q(Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast p1, Li8/p;

    const/4 v3, 0x5

    invoke-static {p0, v0, p1}, Lkotlinx/coroutines/flow/s;->d(Lkotlinx/coroutines/flow/i;Li8/l;Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0
.end method

.method public static final c(Lkotlinx/coroutines/flow/i;Li8/l;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "K:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Li8/l<",
            "-TT;+TK;>;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lkotlinx/coroutines/flow/s;->b:Li8/p;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p0, p1, v0}, Lkotlinx/coroutines/flow/s;->d(Lkotlinx/coroutines/flow/i;Li8/l;Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method private static final d(Lkotlinx/coroutines/flow/i;Li8/l;Li8/p;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Li8/l<",
            "-TT;+",
            "Ljava/lang/Object;",
            ">;",
            "Li8/p<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            "Ljava/lang/Boolean;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    instance-of v0, p0, Lkotlinx/coroutines/flow/g;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    check-cast v0, Lkotlinx/coroutines/flow/g;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, v0, Lkotlinx/coroutines/flow/g;->b:Li8/l;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ne v1, p1, :cond_0

    const/4 v3, 0x0

    iget-object v0, v0, Lkotlinx/coroutines/flow/g;->c:Li8/p;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-ne v0, p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    new-instance v0, Lkotlinx/coroutines/flow/g;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0, p0, p1, p2}, Lkotlinx/coroutines/flow/g;-><init>(Lkotlinx/coroutines/flow/i;Li8/l;Li8/p;)V

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p0
.end method

.method private static synthetic e()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method private static synthetic f()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    return-void
.end method
