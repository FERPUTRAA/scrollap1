.class public final Lkotlinx/coroutines/flow/b0$r$b;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/q;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0$r;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/q<",
        "Lkotlinx/coroutines/flow/j<",
        "-TR;>;[TT;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nZip.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt$combineTransform$7$2\n*L\n1#1,332:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__ZipKt$combineTransform$7$2"
    f = "Zip.kt"
    i = {}
    l = {
        0x134
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $transform:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;[TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field synthetic L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method public constructor <init>(Li8/q;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/q<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-[TT;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/b0$r$b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$r$b;->$transform:Li8/q;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    const/4 p1, 0x3

    const/4 v1, 0x1

    const/4 v0, 0x3

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s@o@ l  i@SiMoo4b@f- t@~vt @@ @~~ @~~@ ~ 1~l ~~.n~a~ f~b ~u~b K/oi@@~@@~~ @~  @~@~csdro@/om~ y"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x5

    check-cast p2, [Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    check-cast p3, Lkotlin/coroutines/d;

    const/4 v1, 0x5

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/b0$r$b;->k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget v1, p0, Lkotlinx/coroutines/flow/b0$r$b;->label:I

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-ne v1, v2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string v0, "inom/ tev m/foe/oels/ er rtsctweeuoauikch/bn /l ro/"

    const-string/jumbo v0, "teslie/oncoh/ oe//tv/oib /rret onu cm/e uekifw sarl"

    const/4 v6, 0x1

    const-string v0, "e//ooltle iu/inmr eewurce ta/isenv/oorht  fb/ok /oc"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    throw p1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$r$b;->L$0:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$r$b;->L$1:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    check-cast v1, [Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v3, p0, Lkotlinx/coroutines/flow/b0$r$b;->$transform:Li8/q;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    iput-object v4, p0, Lkotlinx/coroutines/flow/b0$r$b;->L$0:Ljava/lang/Object;

    const/4 v5, 0x7

    or-int/2addr v6, v5

    iput v2, p0, Lkotlinx/coroutines/flow/b0$r$b;->label:I

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    invoke-interface {v3, p1, v1, p0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ne p1, v0, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object v0

    :cond_2
    :goto_0
    const/4 v5, 0x1

    const/4 v6, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x2

    return-object p1
.end method

.method public final invokeSuspend$$forInline(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$r$b;->L$0:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/flow/b0$r$b;->L$1:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    check-cast v0, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$r$b;->$transform:Li8/q;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v1, p1, v0, p0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x7

    const/4 v2, 0x2

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;[TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/b0$r$b;

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$r$b;->$transform:Li8/q;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0, v1, p3}, Lkotlinx/coroutines/flow/b0$r$b;-><init>(Li8/q;Lkotlin/coroutines/d;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object p1, v0, Lkotlinx/coroutines/flow/b0$r$b;->L$0:Ljava/lang/Object;

    const/4 v3, 0x3

    iput-object p2, v0, Lkotlinx/coroutines/flow/b0$r$b;->L$1:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/flow/b0$r$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p1
.end method
