.class public final Lkotlinx/coroutines/flow/l$h;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/l;->h([I)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "Ljava/lang/Integer;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,112:1\n167#2:113\n168#2,2:115\n170#2:118\n13557#3:114\n13558#3:117\n*S KotlinDebug\n*F\n+ 1 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n*L\n167#1:114\n167#1:117\n*E\n"
.end annotation


# instance fields
.field final synthetic a:[I


# direct methods
.method public constructor <init>([I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/l$h;->a:[I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 9
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-",
            "Ljava/lang/Integer;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    instance-of v0, p2, Lkotlinx/coroutines/flow/l$h$a;

    const/4 v7, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v8, 0x6

    const/4 v7, 0x0

    check-cast v0, Lkotlinx/coroutines/flow/l$h$a;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget v1, v0, Lkotlinx/coroutines/flow/l$h$a;->label:I

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/high16 v2, -0x80000000

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    and-int v3, v1, v2

    const/4 v8, 0x3

    if-eqz v3, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    sub-int/2addr v1, v2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    iput v1, v0, Lkotlinx/coroutines/flow/l$h$a;->label:I

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    goto :goto_0

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/l$h$a;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/l$h$a;-><init>(Lkotlinx/coroutines/flow/l$h;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v7, 0x4

    move v8, v7

    iget-object p2, v0, Lkotlinx/coroutines/flow/l$h$a;->result:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget v2, v0, Lkotlinx/coroutines/flow/l$h$a;->label:I

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/4 v3, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eqz v2, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-ne v2, v3, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget p1, v0, Lkotlinx/coroutines/flow/l$h$a;->I$1:I

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget v2, v0, Lkotlinx/coroutines/flow/l$h$a;->I$0:I

    const/4 v7, 0x4

    iget-object v4, v0, Lkotlinx/coroutines/flow/l$h$a;->L$1:Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    check-cast v4, [I

    const/4 v7, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object v5, v0, Lkotlinx/coroutines/flow/l$h$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x5

    check-cast v5, Lkotlinx/coroutines/flow/j;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p2, v5

    move-object p2, v5

    move-object p2, v5

    move-object p2, v5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto :goto_2

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string p2, "o sieoeleei n// hnucrbsoucvfr// s eor/al/o/t/m wket"

    const-string p2, "ras mrlee hbo/sv// e /ec/t/lrn coek/ ooinoiuuwfte/i"

    const-string p2, "ienmml /leeu aewr/ oit  er/on//ov/surt/hfc/ckeooibt"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    throw p1

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x6

    move v8, v7

    iget-object p2, p0, Lkotlinx/coroutines/flow/l$h;->a:[I

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    array-length v2, p2

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/4 v4, 0x0

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v8, 0x2

    const/4 v7, 0x2

    move p1, v2

    move p1, v2

    const/4 v8, 0x7

    move p1, v2

    move p1, v2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    move v2, v4

    move v2, v4

    const/4 v8, 0x1

    move v2, v4

    move v2, v4

    move-object v4, v6

    move-object v4, v6

    move-object v4, v6

    move-object v4, v6

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-ge v2, p1, :cond_4

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    aget v5, v4, v2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {v5}, Lkotlin/coroutines/jvm/internal/b;->f(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    iput-object p2, v0, Lkotlinx/coroutines/flow/l$h$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x4

    iput-object v4, v0, Lkotlinx/coroutines/flow/l$h$a;->L$1:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    iput v2, v0, Lkotlinx/coroutines/flow/l$h$a;->I$0:I

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    iput p1, v0, Lkotlinx/coroutines/flow/l$h$a;->I$1:I

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    iput v3, v0, Lkotlinx/coroutines/flow/l$h$a;->label:I

    const/4 v8, 0x2

    invoke-interface {p2, v5, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-ne v5, v1, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    return-object v1

    :cond_3
    :goto_2
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    add-int/2addr v2, v3

    const/4 v7, 0x3

    const/4 v7, 0x0

    goto :goto_1

    :cond_4
    const/4 v7, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x6

    move v8, v7

    return-object p1
.end method
