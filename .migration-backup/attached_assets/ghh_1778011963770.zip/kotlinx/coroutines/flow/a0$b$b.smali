.class public final Lkotlinx/coroutines/flow/a0$b$b;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/a0$b;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEmitters.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$1$1\n+ 2 Transform.kt\nkotlinx/coroutines/flow/FlowKt__TransformKt\n*L\n1#1,222:1\n21#2:223\n35#2:224\n22#2:225\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/j;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/j;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$b$b;->a:Lkotlinx/coroutines/flow/j;

    const/4 v0, 0x5

    xor-int/2addr v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "l@s~@4 1@@.@~ ~~@~i~d  i Kc~~~ou@o rt~ @m b @@  ~ov/ ~~~ ~ fs/@o@n ~yof@~@~~l@MS@b@@@at@-b~i  o~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    const/4 v0, 0x4

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/a0$b$b$a;

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/a0$b$b$a;-><init>(Lkotlinx/coroutines/flow/a0$b$b;Lkotlin/coroutines/d;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v0, 0x5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/flow/a0$b$b;->a:Lkotlinx/coroutines/flow/j;

    const/4 v3, 0x5

    move v4, v3

    const/4 v1, 0x3

    move v4, v1

    const/4 v3, 0x0

    move v4, v3

    const-string v2, "R"

    const-string v2, "R"

    const/4 v4, 0x2

    const-string v2, "R"

    const-string v2, "R"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    instance-of v1, p1, Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    invoke-static {v1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {v0, p1, p2}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {p1}, Lkotlin/jvm/internal/i0;->e(I)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x2

    const/4 v3, 0x3

    return-object p1
.end method

.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    instance-of v0, p2, Lkotlinx/coroutines/flow/a0$b$b$a;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    check-cast v0, Lkotlinx/coroutines/flow/a0$b$b$a;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget v1, v0, Lkotlinx/coroutines/flow/a0$b$b$a;->label:I

    const/4 v5, 0x0

    move v6, v5

    const/high16 v2, -0x80000000

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    and-int v3, v1, v2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    sub-int/2addr v1, v2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    iput v1, v0, Lkotlinx/coroutines/flow/a0$b$b$a;->label:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-instance v0, Lkotlinx/coroutines/flow/a0$b$b$a;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/a0$b$b$a;-><init>(Lkotlinx/coroutines/flow/a0$b$b;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object p2, v0, Lkotlinx/coroutines/flow/a0$b$b$a;->result:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget v2, v0, Lkotlinx/coroutines/flow/a0$b$b$a;->label:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v2, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x2

    if-ne v2, v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_1

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string p2, "sf/mtr e ob /em/ul/ct  /ulnewonve/aiikoeectrh/rsoo/"

    const-string p2, "hrs/nteeicvwi/lu orf //roe/ o ktbeiucnomeatl/ seo//"

    const/4 v6, 0x2

    const-string p2, "nuttoeo /eoeeilosi en /cta  /eu /ioo/bv/rlwkrfmrhc/"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    throw p1

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object p2, p0, Lkotlinx/coroutines/flow/a0$b$b;->a:Lkotlinx/coroutines/flow/j;

    const/4 v5, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v2, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v4, "R"

    const-string v4, "R"

    const/4 v6, 0x6

    const-string v4, "R"

    const-string v4, "R"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v2, v4}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    instance-of v2, p1, Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v2, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    iput v3, v0, Lkotlinx/coroutines/flow/a0$b$b$a;->label:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {p2, p1, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-ne p1, v1, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-object v1

    :cond_3
    :goto_1
    const/4 v5, 0x4

    const/4 v6, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-object p1
.end method
