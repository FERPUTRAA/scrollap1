.class public final Lkotlinx/coroutines/flow/t$b$a;
.super Lkotlin/coroutines/jvm/internal/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/t$b;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1$collect$1\n*L\n1#1,112:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__EmittersKt$onCompletion$$inlined$unsafeFlow$1"
    f = "Emitters.kt"
    i = {
        0x0,
        0x0,
        0x1,
        0x2
    }
    l = {
        0x72,
        0x79,
        0x80
    }
    m = "collect"
    n = {
        "this",
        "$this$onCompletion_u24lambda_u2d2",
        "e",
        "sc"
    }
    s = {
        "L$0",
        "L$1",
        "L$0",
        "L$0"
    }
.end annotation


# instance fields
.field L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field label:I

.field synthetic result:Ljava/lang/Object;

.field final synthetic this$0:Lkotlinx/coroutines/flow/t$b;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/t$b;Lkotlin/coroutines/d;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/flow/t$b$a;->this$0:Lkotlinx/coroutines/flow/t$b;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/d;-><init>(Lkotlin/coroutines/d;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ts~K4M~  it@~-a @@@cnoor@b~~~b@o@.~vi@@u d /@1S~ ~~~/ b@~ ~@io s ~~@@@@ff~ o~ @@@~~~  m~o  ~@ly"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iput-object p1, p0, Lkotlinx/coroutines/flow/t$b$a;->result:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget p1, p0, Lkotlinx/coroutines/flow/t$b$a;->label:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/high16 v0, -0x80000000

    const/4 v1, 0x2

    move v2, v1

    or-int/2addr p1, v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput p1, p0, Lkotlinx/coroutines/flow/t$b$a;->label:I

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object p1, p0, Lkotlinx/coroutines/flow/t$b$a;->this$0:Lkotlinx/coroutines/flow/t$b;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1, v0, p0}, Lkotlinx/coroutines/flow/t$b;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p1
.end method
