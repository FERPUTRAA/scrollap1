.class final Lkotlinx/coroutines/flow/t$d;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/t;->e(Lkotlinx/coroutines/flow/i;Li8/p;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlin/jvm/internal/k1$a;

.field final synthetic b:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/k1$a;Lkotlinx/coroutines/flow/j;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/k1$a;",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/flow/t$d;->a:Lkotlin/jvm/internal/k1$a;

    const/4 v1, 0x7

    const/4 v0, 0x6

    iput-object p2, p0, Lkotlinx/coroutines/flow/t$d;->b:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    instance-of v0, p2, Lkotlinx/coroutines/flow/t$d$a;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    check-cast v0, Lkotlinx/coroutines/flow/t$d$a;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v1, v0, Lkotlinx/coroutines/flow/t$d$a;->label:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/high16 v2, -0x80000000

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    and-int v3, v1, v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v5, 0x2

    sub-int/2addr v1, v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput v1, v0, Lkotlinx/coroutines/flow/t$d$a;->label:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/t$d$a;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/t$d$a;-><init>(Lkotlinx/coroutines/flow/t$d;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object p2, v0, Lkotlinx/coroutines/flow/t$d$a;->result:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget v2, v0, Lkotlinx/coroutines/flow/t$d$a;->label:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x0

    if-eqz v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-ne v2, v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const-string p2, "clsn/rr oa/onlukee mst i v/eeo/eo/tscwutr//ifi  he/"

    const-string p2, "e/seeo ei/wosmnhc/ko/rlu/ u  /fovblte/ rtircie/tan "

    const/4 v5, 0x3

    const-string p2, "eo/m rt/tr o/tiauoe /vrbk/weeemoch/f oseulici/ n nl"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    throw p1

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p2, p0, Lkotlinx/coroutines/flow/t$d;->a:Lkotlin/jvm/internal/k1$a;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x0

    xor-int/2addr v5, v2

    const/4 v4, 0x4

    move v5, v4

    iput-boolean v2, p2, Lkotlin/jvm/internal/k1$a;->element:Z

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object p2, p0, Lkotlinx/coroutines/flow/t$d;->b:Lkotlinx/coroutines/flow/j;

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput v3, v0, Lkotlinx/coroutines/flow/t$d$a;->label:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {p2, p1, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ne p1, v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-object v1

    :cond_3
    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object p1
.end method
