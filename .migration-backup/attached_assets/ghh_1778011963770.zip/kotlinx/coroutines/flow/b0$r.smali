.class public final Lkotlinx/coroutines/flow/b0$r;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0;->h(Ljava/lang/Iterable;Li8/q;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/flow/j<",
        "-TR;>;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nZip.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt$combineTransform$7\n*L\n1#1,332:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__ZipKt$combineTransform$7"
    f = "Zip.kt"
    i = {}
    l = {
        0x134
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $flowArray:[Lkotlinx/coroutines/flow/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation
.end field

.field final synthetic $transform:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;[TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method public constructor <init>([Lkotlinx/coroutines/flow/i;Li8/q;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;",
            "Li8/q<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-[TT;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/b0$r;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$r;->$flowArray:[Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p2, p0, Lkotlinx/coroutines/flow/b0$r;->$transform:Li8/q;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p1, 0x2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v0, Lkotlinx/coroutines/flow/b0$r;

    const/4 v4, 0x1

    const/4 v3, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$r;->$flowArray:[Lkotlinx/coroutines/flow/i;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v2, p0, Lkotlinx/coroutines/flow/b0$r;->$transform:Li8/q;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/flow/b0$r;-><init>([Lkotlinx/coroutines/flow/i;Li8/q;Lkotlin/coroutines/d;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-object p1, v0, Lkotlinx/coroutines/flow/b0$r;->L$0:Ljava/lang/Object;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x6

    const/4 v0, 0x4

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/b0$r;->invoke(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/b0$r;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    check-cast p1, Lkotlinx/coroutines/flow/b0$r;

    const/4 v1, 0x3

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/b0$r;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    iget v1, p0, Lkotlinx/coroutines/flow/b0$r;->label:I

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz v1, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-ne v1, v2, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    goto :goto_0

    :cond_0
    const/4 v8, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x0

    const-string v0, "eesecmhoerf t/v/nt/ia/e cowb/ukot r/iesnl uolor/ s "

    const-string v0, "/osn  /t/eeecseiioa tu  /hlloc//triw ovrkfrueeb/mno"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    throw p1

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$r;->L$0:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v8, 0x1

    const/4 v7, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$r;->$flowArray:[Lkotlinx/coroutines/flow/i;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v8, 0x5

    const/4 v7, 0x5

    new-instance v3, Lkotlinx/coroutines/flow/b0$r$a;

    const/4 v8, 0x0

    const/4 v7, 0x3

    iget-object v4, p0, Lkotlinx/coroutines/flow/b0$r;->$flowArray:[Lkotlinx/coroutines/flow/i;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-direct {v3, v4}, Lkotlinx/coroutines/flow/b0$r$a;-><init>([Lkotlinx/coroutines/flow/i;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    new-instance v4, Lkotlinx/coroutines/flow/b0$r$b;

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object v5, p0, Lkotlinx/coroutines/flow/b0$r;->$transform:Li8/q;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/4 v6, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {v4, v5, v6}, Lkotlinx/coroutines/flow/b0$r$b;-><init>(Li8/q;Lkotlin/coroutines/d;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    iput v2, p0, Lkotlinx/coroutines/flow/b0$r;->label:I

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {p1, v1, v3, v4, p0}, Lkotlinx/coroutines/flow/internal/m;->a(Lkotlinx/coroutines/flow/j;[Lkotlinx/coroutines/flow/i;Li8/a;Li8/q;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-ne p1, v0, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    return-object v0

    :cond_2
    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x1

    const/4 v7, 0x0

    return-object p1
.end method

.method public final invokeSuspend$$forInline(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x6

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$r;->L$0:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/flow/b0$r;->$flowArray:[Lkotlinx/coroutines/flow/i;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v6, 0x0

    new-instance v1, Lkotlinx/coroutines/flow/b0$r$a;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/flow/b0$r;->$flowArray:[Lkotlinx/coroutines/flow/i;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {v1, v2}, Lkotlinx/coroutines/flow/b0$r$a;-><init>([Lkotlinx/coroutines/flow/i;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    new-instance v2, Lkotlinx/coroutines/flow/b0$r$b;

    const/4 v6, 0x4

    iget-object v3, p0, Lkotlinx/coroutines/flow/b0$r;->$transform:Li8/q;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {v2, v3, v4}, Lkotlinx/coroutines/flow/b0$r$b;-><init>(Li8/q;Lkotlin/coroutines/d;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v3, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v3}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {p1, v0, v1, v2, p0}, Lkotlinx/coroutines/flow/internal/m;->a(Lkotlinx/coroutines/flow/j;[Lkotlinx/coroutines/flow/i;Li8/a;Li8/q;Lkotlin/coroutines/d;)Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 p1, 0x1

    const/4 v5, 0x7

    move v6, v5

    invoke-static {p1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x5

    return-object p1
.end method
