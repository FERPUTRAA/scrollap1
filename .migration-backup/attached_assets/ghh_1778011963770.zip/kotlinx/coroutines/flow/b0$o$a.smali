.class public final Lkotlinx/coroutines/flow/b0$o$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/q;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0$o;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/q<",
        "Lkotlinx/coroutines/flow/j<",
        "-TR;>;[",
        "Ljava/lang/Object;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nZip.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt$combineTransformUnsafe$1$1\n+ 2 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt\n*L\n1#1,332:1\n178#2,7:333\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$4$1"
    f = "Zip.kt"
    i = {}
    l = {
        0x14d
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $transform$inlined:Li8/t;

.field private synthetic L$0:Ljava/lang/Object;

.field synthetic L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method public constructor <init>(Lkotlin/coroutines/d;Li8/t;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/flow/b0$o$a;->$transform$inlined:Li8/t;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    const/4 p2, 0x3

    const/4 v1, 0x2

    const/4 v0, 0x2

    invoke-direct {p0, p2, p1}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ ssnofo~4l@~c@d@v@ a@@  /@~~i i ~ @~y~~~Ko~@ ~orl @@@~o~@bM ~  ~t@ ~@~ ~  m1~bt~@u -.bS@@i~fo~/"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    check-cast p2, [Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    check-cast p3, Lkotlin/coroutines/d;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/b0$o$a;->k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v11, 0x1

    const/4 v10, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget v1, p0, Lkotlinx/coroutines/flow/b0$o$a;->label:I

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x3

    const/4 v2, 0x1

    const/4 v10, 0x1

    or-int/2addr v11, v10

    if-eqz v1, :cond_1

    const/4 v10, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x2

    if-ne v1, v2, :cond_0

    const/4 v11, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    goto :goto_0

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    const-string v0, "t hmkcb/sme/lfe//uw a/t//ernneiooi le  rveociro/uot"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    throw p1

    :cond_1
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$o$a;->L$0:Ljava/lang/Object;

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x2

    check-cast v4, Lkotlinx/coroutines/flow/j;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$o$a;->L$1:Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    check-cast p1, [Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x5

    iget-object v3, p0, Lkotlinx/coroutines/flow/b0$o$a;->$transform$inlined:Li8/t;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    const/4 v1, 0x0

    const/4 v11, 0x1

    aget-object v5, p1, v1

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    aget-object v6, p1, v2

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    const/4 v1, 0x2

    const/4 v10, 0x2

    move v11, v10

    aget-object v7, p1, v1

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    const/4 v1, 0x3

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    aget-object v8, p1, v1

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    iput v2, p0, Lkotlinx/coroutines/flow/b0$o$a;->label:I

    const/4 v11, 0x2

    const/4 p1, 0x6

    move v10, p1

    const/4 v11, 0x4

    invoke-static {p1}, Lkotlin/jvm/internal/i0;->e(I)V

    move-object v9, p0

    move-object v9, p0

    move-object v9, p0

    const/4 v11, 0x4

    invoke-interface/range {v3 .. v9}, Li8/t;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    const/4 v1, 0x7

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-static {v1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x5

    if-ne p1, v0, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    return-object v0

    :cond_2
    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v10, 0x0

    or-int/2addr v11, v10

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;[",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Lkotlinx/coroutines/flow/b0$o$a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$o$a;->$transform$inlined:Li8/t;

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, p3, v1}, Lkotlinx/coroutines/flow/b0$o$a;-><init>(Lkotlin/coroutines/d;Li8/t;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object p1, v0, Lkotlinx/coroutines/flow/b0$o$a;->L$0:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object p2, v0, Lkotlinx/coroutines/flow/b0$o$a;->L$1:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/flow/b0$o$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p1
.end method
