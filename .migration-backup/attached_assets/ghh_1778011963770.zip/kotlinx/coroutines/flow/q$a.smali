.class final Lkotlinx/coroutines/flow/q$a;
.super Lkotlin/coroutines/jvm/internal/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/q;->b(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlin/coroutines/jvm/internal/d;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__CountKt"
    f = "Count.kt"
    i = {
        0x0
    }
    l = {
        0x12
    }
    m = "count"
    n = {
        "i"
    }
    s = {
        "L$0"
    }
.end annotation


# instance fields
.field L$0:Ljava/lang/Object;

.field label:I

.field synthetic result:Ljava/lang/Object;


# direct methods
.method constructor <init>(Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/q$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lkotlin/coroutines/jvm/internal/d;-><init>(Lkotlin/coroutines/d;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "o@s~M@ ~t~/4 i@ ~ @~~@ ~~f~~@vn~~by~~b @@@  Sm~@~~ /~-Kao@ .osc@oi~ @oudoi@@ ~@1f rl @~ @@~tlb @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/flow/q$a;->result:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget p1, p0, Lkotlinx/coroutines/flow/q$a;->label:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/high16 v0, -0x80000000

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    or-int/2addr p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput p1, p0, Lkotlinx/coroutines/flow/q$a;->label:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-static {p1, p0}, Lkotlinx/coroutines/flow/k;->Z(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p1
.end method
