.class final Lkotlinx/coroutines/flow/r0$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/r0;->a(Lkotlinx/coroutines/flow/t0;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/flow/j<",
        "-",
        "Lkotlinx/coroutines/flow/m0;",
        ">;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.StartedLazily$command$1"
    f = "SharingStarted.kt"
    i = {}
    l = {
        0x9b
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $subscriptionCount:Lkotlinx/coroutines/flow/t0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/t0<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/t0;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/t0<",
            "Ljava/lang/Integer;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/r0$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/r0$a;->$subscriptionCount:Lkotlinx/coroutines/flow/t0;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 p1, 0x2

    const/4 v0, 0x1

    shl-int/2addr v1, v0

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/r0$a;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/flow/r0$a;->$subscriptionCount:Lkotlinx/coroutines/flow/t0;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, v1, p2}, Lkotlinx/coroutines/flow/r0$a;-><init>(Lkotlinx/coroutines/flow/t0;Lkotlin/coroutines/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object p1, v0, Lkotlinx/coroutines/flow/r0$a;->L$0:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/r0$a;->invoke(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-",
            "Lkotlinx/coroutines/flow/m0;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/r0$a;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    check-cast p1, Lkotlinx/coroutines/flow/r0$a;

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v0, 0x7

    or-int/2addr v1, v0

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/r0$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v1, p0, Lkotlinx/coroutines/flow/r0$a;->label:I

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    const/4 v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eq v1, v2, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x6

    move v6, v5

    const-string v0, "fuslbsencc eolneos/ir/ir/kr/ou vi/owee  t//ao et /m"

    const-string v0, "nostu/rslmnle/w  e kcoo etc//iereu/vrt bof /eia//io"

    const/4 v6, 0x5

    const-string v0, "nwbmhir/crvocse/le//ieu e/ li  noomu/to reftt oka//"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    move v6, v5

    throw p1

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/flow/r0$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x4

    shr-int/2addr v6, v5

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v1, Lkotlin/jvm/internal/k1$a;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v1}, Lkotlin/jvm/internal/k1$a;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v3, p0, Lkotlinx/coroutines/flow/r0$a;->$subscriptionCount:Lkotlinx/coroutines/flow/t0;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance v4, Lkotlinx/coroutines/flow/r0$a$a;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v4, v1, p1}, Lkotlinx/coroutines/flow/r0$a$a;-><init>(Lkotlin/jvm/internal/k1$a;Lkotlinx/coroutines/flow/j;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    iput v2, p0, Lkotlinx/coroutines/flow/r0$a;->label:I

    const/4 v5, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {v3, v4, p0}, Lkotlinx/coroutines/flow/i0;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-ne p1, v0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object v0

    :cond_2
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance p1, Lkotlin/y;

    const/4 v6, 0x3

    invoke-direct {p1}, Lkotlin/y;-><init>()V

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    throw p1
.end method
