.class final Lkotlinx/coroutines/flow/s0$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/q;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/s0;->a(Lkotlinx/coroutines/flow/t0;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/q<",
        "Lkotlinx/coroutines/flow/j<",
        "-",
        "Lkotlinx/coroutines/flow/m0;",
        ">;",
        "Ljava/lang/Integer;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.StartedWhileSubscribed$command$1"
    f = "SharingStarted.kt"
    i = {
        0x1,
        0x2,
        0x3
    }
    l = {
        0xb2,
        0xb4,
        0xb6,
        0xb7,
        0xb9
    }
    m = "invokeSuspend"
    n = {
        "$this$transformLatest",
        "$this$transformLatest",
        "$this$transformLatest"
    }
    s = {
        "L$0",
        "L$0",
        "L$0"
    }
.end annotation


# instance fields
.field synthetic I$0:I

.field private synthetic L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Lkotlinx/coroutines/flow/s0;


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/s0;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/s0;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/s0$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/flow/s0$a;->this$0:Lkotlinx/coroutines/flow/s0;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p1, 0x3

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s~@ ~~ 4~~ost~i@l@i  ~@/Mo ~y b @btvfo~ ~o@@~-@~ S~ ~m~~ n ~/~@ o@ a 1~@olc f@ @@K~d@@ub@.~@@i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    check-cast p2, Ljava/lang/Number;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    move-result p2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    check-cast p3, Lkotlin/coroutines/d;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/s0$a;->k(Lkotlinx/coroutines/flow/j;ILkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x0

    iget v1, p0, Lkotlinx/coroutines/flow/s0$a;->label:I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    const/4 v2, 0x5

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/4 v3, 0x4

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    const/4 v4, 0x3

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    const/4 v5, 0x2

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    const/4 v6, 0x1

    const/4 v9, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-eqz v1, :cond_5

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eq v1, v6, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eq v1, v5, :cond_3

    const/4 v10, 0x7

    const/4 v9, 0x3

    if-eq v1, v4, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-eq v1, v3, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-ne v1, v2, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    goto :goto_0

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v10, 0x1

    const-string v0, "/romioac i/lw ecv /emf t/ekrtonheus//l ue/bnoreo/i "

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v10, 0x2

    const/4 v9, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x5

    throw p1

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/s0$a;->L$0:Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    check-cast v1, Lkotlinx/coroutines/flow/j;

    const/4 v10, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    goto/16 :goto_3

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/flow/s0$a;->L$0:Ljava/lang/Object;

    const/4 v10, 0x7

    check-cast v1, Lkotlinx/coroutines/flow/j;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    goto/16 :goto_2

    :cond_3
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/flow/s0$a;->L$0:Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    check-cast v1, Lkotlinx/coroutines/flow/j;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    goto :goto_1

    :cond_4
    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto/16 :goto_4

    :cond_5
    const/4 v9, 0x6

    move v10, v9

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/s0$a;->L$0:Ljava/lang/Object;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x5

    check-cast v1, Lkotlinx/coroutines/flow/j;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget p1, p0, Lkotlinx/coroutines/flow/s0$a;->I$0:I

    const/4 v9, 0x5

    move v10, v9

    if-lez p1, :cond_6

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    sget-object p1, Lkotlinx/coroutines/flow/m0;->a:Lkotlinx/coroutines/flow/m0;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    iput v6, p0, Lkotlinx/coroutines/flow/s0$a;->label:I

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {v1, p1, p0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    if-ne p1, v0, :cond_a

    const/4 v10, 0x2

    return-object v0

    :cond_6
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/flow/s0$a;->this$0:Lkotlinx/coroutines/flow/s0;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {p1}, Lkotlinx/coroutines/flow/s0;->c(Lkotlinx/coroutines/flow/s0;)J

    move-result-wide v6

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    iput-object v1, p0, Lkotlinx/coroutines/flow/s0$a;->L$0:Ljava/lang/Object;

    const/4 v9, 0x2

    move v10, v9

    iput v5, p0, Lkotlinx/coroutines/flow/s0$a;->label:I

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {v6, v7, p0}, Lkotlinx/coroutines/f1;->b(JLkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x7

    if-ne p1, v0, :cond_7

    const/4 v9, 0x2

    xor-int/2addr v10, v9

    return-object v0

    :cond_7
    :goto_1
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/s0$a;->this$0:Lkotlinx/coroutines/flow/s0;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-static {p1}, Lkotlinx/coroutines/flow/s0;->b(Lkotlinx/coroutines/flow/s0;)J

    move-result-wide v5

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x1

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v9, 0x1

    xor-int/2addr v10, v9

    cmp-long p1, v5, v7

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-lez p1, :cond_9

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    sget-object p1, Lkotlinx/coroutines/flow/m0;->b:Lkotlinx/coroutines/flow/m0;

    const/4 v10, 0x3

    iput-object v1, p0, Lkotlinx/coroutines/flow/s0$a;->L$0:Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    iput v4, p0, Lkotlinx/coroutines/flow/s0$a;->label:I

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-interface {v1, p1, p0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-ne p1, v0, :cond_8

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    return-object v0

    :cond_8
    :goto_2
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/s0$a;->this$0:Lkotlinx/coroutines/flow/s0;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {p1}, Lkotlinx/coroutines/flow/s0;->b(Lkotlinx/coroutines/flow/s0;)J

    move-result-wide v4

    const/4 v10, 0x3

    const/4 v9, 0x1

    iput-object v1, p0, Lkotlinx/coroutines/flow/s0$a;->L$0:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    iput v3, p0, Lkotlinx/coroutines/flow/s0$a;->label:I

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-static {v4, v5, p0}, Lkotlinx/coroutines/f1;->b(JLkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x0

    const/4 v9, 0x6

    if-ne p1, v0, :cond_9

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    return-object v0

    :cond_9
    :goto_3
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    sget-object p1, Lkotlinx/coroutines/flow/m0;->c:Lkotlinx/coroutines/flow/m0;

    const/4 v10, 0x3

    const/4 v3, 0x7

    const/4 v10, 0x5

    const/4 v3, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    iput-object v3, p0, Lkotlinx/coroutines/flow/s0$a;->L$0:Ljava/lang/Object;

    const/4 v10, 0x4

    iput v2, p0, Lkotlinx/coroutines/flow/s0$a;->label:I

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {v1, p1, p0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-ne p1, v0, :cond_a

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    return-object v0

    :cond_a
    :goto_4
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/flow/j;ILkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-",
            "Lkotlinx/coroutines/flow/m0;",
            ">;I",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/s0$a;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/flow/s0$a;->this$0:Lkotlinx/coroutines/flow/s0;

    const/4 v3, 0x2

    invoke-direct {v0, v1, p3}, Lkotlinx/coroutines/flow/s0$a;-><init>(Lkotlinx/coroutines/flow/s0;Lkotlin/coroutines/d;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object p1, v0, Lkotlinx/coroutines/flow/s0$a;->L$0:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput p2, v0, Lkotlinx/coroutines/flow/s0$a;->I$0:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/flow/s0$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1
.end method
