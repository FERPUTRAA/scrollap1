.class public final Lkotlinx/coroutines/flow/t$g;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/t;->h(Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TR;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt\n*L\n1#1,112:1\n51#2,5:113\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/i;

.field final synthetic b:Li8/q;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/i;Li8/q;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/t$g;->a:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x6

    iput-object p2, p0, Lkotlinx/coroutines/flow/t$g;->b:Li8/q;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/flow/t$g;->a:Lkotlinx/coroutines/flow/i;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v1, Lkotlinx/coroutines/flow/t$h;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v2, p0, Lkotlinx/coroutines/flow/t$g;->b:Li8/q;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {v1, v2, p1}, Lkotlinx/coroutines/flow/t$h;-><init>(Li8/q;Lkotlinx/coroutines/flow/j;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {v0, v1, p2}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-ne p1, p2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-object p1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object p1
.end method

.method public f(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v0, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x0

    new-instance v0, Lkotlinx/coroutines/flow/t$g$a;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/t$g$a;-><init>(Lkotlinx/coroutines/flow/t$g;Lkotlin/coroutines/d;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v0, 0x5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/flow/t$g;->a:Lkotlinx/coroutines/flow/i;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v1, Lkotlinx/coroutines/flow/t$h;

    const/4 v3, 0x6

    move v4, v3

    iget-object v2, p0, Lkotlinx/coroutines/flow/t$g;->b:Li8/q;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v1, v2, p1}, Lkotlinx/coroutines/flow/t$h;-><init>(Li8/q;Lkotlinx/coroutines/flow/j;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {v0, v1, p2}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 p1, 0x1

    const/4 v4, 0x3

    invoke-static {p1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object p1
.end method
