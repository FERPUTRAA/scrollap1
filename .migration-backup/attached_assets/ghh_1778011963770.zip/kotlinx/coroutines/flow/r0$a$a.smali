.class final Lkotlinx/coroutines/flow/r0$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/r0$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlin/jvm/internal/k1$a;

.field final synthetic b:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "Lkotlinx/coroutines/flow/m0;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/k1$a;Lkotlinx/coroutines/flow/j;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/k1$a;",
            "Lkotlinx/coroutines/flow/j<",
            "-",
            "Lkotlinx/coroutines/flow/m0;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/flow/r0$a$a;->a:Lkotlin/jvm/internal/k1$a;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/flow/r0$a$a;->b:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final a(ILkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    const/4 v5, 0x1

    instance-of v0, p2, Lkotlinx/coroutines/flow/r0$a$a$a;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast v0, Lkotlinx/coroutines/flow/r0$a$a$a;

    const/4 v5, 0x0

    iget v1, v0, Lkotlinx/coroutines/flow/r0$a$a$a;->label:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/high16 v2, -0x80000000

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    and-int v3, v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v3, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    sub-int/2addr v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    iput v1, v0, Lkotlinx/coroutines/flow/r0$a$a$a;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v0, Lkotlinx/coroutines/flow/r0$a$a$a;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/r0$a$a$a;-><init>(Lkotlinx/coroutines/flow/r0$a$a;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object p2, v0, Lkotlinx/coroutines/flow/r0$a$a$a;->result:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    iget v2, v0, Lkotlinx/coroutines/flow/r0$a$a$a;->label:I

    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v5, 0x7

    move v4, v3

    move v4, v3

    const/4 v5, 0x3

    if-eqz v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-ne v2, v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const-string p2, "css l ietteaen fber/on///hosilo/tkuvi om /er/u/er c"

    const-string p2, "/esewce v/ t/niaur/ u/frret/otch eeni/ oo mkloil/bs"

    const/4 v5, 0x7

    const-string p2, "oa/msh/ r/bvt/eo iurmt/i /tif loek/cw nconoueeeer l"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    throw p1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-lez p1, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/flow/r0$a$a;->a:Lkotlin/jvm/internal/k1$a;

    const/4 v5, 0x4

    iget-boolean p2, p1, Lkotlin/jvm/internal/k1$a;->element:Z

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-nez p2, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x2

    iput-boolean v3, p1, Lkotlin/jvm/internal/k1$a;->element:Z

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/flow/r0$a$a;->b:Lkotlinx/coroutines/flow/j;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object p2, Lkotlinx/coroutines/flow/m0;->a:Lkotlinx/coroutines/flow/m0;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput v3, v0, Lkotlinx/coroutines/flow/r0$a$a$a;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-interface {p1, p2, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-ne p1, v1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-object v1

    :cond_3
    :goto_1
    const/4 v4, 0x5

    const/4 v5, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x2

    return-object p1

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-object p1
.end method

.method public bridge synthetic emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    check-cast p1, Ljava/lang/Number;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/r0$a$a;->a(ILkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p1
.end method
