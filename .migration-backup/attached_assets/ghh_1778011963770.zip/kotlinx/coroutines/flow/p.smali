.class final synthetic Lkotlinx/coroutines/flow/p;
.super Ljava/lang/Object;


# direct methods
.method public static final synthetic a(Lkotlinx/coroutines/flow/i;I)Lkotlinx/coroutines/flow/i;
    .locals 4
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Since 1.4.0, binary compatibility with earlier versions"
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p0, p1, v0, v1, v0}, Lkotlinx/coroutines/flow/k;->q(Lkotlinx/coroutines/flow/i;ILkotlinx/coroutines/channels/m;ILjava/lang/Object;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public static final b(Lkotlinx/coroutines/flow/i;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/i;
    .locals 11
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;I",
            "Lkotlinx/coroutines/channels/m;",
            ")",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/4 v0, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    const/4 v1, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/4 v2, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    if-gez p1, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    const/4 v3, -0x2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    if-eq p1, v3, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-ne p1, v2, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    goto :goto_0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    move v3, v1

    move v3, v1

    const/4 v10, 0x0

    move v3, v1

    move v3, v1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x4

    move v3, v0

    move v3, v0

    const/4 v10, 0x1

    move v3, v0

    move v3, v0

    :goto_1
    const/4 v10, 0x2

    if-eqz v3, :cond_7

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    if-ne p1, v2, :cond_3

    sget-object v3, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-ne p2, v3, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    goto :goto_2

    :cond_2
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    move v0, v1

    move v0, v1

    const/4 v10, 0x0

    move v0, v1

    move v0, v1

    :cond_3
    :goto_2
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-eqz v0, :cond_6

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-ne p1, v2, :cond_4

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    sget-object p2, Lkotlinx/coroutines/channels/m;->b:Lkotlinx/coroutines/channels/m;

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    move v5, v1

    move v5, v1

    const/4 v10, 0x0

    move v5, v1

    move v5, v1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    goto :goto_3

    :cond_4
    const/4 v10, 0x4

    move v5, p1

    move v5, p1

    const/4 v10, 0x7

    move v5, p1

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    :goto_3
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    instance-of p1, p0, Lkotlinx/coroutines/flow/internal/r;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-eqz p1, :cond_5

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    check-cast v2, Lkotlinx/coroutines/flow/internal/r;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    const/4 v3, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 p0, 0x1

    move v10, p0

    const/4 v9, 0x1

    const/4 v10, 0x7

    const/4 v7, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    move v4, v5

    move v4, v5

    const/4 v10, 0x4

    move v4, v5

    move v4, v5

    move-object v5, v6

    move-object v5, v6

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    move v6, p0

    move v6, p0

    const/4 v10, 0x1

    move v6, p0

    move v6, p0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-static/range {v2 .. v7}, Lkotlinx/coroutines/flow/internal/r$a;->a(Lkotlinx/coroutines/flow/internal/r;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILjava/lang/Object;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x1

    goto :goto_4

    :cond_5
    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    new-instance p1, Lkotlinx/coroutines/flow/internal/i;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    const/4 v4, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/4 v7, 0x2

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v8, 0x0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-direct/range {v2 .. v8}, Lkotlinx/coroutines/flow/internal/i;-><init>(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    :goto_4
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    return-object p0

    :cond_6
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    const-string p1, "EpsnaAelwnrfsyuNnfeeoc-hieor nB  oeDCbOttat ucLsTav  dlfdac OwtiuFn"

    const-string p1, "dhsuwoteantFf anDicOf tlrnrCT sAnNEan adLouuOepofyvet cl Bcwbei-o e"

    const/4 v10, 0x6

    const-string p1, "TwdmOrcetL evno anrDtfatonhed cNuaCti bnucOoyE  ni-Af flauoeBfweFls"

    const-string p1, "CONFLATED capacity cannot be used with non-default onBufferOverflow"

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    throw p0

    :cond_7
    const/4 v9, 0x2

    move v10, v9

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    const-string p2, "osz,o LnatsasuE,rND-bEoFfAi O  FeC ewEibUg,n eo udnhDFBBeeT frvltm R"

    const-string p2, "egfmsFeCe DLNAo-ad,seRiBwu DtEF ,tOuzE  fbrui,hTlovB F rbUo Enesnan "

    const/4 v10, 0x0

    const-string p2, "T buvbflaODFe swF,zA ,tniBN iou eEbDeE f gton rEesFrn,heCRUBLs - duo"

    const-string p2, "Buffer size should be non-negative, BUFFERED, or CONFLATED, but was "

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    throw p1
.end method

.method public static synthetic c(Lkotlinx/coroutines/flow/i;IILjava/lang/Object;)Lkotlinx/coroutines/flow/i;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    if-eqz p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 p1, -0x6

    const/4 p1, -0x2

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lkotlinx/coroutines/flow/k;->n(Lkotlinx/coroutines/flow/i;I)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x5

    return-object p0
.end method

.method public static synthetic d(Lkotlinx/coroutines/flow/i;ILkotlinx/coroutines/channels/m;ILjava/lang/Object;)Lkotlinx/coroutines/flow/i;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    and-int/lit8 p4, p3, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    if-eqz p4, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    const/4 p1, -0x2

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    and-int/lit8 p3, p3, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    if-eqz p3, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    sget-object p2, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/flow/k;->o(Lkotlinx/coroutines/flow/i;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-object p0
.end method

.method public static final e(Lkotlinx/coroutines/flow/i;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    instance-of v0, p0, Lkotlinx/coroutines/flow/c;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Lkotlinx/coroutines/flow/d;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/d;-><init>(Lkotlinx/coroutines/flow/i;)V

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method private static final f(Lkotlin/coroutines/g;)V
    .locals 4

    const/4 v2, 0x2

    move v3, v2

    sget-object v0, Lkotlinx/coroutines/n2;->n0:Lkotlinx/coroutines/n2$b;

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-interface {p0, v0}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v1, "oF tntui ndloncocjix intbn Ha owctt  ea oon"

    const-string v1, "onabooH Fca inctx ina enjnottoi ont wtcd  l"

    const/4 v3, 0x2

    const-string v1, "eHtinodpi. awtoji  cnnnbccx nno  taolt at F"

    const-string v1, "Flow context cannot contain job in it. Had "

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    throw v0
.end method

.method public static final g(Lkotlinx/coroutines/flow/i;)Lkotlinx/coroutines/flow/i;
    .locals 5
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v2, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p0, v2, v0, v1, v0}, Lkotlinx/coroutines/flow/k;->q(Lkotlinx/coroutines/flow/i;ILkotlinx/coroutines/channels/m;ILjava/lang/Object;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object p0
.end method

.method public static final h(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/g;)Lkotlinx/coroutines/flow/i;
    .locals 10
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Lkotlin/coroutines/g;",
            ")",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static {p1}, Lkotlinx/coroutines/flow/p;->f(Lkotlin/coroutines/g;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    sget-object v0, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eqz v0, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    goto :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    instance-of v0, p0, Lkotlinx/coroutines/flow/internal/r;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-eqz v0, :cond_1

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    check-cast v1, Lkotlinx/coroutines/flow/internal/r;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v3, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    const/4 v4, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    const/4 v5, 0x6

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    const/4 v6, 0x0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/flow/internal/r$a;->a(Lkotlinx/coroutines/flow/internal/r;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILjava/lang/Object;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_0

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    new-instance v7, Lkotlinx/coroutines/flow/internal/i;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    const/4 v3, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v4, 0x0

    shr-int/2addr v9, v4

    const/4 v8, 0x1

    shl-int/2addr v9, v8

    const/16 v5, 0xc

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    const/4 v6, 0x0

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct/range {v0 .. v6}, Lkotlinx/coroutines/flow/internal/i;-><init>(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V

    move-object p0, v7

    move-object p0, v7

    move-object p0, v7

    move-object p0, v7

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    return-object p0
.end method
