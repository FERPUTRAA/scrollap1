.class final Lkotlinx/coroutines/flow/r$c$b;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/r$c;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/r<",
        "+",
        "Ljava/lang/Object;",
        ">;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDelay.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/flow/FlowKt__DelayKt$debounceInternal$1$3$2\n+ 2 Channel.kt\nkotlinx/coroutines/channels/ChannelKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 Symbol.kt\nkotlinx/coroutines/internal/Symbol\n*L\n1#1,348:1\n507#2,6:349\n523#2,5:355\n528#2:362\n1#3:360\n18#4:361\n*S KotlinDebug\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/flow/FlowKt__DelayKt$debounceInternal$1$3$2\n*L\n239#1:349,6\n240#1:355,5\n240#1:362\n243#1:361\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__DelayKt$debounceInternal$1$3$2"
    f = "Delay.kt"
    i = {
        0x0
    }
    l = {
        0xf3
    }
    m = "invokeSuspend"
    n = {
        "$this$onFailure_u2dWpGqRn0$iv"
    }
    s = {
        "L$0"
    }
.end annotation


# instance fields
.field final synthetic $downstream:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TT;>;"
        }
    .end annotation
.end field

.field final synthetic $lastValue:Lkotlin/jvm/internal/k1$h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/k1$h;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/r$c$b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/flow/r$c$b;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v1, 0x3

    const/4 v0, 0x3

    iput-object p2, p0, Lkotlinx/coroutines/flow/r$c$b;->$downstream:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/4 p1, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/r$c$b;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/flow/r$c$b;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v2, p0, Lkotlinx/coroutines/flow/r$c$b;->$downstream:Lkotlinx/coroutines/flow/j;

    const/4 v3, 0x5

    move v4, v3

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/flow/r$c$b;-><init>(Lkotlin/jvm/internal/k1$h;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    iput-object p1, v0, Lkotlinx/coroutines/flow/r$c$b;->L$0:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    check-cast p1, Lkotlinx/coroutines/channels/r;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/r;->o()Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    check-cast p2, Lkotlin/coroutines/d;

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/r$c$b;->k(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget v1, p0, Lkotlinx/coroutines/flow/r$c$b;->label:I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    const/4 v2, 0x1

    const/4 v7, 0x1

    if-eqz v1, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-ne v1, v2, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/flow/r$c$b;->L$1:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    check-cast v0, Lkotlin/jvm/internal/k1$h;

    const/4 v6, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string v0, "res  eml /vr i/cfos////uoiou/etb nstrltwohek/co ine"

    const-string v0, "cisr vrlob//is ekuctn e/ iwono//retmeo/ floe/ hute/"

    const/4 v7, 0x1

    const-string v0, "/u/m/em/rw  v/tbl /lcehfoeieto/cau  noii/tko soerne"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    throw p1

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/flow/r$c$b;->L$0:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    check-cast p1, Lkotlinx/coroutines/channels/r;

    const/4 v6, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/r;->o()Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/flow/r$c$b;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    instance-of v3, p1, Lkotlinx/coroutines/channels/r$c;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-nez v3, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    iput-object p1, v1, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x7

    iget-object v4, p0, Lkotlinx/coroutines/flow/r$c$b;->$downstream:Lkotlinx/coroutines/flow/j;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v3, :cond_7

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {p1}, Lkotlinx/coroutines/channels/r;->f(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-nez v3, :cond_6

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v3, v1, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v3, :cond_5

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    sget-object v5, Lkotlinx/coroutines/flow/internal/u;->a:Lkotlinx/coroutines/internal/r0;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-ne v3, v5, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v3, 0x0

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/flow/r$c$b;->L$0:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    iput-object v1, p0, Lkotlinx/coroutines/flow/r$c$b;->L$1:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput v2, p0, Lkotlinx/coroutines/flow/r$c$b;->label:I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-interface {v4, v3, p0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-ne p1, v0, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-object v0

    :cond_4
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_0
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :cond_5
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    sget-object p1, Lkotlinx/coroutines/flow/internal/u;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    iput-object p1, v1, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v7, 0x3

    goto :goto_1

    :cond_6
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    throw v3

    :cond_7
    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x4

    const/4 v6, 0x4

    return-object p1
.end method

.method public final k(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p1}, Lkotlinx/coroutines/channels/r;->b(Ljava/lang/Object;)Lkotlinx/coroutines/channels/r;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/r$c$b;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    check-cast p1, Lkotlinx/coroutines/flow/r$c$b;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/r$c$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method
