.class public final Lkotlinx/coroutines/flow/l$j;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/l;->e(Lkotlin/ranges/l;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "Ljava/lang/Integer;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,112:1\n187#2:113\n188#2,2:115\n190#2:118\n1849#3:114\n1850#3:117\n*S KotlinDebug\n*F\n+ 1 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n*L\n187#1:114\n187#1:117\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Lkotlin/ranges/l;


# direct methods
.method public constructor <init>(Lkotlin/ranges/l;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/flow/l$j;->a:Lkotlin/ranges/l;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-",
            "Ljava/lang/Integer;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x3

    const-string v5, " bs -~~o1nii@~uy~ @@~K~@~@fc @@  @~~@~~.   oafs/~@ ~  ~ Soo~@t~i@~@o~M@rl bt/~b~@@@l@~o m@ dv4 @"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    instance-of v0, p2, Lkotlinx/coroutines/flow/l$j$a;

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    check-cast v0, Lkotlinx/coroutines/flow/l$j$a;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget v1, v0, Lkotlinx/coroutines/flow/l$j$a;->label:I

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/high16 v2, -0x80000000

    const/4 v6, 0x1

    const/4 v5, 0x3

    and-int v3, v1, v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v3, :cond_0

    const/4 v6, 0x3

    sub-int/2addr v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput v1, v0, Lkotlinx/coroutines/flow/l$j$a;->label:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/l$j$a;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/l$j$a;-><init>(Lkotlinx/coroutines/flow/l$j;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v6, 0x3

    iget-object p2, v0, Lkotlinx/coroutines/flow/l$j$a;->result:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget v2, v0, Lkotlinx/coroutines/flow/l$j$a;->label:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v2, :cond_2

    const/4 v6, 0x6

    if-ne v2, v3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object p1, v0, Lkotlinx/coroutines/flow/l$j$a;->L$1:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    check-cast p1, Ljava/util/Iterator;

    const/4 v6, 0x3

    const/4 v5, 0x5

    iget-object v2, v0, Lkotlinx/coroutines/flow/l$j$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x4

    check-cast v2, Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p2, v2

    move-object p2, v2

    move-object p2, v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    goto :goto_1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo p2, "ua/ms/ i/et/eeoo/ubfo c/hr/tcnvsoeotl mlnr i/e kir "

    const-string p2, "cast/oi lorien/ ucs/oee nmhb l/o/ru/fr/voew /etik t"

    const/4 v6, 0x7

    const-string p2, "/haioiubotvm //t/osteee /nro  /rlren/oieuef l/cwko "

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x4

    const/4 v5, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    throw p1

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x3

    iget-object p2, p0, Lkotlinx/coroutines/flow/l$j;->a:Lkotlin/ranges/l;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    :cond_3
    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz v2, :cond_4

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    check-cast v2, Lkotlin/collections/s0;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v2}, Lkotlin/collections/s0;->b()I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v2}, Lkotlin/coroutines/jvm/internal/b;->f(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    iput-object p2, v0, Lkotlinx/coroutines/flow/l$j$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    iput-object p1, v0, Lkotlinx/coroutines/flow/l$j$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    iput v3, v0, Lkotlinx/coroutines/flow/l$j$a;->label:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-interface {p2, v2, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-ne v2, v1, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-object v1

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x1

    return-object p1
.end method
