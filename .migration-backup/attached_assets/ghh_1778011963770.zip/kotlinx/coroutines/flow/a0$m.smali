.class final Lkotlinx/coroutines/flow/a0$m;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/a0;->k(Lkotlinx/coroutines/flow/i;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nTransform.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Transform.kt\nkotlinx/coroutines/flow/FlowKt__TransformKt$withIndex$1$1\n+ 2 FlowExceptions.common.kt\nkotlinx/coroutines/flow/internal/FlowExceptions_commonKt\n*L\n1#1,130:1\n32#2,4:131\n*S KotlinDebug\n*F\n+ 1 Transform.kt\nkotlinx/coroutines/flow/FlowKt__TransformKt$withIndex$1$1\n*L\n65#1:131,4\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "Lkotlin/collections/p0<",
            "+TT;>;>;"
        }
    .end annotation
.end field

.field final synthetic b:Lkotlin/jvm/internal/k1$f;


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/j;Lkotlin/jvm/internal/k1$f;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-",
            "Lkotlin/collections/p0<",
            "+TT;>;>;",
            "Lkotlin/jvm/internal/k1$f;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$m;->a:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p2, p0, Lkotlinx/coroutines/flow/a0$m;->b:Lkotlin/jvm/internal/k1$f;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 9
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    instance-of v0, p2, Lkotlinx/coroutines/flow/a0$m$a;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    check-cast v0, Lkotlinx/coroutines/flow/a0$m$a;

    const/4 v8, 0x1

    const/4 v7, 0x5

    iget v1, v0, Lkotlinx/coroutines/flow/a0$m$a;->label:I

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/high16 v2, -0x80000000

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    and-int v3, v1, v2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz v3, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    sub-int/2addr v1, v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    iput v1, v0, Lkotlinx/coroutines/flow/a0$m$a;->label:I

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/a0$m$a;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/a0$m$a;-><init>(Lkotlinx/coroutines/flow/a0$m;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget-object p2, v0, Lkotlinx/coroutines/flow/a0$m$a;->result:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget v2, v0, Lkotlinx/coroutines/flow/a0$m$a;->label:I

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz v2, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-ne v2, v3, :cond_1

    const/4 v7, 0x0

    move v8, v7

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    goto :goto_1

    :cond_1
    const/4 v7, 0x7

    move v8, v7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x2

    const-string p2, "oaseolre lefnht//net/ re/s/stc i/e/b mro  icuiovowu"

    const-string/jumbo p2, "tusloe t von/fli /i ebtsw/ecoeaeor/cinr/o/u m/eh/ r"

    const-string p2, "i rmive rkch/oaou/ lw/iblt/e/rum cn toe//set oofene"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    throw p1

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    iget-object p2, p0, Lkotlinx/coroutines/flow/a0$m;->a:Lkotlinx/coroutines/flow/j;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    new-instance v2, Lkotlin/collections/p0;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v4, p0, Lkotlinx/coroutines/flow/a0$m;->b:Lkotlin/jvm/internal/k1$f;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget v5, v4, Lkotlin/jvm/internal/k1$f;->element:I

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    add-int/lit8 v6, v5, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x7

    iput v6, v4, Lkotlin/jvm/internal/k1$f;->element:I

    const/4 v8, 0x1

    const/4 v7, 0x4

    if-ltz v5, :cond_4

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-direct {v2, v5, p1}, Lkotlin/collections/p0;-><init>(ILjava/lang/Object;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    iput v3, v0, Lkotlinx/coroutines/flow/a0$m$a;->label:I

    const/4 v8, 0x2

    invoke-interface {p2, v2, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-ne p1, v1, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x1

    return-object v1

    :cond_3
    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-object p1

    :cond_4
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance p1, Ljava/lang/ArithmeticException;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const-string p2, "Index overflow has happened"

    const/4 v8, 0x6

    const/4 v7, 0x0

    invoke-direct {p1, p2}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    throw p1
.end method
