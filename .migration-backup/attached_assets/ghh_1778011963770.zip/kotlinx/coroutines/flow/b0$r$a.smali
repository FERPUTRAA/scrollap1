.class public final Lkotlinx/coroutines/flow/b0$r$a;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0$r;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/a<",
        "[TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nZip.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt$combineTransform$7$1\n*L\n1#1,332:1\n*E\n"
.end annotation


# instance fields
.field final synthetic $flowArray:[Lkotlinx/coroutines/flow/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>([Lkotlinx/coroutines/flow/i;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$r$a;->$flowArray:[Lkotlinx/coroutines/flow/i;

    const/4 v0, 0x7

    move v1, v0

    const/4 p1, 0x0

    xor-int/2addr v1, p1

    const/4 v0, 0x4

    and-int/2addr v1, v0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final c()[Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[TT;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x1

    const-string v3, "b@s S@~ll.@@~~~4~o@ @~~o @r~@ @~1@b~@u~~f@t~f i -K@mM~@io~i  ~@@@~~ ty o@~~b dc v / ~ao~so @n/ @"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/flow/b0$r$a;->$flowArray:[Lkotlinx/coroutines/flow/i;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    array-length v0, v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x1

    or-int/2addr v4, v3

    const-string v2, "T?"

    const-string v2, "?T"

    const/4 v4, 0x0

    const-string v2, "T?"

    const-string v2, "T?"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lkotlinx/coroutines/flow/b0$r$a;->c()[Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method
