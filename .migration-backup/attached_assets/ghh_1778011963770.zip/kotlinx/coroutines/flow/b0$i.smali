.class public final Lkotlinx/coroutines/flow/b0$i;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/q;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0;->g([Lkotlinx/coroutines/flow/i;Li8/p;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/q<",
        "Lkotlinx/coroutines/flow/j<",
        "-TR;>;[TT;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nZip.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt$combine$5$2\n*L\n1#1,332:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__ZipKt$combine$5$2"
    f = "Zip.kt"
    i = {}
    l = {
        0xee,
        0xee
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $transform:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "[TT;",
            "Lkotlin/coroutines/d<",
            "-TR;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field synthetic L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method public constructor <init>(Li8/p;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/p<",
            "-[TT;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/b0$i;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$i;->$transform:Li8/p;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    const/4 p1, 0x3

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "i@s -~  ~~/o@lf@tnb~~ @ @a@~bd@i/ct@K1~b~@~~@ S rm~~o~  @yl.@  @~@@o@@~uo~@ i~vos~f@~  ~M 4@ ~ o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x0

    const/4 v0, 0x0

    check-cast p2, [Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    check-cast p3, Lkotlin/coroutines/d;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/b0$i;->k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v1, p0, Lkotlinx/coroutines/flow/b0$i;->label:I

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v2, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eq v1, v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-ne v1, v2, :cond_0

    const/4 v5, 0x5

    move v6, v5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto/16 :goto_1

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string v0, "ienmoooro/sv i a/werbuernmhsl/e ul/kcc/ e/ /ti/e fo"

    const-string v0, "i/sokio/ru/eoe/vciowofrelem /h bca let/nr /s n ute/"

    const-string/jumbo v0, "voe ol/  niioarn //ub/eo two/erurhteec c/l/iksemt/f"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    throw p1

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$i;->L$0:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    check-cast v1, Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$i;->L$0:Ljava/lang/Object;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    check-cast v1, Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x6

    const/4 v5, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$i;->L$1:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    check-cast p1, [Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v4, p0, Lkotlinx/coroutines/flow/b0$i;->$transform:Li8/p;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object v1, p0, Lkotlinx/coroutines/flow/b0$i;->L$0:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput v3, p0, Lkotlinx/coroutines/flow/b0$i;->label:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {v4, p1, p0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-ne p1, v0, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-object v0

    :cond_3
    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput-object v3, p0, Lkotlinx/coroutines/flow/b0$i;->L$0:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    iput v2, p0, Lkotlinx/coroutines/flow/b0$i;->label:I

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-interface {v1, p1, p0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-ne p1, v0, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-object v0

    :cond_4
    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-object p1
.end method

.method public final invokeSuspend$$forInline(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$i;->L$0:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/flow/b0$i;->L$1:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast v0, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$i;->$transform:Li8/p;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v1, v0, p0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-interface {p1, v0, p0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    const/4 p1, 0x1

    move v3, p1

    const/4 v2, 0x7

    move v3, v2

    invoke-static {p1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v3, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;[TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/b0$i;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$i;->$transform:Li8/p;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0, v1, p3}, Lkotlinx/coroutines/flow/b0$i;-><init>(Li8/p;Lkotlin/coroutines/d;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object p1, v0, Lkotlinx/coroutines/flow/b0$i;->L$0:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object p2, v0, Lkotlinx/coroutines/flow/b0$i;->L$1:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/flow/b0$i;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p1
.end method
