.class final Lkotlinx/coroutines/flow/r$e$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/r$e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/r<",
        "+",
        "Ljava/lang/Object;",
        ">;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDelay.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/flow/FlowKt__DelayKt$sample$2$1$1\n+ 2 Channel.kt\nkotlinx/coroutines/channels/ChannelKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,348:1\n507#2,6:349\n523#2,5:355\n528#2:361\n1#3:360\n*S KotlinDebug\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/flow/FlowKt__DelayKt$sample$2$1$1\n*L\n288#1:349,6\n289#1:355,5\n289#1:361\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__DelayKt$sample$2$1$1"
    f = "Delay.kt"
    i = {}
    l = {}
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $lastValue:Lkotlin/jvm/internal/k1$h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $ticker:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation
.end field

.field synthetic L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/k1$h;Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlinx/coroutines/channels/i0<",
            "Lkotlin/s2;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/r$e$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/flow/r$e$a;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p2, p0, Lkotlinx/coroutines/flow/r$e$a;->$ticker:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 p1, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/r$e$a;

    const/4 v4, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/flow/r$e$a;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v2, p0, Lkotlinx/coroutines/flow/r$e$a;->$ticker:Lkotlinx/coroutines/channels/i0;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/flow/r$e$a;-><init>(Lkotlin/jvm/internal/k1$h;Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-object p1, v0, Lkotlinx/coroutines/flow/r$e$a;->L$0:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    check-cast p1, Lkotlinx/coroutines/channels/r;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/r;->o()Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/r$e$a;->k(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x1

    move v4, v3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v0, p0, Lkotlinx/coroutines/flow/r$e$a;->label:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-nez v0, :cond_3

    const/4 v4, 0x1

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object p1, p0, Lkotlinx/coroutines/flow/r$e$a;->L$0:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x3

    check-cast p1, Lkotlinx/coroutines/channels/r;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/r;->o()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/flow/r$e$a;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    instance-of v1, p1, Lkotlinx/coroutines/channels/r$c;

    const/4 v3, 0x5

    move v4, v3

    if-nez v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object p1, v0, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v2, p0, Lkotlinx/coroutines/flow/r$e$a;->$ticker:Lkotlinx/coroutines/channels/i0;

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {p1}, Lkotlinx/coroutines/channels/r;->f(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    if-nez p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance p1, Lkotlinx/coroutines/flow/internal/l;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {p1}, Lkotlinx/coroutines/flow/internal/l;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {v2, p1}, Lkotlinx/coroutines/channels/i0;->cancel(Ljava/util/concurrent/CancellationException;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    sget-object p1, Lkotlinx/coroutines/flow/internal/u;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object p1, v0, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    throw p1

    :cond_2
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object p1

    :cond_3
    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v0, "oksl v/te/oimreeu rs / a/ofn/ cou ebct/rs//nilehtew"

    const-string/jumbo v0, "ucsufatb/oinevrowh ei/om/nr te l/ c/lsroei /t/k /ee"

    const/4 v4, 0x7

    const-string/jumbo v0, "v tmoe/  k/tne//ou /frieotheo/m/r/ lcliabouriecnwes"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    throw p1
.end method

.method public final k(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p1}, Lkotlinx/coroutines/channels/r;->b(Ljava/lang/Object;)Lkotlinx/coroutines/channels/r;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/r$e$a;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    check-cast p1, Lkotlinx/coroutines/flow/r$e$a;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/r$e$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    return-object p1
.end method
