.class public abstract Lkotlinx/coroutines/flow/a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;
.implements Lkotlinx/coroutines/flow/c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TT;>;",
        "Lkotlinx/coroutines/flow/c<",
        "TT;>;"
    }
.end annotation

.annotation build Lkotlinx/coroutines/d2;
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    instance-of v0, p2, Lkotlinx/coroutines/flow/a$a;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    check-cast v0, Lkotlinx/coroutines/flow/a$a;

    const/4 v5, 0x2

    or-int/2addr v6, v5

    iget v1, v0, Lkotlinx/coroutines/flow/a$a;->label:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/high16 v2, -0x80000000

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    and-int v3, v1, v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    sub-int/2addr v1, v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    iput v1, v0, Lkotlinx/coroutines/flow/a$a;->label:I

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-instance v0, Lkotlinx/coroutines/flow/a$a;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/a$a;-><init>(Lkotlinx/coroutines/flow/a;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object p2, v0, Lkotlinx/coroutines/flow/a$a;->result:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget v2, v0, Lkotlinx/coroutines/flow/a$a;->label:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v3, 0x1

    const/4 v6, 0x3

    if-eqz v2, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-ne v2, v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object p1, v0, Lkotlinx/coroutines/flow/a$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    check-cast p1, Lkotlinx/coroutines/flow/internal/v;

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_1

    :catchall_0
    move-exception p2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_2

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string p2, "t/s/et/swmno h f vseoe/leeci k/ue/i tr o/no/uarcrbo"

    const-string p2, "ios/nc/r/llu/t/oi/ urts eafnce/ eo erok/otem bhvwe "

    const/4 v6, 0x3

    const-string p2, "e/smrt/ec//n/rowkomcvro/e   flb/tteuno /ihiu ielo a"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    throw p1

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance p2, Lkotlinx/coroutines/flow/internal/v;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v0}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    invoke-direct {p2, p1, v2}, Lkotlinx/coroutines/flow/internal/v;-><init>(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/g;)V

    :try_start_1
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    iput-object p2, v0, Lkotlinx/coroutines/flow/a$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput v3, v0, Lkotlinx/coroutines/flow/a$a;->label:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p0, p2, v0}, Lkotlinx/coroutines/flow/a;->f(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-ne p1, v1, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x1

    return-object v1

    :cond_3
    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1}, Lkotlinx/coroutines/flow/internal/v;->releaseIntercepted()V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-object p1

    :catchall_1
    move-exception p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object p2, p1

    move-object p2, p1

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    :goto_2
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1}, Lkotlinx/coroutines/flow/internal/v;->releaseIntercepted()V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    throw p2
.end method

.method public abstract f(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end method
