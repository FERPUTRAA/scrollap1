.class final Lkotlinx/coroutines/flow/r$e$b;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/r$e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlin/s2;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDelay.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/flow/FlowKt__DelayKt$sample$2$1$2\n+ 2 Symbol.kt\nkotlinx/coroutines/internal/Symbol\n*L\n1#1,348:1\n18#2:349\n*S KotlinDebug\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/flow/FlowKt__DelayKt$sample$2$1$2\n*L\n300#1:349\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__DelayKt$sample$2$1$2"
    f = "Delay.kt"
    i = {}
    l = {
        0x12c
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $downstream:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TT;>;"
        }
    .end annotation
.end field

.field final synthetic $lastValue:Lkotlin/jvm/internal/k1$h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field label:I


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/k1$h;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/r$e$b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/flow/r$e$b;->$lastValue:Lkotlin/jvm/internal/k1$h;

    iput-object p2, p0, Lkotlinx/coroutines/flow/r$e$b;->$downstream:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    const/4 p1, 0x2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance p1, Lkotlinx/coroutines/flow/r$e$b;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/flow/r$e$b;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v3, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/flow/r$e$b;->$downstream:Lkotlinx/coroutines/flow/j;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p1, v0, v1, p2}, Lkotlinx/coroutines/flow/r$e$b;-><init>(Lkotlin/jvm/internal/k1$h;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    check-cast p1, Lkotlin/s2;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x1

    const/4 v0, 0x4

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/r$e$b;->k(Lkotlin/s2;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget v1, p0, Lkotlinx/coroutines/flow/r$e$b;->label:I

    const/4 v6, 0x0

    const/4 v2, 0x5

    const/4 v6, 0x2

    const/4 v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-ne v1, v2, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v0, " fsot beu/iteionoiao/v hke lsm/ /nlrwoctu/re//csr/e"

    const-string/jumbo v0, "tmsi/heetub/encr/ lw/i uee/lto/v srooo kion/ca e/rf"

    const/4 v6, 0x4

    const-string v0, "cvkm ibel//eifo /e/u/ rr/owleuotsoantcieeo hn m/r /"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    throw p1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/flow/r$e$b;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v1, p1, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v6, 0x7

    if-nez v1, :cond_2

    const/4 v6, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-object p1

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-object v3, p1, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/flow/r$e$b;->$downstream:Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    sget-object v4, Lkotlinx/coroutines/flow/internal/u;->a:Lkotlinx/coroutines/internal/r0;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-ne v1, v4, :cond_3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x2

    iput v2, p0, Lkotlinx/coroutines/flow/r$e$b;->label:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {p1, v1, p0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-ne p1, v0, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    return-object v0

    :cond_4
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-object p1
.end method

.method public final k(Lkotlin/s2;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlin/s2;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/s2;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/r$e$b;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    check-cast p1, Lkotlinx/coroutines/flow/r$e$b;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/r$e$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p1
.end method
