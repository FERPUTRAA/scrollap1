.class public final Lkotlinx/coroutines/flow/internal/g;
.super Lkotlinx/coroutines/flow/internal/e;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/flow/internal/e<",
        "TT;>;"
    }
.end annotation


# instance fields
.field private final d:Lkotlinx/coroutines/flow/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/i<",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private final e:I


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/i;ILkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p5    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/i<",
            "+",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;>;I",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0, p3, p4, p5}, Lkotlinx/coroutines/flow/internal/e;-><init>(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/g;->d:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p2, p0, Lkotlinx/coroutines/flow/internal/g;->e:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public synthetic constructor <init>(Lkotlinx/coroutines/flow/i;ILkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    and-int/lit8 p7, p6, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz p7, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    sget-object p3, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    :cond_0
    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    and-int/lit8 p3, p6, 0x8

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz p3, :cond_1

    const/4 v7, 0x3

    const/4 p4, -0x2

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    move v4, p4

    move v4, p4

    const/4 v7, 0x6

    move v4, p4

    move v4, p4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    and-int/lit8 p3, p6, 0x10

    const/4 v7, 0x6

    const/4 v6, 0x2

    if-eqz p3, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    sget-object p5, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    :cond_2
    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    move v2, p2

    move v2, p2

    move v2, p2

    move v2, p2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct/range {v0 .. v5}, Lkotlinx/coroutines/flow/internal/g;-><init>(Lkotlinx/coroutines/flow/i;ILkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    return-void
.end method


# virtual methods
.method protected f()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@bs~~Ks -@@~~o@ ~fS4 dol@~@t~ @@t~@o.~r@ ~M ~@~@ @biy/  ivl  muin ~~1@o~@b@~/@~o@a ~~   co@f~~ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "uns=ycnccoer"

    const/4 v3, 0x6

    const-string v1, "nu=moycrrcec"

    const-string v1, "concurrency="

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    iget v1, p0, Lkotlinx/coroutines/flow/internal/g;->e:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0
.end method

.method protected h(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget v0, p0, Lkotlinx/coroutines/flow/internal/g;->e:I

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v6, 0x2

    const/4 v1, 0x2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v6, 0x5

    invoke-static {v0, v3, v1, v2}, Lkotlinx/coroutines/sync/h;->b(IIILjava/lang/Object;)Lkotlinx/coroutines/sync/f;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    new-instance v1, Lkotlinx/coroutines/flow/internal/y;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {v1, p1}, Lkotlinx/coroutines/flow/internal/y;-><init>(Lkotlinx/coroutines/channels/m0;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {p2}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget-object v3, Lkotlinx/coroutines/n2;->n0:Lkotlinx/coroutines/n2$b;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v2, v3}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast v2, Lkotlinx/coroutines/n2;

    const/4 v6, 0x2

    iget-object v3, p0, Lkotlinx/coroutines/flow/internal/g;->d:Lkotlinx/coroutines/flow/i;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-instance v4, Lkotlinx/coroutines/flow/internal/g$a;

    invoke-direct {v4, v2, v0, p1, v1}, Lkotlinx/coroutines/flow/internal/g$a;-><init>(Lkotlinx/coroutines/n2;Lkotlinx/coroutines/sync/f;Lkotlinx/coroutines/channels/g0;Lkotlinx/coroutines/flow/internal/y;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {v3, v4, p2}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x7

    move v6, v5

    if-ne p1, p2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-object p1

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x0

    const/4 v5, 0x7

    return-object p1
.end method

.method protected i(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/internal/e;
    .locals 9
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")",
            "Lkotlinx/coroutines/flow/internal/e<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    new-instance v6, Lkotlinx/coroutines/flow/internal/g;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/g;->d:Lkotlinx/coroutines/flow/i;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget v2, p0, Lkotlinx/coroutines/flow/internal/g;->e:I

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    move v4, p2

    move v4, p2

    move v4, p2

    move v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v8, 0x1

    const/4 v7, 0x5

    invoke-direct/range {v0 .. v5}, Lkotlinx/coroutines/flow/internal/g;-><init>(Lkotlinx/coroutines/flow/i;ILkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    return-object v6
.end method

.method public n(Lkotlinx/coroutines/u0;)Lkotlinx/coroutines/channels/i0;
    .locals 5
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            ")",
            "Lkotlinx/coroutines/channels/i0<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/e;->a:Lkotlin/coroutines/g;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v1, p0, Lkotlinx/coroutines/flow/internal/e;->b:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/flow/internal/e;->l()Li8/p;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p1, v0, v1, v2}, Lkotlinx/coroutines/channels/e0;->c(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILi8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object p1
.end method
