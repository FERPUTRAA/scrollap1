.class final Lkotlinx/coroutines/flow/internal/x$a;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/x;->a(Lkotlinx/coroutines/flow/internal/v;Lkotlin/coroutines/g;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/p<",
        "Ljava/lang/Integer;",
        "Lkotlin/coroutines/g$b;",
        "Ljava/lang/Integer;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic $this_checkContext:Lkotlinx/coroutines/flow/internal/v;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/internal/v<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/internal/v;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/internal/v<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/x$a;->$this_checkContext:Lkotlinx/coroutines/flow/internal/v;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    const/4 p1, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public final c(ILkotlin/coroutines/g$b;)Ljava/lang/Integer;
    .locals 5
    .param p2    # Lkotlin/coroutines/g$b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    invoke-interface {p2}, Lkotlin/coroutines/g$b;->getKey()Lkotlin/coroutines/g$c;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/x$a;->$this_checkContext:Lkotlinx/coroutines/flow/internal/v;

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, v1, Lkotlinx/coroutines/flow/internal/v;->collectContext:Lkotlin/coroutines/g;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {v1, v0}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v2, Lkotlinx/coroutines/n2;->n0:Lkotlinx/coroutines/n2$b;

    const/4 v4, 0x7

    if-eq v0, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eq p2, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/high16 p1, -0x80000000

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    add-int/lit8 p1, p1, 0x1

    :goto_0
    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object p1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    check-cast v1, Lkotlinx/coroutines/n2;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast p2, Lkotlinx/coroutines/n2;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p2, v1}, Lkotlinx/coroutines/flow/internal/x;->b(Lkotlinx/coroutines/n2;Lkotlinx/coroutines/n2;)Lkotlinx/coroutines/n2;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x7

    if-ne p2, v1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-nez v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_1

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    add-int/lit8 p1, p1, 0x1

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object p1

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v2, "dush ln/lcisioe:dsCdn at/aniiiotenvref . oattdeEtceam rfsr ntln nowmFh/o/ssit//i  trtoo vite"

    const-string v2, "iCsfii ltea/tsmtarn//aonon o htevt/enutr ih/ tFfti veEoosdn dsl/e ntd.oa:werin lomoicsd rtci"

    const/4 v4, 0x1

    const-string v2, "scamoF/nvnwn/e mnsetr  s dt:ooivt  oet. hior/Eitdeodialiitnfdnilttuo n/eshirta refo/C tmli/a"

    const-string v2, "Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n\t\tChild of "

    const/4 v3, 0x2

    shr-int/2addr v4, v3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string p2, "cpi oeocfh, ddex e t"

    const-string p2, ", expected child of "

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string p2, "iaemesgst/ ia otiFuc nt/laeifoniieth/ o/m/sohbC-/rnc l Frlo tuoe raerrrp dsfeiehnwnohl  . tctrnttp./nl/so sawbi/sttti/s/de/inimlteeenc fau  dn /esael oocel/witoTandsrdro"

    const/4 v4, 0x3

    const-string p2, "t/fcrbooclili nbfdrttdt/ a.ostdssei/nnote oeceenooaptthehi//c.trllraeewrg nComFt rst /ntaoe/ fob s a/rdanp nicew/  r lsat- lenihisenduitlFut m/wuaiiooih  l/e/Tssr/enis/ "

    const-string p2, ".\n\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n\t\tTo mitigate this restriction please use \'channelFlow\' builder instead of \'flow\'"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    throw p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    check-cast p1, Ljava/lang/Number;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    check-cast p2, Lkotlin/coroutines/g$b;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/x$a;->c(ILkotlin/coroutines/g$b;)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method
