.class final Lkotlinx/coroutines/flow/internal/h$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/h;->r(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/g;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/flow/j<",
        "-TT;>;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.internal.ChannelFlowOperator$collectWithContextUndispatched$2"
    f = "ChannelFlow.kt"
    i = {}
    l = {
        0x98
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field synthetic L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Lkotlinx/coroutines/flow/internal/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/internal/h<",
            "TS;TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/internal/h;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/internal/h<",
            "TS;TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/internal/h$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/h$a;->this$0:Lkotlinx/coroutines/flow/internal/h;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/internal/h$a;

    const/4 v3, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/h$a;->this$0:Lkotlinx/coroutines/flow/internal/h;

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-direct {v0, v1, p2}, Lkotlinx/coroutines/flow/internal/h$a;-><init>(Lkotlinx/coroutines/flow/internal/h;Lkotlin/coroutines/d;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object p1, v0, Lkotlinx/coroutines/flow/internal/h$a;->L$0:Ljava/lang/Object;

    const/4 v2, 0x3

    and-int/2addr v3, v2

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x2

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x4

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/h$a;->invoke(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/h$a;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    check-cast p1, Lkotlinx/coroutines/flow/internal/h$a;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/internal/h$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget v1, p0, Lkotlinx/coroutines/flow/internal/h$a;->label:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-ne v1, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const-string v0, "//si/rrnek/cuwi etote nl osmbh/o/ eoas ficvrute e//"

    const-string v0, "mrsbr/ife/tsec w k r eh/iun/oteo//a/ec  nue/otvloio"

    const/4 v4, 0x4

    const-string v0, "/ermen ov/kaebcoourrs/ t oh/iuet/oc/t/ ewfnili/elm "

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw p1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/h$a;->L$0:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/h$a;->this$0:Lkotlinx/coroutines/flow/internal/h;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput v2, p0, Lkotlinx/coroutines/flow/internal/h$a;->label:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, p1, p0}, Lkotlinx/coroutines/flow/internal/h;->s(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-ne p1, v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x4

    return-object v0

    :cond_2
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object p1
.end method
