.class public final Lkotlinx/coroutines/flow/internal/y;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j<",
        "TT;>;"
    }
.end annotation

.annotation build Lkotlinx/coroutines/i2;
.end annotation


# instance fields
.field private final a:Lkotlinx/coroutines/channels/m0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/m0<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/channels/m0;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/m0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/m0<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/y;->a:Lkotlinx/coroutines/channels/m0;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 3
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/y;->a:Lkotlinx/coroutines/channels/m0;

    const/4 v1, 0x3

    move v2, v1

    invoke-interface {v0, p1, p2}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-ne p1, p2, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p1
.end method
