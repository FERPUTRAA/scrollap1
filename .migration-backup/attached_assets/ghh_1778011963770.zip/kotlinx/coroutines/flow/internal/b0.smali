.class final Lkotlinx/coroutines/flow/internal/b0;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j<",
        "TT;>;"
    }
.end annotation


# instance fields
.field private final a:Lkotlin/coroutines/g;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final b:Ljava/lang/Object;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final c:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/g;)V
    .locals 3
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/g;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/b0;->a:Lkotlin/coroutines/g;

    const/4 v2, 0x2

    invoke-static {p2}, Lkotlinx/coroutines/internal/w0;->b(Lkotlin/coroutines/g;)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/b0;->b:Ljava/lang/Object;

    const/4 v1, 0x7

    and-int/2addr v2, v1

    new-instance p2, Lkotlinx/coroutines/flow/internal/b0$a;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-direct {p2, p1, v0}, Lkotlinx/coroutines/flow/internal/b0$a;-><init>(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/b0;->c:Li8/p;

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/b0;->a:Lkotlin/coroutines/g;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/b0;->b:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v2, p0, Lkotlinx/coroutines/flow/internal/b0;->c:Li8/p;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v0, p1, v1, v2, p2}, Lkotlinx/coroutines/flow/internal/f;->c(Lkotlin/coroutines/g;Ljava/lang/Object;Ljava/lang/Object;Li8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-ne p1, p2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object p1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object p1
.end method
