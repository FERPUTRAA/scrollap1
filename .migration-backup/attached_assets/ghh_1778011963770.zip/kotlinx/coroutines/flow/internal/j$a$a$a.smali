.class final Lkotlinx/coroutines/flow/internal/j$a$a$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/j$a$a;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/u0;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.internal.ChannelFlowTransformLatest$flowCollect$3$1$2"
    f = "Merge.kt"
    i = {}
    l = {
        0x22
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $collector:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TR;>;"
        }
    .end annotation
.end field

.field final synthetic $value:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field label:I

.field final synthetic this$0:Lkotlinx/coroutines/flow/internal/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/internal/j<",
            "TT;TR;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/internal/j;Lkotlinx/coroutines/flow/j;Ljava/lang/Object;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/internal/j<",
            "TT;TR;>;",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/internal/j$a$a$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/j$a$a$a;->this$0:Lkotlinx/coroutines/flow/internal/j;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/j$a$a$a;->$collector:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p3, p0, Lkotlinx/coroutines/flow/internal/j$a$a$a;->$value:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance p1, Lkotlinx/coroutines/flow/internal/j$a$a$a;

    const/4 v3, 0x0

    and-int/2addr v4, v3

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/j$a$a$a;->this$0:Lkotlinx/coroutines/flow/internal/j;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/j$a$a$a;->$collector:Lkotlinx/coroutines/flow/j;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v2, p0, Lkotlinx/coroutines/flow/internal/j$a$a$a;->$value:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-direct {p1, v0, v1, v2, p2}, Lkotlinx/coroutines/flow/internal/j$a$a$a;-><init>(Lkotlinx/coroutines/flow/internal/j;Lkotlinx/coroutines/flow/j;Ljava/lang/Object;Lkotlin/coroutines/d;)V

    const/4 v3, 0x2

    const/4 v3, 0x1

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/j$a$a$a;->invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/j$a$a$a;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    check-cast p1, Lkotlinx/coroutines/flow/internal/j$a$a$a;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/internal/j$a$a$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v1, p0, Lkotlinx/coroutines/flow/internal/j$a$a$a;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-ne v1, v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v0, "i/srli rskeowuctr/fte /o i/ eu/ton/eb/leosncomv a/h"

    const-string v0, " fsnuitlue eroetaecrmew/ovo/sto///lr/ n obhice //ki"

    const/4 v5, 0x5

    const-string v0, "o cm u /fteea/c/u/et/ /oevonrlierwntlhrs m/k iei/bo"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    throw p1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/j$a$a$a;->this$0:Lkotlinx/coroutines/flow/internal/j;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p1}, Lkotlinx/coroutines/flow/internal/j;->t(Lkotlinx/coroutines/flow/internal/j;)Li8/q;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/j$a$a$a;->$collector:Lkotlinx/coroutines/flow/j;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v3, p0, Lkotlinx/coroutines/flow/internal/j$a$a$a;->$value:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    iput v2, p0, Lkotlinx/coroutines/flow/internal/j$a$a$a;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {p1, v1, v3, p0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ne p1, v0, :cond_2

    const/4 v4, 0x1

    move v5, v4

    return-object v0

    :cond_2
    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x2

    const/4 v4, 0x0

    return-object p1
.end method
