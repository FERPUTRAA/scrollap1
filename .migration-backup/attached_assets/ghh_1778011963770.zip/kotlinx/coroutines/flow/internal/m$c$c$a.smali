.class final Lkotlinx/coroutines/flow/internal/m$c$c$a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/m$c$c;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/channels/g0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/g0<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/g0;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/m$c$c$a;->a:Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT2;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    instance-of v0, p2, Lkotlinx/coroutines/flow/internal/m$c$c$a$a;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v5, 0x6

    const/4 v4, 0x3

    check-cast v0, Lkotlinx/coroutines/flow/internal/m$c$c$a$a;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget v1, v0, Lkotlinx/coroutines/flow/internal/m$c$c$a$a;->label:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/high16 v2, -0x80000000

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    and-int v3, v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    sub-int/2addr v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput v1, v0, Lkotlinx/coroutines/flow/internal/m$c$c$a$a;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/internal/m$c$c$a$a;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/internal/m$c$c$a$a;-><init>(Lkotlinx/coroutines/flow/internal/m$c$c$a;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object p2, v0, Lkotlinx/coroutines/flow/internal/m$c$c$a$a;->result:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v2, v0, Lkotlinx/coroutines/flow/internal/m$c$c$a$a;->label:I

    const/4 v5, 0x5

    const/4 v3, 0x6

    const/4 v5, 0x7

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ne v2, v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string p2, "l swnans b huut/okv eeoil/o//fcceiieemer t /to/o//s"

    const-string p2, "o s wbm etnooesoe eu i/n/khtl e/l//actiiue/v/forr/c"

    const/4 v5, 0x4

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    throw p1

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object p2, p0, Lkotlinx/coroutines/flow/internal/m$c$c$a;->a:Lkotlinx/coroutines/channels/g0;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {p2}, Lkotlinx/coroutines/channels/g0;->getChannel()Lkotlinx/coroutines/channels/m0;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez p1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget-object p1, Lkotlinx/coroutines/flow/internal/u;->a:Lkotlinx/coroutines/internal/r0;

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput v3, v0, Lkotlinx/coroutines/flow/internal/m$c$c$a$a;->label:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {p2, p1, v0}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-ne p1, v1, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object v1

    :cond_4
    :goto_1
    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-object p1
.end method
