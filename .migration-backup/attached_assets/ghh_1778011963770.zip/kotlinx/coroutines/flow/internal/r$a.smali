.class public final Lkotlinx/coroutines/flow/internal/r$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/flow/internal/r;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static synthetic a(Lkotlinx/coroutines/flow/internal/r;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILjava/lang/Object;)Lkotlinx/coroutines/flow/i;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@1s @~u ~o@~ ~f~l@@ f@@@db~M~i~ t@@nocK S~~ o/~  .lo~ ~@~ r@ti/  @b@-s @~@v@am~4b~~ @~y @ o~~i@o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    if-nez p5, :cond_3

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    and-int/lit8 p5, p4, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-eqz p5, :cond_0

    const/4 v0, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    sget-object p1, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    and-int/lit8 p5, p4, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-eqz p5, :cond_1

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 p2, -0x3

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    and-int/lit8 p4, p4, 0x4

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    if-eqz p4, :cond_2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    sget-object p3, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    :cond_2
    const/4 v1, 0x4

    invoke-interface {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/internal/r;->b(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0

    :cond_3
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const-string/jumbo p1, "tcsln ,ni:gsreemfpihhute fnfotiuutt Stesa  ngoo rtiaa rtl wt ssuacnl ddeuu prps"

    const/4 v1, 0x7

    const-string p1, "  nmotrltrdp,staisneufsu:ee ttp hoptshaloiitwngntaeaSferfcu  c nigde ml rts  uu"

    const-string p1, "Super calls with default arguments not supported in this target, function: fuse"

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    throw p0
.end method
