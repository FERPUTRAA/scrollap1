.class public final Lkotlinx/coroutines/flow/internal/v;
.super Lkotlin/coroutines/jvm/internal/d;

# interfaces
.implements Lkotlinx/coroutines/flow/j;
.implements Lkotlin/coroutines/jvm/internal/e;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlin/coroutines/jvm/internal/d;",
        "Lkotlinx/coroutines/flow/j<",
        "TT;>;",
        "Lkotlin/coroutines/jvm/internal/e;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.kt\nkotlinx/coroutines/flow/internal/SafeCollector\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,156:1\n1#2:157\n*E\n"
.end annotation


# instance fields
.field public final collectContext:Lkotlin/coroutines/g;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public final collectContextSize:I
    .annotation build Lh8/e;
    .end annotation
.end field

.field public final collector:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private completion:Lkotlin/coroutines/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field private lastEmissionContext:Lkotlin/coroutines/g;
    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/g;)V
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/g;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v0, Lkotlinx/coroutines/flow/internal/s;->a:Lkotlinx/coroutines/flow/internal/s;

    const/4 v3, 0x1

    const/4 v2, 0x5

    sget-object v1, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0, v0, v1}, Lkotlin/coroutines/jvm/internal/d;-><init>(Lkotlin/coroutines/d;Lkotlin/coroutines/g;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/v;->collector:Lkotlinx/coroutines/flow/j;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/v;->collectContext:Lkotlin/coroutines/g;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 p1, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v0, Lkotlinx/coroutines/flow/internal/v$a;->a:Lkotlinx/coroutines/flow/internal/v$a;

    const/4 v3, 0x3

    invoke-interface {p2, p1, v0}, Lkotlin/coroutines/g;->fold(Ljava/lang/Object;Li8/p;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast p1, Ljava/lang/Number;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput p1, p0, Lkotlinx/coroutines/flow/internal/v;->collectContextSize:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method private final k(Lkotlin/coroutines/g;Lkotlin/coroutines/g;Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "Lkotlin/coroutines/g;",
            "TT;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ slo~ o    a~~~i~f~/~m@  b@ @u@@ ns~@~~~1f / v~i@~@dlo b@@oKiS~ ~@o~c~~4o@~r~@M~@~ . y@ t@@b@t@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    instance-of v0, p2, Lkotlinx/coroutines/flow/internal/n;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast p2, Lkotlinx/coroutines/flow/internal/n;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, p2, p3}, Lkotlinx/coroutines/flow/internal/v;->p(Lkotlinx/coroutines/flow/internal/n;Ljava/lang/Object;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p0, p1}, Lkotlinx/coroutines/flow/internal/x;->a(Lkotlinx/coroutines/flow/internal/v;Lkotlin/coroutines/g;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method private final l(Lkotlin/coroutines/d;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;TT;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {p1}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Lkotlinx/coroutines/r2;->z(Lkotlin/coroutines/g;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/v;->lastEmissionContext:Lkotlin/coroutines/g;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eq v1, v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0, v0, v1, p2}, Lkotlinx/coroutines/flow/internal/v;->k(Lkotlin/coroutines/g;Lkotlin/coroutines/g;Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lkotlinx/coroutines/flow/internal/v;->lastEmissionContext:Lkotlin/coroutines/g;

    :cond_0
    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/v;->completion:Lkotlin/coroutines/d;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {}, Lkotlinx/coroutines/flow/internal/w;->a()Li8/q;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/v;->collector:Lkotlinx/coroutines/flow/j;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {p1, v0, p2, p0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez p2, :cond_1

    const/4 v3, 0x3

    const/4 p2, 0x0

    const/4 v3, 0x7

    shr-int/2addr v2, p2

    const/4 v3, 0x2

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/v;->completion:Lkotlin/coroutines/d;

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p1
.end method

.method private final p(Lkotlinx/coroutines/flow/internal/n;Ljava/lang/Object;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v2, " t mm o   usyhlneovnrxan/seo i  lh  t eow/ s pivs e ai /r  a /ot :ioPpetep  F wt//arccntr c   clen si  xnei  a  n  d"

    const-string v2, "osser:lw  n yi t idsat vpe nic  o/r n ee F pp o  ch   annalr  /xs xi  tc /vre c/ eeao n   ew/o m/os Phil t nt lauti "

    const/4 v4, 0x4

    const-string v2, "n   oea sxavcF wy/a :c tov rct n     i   /  hien e/isrP  poirusl/dt oelcinnroml    /ns ihx /ntlt pa   eetp  oo ee wa"

    const-string v2, "\n            Flow exception transparency is violated:\n                Previous \'emit\' call has thrown exception "

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object p1, p1, Lkotlinx/coroutines/flow/internal/n;->a:Ljava/lang/Throwable;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string p1, "nsetob amtnl/istoeummptav  /tf ue  bhi,"

    const-string/jumbo p1, "to,mhiaoftb  smaues/tpltunmv n te  ie/e"

    const/4 v4, 0x5

    const-string p1, "opnoleutttma eh uf t/ e /m inuv aes,sbi"

    const-string p1, ", but then emission attempt of value \'"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string p1, " imv lwpe/etar x o,ascia  ErsbrFsoo oa ndoiodceup/ l  eheoe oe    raoc/ait rapa   enmheh oeerao cr .loe tr  tlf eccr / /bmo.n s /n/de    eetr adonu    odFd //b .ldiiw cf f sapi cp  oi / s/i   esi .d  enFbkp ntc  ueotst br   nnmeata  vnditdee unode htt isn/, ai ear  ol/ h"

    const-string p1, "e i ot   b eomeno.tet   /e/ra  ti c c re/a n o//elr td snarccen/ ip seinsaa fomaf uk sh ep ni  el  o// eiFv eot i  d  os ln rwe ,oo hv p,ificaaos  ttdbp   o ruh/Fiun i tteuodis/  l on her.bdio c. elawoesreet Eensad/ co mdnr e brr bdaa/ F  d dt lomn/ dr xet e  o cp hac.aa"

    const/4 v4, 0x7

    const-string p1, "\' has been detected.\n                Emissions from \'catch\' blocks are prohibited in order to avoid unspecified behaviour, \'Flow.catch\' operator can be used instead.\n                For a more detailed explanation, please refer to Flow documentation.\n            "

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p1}, Lkotlin/text/v;->p(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    throw v0
.end method


# virtual methods
.method public emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 3
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, p2, p1}, Lkotlinx/coroutines/flow/internal/v;->l(Lkotlin/coroutines/d;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-ne p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p2}, Lkotlin/coroutines/jvm/internal/h;->c(Lkotlin/coroutines/d;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne p1, p2, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/internal/n;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {p2}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {v0, p1, p2}, Lkotlinx/coroutines/flow/internal/n;-><init>(Ljava/lang/Throwable;Lkotlin/coroutines/g;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lkotlinx/coroutines/flow/internal/v;->lastEmissionContext:Lkotlin/coroutines/g;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    throw p1
.end method

.method public getCallerFrame()Lkotlin/coroutines/jvm/internal/e;
    .locals 4
    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/v;->completion:Lkotlin/coroutines/d;

    const/4 v3, 0x5

    const/4 v2, 0x4

    instance-of v1, v0, Lkotlin/coroutines/jvm/internal/e;

    const/4 v2, 0x6

    move v3, v2

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    check-cast v0, Lkotlin/coroutines/jvm/internal/e;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public getContext()Lkotlin/coroutines/g;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/v;->lastEmissionContext:Lkotlin/coroutines/g;

    const/4 v2, 0x5

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    :cond_0
    const/4 v2, 0x6

    return-object v0
.end method

.method public getStackTraceElement()Ljava/lang/StackTraceElement;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1}, Lkotlin/d1;->e(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v1, Lkotlinx/coroutines/flow/internal/n;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Lkotlinx/coroutines/flow/internal/v;->getContext()Lkotlin/coroutines/g;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v1, v0, v2}, Lkotlinx/coroutines/flow/internal/n;-><init>(Ljava/lang/Throwable;Lkotlin/coroutines/g;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object v1, p0, Lkotlinx/coroutines/flow/internal/v;->lastEmissionContext:Lkotlin/coroutines/g;

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/v;->completion:Lkotlin/coroutines/d;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {v0, p1}, Lkotlin/coroutines/d;->resumeWith(Ljava/lang/Object;)V

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object p1
.end method

.method public releaseIntercepted()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-super {p0}, Lkotlin/coroutines/jvm/internal/d;->releaseIntercepted()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
