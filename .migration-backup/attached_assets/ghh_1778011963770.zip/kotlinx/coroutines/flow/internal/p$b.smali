.class final Lkotlinx/coroutines/flow/internal/p$b;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/p;->b(Li8/q;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/u0;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.internal.FlowCoroutineKt$scopedFlow$1$1"
    f = "FlowCoroutine.kt"
    i = {}
    l = {
        0x33
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $block:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "Lkotlinx/coroutines/u0;",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $this_unsafeFlow:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TR;>;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Li8/q;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/q<",
            "-",
            "Lkotlinx/coroutines/u0;",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/internal/p$b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/p$b;->$block:Li8/q;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/p$b;->$this_unsafeFlow:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 p1, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/internal/p$b;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/p$b;->$block:Li8/q;

    const/4 v4, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/flow/internal/p$b;->$this_unsafeFlow:Lkotlinx/coroutines/flow/j;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/flow/internal/p$b;-><init>(Li8/q;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-object p1, v0, Lkotlinx/coroutines/flow/internal/p$b;->L$0:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/p$b;->invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/p$b;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    check-cast p1, Lkotlinx/coroutines/flow/internal/p$b;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/internal/p$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget v1, p0, Lkotlinx/coroutines/flow/internal/p$b;->label:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-ne v1, v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v0, "tls nveotes teok/ oicireiouue//awfser/om/h/nrb/l c "

    const-string v0, "c skfi/e/hlm /eoinoo//vwt sutolor/ c eeibear/ uetnr"

    const/4 v5, 0x1

    const-string v0, "ct m///i h uutr/merel  ke/eoinvotow//obsclneiref o/"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    throw p1

    :cond_1
    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/p$b;->L$0:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v5, 0x2

    const/4 v4, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/p$b;->$block:Li8/q;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v3, p0, Lkotlinx/coroutines/flow/internal/p$b;->$this_unsafeFlow:Lkotlinx/coroutines/flow/j;

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput v2, p0, Lkotlinx/coroutines/flow/internal/p$b;->label:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v1, p1, v3, p0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-ne p1, v0, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object v0

    :cond_2
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object p1
.end method
