.class public final Lkotlinx/coroutines/flow/internal/q;
.super Ljava/lang/Object;


# direct methods
.method public static final a(I)I
    .locals 3
    .annotation build Lkotlin/a1;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~sy~a@ ~b~o@ @l~@s~t~@  @~tbo@@~~MKf4 /~o -~   bo@ ~@@ @ou/@@@fri~ ~~~mn @l@i.Svc~d ~~~@1 @ ~o@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    if-ltz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance p0, Ljava/lang/ArithmeticException;

    const/4 v2, 0x7

    const-string v0, "  pmheeesahdoeofsdw rpvxInn"

    const-string v0, "dlss  hawIpronxf ndehevpeoe"

    const/4 v2, 0x5

    const-string/jumbo v0, "vpaso eelenI xorpeoadwfhdhn"

    const-string v0, "Index overflow has happened"

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-direct {p0, v0}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    throw p0
.end method

.method public static final b(Lkotlinx/coroutines/flow/internal/a;Lkotlinx/coroutines/flow/j;)V
    .locals 3
    .param p0    # Lkotlinx/coroutines/flow/internal/a;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/internal/a;",
            "Lkotlinx/coroutines/flow/j<",
            "*>;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/a;->a:Lkotlinx/coroutines/flow/j;

    const/4 v2, 0x1

    if-ne v0, p1, :cond_0

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    throw p0
.end method
