.class final Lkotlinx/coroutines/flow/internal/m$c$b$a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/m$c$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlin/coroutines/g;

.field final synthetic b:Ljava/lang/Object;

.field final synthetic c:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic d:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TR;>;"
        }
    .end annotation
.end field

.field final synthetic e:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "TT1;TT2;",
            "Lkotlin/coroutines/d<",
            "-TR;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlin/coroutines/g;Ljava/lang/Object;Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/flow/j;Li8/q;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "Ljava/lang/Object;",
            "Lkotlinx/coroutines/channels/i0<",
            "+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Li8/q<",
            "-TT1;-TT2;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/m$c$b$a;->a:Lkotlin/coroutines/g;

    const/4 v1, 0x3

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/m$c$b$a;->b:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p3, p0, Lkotlinx/coroutines/flow/internal/m$c$b$a;->c:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p4, p0, Lkotlinx/coroutines/flow/internal/m$c$b$a;->d:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p5, p0, Lkotlinx/coroutines/flow/internal/m$c$b$a;->e:Li8/q;

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 13
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT1;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v12, 0x3

    instance-of v0, p2, Lkotlinx/coroutines/flow/internal/m$c$b$a$b;

    const/4 v12, 0x3

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v12, 0x5

    check-cast v0, Lkotlinx/coroutines/flow/internal/m$c$b$a$b;

    const/4 v12, 0x1

    iget v1, v0, Lkotlinx/coroutines/flow/internal/m$c$b$a$b;->label:I

    const/4 v12, 0x6

    const/high16 v2, -0x80000000

    const/4 v12, 0x0

    and-int v3, v1, v2

    if-eqz v3, :cond_0

    const/4 v12, 0x7

    sub-int/2addr v1, v2

    const/4 v12, 0x2

    iput v1, v0, Lkotlinx/coroutines/flow/internal/m$c$b$a$b;->label:I

    const/4 v12, 0x4

    goto :goto_0

    :cond_0
    const/4 v12, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/internal/m$c$b$a$b;

    const/4 v12, 0x0

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/internal/m$c$b$a$b;-><init>(Lkotlinx/coroutines/flow/internal/m$c$b$a;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v12, 0x1

    iget-object p2, v0, Lkotlinx/coroutines/flow/internal/m$c$b$a$b;->result:Ljava/lang/Object;

    const/4 v12, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v12, 0x5

    iget v2, v0, Lkotlinx/coroutines/flow/internal/m$c$b$a$b;->label:I

    const/4 v12, 0x3

    const/4 v3, 0x1

    const/4 v12, 0x6

    if-eqz v2, :cond_2

    const/4 v12, 0x0

    if-ne v2, v3, :cond_1

    const/4 v12, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v12, 0x3

    goto :goto_1

    :cond_1
    const/4 v12, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v12, 0x2

    const-string p2, "o/seka/nvtlolrso // meii hieur o//eu/bwercen/sc tto"

    const-string/jumbo p2, "wrseneeb/lo  /e n meoou/hiurr vcttl/s//eaoktc/o i/i"

    const-string p2, "slrmecorn/m/h e/blnuei/fec /ero/i ko twva/oout/ iet"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v12, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x2

    throw p1

    :cond_2
    const/4 v12, 0x2

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v12, 0x2

    iget-object p2, p0, Lkotlinx/coroutines/flow/internal/m$c$b$a;->a:Lkotlin/coroutines/g;

    const/4 v12, 0x3

    sget-object v2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v12, 0x2

    iget-object v4, p0, Lkotlinx/coroutines/flow/internal/m$c$b$a;->b:Ljava/lang/Object;

    const/4 v12, 0x4

    new-instance v11, Lkotlinx/coroutines/flow/internal/m$c$b$a$a;

    const/4 v12, 0x3

    iget-object v6, p0, Lkotlinx/coroutines/flow/internal/m$c$b$a;->c:Lkotlinx/coroutines/channels/i0;

    const/4 v12, 0x6

    iget-object v7, p0, Lkotlinx/coroutines/flow/internal/m$c$b$a;->d:Lkotlinx/coroutines/flow/j;

    const/4 v12, 0x3

    iget-object v8, p0, Lkotlinx/coroutines/flow/internal/m$c$b$a;->e:Li8/q;

    const/4 v12, 0x7

    const/4 v10, 0x0

    move-object v5, v11

    move-object v5, v11

    move-object v5, v11

    move-object v5, v11

    move-object v9, p1

    move-object v9, p1

    move-object v9, p1

    move-object v9, p1

    const/4 v12, 0x2

    invoke-direct/range {v5 .. v10}, Lkotlinx/coroutines/flow/internal/m$c$b$a$a;-><init>(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/flow/j;Li8/q;Ljava/lang/Object;Lkotlin/coroutines/d;)V

    const/4 v12, 0x0

    iput v3, v0, Lkotlinx/coroutines/flow/internal/m$c$b$a$b;->label:I

    const/4 v12, 0x4

    invoke-static {p2, v2, v4, v11, v0}, Lkotlinx/coroutines/flow/internal/f;->c(Lkotlin/coroutines/g;Ljava/lang/Object;Ljava/lang/Object;Li8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x3

    if-ne p1, v1, :cond_3

    const/4 v12, 0x6

    return-object v1

    :cond_3
    :goto_1
    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v12, 0x1

    return-object p1
.end method
