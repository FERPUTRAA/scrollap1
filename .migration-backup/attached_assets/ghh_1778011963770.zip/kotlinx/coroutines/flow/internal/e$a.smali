.class final Lkotlinx/coroutines/flow/internal/e$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/e;->g(Lkotlinx/coroutines/flow/internal/e;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/u0;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.internal.ChannelFlow$collect$2"
    f = "ChannelFlow.kt"
    i = {}
    l = {
        0x7b
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $collector:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TT;>;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Lkotlinx/coroutines/flow/internal/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/internal/e<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/j;Lkotlinx/coroutines/flow/internal/e;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlinx/coroutines/flow/internal/e<",
            "TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/internal/e$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/e$a;->$collector:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x1

    const/4 v0, 0x6

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/e$a;->this$0:Lkotlinx/coroutines/flow/internal/e;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    const/4 p1, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x1

    const-string v3, " ts.~~r~ c1~lb@ ~@~K@ y~o@~/@~un@@S~v~~@~ ~@~i/  bo~f Midt~o -@f o4 @@~@~@l o @ma~~ i@~@   @@@os"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    new-instance v0, Lkotlinx/coroutines/flow/internal/e$a;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/e$a;->$collector:Lkotlinx/coroutines/flow/j;

    const/4 v4, 0x6

    const/4 v3, 0x1

    iget-object v2, p0, Lkotlinx/coroutines/flow/internal/e$a;->this$0:Lkotlinx/coroutines/flow/internal/e;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/flow/internal/e$a;-><init>(Lkotlinx/coroutines/flow/j;Lkotlinx/coroutines/flow/internal/e;Lkotlin/coroutines/d;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput-object p1, v0, Lkotlinx/coroutines/flow/internal/e$a;->L$0:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v1, 0x0

    const/4 v0, 0x6

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/e$a;->invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/e$a;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    check-cast p1, Lkotlinx/coroutines/flow/internal/e$a;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/internal/e$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v1, p0, Lkotlinx/coroutines/flow/internal/e$a;->label:I

    const/4 v4, 0x0

    move v5, v4

    const/4 v2, 0x1

    xor-int/2addr v5, v2

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    if-ne v1, v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string v0, "/iom  etlcuove r frto elatm/ohk/u/si/ennsocre/b i/w"

    const-string v0, "mist rlui ek / /ne/ecol/wobnr tootfiauc/ee/ro /hv/s"

    const/4 v5, 0x2

    const-string v0, "ceooo/uh re //lto/v/reeia/lrti cmfe o/ibnts ouen/k "

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    throw p1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/e$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/e$a;->$collector:Lkotlinx/coroutines/flow/j;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v3, p0, Lkotlinx/coroutines/flow/internal/e$a;->this$0:Lkotlinx/coroutines/flow/internal/e;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v3, p1}, Lkotlinx/coroutines/flow/internal/e;->n(Lkotlinx/coroutines/u0;)Lkotlinx/coroutines/channels/i0;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput v2, p0, Lkotlinx/coroutines/flow/internal/e$a;->label:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v1, p1, p0}, Lkotlinx/coroutines/flow/k;->l0(Lkotlinx/coroutines/flow/j;Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    if-ne p1, v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-object v0

    :cond_2
    :goto_0
    const/4 v5, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x5

    move v5, v4

    return-object p1
.end method
