.class final Lkotlinx/coroutines/flow/internal/m$a$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/m$a$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/channels/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/n<",
            "Lkotlin/collections/p0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field final synthetic b:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/n;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/n<",
            "Lkotlin/collections/p0<",
            "Ljava/lang/Object;",
            ">;>;I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/m$a$a$a;->a:Lkotlinx/coroutines/channels/n;

    const/4 v0, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p2, p0, Lkotlinx/coroutines/flow/internal/m$a$a$a;->b:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 8
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    instance-of v0, p2, Lkotlinx/coroutines/flow/internal/m$a$a$a$a;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    check-cast v0, Lkotlinx/coroutines/flow/internal/m$a$a$a$a;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget v1, v0, Lkotlinx/coroutines/flow/internal/m$a$a$a$a;->label:I

    const/4 v6, 0x7

    move v7, v6

    const/high16 v2, -0x80000000

    const/4 v6, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    and-int v3, v1, v2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v3, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    sub-int/2addr v1, v2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    iput v1, v0, Lkotlinx/coroutines/flow/internal/m$a$a$a$a;->label:I

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/internal/m$a$a$a$a;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/internal/m$a$a$a$a;-><init>(Lkotlinx/coroutines/flow/internal/m$a$a$a;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object p2, v0, Lkotlinx/coroutines/flow/internal/m$a$a$a$a;->result:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget v2, v0, Lkotlinx/coroutines/flow/internal/m$a$a$a$a;->label:I

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 v3, 0x2

    const/4 v7, 0x0

    const/4 v4, 0x2

    const/4 v7, 0x0

    const/4 v4, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-eqz v2, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eq v2, v4, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-ne v2, v3, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    goto :goto_2

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x6

    const-string p2, "emsoe/ouinrclrev cf broonket te/s  ih/uwe//al/os//i"

    const-string p2, "bvsu/rw thsi ce//koe ntla er//teofe/mooinro/ielc u/"

    const/4 v7, 0x0

    const-string p2, "/w miik ueetale/oof/ /tuvoteno//i/shorrn/ lrebm ecc"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    throw p1

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_1

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object p2, p0, Lkotlinx/coroutines/flow/internal/m$a$a$a;->a:Lkotlinx/coroutines/channels/n;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    new-instance v2, Lkotlin/collections/p0;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget v5, p0, Lkotlinx/coroutines/flow/internal/m$a$a$a;->b:I

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {v2, v5, p1}, Lkotlin/collections/p0;-><init>(ILjava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    iput v4, v0, Lkotlinx/coroutines/flow/internal/m$a$a$a$a;->label:I

    invoke-interface {p2, v2, v0}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-ne p1, v1, :cond_4

    const/4 v7, 0x5

    return-object v1

    :cond_4
    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    iput v3, v0, Lkotlinx/coroutines/flow/internal/m$a$a$a$a;->label:I

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {v0}, Lkotlinx/coroutines/f4;->a(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-ne p1, v1, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-object v1

    :cond_5
    :goto_2
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    return-object p1
.end method
