.class public final Lkotlinx/coroutines/flow/internal/k;
.super Lkotlinx/coroutines/flow/internal/e;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/flow/internal/e<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nMerge.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Merge.kt\nkotlinx/coroutines/flow/internal/ChannelLimitedFlowMerge\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,100:1\n1849#2,2:101\n*S KotlinDebug\n*F\n+ 1 Merge.kt\nkotlinx/coroutines/flow/internal/ChannelLimitedFlowMerge\n*L\n95#1:101,2\n*E\n"
.end annotation


# instance fields
.field private final d:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Iterable;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V
    .locals 2
    .param p1    # Ljava/lang/Iterable;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;>;",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p2, p3, p4}, Lkotlinx/coroutines/flow/internal/e;-><init>(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/k;->d:Ljava/lang/Iterable;

    const/4 v1, 0x2

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Iterable;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x7

    and-int/lit8 p6, p5, 0x2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    if-eqz p6, :cond_0

    const/4 v0, 0x2

    move v1, v0

    sget-object p2, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    :cond_0
    const/4 v0, 0x3

    move v1, v0

    and-int/lit8 p6, p5, 0x4

    const/4 v1, 0x0

    const/4 v0, 0x3

    if-eqz p6, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    const/4 p3, -0x2

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    and-int/lit8 p5, p5, 0x8

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    if-eqz p5, :cond_2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    sget-object p4, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    :cond_2
    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/flow/internal/k;-><init>(Ljava/lang/Iterable;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method protected h(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 10
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x7

    const/4 v9, 0x6

    new-instance p2, Lkotlinx/coroutines/flow/internal/y;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-direct {p2, p1}, Lkotlinx/coroutines/flow/internal/y;-><init>(Lkotlinx/coroutines/channels/m0;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/k;->d:Ljava/lang/Iterable;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x7

    if-eqz v1, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    check-cast v1, Lkotlinx/coroutines/flow/i;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    const/4 v4, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    new-instance v5, Lkotlinx/coroutines/flow/internal/k$a;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    const/4 v2, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-direct {v5, v1, p2, v2}, Lkotlinx/coroutines/flow/internal/k$a;-><init>(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/internal/y;Lkotlin/coroutines/d;)V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    const/4 v6, 0x3

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/4 v7, 0x0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static/range {v2 .. v7}, Lkotlinx/coroutines/j;->e(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;Lkotlinx/coroutines/w0;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/n2;

    const/4 v9, 0x4

    goto :goto_0

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x0

    const/4 v9, 0x2

    return-object p1
.end method

.method protected i(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/internal/e;
    .locals 4
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")",
            "Lkotlinx/coroutines/flow/internal/e<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/internal/k;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/k;->d:Ljava/lang/Iterable;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, v1, p1, p2, p3}, Lkotlinx/coroutines/flow/internal/k;-><init>(Ljava/lang/Iterable;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method public n(Lkotlinx/coroutines/u0;)Lkotlinx/coroutines/channels/i0;
    .locals 5
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            ")",
            "Lkotlinx/coroutines/channels/i0<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/e;->a:Lkotlin/coroutines/g;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget v1, p0, Lkotlinx/coroutines/flow/internal/e;->b:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/flow/internal/e;->l()Li8/p;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p1, v0, v1, v2}, Lkotlinx/coroutines/channels/e0;->c(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILi8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object p1
.end method
