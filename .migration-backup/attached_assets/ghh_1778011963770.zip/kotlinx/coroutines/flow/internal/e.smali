.class public abstract Lkotlinx/coroutines/flow/internal/e;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/internal/r;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/internal/r<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nChannelFlow.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ChannelFlow.kt\nkotlinx/coroutines/flow/internal/ChannelFlow\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,245:1\n1#2:246\n*E\n"
.end annotation

.annotation build Lkotlinx/coroutines/i2;
.end annotation


# instance fields
.field public final a:Lkotlin/coroutines/g;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public final b:I
    .annotation build Lh8/e;
    .end annotation
.end field

.field public final c:Lkotlinx/coroutines/channels/m;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V
    .locals 2
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/e;->a:Lkotlin/coroutines/g;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p2, p0, Lkotlinx/coroutines/flow/internal/e;->b:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p3, p0, Lkotlinx/coroutines/flow/internal/e;->c:Lkotlinx/coroutines/channels/m;

    const/4 v1, 0x6

    const/4 v0, 0x6

    return-void
.end method

.method static synthetic g(Lkotlinx/coroutines/flow/internal/e;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ s @~b~~i v~@o@~@@@@y~os~@d@~ 1fna~b~~~~@o o  @~4 ~@@i @ @u S/@r~ @t~ ~K@ @m~M/.cl~ib~ tf~o lo "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    new-instance v0, Lkotlinx/coroutines/flow/internal/e$a;

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    move v2, v1

    move v2, v1

    const/4 v3, 0x4

    invoke-direct {v0, p1, p0, v1}, Lkotlinx/coroutines/flow/internal/e$a;-><init>(Lkotlinx/coroutines/flow/j;Lkotlinx/coroutines/flow/internal/e;Lkotlin/coroutines/d;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0, p2}, Lkotlinx/coroutines/v0;->g(Li8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ne p0, p1, :cond_0

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object p0
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/e;->g(Lkotlinx/coroutines/flow/internal/e;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p1
.end method

.method public b(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/e;->a:Lkotlin/coroutines/g;

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-interface {p1, v0}, Lkotlin/coroutines/g;->plus(Lkotlin/coroutines/g;)Lkotlin/coroutines/g;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    sget-object v0, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eq p3, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_2

    :cond_0
    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget p3, p0, Lkotlinx/coroutines/flow/internal/e;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, -0x3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-ne p3, v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_1

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-ne p2, v0, :cond_2

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    move p2, p3

    move p2, p3

    const/4 v2, 0x1

    move p2, p3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_1

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, -0x2

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-ne p3, v0, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_1

    :cond_3
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-ne p2, v0, :cond_4

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_4
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    add-int/2addr p3, p2

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-ltz p3, :cond_5

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_5
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const p2, 0x7fffffff

    :goto_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p3, p0, Lkotlinx/coroutines/flow/internal/e;->c:Lkotlinx/coroutines/channels/m;

    :goto_2
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/e;->a:Lkotlin/coroutines/g;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_6

    const/4 v2, 0x7

    const/4 v1, 0x5

    iget v0, p0, Lkotlinx/coroutines/flow/internal/e;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-ne p2, v0, :cond_6

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/e;->c:Lkotlinx/coroutines/channels/m;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-ne p3, v0, :cond_6

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0

    :cond_6
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/internal/e;->i(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/internal/e;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    return-object p1
.end method

.method protected f()Ljava/lang/String;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method protected abstract h(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end method

.method protected abstract i(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/internal/e;
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")",
            "Lkotlinx/coroutines/flow/internal/e<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end method

.method public k()Lkotlinx/coroutines/flow/i;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public final l()Li8/p;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Li8/p<",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    new-instance v0, Lkotlinx/coroutines/flow/internal/e$b;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, p0, v1}, Lkotlinx/coroutines/flow/internal/e$b;-><init>(Lkotlinx/coroutines/flow/internal/e;Lkotlin/coroutines/d;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0
.end method

.method public final m()I
    .locals 4

    const/4 v3, 0x2

    iget v0, p0, Lkotlinx/coroutines/flow/internal/e;->b:I

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, -0x3

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v0, -0x2

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v0
.end method

.method public n(Lkotlinx/coroutines/u0;)Lkotlinx/coroutines/channels/i0;
    .locals 11
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            ")",
            "Lkotlinx/coroutines/channels/i0<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/e;->a:Lkotlin/coroutines/g;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {p0}, Lkotlinx/coroutines/flow/internal/e;->m()I

    move-result v2

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget-object v3, p0, Lkotlinx/coroutines/flow/internal/e;->c:Lkotlinx/coroutines/channels/m;

    const/4 v10, 0x2

    const/4 v9, 0x4

    sget-object v4, Lkotlinx/coroutines/w0;->c:Lkotlinx/coroutines/w0;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v5, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/flow/internal/e;->l()Li8/p;

    move-result-object v6

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/16 v7, 0x10

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    const/4 v8, 0x0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static/range {v0 .. v8}, Lkotlinx/coroutines/channels/e0;->h(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;Lkotlinx/coroutines/w0;Li8/l;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 12
    .annotation build Lia/d;
    .end annotation

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    const/4 v1, 0x4

    const/4 v11, 0x4

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/flow/internal/e;->f()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eqz v1, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/e;->a:Lkotlin/coroutines/g;

    const/4 v11, 0x4

    sget-object v2, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-eq v1, v2, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-string v2, "nx=mesoc"

    const-string v2, "nxs=tcoe"

    const/4 v11, 0x2

    const-string/jumbo v2, "xe=notot"

    const-string v2, "context="

    const/4 v11, 0x6

    const/4 v10, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    iget-object v2, p0, Lkotlinx/coroutines/flow/internal/e;->a:Lkotlin/coroutines/g;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    iget v1, p0, Lkotlinx/coroutines/flow/internal/e;->b:I

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    const/4 v2, -0x3

    const/4 v10, 0x3

    move v11, v10

    if-eq v1, v2, :cond_2

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    const-string/jumbo v2, "ycpmabtai"

    const-string/jumbo v2, "ycamiatpc"

    const/4 v11, 0x3

    const-string v2, "caticau=y"

    const-string v2, "capacity="

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    iget v2, p0, Lkotlinx/coroutines/flow/internal/e;->b:I

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/e;->c:Lkotlinx/coroutines/channels/m;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    sget-object v2, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-eq v1, v2, :cond_3

    const/4 v11, 0x5

    const/4 v10, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    const-string v2, "fefone=puOwlfvroo"

    const-string/jumbo v2, "uefBo=weolfrvOonf"

    const-string v2, "onBufferOverflow="

    const/4 v10, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget-object v2, p0, Lkotlinx/coroutines/flow/internal/e;->c:Lkotlinx/coroutines/channels/m;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_3
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    new-instance v9, Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static {p0}, Lkotlinx/coroutines/z0;->a(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/16 v1, 0x5b

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string v1, ", "

    const-string v1, ", "

    const/4 v11, 0x0

    const-string v1, ", "

    const-string v1, ", "

    const/4 v11, 0x4

    const/4 v2, 0x7

    const/4 v11, 0x4

    const/4 v2, 0x0

    const/4 v10, 0x5

    shl-int/2addr v11, v10

    const/4 v3, 0x0

    shl-int/2addr v11, v3

    const/4 v10, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    const/4 v4, 0x0

    const/4 v11, 0x4

    const/4 v5, 0x0

    const/4 v11, 0x5

    move v10, v5

    move v10, v5

    const/4 v11, 0x4

    const/4 v6, 0x0

    const/4 v11, 0x2

    move v10, v6

    move v10, v6

    const/4 v11, 0x1

    const/16 v7, 0x3e

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    const/4 v8, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static/range {v0 .. v8}, Lkotlin/collections/u;->j3(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Li8/l;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x1

    const/16 v0, 0x5d

    const/4 v11, 0x7

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x3

    return-object v0
.end method
