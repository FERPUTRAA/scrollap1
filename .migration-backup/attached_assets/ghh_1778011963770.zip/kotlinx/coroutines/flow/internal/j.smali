.class public final Lkotlinx/coroutines/flow/internal/j;
.super Lkotlinx/coroutines/flow/internal/h;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/flow/internal/h<",
        "TT;TR;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nMerge.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Merge.kt\nkotlinx/coroutines/flow/internal/ChannelFlowTransformLatest\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,100:1\n1#2:101\n*E\n"
.end annotation


# instance fields
.field private final e:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Li8/q;Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V
    .locals 2
    .param p1    # Li8/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p5    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/q<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-TT;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p2, p3, p4, p5}, Lkotlinx/coroutines/flow/internal/h;-><init>(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/j;->e:Li8/q;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public synthetic constructor <init>(Li8/q;Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    and-int/lit8 p7, p6, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz p7, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    sget-object p3, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    :cond_0
    move-object v3, p3

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    and-int/lit8 p3, p6, 0x8

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz p3, :cond_1

    const/4 v6, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 p4, -0x2

    :cond_1
    const/4 v6, 0x5

    const/4 v7, 0x2

    move v4, p4

    move v4, p4

    move v4, p4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    and-int/lit8 p3, p6, 0x10

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz p3, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    sget-object p5, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    :cond_2
    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct/range {v0 .. v5}, Lkotlinx/coroutines/flow/internal/j;-><init>(Li8/q;Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-void
.end method

.method public static final synthetic t(Lkotlinx/coroutines/flow/internal/j;)Li8/q;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "v~s~f d~~@nuo@~~@@~m~o~oS~~ @tb -K1/   4 @o@~@ i c~@bt i@@@~~~~if~  os@@@ @@/roMl@~~~y  l.@~b  a"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p0, p0, Lkotlinx/coroutines/flow/internal/j;->e:Li8/q;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method


# virtual methods
.method protected i(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/internal/e;
    .locals 9
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")",
            "Lkotlinx/coroutines/flow/internal/e<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-instance v6, Lkotlinx/coroutines/flow/internal/j;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/j;->e:Li8/q;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v2, p0, Lkotlinx/coroutines/flow/internal/h;->d:Lkotlinx/coroutines/flow/i;

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    move v4, p2

    move v4, p2

    move v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-direct/range {v0 .. v5}, Lkotlinx/coroutines/flow/internal/j;-><init>(Li8/q;Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v7, 0x5

    shr-int/2addr v8, v7

    return-object v6
.end method

.method protected s(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Lkotlinx/coroutines/flow/internal/j$a;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v0, p0, p1, v1}, Lkotlinx/coroutines/flow/internal/j$a;-><init>(Lkotlinx/coroutines/flow/internal/j;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0, p2}, Lkotlinx/coroutines/v0;->g(Li8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ne p1, p2, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p1
.end method
