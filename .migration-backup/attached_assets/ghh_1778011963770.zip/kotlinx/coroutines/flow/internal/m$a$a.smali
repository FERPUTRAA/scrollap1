.class final Lkotlinx/coroutines/flow/internal/m$a$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/m$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/u0;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.internal.CombineKt$combineInternal$2$1"
    f = "Combine.kt"
    i = {}
    l = {
        0x22
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $flows:[Lkotlinx/coroutines/flow/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation
.end field

.field final synthetic $i:I

.field final synthetic $nonClosed:Ljava/util/concurrent/atomic/AtomicInteger;

.field final synthetic $resultChannel:Lkotlinx/coroutines/channels/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/n<",
            "Lkotlin/collections/p0<",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field label:I


# direct methods
.method constructor <init>([Lkotlinx/coroutines/flow/i;ILjava/util/concurrent/atomic/AtomicInteger;Lkotlinx/coroutines/channels/n;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;I",
            "Ljava/util/concurrent/atomic/AtomicInteger;",
            "Lkotlinx/coroutines/channels/n<",
            "Lkotlin/collections/p0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/internal/m$a$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$flows:[Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput p2, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$i:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p3, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$nonClosed:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p4, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$resultChannel:Lkotlinx/coroutines/channels/n;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 p1, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 8
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance p1, Lkotlinx/coroutines/flow/internal/m$a$a;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$flows:[Lkotlinx/coroutines/flow/i;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget v2, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$i:I

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v3, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$nonClosed:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v4, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$resultChannel:Lkotlinx/coroutines/channels/n;

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct/range {v0 .. v5}, Lkotlinx/coroutines/flow/internal/m$a$a;-><init>([Lkotlinx/coroutines/flow/i;ILjava/util/concurrent/atomic/AtomicInteger;Lkotlinx/coroutines/channels/n;Lkotlin/coroutines/d;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/m$a$a;->invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/m$a$a;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    check-cast p1, Lkotlinx/coroutines/flow/internal/m$a$a;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/internal/m$a$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget v1, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->label:I

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-eqz v1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-ne v1, v3, :cond_0

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto :goto_1

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string v0, "oesfum/v uisk/ot/w one/co  /etar hbr/l/celrnstii eo"

    const-string v0, "rosvih/noekut ///aoimu/ ib /er/ enofsto wel/lrecc t"

    const/4 v7, 0x3

    const-string v0, "ei/mi// /ace/suu/l oe / nfloeehtbirotkmo o nwcrev/r"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    throw p1

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$flows:[Lkotlinx/coroutines/flow/i;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget v1, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$i:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    aget-object p1, p1, v1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    new-instance v4, Lkotlinx/coroutines/flow/internal/m$a$a$a;

    const/4 v7, 0x0

    const/4 v6, 0x0

    iget-object v5, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$resultChannel:Lkotlinx/coroutines/channels/n;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {v4, v5, v1}, Lkotlinx/coroutines/flow/internal/m$a$a$a;-><init>(Lkotlinx/coroutines/channels/n;I)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    iput v3, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->label:I

    const/4 v6, 0x0

    xor-int/2addr v7, v6

    invoke-interface {p1, v4, p0}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-ne p1, v0, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    return-object v0

    :cond_2
    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$nonClosed:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-nez p1, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$resultChannel:Lkotlinx/coroutines/channels/n;

    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-static {p1, v2, v3, v2}, Lkotlinx/coroutines/channels/m0$a;->a(Lkotlinx/coroutines/channels/m0;Ljava/lang/Throwable;ILjava/lang/Object;)Z

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    return-object p1

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$nonClosed:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x4

    if-nez v0, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/m$a$a;->$resultChannel:Lkotlinx/coroutines/channels/n;

    const/4 v7, 0x6

    const/4 v6, 0x5

    invoke-static {v0, v2, v3, v2}, Lkotlinx/coroutines/channels/m0$a;->a(Lkotlinx/coroutines/channels/m0;Ljava/lang/Throwable;ILjava/lang/Object;)Z

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    throw p1
.end method
