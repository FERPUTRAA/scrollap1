.class final Lkotlinx/coroutines/flow/internal/j$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/j;->s(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/u0;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.internal.ChannelFlowTransformLatest$flowCollect$3"
    f = "Merge.kt"
    i = {}
    l = {
        0x1b
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $collector:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TR;>;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Lkotlinx/coroutines/flow/internal/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/internal/j<",
            "TT;TR;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/internal/j;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/internal/j<",
            "TT;TR;>;",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/internal/j$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/j$a;->this$0:Lkotlinx/coroutines/flow/internal/j;

    const/4 v1, 0x1

    const/4 v0, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/j$a;->$collector:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p1, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/internal/j$a;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/j$a;->this$0:Lkotlinx/coroutines/flow/internal/j;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v2, p0, Lkotlinx/coroutines/flow/internal/j$a;->$collector:Lkotlinx/coroutines/flow/j;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/flow/internal/j$a;-><init>(Lkotlinx/coroutines/flow/internal/j;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-object p1, v0, Lkotlinx/coroutines/flow/internal/j$a;->L$0:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x0

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/j$a;->invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/j$a;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    check-cast p1, Lkotlinx/coroutines/flow/internal/j$a;

    const/4 v1, 0x7

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/internal/j$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget v1, p0, Lkotlinx/coroutines/flow/internal/j$a;->label:I

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v2, 0x1

    move v8, v2

    if-eqz v1, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    if-ne v1, v2, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string v0, "e se uio/moa/nr / iirco/ebl//erous/nwclohke ttvf /e"

    const/4 v8, 0x6

    const-string v0, "/bsumi t rc /owk lee/ooei i/vtnl/ur/teh/oer noa/esf"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    throw p1

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v8, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/j$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    new-instance v1, Lkotlin/jvm/internal/k1$h;

    const/4 v7, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {v1}, Lkotlin/jvm/internal/k1$h;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x4

    iget-object v3, p0, Lkotlinx/coroutines/flow/internal/j$a;->this$0:Lkotlinx/coroutines/flow/internal/j;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v4, v3, Lkotlinx/coroutines/flow/internal/h;->d:Lkotlinx/coroutines/flow/i;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-instance v5, Lkotlinx/coroutines/flow/internal/j$a$a;

    const/4 v7, 0x7

    or-int/2addr v8, v7

    iget-object v6, p0, Lkotlinx/coroutines/flow/internal/j$a;->$collector:Lkotlinx/coroutines/flow/j;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-direct {v5, v1, p1, v3, v6}, Lkotlinx/coroutines/flow/internal/j$a$a;-><init>(Lkotlin/jvm/internal/k1$h;Lkotlinx/coroutines/u0;Lkotlinx/coroutines/flow/internal/j;Lkotlinx/coroutines/flow/j;)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    iput v2, p0, Lkotlinx/coroutines/flow/internal/j$a;->label:I

    const/4 v8, 0x2

    const/4 v7, 0x1

    invoke-interface {v4, v5, p0}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-ne p1, v0, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    return-object v0

    :cond_2
    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    return-object p1
.end method
