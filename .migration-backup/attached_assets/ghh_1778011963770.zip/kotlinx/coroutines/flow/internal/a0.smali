.class final Lkotlinx/coroutines/flow/internal/a0;
.super Lkotlinx/coroutines/flow/j0;

# interfaces
.implements Lkotlinx/coroutines/flow/t0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlinx/coroutines/flow/j0<",
        "Ljava/lang/Integer;",
        ">;",
        "Lkotlinx/coroutines/flow/t0<",
        "Ljava/lang/Integer;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAbstractSharedFlow.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AbstractSharedFlow.kt\nkotlinx/coroutines/flow/internal/SubscriptionCountStateFlow\n+ 2 Synchronized.kt\nkotlinx/coroutines/internal/SynchronizedKt\n*L\n1#1,135:1\n20#2:136\n20#2:137\n*S KotlinDebug\n*F\n+ 1 AbstractSharedFlow.kt\nkotlinx/coroutines/flow/internal/SubscriptionCountStateFlow\n*L\n129#1:136\n131#1:137\n*E\n"
.end annotation


# direct methods
.method public constructor <init>(I)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const v0, 0x7fffffff

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-object v1, Lkotlinx/coroutines/channels/m;->b:Lkotlinx/coroutines/channels/m;

    const/4 v4, 0x2

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {p0, v2, v0, v1}, Lkotlinx/coroutines/flow/j0;-><init>(IILkotlinx/coroutines/channels/m;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/flow/j0;->c(Ljava/lang/Object;)Z

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method


# virtual methods
.method public e0()Ljava/lang/Integer;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sy@.aboo@@ ~@vc@n ~t u@@b r~1@o l  f4i~o@@s i-dif/~~@~t ~~@@m~~K @~@ ~~~o@ S ~o@~@/~l ~  ~M @~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    invoke-virtual {p0}, Lkotlinx/coroutines/flow/j0;->Q()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast v0, Ljava/lang/Number;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    throw v0
.end method

.method public final f0(I)Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/flow/j0;->Q()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    check-cast v0, Ljava/lang/Number;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    add-int/2addr v0, p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/flow/j0;->c(Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x7

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x5

    throw p1
.end method

.method public bridge synthetic getValue()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/flow/internal/a0;->e0()Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method
