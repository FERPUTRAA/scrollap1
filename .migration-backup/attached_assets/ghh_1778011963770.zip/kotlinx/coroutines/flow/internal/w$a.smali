.class final synthetic Lkotlinx/coroutines/flow/internal/w$a;
.super Lkotlin/jvm/internal/h0;

# interfaces
.implements Li8/q;
.implements Lkotlin/coroutines/jvm/internal/n;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/flow/internal/w;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1000
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/h0;",
        "Li8/q<",
        "Lkotlinx/coroutines/flow/j<",
        "-",
        "Ljava/lang/Object;",
        ">;",
        "Ljava/lang/Object;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;",
        "Lkotlin/coroutines/jvm/internal/n;"
    }
.end annotation


# static fields
.field public static final a:Lkotlinx/coroutines/flow/internal/w$a;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance v0, Lkotlinx/coroutines/flow/internal/w$a;

    const/4 v1, 0x4

    move v2, v1

    invoke-direct {v0}, Lkotlinx/coroutines/flow/internal/w$a;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    sput-object v0, Lkotlinx/coroutines/flow/internal/w$a;->a:Lkotlinx/coroutines/flow/internal/w$a;

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method constructor <init>()V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    const/4 v1, 0x3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-class v2, Lkotlinx/coroutines/flow/j;

    const/4 v7, 0x0

    const-class v2, Lkotlinx/coroutines/flow/j;

    const-class v2, Lkotlinx/coroutines/flow/j;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string/jumbo v3, "tmie"

    const-string/jumbo v3, "temi"

    const/4 v7, 0x7

    const-string v3, "imet"

    const-string v3, "emit"

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string v4, "egsatl/OebLjcannritanjeCenivn/atOlujcisot/aaii);Lo/nomg;(nLactlottb/kjs;v/"

    const-string v4, "/csaotaljL;t/vmaCluitjntbosiact/nl()ornnkn;/cteuentOj/anjioiOe;egbL/avLaig"

    const/4 v7, 0x2

    const-string v4, "t(nmCboogutj;i/Omocnja;alco/et/tvjnilcuLi;e/eaL)iaenOvliaj/atLgbsat/tnkorn"

    const-string v4, "emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-direct/range {v0 .. v5}, Lkotlin/jvm/internal/h0;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-void
.end method


# virtual methods
.method public final a0(Lkotlinx/coroutines/flow/j;Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-interface {p1, p2, p3}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x1

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    check-cast p3, Lkotlin/coroutines/d;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/internal/w$a;->a0(Lkotlinx/coroutines/flow/j;Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    return-object p1
.end method
