.class public final Lkotlinx/coroutines/flow/internal/x;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lkotlinx/coroutines/flow/internal/v;Lkotlin/coroutines/g;)V
    .locals 5
    .param p0    # Lkotlinx/coroutines/flow/internal/v;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/internal/v<",
            "*>;",
            "Lkotlin/coroutines/g;",
            ")V"
        }
    .end annotation

    .annotation build Lh8/h;
        name = "checkContext"
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance v1, Lkotlinx/coroutines/flow/internal/x$a;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {v1, p0}, Lkotlinx/coroutines/flow/internal/x$a;-><init>(Lkotlinx/coroutines/flow/internal/v;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {p1, v0, v1}, Lkotlin/coroutines/g;->fold(Ljava/lang/Object;Li8/p;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    check-cast v0, Ljava/lang/Number;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v1, p0, Lkotlinx/coroutines/flow/internal/v;->collectContextSize:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-ne v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v2, "o sid /lvetadnaw FconFno/v stie/ nlwsaltclwriat tioi l:"

    const-string v2, "lts: rtetollcaa nFwi/Fdivl dwoitil/i snaev  nnoowt ce/a"

    const/4 v4, 0x6

    const-string v2, "o/nmiidl t/esna  nccosevowvFFrawtala i/d let ll twiin:o"

    const-string v2, "Flow invariant is violated:\n\t\tFlow was collected in "

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object p0, p0, Lkotlinx/coroutines/flow/internal/v;->collectContext:Lkotlin/coroutines/g;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v3, 0x6

    const-string/jumbo p0, "ubmso nntimee/o/ detanp hn/it ,p"

    const-string p0, "it muio ide ,etnn /empnnhpt/b/sa"

    const/4 v4, 0x3

    const-string/jumbo p0, "umh ibeeno pi//nbt stt/sde,pnina"

    const-string p0, ",\n\t\tbut emission happened in "

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const-string p0, "O/coP u /dosonisfnin/ eew uolen/dertwoof u//e t/lnmtea se o/f.t/rlraa/t"

    const-string p0, " /eoooentddere ffi//nne lo//imswno/a te/Pur/s/ a/r.toolclaestOwnf  t /u"

    const/4 v4, 0x7

    const-string p0, "a/eul epcwar aP//t/deu/e/ftrolteorts/f //nnnoosfi/ nt. /m teOl esnooi d"

    const-string p0, ".\n\t\tPlease refer to \'flow\' documentation or use \'flowOn\' instead"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    throw v0
.end method

.method public static final b(Lkotlinx/coroutines/n2;Lkotlinx/coroutines/n2;)Lkotlinx/coroutines/n2;
    .locals 3
    .param p0    # Lkotlinx/coroutines/n2;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/n2;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    :goto_0
    const/4 v1, 0x4

    const/4 v1, 0x6

    if-nez p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-ne p0, p1, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    instance-of v0, p0, Lkotlinx/coroutines/internal/n0;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p0

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    check-cast p0, Lkotlinx/coroutines/internal/n0;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Lkotlinx/coroutines/internal/n0;->j1()Lkotlinx/coroutines/n2;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0
.end method

.method public static final c(Li8/p;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Li8/p;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/internal/x$b;

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/internal/x$b;-><init>(Li8/p;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method
