.class final Lkotlinx/coroutines/flow/internal/g$a$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/g$a;->a(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/u0;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.internal.ChannelFlowMerge$collectTo$2$1"
    f = "Merge.kt"
    i = {}
    l = {
        0x45
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $collector:Lkotlinx/coroutines/flow/internal/y;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/internal/y<",
            "TT;>;"
        }
    .end annotation
.end field

.field final synthetic $inner:Lkotlinx/coroutines/flow/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation
.end field

.field final synthetic $semaphore:Lkotlinx/coroutines/sync/f;

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/internal/y;Lkotlinx/coroutines/sync/f;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Lkotlinx/coroutines/flow/internal/y<",
            "TT;>;",
            "Lkotlinx/coroutines/sync/f;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/internal/g$a$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->$inner:Lkotlinx/coroutines/flow/i;

    const/4 v0, 0x5

    move v1, v0

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->$collector:Lkotlinx/coroutines/flow/internal/y;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p3, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->$semaphore:Lkotlinx/coroutines/sync/f;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 p1, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance p1, Lkotlinx/coroutines/flow/internal/g$a$a;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->$inner:Lkotlinx/coroutines/flow/i;

    const/4 v4, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->$collector:Lkotlinx/coroutines/flow/internal/y;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v2, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->$semaphore:Lkotlinx/coroutines/sync/f;

    const/4 v4, 0x7

    const/4 v3, 0x6

    invoke-direct {p1, v0, v1, v2, p2}, Lkotlinx/coroutines/flow/internal/g$a$a;-><init>(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/internal/y;Lkotlinx/coroutines/sync/f;Lkotlin/coroutines/d;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/g$a$a;->invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/g$a$a;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    check-cast p1, Lkotlinx/coroutines/flow/internal/g$a$a;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/internal/g$a$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget v1, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->label:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x3

    if-eqz v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    if-ne v1, v2, :cond_0

    :try_start_0
    const/4 v4, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v0, "fts/m cb eren/l/ihwstcu/kiouaeo o il/r/o/tv eeo/ne "

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    throw p1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    :try_start_1
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->$inner:Lkotlinx/coroutines/flow/i;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->$collector:Lkotlinx/coroutines/flow/internal/y;

    const/4 v4, 0x4

    iput v2, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->label:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {p1, v1, p0}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-ne p1, v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object v0

    :cond_2
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->$semaphore:Lkotlinx/coroutines/sync/f;

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {p1}, Lkotlinx/coroutines/sync/f;->release()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-object p1

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/flow/internal/g$a$a;->$semaphore:Lkotlinx/coroutines/sync/f;

    const/4 v4, 0x6

    invoke-interface {v0}, Lkotlinx/coroutines/sync/f;->release()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    throw p1
.end method
