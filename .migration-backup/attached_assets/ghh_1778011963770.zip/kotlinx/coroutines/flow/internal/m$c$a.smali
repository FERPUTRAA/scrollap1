.class final Lkotlinx/coroutines/flow/internal/m$c$a;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/m$c;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/l<",
        "Ljava/lang/Throwable;",
        "Lkotlin/s2;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic $collectJob:Lkotlinx/coroutines/c0;

.field final synthetic $this_unsafeFlow:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TR;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/c0;Lkotlinx/coroutines/flow/j;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/c0;",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;)V"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v0, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/m$c$a;->$collectJob:Lkotlinx/coroutines/c0;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/m$c$a;->$this_unsafeFlow:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    const/4 p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "n~s~.@S @~~ c~@@ r@@bobt@om@a ~ d~~lo~ @ i o/i@s-@~@@ @Ml@ ~ 1y@~f~u~tvbo~ @ K~   ~~4i~@f/~o~@ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    check-cast p1, Ljava/lang/Throwable;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/flow/internal/m$c$a;->invoke(Ljava/lang/Throwable;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method

.method public final invoke(Ljava/lang/Throwable;)V
    .locals 4
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/m$c$a;->$collectJob:Lkotlinx/coroutines/c0;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p1}, Lkotlinx/coroutines/n2;->isActive()Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/m$c$a;->$collectJob:Lkotlinx/coroutines/c0;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Lkotlinx/coroutines/flow/internal/a;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/m$c$a;->$this_unsafeFlow:Lkotlinx/coroutines/flow/j;

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lkotlinx/coroutines/flow/internal/a;-><init>(Lkotlinx/coroutines/flow/j;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {p1, v0}, Lkotlinx/coroutines/n2;->cancel(Ljava/util/concurrent/CancellationException;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method
