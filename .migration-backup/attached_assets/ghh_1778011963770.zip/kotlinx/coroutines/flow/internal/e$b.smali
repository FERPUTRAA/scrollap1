.class final Lkotlinx/coroutines/flow/internal/e$b;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/e;->l()Li8/p;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "-TT;>;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.internal.ChannelFlow$collectToFun$1"
    f = "ChannelFlow.kt"
    i = {}
    l = {
        0x3c
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field synthetic L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Lkotlinx/coroutines/flow/internal/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/internal/e<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/internal/e;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/internal/e<",
            "TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/internal/e$b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/e$b;->this$0:Lkotlinx/coroutines/flow/internal/e;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v0, Lkotlinx/coroutines/flow/internal/e$b;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/e$b;->this$0:Lkotlinx/coroutines/flow/internal/e;

    const/4 v2, 0x0

    move v3, v2

    invoke-direct {v0, v1, p2}, Lkotlinx/coroutines/flow/internal/e$b;-><init>(Lkotlinx/coroutines/flow/internal/e;Lkotlin/coroutines/d;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object p1, v0, Lkotlinx/coroutines/flow/internal/e$b;->L$0:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x2

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/e$b;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v1, p0, Lkotlinx/coroutines/flow/internal/e$b;->label:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-ne v1, v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x3

    const-string v0, " is l/ur eoeusafint eecr/w/kovr/ceobol/t/e nh/omit/"

    const-string/jumbo v0, "u/s evrc i/nhfeee //toutl//ntlseobcroo/w akm i/roei"

    const/4 v4, 0x0

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    throw p1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/e$b;->L$0:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x4

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/e$b;->this$0:Lkotlinx/coroutines/flow/internal/e;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput v2, p0, Lkotlinx/coroutines/flow/internal/e$b;->label:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1, p1, p0}, Lkotlinx/coroutines/flow/internal/e;->h(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-ne p1, v0, :cond_2

    const/4 v4, 0x3

    return-object v0

    :cond_2
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/e$b;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    check-cast p1, Lkotlinx/coroutines/flow/internal/e$b;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/internal/e$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    return-object p1
.end method
