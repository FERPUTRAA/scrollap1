.class final Lkotlinx/coroutines/flow/internal/g$a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/g;->h(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/n2;

.field final synthetic b:Lkotlinx/coroutines/sync/f;

.field final synthetic c:Lkotlinx/coroutines/channels/g0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/g0<",
            "TT;>;"
        }
    .end annotation
.end field

.field final synthetic d:Lkotlinx/coroutines/flow/internal/y;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/internal/y<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/n2;Lkotlinx/coroutines/sync/f;Lkotlinx/coroutines/channels/g0;Lkotlinx/coroutines/flow/internal/y;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/n2;",
            "Lkotlinx/coroutines/sync/f;",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;",
            "Lkotlinx/coroutines/flow/internal/y<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/g$a;->a:Lkotlinx/coroutines/n2;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/g$a;->b:Lkotlinx/coroutines/sync/f;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p3, p0, Lkotlinx/coroutines/flow/internal/g$a;->c:Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p4, p0, Lkotlinx/coroutines/flow/internal/g$a;->d:Lkotlinx/coroutines/flow/internal/y;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final a(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 9
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    instance-of v0, p2, Lkotlinx/coroutines/flow/internal/g$a$b;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    check-cast v0, Lkotlinx/coroutines/flow/internal/g$a$b;

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget v1, v0, Lkotlinx/coroutines/flow/internal/g$a$b;->label:I

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/high16 v2, -0x80000000

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    and-int v3, v1, v2

    if-eqz v3, :cond_0

    const/4 v7, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    sub-int/2addr v1, v2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    iput v1, v0, Lkotlinx/coroutines/flow/internal/g$a$b;->label:I

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    goto :goto_0

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/internal/g$a$b;

    const/4 v7, 0x0

    const/4 v7, 0x4

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/internal/g$a$b;-><init>(Lkotlinx/coroutines/flow/internal/g$a;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object p2, v0, Lkotlinx/coroutines/flow/internal/g$a$b;->result:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget v2, v0, Lkotlinx/coroutines/flow/internal/g$a$b;->label:I

    const/4 v8, 0x2

    const/4 v3, 0x1

    const/4 v8, 0x3

    shl-int/2addr v7, v3

    const/4 v8, 0x4

    if-eqz v2, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-ne v2, v3, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object p1, v0, Lkotlinx/coroutines/flow/internal/g$a$b;->L$1:Ljava/lang/Object;

    const/4 v7, 0x6

    or-int/2addr v8, v7

    check-cast p1, Lkotlinx/coroutines/flow/i;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object v0, v0, Lkotlinx/coroutines/flow/internal/g$a$b;->L$0:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    check-cast v0, Lkotlinx/coroutines/flow/internal/g$a;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    goto :goto_1

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string p2, " ns/e/rfibe em/vso//li a kelh/ ri/nctroetsuu ocwe/t"

    const-string/jumbo p2, "w/s//ts /e n/bcu eniri//ormle/eet aitke  ocoflhvour"

    const/4 v8, 0x4

    const-string p2, "n tmlwioa uitoolcu  n/rm//ev//rbiehsoeerft/ e/kec/o"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    throw p1

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x2

    iget-object p2, p0, Lkotlinx/coroutines/flow/internal/g$a;->a:Lkotlinx/coroutines/n2;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eqz p2, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {p2}, Lkotlinx/coroutines/r2;->A(Lkotlinx/coroutines/n2;)V

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-object p2, p0, Lkotlinx/coroutines/flow/internal/g$a;->b:Lkotlinx/coroutines/sync/f;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    iput-object p0, v0, Lkotlinx/coroutines/flow/internal/g$a$b;->L$0:Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    iput-object p1, v0, Lkotlinx/coroutines/flow/internal/g$a$b;->L$1:Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    iput v3, v0, Lkotlinx/coroutines/flow/internal/g$a$b;->label:I

    const/4 v8, 0x3

    invoke-interface {p2, v0}, Lkotlinx/coroutines/sync/f;->c(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-ne p2, v1, :cond_4

    const/4 v8, 0x6

    return-object v1

    :cond_4
    move-object v0, p0

    move-object v0, p0

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    iget-object v1, v0, Lkotlinx/coroutines/flow/internal/g$a;->c:Lkotlinx/coroutines/channels/g0;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v3, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-instance v4, Lkotlinx/coroutines/flow/internal/g$a$a;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    iget-object p2, v0, Lkotlinx/coroutines/flow/internal/g$a;->d:Lkotlinx/coroutines/flow/internal/y;

    const/4 v7, 0x6

    move v8, v7

    iget-object v0, v0, Lkotlinx/coroutines/flow/internal/g$a;->b:Lkotlinx/coroutines/sync/f;

    const/4 v7, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v5, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-direct {v4, p1, p2, v0, v5}, Lkotlinx/coroutines/flow/internal/g$a$a;-><init>(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/internal/y;Lkotlinx/coroutines/sync/f;Lkotlin/coroutines/d;)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v5, 0x6

    const/4 v5, 0x3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v6, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/j;->e(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;Lkotlinx/coroutines/w0;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/n2;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    return-object p1
.end method

.method public bridge synthetic emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    check-cast p1, Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/g$a;->a(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    return-object p1
.end method
