.class public final Lkotlinx/coroutines/flow/internal/w;
.super Ljava/lang/Object;


# static fields
.field private static final a:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "Lkotlinx/coroutines/flow/j<",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v0, Lkotlinx/coroutines/flow/internal/w$a;->a:Lkotlinx/coroutines/flow/internal/w$a;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lkotlin/jvm/internal/u1;->q(Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Li8/q;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    sput-object v0, Lkotlinx/coroutines/flow/internal/w;->a:Li8/q;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public static final synthetic a()Li8/q;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@tss  ~iK~@  u@bb/1~ ~ l/~o~~@y.@~@@@ ra~o@ ~4~~f ~o@~ ifl~@@   mio@tb~S@~  n@@@~@o~ @ vdo~@M~c-"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lkotlinx/coroutines/flow/internal/w;->a:Li8/q;

    const/4 v2, 0x3

    return-object v0
.end method

.method private static synthetic b()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method
