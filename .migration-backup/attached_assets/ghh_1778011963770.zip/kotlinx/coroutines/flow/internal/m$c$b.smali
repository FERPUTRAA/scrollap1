.class final Lkotlinx/coroutines/flow/internal/m$c$b;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/internal/m$c;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlin/s2;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.internal.CombineKt$zipImpl$1$1$2"
    f = "Combine.kt"
    i = {}
    l = {
        0x82
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $cnt:Ljava/lang/Object;

.field final synthetic $flow:Lkotlinx/coroutines/flow/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/i<",
            "TT1;>;"
        }
    .end annotation
.end field

.field final synthetic $scopeContext:Lkotlin/coroutines/g;

.field final synthetic $second:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $this_unsafeFlow:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TR;>;"
        }
    .end annotation
.end field

.field final synthetic $transform:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "TT1;TT2;",
            "Lkotlin/coroutines/d<",
            "-TR;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/g;Ljava/lang/Object;Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/flow/j;Li8/q;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlin/coroutines/g;",
            "Ljava/lang/Object;",
            "Lkotlinx/coroutines/channels/i0<",
            "+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Li8/q<",
            "-TT1;-TT2;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/internal/m$c$b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$flow:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$scopeContext:Lkotlin/coroutines/g;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p3, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$cnt:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p4, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$second:Lkotlinx/coroutines/channels/i0;

    iput-object p5, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$this_unsafeFlow:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p6, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$transform:Li8/q;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x3

    invoke-direct {p0, p1, p7}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 10
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "@iso@ mi@@ cs~~d~~~Sf@y~u @@~~t t@/bo~@~@  @ f @ b ~~-~  @@K oM~@v~a4 @ l@ro~@@o1bo~@n /i~ ~~~.l"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x7

    new-instance p1, Lkotlinx/coroutines/flow/internal/m$c$b;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$flow:Lkotlinx/coroutines/flow/i;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    iget-object v2, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$scopeContext:Lkotlin/coroutines/g;

    iget-object v3, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$cnt:Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v4, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$second:Lkotlinx/coroutines/channels/i0;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    iget-object v5, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$this_unsafeFlow:Lkotlinx/coroutines/flow/j;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget-object v6, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$transform:Li8/q;

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-direct/range {v0 .. v7}, Lkotlinx/coroutines/flow/internal/m$c$b;-><init>(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/g;Ljava/lang/Object;Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/flow/j;Li8/q;Lkotlin/coroutines/d;)V

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    check-cast p1, Lkotlin/s2;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/m$c$b;->k(Lkotlin/s2;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v9, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget v1, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->label:I

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    const/4 v2, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-eqz v1, :cond_1

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-ne v1, v2, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    goto :goto_0

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    const-string v0, "o/ommeoi ennir /sk/tb/ oolseu ri/te ae/tc/ve hcrlwu"

    const-string v0, "ons/sertc /r/ocei/one  eal/eluuo  mio//iettbhr kwv/"

    const/4 v10, 0x3

    const-string/jumbo v0, "uvokoi/tirc//tat/e  e/lorrenon/o bfee h c/ei s/olum"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    throw p1

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v9, 0x2

    move v10, v9

    iget-object p1, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$flow:Lkotlinx/coroutines/flow/i;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    new-instance v1, Lkotlinx/coroutines/flow/internal/m$c$b$a;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v4, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$scopeContext:Lkotlin/coroutines/g;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object v5, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$cnt:Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-object v6, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$second:Lkotlinx/coroutines/channels/i0;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-object v7, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$this_unsafeFlow:Lkotlinx/coroutines/flow/j;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget-object v8, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->$transform:Li8/q;

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-direct/range {v3 .. v8}, Lkotlinx/coroutines/flow/internal/m$c$b$a;-><init>(Lkotlin/coroutines/g;Ljava/lang/Object;Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/flow/j;Li8/q;)V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    iput v2, p0, Lkotlinx/coroutines/flow/internal/m$c$b;->label:I

    const/4 v10, 0x1

    const/4 v9, 0x2

    invoke-interface {p1, v1, p0}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    if-ne p1, v0, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    return-object v0

    :cond_2
    :goto_0
    const/4 v10, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    return-object p1
.end method

.method public final k(Lkotlin/s2;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlin/s2;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/s2;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/m$c$b;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    check-cast p1, Lkotlinx/coroutines/flow/internal/m$c$b;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/internal/m$c$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p1
.end method
