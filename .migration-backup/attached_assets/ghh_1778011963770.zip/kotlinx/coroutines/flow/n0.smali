.class final Lkotlinx/coroutines/flow/n0;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public final a:Lkotlinx/coroutines/flow/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public final b:I
    .annotation build Lh8/e;
    .end annotation
.end field

.field public final c:Lkotlinx/coroutines/channels/m;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public final d:Lkotlin/coroutines/g;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/i;ILkotlinx/coroutines/channels/m;Lkotlin/coroutines/g;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;I",
            "Lkotlinx/coroutines/channels/m;",
            "Lkotlin/coroutines/g;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    move v1, v0

    iput-object p1, p0, Lkotlinx/coroutines/flow/n0;->a:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput p2, p0, Lkotlinx/coroutines/flow/n0;->b:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p3, p0, Lkotlinx/coroutines/flow/n0;->c:Lkotlinx/coroutines/channels/m;

    const/4 v1, 0x5

    iput-object p4, p0, Lkotlinx/coroutines/flow/n0;->d:Lkotlin/coroutines/g;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method
