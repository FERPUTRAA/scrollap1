.class public final Lkotlinx/coroutines/flow/t$c;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/t;->e(Lkotlinx/coroutines/flow/i;Li8/p;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt\n+ 3 CoroutineScope.kt\nkotlinx/coroutines/CoroutineScopeKt\n*L\n1#1,112:1\n182#2,7:113\n189#2,7:121\n329#3:120\n*S KotlinDebug\n*F\n+ 1 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt\n*L\n188#1:120\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/i;

.field final synthetic b:Li8/p;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/i;Li8/p;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/t$c;->a:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lkotlinx/coroutines/flow/t$c;->b:Li8/p;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 8
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    instance-of v0, p2, Lkotlinx/coroutines/flow/t$c$a;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    check-cast v0, Lkotlinx/coroutines/flow/t$c$a;

    const/4 v7, 0x3

    iget v1, v0, Lkotlinx/coroutines/flow/t$c$a;->label:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/high16 v2, -0x80000000

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    and-int v3, v1, v2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v3, :cond_0

    const/4 v7, 0x5

    sub-int/2addr v1, v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput v1, v0, Lkotlinx/coroutines/flow/t$c$a;->label:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/t$c$a;

    const/4 v7, 0x4

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/t$c$a;-><init>(Lkotlinx/coroutines/flow/t$c;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v6, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object p2, v0, Lkotlinx/coroutines/flow/t$c$a;->result:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget v2, v0, Lkotlinx/coroutines/flow/t$c$a;->label:I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v3, 0x2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v4, 0x1

    const/4 v6, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-eqz v2, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eq v2, v4, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-ne v2, v3, :cond_1

    const/4 v6, 0x6

    move v7, v6

    iget-object p1, v0, Lkotlinx/coroutines/flow/t$c$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    check-cast p1, Lkotlinx/coroutines/flow/internal/v;

    :try_start_0
    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    goto/16 :goto_2

    :catchall_0
    move-exception p2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto/16 :goto_3

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string p2, "aes/sun/e blie/vc  ite/fmr osiceletouk rowo/o/r /t/"

    const-string p2, "/isooorm/t/  ul  oflvt/ae/ew/htkre/ ieoceurbie cns/"

    const/4 v7, 0x2

    const-string p2, "n/ mncf/co/sm /et biueheo/leorlv/atrto wo uk/iei r/"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x3

    const/4 v6, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    throw p1

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object p1, v0, Lkotlinx/coroutines/flow/t$c$a;->L$2:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    check-cast p1, Lkotlin/jvm/internal/k1$a;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object v2, v0, Lkotlinx/coroutines/flow/t$c$a;->L$1:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    check-cast v2, Lkotlinx/coroutines/flow/j;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v4, v0, Lkotlinx/coroutines/flow/t$c$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    check-cast v4, Lkotlinx/coroutines/flow/t$c;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_1

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    new-instance p2, Lkotlin/jvm/internal/k1$a;

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-direct {p2}, Lkotlin/jvm/internal/k1$a;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    iput-boolean v4, p2, Lkotlin/jvm/internal/k1$a;->element:Z

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v2, p0, Lkotlinx/coroutines/flow/t$c;->a:Lkotlinx/coroutines/flow/i;

    const/4 v7, 0x5

    new-instance v5, Lkotlinx/coroutines/flow/t$d;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-direct {v5, p2, p1}, Lkotlinx/coroutines/flow/t$d;-><init>(Lkotlin/jvm/internal/k1$a;Lkotlinx/coroutines/flow/j;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    iput-object p0, v0, Lkotlinx/coroutines/flow/t$c$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x4

    iput-object p1, v0, Lkotlinx/coroutines/flow/t$c$a;->L$1:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput-object p2, v0, Lkotlinx/coroutines/flow/t$c$a;->L$2:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    iput v4, v0, Lkotlinx/coroutines/flow/t$c$a;->label:I

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-interface {v2, v5, v0}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-ne v2, v1, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-object v1

    :cond_4
    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-boolean p1, p1, Lkotlin/jvm/internal/k1$a;->element:Z

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-eqz p1, :cond_6

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-instance p1, Lkotlinx/coroutines/flow/internal/v;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {v0}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {p1, v2, p2}, Lkotlinx/coroutines/flow/internal/v;-><init>(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/g;)V

    :try_start_1
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object p2, v4, Lkotlinx/coroutines/flow/t$c;->b:Li8/p;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput-object p1, v0, Lkotlinx/coroutines/flow/t$c$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x3

    shl-int/2addr v7, v6

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    iput-object v2, v0, Lkotlinx/coroutines/flow/t$c$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x5

    xor-int/2addr v7, v6

    iput-object v2, v0, Lkotlinx/coroutines/flow/t$c$a;->L$2:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput v3, v0, Lkotlinx/coroutines/flow/t$c$a;->label:I

    const/4 v7, 0x5

    const/4 v2, 0x3

    const/4 v7, 0x6

    const/4 v2, 0x6

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v2}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-interface {p2, p1, v0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v0, 0x7

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-ne p2, v1, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    return-object v1

    :cond_5
    :goto_2
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p1}, Lkotlinx/coroutines/flow/internal/v;->releaseIntercepted()V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_4

    :goto_3
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p1}, Lkotlinx/coroutines/flow/internal/v;->releaseIntercepted()V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    throw p2

    :cond_6
    :goto_4
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    return-object p1
.end method
