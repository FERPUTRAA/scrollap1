.class final Lkotlinx/coroutines/flow/g$a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/g;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/g<",
            "TT;>;"
        }
    .end annotation
.end field

.field final synthetic b:Lkotlin/jvm/internal/k1$h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic c:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/g;Lkotlin/jvm/internal/k1$h;Lkotlinx/coroutines/flow/j;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/g<",
            "TT;>;",
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/g$a;->a:Lkotlinx/coroutines/flow/g;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p2, p0, Lkotlinx/coroutines/flow/g$a;->b:Lkotlin/jvm/internal/k1$h;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p3, p0, Lkotlinx/coroutines/flow/g$a;->c:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    instance-of v0, p2, Lkotlinx/coroutines/flow/g$a$a;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    check-cast v0, Lkotlinx/coroutines/flow/g$a$a;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget v1, v0, Lkotlinx/coroutines/flow/g$a$a;->label:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/high16 v2, -0x80000000

    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    and-int v3, v1, v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x7

    sub-int/2addr v1, v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    iput v1, v0, Lkotlinx/coroutines/flow/g$a$a;->label:I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/g$a$a;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/g$a$a;-><init>(Lkotlinx/coroutines/flow/g$a;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object p2, v0, Lkotlinx/coroutines/flow/g$a$a;->result:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget v2, v0, Lkotlinx/coroutines/flow/g$a$a;->label:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v2, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-ne v2, v3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto/16 :goto_2

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string p2, "ensoiarsco/ik l/wnvel/ coout em/e  u/ tioh/ef/t/ber"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    move v6, v5

    throw p1

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x5

    move v6, v5

    iget-object p2, p0, Lkotlinx/coroutines/flow/g$a;->a:Lkotlinx/coroutines/flow/g;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object p2, p2, Lkotlinx/coroutines/flow/g;->b:Li8/l;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {p2, p1}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v2, p0, Lkotlinx/coroutines/flow/g$a;->b:Lkotlin/jvm/internal/k1$h;

    const/4 v6, 0x6

    iget-object v2, v2, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    sget-object v4, Lkotlinx/coroutines/flow/internal/u;->a:Lkotlinx/coroutines/internal/r0;

    const/4 v6, 0x3

    const/4 v5, 0x1

    if-eq v2, v4, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v4, p0, Lkotlinx/coroutines/flow/g$a;->a:Lkotlinx/coroutines/flow/g;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v4, v4, Lkotlinx/coroutines/flow/g;->c:Li8/p;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {v4, v2, p2}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    check-cast v2, Ljava/lang/Boolean;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-nez v2, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x0

    goto :goto_1

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x1

    return-object p1

    :cond_4
    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v2, p0, Lkotlinx/coroutines/flow/g$a;->b:Lkotlin/jvm/internal/k1$h;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    iput-object p2, v2, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object p2, p0, Lkotlinx/coroutines/flow/g$a;->c:Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x3

    iput v3, v0, Lkotlinx/coroutines/flow/g$a$a;->label:I

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {p2, p1, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-ne p1, v1, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x3

    return-object v1

    :cond_5
    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-object p1
.end method
