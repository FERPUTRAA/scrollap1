.class public final Lkotlinx/coroutines/flow/l$g;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/l;->j([Ljava/lang/Object;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,112:1\n156#2:113\n157#2,2:115\n159#2:118\n13536#3:114\n13537#3:117\n*S KotlinDebug\n*F\n+ 1 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n*L\n156#1:114\n156#1:117\n*E\n"
.end annotation


# instance fields
.field final synthetic a:[Ljava/lang/Object;


# direct methods
.method public constructor <init>([Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/flow/l$g;->a:[Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 9
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x4

    const/4 v8, 0x3

    instance-of v0, p2, Lkotlinx/coroutines/flow/l$g$a;

    const/4 v8, 0x0

    const/4 v7, 0x6

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    check-cast v0, Lkotlinx/coroutines/flow/l$g$a;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget v1, v0, Lkotlinx/coroutines/flow/l$g$a;->label:I

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/high16 v2, -0x80000000

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    and-int v3, v1, v2

    const/4 v7, 0x2

    move v8, v7

    if-eqz v3, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    sub-int/2addr v1, v2

    const/4 v8, 0x6

    const/4 v7, 0x7

    iput v1, v0, Lkotlinx/coroutines/flow/l$g$a;->label:I

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    goto :goto_0

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-instance v0, Lkotlinx/coroutines/flow/l$g$a;

    const/4 v8, 0x1

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/l$g$a;-><init>(Lkotlinx/coroutines/flow/l$g;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object p2, v0, Lkotlinx/coroutines/flow/l$g$a;->result:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget v2, v0, Lkotlinx/coroutines/flow/l$g$a;->label:I

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v3, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-eqz v2, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-ne v2, v3, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x5

    iget p1, v0, Lkotlinx/coroutines/flow/l$g$a;->I$1:I

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget v2, v0, Lkotlinx/coroutines/flow/l$g$a;->I$0:I

    const/4 v7, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-object v4, v0, Lkotlinx/coroutines/flow/l$g$a;->L$1:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v8, 0x3

    check-cast v4, [Ljava/lang/Object;

    const/4 v8, 0x4

    iget-object v5, v0, Lkotlinx/coroutines/flow/l$g$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    check-cast v5, Lkotlinx/coroutines/flow/j;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p2, v5

    move-object p2, v5

    move-object p2, v5

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    goto :goto_2

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string/jumbo p2, "tes taiio//oem/c unlhe/wlreot encur  /sboo// rkfsv/"

    const-string p2, "e/sk/onolf/i/ sr iu/tvumeh wnoea rr/ielot cc/oe/ bt"

    const/4 v8, 0x4

    const-string p2, " bem e/ h/oe  lu/efro/ crverawm/tot/cl/knueosiin/it"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    throw p1

    :cond_2
    const/4 v7, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object p2, p0, Lkotlinx/coroutines/flow/l$g;->a:[Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    array-length v2, p2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v4, 0x0

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    move p1, v2

    const/4 v8, 0x4

    move p1, v2

    move p1, v2

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    move v2, v4

    move v2, v4

    move-object v4, v6

    move-object v4, v6

    :goto_1
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-ge v2, p1, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x1

    aget-object v5, v4, v2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    iput-object p2, v0, Lkotlinx/coroutines/flow/l$g$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    iput-object v4, v0, Lkotlinx/coroutines/flow/l$g$a;->L$1:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    iput v2, v0, Lkotlinx/coroutines/flow/l$g$a;->I$0:I

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    iput p1, v0, Lkotlinx/coroutines/flow/l$g$a;->I$1:I

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    iput v3, v0, Lkotlinx/coroutines/flow/l$g$a;->label:I

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-interface {p2, v5, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-ne v5, v1, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    return-object v1

    :cond_3
    :goto_2
    const/4 v8, 0x3

    const/4 v7, 0x5

    add-int/2addr v2, v3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_1

    :cond_4
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x1

    move v8, v7

    return-object p1
.end method
