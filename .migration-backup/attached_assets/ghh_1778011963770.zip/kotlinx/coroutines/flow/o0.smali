.class public interface abstract Lkotlinx/coroutines/flow/o0;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/flow/o0$a;
    }
.end annotation


# static fields
.field public static final a:Lkotlinx/coroutines/flow/o0$a;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    sget-object v0, Lkotlinx/coroutines/flow/o0$a;->a:Lkotlinx/coroutines/flow/o0$a;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    sput-object v0, Lkotlinx/coroutines/flow/o0;->a:Lkotlinx/coroutines/flow/o0$a;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method public abstract a(Lkotlinx/coroutines/flow/t0;)Lkotlinx/coroutines/flow/i;
    .param p1    # Lkotlinx/coroutines/flow/t0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/t0<",
            "Ljava/lang/Integer;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "Lkotlinx/coroutines/flow/m0;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end method
