.class final synthetic Lkotlinx/coroutines/flow/o;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lkotlinx/coroutines/flow/i;Ljava/util/Collection;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Ljava/util/Collection;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "C::",
            "Ljava/util/Collection<",
            "-TT;>;>(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;TC;",
            "Lkotlin/coroutines/d<",
            "-TC;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    instance-of v0, p2, Lkotlinx/coroutines/flow/o$a;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    check-cast v0, Lkotlinx/coroutines/flow/o$a;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget v1, v0, Lkotlinx/coroutines/flow/o$a;->label:I

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/high16 v2, -0x80000000

    const/4 v5, 0x6

    const/4 v4, 0x0

    and-int v3, v1, v2

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v5, 0x4

    sub-int/2addr v1, v2

    const/4 v4, 0x0

    or-int/2addr v5, v4

    iput v1, v0, Lkotlinx/coroutines/flow/o$a;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v0, Lkotlinx/coroutines/flow/o$a;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v0, p2}, Lkotlinx/coroutines/flow/o$a;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    iget-object p2, v0, Lkotlinx/coroutines/flow/o$a;->result:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget v2, v0, Lkotlinx/coroutines/flow/o$a;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-ne v2, v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object p0, v0, Lkotlinx/coroutines/flow/o$a;->L$0:Ljava/lang/Object;

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    check-cast p1, Ljava/util/Collection;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x0

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo p1, "u/se/rout entmiaooi esew//kfbstc/r lnir o/ h/ eecol"

    const-string p1, "/msinh/oe/o oae s/leoceutf te/c t ob r/kriri/lwune/"

    const-string p1, "e/ msn/i/e /ae/noor  lowkul/iviorumbo /eehct tertc/"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    throw p0

    :cond_2
    const/4 v5, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v4, 0x3

    new-instance p2, Lkotlinx/coroutines/flow/o$b;

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {p2, p1}, Lkotlinx/coroutines/flow/o$b;-><init>(Ljava/util/Collection;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    iput-object p1, v0, Lkotlinx/coroutines/flow/o$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput v3, v0, Lkotlinx/coroutines/flow/o$a;->label:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-interface {p0, p2, v0}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-ne p0, v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-object v1

    :cond_3
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object p1
.end method

.method public static final b(Lkotlinx/coroutines/flow/i;Ljava/util/List;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Ljava/util/List<",
            "TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/util/List<",
            "+TT;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/flow/k;->V1(Lkotlinx/coroutines/flow/i;Ljava/util/Collection;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p0
.end method

.method public static synthetic c(Lkotlinx/coroutines/flow/i;Ljava/util/List;Lkotlin/coroutines/d;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    and-int/lit8 p3, p3, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-eqz p3, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    new-instance p1, Ljava/util/ArrayList;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/flow/k;->W1(Lkotlinx/coroutines/flow/i;Ljava/util/List;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method public static final d(Lkotlinx/coroutines/flow/i;Ljava/util/Set;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Ljava/util/Set;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Ljava/util/Set<",
            "TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/util/Set<",
            "+TT;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    check-cast p1, Ljava/util/Collection;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/flow/k;->V1(Lkotlinx/coroutines/flow/i;Ljava/util/Collection;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method

.method public static synthetic e(Lkotlinx/coroutines/flow/i;Ljava/util/Set;Lkotlin/coroutines/d;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    and-int/lit8 p3, p3, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-eqz p3, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    new-instance p1, Ljava/util/LinkedHashSet;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/flow/k;->Y1(Lkotlinx/coroutines/flow/i;Ljava/util/Set;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method
