.class public final Lkotlinx/coroutines/flow/l$h$a;
.super Lkotlin/coroutines/jvm/internal/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/l$h;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1$collect$1\n*L\n1#1,112:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__BuildersKt$asFlow$$inlined$unsafeFlow$7"
    f = "Builders.kt"
    i = {
        0x0,
        0x0
    }
    l = {
        0x73
    }
    m = "collect"
    n = {
        "$this$asFlow_u24lambda_u2d13",
        "$this$forEach$iv"
    }
    s = {
        "L$0",
        "L$1"
    }
.end annotation


# instance fields
.field I$0:I

.field I$1:I

.field L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field label:I

.field synthetic result:Ljava/lang/Object;

.field final synthetic this$0:Lkotlinx/coroutines/flow/l$h;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/l$h;Lkotlin/coroutines/d;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/flow/l$h$a;->this$0:Lkotlinx/coroutines/flow/l$h;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/d;-><init>(Lkotlin/coroutines/d;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "l@s bnoi cs ~~~@~i~m/d.~f~b~~f ~@1@ Ku / o@rto~o~ @@  ~@@@ ~o  @y@t @4@~@@ov ~~~S@-~@~ @@iM~b~la"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/l$h$a;->result:Ljava/lang/Object;

    const/4 v2, 0x1

    iget p1, p0, Lkotlinx/coroutines/flow/l$h$a;->label:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/high16 v0, -0x80000000

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    or-int/2addr p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput p1, p0, Lkotlinx/coroutines/flow/l$h$a;->label:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/flow/l$h$a;->this$0:Lkotlinx/coroutines/flow/l$h;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1, v0, p0}, Lkotlinx/coroutines/flow/l$h;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p1
.end method
