.class public final Lkotlinx/coroutines/flow/a0$a$b;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/a0$a;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEmitters.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$1$1\n+ 2 Transform.kt\nkotlinx/coroutines/flow/FlowKt__TransformKt\n*L\n1#1,222:1\n21#2,2:223\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/j;

.field final synthetic b:Li8/p;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/j;Li8/p;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$a$b;->a:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/flow/a0$a$b;->b:Li8/p;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "S@sr  ~t~  v @m idl  . @o~oot@b~ bbs~of1~n@//~  ~~l~~~ @u@@~~ai ~@@~@~K@oo ~ f-@~@4~M@@ y~@~@@ic"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    const/4 v0, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Lkotlinx/coroutines/flow/a0$a$b$a;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/a0$a$b$a;-><init>(Lkotlinx/coroutines/flow/a0$a$b;Lkotlin/coroutines/d;)V

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x5

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/flow/a0$a$b;->a:Lkotlinx/coroutines/flow/j;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/flow/a0$a$b;->b:Li8/p;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v1, p1, p2}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast v1, Ljava/lang/Boolean;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    invoke-static {v1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, p1, p2}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p1}, Lkotlin/jvm/internal/i0;->e(I)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p1
.end method

.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 8
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    instance-of v0, p2, Lkotlinx/coroutines/flow/a0$a$b$a;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    check-cast v0, Lkotlinx/coroutines/flow/a0$a$b$a;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget v1, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->label:I

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    const/high16 v2, -0x80000000

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    and-int v3, v1, v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    if-eqz v3, :cond_0

    sub-int/2addr v1, v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    iput v1, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->label:I

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v7, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/a0$a$b$a;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/a0$a$b$a;-><init>(Lkotlinx/coroutines/flow/a0$a$b;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v6, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object p2, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->result:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget v2, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->label:I

    const/4 v6, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/4 v3, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v2, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eq v2, v4, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-ne v2, v3, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto/16 :goto_2

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string p2, "so/mioe/btuo/rioeike/new/ eu/ao/clvsl emrrt c t nh/"

    const-string/jumbo p2, "twsi//oroo/iruiaclv eoern/sb mlknt hu te//oc// ee e"

    const/4 v7, 0x5

    const-string p2, "/cuvoe/arsefwilroeo btohei  /e/tc/o/nilek nrtu o/ m"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    throw p1

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object p1, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->L$1:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v2, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    goto :goto_1

    :cond_3
    const/4 v7, 0x3

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object p2, p0, Lkotlinx/coroutines/flow/a0$a$b;->a:Lkotlinx/coroutines/flow/j;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/flow/a0$a$b;->b:Li8/p;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-object p1, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x6

    iput-object p2, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->L$1:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput v4, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->label:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-interface {v2, p1, v0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-ne v2, v1, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-object v1

    :cond_4
    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p2, v5

    move-object p2, v5

    move-object p2, v5

    move-object p2, v5

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    check-cast p2, Ljava/lang/Boolean;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-eqz p2, :cond_5

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 p2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x4

    iput-object p2, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x3

    iput-object p2, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->L$1:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    iput v3, v0, Lkotlinx/coroutines/flow/a0$a$b$a;->label:I

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-interface {p1, v2, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-ne p1, v1, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    return-object v1

    :cond_5
    :goto_2
    const/4 v7, 0x0

    const/4 v6, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    return-object p1
.end method
