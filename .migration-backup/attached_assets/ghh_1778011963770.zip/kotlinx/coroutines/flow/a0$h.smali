.class public final Lkotlinx/coroutines/flow/a0$h;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/a0;->h(Lkotlinx/coroutines/flow/i;Ljava/lang/Object;Li8/q;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TR;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Transform.kt\nkotlinx/coroutines/flow/FlowKt__TransformKt\n*L\n1#1,112:1\n100#2,7:113\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/Object;

.field final synthetic b:Lkotlinx/coroutines/flow/i;

.field final synthetic c:Li8/q;


# direct methods
.method public constructor <init>(Ljava/lang/Object;Lkotlinx/coroutines/flow/i;Li8/q;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$h;->a:Ljava/lang/Object;

    const/4 v1, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/flow/a0$h;->b:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p3, p0, Lkotlinx/coroutines/flow/a0$h;->c:Li8/q;

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 8
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    instance-of v0, p2, Lkotlinx/coroutines/flow/a0$h$a;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    check-cast v0, Lkotlinx/coroutines/flow/a0$h$a;

    const/4 v7, 0x5

    iget v1, v0, Lkotlinx/coroutines/flow/a0$h$a;->label:I

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/high16 v2, -0x80000000

    const/4 v7, 0x7

    and-int v3, v1, v2

    const/4 v6, 0x2

    move v7, v6

    if-eqz v3, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    sub-int/2addr v1, v2

    const/4 v7, 0x4

    iput v1, v0, Lkotlinx/coroutines/flow/a0$h$a;->label:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/a0$h$a;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/a0$h$a;-><init>(Lkotlinx/coroutines/flow/a0$h;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object p2, v0, Lkotlinx/coroutines/flow/a0$h$a;->result:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget v2, v0, Lkotlinx/coroutines/flow/a0$h$a;->label:I

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 v3, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v4, 0x1

    const/4 v7, 0x6

    if-eqz v2, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eq v2, v4, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-ne v2, v3, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    goto/16 :goto_2

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string p2, " fs/tel slowcrh/ern/n/si/v keeo/ir tc  eoou/b/uimao"

    const-string p2, " escot//ou obrl/ n/eetl/ck/r/ m/riewsauhv intiof oe"

    const/4 v7, 0x6

    const-string/jumbo p2, "ukumecicrnwoo ea omeh   /erlili/bs evon/tt/o/etr/f/"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v7, 0x2

    throw p1

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object p1, v0, Lkotlinx/coroutines/flow/a0$h$a;->L$2:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    check-cast p1, Lkotlin/jvm/internal/k1$h;

    const/4 v6, 0x7

    move v7, v6

    iget-object v2, v0, Lkotlinx/coroutines/flow/a0$h$a;->L$1:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    check-cast v2, Lkotlinx/coroutines/flow/j;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v4, v0, Lkotlinx/coroutines/flow/a0$h$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    check-cast v4, Lkotlinx/coroutines/flow/a0$h;

    const/4 v6, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    goto :goto_1

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x1

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-instance p2, Lkotlin/jvm/internal/k1$h;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {p2}, Lkotlin/jvm/internal/k1$h;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/flow/a0$h;->a:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x4

    iput-object v2, p2, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput-object p0, v0, Lkotlinx/coroutines/flow/a0$h$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    iput-object p1, v0, Lkotlinx/coroutines/flow/a0$h$a;->L$1:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    iput-object p2, v0, Lkotlinx/coroutines/flow/a0$h$a;->L$2:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x4

    iput v4, v0, Lkotlinx/coroutines/flow/a0$h$a;->label:I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-interface {p1, v2, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    move v7, v6

    if-ne v2, v1, :cond_4

    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-object v1

    :cond_4
    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object p2, v4, Lkotlinx/coroutines/flow/a0$h;->b:Lkotlinx/coroutines/flow/i;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    new-instance v5, Lkotlinx/coroutines/flow/a0$i;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v4, v4, Lkotlinx/coroutines/flow/a0$h;->c:Li8/q;

    const/4 v6, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-direct {v5, p1, v4, v2}, Lkotlinx/coroutines/flow/a0$i;-><init>(Lkotlin/jvm/internal/k1$h;Li8/q;Lkotlinx/coroutines/flow/j;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 p1, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    iput-object p1, v0, Lkotlinx/coroutines/flow/a0$h$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    iput-object p1, v0, Lkotlinx/coroutines/flow/a0$h$a;->L$1:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput-object p1, v0, Lkotlinx/coroutines/flow/a0$h$a;->L$2:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    iput v3, v0, Lkotlinx/coroutines/flow/a0$h$a;->label:I

    const/4 v7, 0x2

    invoke-interface {p2, v5, v0}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-ne p1, v1, :cond_5

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    return-object v1

    :cond_5
    :goto_2
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    return-object p1
.end method
