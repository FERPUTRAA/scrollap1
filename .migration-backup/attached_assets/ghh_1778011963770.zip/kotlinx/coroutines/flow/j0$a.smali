.class final Lkotlinx/coroutines/flow/j0$a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/p1;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/flow/j0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field public final a:Lkotlinx/coroutines/flow/j0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j0<",
            "*>;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public b:J
    .annotation build Lh8/e;
    .end annotation
.end field

.field public final c:Ljava/lang/Object;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public final d:Lkotlin/coroutines/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/j0;JLjava/lang/Object;Lkotlin/coroutines/d;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/flow/j0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p5    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j0<",
            "*>;J",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/flow/j0$a;->a:Lkotlinx/coroutines/flow/j0;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-wide p2, p0, Lkotlinx/coroutines/flow/j0$a;->b:J

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p4, p0, Lkotlinx/coroutines/flow/j0$a;->c:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p5, p0, Lkotlinx/coroutines/flow/j0$a;->d:Lkotlin/coroutines/d;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public e()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s  ~~@o@~r~i@@@Ka~l  o~~M@~~ @ o~~@Sv@c f~~~  tdb @@u @~ot1@y~ o@@b @o@ -i~sm~~ ~if nb 4@./l/@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/flow/j0$a;->a:Lkotlinx/coroutines/flow/j0;

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0, p0}, Lkotlinx/coroutines/flow/j0;->r(Lkotlinx/coroutines/flow/j0;Lkotlinx/coroutines/flow/j0$a;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-void
.end method
