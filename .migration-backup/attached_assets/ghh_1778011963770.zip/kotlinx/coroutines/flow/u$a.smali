.class public final Lkotlinx/coroutines/flow/u$a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/u;->a(Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Errors.kt\nkotlinx/coroutines/flow/FlowKt__ErrorsKt\n*L\n1#1,112:1\n59#2,3:113\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/i;

.field final synthetic b:Li8/q;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/i;Li8/q;)V
    .locals 2

    iput-object p1, p0, Lkotlinx/coroutines/flow/u$a;->a:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p2, p0, Lkotlinx/coroutines/flow/u$a;->b:Li8/q;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    instance-of v0, p2, Lkotlinx/coroutines/flow/u$a$a;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast v0, Lkotlinx/coroutines/flow/u$a$a;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget v1, v0, Lkotlinx/coroutines/flow/u$a$a;->label:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/high16 v2, -0x80000000

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    and-int v3, v1, v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    sub-int/2addr v1, v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput v1, v0, Lkotlinx/coroutines/flow/u$a$a;->label:I

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    new-instance v0, Lkotlinx/coroutines/flow/u$a$a;

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/u$a$a;-><init>(Lkotlinx/coroutines/flow/u$a;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object p2, v0, Lkotlinx/coroutines/flow/u$a$a;->result:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    iget v2, v0, Lkotlinx/coroutines/flow/u$a$a;->label:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v3, 0x2

    const/4 v6, 0x3

    const/4 v4, 0x1

    const/4 v6, 0x2

    xor-int/2addr v5, v4

    const/4 v6, 0x6

    if-eqz v2, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eq v2, v4, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-ne v2, v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto/16 :goto_2

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string p2, "absv/oeee/ iok ee ec/rin/sl/tlsc/h o/wmui rrot/oufn"

    const-string p2, "nis nioeet/// ceh/erot su/orautvl efoo/bie/klrcmw/ "

    const-string p2, "//lmueblweotctnierihua/ort//i/seoemf kre/v no c /  "

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    throw p1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object p1, v0, Lkotlinx/coroutines/flow/u$a$a;->L$1:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v2, v0, Lkotlinx/coroutines/flow/u$a$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x2

    check-cast v2, Lkotlinx/coroutines/flow/u$a;

    const/4 v6, 0x0

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto :goto_1

    :cond_3
    const/4 v5, 0x4

    move v6, v5

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object p2, p0, Lkotlinx/coroutines/flow/u$a;->a:Lkotlinx/coroutines/flow/i;

    const/4 v6, 0x4

    iput-object p0, v0, Lkotlinx/coroutines/flow/u$a$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    iput-object p1, v0, Lkotlinx/coroutines/flow/u$a$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    iput v4, v0, Lkotlinx/coroutines/flow/u$a$a;->label:I

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {p2, p1, v0}, Lkotlinx/coroutines/flow/k;->v(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-ne p2, v1, :cond_4

    const/4 v5, 0x5

    const/4 v5, 0x6

    return-object v1

    :cond_4
    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    check-cast p2, Ljava/lang/Throwable;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz p2, :cond_5

    const/4 v6, 0x3

    const/4 v5, 0x6

    iget-object v2, v2, Lkotlinx/coroutines/flow/u$a;->b:Li8/q;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v4, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput-object v4, v0, Lkotlinx/coroutines/flow/u$a$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    iput-object v4, v0, Lkotlinx/coroutines/flow/u$a$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput v3, v0, Lkotlinx/coroutines/flow/u$a$a;->label:I

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x6

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v3}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {v2, p1, p2, v0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 p2, 0x7

    const/4 v5, 0x6

    move v6, v5

    invoke-static {p2}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v5, 0x2

    and-int/2addr v6, v5

    if-ne p1, v1, :cond_5

    const/4 v6, 0x0

    return-object v1

    :cond_5
    :goto_2
    const/4 v5, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x0

    const/4 v5, 0x5

    return-object p1
.end method
