.class public final Lkotlinx/coroutines/flow/a0$j;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/a0;->i(Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Transform.kt\nkotlinx/coroutines/flow/FlowKt__TransformKt\n*L\n1#1,112:1\n120#2,10:113\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/i;

.field final synthetic b:Li8/q;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/i;Li8/q;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$j;->a:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p2, p0, Lkotlinx/coroutines/flow/a0$j;->b:Li8/q;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance v0, Lkotlin/jvm/internal/k1$h;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {v0}, Lkotlin/jvm/internal/k1$h;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    sget-object v1, Lkotlinx/coroutines/flow/internal/u;->a:Lkotlinx/coroutines/internal/r0;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput-object v1, v0, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/a0$j;->a:Lkotlinx/coroutines/flow/i;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v2, Lkotlinx/coroutines/flow/a0$k;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v3, p0, Lkotlinx/coroutines/flow/a0$j;->b:Li8/q;

    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {v2, v0, v3, p1}, Lkotlinx/coroutines/flow/a0$k;-><init>(Lkotlin/jvm/internal/k1$h;Li8/q;Lkotlinx/coroutines/flow/j;)V

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {v1, v2, p2}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x7

    if-ne p1, p2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-object p1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-object p1
.end method
