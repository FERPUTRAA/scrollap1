.class public final Lkotlinx/coroutines/flow/a0$e$b$a;
.super Lkotlin/coroutines/jvm/internal/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/a0$e$b;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEmitters.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$1$1$emit$1\n*L\n1#1,222:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__TransformKt$map$$inlined$unsafeTransform$1$2"
    f = "Transform.kt"
    i = {}
    l = {
        0xdf,
        0xdf
    }
    m = "emit"
    n = {}
    s = {}
.end annotation


# instance fields
.field L$0:Ljava/lang/Object;

.field label:I

.field synthetic result:Ljava/lang/Object;

.field final synthetic this$0:Lkotlinx/coroutines/flow/a0$e$b;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/a0$e$b;Lkotlin/coroutines/d;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$e$b$a;->this$0:Lkotlinx/coroutines/flow/a0$e$b;

    const/4 v0, 0x0

    shr-int/2addr v1, v0

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/d;-><init>(Lkotlin/coroutines/d;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " osyi@o f@~1-oaM~s~i@~d.o~~~m~i@~ ~n@b ~o@ t@ @ ~u l@KtfS  l/o@@~v~@@@/@ ~@  ~ ~4r~ @~c~ b @b@~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$e$b$a;->result:Ljava/lang/Object;

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    iget p1, p0, Lkotlinx/coroutines/flow/a0$e$b$a;->label:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/high16 v0, -0x80000000

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    or-int/2addr p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput p1, p0, Lkotlinx/coroutines/flow/a0$e$b$a;->label:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/a0$e$b$a;->this$0:Lkotlinx/coroutines/flow/a0$e$b;

    const/4 v1, 0x3

    move v2, v1

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-virtual {p1, v0, p0}, Lkotlinx/coroutines/flow/a0$e$b;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p1
.end method
