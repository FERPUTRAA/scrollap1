.class final Lkotlinx/coroutines/flow/r0;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/o0;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/t0;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/t0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/t0<",
            "Ljava/lang/Integer;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "Lkotlinx/coroutines/flow/m0;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/r0$a;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-direct {v0, p1, v1}, Lkotlinx/coroutines/flow/r0$a;-><init>(Lkotlinx/coroutines/flow/t0;Lkotlin/coroutines/d;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Lkotlinx/coroutines/flow/k;->I0(Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "trshgeSdnLSiyaizrl.aa"

    const/4 v2, 0x4

    const-string v0, "Sis.gzirnStaehtyarLld"

    const-string v0, "SharingStarted.Lazily"

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method
