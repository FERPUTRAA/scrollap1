.class final Lkotlinx/coroutines/flow/r$d;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/r;->f(Lkotlinx/coroutines/u0;JJ)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__DelayKt$fixedPeriodTicker$3"
    f = "Delay.kt"
    i = {
        0x0,
        0x1,
        0x2
    }
    l = {
        0x13a,
        0x13c,
        0x13d
    }
    m = "invokeSuspend"
    n = {
        "$this$produce",
        "$this$produce",
        "$this$produce"
    }
    s = {
        "L$0",
        "L$0",
        "L$0"
    }
.end annotation


# instance fields
.field final synthetic $delayMillis:J

.field final synthetic $initialDelayMillis:J

.field private synthetic L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(JJLkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JJ",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/r$d;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-wide p1, p0, Lkotlinx/coroutines/flow/r$d;->$initialDelayMillis:J

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-wide p3, p0, Lkotlinx/coroutines/flow/r$d;->$delayMillis:J

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/4 p1, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance v6, Lkotlinx/coroutines/flow/r$d;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-wide v1, p0, Lkotlinx/coroutines/flow/r$d;->$initialDelayMillis:J

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget-wide v3, p0, Lkotlinx/coroutines/flow/r$d;->$delayMillis:J

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v5}, Lkotlinx/coroutines/flow/r$d;-><init>(JJLkotlin/coroutines/d;)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    iput-object p1, v6, Lkotlinx/coroutines/flow/r$d;->L$0:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x5

    return-object v6
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x2

    const/4 v0, 0x1

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v0, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/r$d;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget v1, p0, Lkotlinx/coroutines/flow/r$d;->label:I

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v2, 0x3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 v3, 0x2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/4 v4, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-eqz v1, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eq v1, v4, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eq v1, v3, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-ne v1, v2, :cond_1

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/flow/r$d;->L$0:Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    check-cast v1, Lkotlinx/coroutines/channels/g0;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_0

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v0, "/eskwovbl fia/io hicn/u/e ern teut osmt//leeosrcor "

    const-string v0, "eas ncwiurhleifr//o/v u/ketsntebl/o em /e  /iortooc"

    const/4 v8, 0x7

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    throw p1

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/flow/r$d;->L$0:Ljava/lang/Object;

    const/4 v8, 0x7

    check-cast v1, Lkotlinx/coroutines/channels/g0;

    const/4 v8, 0x4

    const/4 v7, 0x7

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p1, p0

    const/4 v8, 0x2

    const/4 v7, 0x7

    goto :goto_1

    :cond_3
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/flow/r$d;->L$0:Ljava/lang/Object;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    check-cast v1, Lkotlinx/coroutines/channels/g0;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-wide v5, p0, Lkotlinx/coroutines/flow/r$d;->$initialDelayMillis:J

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    iput-object v1, p0, Lkotlinx/coroutines/flow/r$d;->L$0:Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    iput v4, p0, Lkotlinx/coroutines/flow/r$d;->label:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v5, v6, p0}, Lkotlinx/coroutines/f1;->b(JLkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-ne p1, v0, :cond_4

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    return-object v0

    :cond_4
    :goto_0
    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    :cond_5
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-interface {v1}, Lkotlinx/coroutines/channels/g0;->getChannel()Lkotlinx/coroutines/channels/m0;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    sget-object v5, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x0

    iput-object v1, p1, Lkotlinx/coroutines/flow/r$d;->L$0:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    iput v3, p1, Lkotlinx/coroutines/flow/r$d;->label:I

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-interface {v4, v5, p1}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-ne v4, v0, :cond_6

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-object v0

    :cond_6
    :goto_1
    iget-wide v4, p1, Lkotlinx/coroutines/flow/r$d;->$delayMillis:J

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    iput-object v1, p1, Lkotlinx/coroutines/flow/r$d;->L$0:Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    iput v2, p1, Lkotlinx/coroutines/flow/r$d;->label:I

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {v4, v5, p1}, Lkotlinx/coroutines/f1;->b(JLkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-ne v4, v0, :cond_5

    const/4 v7, 0x2

    move v8, v7

    return-object v0
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/r$d;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    check-cast p1, Lkotlinx/coroutines/flow/r$d;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v0, 0x2

    move v1, v0

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/r$d;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method
