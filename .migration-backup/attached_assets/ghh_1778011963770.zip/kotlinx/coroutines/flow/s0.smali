.class final Lkotlinx/coroutines/flow/s0;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/o0;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSharingStarted.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SharingStarted.kt\nkotlinx/coroutines/flow/StartedWhileSubscribed\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,209:1\n1#2:210\n*E\n"
.end annotation


# instance fields
.field private final b:J

.field private final c:J


# direct methods
.method public constructor <init>(JJ)V
    .locals 8

    const/4 v6, 0x4

    move v7, v6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    iput-wide p1, p0, Lkotlinx/coroutines/flow/s0;->b:J

    const/4 v7, 0x5

    iput-wide p3, p0, Lkotlinx/coroutines/flow/s0;->c:J

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    cmp-long v2, p1, v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v4, 0x0

    const/4 v7, 0x6

    if-ltz v2, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    move v2, v3

    move v2, v3

    const/4 v7, 0x3

    move v2, v3

    move v2, v3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    move v2, v4

    move v2, v4

    move v2, v4

    move v2, v4

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v5, " ts)b atn gie nensaoemc"

    const-string v5, "ebsamai)nee tngcn o t s"

    const-string v5, "nenm ne m)osv aticatebg"

    const-string v5, " ms) cannot be negative"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eqz v2, :cond_3

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    cmp-long p1, p3, v0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-ltz p1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    goto :goto_1

    :cond_1
    const/4 v6, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    move v3, v4

    move v3, v4

    const/4 v7, 0x6

    move v3, v4

    move v3, v4

    :goto_1
    const/4 v6, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v3, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-void

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo p2, "tn(poayEalrreiomi"

    const-string p2, "ritmraeExyoai(lpn"

    const/4 v7, 0x6

    const-string/jumbo p2, "ylrpobexai(rpiEna"

    const-string p2, "replayExpiration("

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p1, p3, p4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance p2, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x6

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    throw p2

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const-string p4, "Tosp(ouittmo"

    const-string p4, "(toeoiTstomp"

    const/4 v7, 0x7

    const-string/jumbo p4, "ttuse(opTmpo"

    const-string p4, "stopTimeout("

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p3, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p3, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    new-instance p2, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x1

    and-int/2addr v7, v6

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    throw p2
.end method

.method public static final synthetic b(Lkotlinx/coroutines/flow/s0;)J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@~-bi ~q~~/lb~fm@ tu ~n~o  @ ~ 1y@i~ @~ctdb4o~~~/~@@f~~ ~@o. oKr@@@ @~@@@ @@ l @o o~sSM~a @~ iv"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-wide v0, p0, Lkotlinx/coroutines/flow/s0;->c:J

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-wide v0
.end method

.method public static final synthetic c(Lkotlinx/coroutines/flow/s0;)J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-wide v0, p0, Lkotlinx/coroutines/flow/s0;->b:J

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-wide v0
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/t0;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/t0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/t0<",
            "Ljava/lang/Integer;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "Lkotlinx/coroutines/flow/m0;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Lkotlinx/coroutines/flow/s0$a;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v0, p0, v1}, Lkotlinx/coroutines/flow/s0$a;-><init>(Lkotlinx/coroutines/flow/s0;Lkotlin/coroutines/d;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lkotlinx/coroutines/flow/k;->b2(Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Lkotlinx/coroutines/flow/s0$b;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lkotlinx/coroutines/flow/s0$b;-><init>(Lkotlin/coroutines/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lkotlinx/coroutines/flow/k;->k0(Lkotlinx/coroutines/flow/i;Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p1}, Lkotlinx/coroutines/flow/k;->g0(Lkotlinx/coroutines/flow/i;)Lkotlinx/coroutines/flow/i;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    instance-of v0, p1, Lkotlinx/coroutines/flow/s0;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-wide v0, p0, Lkotlinx/coroutines/flow/s0;->b:J

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    check-cast p1, Lkotlinx/coroutines/flow/s0;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-wide v2, p1, Lkotlinx/coroutines/flow/s0;->b:J

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-wide v0, p0, Lkotlinx/coroutines/flow/s0;->c:J

    const/4 v4, 0x6

    move v5, v4

    iget-wide v2, p1, Lkotlinx/coroutines/flow/s0;->c:J

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    cmp-long p1, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    if-nez p1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 p1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    return p1
.end method

.method public hashCode()I
    .locals 5
    .annotation build Lorg/codehaus/mojo/animal_sniffer/IgnoreJRERequirement;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-wide v0, p0, Lkotlinx/coroutines/flow/s0;->b:J

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0, v1}, Li2/a;->a(J)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    mul-int/lit8 v0, v0, 0x1f

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-wide v1, p0, Lkotlinx/coroutines/flow/s0;->c:J

    const/4 v4, 0x1

    invoke-static {v1, v2}, Li2/a;->a(J)I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    add-int/2addr v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 13
    .annotation build Lia/d;
    .end annotation

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x5

    const/4 v0, 0x2

    const/4 v12, 0x5

    const/4 v11, 0x6

    invoke-static {v0}, Lkotlin/collections/u;->j(I)Ljava/util/List;

    move-result-object v0

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    iget-wide v1, p0, Lkotlinx/coroutines/flow/s0;->b:J

    const/4 v12, 0x5

    const/4 v11, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    cmp-long v1, v1, v3

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    const-string v2, "ms"

    const-string v2, "sm"

    const/4 v12, 0x2

    const-string v2, "ms"

    const-string v2, "ms"

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    if-lez v1, :cond_0

    const/4 v11, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    const-string v3, "opsbsut=teoi"

    const-string v3, "oepisbmottu="

    const/4 v12, 0x3

    const-string/jumbo v3, "tptmoomsieTu"

    const-string v3, "stopTimeout="

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget-wide v3, p0, Lkotlinx/coroutines/flow/s0;->b:J

    const/4 v12, 0x2

    invoke-virtual {v1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    iget-wide v3, p0, Lkotlinx/coroutines/flow/s0;->c:J

    const/4 v12, 0x1

    const-wide v5, 0x7fffffffffffffffL

    const-wide v5, 0x7fffffffffffffffL

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    cmp-long v1, v3, v5

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    if-gez v1, :cond_1

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x6

    const-string v3, "oiiaonraruxpy=epE"

    const-string v3, "praEpeuraiy=lniox"

    const/4 v12, 0x2

    const-string v3, "anloEbapxreiip=ty"

    const-string v3, "replayExpiration="

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    iget-wide v3, p0, Lkotlinx/coroutines/flow/s0;->c:J

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {v1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-static {v0}, Lkotlin/collections/u;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x6

    const-string v1, "eW.dreudigrihseinlatacbSrbpuSSh"

    const-string v1, "eiau(crpnbiri.hgrdSadtebeslWShS"

    const-string v1, "atreSiWpbSedirbtn(rgldhahseS.cu"

    const-string v1, "SharingStarted.WhileSubscribed("

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x0

    const/4 v3, 0x0

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    const/4 v4, 0x0

    const/4 v12, 0x3

    const/4 v5, 0x0

    const/4 v12, 0x4

    shl-int/2addr v11, v5

    const/4 v12, 0x5

    const/4 v6, 0x0

    and-int/2addr v11, v6

    const/4 v7, 0x3

    const/4 v7, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    const/4 v8, 0x0

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    const/16 v9, 0x3f

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x5

    const/4 v10, 0x0

    const/4 v12, 0x4

    invoke-static/range {v2 .. v10}, Lkotlin/collections/u;->j3(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Li8/l;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/16 v1, 0x29

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x5

    return-object v0
.end method
