.class public final Lkotlinx/coroutines/flow/b0$l;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0;->q(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/r;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/flow/j<",
        "-TR;>;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nZip.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt$combineTransformUnsafe$1\n*L\n1#1,332:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$1"
    f = "Zip.kt"
    i = {}
    l = {
        0x111
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $flows:[Lkotlinx/coroutines/flow/i;

.field final synthetic $transform$inlined:Li8/r;

.field private synthetic L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method public constructor <init>([Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;Li8/r;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$l;->$flows:[Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p3, p0, Lkotlinx/coroutines/flow/b0$l;->$transform$inlined:Li8/r;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p1, 0x2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/b0$l;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$l;->$flows:[Lkotlinx/coroutines/flow/i;

    iget-object v2, p0, Lkotlinx/coroutines/flow/b0$l;->$transform$inlined:Li8/r;

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0, v1, p2, v2}, Lkotlinx/coroutines/flow/b0$l;-><init>([Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;Li8/r;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput-object p1, v0, Lkotlinx/coroutines/flow/b0$l;->L$0:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x2

    const/4 v0, 0x5

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/b0$l;->invoke(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/b0$l;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    check-cast p1, Lkotlinx/coroutines/flow/b0$l;

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/b0$l;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget v1, p0, Lkotlinx/coroutines/flow/b0$l;->label:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v2, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-eqz v1, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-ne v1, v2, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string v0, "/mso acvi r s uk b/ooteeeft/uowcho/e/i/ /lir/enetrn"

    const-string v0, "o/s vfneue w irbretle oo  rk//etiho///ulemicno/at/c"

    const/4 v8, 0x2

    const-string v0, "l/rme f osnr// ehitvtrmibecano/ ekow/tueec l //ouio"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    throw p1

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$l;->L$0:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$l;->$flows:[Lkotlinx/coroutines/flow/i;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {}, Lkotlinx/coroutines/flow/b0;->a()Li8/a;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    new-instance v4, Lkotlinx/coroutines/flow/b0$l$a;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v5, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object v6, p0, Lkotlinx/coroutines/flow/b0$l;->$transform$inlined:Li8/r;

    const/4 v7, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {v4, v5, v6}, Lkotlinx/coroutines/flow/b0$l$a;-><init>(Lkotlin/coroutines/d;Li8/r;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    iput v2, p0, Lkotlinx/coroutines/flow/b0$l;->label:I

    const/4 v8, 0x4

    invoke-static {p1, v1, v3, v4, p0}, Lkotlinx/coroutines/flow/internal/m;->a(Lkotlinx/coroutines/flow/j;[Lkotlinx/coroutines/flow/i;Li8/a;Li8/q;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-ne p1, v0, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    return-object v0

    :cond_2
    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    return-object p1
.end method
