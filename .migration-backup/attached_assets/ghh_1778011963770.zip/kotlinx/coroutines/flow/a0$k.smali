.class final Lkotlinx/coroutines/flow/a0$k;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/a0;->i(Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlin/jvm/internal/k1$h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic b:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "TT;TT;",
            "Lkotlin/coroutines/d<",
            "-TT;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic c:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/k1$h;Li8/q;Lkotlinx/coroutines/flow/j;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;",
            "Li8/q<",
            "-TT;-TT;-",
            "Lkotlin/coroutines/d<",
            "-TT;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$k;->a:Lkotlin/jvm/internal/k1$h;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p2, p0, Lkotlinx/coroutines/flow/a0$k;->b:Li8/q;

    const/4 v1, 0x6

    iput-object p3, p0, Lkotlinx/coroutines/flow/a0$k;->c:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x1

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 9
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    instance-of v0, p2, Lkotlinx/coroutines/flow/a0$k$a;

    const/4 v8, 0x4

    const/4 v7, 0x4

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    check-cast v0, Lkotlinx/coroutines/flow/a0$k$a;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget v1, v0, Lkotlinx/coroutines/flow/a0$k$a;->label:I

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/high16 v2, -0x80000000

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    and-int v3, v1, v2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz v3, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    sub-int/2addr v1, v2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    iput v1, v0, Lkotlinx/coroutines/flow/a0$k$a;->label:I

    const/4 v7, 0x1

    and-int/2addr v8, v7

    goto :goto_0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/a0$k$a;

    const/4 v7, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/a0$k$a;-><init>(Lkotlinx/coroutines/flow/a0$k;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object p2, v0, Lkotlinx/coroutines/flow/a0$k$a;->result:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget v2, v0, Lkotlinx/coroutines/flow/a0$k$a;->label:I

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v3, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v4, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    if-eqz v2, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-eq v2, v4, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-ne v2, v3, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x0

    move v8, v7

    goto/16 :goto_3

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string p2, "ans/ t vteciow hesu  e/usfecrolerr/o//liktobmo/ eni"

    const-string p2, "f/seckao/oeet/  v/ um briecn/ir/ /utolrtwhoisneo el"

    const/4 v8, 0x3

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x4

    move v8, v7

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    throw p1

    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-object p1, v0, Lkotlinx/coroutines/flow/a0$k$a;->L$1:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    check-cast p1, Lkotlin/jvm/internal/k1$h;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object v2, v0, Lkotlinx/coroutines/flow/a0$k$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x0

    check-cast v2, Lkotlinx/coroutines/flow/a0$k;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    goto :goto_1

    :cond_3
    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object p2, p0, Lkotlinx/coroutines/flow/a0$k;->a:Lkotlin/jvm/internal/k1$h;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v2, p2, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    sget-object v5, Lkotlinx/coroutines/flow/internal/u;->a:Lkotlinx/coroutines/internal/r0;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-ne v2, v5, :cond_4

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    goto :goto_2

    :cond_4
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    iget-object v5, p0, Lkotlinx/coroutines/flow/a0$k;->b:Li8/q;

    const/4 v7, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    iput-object p0, v0, Lkotlinx/coroutines/flow/a0$k$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    iput-object p2, v0, Lkotlinx/coroutines/flow/a0$k$a;->L$1:Ljava/lang/Object;

    iput v4, v0, Lkotlinx/coroutines/flow/a0$k$a;->label:I

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-interface {v5, v2, p1, v0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-ne p1, v1, :cond_5

    const/4 v7, 0x4

    and-int/2addr v8, v7

    return-object v1

    :cond_5
    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v6, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    :goto_1
    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object p2, p1

    move-object p2, p1

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    :goto_2
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    iput-object p1, p2, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object p1, v2, Lkotlinx/coroutines/flow/a0$k;->c:Lkotlinx/coroutines/flow/j;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    iget-object p2, v2, Lkotlinx/coroutines/flow/a0$k;->a:Lkotlin/jvm/internal/k1$h;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget-object p2, p2, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x2

    iput-object v2, v0, Lkotlinx/coroutines/flow/a0$k$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    iput-object v2, v0, Lkotlinx/coroutines/flow/a0$k$a;->L$1:Ljava/lang/Object;

    iput v3, v0, Lkotlinx/coroutines/flow/a0$k$a;->label:I

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-interface {p1, p2, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-ne p1, v1, :cond_6

    const/4 v7, 0x1

    const/4 v8, 0x3

    return-object v1

    :cond_6
    :goto_3
    const/4 v8, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    return-object p1
.end method
