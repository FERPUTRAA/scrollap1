.class final Lkotlinx/coroutines/flow/q$d;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/q;->a(Lkotlinx/coroutines/flow/i;Li8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic b:Lkotlin/jvm/internal/k1$f;


# direct methods
.method constructor <init>(Li8/p;Lkotlin/jvm/internal/k1$f;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/p<",
            "-TT;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/jvm/internal/k1$f;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/flow/q$d;->a:Li8/p;

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput-object p2, p0, Lkotlinx/coroutines/flow/q$d;->b:Lkotlin/jvm/internal/k1$f;

    const/4 v1, 0x6

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    instance-of v0, p2, Lkotlinx/coroutines/flow/q$d$a;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    check-cast v0, Lkotlinx/coroutines/flow/q$d$a;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v1, v0, Lkotlinx/coroutines/flow/q$d$a;->label:I

    const/4 v5, 0x2

    const/high16 v2, -0x80000000

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    and-int v3, v1, v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    sub-int/2addr v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput v1, v0, Lkotlinx/coroutines/flow/q$d$a;->label:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v0, Lkotlinx/coroutines/flow/q$d$a;

    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/q$d$a;-><init>(Lkotlinx/coroutines/flow/q$d;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object p2, v0, Lkotlinx/coroutines/flow/q$d$a;->result:Ljava/lang/Object;

    const/4 v4, 0x0

    move v5, v4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v2, v0, Lkotlinx/coroutines/flow/q$d$a;->label:I

    const/4 v5, 0x6

    const/4 v3, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-ne v2, v3, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object p1, v0, Lkotlinx/coroutines/flow/q$d$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    check-cast p1, Lkotlinx/coroutines/flow/q$d;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x1

    const-string/jumbo p2, "woscf/u/heom//ceeat  oreieuk/lri  v/nsble/stinoor /"

    const-string p2, " csielo/cree  ns/ ti/oelrotkin/heb /t/wrau/uomeov/f"

    const-string p2, "t/rmskbr/otn t i oeiau/nlee/e/ f/lrieoccvue/ /whoo "

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    throw p1

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x7

    iget-object p2, p0, Lkotlinx/coroutines/flow/q$d;->a:Li8/p;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput-object p0, v0, Lkotlinx/coroutines/flow/q$d$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x5

    iput v3, v0, Lkotlinx/coroutines/flow/q$d$a;->label:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {p2, p1, v0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-ne p2, v1, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object v1

    :cond_3
    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    check-cast p2, Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz p2, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object p1, p1, Lkotlinx/coroutines/flow/q$d;->b:Lkotlin/jvm/internal/k1$f;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget p2, p1, Lkotlin/jvm/internal/k1$f;->element:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    add-int/2addr p2, v3

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput p2, p1, Lkotlin/jvm/internal/k1$f;->element:I

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-object p1
.end method
