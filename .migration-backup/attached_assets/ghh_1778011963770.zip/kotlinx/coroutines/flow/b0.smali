.class final synthetic Lkotlinx/coroutines/flow/b0;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nZip.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt\n+ 2 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,332:1\n272#1,3:334\n272#1,3:337\n261#1:340\n263#1:342\n272#1,3:343\n261#1:346\n263#1:348\n272#1,3:349\n261#1:352\n263#1:354\n272#1,3:355\n106#2:333\n106#2:341\n106#2:347\n106#2:353\n106#2:358\n106#2:359\n106#2:364\n37#3:360\n36#3,3:361\n37#3:365\n36#3,3:366\n*S KotlinDebug\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt\n*L\n75#1:334,3\n103#1:337,3\n119#1:340\n119#1:342\n138#1:343,3\n156#1:346\n156#1:348\n177#1:349,3\n197#1:352\n197#1:354\n220#1:355,3\n32#1:333\n119#1:341\n156#1:347\n197#1:353\n237#1:358\n261#1:359\n288#1:364\n287#1:360\n287#1:361,3\n306#1:365\n306#1:366,3\n*E\n"
.end annotation


# direct methods
.method public static final synthetic a()Li8/a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s@@~  u~~ f~v~@~~~  anobd@4@@o iy1i@ t~~cf.~@l~@o l@K- @/ s@~o@~/@@ @M~~~S@r t@i ~@oob~ ~  mb "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-static {}, Lkotlinx/coroutines/flow/b0;->r()Li8/a;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public static final synthetic b(Ljava/lang/Iterable;Li8/p;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Iterable<",
            "+",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;>;",
            "Li8/p<",
            "-[TT;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0}, Lkotlin/collections/u;->S5(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-array v0, v0, [Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x4

    const/4 v1, 0x2

    invoke-interface {p0, v0}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p0, [Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x7

    move v2, v1

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Lkotlinx/coroutines/flow/b0$f;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {v0, p0, p1}, Lkotlinx/coroutines/flow/b0$f;-><init>([Lkotlinx/coroutines/flow/i;Li8/p;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string p1, "T<tmkcrasKru inr olysnaKlAno-y y.rrldnetlAnyre tytT.nots aasebayllaoAt i toctrnc_ kVoueop.t>AtJ.oM iosl_nrfnc"

    const-string p1, "rysci u o ai aynKantdAcVntrTuoscyrt oltplaJ-<K_b oratAM spt.nt>Anr selnllo.fkcslnrtean y.elioyArrkeyT_ntooto."

    const/4 v2, 0x3

    const-string p1, ".AtroAur.nl yktaetadfr Te oy.treni.uc>nntnabJ lpntrlok rytalsVyaoopl<Aco- c Keo_Mllstsol oii nKTyAtoycsrnantr"

    const-string p1, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    move v2, v1

    throw p0
.end method

.method public static final c(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
    .locals 2
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T1:",
            "Ljava/lang/Object;",
            "T2:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT2;>;",
            "Li8/q<",
            "-TT1;-TT2;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/flow/k;->J0(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final d(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/r;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Li8/r;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T1:",
            "Ljava/lang/Object;",
            "T2:",
            "Ljava/lang/Object;",
            "T3:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT2;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT3;>;",
            "Li8/r<",
            "-TT1;-TT2;-TT3;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-array v0, v0, [Lkotlinx/coroutines/flow/i;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    aput-object p0, v0, v1

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 p0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    aput-object p1, v0, p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p0, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    aput-object p2, v0, p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance p0, Lkotlinx/coroutines/flow/b0$a;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0, v0, p3}, Lkotlinx/coroutines/flow/b0$a;-><init>([Lkotlinx/coroutines/flow/i;Li8/r;)V

    const/4 v3, 0x0

    return-object p0
.end method

.method public static final e(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/s;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Li8/s;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T1:",
            "Ljava/lang/Object;",
            "T2:",
            "Ljava/lang/Object;",
            "T3:",
            "Ljava/lang/Object;",
            "T4:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT2;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT3;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT4;>;",
            "Li8/s<",
            "-TT1;-TT2;-TT3;-TT4;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-array v0, v0, [Lkotlinx/coroutines/flow/i;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    aput-object p0, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 p0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    aput-object p1, v0, p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 p0, 0x2

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    aput-object p2, v0, p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 p0, 0x3

    xor-int/2addr v3, p0

    aput-object p3, v0, p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    new-instance p0, Lkotlinx/coroutines/flow/b0$b;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0, v0, p4}, Lkotlinx/coroutines/flow/b0$b;-><init>([Lkotlinx/coroutines/flow/i;Li8/s;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object p0
.end method

.method public static final f(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/t;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p5    # Li8/t;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T1:",
            "Ljava/lang/Object;",
            "T2:",
            "Ljava/lang/Object;",
            "T3:",
            "Ljava/lang/Object;",
            "T4:",
            "Ljava/lang/Object;",
            "T5:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT2;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT3;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT4;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT5;>;",
            "Li8/t<",
            "-TT1;-TT2;-TT3;-TT4;-TT5;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x5

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-array v0, v0, [Lkotlinx/coroutines/flow/i;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    aput-object p0, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    aput-object p1, v0, p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 p0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    aput-object p2, v0, p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 p0, 0x1

    const/4 p0, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    aput-object p3, v0, p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p0, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    aput-object p4, v0, p0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance p0, Lkotlinx/coroutines/flow/b0$c;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0, v0, p5}, Lkotlinx/coroutines/flow/b0$c;-><init>([Lkotlinx/coroutines/flow/i;Li8/t;)V

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p0
.end method

.method public static final synthetic g([Lkotlinx/coroutines/flow/i;Li8/p;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">([",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Li8/p<",
            "-[TT;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/b0$e;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0, p0, p1}, Lkotlinx/coroutines/flow/b0$e;-><init>([Lkotlinx/coroutines/flow/i;Li8/p;)V

    const/4 v2, 0x6

    return-object v0
.end method

.method public static final synthetic h(Ljava/lang/Iterable;Li8/q;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p1    # Li8/q;
        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Iterable<",
            "+",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;>;",
            "Li8/q<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-[TT;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0}, Lkotlin/collections/u;->S5(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-array v0, v0, [Lkotlinx/coroutines/flow/i;

    const/4 v2, 0x0

    move v3, v2

    invoke-interface {p0, v0}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    check-cast p0, [Lkotlinx/coroutines/flow/i;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Lkotlinx/coroutines/flow/b0$r;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x4

    move v3, v2

    invoke-direct {v0, p0, p1, v1}, Lkotlinx/coroutines/flow/b0$r;-><init>([Lkotlinx/coroutines/flow/i;Li8/q;Lkotlin/coroutines/d;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0}, Lkotlinx/coroutines/flow/k;->I0(Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string p1, "n>omiryitttlotp A ai-TV<suloedrctMenyaTy.yKA.soca _astrrAknnt r oK. ynr ncn_Jlo b.neatnlelrAsrltc uolkplatoyo"

    const/4 v3, 0x3

    const-string p1, "la s b-ekoAsylpnaJctooykT.anefrroc ter_lr.A onr lt>pttnniysolA r cy_i VKusaK<orrAttibt.laudnl MclotoytnnanyeT"

    const-string p1, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    throw p0
.end method

.method public static final i(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/r;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/r;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T1:",
            "Ljava/lang/Object;",
            "T2:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT2;>;",
            "Li8/r<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-TT1;-TT2;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-array v0, v0, [Lkotlinx/coroutines/flow/i;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    aput-object p0, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 p0, 0x1

    move v3, p0

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    aput-object p1, v0, p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    new-instance p0, Lkotlinx/coroutines/flow/b0$m;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0, v0, p1, p2}, Lkotlinx/coroutines/flow/b0$m;-><init>([Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;Li8/r;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p0}, Lkotlinx/coroutines/flow/k;->I0(Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p0
.end method

.method public static final j(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/s;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Li8/s;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T1:",
            "Ljava/lang/Object;",
            "T2:",
            "Ljava/lang/Object;",
            "T3:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT2;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT3;>;",
            "Li8/s<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-TT1;-TT2;-TT3;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-array v0, v0, [Lkotlinx/coroutines/flow/i;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    aput-object p0, v0, v1

    const/4 v3, 0x6

    const/4 p0, 0x1

    const/4 v3, 0x0

    move v2, p0

    move v2, p0

    const/4 v3, 0x5

    aput-object p1, v0, p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 p0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    aput-object p2, v0, p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance p0, Lkotlinx/coroutines/flow/b0$n;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0, v0, p1, p3}, Lkotlinx/coroutines/flow/b0$n;-><init>([Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;Li8/s;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p0}, Lkotlinx/coroutines/flow/k;->I0(Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p0
.end method

.method public static final k(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/t;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Li8/t;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T1:",
            "Ljava/lang/Object;",
            "T2:",
            "Ljava/lang/Object;",
            "T3:",
            "Ljava/lang/Object;",
            "T4:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT2;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT3;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT4;>;",
            "Li8/t<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-TT1;-TT2;-TT3;-TT4;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-array v0, v0, [Lkotlinx/coroutines/flow/i;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    aput-object p0, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 p0, 0x1

    const/4 v3, 0x2

    aput-object p1, v0, p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 p0, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    aput-object p2, v0, p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 p0, 0x3

    move v3, p0

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    aput-object p3, v0, p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance p0, Lkotlinx/coroutines/flow/b0$o;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0, v0, p1, p4}, Lkotlinx/coroutines/flow/b0$o;-><init>([Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;Li8/t;)V

    const/4 v2, 0x3

    const/4 v2, 0x5

    invoke-static {p0}, Lkotlinx/coroutines/flow/k;->I0(Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p0
.end method

.method public static final l(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/u;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p5    # Li8/u;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T1:",
            "Ljava/lang/Object;",
            "T2:",
            "Ljava/lang/Object;",
            "T3:",
            "Ljava/lang/Object;",
            "T4:",
            "Ljava/lang/Object;",
            "T5:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT2;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT3;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT4;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT5;>;",
            "Li8/u<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-TT1;-TT2;-TT3;-TT4;-TT5;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x5

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-array v0, v0, [Lkotlinx/coroutines/flow/i;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    aput-object p0, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v2, 0x4

    and-int/2addr v3, v2

    aput-object p1, v0, p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p0, 0x2

    const/4 v2, 0x5

    move v3, v2

    aput-object p2, v0, p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 p0, 0x3

    const/4 v3, 0x7

    aput-object p3, v0, p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p0, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    aput-object p4, v0, p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance p0, Lkotlinx/coroutines/flow/b0$p;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0, v0, p1, p5}, Lkotlinx/coroutines/flow/b0$p;-><init>([Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;Li8/u;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p0}, Lkotlinx/coroutines/flow/k;->I0(Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0
.end method

.method public static final synthetic m([Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p1    # Li8/q;
        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">([",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Li8/q<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-[TT;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/b0$q;

    const/4 v3, 0x5

    const/4 v1, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {v0, p0, p1, v1}, Lkotlinx/coroutines/flow/b0$q;-><init>([Lkotlinx/coroutines/flow/i;Li8/q;Lkotlin/coroutines/d;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-static {v0}, Lkotlinx/coroutines/flow/k;->I0(Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0
.end method

.method private static final synthetic n([Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p1    # Li8/q;
        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">([",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Li8/q<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-[TT;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    const/4 v3, 0x0

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/b0$s;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    and-int/2addr v3, v2

    invoke-direct {v0, p0, p1, v1}, Lkotlinx/coroutines/flow/b0$s;-><init>([Lkotlinx/coroutines/flow/i;Li8/q;Lkotlin/coroutines/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0}, Lkotlinx/coroutines/flow/k;->I0(Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0
.end method

.method private static final synthetic o([Lkotlinx/coroutines/flow/i;Li8/p;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">([",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Li8/p<",
            "-[TT;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/b0$t;

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0, p0, p1}, Lkotlinx/coroutines/flow/b0$t;-><init>([Lkotlinx/coroutines/flow/i;Li8/p;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public static final p(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T1:",
            "Ljava/lang/Object;",
            "T2:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT2;>;",
            "Li8/q<",
            "-TT1;-TT2;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lh8/h;
        name = "flowCombine"
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/b0$d;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1, p2}, Lkotlinx/coroutines/flow/b0$d;-><init>(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/q;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public static final q(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/r;)Lkotlinx/coroutines/flow/i;
    .locals 4
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/r;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T1:",
            "Ljava/lang/Object;",
            "T2:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT2;>;",
            "Li8/r<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-TT1;-TT2;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lh8/h;
        name = "flowCombineTransform"
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x6

    new-array v0, v0, [Lkotlinx/coroutines/flow/i;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x6

    aput-object p0, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p0, 0x1

    const/4 v3, 0x1

    aput-object p1, v0, p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance p0, Lkotlinx/coroutines/flow/b0$l;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p0, v0, p1, p2}, Lkotlinx/coroutines/flow/b0$l;-><init>([Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;Li8/r;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0}, Lkotlinx/coroutines/flow/k;->I0(Li8/p;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p0
.end method

.method private static final r()Li8/a;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">()",
            "Li8/a<",
            "[TT;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    sget-object v0, Lkotlinx/coroutines/flow/b0$v;->a:Lkotlinx/coroutines/flow/b0$v;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public static final s(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
    .locals 2
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T1:",
            "Ljava/lang/Object;",
            "T2:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT1;>;",
            "Lkotlinx/coroutines/flow/i<",
            "+TT2;>;",
            "Li8/q<",
            "-TT1;-TT2;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/m;->b(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method
