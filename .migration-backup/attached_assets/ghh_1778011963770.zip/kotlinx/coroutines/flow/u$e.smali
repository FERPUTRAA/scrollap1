.class final Lkotlinx/coroutines/flow/u$e;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/r;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/u;->e(Lkotlinx/coroutines/flow/i;JLi8/p;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/r<",
        "Lkotlinx/coroutines/flow/j<",
        "-TT;>;",
        "Ljava/lang/Throwable;",
        "Ljava/lang/Long;",
        "Lkotlin/coroutines/d<",
        "-",
        "Ljava/lang/Boolean;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__ErrorsKt$retry$3"
    f = "Errors.kt"
    i = {}
    l = {
        0x5f
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $predicate:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "Ljava/lang/Throwable;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $retries:J

.field synthetic J$0:J

.field synthetic L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(JLi8/p;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Li8/p<",
            "-",
            "Ljava/lang/Throwable;",
            "-",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/u$e;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-wide p1, p0, Lkotlinx/coroutines/flow/u$e;->$retries:J

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p3, p0, Lkotlinx/coroutines/flow/u$e;->$predicate:Li8/p;

    const/4 v0, 0x0

    xor-int/2addr v1, v0

    const/4 p1, 0x4

    move v1, p1

    const/4 v0, 0x0

    shl-int/2addr v1, v0

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    move-object v1, p1

    move-object v1, p1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    check-cast v1, Lkotlinx/coroutines/flow/j;

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    check-cast v2, Ljava/lang/Throwable;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    check-cast p3, Ljava/lang/Number;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p3}, Ljava/lang/Number;->longValue()J

    move-result-wide v3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    check-cast v5, Lkotlin/coroutines/d;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual/range {v0 .. v5}, Lkotlinx/coroutines/flow/u$e;->k(Lkotlinx/coroutines/flow/j;Ljava/lang/Throwable;JLkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x4

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget v1, p0, Lkotlinx/coroutines/flow/u$e;->label:I

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/4 v2, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-eqz v1, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-ne v1, v2, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    goto :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string v0, "/oseet/ in wo//s/n  f/c/vlcoelseueok beo/huart rrim"

    const-string v0, "ehseuvlc/ ott/k/oebia/r nen/lremisoooeru / / w/ fct"

    const-string v0, "oh/moean//lfsrcemo/oeilvt/nrr ceuo uwib  ek/tit/e  "

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    throw p1

    :cond_1
    const/4 v8, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/u$e;->L$0:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    check-cast p1, Ljava/lang/Throwable;

    const/4 v8, 0x3

    iget-wide v3, p0, Lkotlinx/coroutines/flow/u$e;->J$0:J

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-wide v5, p0, Lkotlinx/coroutines/flow/u$e;->$retries:J

    const/4 v8, 0x2

    const/4 v7, 0x3

    cmp-long v1, v3, v5

    const/4 v8, 0x0

    const/4 v7, 0x2

    if-gez v1, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/flow/u$e;->$predicate:Li8/p;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    iput v2, p0, Lkotlinx/coroutines/flow/u$e;->label:I

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-interface {v1, p1, p0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-ne p1, v0, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-object v0

    :cond_2
    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x5

    check-cast p1, Ljava/lang/Boolean;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    if-eqz p1, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    goto :goto_1

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/4 v2, 0x0

    :goto_1
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v2}, Lkotlin/coroutines/jvm/internal/b;->a(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/flow/j;Ljava/lang/Throwable;JLkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p5    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Ljava/lang/Throwable;",
            "J",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance p1, Lkotlinx/coroutines/flow/u$e;

    const/4 v4, 0x6

    const/4 v3, 0x6

    iget-wide v0, p0, Lkotlinx/coroutines/flow/u$e;->$retries:J

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v2, p0, Lkotlinx/coroutines/flow/u$e;->$predicate:Li8/p;

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-direct {p1, v0, v1, v2, p5}, Lkotlinx/coroutines/flow/u$e;-><init>(JLi8/p;Lkotlin/coroutines/d;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object p2, p1, Lkotlinx/coroutines/flow/u$e;->L$0:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-wide p3, p1, Lkotlinx/coroutines/flow/u$e;->J$0:J

    const/4 v3, 0x7

    const/4 v4, 0x5

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/u$e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object p1
.end method
