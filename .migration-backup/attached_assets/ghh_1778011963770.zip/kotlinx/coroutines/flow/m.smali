.class final synthetic Lkotlinx/coroutines/flow/m;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nChannels.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Channels.kt\nkotlinx/coroutines/flow/FlowKt__ChannelsKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt\n*L\n1#1,201:1\n1#2:202\n106#3:203\n*S KotlinDebug\n*F\n+ 1 Channels.kt\nkotlinx/coroutines/flow/FlowKt__ChannelsKt\n*L\n177#1:203\n*E\n"
.end annotation


# direct methods
.method public static final synthetic a(Lkotlinx/coroutines/flow/j;Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  si~n~~.@rc f~v~~bi@~@@~@~~@ ~ /Sa@@K @@~  ~ - @~b t @ oo~@~~@1i@@ml@o@4y d/~~ s o@~~blMut~fo o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-static {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/m;->e(Lkotlinx/coroutines/flow/j;Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0
.end method

.method public static final b(Lkotlinx/coroutines/channels/i;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Lkotlinx/coroutines/channels/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i<",
            "TT;>;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->a:Lkotlin/m;
        message = "\'BroadcastChannel\' is obsolete and all corresponding operators are deprecated in the favour of StateFlow and SharedFlow"
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance v0, Lkotlinx/coroutines/flow/m$a;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/m$a;-><init>(Lkotlinx/coroutines/channels/i;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public static final c(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/flow/i;
    .locals 11
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TT;>;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    new-instance v8, Lkotlinx/coroutines/flow/e;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v2, 0x1

    const/4 v10, 0x4

    const/4 v3, 0x6

    const/4 v10, 0x7

    const/4 v3, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    const/4 v4, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v5, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    const/16 v6, 0x1c

    const/4 v10, 0x1

    const/4 v7, 0x0

    const/4 v10, 0x6

    xor-int/2addr v9, v7

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v10, 0x5

    const/4 v9, 0x0

    invoke-direct/range {v0 .. v7}, Lkotlinx/coroutines/flow/e;-><init>(Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    return-object v8
.end method

.method public static final d(Lkotlinx/coroutines/flow/j;Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 3
    .param p0    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlinx/coroutines/channels/i0<",
            "+TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p0, p1, v0, p2}, Lkotlinx/coroutines/flow/m;->e(Lkotlinx/coroutines/flow/j;Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ne p0, p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method private static final e(Lkotlinx/coroutines/flow/j;Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlinx/coroutines/channels/i0<",
            "+TT;>;Z",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    instance-of v0, p3, Lkotlinx/coroutines/flow/m$b;

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    move-object v0, p3

    move-object v0, p3

    move-object v0, p3

    move-object v0, p3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    check-cast v0, Lkotlinx/coroutines/flow/m$b;

    const/4 v7, 0x2

    const/4 v6, 0x7

    iget v1, v0, Lkotlinx/coroutines/flow/m$b;->label:I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/high16 v2, -0x80000000

    const/4 v7, 0x5

    and-int v3, v1, v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eqz v3, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    sub-int/2addr v1, v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput v1, v0, Lkotlinx/coroutines/flow/m$b;->label:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-instance v0, Lkotlinx/coroutines/flow/m$b;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-direct {v0, p3}, Lkotlinx/coroutines/flow/m$b;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object p3, v0, Lkotlinx/coroutines/flow/m$b;->result:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget v2, v0, Lkotlinx/coroutines/flow/m$b;->label:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v3, 0x2

    const/4 v7, 0x4

    const/4 v4, 0x1

    const/4 v7, 0x4

    move v6, v4

    move v6, v4

    const/4 v7, 0x3

    if-eqz v2, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eq v2, v4, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-ne v2, v3, :cond_2

    const/4 v6, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-boolean p0, v0, Lkotlinx/coroutines/flow/m$b;->Z$0:Z

    const/4 v7, 0x1

    iget-object p1, v0, Lkotlinx/coroutines/flow/m$b;->L$1:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    check-cast p1, Lkotlinx/coroutines/channels/i0;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object p2, v0, Lkotlinx/coroutines/flow/m$b;->L$0:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    check-cast p2, Lkotlinx/coroutines/flow/j;

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {p3}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_1
    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    move p2, p0

    move p2, p0

    const/4 v7, 0x7

    move p2, p0

    move p2, p0

    move-object p0, v5

    move-object p0, v5

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto :goto_1

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string p1, "otrmueoh norsneo/w tc//lut /ai/ee/ifoel /ebvmk/ ic "

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    throw p0

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-boolean p0, v0, Lkotlinx/coroutines/flow/m$b;->Z$0:Z

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object p1, v0, Lkotlinx/coroutines/flow/m$b;->L$1:Ljava/lang/Object;

    const/4 v6, 0x5

    move v7, v6

    check-cast p1, Lkotlinx/coroutines/channels/i0;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object p2, v0, Lkotlinx/coroutines/flow/m$b;->L$0:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    check-cast p2, Lkotlinx/coroutines/flow/j;

    :try_start_1
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {p3}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    check-cast p3, Lkotlinx/coroutines/channels/r;

    const/4 v6, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p3}, Lkotlinx/coroutines/channels/r;->o()Ljava/lang/Object;

    move-result-object p3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_2

    :catchall_0
    move-exception p2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto/16 :goto_3

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {p3}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {p0}, Lkotlinx/coroutines/flow/k;->o0(Lkotlinx/coroutines/flow/j;)V

    :goto_1
    :try_start_2
    const/4 v7, 0x3

    const/4 v6, 0x7

    iput-object p0, v0, Lkotlinx/coroutines/flow/m$b;->L$0:Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    iput-object p1, v0, Lkotlinx/coroutines/flow/m$b;->L$1:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    iput-boolean p2, v0, Lkotlinx/coroutines/flow/m$b;->Z$0:Z

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    iput v4, v0, Lkotlinx/coroutines/flow/m$b;->label:I

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {p1, v0}, Lkotlinx/coroutines/channels/i0;->A(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-ne p3, v1, :cond_5

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    return-object v1

    :cond_5
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    move v5, p2

    move v5, p2

    const/4 v7, 0x4

    move v5, p2

    move v5, p2

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    move p0, v5

    move p0, v5

    const/4 v7, 0x5

    move p0, v5

    :goto_2
    :try_start_3
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {p3}, Lkotlinx/coroutines/channels/r;->k(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v2, :cond_8

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {p3}, Lkotlinx/coroutines/channels/r;->f(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-nez p2, :cond_7

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz p0, :cond_6

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 p0, 0x0

    const/4 v7, 0x0

    invoke-static {p1, p0}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    :cond_6
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x3

    const/4 v6, 0x6

    return-object p0

    :cond_7
    :try_start_4
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    throw p2

    :cond_8
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {p3}, Lkotlinx/coroutines/channels/r;->i(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    iput-object p2, v0, Lkotlinx/coroutines/flow/m$b;->L$0:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    iput-object p1, v0, Lkotlinx/coroutines/flow/m$b;->L$1:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput-boolean p0, v0, Lkotlinx/coroutines/flow/m$b;->Z$0:Z

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    iput v3, v0, Lkotlinx/coroutines/flow/m$b;->label:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-interface {p2, p3, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p3
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-ne p3, v1, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-object v1

    :catchall_1
    move-exception p0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    move v5, p2

    move v5, p2

    const/4 v7, 0x4

    move v5, p2

    move v5, p2

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    move p0, v5

    move p0, v5

    const/4 v7, 0x1

    move p0, v5

    :goto_3
    :try_start_5
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    throw p2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :catchall_2
    move-exception p3

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz p0, :cond_9

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {p1, p2}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    :cond_9
    const/4 v7, 0x7

    throw p3
.end method

.method public static final f(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/u0;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Lkotlinx/coroutines/u0;",
            ")",
            "Lkotlinx/coroutines/channels/i0<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlinx/coroutines/d2;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p0}, Lkotlinx/coroutines/flow/internal/f;->b(Lkotlinx/coroutines/flow/i;)Lkotlinx/coroutines/flow/internal/e;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/flow/internal/e;->n(Lkotlinx/coroutines/u0;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method public static final g(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/flow/i;
    .locals 11
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TT;>;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    new-instance v8, Lkotlinx/coroutines/flow/e;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/4 v2, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v3, 0x0

    const/4 v9, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    const/4 v4, 0x0

    const/4 v10, 0x3

    const/4 v5, 0x0

    const/4 v10, 0x5

    xor-int/2addr v9, v5

    const/4 v10, 0x2

    const/16 v6, 0x1c

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v7, 0x0

    const/4 v7, 0x0

    move-object v0, v8

    move-object v0, v8

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-direct/range {v0 .. v7}, Lkotlinx/coroutines/flow/e;-><init>(Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    return-object v8
.end method
