.class public final Lkotlinx/coroutines/flow/l$e$a;
.super Lkotlin/coroutines/jvm/internal/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/l$e;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1$collect$1\n*L\n1#1,112:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__BuildersKt$asFlow$$inlined$unsafeFlow$4"
    f = "Builders.kt"
    i = {
        0x0
    }
    l = {
        0x73
    }
    m = "collect"
    n = {
        "$this$asFlow_u24lambda_u2d5"
    }
    s = {
        "L$0"
    }
.end annotation


# instance fields
.field L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field label:I

.field synthetic result:Ljava/lang/Object;

.field final synthetic this$0:Lkotlinx/coroutines/flow/l$e;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/l$e;Lkotlin/coroutines/d;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/l$e$a;->this$0:Lkotlinx/coroutines/flow/l$e;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/d;-><init>(Lkotlin/coroutines/d;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s~~ ~/~oc @@/fo@@@ SM@~@v@~~o~mb -  ~f~to@ldl a~@4  i@~~ b~@~ r~i~sy@ uoni@@ @.1~ @b@ ~~oK~t@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/flow/l$e$a;->result:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget p1, p0, Lkotlinx/coroutines/flow/l$e$a;->label:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/high16 v0, -0x80000000

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    or-int/2addr p1, v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput p1, p0, Lkotlinx/coroutines/flow/l$e$a;->label:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p1, p0, Lkotlinx/coroutines/flow/l$e$a;->this$0:Lkotlinx/coroutines/flow/l$e;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1, v0, p0}, Lkotlinx/coroutines/flow/l$e;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p1
.end method
