.class final Lkotlinx/coroutines/flow/b0$g;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/q;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0;->p(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/q<",
        "Lkotlinx/coroutines/flow/j<",
        "-TR;>;[",
        "Ljava/lang/Object;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__ZipKt$combine$1$1"
    f = "Zip.kt"
    i = {}
    l = {
        0x21,
        0x21
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $transform:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "TT1;TT2;",
            "Lkotlin/coroutines/d<",
            "-TR;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field synthetic L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Li8/q;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/q<",
            "-TT1;-TT2;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/b0$g;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$g;->$transform:Li8/q;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/4 p1, 0x3

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  sr-ib t4 ofts~b @@ @ocio@@@~~~~f@ ~@@d~~@imon~a/u@l~~ @ ~~~o@~ / l  K~v o~@~M@@.@ ~~ @b@@S 1~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    check-cast p2, [Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    check-cast p3, Lkotlin/coroutines/d;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/b0$g;->k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget v1, p0, Lkotlinx/coroutines/flow/b0$g;->label:I

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v2, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v3, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz v1, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eq v1, v3, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-ne v1, v2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto/16 :goto_1

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v0, "l/ mtfeoa/ c/mwoecouotueesrroi nrkle/n/ /bvh/ i /te"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x4

    const/4 v6, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    throw p1

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$g;->L$0:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    check-cast v1, Lkotlinx/coroutines/flow/j;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_0

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x2

    move v7, v6

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$g;->L$0:Ljava/lang/Object;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    check-cast v1, Lkotlinx/coroutines/flow/j;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$g;->L$1:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x5

    check-cast p1, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v4, p0, Lkotlinx/coroutines/flow/b0$g;->$transform:Li8/q;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x0

    move v7, v5

    const/4 v6, 0x1

    const/4 v6, 0x6

    aget-object v5, p1, v5

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    aget-object p1, p1, v3

    const/4 v7, 0x7

    iput-object v1, p0, Lkotlinx/coroutines/flow/b0$g;->L$0:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    iput v3, p0, Lkotlinx/coroutines/flow/b0$g;->label:I

    const/4 v7, 0x2

    invoke-interface {v4, v5, p1, p0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-ne p1, v0, :cond_3

    const/4 v6, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-object v0

    :cond_3
    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    iput-object v3, p0, Lkotlinx/coroutines/flow/b0$g;->L$0:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    iput v2, p0, Lkotlinx/coroutines/flow/b0$g;->label:I

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-interface {v1, p1, p0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-ne p1, v0, :cond_4

    const/4 v7, 0x7

    return-object v0

    :cond_4
    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;[",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/b0$g;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$g;->$transform:Li8/q;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v0, v1, p3}, Lkotlinx/coroutines/flow/b0$g;-><init>(Li8/q;Lkotlin/coroutines/d;)V

    const/4 v3, 0x2

    iput-object p1, v0, Lkotlinx/coroutines/flow/b0$g;->L$0:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object p2, v0, Lkotlinx/coroutines/flow/b0$g;->L$1:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/flow/b0$g;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object p1
.end method
