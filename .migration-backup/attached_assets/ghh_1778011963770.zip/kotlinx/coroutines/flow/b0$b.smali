.class public final Lkotlinx/coroutines/flow/b0$b;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0;->e(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/s;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TR;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt\n*L\n1#1,112:1\n262#2,2:113\n*E\n"
.end annotation


# instance fields
.field final synthetic a:[Lkotlinx/coroutines/flow/i;

.field final synthetic b:Li8/s;


# direct methods
.method public constructor <init>([Lkotlinx/coroutines/flow/i;Li8/s;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$b;->a:[Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p2, p0, Lkotlinx/coroutines/flow/b0$b;->b:Li8/s;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@usf~@ r@~ o@~-tSy@o   @ @v~/o ~@@l~o.f~ 1@ @~ ~iKs ~~  moti @~iMb~~@c@ ~b~~ d~@@~@@ onl4@~~/a@b"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/flow/b0$b;->a:[Lkotlinx/coroutines/flow/i;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {}, Lkotlinx/coroutines/flow/b0;->a()Li8/a;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    new-instance v2, Lkotlinx/coroutines/flow/b0$b$a;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x7

    iget-object v4, p0, Lkotlinx/coroutines/flow/b0$b;->b:Li8/s;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {v2, v3, v4}, Lkotlinx/coroutines/flow/b0$b$a;-><init>(Lkotlin/coroutines/d;Li8/s;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {p1, v0, v1, v2, p2}, Lkotlinx/coroutines/flow/internal/m;->a(Lkotlinx/coroutines/flow/j;[Lkotlinx/coroutines/flow/i;Li8/a;Li8/q;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-ne p1, p2, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    return-object p1

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-object p1
.end method
