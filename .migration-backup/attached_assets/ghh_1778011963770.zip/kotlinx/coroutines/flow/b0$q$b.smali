.class public final Lkotlinx/coroutines/flow/b0$q$b;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/q;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0$q;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/q<",
        "Lkotlinx/coroutines/flow/j<",
        "-TR;>;[TT;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nZip.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt$combineTransform$6$2\n*L\n1#1,332:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__ZipKt$combineTransform$6$2"
    f = "Zip.kt"
    i = {}
    l = {
        0xfb
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $transform:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;[TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field synthetic L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method public constructor <init>(Li8/q;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/q<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-[TT;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/b0$q$b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$q$b;->$transform:Li8/q;

    const/4 v0, 0x0

    shr-int/2addr v1, v0

    const/4 p1, 0x3

    move v1, p1

    const/4 v0, 0x2

    and-int/2addr v1, v0

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s@~~bt@i~n~@@@~o   r1oMva@co t@ @d fs. @@ m@~~@~l~  @i~i~@~~o- @ /~b ~~@@~b@4Su ~ly@~~ ~ / ofK"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x7

    const/4 v0, 0x6

    check-cast p2, [Ljava/lang/Object;

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    check-cast p3, Lkotlin/coroutines/d;

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/b0$q$b;->k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget v1, p0, Lkotlinx/coroutines/flow/b0$q$b;->label:I

    const/4 v6, 0x6

    const/4 v2, 0x1

    const/4 v6, 0x5

    and-int/2addr v5, v2

    const/4 v6, 0x6

    if-eqz v1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-ne v1, v2, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v0, " wtmcul/etthi o/er/enu/ei bvn f so/ro/ oema/rekicol"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    throw p1

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$q$b;->L$0:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$q$b;->L$1:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    check-cast v1, [Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v3, p0, Lkotlinx/coroutines/flow/b0$q$b;->$transform:Li8/q;

    const/4 v6, 0x6

    const/4 v4, 0x0

    move v5, v4

    move v5, v4

    const/4 v6, 0x1

    iput-object v4, p0, Lkotlinx/coroutines/flow/b0$q$b;->L$0:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput v2, p0, Lkotlinx/coroutines/flow/b0$q$b;->label:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-interface {v3, p1, v1, p0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-ne p1, v0, :cond_2

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-object v0

    :cond_2
    :goto_0
    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-object p1
.end method

.method public final invokeSuspend$$forInline(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$q$b;->L$0:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/flow/b0$q$b;->L$1:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast v0, [Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$q$b;->$transform:Li8/q;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {v1, p1, v0, p0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;[TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/b0$q$b;

    const/4 v3, 0x2

    const/4 v2, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$q$b;->$transform:Li8/q;

    const/4 v3, 0x1

    invoke-direct {v0, v1, p3}, Lkotlinx/coroutines/flow/b0$q$b;-><init>(Li8/q;Lkotlin/coroutines/d;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object p1, v0, Lkotlinx/coroutines/flow/b0$q$b;->L$0:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object p2, v0, Lkotlinx/coroutines/flow/b0$q$b;->L$1:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/flow/b0$q$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p1
.end method
