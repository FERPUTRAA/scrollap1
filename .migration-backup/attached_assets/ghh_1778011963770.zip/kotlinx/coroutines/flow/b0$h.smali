.class public final Lkotlinx/coroutines/flow/b0$h;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0;->g([Lkotlinx/coroutines/flow/i;Li8/p;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/a<",
        "[TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nZip.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt$combine$5$1\n*L\n1#1,332:1\n*E\n"
.end annotation


# instance fields
.field final synthetic $flows:[Lkotlinx/coroutines/flow/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>([Lkotlinx/coroutines/flow/i;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$h;->$flows:[Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final c()[Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()[TT;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/flow/b0$h;->$flows:[Lkotlinx/coroutines/flow/i;

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    array-length v0, v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string v2, "?T"

    const-string v2, "?T"

    const/4 v4, 0x4

    const-string v2, "T?"

    const-string v2, "T?"

    const/4 v3, 0x1

    or-int/2addr v4, v3

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object v0
.end method

.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/flow/b0$h;->c()[Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method
