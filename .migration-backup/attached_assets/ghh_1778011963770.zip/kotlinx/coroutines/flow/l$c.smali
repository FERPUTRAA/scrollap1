.class public final Lkotlinx/coroutines/flow/l$c;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/l;->b(Li8/l;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n*L\n1#1,112:1\n85#2,2:113\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Li8/l;


# direct methods
.method public constructor <init>(Li8/l;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/flow/l$c;->a:Li8/l;

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x6

    instance-of v0, p2, Lkotlinx/coroutines/flow/l$c$a;

    const/4 v6, 0x4

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    check-cast v0, Lkotlinx/coroutines/flow/l$c$a;

    const/4 v5, 0x1

    const/4 v5, 0x4

    iget v1, v0, Lkotlinx/coroutines/flow/l$c$a;->label:I

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/high16 v2, -0x80000000

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    and-int v3, v1, v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    sub-int/2addr v1, v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    iput v1, v0, Lkotlinx/coroutines/flow/l$c$a;->label:I

    const/4 v6, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/l$c$a;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/l$c$a;-><init>(Lkotlinx/coroutines/flow/l$c;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object p2, v0, Lkotlinx/coroutines/flow/l$c$a;->result:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget v2, v0, Lkotlinx/coroutines/flow/l$c$a;->label:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v4, 0x1

    const/4 v6, 0x7

    if-eqz v2, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eq v2, v4, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-ne v2, v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v5, 0x2

    goto :goto_2

    :cond_1
    const/4 v6, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x5

    const-string p2, "iusmin oe /etheeu fi ars rrkectlc//vlo s/b/tn/owo/o"

    const-string p2, "ovselrofuoehacio//btnmeil/tnueik/eco/w /st / e rr  "

    const/4 v6, 0x5

    const-string p2, "re/mace/e n/ i t/io//lrmnoo ie twbuheo/vlt rskfe/oc"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    throw p1

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object p1, v0, Lkotlinx/coroutines/flow/l$c$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_1

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object p2, p0, Lkotlinx/coroutines/flow/l$c;->a:Li8/l;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput-object p1, v0, Lkotlinx/coroutines/flow/l$c$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x6

    move v6, v5

    iput v4, v0, Lkotlinx/coroutines/flow/l$c$a;->label:I

    const/4 v5, 0x2

    and-int/2addr v6, v5

    const/4 v2, 0x6

    move v6, v2

    const/4 v5, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v2}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {p2, v0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v2, 0x7

    const/4 v6, 0x1

    invoke-static {v2}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    if-ne p2, v1, :cond_4

    const/4 v6, 0x1

    return-object v1

    :cond_4
    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput-object v2, v0, Lkotlinx/coroutines/flow/l$c$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput v3, v0, Lkotlinx/coroutines/flow/l$c$a;->label:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    invoke-interface {p1, p2, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-ne p1, v1, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object v1

    :cond_5
    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-object p1
.end method
