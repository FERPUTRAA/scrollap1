.class final Lkotlinx/coroutines/flow/r$c$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/r$c;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/l<",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDelay.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/flow/FlowKt__DelayKt$debounceInternal$1$3$1\n+ 2 Symbol.kt\nkotlinx/coroutines/internal/Symbol\n*L\n1#1,348:1\n18#2:349\n*S KotlinDebug\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/flow/FlowKt__DelayKt$debounceInternal$1$3$1\n*L\n233#1:349\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__DelayKt$debounceInternal$1$3$1"
    f = "Delay.kt"
    i = {}
    l = {
        0xe9
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $downstream:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TT;>;"
        }
    .end annotation
.end field

.field final synthetic $lastValue:Lkotlin/jvm/internal/k1$h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/j;Lkotlin/jvm/internal/k1$h;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/r$c$a;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/flow/r$c$a;->$downstream:Lkotlinx/coroutines/flow/j;

    const/4 v0, 0x7

    move v1, v0

    iput-object p2, p0, Lkotlinx/coroutines/flow/r$c$a;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x3

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final create(Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v0, Lkotlinx/coroutines/flow/r$c$a;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/flow/r$c$a;->$downstream:Lkotlinx/coroutines/flow/j;

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    iget-object v2, p0, Lkotlinx/coroutines/flow/r$c$a;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v0, v1, v2, p1}, Lkotlinx/coroutines/flow/r$c$a;-><init>(Lkotlinx/coroutines/flow/j;Lkotlin/jvm/internal/k1$h;Lkotlin/coroutines/d;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    check-cast p1, Lkotlin/coroutines/d;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/flow/r$c$a;->invoke(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method public final invoke(Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 3
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/flow/r$c$a;->create(Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p1, Lkotlinx/coroutines/flow/r$c$a;

    const/4 v1, 0x7

    sget-object v0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Lkotlinx/coroutines/flow/r$c$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    iget v1, p0, Lkotlinx/coroutines/flow/r$c$a;->label:I

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x7

    move v5, v2

    move v5, v2

    const/4 v6, 0x2

    const/4 v3, 0x7

    const/4 v6, 0x4

    const/4 v3, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-ne v1, v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string v0, "lls/n ur/oo /eck aei//oufitocewet /ros/mn/ sei hebv"

    const-string v0, "b/sreei w/auutoliso/krnvo/  r/t/ / oliecoe/ec hmfen"

    const/4 v6, 0x5

    const-string v0, "ehem/otsi rtonao  /onuce/ ef/ iwirevm/tcok/le /blru"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    throw p1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/r$c$a;->$downstream:Lkotlinx/coroutines/flow/j;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    sget-object v1, Lkotlinx/coroutines/flow/internal/u;->a:Lkotlinx/coroutines/internal/r0;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v4, p0, Lkotlinx/coroutines/flow/r$c$a;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v4, v4, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-ne v4, v1, :cond_2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput v3, p0, Lkotlinx/coroutines/flow/r$c$a;->label:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-interface {p1, v4, p0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-ne p1, v0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-object v0

    :cond_3
    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object p1, p0, Lkotlinx/coroutines/flow/r$c$a;->$lastValue:Lkotlin/jvm/internal/k1$h;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    iput-object v2, p1, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-object p1
.end method
