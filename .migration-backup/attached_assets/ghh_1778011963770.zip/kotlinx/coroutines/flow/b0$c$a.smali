.class public final Lkotlinx/coroutines/flow/b0$c$a;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/q;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0$c;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/q<",
        "Lkotlinx/coroutines/flow/j<",
        "-TR;>;[",
        "Ljava/lang/Object;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nZip.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt$combineUnsafe$1$1\n+ 2 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt\n*L\n1#1,332:1\n198#2,6:333\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__ZipKt$combine$$inlined$combineUnsafe$FlowKt__ZipKt$3$2"
    f = "Zip.kt"
    i = {}
    l = {
        0x14d,
        0x14d
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $transform$inlined:Li8/t;

.field private synthetic L$0:Ljava/lang/Object;

.field synthetic L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method public constructor <init>(Lkotlin/coroutines/d;Li8/t;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p2, p0, Lkotlinx/coroutines/flow/b0$c$a;->$transform$inlined:Li8/t;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p2, 0x3

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p2, p1}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s /lo@~o~ ~@ bo-u@roac ~f@@ iv l@@s ~ @o~@@@@m/~@oi  ~~~y @fbd~~~.4 @~~@ @t ~~~  ~Snt K@~@~Mib"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    check-cast p2, [Ljava/lang/Object;

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    check-cast p3, Lkotlin/coroutines/d;

    const/4 v0, 0x6

    move v1, v0

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/b0$c$a;->k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x5

    iget v1, p0, Lkotlinx/coroutines/flow/b0$c$a;->label:I

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    const/4 v2, 0x2

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x3

    if-eqz v1, :cond_2

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x5

    if-eq v1, v3, :cond_1

    const/4 v12, 0x5

    if-ne v1, v2, :cond_0

    const/4 v11, 0x1

    const/4 v11, 0x4

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    goto/16 :goto_1

    :cond_0
    const/4 v12, 0x5

    const/4 v11, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v12, 0x0

    const/4 v11, 0x1

    const-string v0, "/i/mrseretifnnc/l b/sem eve uto/i htr/ul/ oaeo/wkoc"

    const-string/jumbo v0, "vesaef/m eros/ow uriito/ihlu//oce ttb/ln/ n k/eeroc"

    const/4 v12, 0x4

    const-string/jumbo v0, "teeoos r/w o/nnrll/ooairfecet/c /k/hb /eeimi/v u tu"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x4

    throw p1

    :cond_1
    const/4 v12, 0x0

    const/4 v11, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$c$a;->L$0:Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    check-cast v1, Lkotlinx/coroutines/flow/j;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v11, 0x0

    move v12, v11

    goto :goto_0

    :cond_2
    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x6

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$c$a;->L$0:Ljava/lang/Object;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    check-cast v1, Lkotlinx/coroutines/flow/j;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$c$a;->L$1:Ljava/lang/Object;

    const/4 v12, 0x7

    check-cast p1, [Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    iget-object v4, p0, Lkotlinx/coroutines/flow/b0$c$a;->$transform$inlined:Li8/t;

    const/4 v12, 0x1

    const/4 v5, 0x0

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x7

    aget-object v5, p1, v5

    const/4 v12, 0x5

    aget-object v6, p1, v3

    const/4 v12, 0x6

    aget-object v7, p1, v2

    const/4 v11, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x1

    const/4 v8, 0x3

    const/4 v12, 0x2

    aget-object v8, p1, v8

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x3

    const/4 v9, 0x4

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    aget-object v9, p1, v9

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x2

    iput-object v1, p0, Lkotlinx/coroutines/flow/b0$c$a;->L$0:Ljava/lang/Object;

    const/4 v12, 0x3

    iput v3, p0, Lkotlinx/coroutines/flow/b0$c$a;->label:I

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x3

    const/4 p1, 0x6

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-static {p1}, Lkotlin/jvm/internal/i0;->e(I)V

    move-object v10, p0

    move-object v10, p0

    move-object v10, p0

    move-object v10, p0

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-interface/range {v4 .. v10}, Li8/t;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 v3, 0x7

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-static {v3}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v11, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    if-ne p1, v0, :cond_3

    const/4 v11, 0x7

    xor-int/2addr v12, v11

    return-object v0

    :cond_3
    :goto_0
    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x4

    const/4 v3, 0x0

    const/4 v12, 0x0

    iput-object v3, p0, Lkotlinx/coroutines/flow/b0$c$a;->L$0:Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    iput v2, p0, Lkotlinx/coroutines/flow/b0$c$a;->label:I

    const/4 v12, 0x1

    invoke-interface {v1, p1, p0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x5

    if-ne p1, v0, :cond_4

    const/4 v12, 0x6

    const/4 v11, 0x5

    return-object v0

    :cond_4
    :goto_1
    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v11, 0x1

    or-int/2addr v12, v11

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/flow/j;[Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;[",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/b0$c$a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$c$a;->$transform$inlined:Li8/t;

    const/4 v3, 0x4

    invoke-direct {v0, p3, v1}, Lkotlinx/coroutines/flow/b0$c$a;-><init>(Lkotlin/coroutines/d;Li8/t;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object p1, v0, Lkotlinx/coroutines/flow/b0$c$a;->L$0:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object p2, v0, Lkotlinx/coroutines/flow/b0$c$a;->L$1:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/flow/b0$c$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p1
.end method
