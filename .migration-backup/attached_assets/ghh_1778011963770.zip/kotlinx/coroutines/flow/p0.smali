.class public final Lkotlinx/coroutines/flow/p0;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lkotlinx/coroutines/flow/o0$a;JJ)Lkotlinx/coroutines/flow/o0;
    .locals 2
    .param p0    # Lkotlinx/coroutines/flow/o0$a;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "cos.o/~m@au~f~t~y   @@~~odo o~ l@n~@~S~@~K~ ~ ~@M@r  ~@  o ~1~bi@@@tf~/ @@i @~4@bv~bl ~~-  @s@@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    new-instance p0, Lkotlinx/coroutines/flow/s0;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p1, p2}, Lkotlin/time/e;->L(J)J

    move-result-wide p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p3, p4}, Lkotlin/time/e;->L(J)J

    move-result-wide p3

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/flow/s0;-><init>(JJ)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method

.method public static synthetic b(Lkotlinx/coroutines/flow/o0$a;JJILjava/lang/Object;)Lkotlinx/coroutines/flow/o0;
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    and-int/lit8 p6, p5, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    if-eqz p6, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    sget-object p1, Lkotlin/time/e;->b:Lkotlin/time/e$a;

    const/4 v1, 0x0

    const/4 v0, 0x2

    invoke-virtual {p1}, Lkotlin/time/e$a;->W()J

    move-result-wide p1

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    and-int/lit8 p5, p5, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x4

    if-eqz p5, :cond_1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    sget-object p3, Lkotlin/time/e;->b:Lkotlin/time/e$a;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p3}, Lkotlin/time/e$a;->q()J

    move-result-wide p3

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/flow/p0;->a(Lkotlinx/coroutines/flow/o0$a;JJ)Lkotlinx/coroutines/flow/o0;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method
