.class public final Lkotlinx/coroutines/flow/t$e;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/t;->f(Lkotlinx/coroutines/flow/i;Li8/p;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt\n+ 3 CoroutineScope.kt\nkotlinx/coroutines/CoroutineScopeKt\n*L\n1#1,112:1\n77#2:113\n78#2,7:115\n329#3:114\n*S KotlinDebug\n*F\n+ 1 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt\n*L\n77#1:114\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Li8/p;

.field final synthetic b:Lkotlinx/coroutines/flow/i;


# direct methods
.method public constructor <init>(Li8/p;Lkotlinx/coroutines/flow/i;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/t$e;->a:Li8/p;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p2, p0, Lkotlinx/coroutines/flow/t$e;->b:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x6

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 8
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    instance-of v0, p2, Lkotlinx/coroutines/flow/t$e$a;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    check-cast v0, Lkotlinx/coroutines/flow/t$e$a;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget v1, v0, Lkotlinx/coroutines/flow/t$e$a;->label:I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/high16 v2, -0x80000000

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    and-int v3, v1, v2

    const/4 v7, 0x2

    const/4 v6, 0x0

    if-eqz v3, :cond_0

    const/4 v7, 0x4

    sub-int/2addr v1, v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    iput v1, v0, Lkotlinx/coroutines/flow/t$e$a;->label:I

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/t$e$a;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/t$e$a;-><init>(Lkotlinx/coroutines/flow/t$e;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object p2, v0, Lkotlinx/coroutines/flow/t$e$a;->result:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget v2, v0, Lkotlinx/coroutines/flow/t$e$a;->label:I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v3, 0x2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v4, 0x1

    move v7, v4

    const/4 v6, 0x2

    and-int/2addr v7, v6

    if-eqz v2, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eq v2, v4, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-ne v2, v3, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x3

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x4

    goto/16 :goto_2

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const-string p2, "o/scfimskw ouio/cr e/eniltothb/eteo lv  /e/ur/ear s"

    const-string/jumbo p2, "u se/ooko lo tlwfrim/r/ebc//ivteuaheeo//etcsrnin   "

    const/4 v7, 0x1

    const-string p2, "/tumoekie c cwlvn/otnur//o/ ieelhrofirbo/ t/e/a mse"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    throw p1

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object p1, v0, Lkotlinx/coroutines/flow/t$e$a;->L$2:Ljava/lang/Object;

    const/4 v7, 0x2

    check-cast p1, Lkotlinx/coroutines/flow/internal/v;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v2, v0, Lkotlinx/coroutines/flow/t$e$a;->L$1:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x2

    check-cast v2, Lkotlinx/coroutines/flow/j;

    const/4 v7, 0x0

    iget-object v4, v0, Lkotlinx/coroutines/flow/t$e$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x4

    shr-int/2addr v7, v6

    check-cast v4, Lkotlinx/coroutines/flow/t$e;

    :try_start_0
    const/4 v7, 0x2

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    goto :goto_1

    :catchall_0
    move-exception p2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto/16 :goto_3

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance p2, Lkotlinx/coroutines/flow/internal/v;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-interface {v0}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {p2, p1, v2}, Lkotlinx/coroutines/flow/internal/v;-><init>(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/g;)V

    :try_start_1
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v2, p0, Lkotlinx/coroutines/flow/t$e;->a:Li8/p;

    const/4 v6, 0x2

    move v7, v6

    iput-object p0, v0, Lkotlinx/coroutines/flow/t$e$a;->L$0:Ljava/lang/Object;

    iput-object p1, v0, Lkotlinx/coroutines/flow/t$e$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x4

    and-int/2addr v7, v6

    iput-object p2, v0, Lkotlinx/coroutines/flow/t$e$a;->L$2:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    iput v4, v0, Lkotlinx/coroutines/flow/t$e$a;->label:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v4, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-interface {v2, p2, v0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v4, 0x7

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->e(I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-ne v2, v1, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    return-object v1

    :cond_4
    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object p1, p2

    move-object p1, p2

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p1}, Lkotlinx/coroutines/flow/internal/v;->releaseIntercepted()V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object p1, v4, Lkotlinx/coroutines/flow/t$e;->b:Lkotlinx/coroutines/flow/i;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 p2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput-object p2, v0, Lkotlinx/coroutines/flow/t$e$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    iput-object p2, v0, Lkotlinx/coroutines/flow/t$e$a;->L$1:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    iput-object p2, v0, Lkotlinx/coroutines/flow/t$e$a;->L$2:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    iput v3, v0, Lkotlinx/coroutines/flow/t$e$a;->label:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {p1, v2, v0}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-ne p1, v1, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    return-object v1

    :cond_5
    :goto_2
    const/4 v7, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    return-object p1

    :catchall_1
    move-exception p1

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    :goto_3
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p1}, Lkotlinx/coroutines/flow/internal/v;->releaseIntercepted()V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    throw p2
.end method
