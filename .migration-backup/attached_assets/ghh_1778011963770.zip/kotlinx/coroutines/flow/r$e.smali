.class final Lkotlinx/coroutines/flow/r$e;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/q;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/r;->h(Lkotlinx/coroutines/flow/i;J)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/q<",
        "Lkotlinx/coroutines/u0;",
        "Lkotlinx/coroutines/flow/j<",
        "-TT;>;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDelay.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/flow/FlowKt__DelayKt$sample$2\n+ 2 Select.kt\nkotlinx/coroutines/selects/SelectKt\n*L\n1#1,348:1\n199#2,11:349\n*S KotlinDebug\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/flow/FlowKt__DelayKt$sample$2\n*L\n285#1:349,11\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__DelayKt$sample$2"
    f = "Delay.kt"
    i = {
        0x0,
        0x0,
        0x0,
        0x0
    }
    l = {
        0x160
    }
    m = "invokeSuspend"
    n = {
        "downstream",
        "values",
        "lastValue",
        "ticker"
    }
    s = {
        "L$0",
        "L$1",
        "L$2",
        "L$3"
    }
.end annotation


# instance fields
.field final synthetic $periodMillis:J

.field final synthetic $this_sample:Lkotlinx/coroutines/flow/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field synthetic L$1:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field L$3:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(JLkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/r$e;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-wide p1, p0, Lkotlinx/coroutines/flow/r$e;->$periodMillis:J

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p3, p0, Lkotlinx/coroutines/flow/r$e;->$this_sample:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    const/4 p1, 0x3

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "ifs~m~@s  ot b~@-/@ct~~MK@~~ ~14@~ ~o@@@  @v~f  So ~@~i~@u y@b@ @@@o ~~@n~r@b~d. o@~ oi/a~l~l  ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    check-cast p2, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x7

    check-cast p3, Lkotlin/coroutines/d;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/r$e;->k(Lkotlinx/coroutines/u0;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v13, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v13, 0x4

    iget v1, p0, Lkotlinx/coroutines/flow/r$e;->label:I

    const/4 v13, 0x1

    const/4 v2, 0x1

    const/4 v13, 0x0

    const/4 v3, 0x0

    const/4 v13, 0x6

    if-eqz v1, :cond_1

    const/4 v13, 0x4

    if-ne v1, v2, :cond_0

    const/4 v13, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/flow/r$e;->L$3:Ljava/lang/Object;

    const/4 v13, 0x4

    check-cast v1, Lkotlinx/coroutines/channels/i0;

    const/4 v13, 0x6

    iget-object v4, p0, Lkotlinx/coroutines/flow/r$e;->L$2:Ljava/lang/Object;

    const/4 v13, 0x3

    check-cast v4, Lkotlin/jvm/internal/k1$h;

    const/4 v13, 0x7

    iget-object v5, p0, Lkotlinx/coroutines/flow/r$e;->L$1:Ljava/lang/Object;

    const/4 v13, 0x7

    check-cast v5, Lkotlinx/coroutines/channels/i0;

    const/4 v13, 0x1

    iget-object v6, p0, Lkotlinx/coroutines/flow/r$e;->L$0:Ljava/lang/Object;

    const/4 v13, 0x3

    check-cast v6, Lkotlinx/coroutines/flow/j;

    const/4 v13, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v13, 0x7

    goto :goto_0

    :cond_0
    const/4 v13, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v13, 0x5

    const-string v0, "//im utsen/siloec/aetuow ohrofbevmc/nt/ li  / roe/k"

    const-string v0, " isbo/vauwecuc /eo/nl t/sereektl /ihof mt/i /oonr/r"

    const-string v0, "hrenooea iuml/t/ rt/ne oi /rkeoe toiub/vsof/l c/ecw"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v13, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    const/4 v13, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v13, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/r$e;->L$0:Ljava/lang/Object;

    const/4 v13, 0x7

    check-cast p1, Lkotlinx/coroutines/u0;

    iget-object v1, p0, Lkotlinx/coroutines/flow/r$e;->L$1:Ljava/lang/Object;

    const/4 v13, 0x0

    check-cast v1, Lkotlinx/coroutines/flow/j;

    const/4 v13, 0x4

    const/4 v5, 0x0

    const/4 v13, 0x2

    const/4 v6, -0x1

    const/4 v13, 0x7

    new-instance v7, Lkotlinx/coroutines/flow/r$e$c;

    const/4 v13, 0x4

    iget-object v4, p0, Lkotlinx/coroutines/flow/r$e;->$this_sample:Lkotlinx/coroutines/flow/i;

    const/4 v13, 0x6

    invoke-direct {v7, v4, v3}, Lkotlinx/coroutines/flow/r$e$c;-><init>(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;)V

    const/4 v13, 0x2

    const/4 v8, 0x1

    const/4 v13, 0x4

    const/4 v9, 0x0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v13, 0x0

    invoke-static/range {v4 .. v9}, Lkotlinx/coroutines/channels/e0;->f(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILi8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object v11

    const/4 v13, 0x4

    new-instance v12, Lkotlin/jvm/internal/k1$h;

    const/4 v13, 0x4

    invoke-direct {v12}, Lkotlin/jvm/internal/k1$h;-><init>()V

    const/4 v13, 0x7

    iget-wide v5, p0, Lkotlinx/coroutines/flow/r$e;->$periodMillis:J

    const/4 v13, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v13, 0x5

    const/4 v9, 0x2

    const/4 v13, 0x3

    const/4 v10, 0x0

    const/4 v13, 0x6

    invoke-static/range {v4 .. v10}, Lkotlinx/coroutines/flow/k;->y0(Lkotlinx/coroutines/u0;JJILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v5, v11

    move-object v5, v11

    move-object v5, v11

    move-object v5, v11

    move-object v4, v12

    move-object v4, v12

    move-object v4, v12

    move-object v4, v12

    move-object v1, p1

    move-object v1, p1

    :goto_0
    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    :cond_2
    const/4 v13, 0x4

    iget-object v7, v4, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v13, 0x7

    sget-object v8, Lkotlinx/coroutines/flow/internal/u;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v13, 0x2

    if-eq v7, v8, :cond_4

    iput-object v6, p1, Lkotlinx/coroutines/flow/r$e;->L$0:Ljava/lang/Object;

    const/4 v13, 0x6

    iput-object v5, p1, Lkotlinx/coroutines/flow/r$e;->L$1:Ljava/lang/Object;

    const/4 v13, 0x4

    iput-object v4, p1, Lkotlinx/coroutines/flow/r$e;->L$2:Ljava/lang/Object;

    const/4 v13, 0x7

    iput-object v1, p1, Lkotlinx/coroutines/flow/r$e;->L$3:Ljava/lang/Object;

    const/4 v13, 0x0

    iput v2, p1, Lkotlinx/coroutines/flow/r$e;->label:I

    const/4 v13, 0x4

    new-instance v7, Lkotlinx/coroutines/selects/b;

    const/4 v13, 0x1

    invoke-direct {v7, p1}, Lkotlinx/coroutines/selects/b;-><init>(Lkotlin/coroutines/d;)V

    :try_start_0
    const/4 v13, 0x1

    invoke-interface {v5}, Lkotlinx/coroutines/channels/i0;->u()Lkotlinx/coroutines/selects/d;

    move-result-object v8

    const/4 v13, 0x3

    new-instance v9, Lkotlinx/coroutines/flow/r$e$a;

    const/4 v13, 0x1

    invoke-direct {v9, v4, v1, v3}, Lkotlinx/coroutines/flow/r$e$a;-><init>(Lkotlin/jvm/internal/k1$h;Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)V

    const/4 v13, 0x2

    invoke-interface {v7, v8, v9}, Lkotlinx/coroutines/selects/a;->J(Lkotlinx/coroutines/selects/d;Li8/p;)V

    const/4 v13, 0x2

    invoke-interface {v1}, Lkotlinx/coroutines/channels/i0;->r()Lkotlinx/coroutines/selects/d;

    move-result-object v8

    const/4 v13, 0x6

    new-instance v9, Lkotlinx/coroutines/flow/r$e$b;

    const/4 v13, 0x3

    invoke-direct {v9, v4, v6, v3}, Lkotlinx/coroutines/flow/r$e$b;-><init>(Lkotlin/jvm/internal/k1$h;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)V

    const/4 v13, 0x0

    invoke-interface {v7, v8, v9}, Lkotlinx/coroutines/selects/a;->J(Lkotlinx/coroutines/selects/d;Li8/p;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v8

    const/4 v13, 0x1

    invoke-virtual {v7, v8}, Lkotlinx/coroutines/selects/b;->M0(Ljava/lang/Throwable;)V

    :goto_1
    const/4 v13, 0x6

    invoke-virtual {v7}, Lkotlinx/coroutines/selects/b;->L0()Ljava/lang/Object;

    move-result-object v7

    const/4 v13, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v8

    const/4 v13, 0x1

    if-ne v7, v8, :cond_3

    const/4 v13, 0x2

    invoke-static {p1}, Lkotlin/coroutines/jvm/internal/h;->c(Lkotlin/coroutines/d;)V

    :cond_3
    const/4 v13, 0x2

    if-ne v7, v0, :cond_2

    const/4 v13, 0x3

    return-object v0

    :cond_4
    const/4 v13, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v13, 0x4

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/u0;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/r$e;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-wide v1, p0, Lkotlinx/coroutines/flow/r$e;->$periodMillis:J

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v3, p0, Lkotlinx/coroutines/flow/r$e;->$this_sample:Lkotlinx/coroutines/flow/i;

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2, v3, p3}, Lkotlinx/coroutines/flow/r$e;-><init>(JLkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput-object p1, v0, Lkotlinx/coroutines/flow/r$e;->L$0:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput-object p2, v0, Lkotlinx/coroutines/flow/r$e;->L$1:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/flow/r$e;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-object p1
.end method
