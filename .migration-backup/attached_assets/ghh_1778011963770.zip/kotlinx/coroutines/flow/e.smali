.class final Lkotlinx/coroutines/flow/e;
.super Lkotlinx/coroutines/flow/internal/e;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/flow/internal/e<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nChannels.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Channels.kt\nkotlinx/coroutines/flow/ChannelAsFlow\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,201:1\n1#2:202\n*E\n"
.end annotation


# static fields
.field private static final synthetic f:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;


# instance fields
.field private volatile synthetic consumed:I
    .annotation build Lia/d;
    .end annotation
.end field

.field private final d:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private final e:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-class v0, Lkotlinx/coroutines/flow/e;

    const-class v0, Lkotlinx/coroutines/flow/e;

    const/4 v3, 0x4

    const-class v0, Lkotlinx/coroutines/flow/e;

    const-class v0, Lkotlinx/coroutines/flow/e;

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string v1, "essdsmcu"

    const-string v1, "sesndmcu"

    const/4 v3, 0x5

    const-string v1, "odemnmus"

    const-string v1, "consumed"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, v1}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    sput-object v0, Lkotlinx/coroutines/flow/e;->f:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v2, 0x6

    and-int/2addr v3, v2

    return-void
.end method

.method public constructor <init>(Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p5    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TT;>;Z",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")V"
        }
    .end annotation

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p3, p4, p5}, Lkotlinx/coroutines/flow/internal/e;-><init>(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/e;->d:Lkotlinx/coroutines/channels/i0;

    const/4 v0, 0x3

    move v1, v0

    iput-boolean p2, p0, Lkotlinx/coroutines/flow/e;->e:Z

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v0, 0x7

    move v1, v0

    iput p1, p0, Lkotlinx/coroutines/flow/e;->consumed:I

    const/4 v1, 0x2

    return-void
.end method

.method public synthetic constructor <init>(Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    and-int/lit8 p7, p6, 0x4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz p7, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    sget-object p3, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    :cond_0
    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    and-int/lit8 p3, p6, 0x8

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz p3, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 p4, -0x3

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    move v4, p4

    move v4, p4

    move v4, p4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    and-int/lit8 p3, p6, 0x10

    const/4 v6, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz p3, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    sget-object p5, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    :cond_2
    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    move v2, p2

    move v2, p2

    const/4 v7, 0x5

    move v2, p2

    move v2, p2

    const/4 v7, 0x0

    invoke-direct/range {v0 .. v5}, Lkotlinx/coroutines/flow/e;-><init>(Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    return-void
.end method

.method private final o()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~o@o l b@ /@boi~@K~bo o1~@Sf- ~y@u ~@v~~@t~M ~.@@ @d 4@m o~s@ctl@ar~@f~@n @/  i ~~ ~@~ ~~~o~~ i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-boolean v0, p0, Lkotlinx/coroutines/flow/e;->e:Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v0, Lkotlinx/coroutines/flow/e;->f:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, p0, v1}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->getAndSet(Ljava/lang/Object;I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string v1, "lCRlcbilbuemjnt oetsvn leo d AFcwonsa.aeeeccuno secenem"

    const-string/jumbo v1, "wc meaelteuncnevelc mceA ts RnoFeCisndjb.laleoucesonc o"

    const/4 v3, 0x0

    const-string v1, "eeRnvoutl cls AoeenCn oajcea .neFucietcldhnccmwub soele"

    const-string v1, "ReceiveChannel.consumeAsFlow can be collected just once"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw v0

    :cond_2
    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v0, p0, Lkotlinx/coroutines/flow/internal/e;->b:I

    const/4 v1, -0x6

    const/4 v1, -0x3

    const/4 v3, 0x7

    const/4 v1, -0x3

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ne v0, v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0}, Lkotlinx/coroutines/flow/e;->o()V

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    iget-object v0, p0, Lkotlinx/coroutines/flow/e;->d:Lkotlinx/coroutines/channels/i0;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-boolean v1, p0, Lkotlinx/coroutines/flow/e;->e:Z

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1, v0, v1, p2}, Lkotlinx/coroutines/flow/m;->a(Lkotlinx/coroutines/flow/j;Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ne p1, p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object p1

    :cond_1
    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-super {p0, p1, p2}, Lkotlinx/coroutines/flow/internal/e;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-ne p1, p2, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object p1

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p1
.end method

.method protected f()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, "neaho=cp"

    const-string v1, "ecnao=lh"

    const/4 v3, 0x2

    const-string v1, "qlhcena="

    const-string v1, "channel="

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    or-int/2addr v3, v2

    iget-object v1, p0, Lkotlinx/coroutines/flow/e;->d:Lkotlinx/coroutines/channels/i0;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method protected h(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Lkotlinx/coroutines/flow/internal/y;

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-direct {v0, p1}, Lkotlinx/coroutines/flow/internal/y;-><init>(Lkotlinx/coroutines/channels/m0;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/e;->d:Lkotlinx/coroutines/channels/i0;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-boolean v1, p0, Lkotlinx/coroutines/flow/e;->e:Z

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0, p1, v1, p2}, Lkotlinx/coroutines/flow/m;->a(Lkotlinx/coroutines/flow/j;Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-ne p1, p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x1

    return-object p1
.end method

.method protected i(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/internal/e;
    .locals 9
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")",
            "Lkotlinx/coroutines/flow/internal/e<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-instance v6, Lkotlinx/coroutines/flow/e;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/flow/e;->d:Lkotlinx/coroutines/channels/i0;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    iget-boolean v2, p0, Lkotlinx/coroutines/flow/e;->e:Z

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    move v4, p2

    move v4, p2

    const/4 v8, 0x7

    move v4, p2

    move v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v5}, Lkotlinx/coroutines/flow/e;-><init>(Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    return-object v6
.end method

.method public k()Lkotlinx/coroutines/flow/i;
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    new-instance v8, Lkotlinx/coroutines/flow/e;

    const/4 v10, 0x4

    const/4 v9, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/flow/e;->d:Lkotlinx/coroutines/channels/i0;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    iget-boolean v2, p0, Lkotlinx/coroutines/flow/e;->e:Z

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    const/4 v3, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    const/4 v4, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/4 v5, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/16 v6, 0x1c

    const/4 v9, 0x7

    xor-int/2addr v10, v9

    const/4 v7, 0x0

    shl-int/2addr v10, v7

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-direct/range {v0 .. v7}, Lkotlinx/coroutines/flow/e;-><init>(Lkotlinx/coroutines/channels/i0;ZLkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    return-object v8
.end method

.method public n(Lkotlinx/coroutines/u0;)Lkotlinx/coroutines/channels/i0;
    .locals 4
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            ")",
            "Lkotlinx/coroutines/channels/i0<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/flow/e;->o()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v0, p0, Lkotlinx/coroutines/flow/internal/e;->b:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, -0x3

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/e;->d:Lkotlinx/coroutines/channels/i0;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-super {p0, p1}, Lkotlinx/coroutines/flow/internal/e;->n(Lkotlinx/coroutines/u0;)Lkotlinx/coroutines/channels/i0;

    move-result-object p1

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object p1
.end method
