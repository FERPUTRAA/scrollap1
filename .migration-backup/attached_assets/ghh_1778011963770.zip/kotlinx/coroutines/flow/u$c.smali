.class final Lkotlinx/coroutines/flow/u$c;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/u;->b(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TT;>;"
        }
    .end annotation
.end field

.field final synthetic b:Lkotlin/jvm/internal/k1$h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/j;Lkotlin/jvm/internal/k1$h;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/jvm/internal/k1$h<",
            "Ljava/lang/Throwable;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/u$c;->a:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p2, p0, Lkotlinx/coroutines/flow/u$c;->b:Lkotlin/jvm/internal/k1$h;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    instance-of v0, p2, Lkotlinx/coroutines/flow/u$c$a;

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    check-cast v0, Lkotlinx/coroutines/flow/u$c$a;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget v1, v0, Lkotlinx/coroutines/flow/u$c$a;->label:I

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/high16 v2, -0x80000000

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    and-int v3, v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    if-eqz v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    sub-int/2addr v1, v2

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    iput v1, v0, Lkotlinx/coroutines/flow/u$c$a;->label:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/u$c$a;

    const/4 v4, 0x4

    or-int/2addr v5, v4

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/u$c$a;-><init>(Lkotlinx/coroutines/flow/u$c;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v4, 0x6

    iget-object p2, v0, Lkotlinx/coroutines/flow/u$c$a;->result:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget v2, v0, Lkotlinx/coroutines/flow/u$c$a;->label:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-ne v2, v3, :cond_1

    const/4 v5, 0x0

    iget-object p1, v0, Lkotlinx/coroutines/flow/u$c$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x3

    check-cast p1, Lkotlinx/coroutines/flow/u$c;

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_1

    :catchall_0
    move-exception p2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    goto :goto_2

    :cond_1
    const/4 v5, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string p2, "eism o/ooells ike /ia/fn eu/rr httbse///vwcnu /oote"

    const-string p2, "/es/enutm/r ko/ ws v o oioa/ctlr/oebenh/fiu eiel/ct"

    const/4 v5, 0x3

    const-string p2, "//hmoto//es/ono leotr /r ecii/vaf/lwt ic mueeebnkr "

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    throw p1

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object p2, p0, Lkotlinx/coroutines/flow/u$c;->a:Lkotlinx/coroutines/flow/j;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput-object p0, v0, Lkotlinx/coroutines/flow/u$c$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput v3, v0, Lkotlinx/coroutines/flow/u$c$a;->label:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {p2, p1, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-ne p1, v1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object v1

    :cond_3
    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-object p1

    :catchall_1
    move-exception p2

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    :goto_2
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object p1, p1, Lkotlinx/coroutines/flow/u$c;->b:Lkotlin/jvm/internal/k1$h;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    iput-object p2, p1, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    throw p2
.end method
