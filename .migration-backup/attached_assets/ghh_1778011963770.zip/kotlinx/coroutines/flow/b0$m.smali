.class public final Lkotlinx/coroutines/flow/b0$m;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0;->i(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/r;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/flow/j<",
        "-TR;>;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nZip.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt$combineTransformUnsafe$1\n*L\n1#1,332:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__ZipKt$combineTransform$$inlined$combineTransformUnsafe$FlowKt__ZipKt$2"
    f = "Zip.kt"
    i = {}
    l = {
        0x111
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $flows:[Lkotlinx/coroutines/flow/i;

.field final synthetic $transform$inlined:Li8/r;

.field private synthetic L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method public constructor <init>([Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;Li8/r;)V
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$m;->$flows:[Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x3

    iput-object p3, p0, Lkotlinx/coroutines/flow/b0$m;->$transform$inlined:Li8/r;

    const/4 v1, 0x2

    const/4 p1, 0x2

    const/4 v1, 0x3

    const/4 p1, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/b0$m;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$m;->$flows:[Lkotlinx/coroutines/flow/i;

    const/4 v4, 0x2

    const/4 v3, 0x1

    iget-object v2, p0, Lkotlinx/coroutines/flow/b0$m;->$transform$inlined:Li8/r;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v0, v1, p2, v2}, Lkotlinx/coroutines/flow/b0$m;-><init>([Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;Li8/r;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-object p1, v0, Lkotlinx/coroutines/flow/b0$m;->L$0:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/b0$m;->invoke(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/flow/b0$m;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    check-cast p1, Lkotlinx/coroutines/flow/b0$m;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/flow/b0$m;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v7, 0x4

    move v8, v7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget v1, p0, Lkotlinx/coroutines/flow/b0$m;->label:I

    const/4 v7, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/4 v2, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-eqz v1, :cond_1

    const/4 v7, 0x3

    move v8, v7

    if-ne v1, v2, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x4

    goto :goto_0

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string/jumbo v0, "u/smcb  o/nlw//e / cvuio/oe nhrolerit tae/rteeiok/f"

    const/4 v8, 0x4

    const-string v0, " isloefn kauebcm/wti/ tolurevrt n/eo/i/ //er/eshoc "

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    throw p1

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/flow/b0$m;->L$0:Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v8, 0x7

    const/4 v7, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/flow/b0$m;->$flows:[Lkotlinx/coroutines/flow/i;

    const/4 v7, 0x3

    and-int/2addr v8, v7

    invoke-static {}, Lkotlinx/coroutines/flow/b0;->a()Li8/a;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance v4, Lkotlinx/coroutines/flow/b0$m$a;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v5, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget-object v6, p0, Lkotlinx/coroutines/flow/b0$m;->$transform$inlined:Li8/r;

    const/4 v8, 0x2

    const/4 v7, 0x7

    invoke-direct {v4, v5, v6}, Lkotlinx/coroutines/flow/b0$m$a;-><init>(Lkotlin/coroutines/d;Li8/r;)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    iput v2, p0, Lkotlinx/coroutines/flow/b0$m;->label:I

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {p1, v1, v3, v4, p0}, Lkotlinx/coroutines/flow/internal/m;->a(Lkotlinx/coroutines/flow/j;[Lkotlinx/coroutines/flow/i;Li8/a;Li8/q;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-ne p1, v0, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    return-object v0

    :cond_2
    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    return-object p1
.end method
