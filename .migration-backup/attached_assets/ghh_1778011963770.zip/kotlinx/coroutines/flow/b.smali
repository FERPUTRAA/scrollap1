.class final Lkotlinx/coroutines/flow/b;
.super Lkotlinx/coroutines/flow/f;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/flow/f<",
        "TT;>;"
    }
.end annotation


# instance fields
.field private final e:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Li8/p;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V
    .locals 2
    .param p1    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/flow/f;-><init>(Li8/p;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/b;->e:Li8/p;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public synthetic constructor <init>(Li8/p;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    and-int/lit8 p6, p5, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    if-eqz p6, :cond_0

    const/4 v1, 0x1

    sget-object p2, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    and-int/lit8 p6, p5, 0x4

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-eqz p6, :cond_1

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    const/4 p3, -0x2

    :cond_1
    and-int/lit8 p5, p5, 0x8

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-eqz p5, :cond_2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    sget-object p4, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    :cond_2
    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/flow/b;-><init>(Li8/p;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method protected h(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    instance-of v0, p2, Lkotlinx/coroutines/flow/b$a;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    check-cast v0, Lkotlinx/coroutines/flow/b$a;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget v1, v0, Lkotlinx/coroutines/flow/b$a;->label:I

    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/high16 v2, -0x80000000

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    and-int v3, v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    sub-int/2addr v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput v1, v0, Lkotlinx/coroutines/flow/b$a;->label:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v0, Lkotlinx/coroutines/flow/b$a;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/b$a;-><init>(Lkotlinx/coroutines/flow/b;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v4, 0x3

    move v5, v4

    iget-object p2, v0, Lkotlinx/coroutines/flow/b$a;->result:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget v2, v0, Lkotlinx/coroutines/flow/b$a;->label:I

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    if-eqz v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-ne v2, v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x1

    iget-object p1, v0, Lkotlinx/coroutines/flow/b$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_1

    :cond_1
    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string p2, "fes s/r/lio/  oer ot ne/rocb itov/hl/auintseue/km/w"

    const-string p2, "/is ima kocer euo lbuor/e/otevs/  nfhriottewln//e//"

    const/4 v5, 0x0

    const-string p2, " femvlso/t iwo  ota/knetue eeci//urm///oen/clrrhboi"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    throw p1

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput-object p1, v0, Lkotlinx/coroutines/flow/b$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput v3, v0, Lkotlinx/coroutines/flow/b$a;->label:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-super {p0, p1, v0}, Lkotlinx/coroutines/flow/f;->h(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-ne p2, v1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object v1

    :cond_3
    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-interface {p1}, Lkotlinx/coroutines/channels/m0;->E()Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz p1, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object p1

    :cond_4
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string p2, "i)aCodsac/ nl a nblban/ceo cteosafas  c e ab e/yuactOeserudtlcl dnta.nens PlolnccAlFCaec/i.xomlrka aaLhwoeOerr  nohre  lolulFc issate dco}ne/.tiaoeI{isnywwkllnlielaemk ble ilkrfcbo ewk cti/oa/rue fai(en ahltctdeke. bl  Shmalt,n"

    const-string p2, "kenmbietO d sysalCl aa  ) ahndlakci /naooilc hfo Cleicc wnwaaeasl uon/ik d uS uy/tle.ianereers ,nbn cmbnn}F  te/nflukohb xlre/ l.csAtOos( s/eccttn alae allld ieaotiFwca oecoe.aPla.d ceea{wlLcrltolaeto/bbockiaktlsleenmhIrrerefc "

    const/4 v5, 0x4

    const-string p2, "akclnbd uabwettye esos nn  tnultc.Ia la/i th{..e.sllno  eoebtsdfAaalrilet  es/in  Fai /c hdnodutcciO oaleaxrerwo  norscoyccCks//ka(lbl nllltidn)lnlh iFa/nak rwcuLcbeahliataoaese lCo, ofeP /eertlmia abweael}Oecfnccekeoe bm Slkca"

    const-string p2, "\'awaitClose { yourCallbackOrListener.cancel() }\' should be used in the end of callbackFlow block.\nOtherwise, a callback/listener may leak in case of external cancellation.\nSee callbackFlow API documentation for the details."

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    throw p1
.end method

.method protected i(Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/internal/e;
    .locals 4
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")",
            "Lkotlinx/coroutines/flow/internal/e<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Lkotlinx/coroutines/flow/b;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/flow/b;->e:Li8/p;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0, v1, p1, p2, p3}, Lkotlinx/coroutines/flow/b;-><init>(Li8/p;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0
.end method
