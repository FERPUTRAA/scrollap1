.class public final Lkotlinx/coroutines/flow/b0$t;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0;->o([Lkotlinx/coroutines/flow/i;Li8/p;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TR;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt\n*L\n1#1,112:1\n262#2,2:113\n*E\n"
.end annotation


# instance fields
.field final synthetic a:[Lkotlinx/coroutines/flow/i;

.field final synthetic b:Li8/p;


# direct methods
.method public constructor <init>([Lkotlinx/coroutines/flow/i;Li8/p;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$t;->a:[Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lkotlinx/coroutines/flow/b0$t;->b:Li8/p;

    const/4 v1, 0x7

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@~s/v-om@o@14/~~  t.@~~~~iyf~s@ MKd~  ~@~~bb@S @@ o~~loo~ @no@c ~ @~~@ ~b@ af @l @u  ~ @@ti@~ri@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/flow/b0$t;->a:[Lkotlinx/coroutines/flow/i;

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-static {}, Lkotlinx/coroutines/flow/b0;->a()Li8/a;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-instance v2, Lkotlinx/coroutines/flow/b0$u;

    const/4 v5, 0x6

    move v6, v5

    iget-object v3, p0, Lkotlinx/coroutines/flow/b0$t;->b:Li8/p;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {v2, v3, v4}, Lkotlinx/coroutines/flow/b0$u;-><init>(Li8/p;Lkotlin/coroutines/d;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {p1, v0, v1, v2, p2}, Lkotlinx/coroutines/flow/internal/m;->a(Lkotlinx/coroutines/flow/j;[Lkotlinx/coroutines/flow/i;Li8/a;Li8/q;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-ne p1, p2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object p1

    :cond_0
    const/4 v5, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    return-object p1
.end method

.method public f(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v0, 0x4

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-instance v0, Lkotlinx/coroutines/flow/b0$t$a;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/b0$t$a;-><init>(Lkotlinx/coroutines/flow/b0$t;Lkotlin/coroutines/d;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v0, 0x5

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/flow/b0$t;->a:[Lkotlinx/coroutines/flow/i;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {}, Lkotlinx/coroutines/flow/b0;->a()Li8/a;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {}, Lkotlin/jvm/internal/l0;->w()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v2, Lkotlinx/coroutines/flow/b0$u;

    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v3, p0, Lkotlinx/coroutines/flow/b0$t;->b:Li8/p;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v2, v3, v4}, Lkotlinx/coroutines/flow/b0$u;-><init>(Li8/p;Lkotlin/coroutines/d;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v3}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p1, v0, v1, v2, p2}, Lkotlinx/coroutines/flow/internal/m;->a(Lkotlinx/coroutines/flow/j;[Lkotlinx/coroutines/flow/i;Li8/a;Li8/q;Lkotlin/coroutines/d;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 p1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {p1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x0

    return-object p1
.end method
