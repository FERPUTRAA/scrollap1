.class final Lkotlinx/coroutines/flow/q$b;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/q;->b(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlin/jvm/internal/k1$f;


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/k1$f;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/q$b;->a:Lkotlin/jvm/internal/k1$f;

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/flow/q$b;->a:Lkotlin/jvm/internal/k1$f;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget p2, p1, Lkotlin/jvm/internal/k1$f;->element:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    add-int/lit8 p2, p2, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p2, p1, Lkotlin/jvm/internal/k1$f;->element:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method
