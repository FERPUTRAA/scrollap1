.class public final Lkotlinx/coroutines/flow/k0;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSharedFlow.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SharedFlow.kt\nkotlinx/coroutines/flow/SharedFlowKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,733:1\n1#2:734\n*E\n"
.end annotation


# static fields
.field public static final a:Lkotlinx/coroutines/internal/r0;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Lkotlinx/coroutines/internal/r0;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string v1, "OVss_LAN"

    const-string v1, "E_sVANOL"

    const/4 v3, 0x4

    const-string v1, "EVUm_NAL"

    const-string v1, "NO_VALUE"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lkotlinx/coroutines/internal/r0;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    sput-object v0, Lkotlinx/coroutines/flow/k0;->a:Lkotlinx/coroutines/internal/r0;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public static final a(IILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/d0;
    .locals 5
    .param p2    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(II",
            "Lkotlinx/coroutines/channels/m;",
            ")",
            "Lkotlinx/coroutines/flow/d0<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x7

    if-ltz p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    move v2, v0

    move v2, v0

    const/4 v4, 0x0

    move v2, v0

    move v2, v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    move v2, v1

    move v2, v1

    const/4 v4, 0x6

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v2, :cond_7

    const/4 v4, 0x5

    const/4 v3, 0x0

    if-ltz p1, :cond_1

    const/4 v4, 0x7

    move v2, v0

    move v2, v0

    const/4 v4, 0x4

    move v2, v0

    move v2, v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move v2, v1

    const/4 v4, 0x6

    move v2, v1

    move v2, v1

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v2, :cond_6

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-gtz p0, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-gtz p1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    sget-object v2, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-ne p2, v2, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_2

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    move v0, v1

    move v0, v1

    const/4 v4, 0x4

    move v0, v1

    move v0, v1

    :cond_3
    :goto_2
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    add-int/2addr p1, p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-gez p1, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const p1, 0x7fffffff

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/j0;

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, p0, p1, p2}, Lkotlinx/coroutines/flow/j0;-><init>(IILkotlinx/coroutines/channels/m;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object v0

    :cond_5
    const/4 v4, 0x6

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string p1, "sliaorafytynewueyee aBgt beC ape swomlOptiuesxBnvtm f-ttrfehorualrfiofea frt cnro  vuird p"

    const-string p1, "fl-ma rxy rrheyisent rmtcoievaBtwunueOasvaafiouypgtpooterfsfbelwl f  C  prneetet fB urdtai"

    const/4 v4, 0x6

    const-string p1, "oylfvbxgaeesfmain t t OooaB uCe rapfctlioae ptp w- efarudsrrtfrtwelfty rereBsveunibut hyon"

    const-string p1, "replay or extraBufferCapacity must be positive with non-default onBufferOverflow strategy "

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    throw p1

    :cond_6
    const/4 v4, 0x2

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string p2, "anreo nut f iewtnsetacyrBc p o,ax tbaaiaftbgveuC"

    const/4 v4, 0x1

    const-string p2, " bawr u nCuais y axgaeautnft,B bniatpetevreefcct"

    const-string p2, "extraBufferCapacity cannot be negative, but was "

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    throw p1

    :cond_7
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string p2, "beotia psbttng p uaewcaen l narey,b"

    const-string p2, "ba asbt gbre ,yecawnnpluiea t nt oe"

    const/4 v4, 0x7

    const-string p2, "pyvltierqebt   cstunewaa , banoe na"

    const-string p2, "replay cannot be negative, but was "

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    throw p1
.end method

.method public static synthetic b(IILkotlinx/coroutines/channels/m;ILjava/lang/Object;)Lkotlinx/coroutines/flow/d0;
    .locals 3

    const/4 v2, 0x4

    and-int/lit8 p4, p3, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz p4, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    move p0, v0

    move p0, v0

    const/4 v2, 0x5

    move p0, v0

    move p0, v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    and-int/lit8 p4, p3, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x6

    if-eqz p4, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    move p1, v0

    move p1, v0

    const/4 v2, 0x6

    move p1, v0

    move p1, v0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x3

    and-int/lit8 p3, p3, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz p3, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object p2, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/flow/k0;->a(IILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/d0;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public static final synthetic c([Ljava/lang/Object;J)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/flow/k0;->f([Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method public static final synthetic d([Ljava/lang/Object;JLjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x1

    invoke-static {p0, p1, p2, p3}, Lkotlinx/coroutines/flow/k0;->h([Ljava/lang/Object;JLjava/lang/Object;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public static final e(Lkotlinx/coroutines/flow/i0;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Lkotlinx/coroutines/flow/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i0<",
            "+TT;>;",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            ")",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p2, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, -0x3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-ne p2, v0, :cond_1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    const/4 v2, 0x1

    if-ne p3, v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Lkotlinx/coroutines/flow/internal/i;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0, p0, p1, p2, p3}, Lkotlinx/coroutines/flow/internal/i;-><init>(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method private static final f([Ljava/lang/Object;J)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    long-to-int p1, p1

    const/4 v1, 0x3

    array-length p2, p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    add-int/lit8 p2, p2, -0x1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    and-int/2addr p1, p2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    aget-object p0, p0, p1

    const/4 v1, 0x5

    return-object p0
.end method

.method public static synthetic g()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method private static final h([Ljava/lang/Object;JLjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    long-to-int p1, p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    array-length p2, p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    add-int/lit8 p2, p2, -0x1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    and-int/2addr p1, p2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    aput-object p3, p0, p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method
