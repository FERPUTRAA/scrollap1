.class public final Lkotlinx/coroutines/flow/l$k;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/l;->p([Ljava/lang/Object;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n*L\n1#1,112:1\n125#2,4:113\n*E\n"
.end annotation


# instance fields
.field final synthetic a:[Ljava/lang/Object;


# direct methods
.method public constructor <init>([Ljava/lang/Object;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/flow/l$k;->a:[Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 9
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    instance-of v0, p2, Lkotlinx/coroutines/flow/l$k$a;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v8, 0x2

    const/4 v7, 0x4

    check-cast v0, Lkotlinx/coroutines/flow/l$k$a;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget v1, v0, Lkotlinx/coroutines/flow/l$k$a;->label:I

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/high16 v2, -0x80000000

    const/4 v8, 0x6

    and-int v3, v1, v2

    const/4 v8, 0x6

    if-eqz v3, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    sub-int/2addr v1, v2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    iput v1, v0, Lkotlinx/coroutines/flow/l$k$a;->label:I

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    goto :goto_0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/l$k$a;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/l$k$a;-><init>(Lkotlinx/coroutines/flow/l$k;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object p2, v0, Lkotlinx/coroutines/flow/l$k$a;->result:Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    iget v2, v0, Lkotlinx/coroutines/flow/l$k$a;->label:I

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/4 v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eqz v2, :cond_2

    const/4 v7, 0x3

    move v8, v7

    if-ne v2, v3, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x2

    iget p1, v0, Lkotlinx/coroutines/flow/l$k$a;->I$1:I

    const/4 v8, 0x5

    const/4 v7, 0x0

    iget v2, v0, Lkotlinx/coroutines/flow/l$k$a;->I$0:I

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-object v4, v0, Lkotlinx/coroutines/flow/l$k$a;->L$1:Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    check-cast v4, Lkotlinx/coroutines/flow/j;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget-object v5, v0, Lkotlinx/coroutines/flow/l$k$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    check-cast v5, Lkotlinx/coroutines/flow/l$k;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p2, v4

    move-object p2, v4

    move-object p2, v4

    move-object p2, v4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    goto :goto_2

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string p2, "ifs/ ece/clt seun/ibk/elm/oro air //uetootvehnsw  r"

    const-string p2, "/tsr riektob f /nscc t///i/e/voaei lrn/w uoumeleeoh"

    const/4 v8, 0x3

    const-string p2, "/uwmrtiela/fe/h   o/oc/vieeli bs/e/ ken/cor turtmon"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    throw p1

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object p2, p0, Lkotlinx/coroutines/flow/l$k;->a:[Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x1

    array-length p2, p2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v2, 0x0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    move v6, p2

    move v6, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    move p1, v6

    move p1, v6

    const/4 v8, 0x7

    move p1, v6

    move p1, v6

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-ge v2, p1, :cond_4

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v4, v5, Lkotlinx/coroutines/flow/l$k;->a:[Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    aget-object v4, v4, v2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    iput-object v5, v0, Lkotlinx/coroutines/flow/l$k$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    iput-object p2, v0, Lkotlinx/coroutines/flow/l$k$a;->L$1:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    iput v2, v0, Lkotlinx/coroutines/flow/l$k$a;->I$0:I

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    iput p1, v0, Lkotlinx/coroutines/flow/l$k$a;->I$1:I

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    iput v3, v0, Lkotlinx/coroutines/flow/l$k$a;->label:I

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {p2, v4, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-ne v4, v1, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    return-object v1

    :cond_3
    :goto_2
    const/4 v7, 0x0

    const/4 v8, 0x0

    add-int/2addr v2, v3

    const/4 v7, 0x4

    move v8, v7

    goto :goto_1

    :cond_4
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    return-object p1
.end method
