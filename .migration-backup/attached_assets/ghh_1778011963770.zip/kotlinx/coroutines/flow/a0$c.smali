.class public final Lkotlinx/coroutines/flow/a0$c;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/a0;->c(Lkotlinx/coroutines/flow/i;Li8/p;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt\n*L\n1#1,112:1\n51#2,5:113\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/i;

.field final synthetic b:Li8/p;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/i;Li8/p;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$c;->a:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p2, p0, Lkotlinx/coroutines/flow/a0$c;->b:Li8/p;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "4~s@~s@  @u~o ~@ M/@~~r~f~v~~a@~~K1loly~o@ b~ o~ @@ ~S~   o~@@ ifo@m@-/ i.@i c@t@~@t~@@@ b ~d~n "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/flow/a0$c;->a:Lkotlinx/coroutines/flow/i;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v1, Lkotlinx/coroutines/flow/a0$c$b;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/flow/a0$c;->b:Li8/p;

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v1, p1, v2}, Lkotlinx/coroutines/flow/a0$c$b;-><init>(Lkotlinx/coroutines/flow/j;Li8/p;)V

    const/4 v3, 0x6

    move v4, v3

    invoke-interface {v0, v1, p2}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x6

    if-ne p1, p2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object p1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object p1
.end method

.method public f(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/a0$c$a;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/a0$c$a;-><init>(Lkotlinx/coroutines/flow/a0$c;Lkotlin/coroutines/d;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v0, 0x5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/flow/a0$c;->a:Lkotlinx/coroutines/flow/i;

    const/4 v4, 0x3

    const/4 v3, 0x1

    new-instance v1, Lkotlinx/coroutines/flow/a0$c$b;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/flow/a0$c;->b:Li8/p;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {v1, p1, v2}, Lkotlinx/coroutines/flow/a0$c$b;-><init>(Lkotlinx/coroutines/flow/j;Li8/p;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {v0, v1, p2}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 p1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object p1
.end method
