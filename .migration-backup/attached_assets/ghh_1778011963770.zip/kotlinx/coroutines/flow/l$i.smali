.class public final Lkotlinx/coroutines/flow/l$i;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/l;->i([J)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "Ljava/lang/Long;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,112:1\n178#2:113\n179#2,2:115\n181#2:118\n13564#3:114\n13565#3:117\n*S KotlinDebug\n*F\n+ 1 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n*L\n178#1:114\n178#1:117\n*E\n"
.end annotation


# instance fields
.field final synthetic a:[J


# direct methods
.method public constructor <init>([J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/flow/l$i;->a:[J

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 10
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-",
            "Ljava/lang/Long;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    instance-of v0, p2, Lkotlinx/coroutines/flow/l$i$a;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    check-cast v0, Lkotlinx/coroutines/flow/l$i$a;

    const/4 v8, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget v1, v0, Lkotlinx/coroutines/flow/l$i$a;->label:I

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    const/high16 v2, -0x80000000

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    and-int v3, v1, v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-eqz v3, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    sub-int/2addr v1, v2

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    iput v1, v0, Lkotlinx/coroutines/flow/l$i$a;->label:I

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto :goto_0

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    new-instance v0, Lkotlinx/coroutines/flow/l$i$a;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/l$i$a;-><init>(Lkotlinx/coroutines/flow/l$i;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v8, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget-object p2, v0, Lkotlinx/coroutines/flow/l$i$a;->result:Ljava/lang/Object;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x7

    iget v2, v0, Lkotlinx/coroutines/flow/l$i$a;->label:I

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/4 v3, 0x1

    if-eqz v2, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-ne v2, v3, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    iget p1, v0, Lkotlinx/coroutines/flow/l$i$a;->I$1:I

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget v2, v0, Lkotlinx/coroutines/flow/l$i$a;->I$0:I

    const/4 v9, 0x6

    const/4 v8, 0x0

    iget-object v4, v0, Lkotlinx/coroutines/flow/l$i$a;->L$1:Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    check-cast v4, [J

    const/4 v9, 0x2

    const/4 v8, 0x0

    iget-object v5, v0, Lkotlinx/coroutines/flow/l$i$a;->L$0:Ljava/lang/Object;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    check-cast v5, Lkotlinx/coroutines/flow/j;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p2, v5

    move-object p2, v5

    move-object p2, v5

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    goto/16 :goto_2

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const-string p2, "e/s o//ta/ eobsliitc imouee nt/vr/ ukhlf rrws/e/eon"

    const-string p2, "h s/eee/wril/air/ l o  rocbe//ootnmuk/etoitu /vnsfe"

    const/4 v9, 0x1

    const-string p2, "/eumo lcs or//ttfo aeorlu  e/emon/h/bnvrtc ke/e/iwi"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    throw p1

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object p2, p0, Lkotlinx/coroutines/flow/l$i;->a:[J

    const/4 v8, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    array-length v2, p2

    const/4 v8, 0x7

    move v9, v8

    const/4 v4, 0x0

    shl-int/2addr v9, v4

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    move p1, v2

    move p1, v2

    const/4 v9, 0x4

    move p1, v2

    move p1, v2

    const/4 v9, 0x0

    move v2, v4

    move v2, v4

    const/4 v9, 0x3

    move v2, v4

    move v2, v4

    move-object v4, v7

    move-object v4, v7

    move-object v4, v7

    move-object v4, v7

    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-ge v2, p1, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    aget-wide v5, v4, v2

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {v5, v6}, Lkotlin/coroutines/jvm/internal/b;->g(J)Ljava/lang/Long;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    iput-object p2, v0, Lkotlinx/coroutines/flow/l$i$a;->L$0:Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    iput-object v4, v0, Lkotlinx/coroutines/flow/l$i$a;->L$1:Ljava/lang/Object;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    iput v2, v0, Lkotlinx/coroutines/flow/l$i$a;->I$0:I

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    iput p1, v0, Lkotlinx/coroutines/flow/l$i$a;->I$1:I

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    iput v3, v0, Lkotlinx/coroutines/flow/l$i$a;->label:I

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-interface {p2, v5, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x5

    const/4 v8, 0x3

    if-ne v5, v1, :cond_3

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    return-object v1

    :cond_3
    :goto_2
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    add-int/2addr v2, v3

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_1

    :cond_4
    const/4 v9, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    return-object p1
.end method
