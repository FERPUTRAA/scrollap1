.class public final Lkotlinx/coroutines/flow/o0$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/flow/o0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field static final synthetic a:Lkotlinx/coroutines/flow/o0$a;

.field private static final b:Lkotlinx/coroutines/flow/o0;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final c:Lkotlinx/coroutines/flow/o0;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/o0$a;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0}, Lkotlinx/coroutines/flow/o0$a;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    sput-object v0, Lkotlinx/coroutines/flow/o0$a;->a:Lkotlinx/coroutines/flow/o0$a;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Lkotlinx/coroutines/flow/q0;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0}, Lkotlinx/coroutines/flow/q0;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    sput-object v0, Lkotlinx/coroutines/flow/o0$a;->b:Lkotlinx/coroutines/flow/o0;

    const/4 v2, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/r0;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0}, Lkotlinx/coroutines/flow/r0;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    sput-object v0, Lkotlinx/coroutines/flow/o0$a;->c:Lkotlinx/coroutines/flow/o0;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public static synthetic b(Lkotlinx/coroutines/flow/o0$a;JJILjava/lang/Object;)Lkotlinx/coroutines/flow/o0;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " fs~o - @@oS@ @/~l@@.d@m ~~vc/i@~@i@o @b~~ @i@K@ ~~  b~a  4~~~ 1brt@ s~ y~ ~@f@to@no~ ~M~u@~~~l@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    and-int/lit8 p6, p5, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    if-eqz p6, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    and-int/lit8 p5, p5, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x7

    if-eqz p5, :cond_1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    const-wide p3, 0x7fffffffffffffffL

    const-wide p3, 0x7fffffffffffffffL

    const/4 v1, 0x0

    const-wide p3, 0x7fffffffffffffffL

    const-wide p3, 0x7fffffffffffffffL

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/flow/o0$a;->a(JJ)Lkotlinx/coroutines/flow/o0;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method


# virtual methods
.method public final a(JJ)Lkotlinx/coroutines/flow/o0;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance v0, Lkotlinx/coroutines/flow/s0;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0, p1, p2, p3, p4}, Lkotlinx/coroutines/flow/s0;-><init>(JJ)V

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public final c()Lkotlinx/coroutines/flow/o0;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lkotlinx/coroutines/flow/o0$a;->b:Lkotlinx/coroutines/flow/o0;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public final d()Lkotlinx/coroutines/flow/o0;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Lkotlinx/coroutines/flow/o0$a;->c:Lkotlinx/coroutines/flow/o0;

    const/4 v2, 0x6

    return-object v0
.end method
