.class public final Lkotlinx/coroutines/flow/t$b;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/t;->d(Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt\n+ 3 CoroutineScope.kt\nkotlinx/coroutines/CoroutineScopeKt\n*L\n1#1,112:1\n147#2,13:113\n160#2,6:127\n329#3:126\n*S KotlinDebug\n*F\n+ 1 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt\n*L\n159#1:126\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/flow/i;

.field final synthetic b:Li8/q;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/flow/i;Li8/q;)V
    .locals 2

    const/4 v0, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/flow/t$b;->a:Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p2, p0, Lkotlinx/coroutines/flow/t$b;->b:Li8/q;

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 10
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    instance-of v0, p2, Lkotlinx/coroutines/flow/t$b$a;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    check-cast v0, Lkotlinx/coroutines/flow/t$b$a;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget v1, v0, Lkotlinx/coroutines/flow/t$b$a;->label:I

    const/4 v9, 0x6

    const/high16 v2, -0x80000000

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    and-int v3, v1, v2

    const/4 v8, 0x0

    move v9, v8

    if-eqz v3, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    sub-int/2addr v1, v2

    const/4 v8, 0x6

    move v9, v8

    iput v1, v0, Lkotlinx/coroutines/flow/t$b$a;->label:I

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto :goto_0

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    new-instance v0, Lkotlinx/coroutines/flow/t$b$a;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/t$b$a;-><init>(Lkotlinx/coroutines/flow/t$b;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v9, 0x1

    iget-object p2, v0, Lkotlinx/coroutines/flow/t$b$a;->result:Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget v2, v0, Lkotlinx/coroutines/flow/t$b$a;->label:I

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v3, 0x3

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v4, 0x2

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    const/4 v5, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v6, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-eqz v2, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eq v2, v5, :cond_3

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-eq v2, v4, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-ne v2, v3, :cond_1

    const/4 v8, 0x1

    move v9, v8

    iget-object p1, v0, Lkotlinx/coroutines/flow/t$b$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x7

    move v9, v8

    check-cast p1, Lkotlinx/coroutines/flow/internal/v;

    :try_start_0
    const/4 v8, 0x7

    move v9, v8

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    goto/16 :goto_2

    :catchall_0
    move-exception p2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    goto/16 :goto_3

    :cond_1
    const/4 v8, 0x7

    const/4 v9, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string p2, "orsmoiaw/ruvtsu/ b/ck t il/nftn ehelsoeecoe/ ri //e"

    const-string p2, "rcsee/hkow/ r/et iuaoion be/o t//sc/v mlleutrne/if "

    const-string p2, "resm/// k  ueaio  lnlvboewieerirc/tou/fo /coht/netm"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    throw p1

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    iget-object p1, v0, Lkotlinx/coroutines/flow/t$b$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x5

    shr-int/2addr v9, v8

    check-cast p1, Ljava/lang/Throwable;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    goto/16 :goto_5

    :cond_3
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object p1, v0, Lkotlinx/coroutines/flow/t$b$a;->L$1:Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    check-cast p1, Lkotlinx/coroutines/flow/j;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object v2, v0, Lkotlinx/coroutines/flow/t$b$a;->L$0:Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    check-cast v2, Lkotlinx/coroutines/flow/t$b;

    :try_start_1
    const/4 v9, 0x6

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    goto :goto_1

    :catchall_1
    move-exception p1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    goto/16 :goto_4

    :cond_4
    const/4 v8, 0x2

    move v9, v8

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    :try_start_2
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-object p2, p0, Lkotlinx/coroutines/flow/t$b;->a:Lkotlinx/coroutines/flow/i;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    iput-object p0, v0, Lkotlinx/coroutines/flow/t$b$a;->L$0:Ljava/lang/Object;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    iput-object p1, v0, Lkotlinx/coroutines/flow/t$b$a;->L$1:Ljava/lang/Object;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    iput v5, v0, Lkotlinx/coroutines/flow/t$b$a;->label:I

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-interface {p2, p1, v0}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-ne p2, v1, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    return-object v1

    :cond_5
    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    new-instance p2, Lkotlinx/coroutines/flow/internal/v;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-interface {v0}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x5

    invoke-direct {p2, p1, v4}, Lkotlinx/coroutines/flow/internal/v;-><init>(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/g;)V

    :try_start_3
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object p1, v2, Lkotlinx/coroutines/flow/t$b;->b:Li8/q;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    iput-object p2, v0, Lkotlinx/coroutines/flow/t$b$a;->L$0:Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    iput-object v6, v0, Lkotlinx/coroutines/flow/t$b$a;->L$1:Ljava/lang/Object;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    iput v3, v0, Lkotlinx/coroutines/flow/t$b$a;->label:I

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/4 v2, 0x6

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {v2}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-interface {p1, p2, v6, v0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    const/4 v0, 0x7

    const/4 v9, 0x6

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-ne p1, v1, :cond_6

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    return-object v1

    :cond_6
    move-object p1, p2

    move-object p1, p2

    :goto_2
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p1}, Lkotlinx/coroutines/flow/internal/v;->releaseIntercepted()V

    const/4 v8, 0x6

    or-int/2addr v9, v8

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    return-object p1

    :catchall_2
    move-exception p1

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    :goto_3
    const/4 v9, 0x4

    const/4 v8, 0x7

    invoke-virtual {p1}, Lkotlinx/coroutines/flow/internal/v;->releaseIntercepted()V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    throw p2

    :catchall_3
    move-exception p1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    :goto_4
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    new-instance p2, Lkotlinx/coroutines/flow/z0;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-direct {p2, p1}, Lkotlinx/coroutines/flow/z0;-><init>(Ljava/lang/Throwable;)V

    const/4 v9, 0x1

    const/4 v8, 0x3

    iget-object v2, v2, Lkotlinx/coroutines/flow/t$b;->b:Li8/q;

    const/4 v9, 0x2

    iput-object p1, v0, Lkotlinx/coroutines/flow/t$b$a;->L$0:Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    iput-object v6, v0, Lkotlinx/coroutines/flow/t$b$a;->L$1:Ljava/lang/Object;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    iput v4, v0, Lkotlinx/coroutines/flow/t$b$a;->label:I

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {p2, v2, p1, v0}, Lkotlinx/coroutines/flow/t;->a(Lkotlinx/coroutines/flow/j;Li8/q;Ljava/lang/Throwable;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-ne p2, v1, :cond_7

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    return-object v1

    :cond_7
    :goto_5
    const/4 v9, 0x7

    const/4 v8, 0x1

    throw p1
.end method
