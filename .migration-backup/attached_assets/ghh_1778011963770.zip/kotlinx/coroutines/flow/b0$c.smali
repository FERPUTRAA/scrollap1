.class public final Lkotlinx/coroutines/flow/b0$c;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/b0;->f(Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Lkotlinx/coroutines/flow/i;Li8/t;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/i<",
        "TR;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSafeCollector.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt$unsafeFlow$1\n+ 2 Zip.kt\nkotlinx/coroutines/flow/FlowKt__ZipKt\n*L\n1#1,112:1\n262#2,2:113\n*E\n"
.end annotation


# instance fields
.field final synthetic a:[Lkotlinx/coroutines/flow/i;

.field final synthetic b:Li8/t;


# direct methods
.method public constructor <init>([Lkotlinx/coroutines/flow/i;Li8/t;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/flow/b0$c;->a:[Lkotlinx/coroutines/flow/i;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lkotlinx/coroutines/flow/b0$c;->b:Li8/t;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p1    # Lkotlinx/coroutines/flow/j;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "oss1/@~~ b~@ @r o ~@@/ ulf@~lM ~@@ @~ @~ ~a4ob~df~.   ~@ o@ o@m~oy~v@ c~~~t~~~ib @~S@nt~Ki@@@@i-"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/flow/b0$c;->a:[Lkotlinx/coroutines/flow/i;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {}, Lkotlinx/coroutines/flow/b0;->a()Li8/a;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v2, Lkotlinx/coroutines/flow/b0$c$a;

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x2

    iget-object v4, p0, Lkotlinx/coroutines/flow/b0$c;->b:Li8/t;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {v2, v3, v4}, Lkotlinx/coroutines/flow/b0$c$a;-><init>(Lkotlin/coroutines/d;Li8/t;)V

    const/4 v6, 0x3

    invoke-static {p1, v0, v1, v2, p2}, Lkotlinx/coroutines/flow/internal/m;->a(Lkotlinx/coroutines/flow/j;[Lkotlinx/coroutines/flow/i;Li8/a;Li8/q;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-ne p1, p2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-object p1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    return-object p1
.end method
