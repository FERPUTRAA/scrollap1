.class final Lkotlinx/coroutines/flow/a0$i;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/a0;->h(Lkotlinx/coroutines/flow/i;Ljava/lang/Object;Li8/q;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlin/jvm/internal/k1$h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/k1$h<",
            "TR;>;"
        }
    .end annotation
.end field

.field final synthetic b:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "TR;TT;",
            "Lkotlin/coroutines/d<",
            "-TR;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic c:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TR;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/k1$h;Li8/q;Lkotlinx/coroutines/flow/j;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/k1$h<",
            "TR;>;",
            "Li8/q<",
            "-TR;-TT;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;)V"
        }
    .end annotation

    const/4 v0, 0x6

    move v1, v0

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$i;->a:Lkotlin/jvm/internal/k1$h;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p2, p0, Lkotlinx/coroutines/flow/a0$i;->b:Li8/q;

    const/4 v0, 0x3

    const/4 v0, 0x0

    iput-object p3, p0, Lkotlinx/coroutines/flow/a0$i;->c:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 9
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    instance-of v0, p2, Lkotlinx/coroutines/flow/a0$i$a;

    const/4 v8, 0x0

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    check-cast v0, Lkotlinx/coroutines/flow/a0$i$a;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget v1, v0, Lkotlinx/coroutines/flow/a0$i$a;->label:I

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/high16 v2, -0x80000000

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    and-int v3, v1, v2

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-eqz v3, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    sub-int/2addr v1, v2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    iput v1, v0, Lkotlinx/coroutines/flow/a0$i$a;->label:I

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/a0$i$a;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/a0$i$a;-><init>(Lkotlinx/coroutines/flow/a0$i;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v8, 0x4

    iget-object p2, v0, Lkotlinx/coroutines/flow/a0$i$a;->result:Ljava/lang/Object;

    const/4 v7, 0x6

    move v8, v7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget v2, v0, Lkotlinx/coroutines/flow/a0$i$a;->label:I

    const/4 v8, 0x1

    const/4 v3, 0x2

    const/4 v8, 0x6

    shl-int/2addr v7, v3

    const/4 v8, 0x1

    const/4 v4, 0x6

    const/4 v4, 0x1

    or-int/2addr v8, v4

    const/4 v7, 0x3

    and-int/2addr v8, v7

    if-eqz v2, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eq v2, v4, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    if-ne v2, v3, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    goto/16 :goto_2

    :cond_1
    const/4 v7, 0x3

    move v8, v7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string p2, " usoksbtr/ iurmce a//eevoewcst / lfrhel/not/ oo/n/i"

    const-string p2, "ossn///l /mfa/ ho noecerkuiotoc vt//eibe uetrl/ew r"

    const/4 v8, 0x4

    const-string p2, "n/cm/o/iust/uteko/ eb   wre aer/lhofeconi/etr/ml oi"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    throw p1

    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object p1, v0, Lkotlinx/coroutines/flow/a0$i$a;->L$1:Ljava/lang/Object;

    const/4 v8, 0x2

    check-cast p1, Lkotlin/jvm/internal/k1$h;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v2, v0, Lkotlinx/coroutines/flow/a0$i$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    check-cast v2, Lkotlinx/coroutines/flow/a0$i;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    goto :goto_1

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x7

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget-object p2, p0, Lkotlinx/coroutines/flow/a0$i;->a:Lkotlin/jvm/internal/k1$h;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-object v2, p0, Lkotlinx/coroutines/flow/a0$i;->b:Li8/q;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget-object v5, p2, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x4

    iput-object p0, v0, Lkotlinx/coroutines/flow/a0$i$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    iput-object p2, v0, Lkotlinx/coroutines/flow/a0$i$a;->L$1:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    iput v4, v0, Lkotlinx/coroutines/flow/a0$i$a;->label:I

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-interface {v2, v5, p1, v0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-ne p1, v1, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    return-object v1

    :cond_4
    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    iput-object p2, p1, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    iget-object p1, v2, Lkotlinx/coroutines/flow/a0$i;->c:Lkotlinx/coroutines/flow/j;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    iget-object p2, v2, Lkotlinx/coroutines/flow/a0$i;->a:Lkotlin/jvm/internal/k1$h;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object p2, p2, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v2, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    iput-object v2, v0, Lkotlinx/coroutines/flow/a0$i$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x0

    iput-object v2, v0, Lkotlinx/coroutines/flow/a0$i$a;->L$1:Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    iput v3, v0, Lkotlinx/coroutines/flow/a0$i$a;->label:I

    const/4 v7, 0x0

    move v8, v7

    invoke-interface {p1, p2, v0}, Lkotlinx/coroutines/flow/j;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-ne p1, v1, :cond_5

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    return-object v1

    :cond_5
    :goto_2
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    return-object p1
.end method
