.class final synthetic Lkotlinx/coroutines/flow/l;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nBuilders.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n+ 2 SafeCollector.common.kt\nkotlinx/coroutines/flow/internal/SafeCollector_commonKt\n*L\n1#1,356:1\n106#2:357\n106#2:358\n106#2:359\n106#2:360\n106#2:361\n106#2:362\n106#2:363\n106#2:364\n106#2:365\n106#2:366\n106#2:367\n106#2:368\n*S KotlinDebug\n*F\n+ 1 Builders.kt\nkotlinx/coroutines/flow/FlowKt__BuildersKt\n*L\n69#1:357\n84#1:358\n91#1:359\n100#1:360\n109#1:361\n124#1:362\n133#1:363\n155#1:364\n166#1:365\n177#1:366\n186#1:367\n195#1:368\n*E\n"
.end annotation


# direct methods
.method public static final a(Li8/a;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Li8/a;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Li8/a<",
            "+TT;>;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlinx/coroutines/d2;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Lkotlinx/coroutines/flow/l$b;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$b;-><init>(Li8/a;)V

    return-object v0
.end method

.method public static final b(Li8/l;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Li8/l<",
            "-",
            "Lkotlin/coroutines/d<",
            "-TT;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlinx/coroutines/d2;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/l$c;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$c;-><init>(Li8/l;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public static final c(Ljava/lang/Iterable;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Ljava/lang/Iterable;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Iterable<",
            "+TT;>;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance v0, Lkotlinx/coroutines/flow/l$d;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$d;-><init>(Ljava/lang/Iterable;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public static final d(Ljava/util/Iterator;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Ljava/util/Iterator;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Iterator<",
            "+TT;>;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/l$e;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$e;-><init>(Ljava/util/Iterator;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public static final e(Lkotlin/ranges/l;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Lkotlin/ranges/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/ranges/l;",
            ")",
            "Lkotlinx/coroutines/flow/i<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/l$j;

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$j;-><init>(Lkotlin/ranges/l;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public static final f(Lkotlin/ranges/o;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Lkotlin/ranges/o;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/ranges/o;",
            ")",
            "Lkotlinx/coroutines/flow/i<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lkotlinx/coroutines/flow/l$a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$a;-><init>(Lkotlin/ranges/o;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public static final g(Lkotlin/sequences/m;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Lkotlin/sequences/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlin/sequences/m<",
            "+TT;>;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance v0, Lkotlinx/coroutines/flow/l$f;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$f;-><init>(Lkotlin/sequences/m;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public static final h([I)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # [I
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([I)",
            "Lkotlinx/coroutines/flow/i<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Lkotlinx/coroutines/flow/l$h;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$h;-><init>([I)V

    return-object v0
.end method

.method public static final i([J)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # [J
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([J)",
            "Lkotlinx/coroutines/flow/i<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance v0, Lkotlinx/coroutines/flow/l$i;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$i;-><init>([J)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public static final j([Ljava/lang/Object;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # [Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance v0, Lkotlinx/coroutines/flow/l$g;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$g;-><init>([Ljava/lang/Object;)V

    const/4 v2, 0x7

    return-object v0
.end method

.method public static final k(Li8/p;)Lkotlinx/coroutines/flow/i;
    .locals 10
    .param p0    # Li8/p;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-instance v7, Lkotlinx/coroutines/flow/b;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/4 v2, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/4 v4, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    const/16 v5, 0xe

    const/4 v9, 0x7

    const/4 v6, 0x7

    const/4 v9, 0x1

    const/4 v6, 0x0

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-direct/range {v0 .. v6}, Lkotlinx/coroutines/flow/b;-><init>(Li8/p;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    return-object v7
.end method

.method public static final l(Li8/p;)Lkotlinx/coroutines/flow/i;
    .locals 10
    .param p0    # Li8/p;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/channels/g0<",
            "-TT;>;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    new-instance v7, Lkotlinx/coroutines/flow/f;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    const/4 v2, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    const/4 v4, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/16 v5, 0xe

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    const/4 v6, 0x0

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-direct/range {v0 .. v6}, Lkotlinx/coroutines/flow/f;-><init>(Li8/p;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;ILkotlin/jvm/internal/w;)V

    const/4 v8, 0x2

    move v9, v8

    return-object v7
.end method

.method public static final m()Lkotlinx/coroutines/flow/i;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">()",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lkotlinx/coroutines/flow/h;->a:Lkotlinx/coroutines/flow/h;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public static final n(Li8/p;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # Li8/p;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TT;>;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/h0;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/h0;-><init>(Li8/p;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-object v0
.end method

.method public static final o(Ljava/lang/Object;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Lkotlinx/coroutines/flow/l$l;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$l;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public static final varargs p([Ljava/lang/Object;)Lkotlinx/coroutines/flow/i;
    .locals 3
    .param p0    # [Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)",
            "Lkotlinx/coroutines/flow/i<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance v0, Lkotlinx/coroutines/flow/l$k;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lkotlinx/coroutines/flow/l$k;-><init>([Ljava/lang/Object;)V

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    return-object v0
.end method
