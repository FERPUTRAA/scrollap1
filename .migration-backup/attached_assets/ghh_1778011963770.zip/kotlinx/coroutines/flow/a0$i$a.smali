.class final Lkotlinx/coroutines/flow/a0$i$a;
.super Lkotlin/coroutines/jvm/internal/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/a0$i;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.flow.FlowKt__TransformKt$runningFold$1$1"
    f = "Transform.kt"
    i = {
        0x0
    }
    l = {
        0x67,
        0x68
    }
    m = "emit"
    n = {
        "this"
    }
    s = {
        "L$0"
    }
.end annotation


# instance fields
.field L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field label:I

.field synthetic result:Ljava/lang/Object;

.field final synthetic this$0:Lkotlinx/coroutines/flow/a0$i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/a0$i<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/flow/a0$i;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/a0$i<",
            "-TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/flow/a0$i$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$i$a;->this$0:Lkotlinx/coroutines/flow/a0$i;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/d;-><init>(Lkotlin/coroutines/d;)V

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/flow/a0$i$a;->result:Ljava/lang/Object;

    const/4 v2, 0x1

    iget p1, p0, Lkotlinx/coroutines/flow/a0$i$a;->label:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/high16 v0, -0x80000000

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    or-int/2addr p1, v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput p1, p0, Lkotlinx/coroutines/flow/a0$i$a;->label:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/flow/a0$i$a;->this$0:Lkotlinx/coroutines/flow/a0$i;

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, v0, p0}, Lkotlinx/coroutines/flow/a0$i;->emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    return-object p1
.end method
