.class public final Lkotlinx/coroutines/flow/t$h;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/t;->h(Lkotlinx/coroutines/flow/i;Li8/q;)Lkotlinx/coroutines/flow/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEmitters.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Emitters.kt\nkotlinx/coroutines/flow/FlowKt__EmittersKt$unsafeTransform$1$1\n*L\n1#1,222:1\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic b:Lkotlinx/coroutines/flow/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/flow/j<",
            "TR;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Li8/q;Lkotlinx/coroutines/flow/j;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/q<",
            "-",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;-TT;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlinx/coroutines/flow/j<",
            "-TR;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/flow/t$h;->a:Li8/q;

    const/4 v1, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/flow/t$h;->b:Lkotlinx/coroutines/flow/j;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Lkotlinx/coroutines/flow/t$h$a;

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/t$h$a;-><init>(Lkotlinx/coroutines/flow/t$h;Lkotlin/coroutines/d;)V

    const/4 v2, 0x0

    move v3, v2

    const/4 v0, 0x5

    move v3, v0

    const/4 v2, 0x0

    move v3, v2

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/flow/t$h;->a:Li8/q;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/flow/t$h;->b:Lkotlinx/coroutines/flow/j;

    const/4 v3, 0x2

    invoke-interface {v0, v1, p1, p2}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object p1
.end method

.method public final emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    instance-of v0, p2, Lkotlinx/coroutines/flow/t$h$a;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v5, 0x5

    const/4 v4, 0x7

    check-cast v0, Lkotlinx/coroutines/flow/t$h$a;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget v1, v0, Lkotlinx/coroutines/flow/t$h$a;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/high16 v2, -0x80000000

    const/4 v4, 0x6

    move v5, v4

    and-int v3, v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v5, 0x5

    sub-int/2addr v1, v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput v1, v0, Lkotlinx/coroutines/flow/t$h$a;->label:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v0, Lkotlinx/coroutines/flow/t$h$a;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/t$h$a;-><init>(Lkotlinx/coroutines/flow/t$h;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x3

    iget-object p2, v0, Lkotlinx/coroutines/flow/t$h$a;->result:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget v2, v0, Lkotlinx/coroutines/flow/t$h$a;->label:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-ne v2, v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string p2, "o/s/ct //keun/ebwsotivmoei/  laeh/eifro/ rc  tenslu"

    const-string/jumbo p2, "tisaoto toe/k huru l//fl/o/e eer/cwensi m//rbenc iv"

    const/4 v5, 0x2

    const-string p2, "ioeme w/taenkc ou/eb/  s /lrmehltnrf/ru/i/oov/eio c"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    throw p1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v4, 0x5

    move v5, v4

    iget-object p2, p0, Lkotlinx/coroutines/flow/t$h;->a:Li8/q;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v2, p0, Lkotlinx/coroutines/flow/t$h;->b:Lkotlinx/coroutines/flow/j;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    iput v3, v0, Lkotlinx/coroutines/flow/t$h$a;->label:I

    const/4 v5, 0x3

    invoke-interface {p2, v2, p1, v0}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-ne p1, v1, :cond_3

    const/4 v4, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-object v1

    :cond_3
    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-object p1
.end method
