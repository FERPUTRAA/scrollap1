.class public final Lkotlinx/coroutines/flow/n$b;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/flow/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/flow/n;->d(Lkotlinx/coroutines/flow/i;Li8/q;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/flow/j<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCollect.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Collect.kt\nkotlinx/coroutines/flow/FlowKt__CollectKt$collectIndexed$2\n+ 2 FlowExceptions.common.kt\nkotlinx/coroutines/flow/internal/FlowExceptions_commonKt\n*L\n1#1,118:1\n32#2,4:119\n*S KotlinDebug\n*F\n+ 1 Collect.kt\nkotlinx/coroutines/flow/FlowKt__CollectKt$collectIndexed$2\n*L\n62#1:119,4\n*E\n"
.end annotation


# instance fields
.field private a:I

.field final synthetic b:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "Ljava/lang/Integer;",
            "TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Li8/q;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/q<",
            "-",
            "Ljava/lang/Integer;",
            "-TT;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/flow/n$b;->b:Li8/q;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v0, 0x4

    const/4 v4, 0x7

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x7

    new-instance v0, Lkotlinx/coroutines/flow/n$b$a;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/flow/n$b$a;-><init>(Lkotlinx/coroutines/flow/n$b;Lkotlin/coroutines/d;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/flow/n$b;->b:Li8/q;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v1, p0, Lkotlinx/coroutines/flow/n$b;->a:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput v2, p0, Lkotlinx/coroutines/flow/n$b;->a:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    if-ltz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v0, v1, p1, p2}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object p1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/ArithmeticException;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const-string p2, "a s deesrxfhwaeheo loInvsnd"

    const-string p2, "pdsoaIsdwhhne  rofxeael nve"

    const/4 v4, 0x7

    const-string/jumbo p2, "wrnm lh edpneaIapedfesohvo "

    const-string p2, "Index overflow has happened"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {p1, p2}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    throw p1
.end method

.method public emit(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/flow/n$b;->b:Li8/q;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v1, p0, Lkotlinx/coroutines/flow/n$b;->a:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput v2, p0, Lkotlinx/coroutines/flow/n$b;->a:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-ltz v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-static {v1}, Lkotlin/coroutines/jvm/internal/b;->f(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {v0, v1, p1, p2}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-ne p1, p2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-object p1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object p1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/ArithmeticException;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string p2, " h oo xelspIdpdeenwmnarheva"

    const-string p2, "ee mvhenhdIodwlnaxs aope pr"

    const/4 v4, 0x0

    const-string/jumbo p2, "weppebIdehr sadxoa f nhlovn"

    const-string p2, "Index overflow has happened"

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p1, p2}, Ljava/lang/ArithmeticException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    throw p1
.end method
