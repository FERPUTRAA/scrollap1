.class final synthetic Lkotlinx/coroutines/flow/q;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lkotlinx/coroutines/flow/i;Li8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Li8/p<",
            "-TT;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Integer;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " @s@~d@~Sl~ .  @t~noM@@t ~@~@o~rK@/~a i@ ~~~@m-l~@@ ~ ~@/ c@~~v~1 byo obs~bf~ 4 o~ui ~@~@@@fio  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    instance-of v0, p2, Lkotlinx/coroutines/flow/q$c;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    check-cast v0, Lkotlinx/coroutines/flow/q$c;

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget v1, v0, Lkotlinx/coroutines/flow/q$c;->label:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/high16 v2, -0x80000000

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    and-int v3, v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    sub-int/2addr v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    iput v1, v0, Lkotlinx/coroutines/flow/q$c;->label:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v0, Lkotlinx/coroutines/flow/q$c;

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v0, p2}, Lkotlinx/coroutines/flow/q$c;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object p2, v0, Lkotlinx/coroutines/flow/q$c;->result:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v2, v0, Lkotlinx/coroutines/flow/q$c;->label:I

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    if-ne v2, v3, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object p0, v0, Lkotlinx/coroutines/flow/q$c;->L$0:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    check-cast p0, Lkotlin/jvm/internal/k1$f;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "otom/erein eru/mltl fvc/ ahne/ i w ko//ceeburoos/it"

    const-string p1, "o/set t/bcmklen//nc /rrtilo eh/reviu/oeofau e/iwo  "

    const/4 v5, 0x7

    const-string p1, "/rlroetor/ /c/teeiumlvi ehba wiun te n/okof/o /e/co"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    throw p0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    new-instance p2, Lkotlin/jvm/internal/k1$f;

    const/4 v5, 0x5

    invoke-direct {p2}, Lkotlin/jvm/internal/k1$f;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance v2, Lkotlinx/coroutines/flow/q$d;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v2, p1, p2}, Lkotlinx/coroutines/flow/q$d;-><init>(Li8/p;Lkotlin/jvm/internal/k1$f;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput-object p2, v0, Lkotlinx/coroutines/flow/q$c;->L$0:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput v3, v0, Lkotlinx/coroutines/flow/q$c;->label:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-interface {p0, v2, v0}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-ne p0, v1, :cond_3

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-object v1

    :cond_3
    move-object p0, p2

    move-object p0, p2

    move-object p0, p2

    move-object p0, p2

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    iget p0, p0, Lkotlin/jvm/internal/k1$f;->element:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p0}, Lkotlin/coroutines/jvm/internal/b;->f(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x2

    return-object p0
.end method

.method public static final b(Lkotlinx/coroutines/flow/i;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p0    # Lkotlinx/coroutines/flow/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/flow/i<",
            "+TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Integer;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    instance-of v0, p1, Lkotlinx/coroutines/flow/q$a;

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    check-cast v0, Lkotlinx/coroutines/flow/q$a;

    const/4 v5, 0x6

    const/4 v4, 0x0

    iget v1, v0, Lkotlinx/coroutines/flow/q$a;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/high16 v2, -0x80000000

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    and-int v3, v1, v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    sub-int/2addr v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    iput v1, v0, Lkotlinx/coroutines/flow/q$a;->label:I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v0, Lkotlinx/coroutines/flow/q$a;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v0, p1}, Lkotlinx/coroutines/flow/q$a;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object p1, v0, Lkotlinx/coroutines/flow/q$a;->result:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget v2, v0, Lkotlinx/coroutines/flow/q$a;->label:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-ne v2, v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object p0, v0, Lkotlinx/coroutines/flow/q$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    check-cast p0, Lkotlin/jvm/internal/k1$f;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    goto :goto_1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string p1, " elhwbsee//tonv//r  ofm boi otume /a/ccruenilk/tior"

    const-string/jumbo p1, "u/rmnt eiomwo/o/ ent/lcir/btseeh ire cf a/o/veolu k"

    const/4 v5, 0x6

    const-string p1, "o/l/ buu /ecosl irtntef/rkeu/ ew /ea vchor/onoie/mi"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    throw p0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance p1, Lkotlin/jvm/internal/k1$f;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p1}, Lkotlin/jvm/internal/k1$f;-><init>()V

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance v2, Lkotlinx/coroutines/flow/q$b;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {v2, p1}, Lkotlinx/coroutines/flow/q$b;-><init>(Lkotlin/jvm/internal/k1$f;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-object p1, v0, Lkotlinx/coroutines/flow/q$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput v3, v0, Lkotlinx/coroutines/flow/q$a;->label:I

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {p0, v2, v0}, Lkotlinx/coroutines/flow/i;->a(Lkotlinx/coroutines/flow/j;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-ne p0, v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object v1

    :cond_3
    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget p0, p0, Lkotlin/jvm/internal/k1$f;->element:I

    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p0}, Lkotlin/coroutines/jvm/internal/b;->f(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x4

    return-object p0
.end method
