.class public final Lkotlinx/coroutines/flow/l0;
.super Lkotlinx/coroutines/flow/internal/d;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlinx/coroutines/flow/internal/d<",
        "Lkotlinx/coroutines/flow/j0<",
        "*>;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSharedFlow.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SharedFlow.kt\nkotlinx/coroutines/flow/SharedFlowSlot\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,733:1\n1#2:734\n*E\n"
.end annotation


# instance fields
.field public a:J
    .annotation build Lh8/e;
    .end annotation
.end field

.field public b:Lkotlin/coroutines/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/flow/internal/d;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-wide v0, p0, Lkotlinx/coroutines/flow/l0;->a:J

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public bridge synthetic a(Ljava/lang/Object;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "/ s o @@mr~1f@ @@~f@~~ @ab@sMio~4v y @u~d ~~~@@~i~~@ oS@~ c @b~tn l~o~~~o @o ~i~l~t -Kb@/@.@ @~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p1, Lkotlinx/coroutines/flow/j0;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/flow/l0;->c(Lkotlinx/coroutines/flow/j0;)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    return p1
.end method

.method public bridge synthetic b(Ljava/lang/Object;)[Lkotlin/coroutines/d;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    check-cast p1, Lkotlinx/coroutines/flow/j0;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/flow/l0;->d(Lkotlinx/coroutines/flow/j0;)[Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public c(Lkotlinx/coroutines/flow/j0;)Z
    .locals 6
    .param p1    # Lkotlinx/coroutines/flow/j0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j0<",
            "*>;)Z"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-wide v0, p0, Lkotlinx/coroutines/flow/l0;->a:J

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    cmp-long v0, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-ltz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 p1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    return p1

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1}, Lkotlinx/coroutines/flow/j0;->d0()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput-wide v0, p0, Lkotlinx/coroutines/flow/l0;->a:J

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 p1, 0x1

    move v5, p1

    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    return p1
.end method

.method public d(Lkotlinx/coroutines/flow/j0;)[Lkotlin/coroutines/d;
    .locals 6
    .param p1    # Lkotlinx/coroutines/flow/j0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/flow/j0<",
            "*>;)[",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-wide v0, p0, Lkotlinx/coroutines/flow/l0;->a:J

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput-wide v2, p0, Lkotlinx/coroutines/flow/l0;->a:J

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput-object v2, p0, Lkotlinx/coroutines/flow/l0;->b:Lkotlin/coroutines/d;

    const/4 v5, 0x4

    invoke-virtual {p1, v0, v1}, Lkotlinx/coroutines/flow/j0;->c0(J)[Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-object p1
.end method
