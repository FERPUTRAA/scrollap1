.class public interface abstract Lkotlinx/coroutines/c0;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/n2;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/c0$a;
    }
.end annotation


# virtual methods
.method public abstract a()Z
.end method

.method public abstract b(Ljava/lang/Throwable;)Z
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param
.end method
