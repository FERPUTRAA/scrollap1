.class public final Lkotlinx/coroutines/e4;
.super Lkotlin/coroutines/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/e4$a;
    }
.end annotation

.annotation build Lkotlin/a1;
.end annotation


# static fields
.field public static final b:Lkotlinx/coroutines/e4$a;
    .annotation build Lia/d;
    .end annotation
.end field


# instance fields
.field public a:Z
    .annotation build Lh8/e;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Lkotlinx/coroutines/e4$a;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Lkotlinx/coroutines/e4$a;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    sput-object v0, Lkotlinx/coroutines/e4;->b:Lkotlinx/coroutines/e4$a;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lkotlinx/coroutines/e4;->b:Lkotlinx/coroutines/e4$a;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lkotlin/coroutines/a;-><init>(Lkotlin/coroutines/g$c;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method
