.class public final Lkotlinx/coroutines/f4;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p0    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {p0}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {v0}, Lkotlinx/coroutines/r2;->z(Lkotlin/coroutines/g;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p0}, Lkotlin/coroutines/intrinsics/b;->e(Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    instance-of v2, v1, Lkotlinx/coroutines/internal/l;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    check-cast v1, Lkotlinx/coroutines/internal/l;

    const/4 v5, 0x4

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    move v5, v4

    const/4 v1, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-nez v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    sget-object v0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_2

    :cond_1
    const/4 v4, 0x3

    move v5, v4

    iget-object v2, v1, Lkotlinx/coroutines/internal/l;->d:Lkotlinx/coroutines/o0;

    invoke-virtual {v2, v0}, Lkotlinx/coroutines/o0;->p0(Lkotlin/coroutines/g;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget-object v2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1, v0, v2}, Lkotlinx/coroutines/internal/l;->l(Lkotlin/coroutines/g;Ljava/lang/Object;)V

    const/4 v5, 0x2

    goto :goto_1

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance v2, Lkotlinx/coroutines/e4;

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-direct {v2}, Lkotlinx/coroutines/e4;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {v0, v2}, Lkotlin/coroutines/g;->plus(Lkotlin/coroutines/g;)Lkotlin/coroutines/g;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object v3, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x3

    invoke-virtual {v1, v0, v3}, Lkotlinx/coroutines/internal/l;->l(Lkotlin/coroutines/g;Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-boolean v0, v2, Lkotlinx/coroutines/e4;->a:Z

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v0, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v1}, Lkotlinx/coroutines/internal/m;->h(Lkotlinx/coroutines/internal/l;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v0, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    goto :goto_2

    :cond_3
    move-object v0, v3

    move-object v0, v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_2

    :cond_4
    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    :goto_2
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ne v0, v1, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p0}, Lkotlin/coroutines/jvm/internal/h;->c(Lkotlin/coroutines/d;)V

    :cond_5
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-ne v0, p0, :cond_6

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-object v0

    :cond_6
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-object p0
.end method
