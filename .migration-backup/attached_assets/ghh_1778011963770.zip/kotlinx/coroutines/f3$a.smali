.class public final Lkotlinx/coroutines/f3$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/f3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static synthetic a(Lkotlinx/coroutines/f3;)V
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Since 1.2.0, binary compatibility with versions <= 1.1.x"
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@Sss~@ct@4@o ro~@ / ~@~odl@ M ib 1~  ~~@~~i@@@Kf b@~ o @n@a~@~~~@@o./m~ f@~~@o  vy~ @~ ~biu~~t- "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-static {p0}, Lkotlinx/coroutines/n2$a;->a(Lkotlinx/coroutines/n2;)V

    const/4 v1, 0x1

    return-void
.end method

.method public static b(Lkotlinx/coroutines/f3;Ljava/lang/Object;Li8/p;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/f3;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/f3;",
            "TR;",
            "Li8/p<",
            "-TR;-",
            "Lkotlin/coroutines/g$b;",
            "+TR;>;)TR;"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/n2$a;->d(Lkotlinx/coroutines/n2;Ljava/lang/Object;Li8/p;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public static c(Lkotlinx/coroutines/f3;Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;
    .locals 2
    .param p0    # Lkotlinx/coroutines/f3;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g$c;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E::",
            "Lkotlin/coroutines/g$b;",
            ">(",
            "Lkotlinx/coroutines/f3;",
            "Lkotlin/coroutines/g$c<",
            "TE;>;)TE;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lkotlinx/coroutines/n2$a;->e(Lkotlinx/coroutines/n2;Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method public static d(Lkotlinx/coroutines/f3;Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g;
    .locals 2
    .param p0    # Lkotlinx/coroutines/f3;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g$c;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/f3;",
            "Lkotlin/coroutines/g$c<",
            "*>;)",
            "Lkotlin/coroutines/g;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lkotlinx/coroutines/n2$a;->g(Lkotlinx/coroutines/n2;Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method public static e(Lkotlinx/coroutines/f3;Lkotlin/coroutines/g;)Lkotlin/coroutines/g;
    .locals 2
    .param p0    # Lkotlinx/coroutines/f3;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lkotlinx/coroutines/n2$a;->h(Lkotlinx/coroutines/n2;Lkotlin/coroutines/g;)Lkotlin/coroutines/g;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public static f(Lkotlinx/coroutines/f3;Lkotlinx/coroutines/n2;)Lkotlinx/coroutines/n2;
    .locals 2
    .param p0    # Lkotlinx/coroutines/f3;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/n2;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Operator \'+\' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`."
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lkotlinx/coroutines/n2$a;->i(Lkotlinx/coroutines/n2;Lkotlinx/coroutines/n2;)Lkotlinx/coroutines/n2;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method
