.class public final synthetic Lkotlinx/coroutines/android/f;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/Choreographer$FrameCallback;


# instance fields
.field public final synthetic a:Lkotlinx/coroutines/q;


# direct methods
.method public synthetic constructor <init>(Lkotlinx/coroutines/q;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/android/f;->a:Lkotlinx/coroutines/q;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final doFrame(J)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@4s~   b~r ao @ ~ o@ ~@~m~~.~il@f~~fo~@/~o-~@yt@~~@ @@@~~  @@cld~tbSniu1@ @ ooMs @ b@ Ki~ ~/@@v~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/android/f;->a:Lkotlinx/coroutines/q;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, p1, p2}, Lkotlinx/coroutines/android/g;->a(Lkotlinx/coroutines/q;J)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method
