.class public final Lkotlinx/coroutines/android/a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/internal/d0;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ssb~b~ ~~l~t~~fmf @~@@~1~/@@ M ~@~@@~.~ lc@ n@o b@i  ro Ko@i/o ooa~~ ~v@~@y@~-~t @@ @@ud~ @i  S"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const-string/jumbo v0, "tm.moee u hrendttieMbme sos Dtrtfrakcop scsllet su -ootnenau ircoessFdisxnt-i"

    const-string v0, "srste c- s aisatliuktnesnlp t ruFmMeDnrse-i u efddcte.tcssrosoiboeot thenomxo"

    const/4 v2, 0x3

    const-string v0, "rs nonoa otmmeutti-eted o oedtes a scrtnsco kue tethnloi-DlusrefcsiprMxsFaisb"

    const-string v0, "For tests Dispatchers.setMain from kotlinx-coroutines-test module can be used"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public b(Ljava/util/List;)Lkotlinx/coroutines/z2;
    .locals 5
    .param p1    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lkotlinx/coroutines/internal/d0;",
            ">;)",
            "Lkotlinx/coroutines/z2;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x0

    move v4, v3

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v0, Lkotlinx/coroutines/android/d;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p1, v1}, Lkotlinx/coroutines/android/g;->d(Landroid/os/Looper;Z)Landroid/os/Handler;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v0, p1, v2, v1, v2}, Lkotlinx/coroutines/android/d;-><init>(Landroid/os/Handler;Ljava/lang/String;ILkotlin/jvm/internal/w;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v0, " n lpbibi tloamaomaenlahv eirs T"

    const-string v0, "lvpmaneamh naolb sal ieoio T itr"

    const/4 v4, 0x1

    const-string v0, "laa o uhnetae  vrlminTsiobeaop l"

    const-string v0, "The main looper is not available"

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw p1
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const v0, 0x3fffffff    # 1.9999999f

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method
