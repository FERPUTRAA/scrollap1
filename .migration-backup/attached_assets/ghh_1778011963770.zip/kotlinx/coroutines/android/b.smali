.class public final Lkotlinx/coroutines/android/b;
.super Lkotlin/coroutines/a;

# interfaces
.implements Lkotlinx/coroutines/p0;


# instance fields
.field private volatile _preHandler:Ljava/lang/Object;
    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lkotlinx/coroutines/p0;->m0:Lkotlinx/coroutines/p0$b;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lkotlin/coroutines/a;-><init>(Lkotlin/coroutines/g$c;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p0, p0, Lkotlinx/coroutines/android/b;->_preHandler:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method private final d0()Ljava/lang/reflect/Method;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@@s ~n @@ r@ @bS@@o/ ~~lv ~@~@~@~@~ bf~@ @~tK~d~~~~i@c~o  ol@Mob 4 tmi s ~~@y oo~f@i~ ~/~u .@-1@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/android/b;->_preHandler:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eq v0, p0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    check-cast v0, Ljava/lang/reflect/Method;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-object v0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-class v1, Ljava/lang/Thread;

    const-class v1, Ljava/lang/Thread;

    const/4 v6, 0x3

    const-class v1, Ljava/lang/Thread;

    const-class v1, Ljava/lang/Thread;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string v2, "asgmtehnngeluaepPrHocitdcrnUEe"

    const-string v2, "rnsleccugaotpeePtnxgrEiaHnheUd"

    const/4 v6, 0x1

    const-string/jumbo v2, "touporHnaecdPatehrntUEeigcgelx"

    const-string v2, "getUncaughtExceptionPreHandler"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x3

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/lang/reflect/Method;->getModifiers()I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v2}, Ljava/lang/reflect/Modifier;->isPublic(I)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eqz v2, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/lang/reflect/Method;->getModifiers()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v2}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v2, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v3, 0x1

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v3, :cond_2

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :catchall_0
    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    iput-object v0, p0, Lkotlinx/coroutines/android/b;->_preHandler:Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-object v0
.end method


# virtual methods
.method public handleException(Lkotlin/coroutines/g;Ljava/lang/Throwable;)V
    .locals 4
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/16 v0, 0x1a

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    if-gt v0, p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/16 v0, 0x1c

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ge p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v2, 0x7

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    move p1, v1

    move p1, v1

    const/4 v3, 0x6

    move p1, v1

    move p1, v1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz p1, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0}, Lkotlinx/coroutines/android/b;->d0()Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_1

    :cond_1
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    instance-of v1, p1, Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v1, :cond_2

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/Thread$UncaughtExceptionHandler;

    :cond_2
    const/4 v3, 0x3

    if-eqz v0, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {v0, p1, p2}, Ljava/lang/Thread$UncaughtExceptionHandler;->uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method
