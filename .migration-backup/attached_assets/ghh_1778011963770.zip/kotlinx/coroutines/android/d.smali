.class public final Lkotlinx/coroutines/android/d;
.super Lkotlinx/coroutines/android/e;

# interfaces
.implements Lkotlinx/coroutines/e1;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nHandlerDispatcher.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HandlerDispatcher.kt\nkotlinx/coroutines/android/HandlerContext\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Runnable.kt\nkotlinx/coroutines/RunnableKt\n*L\n1#1,212:1\n1#2:213\n17#3:214\n*S KotlinDebug\n*F\n+ 1 HandlerDispatcher.kt\nkotlinx/coroutines/android/HandlerContext\n*L\n147#1:214\n*E\n"
.end annotation


# instance fields
.field private volatile _immediate:Lkotlinx/coroutines/android/d;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final b:Landroid/os/Handler;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final c:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final d:Z

.field private final e:Lkotlinx/coroutines/android/d;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/os/Handler;Ljava/lang/String;)V
    .locals 3
    .param p1    # Landroid/os/Handler;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2, v0}, Lkotlinx/coroutines/android/d;-><init>(Landroid/os/Handler;Ljava/lang/String;Z)V

    const/4 v1, 0x5

    move v2, v1

    return-void
.end method

.method public synthetic constructor <init>(Landroid/os/Handler;Ljava/lang/String;ILkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    and-int/lit8 p3, p3, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    if-eqz p3, :cond_0

    const/4 v1, 0x6

    const/4 p2, 0x1

    const/4 v1, 0x2

    const/4 p2, 0x0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lkotlinx/coroutines/android/d;-><init>(Landroid/os/Handler;Ljava/lang/String;)V

    const/4 v0, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method private constructor <init>(Landroid/os/Handler;Ljava/lang/String;Z)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lkotlinx/coroutines/android/e;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/android/d;->b:Landroid/os/Handler;

    const/4 v1, 0x4

    move v2, v1

    iput-object p2, p0, Lkotlinx/coroutines/android/d;->c:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    iput-boolean p3, p0, Lkotlinx/coroutines/android/d;->d:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz p3, :cond_0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lkotlinx/coroutines/android/d;->_immediate:Lkotlinx/coroutines/android/d;

    const/4 v2, 0x1

    iget-object p3, p0, Lkotlinx/coroutines/android/d;->_immediate:Lkotlinx/coroutines/android/d;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-nez p3, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    new-instance p3, Lkotlinx/coroutines/android/d;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-direct {p3, p1, p2, v0}, Lkotlinx/coroutines/android/d;-><init>(Landroid/os/Handler;Ljava/lang/String;Z)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object p3, p0, Lkotlinx/coroutines/android/d;->_immediate:Lkotlinx/coroutines/android/d;

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object p3, p0, Lkotlinx/coroutines/android/d;->e:Lkotlinx/coroutines/android/d;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public static synthetic D0(Lkotlinx/coroutines/android/d;Ljava/lang/Runnable;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " rs~@u~@  ~ @a/@@fo~@lt@~~~4~~~y  cfni~@@@ @~@Moo b~  v@~~ o@@is~1db@ ~i@~  ~~b @/~tm. oo Kl@-~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lkotlinx/coroutines/android/d;->S0(Lkotlinx/coroutines/android/d;Ljava/lang/Runnable;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static final synthetic G0(Lkotlinx/coroutines/android/d;)Landroid/os/Handler;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget-object p0, p0, Lkotlinx/coroutines/android/d;->b:Landroid/os/Handler;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method private final M0(Lkotlin/coroutines/g;Ljava/lang/Runnable;)V
    .locals 5

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v0, Ljava/util/concurrent/CancellationException;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v2, "nasrd dntu hrsa seeiTl erteelaedkt/g taeip, sn htcw /yhhjr eedc"

    const/4 v4, 0x6

    const-string v2, "The task was rejected, the handler underlying the dispatcher \'"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const-string v2, "/s maes /wdco"

    const/4 v4, 0x2

    const-string v2, "\' was closed"

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p1, v0}, Lkotlinx/coroutines/r2;->f(Lkotlin/coroutines/g;Ljava/util/concurrent/CancellationException;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {}, Lkotlinx/coroutines/m1;->c()Lkotlinx/coroutines/o0;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, p1, p2}, Lkotlinx/coroutines/o0;->d0(Lkotlin/coroutines/g;Ljava/lang/Runnable;)V

    const/4 v4, 0x4

    return-void
.end method

.method private static final S0(Lkotlinx/coroutines/android/d;Ljava/lang/Runnable;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget-object p0, p0, Lkotlinx/coroutines/android/d;->b:Landroid/os/Handler;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public bridge synthetic A0()Lkotlinx/coroutines/android/e;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/android/d;->Q0()Lkotlinx/coroutines/android/d;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public Q0()Lkotlinx/coroutines/android/d;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/android/d;->e:Lkotlinx/coroutines/android/d;

    const/4 v2, 0x4

    const/4 v1, 0x0

    return-object v0
.end method

.method public d(JLkotlinx/coroutines/q;)V
    .locals 6
    .param p3    # Lkotlinx/coroutines/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lkotlinx/coroutines/q<",
            "-",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v0, Lkotlinx/coroutines/android/d$a;

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-direct {v0, p3, p0}, Lkotlinx/coroutines/android/d$a;-><init>(Lkotlinx/coroutines/q;Lkotlinx/coroutines/android/d;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/android/d;->b:Landroid/os/Handler;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-wide v2, 0x3fffffffffffffffL    # 1.9999999999999998

    const-wide v2, 0x3fffffffffffffffL    # 1.9999999999999998

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p1, p2, v2, v3}, Lkotlin/ranges/s;->C(JJ)J

    move-result-wide p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1, v0, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance p1, Lkotlinx/coroutines/android/d$b;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p1, p0, v0}, Lkotlinx/coroutines/android/d$b;-><init>(Lkotlinx/coroutines/android/d;Ljava/lang/Runnable;)V

    const/4 v5, 0x3

    invoke-interface {p3, p1}, Lkotlinx/coroutines/q;->s(Li8/l;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-interface {p3}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {p0, p1, v0}, Lkotlinx/coroutines/android/d;->M0(Lkotlin/coroutines/g;Ljava/lang/Runnable;)V

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    return-void
.end method

.method public d0(Lkotlin/coroutines/g;Ljava/lang/Runnable;)V
    .locals 3
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Runnable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/android/d;->b:Landroid/os/Handler;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2}, Lkotlinx/coroutines/android/d;->M0(Lkotlin/coroutines/g;Ljava/lang/Runnable;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x3

    instance-of v0, p1, Lkotlinx/coroutines/android/d;

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    check-cast p1, Lkotlinx/coroutines/android/d;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object p1, p1, Lkotlinx/coroutines/android/d;->b:Landroid/os/Handler;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/android/d;->b:Landroid/os/Handler;

    const/4 v2, 0x4

    if-ne p1, v0, :cond_0

    const/4 p1, 0x1

    and-int/2addr v2, p1

    move v1, p1

    move v1, p1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p1
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/android/d;->b:Landroid/os/Handler;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public l(JLjava/lang/Runnable;Lkotlin/coroutines/g;)Lkotlinx/coroutines/p1;
    .locals 5
    .param p3    # Ljava/lang/Runnable;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/android/d;->b:Landroid/os/Handler;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const-wide v1, 0x3fffffffffffffffL    # 1.9999999999999998

    const-wide v1, 0x3fffffffffffffffL    # 1.9999999999999998

    const/4 v4, 0x2

    const-wide v1, 0x3fffffffffffffffL    # 1.9999999999999998

    const-wide v1, 0x3fffffffffffffffL    # 1.9999999999999998

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p1, p2, v1, v2}, Lkotlin/ranges/s;->C(JJ)J

    move-result-wide p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, p3, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance p1, Lkotlinx/coroutines/android/c;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {p1, p0, p3}, Lkotlinx/coroutines/android/c;-><init>(Lkotlinx/coroutines/android/d;Ljava/lang/Runnable;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object p1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p0, p4, p3}, Lkotlinx/coroutines/android/d;->M0(Lkotlin/coroutines/g;Ljava/lang/Runnable;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object p1, Lkotlinx/coroutines/c3;->a:Lkotlinx/coroutines/c3;

    const/4 v4, 0x2

    const/4 v3, 0x0

    return-object p1
.end method

.method public p0(Lkotlin/coroutines/g;)Z
    .locals 3
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-boolean p1, p0, Lkotlinx/coroutines/android/d;->d:Z

    const/4 v2, 0x0

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/android/d;->b:Landroid/os/Handler;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p1
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Lkotlinx/coroutines/z2;->v0()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/android/d;->c:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/android/d;->b:Landroid/os/Handler;

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/os/Handler;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-boolean v1, p0, Lkotlinx/coroutines/android/d;->d:Z

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v0, "dam.oteiei"

    const/4 v3, 0x5

    const-string/jumbo v0, "tdimiamme."

    const-string v0, ".immediate"

    const/4 v3, 0x6

    const/4 v2, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0
.end method

.method public bridge synthetic u0()Lkotlinx/coroutines/z2;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/android/d;->Q0()Lkotlinx/coroutines/android/d;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method
