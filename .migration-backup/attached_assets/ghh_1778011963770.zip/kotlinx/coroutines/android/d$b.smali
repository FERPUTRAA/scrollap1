.class final Lkotlinx/coroutines/android/d$b;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/android/d;->d(JLkotlinx/coroutines/q;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/l<",
        "Ljava/lang/Throwable;",
        "Lkotlin/s2;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic $block:Ljava/lang/Runnable;

.field final synthetic this$0:Lkotlinx/coroutines/android/d;


# direct methods
.method constructor <init>(Lkotlinx/coroutines/android/d;Ljava/lang/Runnable;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/android/d$b;->this$0:Lkotlinx/coroutines/android/d;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p2, p0, Lkotlinx/coroutines/android/d$b;->$block:Ljava/lang/Runnable;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p1, 0x1

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " rs @ @ ~@@@- l~~.~@s fti@t~o@bmbooo f u v@M lo1~@ ~4@ ny~@~@S i@@c~~@K/~~~~b~~~@a~  ~i @do~~/ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    check-cast p1, Ljava/lang/Throwable;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/android/d$b;->invoke(Ljava/lang/Throwable;)V

    const/4 v1, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method public final invoke(Ljava/lang/Throwable;)V
    .locals 3
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/android/d$b;->this$0:Lkotlinx/coroutines/android/d;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1}, Lkotlinx/coroutines/android/d;->G0(Lkotlinx/coroutines/android/d;)Landroid/os/Handler;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/android/d$b;->$block:Ljava/lang/Runnable;

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    const/4 v2, 0x0

    return-void
.end method
