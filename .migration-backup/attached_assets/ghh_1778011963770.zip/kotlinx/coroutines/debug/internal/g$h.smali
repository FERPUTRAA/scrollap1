.class final Lkotlinx/coroutines/debug/internal/g$h;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/debug/internal/g;->M()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/a<",
        "Lkotlin/s2;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lkotlinx/coroutines/debug/internal/g$h;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lkotlinx/coroutines/debug/internal/g$h;

    const/4 v2, 0x5

    invoke-direct {v0}, Lkotlinx/coroutines/debug/internal/g$h;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    sput-object v0, Lkotlinx/coroutines/debug/internal/g$h;->a:Lkotlinx/coroutines/debug/internal/g$h;

    const/4 v2, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s@y  @ .v-@m~o~o@4@~b ~ f~@is@~ ~o~r@ l t@b M@ ~ld~if~~~~c~a@~/~un/@~~K@@@~b~io o@S t   ~o@1@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/debug/internal/g$h;->invoke()V

    const/4 v2, 0x7

    sget-object v0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public final invoke()V
    .locals 3

    const/4 v2, 0x7

    invoke-static {}, Lkotlinx/coroutines/debug/internal/g;->a()Lkotlinx/coroutines/debug/internal/b;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lkotlinx/coroutines/debug/internal/b;->k()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method
