.class final Lkotlinx/coroutines/debug/internal/e$a;
.super Lkotlin/coroutines/jvm/internal/k;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/debug/internal/e;->b()Ljava/util/List;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/k;",
        "Li8/p<",
        "Lkotlin/sequences/o<",
        "-",
        "Ljava/lang/StackTraceElement;",
        ">;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.debug.internal.DebugCoroutineInfoImpl$creationStackTrace$1"
    f = "DebugCoroutineInfoImpl.kt"
    i = {}
    l = {
        0x4b
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $bottom:Lkotlinx/coroutines/debug/internal/m;

.field private synthetic L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Lkotlinx/coroutines/debug/internal/e;


# direct methods
.method constructor <init>(Lkotlinx/coroutines/debug/internal/e;Lkotlinx/coroutines/debug/internal/m;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/debug/internal/e;",
            "Lkotlinx/coroutines/debug/internal/m;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/debug/internal/e$a;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/e$a;->this$0:Lkotlinx/coroutines/debug/internal/e;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/e$a;->$bottom:Lkotlinx/coroutines/debug/internal/m;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    const/4 p1, 0x2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/k;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x0

    const-string v3, " ~s@ t@4@@@ K.~abovl@ ~@@@@o@Smbo i~~~ ~~@~@rMb@~@ @@@~  ~~~fu~o~dos ~   -@y/lf n ~co/it~~  1@i~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    new-instance v0, Lkotlinx/coroutines/debug/internal/e$a;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/debug/internal/e$a;->this$0:Lkotlinx/coroutines/debug/internal/e;

    const/4 v4, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/debug/internal/e$a;->$bottom:Lkotlinx/coroutines/debug/internal/m;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/debug/internal/e$a;-><init>(Lkotlinx/coroutines/debug/internal/e;Lkotlinx/coroutines/debug/internal/m;Lkotlin/coroutines/d;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-object p1, v0, Lkotlinx/coroutines/debug/internal/e$a;->L$0:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    check-cast p1, Lkotlin/sequences/o;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/debug/internal/e$a;->k(Lkotlin/sequences/o;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x1

    iget v1, p0, Lkotlinx/coroutines/debug/internal/e$a;->label:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-ne v1, v2, :cond_0

    const/4 v5, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v0, "/camort fmienlos oi /r/wuhu/ ebikl//roe n/e sevtote"

    const-string v0, " tse/iifel/eu eomi// evol/nesn rwb  k/aoottchruc/ro"

    const/4 v5, 0x3

    const-string v0, " oaool nh/tviwroeib s ufte imrkeel /eot/cuceo/r/n//"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v4, 0x5

    move v5, v4

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    throw p1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/debug/internal/e$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    check-cast p1, Lkotlin/sequences/o;

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/debug/internal/e$a;->this$0:Lkotlinx/coroutines/debug/internal/e;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v3, p0, Lkotlinx/coroutines/debug/internal/e$a;->$bottom:Lkotlinx/coroutines/debug/internal/m;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v3}, Lkotlinx/coroutines/debug/internal/m;->getCallerFrame()Lkotlin/coroutines/jvm/internal/e;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput v2, p0, Lkotlinx/coroutines/debug/internal/e$a;->label:I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v1, p1, v3, p0}, Lkotlinx/coroutines/debug/internal/e;->a(Lkotlinx/coroutines/debug/internal/e;Lkotlin/sequences/o;Lkotlin/coroutines/jvm/internal/e;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-ne p1, v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-object v0

    :cond_2
    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object p1
.end method

.method public final k(Lkotlin/sequences/o;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlin/sequences/o;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/sequences/o<",
            "-",
            "Ljava/lang/StackTraceElement;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/debug/internal/e$a;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    check-cast p1, Lkotlinx/coroutines/debug/internal/e$a;

    const/4 v1, 0x3

    const/4 v0, 0x0

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v0, 0x2

    move v1, v0

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/debug/internal/e$a;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p1
.end method
