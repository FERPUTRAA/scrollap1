.class public final Lkotlinx/coroutines/debug/internal/e;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDebugCoroutineInfoImpl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DebugCoroutineInfoImpl.kt\nkotlinx/coroutines/debug/internal/DebugCoroutineInfoImpl\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,101:1\n1#2:102\n*E\n"
.end annotation


# instance fields
.field private final a:Lkotlinx/coroutines/debug/internal/m;
    .annotation build Lia/e;
    .end annotation
.end field

.field public final b:J
    .annotation build Lh8/e;
    .end annotation
.end field

.field private final c:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lkotlin/coroutines/g;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private d:Ljava/lang/String;
    .annotation build Lia/d;
    .end annotation
.end field

.field public e:Ljava/lang/Thread;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field private f:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lkotlin/coroutines/jvm/internal/e;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/debug/internal/m;J)V
    .locals 2
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/debug/internal/m;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/e;->a:Lkotlinx/coroutines/debug/internal/m;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-wide p3, p0, Lkotlinx/coroutines/debug/internal/e;->b:J

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    new-instance p2, Ljava/lang/ref/WeakReference;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p2, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/e;->c:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    const-string p1, "ACsETDE"

    const-string p1, "DEsCTEA"

    const-string p1, "EADmERC"

    const-string p1, "CREATED"

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/e;->d:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public static final synthetic a(Lkotlinx/coroutines/debug/internal/e;Lkotlin/sequences/o;Lkotlin/coroutines/jvm/internal/e;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@b~robi~@ n o~@l4oS~.~ ~~1o ~i@m ~@fMc@ ~~@~@u~lK/o ~ @  @  @@i~@d @@@/tfv~~@b @a-y~~ ~to ~s@o~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2, p3}, Lkotlinx/coroutines/debug/internal/e;->k(Lkotlin/sequences/o;Lkotlin/coroutines/jvm/internal/e;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method private final b()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/e;->a:Lkotlinx/coroutines/debug/internal/m;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {}, Lkotlin/collections/u;->E()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object v0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v1, Lkotlinx/coroutines/debug/internal/e$a;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v2, 0x0

    shl-int/2addr v4, v2

    const/4 v3, 0x5

    move v4, v3

    invoke-direct {v1, p0, v0, v2}, Lkotlinx/coroutines/debug/internal/e$a;-><init>(Lkotlinx/coroutines/debug/internal/e;Lkotlinx/coroutines/debug/internal/m;Lkotlin/coroutines/d;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-static {v1}, Lkotlin/sequences/p;->b(Li8/p;)Lkotlin/sequences/m;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v0}, Lkotlin/sequences/p;->c3(Lkotlin/sequences/m;)Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object v0
.end method

.method private final k(Lkotlin/sequences/o;Lkotlin/coroutines/jvm/internal/e;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/sequences/o<",
            "-",
            "Ljava/lang/StackTraceElement;",
            ">;",
            "Lkotlin/coroutines/jvm/internal/e;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    instance-of v0, p3, Lkotlinx/coroutines/debug/internal/e$b;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v0, :cond_0

    move-object v0, p3

    move-object v0, p3

    move-object v0, p3

    move-object v0, p3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    check-cast v0, Lkotlinx/coroutines/debug/internal/e$b;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget v1, v0, Lkotlinx/coroutines/debug/internal/e$b;->label:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/high16 v2, -0x80000000

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    and-int v3, v1, v2

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v3, :cond_0

    const/4 v5, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    sub-int/2addr v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    iput v1, v0, Lkotlinx/coroutines/debug/internal/e$b;->label:I

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-instance v0, Lkotlinx/coroutines/debug/internal/e$b;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {v0, p0, p3}, Lkotlinx/coroutines/debug/internal/e$b;-><init>(Lkotlinx/coroutines/debug/internal/e;Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object p3, v0, Lkotlinx/coroutines/debug/internal/e$b;->result:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget v2, v0, Lkotlinx/coroutines/debug/internal/e$b;->label:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v2, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ne v2, v3, :cond_1

    const/4 v6, 0x7

    iget-object p1, v0, Lkotlinx/coroutines/debug/internal/e$b;->L$2:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    check-cast p1, Lkotlin/coroutines/jvm/internal/e;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object p2, v0, Lkotlinx/coroutines/debug/internal/e$b;->L$1:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    check-cast p2, Lkotlin/sequences/o;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v2, v0, Lkotlinx/coroutines/debug/internal/e$b;->L$0:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    check-cast v2, Lkotlinx/coroutines/debug/internal/e;

    const/4 v6, 0x3

    invoke-static {p3}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v6, 0x2

    goto :goto_2

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x0

    const-string p2, "irosbbrmea/ei/ h/nlokecur/ee/onmtlwoivt/u    f c//t"

    const-string p2, "l/rm/iebo/emt/esrklcenciau fo/hu/i onw ort/ t ee/ v"

    const/4 v6, 0x0

    const-string p2, "/es wtuen llieecemiuvobrr/r e/ttok a/ uoi h/cf/o/o/"

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    throw p1

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {p3}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez p2, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x2

    return-object p1

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-interface {p2}, Lkotlin/coroutines/jvm/internal/e;->getStackTraceElement()Ljava/lang/StackTraceElement;

    move-result-object p3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz p3, :cond_5

    const/4 v6, 0x1

    const/4 v5, 0x2

    iput-object v2, v0, Lkotlinx/coroutines/debug/internal/e$b;->L$0:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput-object p1, v0, Lkotlinx/coroutines/debug/internal/e$b;->L$1:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput-object p2, v0, Lkotlinx/coroutines/debug/internal/e$b;->L$2:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x3

    iput v3, v0, Lkotlinx/coroutines/debug/internal/e$b;->label:I

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p1, p3, v0}, Lkotlin/sequences/o;->a(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-ne p3, v1, :cond_4

    const/4 v6, 0x0

    return-object v1

    :cond_4
    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    :goto_2
    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    :cond_5
    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-interface {p2}, Lkotlin/coroutines/jvm/internal/e;->getCallerFrame()Lkotlin/coroutines/jvm/internal/e;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz p2, :cond_6

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_1

    :cond_6
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-object p1
.end method


# virtual methods
.method public final c()Lkotlin/coroutines/g;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/e;->c:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast v0, Lkotlin/coroutines/g;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public final d()Lkotlinx/coroutines/debug/internal/m;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/e;->a:Lkotlinx/coroutines/debug/internal/m;

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public final e()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/debug/internal/e;->b()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public final f()Lkotlin/coroutines/jvm/internal/e;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/e;->f:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast v0, Lkotlin/coroutines/jvm/internal/e;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public final g()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/e;->d:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public final h()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/debug/internal/e;->f()Lkotlin/coroutines/jvm/internal/e;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {}, Lkotlin/collections/u;->E()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object v0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance v1, Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    invoke-interface {v0}, Lkotlin/coroutines/jvm/internal/e;->getStackTraceElement()Ljava/lang/StackTraceElement;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-interface {v0}, Lkotlin/coroutines/jvm/internal/e;->getCallerFrame()Lkotlin/coroutines/jvm/internal/e;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object v1
.end method

.method public final i(Lkotlin/coroutines/jvm/internal/e;)V
    .locals 3
    .param p1    # Lkotlin/coroutines/jvm/internal/e;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x2

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x0

    move v2, v0

    :goto_0
    const/4 v1, 0x0

    move v2, v1

    iput-object v0, p0, Lkotlinx/coroutines/debug/internal/e;->f:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public final j(Ljava/lang/String;Lkotlin/coroutines/d;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/coroutines/d<",
            "*>;)V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/e;->d:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v0, "DNESoPUpS"

    const-string v0, "SUPEoEDNS"

    const/4 v3, 0x7

    const-string v0, "SUDEPSENq"

    const-string v0, "SUSPENDED"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    invoke-virtual {p0}, Lkotlinx/coroutines/debug/internal/e;->f()Lkotlin/coroutines/jvm/internal/e;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/e;->d:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    instance-of v0, p2, Lkotlin/coroutines/jvm/internal/e;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast p2, Lkotlin/coroutines/jvm/internal/e;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0, p2}, Lkotlinx/coroutines/debug/internal/e;->i(Lkotlin/coroutines/jvm/internal/e;)V

    const/4 v3, 0x1

    const-string p2, "NNsIbRN"

    const-string p2, "UNNRNbI"

    const/4 v3, 0x1

    const-string p2, "GIUmNNN"

    const-string p2, "RUNNING"

    const/4 v3, 0x3

    invoke-static {p1, p2}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz p1, :cond_2

    const/4 v3, 0x6

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v1, p0, Lkotlinx/coroutines/debug/internal/e;->e:Ljava/lang/Thread;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v1, "CInooDuutut=osreig(nebeft"

    const-string v1, "rCiutuubIsngee=enft(oDoot"

    const/4 v3, 0x7

    const-string v1, "CoirtbutfsDgonIbe=teanoeu"

    const-string v1, "DebugCoroutineInfo(state="

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Lkotlinx/coroutines/debug/internal/e;->g()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v1, "nc=oe,upt"

    const-string v1, "=tecn,opx"

    const/4 v3, 0x1

    const-string v1, "e=x,cnopt"

    const-string v1, ",context="

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/debug/internal/e;->c()Lkotlin/coroutines/g;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/16 v1, 0x29

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0
.end method
