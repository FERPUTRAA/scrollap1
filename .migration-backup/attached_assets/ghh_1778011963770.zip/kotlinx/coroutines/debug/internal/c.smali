.class public final Lkotlinx/coroutines/debug/internal/c;
.super Ljava/lang/Object;


# static fields
.field private static final a:I = -0x61c88647

.field private static final b:I = 0x10

.field private static final c:Lkotlinx/coroutines/internal/r0;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final d:Lkotlinx/coroutines/debug/internal/l;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final e:Lkotlinx/coroutines/debug/internal/l;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance v0, Lkotlinx/coroutines/internal/r0;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v1, "REsSHs"

    const-string v1, "SHsRHE"

    const/4 v3, 0x7

    const-string v1, "AHHmRE"

    const-string v1, "REHASH"

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lkotlinx/coroutines/internal/r0;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    sput-object v0, Lkotlinx/coroutines/debug/internal/c;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v2, 0x7

    const/4 v2, 0x5

    new-instance v0, Lkotlinx/coroutines/debug/internal/l;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lkotlinx/coroutines/debug/internal/l;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    sput-object v0, Lkotlinx/coroutines/debug/internal/c;->d:Lkotlinx/coroutines/debug/internal/l;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Lkotlinx/coroutines/debug/internal/l;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lkotlinx/coroutines/debug/internal/l;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    sput-object v0, Lkotlinx/coroutines/debug/internal/c;->e:Lkotlinx/coroutines/debug/internal/l;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method public static final synthetic a()Lkotlinx/coroutines/internal/r0;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "t~s~o ~~@@@~l ~ @~ b@@~oc~~b@y~lo / ~@@o@~  @ Ko~~SM@im. fn@@ari4@~  ~ vi~@@oo @~~tf@-u ~bd@~/1 "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lkotlinx/coroutines/debug/internal/c;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public static final synthetic b(Ljava/lang/Object;)Lkotlinx/coroutines/debug/internal/l;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p0}, Lkotlinx/coroutines/debug/internal/c;->d(Ljava/lang/Object;)Lkotlinx/coroutines/debug/internal/l;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p0
.end method

.method public static final synthetic c()Ljava/lang/Void;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {}, Lkotlinx/coroutines/debug/internal/c;->e()Ljava/lang/Void;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method private static final d(Ljava/lang/Object;)Lkotlinx/coroutines/debug/internal/l;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez p0, :cond_0

    const/4 v1, 0x6

    move v2, v1

    sget-object p0, Lkotlinx/coroutines/debug/internal/c;->d:Lkotlinx/coroutines/debug/internal/l;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object p0, Lkotlinx/coroutines/debug/internal/c;->e:Lkotlinx/coroutines/debug/internal/l;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Lkotlinx/coroutines/debug/internal/l;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lkotlinx/coroutines/debug/internal/l;-><init>(Ljava/lang/Object;)V

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p0
.end method

.method private static final e()Ljava/lang/Void;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, "nmleebondmte ti"

    const-string v1, "not implemented"

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    move v3, v2

    throw v0
.end method
