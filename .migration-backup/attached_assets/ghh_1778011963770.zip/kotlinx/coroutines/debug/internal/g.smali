.class public final Lkotlinx/coroutines/debug/internal/g;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/debug/internal/g$a;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDebugProbesImpl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DebugProbesImpl.kt\nkotlinx/coroutines/debug/internal/DebugProbesImpl\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 _Sequences.kt\nkotlin/sequences/SequencesKt___SequencesKt\n+ 5 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 6 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,603:1\n154#1,2:627\n156#1,4:630\n161#1,6:635\n154#1,2:641\n156#1,4:644\n161#1,6:649\n1#2:604\n1#2:629\n1#2:643\n764#3:605\n855#3,2:606\n1206#3,2:608\n1236#3,4:610\n1849#3,2:658\n348#3,7:666\n1813#3,8:673\n602#4:614\n602#4:634\n602#4:648\n602#4:655\n1290#4,2:656\n37#5:615\n36#5,3:616\n37#5:619\n36#5,3:620\n37#5:623\n36#5,3:624\n1620#6,6:660\n1728#6,6:681\n*S KotlinDebug\n*F\n+ 1 DebugProbesImpl.kt\nkotlinx/coroutines/debug/internal/DebugProbesImpl\n*L\n249#1:627,2\n249#1:630,4\n249#1:635,6\n256#1:641,2\n256#1:644,4\n256#1:649,6\n249#1:629\n256#1:643\n114#1:605\n114#1:606,2\n115#1:608,2\n115#1:610,4\n310#1:658,2\n419#1:666,7\n504#1:673,8\n159#1:614\n249#1:634\n256#1:648\n290#1:655\n291#1:656,2\n215#1:615\n215#1:616,3\n216#1:619\n216#1:620,3\n217#1:623\n217#1:624,3\n358#1:660,6\n554#1:681,6\n*E\n"
.end annotation


# static fields
.field public static final a:Lkotlinx/coroutines/debug/internal/g;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final b:Ljava/lang/String; = "Coroutine creation stacktrace"
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final c:Ljava/text/SimpleDateFormat;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static d:Ljava/lang/Thread;
    .annotation build Lia/e;
    .end annotation
.end field

.field private static final e:Lkotlinx/coroutines/debug/internal/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/debug/internal/b<",
            "Lkotlinx/coroutines/debug/internal/g$a<",
            "*>;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private static final synthetic f:Lkotlinx/coroutines/debug/internal/h;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final synthetic g:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

.field private static final h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static i:Z

.field private static volatile installations:I

.field private static j:Z

.field private static final k:Li8/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/l<",
            "Ljava/lang/Boolean;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field private static final l:Lkotlinx/coroutines/debug/internal/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/debug/internal/b<",
            "Lkotlin/coroutines/jvm/internal/e;",
            "Lkotlinx/coroutines/debug/internal/e;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x7

    new-instance v0, Lkotlinx/coroutines/debug/internal/g;

    const/4 v6, 0x3

    invoke-direct {v0}, Lkotlinx/coroutines/debug/internal/g;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    sput-object v0, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v6, 0x1

    const/4 v5, 0x1

    new-instance v1, Ljava/text/SimpleDateFormat;

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string v2, "dHs//yH ydysmsMm:sy"

    const-string v2, "/ysyMsHMddmymy:sH /"

    const/4 v6, 0x1

    const-string v2, ":d:mMm/dHysM sHyy/m"

    const-string/jumbo v2, "yyyy/MM/dd HH:mm:ss"

    const/4 v6, 0x2

    const/4 v5, 0x1

    invoke-direct {v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    shl-int/2addr v6, v5

    sput-object v1, Lkotlinx/coroutines/debug/internal/g;->c:Ljava/text/SimpleDateFormat;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-instance v1, Lkotlinx/coroutines/debug/internal/b;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 v4, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct {v1, v3, v4, v2}, Lkotlinx/coroutines/debug/internal/b;-><init>(ZILkotlin/jvm/internal/w;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    sput-object v1, Lkotlinx/coroutines/debug/internal/g;->e:Lkotlinx/coroutines/debug/internal/b;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v1, Lkotlinx/coroutines/debug/internal/h;

    const/4 v6, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v6, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-direct {v1, v2, v3}, Lkotlinx/coroutines/debug/internal/h;-><init>(J)V

    const/4 v6, 0x6

    sput-object v1, Lkotlinx/coroutines/debug/internal/g;->f:Lkotlinx/coroutines/debug/internal/h;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-instance v1, Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-direct {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    sput-object v1, Lkotlinx/coroutines/debug/internal/g;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    sput-boolean v4, Lkotlinx/coroutines/debug/internal/g;->i:Z

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    sput-boolean v4, Lkotlinx/coroutines/debug/internal/g;->j:Z

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {v0}, Lkotlinx/coroutines/debug/internal/g;->t()Li8/l;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    sput-object v0, Lkotlinx/coroutines/debug/internal/g;->k:Li8/l;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-instance v0, Lkotlinx/coroutines/debug/internal/b;

    const/4 v6, 0x6

    const/4 v5, 0x5

    invoke-direct {v0, v4}, Lkotlinx/coroutines/debug/internal/b;-><init>(Z)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    sput-object v0, Lkotlinx/coroutines/debug/internal/g;->l:Lkotlinx/coroutines/debug/internal/b;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-class v0, Lkotlinx/coroutines/debug/internal/h;

    const-class v0, Lkotlinx/coroutines/debug/internal/h;

    const/4 v6, 0x4

    const-class v0, Lkotlinx/coroutines/debug/internal/h;

    const-class v0, Lkotlinx/coroutines/debug/internal/h;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v1, "qmmeoeurecbeun"

    const-string/jumbo v1, "uNbmmreeencequ"

    const/4 v6, 0x1

    const-string/jumbo v1, "ueurebeebqcmns"

    const-string v1, "sequenceNumber"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v0, v1}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    sput-object v0, Lkotlinx/coroutines/debug/internal/g;->g:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method private final A(Ljava/lang/StackTraceElement;)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~u~~M~ut@~rso@~@n@~oi /@ol@v~o ~cl~~/~yb.t@b~  a ~~1o K~4 @@ @~ @@ mb~ i~-fdf@i @ ~@S ~  ~@ @@@@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    invoke-virtual {p1}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x4

    const-string v2, "nolxut.pcoirosneto"

    const-string v2, "ltotoruxneosionck."

    const/4 v5, 0x0

    const-string v2, "kinetorxqlonosu.tc"

    const-string v2, "kotlinx.coroutines"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p1, v2, v3, v0, v1}, Lkotlin/text/v;->s2(Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    return p1
.end method

.method private final B(Lkotlin/coroutines/d;)Lkotlinx/coroutines/debug/internal/g$a;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlinx/coroutines/debug/internal/g$a<",
            "*>;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    instance-of v0, p1, Lkotlin/coroutines/jvm/internal/e;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast p1, Lkotlin/coroutines/jvm/internal/e;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    :goto_0
    const/4 v3, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lkotlinx/coroutines/debug/internal/g;->C(Lkotlin/coroutines/jvm/internal/e;)Lkotlinx/coroutines/debug/internal/g$a;

    move-result-object v1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v1
.end method

.method private final C(Lkotlin/coroutines/jvm/internal/e;)Lkotlinx/coroutines/debug/internal/g$a;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/jvm/internal/e;",
            ")",
            "Lkotlinx/coroutines/debug/internal/g$a<",
            "*>;"
        }
    .end annotation

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    instance-of v0, p1, Lkotlinx/coroutines/debug/internal/g$a;

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p1, Lkotlinx/coroutines/debug/internal/g$a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_1

    :cond_0
    const/4 v1, 0x4

    move v2, v1

    invoke-interface {p1}, Lkotlin/coroutines/jvm/internal/e;->getCallerFrame()Lkotlin/coroutines/jvm/internal/e;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 p1, 0x0

    :goto_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p1
.end method

.method private final D(Ljava/io/PrintStream;Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/PrintStream;",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    const/4 v4, 0x7

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    check-cast v0, Ljava/lang/StackTraceElement;

    const/4 v4, 0x7

    const/4 v3, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    xor-int/2addr v4, v3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v2, "/tsnta/"

    const-string v2, "tan/tb/"

    const/4 v4, 0x5

    const-string v2, "t/ mn/t"

    const-string v2, "\n\tat "

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Ljava/io/PrintStream;->print(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    return-void
.end method

.method private final E(Lkotlinx/coroutines/debug/internal/g$a;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/debug/internal/g$a<",
            "*>;)V"
        }
    .end annotation

    const/4 v2, 0x3

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->e:Lkotlinx/coroutines/debug/internal/b;

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/debug/internal/b;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p1, p1, Lkotlinx/coroutines/debug/internal/g$a;->b:Lkotlinx/coroutines/debug/internal/e;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/e;->f()Lkotlin/coroutines/jvm/internal/e;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lkotlinx/coroutines/debug/internal/g;->I(Lkotlin/coroutines/jvm/internal/e;)Lkotlin/coroutines/jvm/internal/e;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->l:Lkotlinx/coroutines/debug/internal/b;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/debug/internal/b;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method private final I(Lkotlin/coroutines/jvm/internal/e;)Lkotlin/coroutines/jvm/internal/e;
    .locals 3

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {p1}, Lkotlin/coroutines/jvm/internal/e;->getCallerFrame()Lkotlin/coroutines/jvm/internal/e;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez p1, :cond_1

    const/4 v2, 0x4

    const/4 p1, 0x4

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-interface {p1}, Lkotlin/coroutines/jvm/internal/e;->getStackTraceElement()Ljava/lang/StackTraceElement;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object p1
.end method

.method private final J(Ljava/lang/Throwable;)Ljava/util/List;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Throwable;",
            ">(TT;)",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    array-length v0, p1

    const/4 v8, 0x0

    array-length v1, p1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/4 v2, -0x1

    const/4 v7, 0x0

    move v8, v7

    add-int/2addr v1, v2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-ltz v1, :cond_2

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    add-int/lit8 v3, v1, -0x1

    const/4 v8, 0x3

    aget-object v4, p1, v1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string v5, "noguoktsPbtotiD.tencruleorsneviai.u.joelnb.r"

    const-string v5, ".ueiiousmDb.lePrujtan.otneroenl.bsvintgcrotk"

    const/4 v8, 0x1

    const-string v5, "rPootbsm.DnKjetr..obcirelunnsakivintobg.leet"

    const-string v5, "kotlin.coroutines.jvm.internal.DebugProbesKt"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-eqz v4, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    goto :goto_1

    :cond_0
    const/4 v7, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-gez v3, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    goto :goto_1

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    move v1, v3

    move v1, v3

    const/4 v8, 0x7

    move v1, v3

    move v1, v3

    const/4 v7, 0x1

    const/4 v8, 0x2

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x6

    sget-boolean v1, Lkotlinx/coroutines/debug/internal/g;->i:Z

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string/jumbo v3, "tranutuetooic Csrotk enparica"

    const-string v3, "oucCrtoparie sokiracttannce t"

    const/4 v8, 0x6

    const-string v3, "cse uirpnoratnooeccCttaatk er"

    const-string v3, "Coroutine creation stacktrace"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-nez v1, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    sub-int/2addr v0, v2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    new-instance v1, Ljava/util/ArrayList;

    const/4 v8, 0x4

    const/4 v7, 0x6

    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v4, 0x0

    :goto_2
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-ge v4, v0, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-nez v4, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x4

    invoke-static {v3}, Lkotlinx/coroutines/internal/q0;->d(Ljava/lang/String;)Ljava/lang/StackTraceElement;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_3

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    add-int v5, v4, v2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    aget-object v5, p1, v5

    :goto_3
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    goto :goto_2

    :cond_4
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    return-object v1

    :cond_5
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    new-instance v1, Ljava/util/ArrayList;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    sub-int v4, v0, v2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-direct {v1, v4}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v8, 0x5

    invoke-static {v3}, Lkotlinx/coroutines/internal/q0;->d(Ljava/lang/String;)Ljava/lang/StackTraceElement;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-interface {v1, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :goto_4
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    add-int/lit8 v2, v2, 0x1

    :goto_5
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-ge v2, v0, :cond_a

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    aget-object v3, p1, v2

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-direct {p0, v3}, Lkotlinx/coroutines/debug/internal/g;->A(Ljava/lang/StackTraceElement;)Z

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v3, :cond_9

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    aget-object v3, p1, v2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-interface {v1, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    add-int/lit8 v3, v2, 0x1

    :goto_6
    const/4 v8, 0x0

    if-ge v3, v0, :cond_6

    const/4 v8, 0x4

    aget-object v4, p1, v3

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {p0, v4}, Lkotlinx/coroutines/debug/internal/g;->A(Ljava/lang/StackTraceElement;)Z

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-eqz v4, :cond_6

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    goto :goto_6

    :cond_6
    const/4 v8, 0x1

    const/4 v7, 0x4

    add-int/lit8 v4, v3, -0x1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    move v5, v4

    move v5, v4

    const/4 v8, 0x2

    move v5, v4

    move v5, v4

    :goto_7
    const/4 v8, 0x7

    if-le v5, v2, :cond_7

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    aget-object v6, p1, v5

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v6}, Ljava/lang/StackTraceElement;->getFileName()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x5

    const/4 v7, 0x0

    if-nez v6, :cond_7

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    add-int/lit8 v5, v5, -0x1

    const/4 v7, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto :goto_7

    :cond_7
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-le v5, v2, :cond_8

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-ge v5, v4, :cond_8

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    aget-object v2, p1, v5

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-interface {v1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_8
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    aget-object v2, p1, v4

    const/4 v8, 0x5

    const/4 v7, 0x1

    invoke-interface {v1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x6

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    goto/16 :goto_5

    :cond_9
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    aget-object v3, p1, v2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-interface {v1, v3}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    goto/16 :goto_4

    :cond_a
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    return-object v1
.end method

.method private final M()V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    const/4 v1, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/4 v2, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string v3, "rC eCrlqq ouegnusigenoerbtD"

    const-string v3, "s rgnbilqCuuDroeeeeCt ngoer"

    const/4 v9, 0x7

    const-string v3, "goser roenbtusu CCDeaielrge"

    const-string v3, "Coroutines Debugger Cleaner"

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    const/4 v4, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    sget-object v5, Lkotlinx/coroutines/debug/internal/g$h;->a:Lkotlinx/coroutines/debug/internal/g$h;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/16 v6, 0x15

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    const/4 v7, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v0 .. v7}, Lkotlin/concurrent/b;->c(ZZLjava/lang/ClassLoader;Ljava/lang/String;ILi8/a;ILjava/lang/Object;)Ljava/lang/Thread;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    sput-object v0, Lkotlinx/coroutines/debug/internal/g;->d:Ljava/lang/Thread;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    return-void
.end method

.method private final N()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->d:Ljava/lang/Thread;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    sput-object v1, Lkotlinx/coroutines/debug/internal/g;->d:Ljava/lang/Thread;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/Thread;->join()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method private final O(Ljava/util/List;)Lkotlinx/coroutines/debug/internal/m;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;)",
            "Lkotlinx/coroutines/debug/internal/m;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x0

    and-int/2addr v4, v1

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {p1, v0}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    move-result-object p1

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/ListIterator;->hasPrevious()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v0, Ljava/lang/StackTraceElement;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v2, Lkotlinx/coroutines/debug/internal/m;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {v2, v1, v0}, Lkotlinx/coroutines/debug/internal/m;-><init>(Lkotlin/coroutines/jvm/internal/e;Ljava/lang/StackTraceElement;)V

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    return-object v1
.end method

.method private final P(Ljava/lang/Object;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/16 v1, 0x22

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p1
.end method

.method private final R(Lkotlin/coroutines/jvm/internal/e;Ljava/lang/String;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget-object v1, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v1}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-nez v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-void

    :cond_0
    :try_start_1
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    sget-object v2, Lkotlinx/coroutines/debug/internal/g;->l:Lkotlinx/coroutines/debug/internal/b;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v2, p1}, Lkotlinx/coroutines/debug/internal/b;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    check-cast v3, Lkotlinx/coroutines/debug/internal/e;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v3, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x6

    move v6, v5

    invoke-direct {v1, p1}, Lkotlinx/coroutines/debug/internal/g;->C(Lkotlin/coroutines/jvm/internal/e;)Lkotlinx/coroutines/debug/internal/g$a;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v3, :cond_6

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v3, v3, Lkotlinx/coroutines/debug/internal/g$a;->b:Lkotlinx/coroutines/debug/internal/e;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez v3, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_2

    :cond_2
    const/4 v6, 0x1

    invoke-virtual {v3}, Lkotlinx/coroutines/debug/internal/e;->f()Lkotlin/coroutines/jvm/internal/e;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v4, :cond_3

    const/4 v6, 0x7

    invoke-direct {v1, v4}, Lkotlinx/coroutines/debug/internal/g;->I(Lkotlin/coroutines/jvm/internal/e;)Lkotlin/coroutines/jvm/internal/e;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_0

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v4, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v4, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v2, v4}, Lkotlinx/coroutines/debug/internal/b;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_4
    :goto_1
    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    check-cast v4, Lkotlin/coroutines/d;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v3, p2, v4}, Lkotlinx/coroutines/debug/internal/e;->j(Ljava/lang/String;Lkotlin/coroutines/d;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v1, p1}, Lkotlinx/coroutines/debug/internal/g;->I(Lkotlin/coroutines/jvm/internal/e;)Lkotlin/coroutines/jvm/internal/e;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-nez p1, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    return-void

    :cond_5
    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v2, p1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v6, 0x2

    return-void

    :cond_6
    :goto_2
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v5, 0x5

    move v6, v5

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    throw p1
.end method

.method private final S(Lkotlin/coroutines/d;Ljava/lang/String;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "*>;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x2

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const-string v0, "INNmsRN"

    const-string v0, "IRsUNNN"

    const-string v0, "RUNNING"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v0, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget-object v0, Lkotlin/a0;->g:Lkotlin/a0;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v1, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/16 v2, 0x1e

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, v3, v1, v2}, Lkotlin/a0;->f(III)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    instance-of v0, p1, Lkotlin/coroutines/jvm/internal/e;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    check-cast p1, Lkotlin/coroutines/jvm/internal/e;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v5, 0x7

    if-nez p1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-void

    :cond_2
    const/4 v4, 0x5

    move v5, v4

    invoke-direct {p0, p1, p2}, Lkotlinx/coroutines/debug/internal/g;->R(Lkotlin/coroutines/jvm/internal/e;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-void

    :cond_3
    const/4 v5, 0x3

    invoke-direct {p0, p1}, Lkotlinx/coroutines/debug/internal/g;->B(Lkotlin/coroutines/d;)Lkotlinx/coroutines/debug/internal/g$a;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez v0, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x0

    return-void

    :cond_4
    const/4 v5, 0x3

    invoke-direct {p0, v0, p1, p2}, Lkotlinx/coroutines/debug/internal/g;->T(Lkotlinx/coroutines/debug/internal/g$a;Lkotlin/coroutines/d;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-void
.end method

.method private final T(Lkotlinx/coroutines/debug/internal/g$a;Lkotlin/coroutines/d;Ljava/lang/String;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/debug/internal/g$a<",
            "*>;",
            "Lkotlin/coroutines/d<",
            "*>;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    :try_start_0
    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v1, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v3, 0x2

    invoke-virtual {v1}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v2, 0x7

    move v3, v2

    return-void

    :cond_0
    :try_start_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object p1, p1, Lkotlinx/coroutines/debug/internal/g$a;->b:Lkotlinx/coroutines/debug/internal/e;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1, p3, p2}, Lkotlinx/coroutines/debug/internal/e;->j(Ljava/lang/String;Lkotlin/coroutines/d;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v2, 0x5

    or-int/2addr v3, v2

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    throw p1
.end method

.method public static final synthetic a()Lkotlinx/coroutines/debug/internal/b;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->l:Lkotlinx/coroutines/debug/internal/b;

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public static final synthetic b(Lkotlinx/coroutines/debug/internal/g;Lkotlinx/coroutines/debug/internal/g$a;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lkotlinx/coroutines/debug/internal/g;->y(Lkotlinx/coroutines/debug/internal/g$a;)Z

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p0
.end method

.method public static final synthetic c(Lkotlinx/coroutines/debug/internal/g;Lkotlinx/coroutines/debug/internal/g$a;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lkotlinx/coroutines/debug/internal/g;->E(Lkotlinx/coroutines/debug/internal/g$a;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method private final d(Lkotlinx/coroutines/n2;Ljava/util/Map;Ljava/lang/StringBuilder;Ljava/lang/String;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/n2;",
            "Ljava/util/Map<",
            "Lkotlinx/coroutines/n2;",
            "Lkotlinx/coroutines/debug/internal/e;",
            ">;",
            "Ljava/lang/StringBuilder;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    check-cast v0, Lkotlinx/coroutines/debug/internal/e;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/16 v1, 0x9

    const/16 v2, 0xa

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-nez v0, :cond_0

    const/4 v7, 0x3

    instance-of v0, p1, Lkotlinx/coroutines/internal/n0;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-nez v0, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct {p0, p1}, Lkotlinx/coroutines/debug/internal/g;->r(Lkotlinx/coroutines/n2;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p4

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto/16 :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v0}, Lkotlinx/coroutines/debug/internal/e;->h()Ljava/util/List;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v3}, Lkotlin/collections/u;->D2(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    check-cast v3, Ljava/lang/StackTraceElement;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0}, Lkotlinx/coroutines/debug/internal/e;->g()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v4, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-direct {p0, p1}, Lkotlinx/coroutines/debug/internal/g;->r(Lkotlinx/coroutines/n2;)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string v5, " niio uto notm,acs"

    const-string v5, " t,mntnsoao i cuni"

    const/4 v7, 0x6

    const-string v5, "nutonb noii csit ,"

    const-string v5, ", continuation is "

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string v0, " nalo uit"

    const-string v0, "   noailt"

    const/4 v7, 0x7

    const-string v0, "et ln ip "

    const-string v0, " at line "

    const/4 v7, 0x0

    const/4 v6, 0x3

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p4

    :cond_1
    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-interface {p1}, Lkotlinx/coroutines/n2;->getChildren()Lkotlin/sequences/m;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {p1}, Lkotlin/sequences/m;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz v0, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    check-cast v0, Lkotlinx/coroutines/n2;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {p0, v0, p2, p3, p4}, Lkotlinx/coroutines/debug/internal/g;->d(Lkotlinx/coroutines/n2;Ljava/util/Map;Ljava/lang/StringBuilder;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    goto :goto_1

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-void
.end method

.method private final e(Lkotlin/coroutines/d;Lkotlinx/coroutines/debug/internal/m;)Lkotlin/coroutines/d;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlin/coroutines/d<",
            "-TT;>;",
            "Lkotlinx/coroutines/debug/internal/m;",
            ")",
            "Lkotlin/coroutines/d<",
            "TT;>;"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    return-object p1

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    new-instance v0, Lkotlinx/coroutines/debug/internal/e;

    const/4 v5, 0x7

    invoke-interface {p1}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget-object v2, Lkotlinx/coroutines/debug/internal/g;->g:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget-object v3, Lkotlinx/coroutines/debug/internal/g;->f:Lkotlinx/coroutines/debug/internal/h;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;->incrementAndGet(Ljava/lang/Object;)J

    move-result-wide v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {v0, v1, p2, v2, v3}, Lkotlinx/coroutines/debug/internal/e;-><init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/debug/internal/m;J)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v1, Lkotlinx/coroutines/debug/internal/g$a;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v1, p1, v0, p2}, Lkotlinx/coroutines/debug/internal/g$a;-><init>(Lkotlin/coroutines/d;Lkotlinx/coroutines/debug/internal/e;Lkotlin/coroutines/jvm/internal/e;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget-object p1, Lkotlinx/coroutines/debug/internal/g;->e:Lkotlinx/coroutines/debug/internal/b;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-interface {p1, v1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {p0}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result p2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez p2, :cond_1

    const/4 v5, 0x7

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/b;->clear()V

    :cond_1
    const/4 v4, 0x3

    const/4 v5, 0x7

    return-object v1
.end method

.method private final i(Li8/p;)Ljava/util/List;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/debug/internal/g$a<",
            "*>;-",
            "Lkotlin/coroutines/g;",
            "+TR;>;)",
            "Ljava/util/List<",
            "TR;>;"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    const/4 v8, 0x5

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getWriteHoldCount()I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 v3, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-nez v2, :cond_0

    const/4 v8, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getReadHoldCount()I

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    :goto_0
    const/4 v8, 0x0

    move v4, v3

    move v4, v3

    const/4 v8, 0x7

    move v4, v3

    move v4, v3

    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    if-ge v4, v2, :cond_1

    const/4 v7, 0x4

    move v8, v7

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v8, 0x4

    const/4 v7, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    goto :goto_1

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/4 v4, 0x1

    :try_start_0
    const/4 v7, 0x1

    const/4 v8, 0x7

    sget-object v5, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v8, 0x1

    const/4 v7, 0x4

    invoke-virtual {v5}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result v6

    const/4 v8, 0x3

    const/4 v7, 0x4

    if-eqz v6, :cond_3

    const/4 v8, 0x4

    invoke-direct {v5}, Lkotlinx/coroutines/debug/internal/g;->q()Ljava/util/Set;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x5

    check-cast v5, Ljava/lang/Iterable;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v5}, Lkotlin/collections/u;->x1(Ljava/lang/Iterable;)Lkotlin/sequences/m;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance v6, Lkotlinx/coroutines/debug/internal/g$d;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {v6}, Lkotlinx/coroutines/debug/internal/g$d;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v5, v6}, Lkotlin/sequences/p;->K2(Lkotlin/sequences/m;Ljava/util/Comparator;)Lkotlin/sequences/m;

    move-result-object v5

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-instance v6, Lkotlinx/coroutines/debug/internal/g$c;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-direct {v6, p1}, Lkotlinx/coroutines/debug/internal/g$c;-><init>(Li8/p;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {v5, v6}, Lkotlin/sequences/p;->p1(Lkotlin/sequences/m;Li8/l;)Lkotlin/sequences/m;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {p1}, Lkotlin/sequences/p;->c3(Lkotlin/sequences/m;)Ljava/util/List;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->d(I)V

    :goto_2
    const/4 v8, 0x4

    const/4 v7, 0x1

    if-ge v3, v2, :cond_2

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    goto :goto_2

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    return-object p1

    :cond_3
    :try_start_1
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string p1, "rgntobetqa nelb oDilu a bpeess"

    const-string/jumbo p1, "uasibbDbns ldotlee nre teoag p"

    const/4 v8, 0x0

    const-string/jumbo p1, "ueseoit nsreapbtl  aDnre sdolg"

    const-string p1, "Debug probes are not installed"

    const/4 v8, 0x5

    new-instance v5, Ljava/lang/IllegalStateException;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-direct {v5, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    throw v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->d(I)V

    :goto_3
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-ge v3, v2, :cond_4

    const/4 v7, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    goto :goto_3

    :cond_4
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    throw p1
.end method

.method private final j(Ljava/io/PrintStream;)V
    .locals 14

    const/4 v13, 0x4

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    const/4 v13, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v1

    const/4 v13, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getWriteHoldCount()I

    move-result v2

    const/4 v13, 0x4

    const/4 v3, 0x0

    const/4 v13, 0x0

    if-nez v2, :cond_0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getReadHoldCount()I

    move-result v2

    const/4 v13, 0x3

    goto :goto_0

    :cond_0
    const/4 v13, 0x2

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    :goto_0
    move v4, v3

    move v4, v3

    move v4, v3

    move v4, v3

    :goto_1
    const/4 v13, 0x6

    if-ge v4, v2, :cond_1

    const/4 v13, 0x4

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    add-int/lit8 v4, v4, 0x1

    const/4 v13, 0x2

    goto :goto_1

    :cond_1
    const/4 v13, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v0

    const/4 v13, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    :try_start_0
    sget-object v4, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v13, 0x6

    invoke-virtual {v4}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result v5

    const/4 v13, 0x7

    if-eqz v5, :cond_6

    const/4 v13, 0x6

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x4

    const-string v6, " t mproionmeusuC"

    const-string v6, "ernu puouimt sCo"

    const-string/jumbo v6, "utdmosoCeunio p "

    const-string v6, "Coroutines dump "

    const/4 v13, 0x3

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    sget-object v6, Lkotlinx/coroutines/debug/internal/g;->c:Ljava/text/SimpleDateFormat;

    const/4 v13, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    const/4 v13, 0x4

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    const/4 v13, 0x3

    invoke-virtual {v6, v7}, Ljava/text/Format;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    const/4 v13, 0x7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x7

    invoke-virtual {p1, v5}, Ljava/io/PrintStream;->print(Ljava/lang/String;)V

    invoke-direct {v4}, Lkotlinx/coroutines/debug/internal/g;->q()Ljava/util/Set;

    move-result-object v4

    const/4 v13, 0x6

    check-cast v4, Ljava/lang/Iterable;

    invoke-static {v4}, Lkotlin/collections/u;->x1(Ljava/lang/Iterable;)Lkotlin/sequences/m;

    move-result-object v4

    const/4 v13, 0x7

    sget-object v5, Lkotlinx/coroutines/debug/internal/g$e;->a:Lkotlinx/coroutines/debug/internal/g$e;

    const/4 v13, 0x2

    invoke-static {v4, v5}, Lkotlin/sequences/p;->p0(Lkotlin/sequences/m;Li8/l;)Lkotlin/sequences/m;

    move-result-object v4

    const/4 v13, 0x5

    new-instance v5, Lkotlinx/coroutines/debug/internal/g$f;

    const/4 v13, 0x1

    invoke-direct {v5}, Lkotlinx/coroutines/debug/internal/g$f;-><init>()V

    const/4 v13, 0x0

    invoke-static {v4, v5}, Lkotlin/sequences/p;->K2(Lkotlin/sequences/m;Ljava/util/Comparator;)Lkotlin/sequences/m;

    move-result-object v4

    const/4 v13, 0x2

    invoke-interface {v4}, Lkotlin/sequences/m;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_2
    const/4 v13, 0x3

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v13, 0x2

    if-eqz v5, :cond_4

    const/4 v13, 0x3

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v13, 0x1

    check-cast v5, Lkotlinx/coroutines/debug/internal/g$a;

    const/4 v13, 0x4

    iget-object v6, v5, Lkotlinx/coroutines/debug/internal/g$a;->b:Lkotlinx/coroutines/debug/internal/e;

    const/4 v13, 0x7

    invoke-virtual {v6}, Lkotlinx/coroutines/debug/internal/e;->h()Ljava/util/List;

    move-result-object v7

    const/4 v13, 0x4

    sget-object v8, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v13, 0x6

    invoke-virtual {v6}, Lkotlinx/coroutines/debug/internal/e;->g()Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x4

    iget-object v10, v6, Lkotlinx/coroutines/debug/internal/e;->e:Ljava/lang/Thread;

    const/4 v13, 0x7

    invoke-direct {v8, v9, v10, v7}, Lkotlinx/coroutines/debug/internal/g;->n(Ljava/lang/String;Ljava/lang/Thread;Ljava/util/List;)Ljava/util/List;

    move-result-object v9

    const/4 v13, 0x0

    invoke-virtual {v6}, Lkotlinx/coroutines/debug/internal/e;->g()Ljava/lang/String;

    move-result-object v10

    const/4 v13, 0x4

    const-string v11, "NUGINbp"

    const-string v11, "pINRNUG"

    const-string v11, "RUNNING"

    const/4 v13, 0x7

    invoke-static {v10, v11}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    const/4 v13, 0x7

    if-eqz v10, :cond_2

    const/4 v13, 0x2

    if-ne v9, v7, :cond_2

    const/4 v13, 0x2

    new-instance v10, Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x0

    invoke-virtual {v6}, Lkotlinx/coroutines/debug/internal/e;->g()Ljava/lang/String;

    move-result-object v11

    const/4 v13, 0x1

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const-string v11, " tncqtuacsuk )tas ( olasu,nasprLitaetoatnk caacteercs s"

    const-string v11, "susan)r qaatncs cson artct iutsctt(eesap,ae Lko  clakat"

    const-string v11, "aisatsepcc ao,taatcnranLea  oktcrsclu n(a)p ets kt sunt"

    const-string v11, " (Last suspension stacktrace, not an actual stacktrace)"

    const/4 v13, 0x0

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    const/4 v13, 0x5

    goto :goto_3

    :cond_2
    const/4 v13, 0x7

    invoke-virtual {v6}, Lkotlinx/coroutines/debug/internal/e;->g()Ljava/lang/String;

    move-result-object v10

    :goto_3
    const/4 v13, 0x0

    new-instance v11, Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x1

    const-string v12, "noto/nirq/esCu"

    const-string v12, "insnnC/uo/rtoe"

    const-string/jumbo v12, "uisenoto nCr//"

    const-string v12, "\n\nCoroutine "

    const/4 v13, 0x5

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    iget-object v5, v5, Lkotlinx/coroutines/debug/internal/g$a;->a:Lkotlin/coroutines/d;

    const/4 v13, 0x0

    invoke-virtual {v11, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const-string v5, " tams, :m"

    const-string v5, ": smt at,"

    const-string v5, ":,stoaet "

    const-string v5, ", state: "

    const/4 v13, 0x2

    invoke-virtual {v11, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x2

    invoke-virtual {p1, v5}, Ljava/io/PrintStream;->print(Ljava/lang/String;)V

    const/4 v13, 0x6

    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v5

    const/4 v13, 0x1

    if-eqz v5, :cond_3

    const/4 v13, 0x0

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x2

    const-string v7, "on ttba"

    const-string v7, " t/nota"

    const-string v7, "t/ n/tu"

    const-string v7, "\n\tat "

    const/4 v13, 0x1

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const-string/jumbo v7, "uriCaceptotrcbttarneinok oase"

    const-string v7, "oeatkbacoeCucrttsorntneraici "

    const-string v7, "rcck rneqnacsreaooiatCtie tot"

    const-string v7, "Coroutine creation stacktrace"

    const/4 v13, 0x2

    invoke-static {v7}, Lkotlinx/coroutines/internal/q0;->d(Ljava/lang/String;)Ljava/lang/StackTraceElement;

    move-result-object v7

    const/4 v13, 0x6

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x0

    invoke-virtual {p1, v5}, Ljava/io/PrintStream;->print(Ljava/lang/String;)V

    const/4 v13, 0x1

    invoke-virtual {v6}, Lkotlinx/coroutines/debug/internal/e;->e()Ljava/util/List;

    move-result-object v5

    const/4 v13, 0x1

    invoke-direct {v8, p1, v5}, Lkotlinx/coroutines/debug/internal/g;->D(Ljava/io/PrintStream;Ljava/util/List;)V

    const/4 v13, 0x3

    goto/16 :goto_2

    :cond_3
    const/4 v13, 0x4

    invoke-direct {v8, p1, v9}, Lkotlinx/coroutines/debug/internal/g;->D(Ljava/io/PrintStream;Ljava/util/List;)V

    const/4 v13, 0x3

    goto/16 :goto_2

    :cond_4
    const/4 v13, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_4
    const/4 v13, 0x0

    if-ge v3, v2, :cond_5

    const/4 v13, 0x4

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v13, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v13, 0x7

    goto :goto_4

    :cond_5
    const/4 v13, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v13, 0x6

    return-void

    :cond_6
    :try_start_1
    const-string p1, "possbtlrselroea niue a t genbd"

    const-string p1, "ntsopsulg  eeanbd eaerrob iDlt"

    const-string p1, " bsmpsolnDloerbedg iauetrnta  "

    const-string p1, "Debug probes are not installed"

    const/4 v13, 0x5

    new-instance v4, Ljava/lang/IllegalStateException;

    const/4 v13, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v13, 0x3

    invoke-direct {v4, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x1

    throw v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    :goto_5
    const/4 v13, 0x2

    if-ge v3, v2, :cond_7

    const/4 v13, 0x5

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v13, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v13, 0x4

    goto :goto_5

    :cond_7
    const/4 v13, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    throw p1
.end method

.method private final n(Ljava/lang/String;Ljava/lang/Thread;Ljava/util/List;)Ljava/util/List;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/Thread;",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;)",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-string v0, "pNURNNI"

    const/4 v8, 0x2

    const-string v0, "NUNGoNR"

    const-string v0, "RUNNING"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v8, 0x1

    const/4 v7, 0x5

    if-eqz p1, :cond_9

    const/4 v8, 0x0

    if-nez p2, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    goto/16 :goto_6

    :cond_0
    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    sget-object p1, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {p2}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {p1}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    sget-object p2, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {p1}, Lkotlin/e1;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-static {p1}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {p1}, Lkotlin/d1;->i(Ljava/lang/Object;)Z

    move-result p2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-eqz p2, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 p1, 0x0

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    check-cast p1, [Ljava/lang/StackTraceElement;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-nez p1, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    return-object p3

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x1

    array-length p2, p1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/4 v0, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    move v1, v0

    move v1, v0

    const/4 v8, 0x7

    move v1, v0

    move v1, v0

    :goto_1
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v2, -0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-ge v1, p2, :cond_5

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    aget-object v4, p1, v1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string v6, "nnqutbvmIjiotksaunCnaioclioeilitpooel.t.rrnem.sn.Bn"

    const-string v6, "nnltmasoqnv.t.nkmjtt..IuncooiaretelionirepiBCsoliun"

    const/4 v8, 0x6

    const-string v6, "ioasmCuut.nc.spoimntiioniarrenjelol.ItltBoetakvnnu."

    const-string v6, "kotlin.coroutines.jvm.internal.BaseContinuationImpl"

    const/4 v8, 0x4

    invoke-static {v5, v6}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eqz v5, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->getMethodName()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string/jumbo v6, "tiesWusphm"

    const-string v6, "sisWeurhmt"

    const/4 v8, 0x0

    const-string v6, "emteiursqh"

    const-string v6, "resumeWith"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {v5, v6}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-eqz v5, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->getFileName()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v5, ".lstiIamnotikuCtomn"

    const-string v5, "Cunm.mtaotkointlnIi"

    const/4 v8, 0x2

    const-string v5, "aCmmtlintuti.nnpoko"

    const-string v5, "ContinuationImpl.kt"

    const/4 v7, 0x6

    xor-int/2addr v8, v7

    invoke-static {v4, v5}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-eqz v4, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    move v4, v3

    move v4, v3

    move v4, v3

    move v4, v3

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    goto :goto_2

    :cond_3
    const/4 v7, 0x0

    move v8, v7

    move v4, v0

    const/4 v8, 0x7

    move v4, v0

    move v4, v0

    :goto_2
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eqz v4, :cond_4

    const/4 v8, 0x4

    goto :goto_3

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto/16 :goto_1

    :cond_5
    const/4 v7, 0x5

    move v8, v7

    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    :goto_3
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {p0, v1, p1, p3}, Lkotlinx/coroutines/debug/internal/g;->o(I[Ljava/lang/StackTraceElement;Ljava/util/List;)Lkotlin/u0;

    move-result-object p2

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p2}, Lkotlin/u0;->a()Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    check-cast v4, Ljava/lang/Number;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p2}, Lkotlin/u0;->b()Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    check-cast p2, Ljava/lang/Number;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-ne v4, v2, :cond_6

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    return-object p3

    :cond_6
    const/4 v8, 0x3

    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    add-int/2addr v2, v1

    const/4 v8, 0x2

    sub-int/2addr v2, v4

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    sub-int/2addr v2, v3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    sub-int/2addr v2, p2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    new-instance v5, Ljava/util/ArrayList;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-direct {v5, v2}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    sub-int/2addr v1, p2

    :goto_4
    const/4 v8, 0x0

    if-ge v0, v1, :cond_7

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    aget-object p2, p1, v0

    const/4 v8, 0x7

    const/4 v7, 0x7

    invoke-interface {v5, p2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    goto :goto_4

    :cond_7
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    add-int/2addr v4, v3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-interface {p3}, Ljava/util/List;->size()I

    move-result p1

    :goto_5
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-ge v4, p1, :cond_8

    const/4 v8, 0x5

    invoke-interface {p3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {v5, p2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    goto :goto_5

    :cond_8
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    return-object v5

    :cond_9
    :goto_6
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-object p3
.end method

.method private final o(I[Ljava/lang/StackTraceElement;Ljava/util/List;)Lkotlin/u0;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[",
            "Ljava/lang/StackTraceElement;",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;)",
            "Lkotlin/u0<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    move v1, v0

    move v1, v0

    const/4 v6, 0x0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v2, -0x1

    const/4 v3, 0x3

    xor-int/2addr v6, v3

    move v5, v3

    move v5, v3

    const/4 v6, 0x4

    if-ge v1, v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x3

    sget-object v3, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    add-int/lit8 v4, p1, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    sub-int/2addr v4, v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-direct {v3, v4, p2, p3}, Lkotlinx/coroutines/debug/internal/g;->p(I[Ljava/lang/StackTraceElement;Ljava/util/List;)I

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eq v3, v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p1, p2}, Lkotlin/q1;->a(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/u0;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-object p1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {p1, p2}, Lkotlin/q1;->a(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/u0;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-object p1
.end method

.method private final p(I[Ljava/lang/StackTraceElement;Ljava/util/List;)I
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[",
            "Ljava/lang/StackTraceElement;",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;)I"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {p2, p1}, Lkotlin/collections/l;->Pe([Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    check-cast p1, Ljava/lang/StackTraceElement;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 p2, -0x1

    const/4 v6, 0x6

    if-nez p1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    return p2

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {p3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    move v1, v0

    move v1, v0

    const/4 v6, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v6, 0x0

    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x7

    if-eqz v2, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    check-cast v2, Ljava/lang/StackTraceElement;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/lang/StackTraceElement;->getFileName()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/lang/StackTraceElement;->getFileName()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v3, v4}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v3, :cond_1

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz v3, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/lang/StackTraceElement;->getMethodName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/StackTraceElement;->getMethodName()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v2, v3}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v2, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    move v6, v5

    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    move p2, v1

    move p2, v1

    const/4 v6, 0x7

    move p2, v1

    move p2, v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    goto :goto_2

    :cond_2
    const/4 v6, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_3
    :goto_2
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    return p2
.end method

.method private final q()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Lkotlinx/coroutines/debug/internal/g$a<",
            "*>;>;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->e:Lkotlinx/coroutines/debug/internal/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, Lkotlin/collections/g;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method private final r(Lkotlinx/coroutines/n2;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    instance-of v0, p1, Lkotlinx/coroutines/v2;

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast p1, Lkotlinx/coroutines/v2;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1}, Lkotlinx/coroutines/v2;->Y0()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method private static synthetic s(Lkotlinx/coroutines/n2;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method private final t()Li8/l;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Li8/l<",
            "Ljava/lang/Boolean;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string v0, ".tcBoooDnnyknxedAlicisBdubuttcyolhgeadroetmua.ni.ittaren"

    const-string v0, "c.noogeddictktilxbirdam..eDBstteoaouunaltAiyr.nyhcnntBue"

    const/4 v3, 0x1

    const-string v0, "natiubxnteoeh.uBddis.ryDmtdr.ctktnitinucc.AoeelByaonyglb"

    const-string v0, "kotlinx.coroutines.debug.internal.ByteBuddyDynamicAttach"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/Class;->getConstructors()[Ljava/lang/reflect/Constructor;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    move v3, v2

    aget-object v0, v0, v1

    const/4 v2, 0x5

    move v3, v2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lkotlin/jvm/internal/u1;->q(Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Li8/l;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v1, "iln,tcueFlnU.ntoou l lp tna1neytba atnto.it> Be-kobcnik uicnt.onnlkto  lolnus<loni"

    const-string/jumbo v1, "ulniobnnlontFkn nln<tcnUn il stuleki iiBepyk>c,t . aoolonnnlt notu.oat boe1.tcatl-"

    const/4 v3, 0x4

    const-string v1, "pnttiBnp.loonato oul t o1e,nco.lyksoUFita>tn ilneke< iciln-.obt ntankncl  otuunlnl"

    const-string v1, "null cannot be cast to non-null type kotlin.Function1<kotlin.Boolean, kotlin.Unit>"

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v1, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0}, Lkotlin/e1;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-static {v0}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0}, Lkotlin/d1;->i(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast v0, Li8/l;

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0
.end method

.method private final y(Lkotlinx/coroutines/debug/internal/g$a;)Z
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/debug/internal/g$a<",
            "*>;)Z"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p1, Lkotlinx/coroutines/debug/internal/g$a;->b:Lkotlinx/coroutines/debug/internal/e;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0}, Lkotlinx/coroutines/debug/internal/e;->c()Lkotlin/coroutines/g;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget-object v2, Lkotlinx/coroutines/n2;->n0:Lkotlinx/coroutines/n2$b;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {v0, v2}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    check-cast v0, Lkotlinx/coroutines/n2;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {v0}, Lkotlinx/coroutines/n2;->isCompleted()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    return v1

    :cond_1
    const/4 v4, 0x6

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->e:Lkotlinx/coroutines/debug/internal/b;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/debug/internal/b;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 p1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    return p1

    :cond_2
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    return v1
.end method


# virtual methods
.method public final F(Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 3
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlin/coroutines/d<",
            "-TT;>;)",
            "Lkotlin/coroutines/d<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x4

    return-object p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lkotlinx/coroutines/debug/internal/g;->B(Lkotlin/coroutines/d;)Lkotlinx/coroutines/debug/internal/g$a;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-boolean v0, Lkotlinx/coroutines/debug/internal/g;->j:Z

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x5

    new-instance v0, Ljava/lang/Exception;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lkotlinx/coroutines/debug/internal/g;->J(Ljava/lang/Throwable;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lkotlinx/coroutines/debug/internal/g;->O(Ljava/util/List;)Lkotlinx/coroutines/debug/internal/m;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x3

    move v2, v1

    invoke-direct {p0, p1, v0}, Lkotlinx/coroutines/debug/internal/g;->e(Lkotlin/coroutines/d;Lkotlinx/coroutines/debug/internal/m;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p1
.end method

.method public final G(Lkotlin/coroutines/d;)V
    .locals 3
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "*>;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string v0, "NqRuGIN"

    const-string v0, "IUGNRNu"

    const/4 v2, 0x1

    const-string v0, "IUsGNNN"

    const-string v0, "RUNNING"

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lkotlinx/coroutines/debug/internal/g;->S(Lkotlin/coroutines/d;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public final H(Lkotlin/coroutines/d;)V
    .locals 3
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "*>;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, "ENPmDEpUD"

    const-string v0, "UDEDPSEpN"

    const/4 v2, 0x1

    const-string v0, "EPUSoNDDS"

    const-string v0, "SUSPENDED"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0}, Lkotlinx/coroutines/debug/internal/g;->S(Lkotlin/coroutines/d;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public final K(Z)V
    .locals 2

    const/4 v1, 0x1

    sput-boolean p1, Lkotlinx/coroutines/debug/internal/g;->j:Z

    const/4 v0, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public final L(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    sput-boolean p1, Lkotlinx/coroutines/debug/internal/g;->i:Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public final Q()V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getWriteHoldCount()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/4 v3, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-nez v2, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getReadHoldCount()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    move v2, v3

    move v2, v3

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x7

    move v4, v3

    move v4, v3

    const/4 v7, 0x5

    move v4, v3

    move v4, v3

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-ge v4, v2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_1

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    sget-object v4, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v4}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v5, :cond_8

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    sget v5, Lkotlinx/coroutines/debug/internal/g;->installations:I

    const/4 v6, 0x6

    shl-int/2addr v7, v6

    add-int/lit8 v5, v5, -0x1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    sput v5, Lkotlinx/coroutines/debug/internal/g;->installations:I

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    sget v5, Lkotlinx/coroutines/debug/internal/g;->installations:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x4

    if-eqz v5, :cond_3

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-ge v3, v2, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v6, 0x7

    xor-int/2addr v7, v6

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    goto :goto_2

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    return-void

    :cond_3
    :try_start_1
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {v4}, Lkotlinx/coroutines/debug/internal/g;->N()V

    const/4 v7, 0x6

    sget-object v4, Lkotlinx/coroutines/debug/internal/g;->e:Lkotlinx/coroutines/debug/internal/b;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v4}, Lkotlinx/coroutines/debug/internal/b;->clear()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    sget-object v4, Lkotlinx/coroutines/debug/internal/g;->l:Lkotlinx/coroutines/debug/internal/b;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v4}, Lkotlinx/coroutines/debug/internal/b;->clear()V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    sget-object v4, Lkotlinx/coroutines/debug/internal/a;->a:Lkotlinx/coroutines/debug/internal/a;

    const/4 v7, 0x6

    const/4 v6, 0x6

    invoke-virtual {v4}, Lkotlinx/coroutines/debug/internal/a;->a()Z

    move-result v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz v4, :cond_5

    :goto_3
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-ge v3, v2, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x5

    move v7, v6

    goto :goto_3

    :cond_4
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-void

    :cond_5
    :try_start_2
    const/4 v7, 0x6

    const/4 v6, 0x7

    sget-object v4, Lkotlinx/coroutines/debug/internal/g;->k:Li8/l;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v4, :cond_6

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-interface {v4, v5}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_6
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    sget-object v4, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_4
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-ge v3, v2, :cond_7

    const/4 v6, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v7, 0x1

    const/4 v6, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x2

    goto :goto_4

    :cond_7
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-void

    :cond_8
    :try_start_3
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string v4, "s etwbdnAlogislta naq t"

    const-string v4, "lltie Asqsado wetnng at"

    const/4 v7, 0x4

    const-string v4, "negttlulw asaA tisden n"

    const-string v4, "Agent was not installed"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    new-instance v5, Ljava/lang/IllegalStateException;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct {v5, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    throw v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catchall_0
    move-exception v4

    :goto_5
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-ge v3, v2, :cond_9

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_5

    :cond_9
    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    throw v4
.end method

.method public final f(Ljava/io/PrintStream;)V
    .locals 3
    .param p1    # Ljava/io/PrintStream;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    monitor-enter p1

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0, p1}, Lkotlinx/coroutines/debug/internal/g;->j(Ljava/io/PrintStream;)V

    const/4 v2, 0x4

    sget-object v0, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    monitor-exit p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    monitor-exit p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    throw v0
.end method

.method public final g()Ljava/util/List;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lkotlinx/coroutines/debug/internal/d;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getWriteHoldCount()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v3, 0x0

    shr-int/2addr v7, v3

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-nez v2, :cond_0

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getReadHoldCount()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    move v2, v3

    move v2, v3

    const/4 v7, 0x2

    move v2, v3

    move v2, v3

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    move v4, v3

    move v4, v3

    const/4 v7, 0x1

    move v4, v3

    move v4, v3

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-ge v4, v2, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v6, 0x3

    shl-int/2addr v7, v6

    goto :goto_1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    sget-object v4, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v4}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result v5

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v5, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {v4}, Lkotlinx/coroutines/debug/internal/g;->q()Ljava/util/Set;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    check-cast v4, Ljava/lang/Iterable;

    const/4 v7, 0x2

    invoke-static {v4}, Lkotlin/collections/u;->x1(Ljava/lang/Iterable;)Lkotlin/sequences/m;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v5, Lkotlinx/coroutines/debug/internal/g$d;

    const/4 v6, 0x2

    move v7, v6

    invoke-direct {v5}, Lkotlinx/coroutines/debug/internal/g$d;-><init>()V

    const/4 v7, 0x0

    invoke-static {v4, v5}, Lkotlin/sequences/p;->K2(Lkotlin/sequences/m;Ljava/util/Comparator;)Lkotlin/sequences/m;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    new-instance v5, Lkotlinx/coroutines/debug/internal/g$b;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {v5}, Lkotlinx/coroutines/debug/internal/g$b;-><init>()V

    const/4 v7, 0x3

    invoke-static {v4, v5}, Lkotlin/sequences/p;->p1(Lkotlin/sequences/m;Li8/l;)Lkotlin/sequences/m;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {v4}, Lkotlin/sequences/p;->c3(Lkotlin/sequences/m;)Ljava/util/List;

    move-result-object v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_2
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-ge v3, v2, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x3

    goto :goto_2

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    return-object v4

    :cond_3
    :try_start_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string v4, "nl  lbtpr eDatdsnrioepebsgaeo "

    const-string v4, "aesbpa ieeDnosl e tnlordt grub"

    const/4 v7, 0x7

    const-string v4, "pnu lbsoqa  onte tidlaersregbD"

    const-string v4, "Debug probes are not installed"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-instance v5, Ljava/lang/IllegalStateException;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x2

    invoke-direct {v5, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    throw v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception v4

    :goto_3
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-ge v3, v2, :cond_4

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    goto :goto_3

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    throw v4
.end method

.method public final h()[Ljava/lang/Object;
    .locals 15
    .annotation build Lia/d;
    .end annotation

    const/4 v14, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/debug/internal/g;->g()Ljava/util/List;

    move-result-object v0

    const/4 v14, 0x6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v14, 0x5

    new-instance v2, Ljava/util/ArrayList;

    const/4 v14, 0x1

    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v14, 0x0

    new-instance v3, Ljava/util/ArrayList;

    const/4 v14, 0x3

    invoke-direct {v3, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v14, 0x6

    new-instance v4, Ljava/util/ArrayList;

    const/4 v14, 0x0

    invoke-direct {v4, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v14, 0x7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v14, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v14, 0x5

    if-eqz v5, :cond_3

    const/4 v14, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v14, 0x2

    check-cast v5, Lkotlinx/coroutines/debug/internal/d;

    const/4 v14, 0x7

    invoke-virtual {v5}, Lkotlinx/coroutines/debug/internal/d;->a()Lkotlin/coroutines/g;

    move-result-object v6

    const/4 v14, 0x4

    sget-object v7, Lkotlinx/coroutines/t0;->b:Lkotlinx/coroutines/t0$a;

    const/4 v14, 0x5

    invoke-interface {v6, v7}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object v7

    const/4 v14, 0x5

    check-cast v7, Lkotlinx/coroutines/t0;

    const/4 v14, 0x6

    const/4 v8, 0x0

    const/4 v14, 0x0

    if-eqz v7, :cond_0

    const/4 v14, 0x1

    invoke-virtual {v7}, Lkotlinx/coroutines/t0;->r0()Ljava/lang/String;

    move-result-object v7

    const/4 v14, 0x3

    if-eqz v7, :cond_0

    const/4 v14, 0x2

    invoke-direct {p0, v7}, Lkotlinx/coroutines/debug/internal/g;->P(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    goto :goto_1

    :cond_0
    move-object v7, v8

    move-object v7, v8

    move-object v7, v8

    move-object v7, v8

    :goto_1
    const/4 v14, 0x0

    sget-object v9, Lkotlinx/coroutines/o0;->a:Lkotlinx/coroutines/o0$a;

    const/4 v14, 0x0

    invoke-interface {v6, v9}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object v9

    const/4 v14, 0x1

    check-cast v9, Lkotlinx/coroutines/o0;

    if-eqz v9, :cond_1

    const/4 v14, 0x3

    invoke-direct {p0, v9}, Lkotlinx/coroutines/debug/internal/g;->P(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    const/4 v14, 0x7

    goto :goto_2

    :cond_1
    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    :goto_2
    const/4 v14, 0x2

    new-instance v10, Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x6

    const-string v11, "  sn     n   e    a //{/mm          /  : /   n     "

    const-string v11, " e/mn        /        m   /  {/  /   n  n  a     /:"

    const-string v11, "   m      a m  :/n/    { /   n  /   e/      /    n "

    const-string v11, "\n                {\n                    \"name\": "

    const/4 v14, 0x7

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x4

    const-string v7, " /  o  : /,/   o   n d    i  / "

    const-string v7, "i   o  /n    /   d  :   / , /  "

    const-string v7, "  d /b   n  /  :    i   /  / / "

    const-string v7, ",\n                    \"id\": "

    const/4 v14, 0x0

    invoke-virtual {v10, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    sget-object v7, Lkotlinx/coroutines/s0;->b:Lkotlinx/coroutines/s0$a;

    const/4 v14, 0x6

    invoke-interface {v6, v7}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object v6

    const/4 v14, 0x1

    check-cast v6, Lkotlinx/coroutines/s0;

    const/4 v14, 0x0

    if-eqz v6, :cond_2

    const/4 v14, 0x1

    invoke-virtual {v6}, Lkotlinx/coroutines/s0;->r0()J

    move-result-wide v6

    const/4 v14, 0x1

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8

    :cond_2
    const/4 v14, 0x4

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const-string v6, " n , au tb/  dcp :hi      /    r   //se"

    const-string v6, ":h//rb pi / s  tna   d    /c    ,    e "

    const-string v6, "   s i pt , /  / h  :  pc /d   n r  /ea"

    const-string v6, ",\n                    \"dispatcher\": "

    const/4 v14, 0x2

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const-string v6, " r s, /eq/e//n  e /  : c  Nm q   u ub eu  n"

    const-string v6, "ne:  nu m cue b   /q ,  //   eues// N   r  "

    const-string v6, "m sr / ,     /e/Nne    q u e s/:  un   b e/"

    const-string v6, ",\n                    \"sequenceNumber\": "

    const/4 v14, 0x0

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    invoke-virtual {v5}, Lkotlinx/coroutines/debug/internal/d;->f()J

    move-result-wide v6

    const/4 v14, 0x1

    invoke-virtual {v10, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const-string v6, "  nm:s/   /tp        / / / ,a  /   /"

    const-string v6, "   /   p/ t   /  /  /     s :a,t/ /n"

    const-string v6, "/  ,o    /  t :n/ t      a //s //  e"

    const-string v6, ",\n                    \"state\": \""

    const/4 v14, 0x2

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    invoke-virtual {v5}, Lkotlinx/coroutines/debug/internal/d;->g()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x1

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const-string v6, "   / b      /  n /    q    }/          n"

    const-string v6, "nn /   }q       /              /   /    "

    const-string v6, "\"\n                } \n                "

    const/4 v14, 0x6

    invoke-virtual {v10, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lkotlin/text/v;->p(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x2

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v14, 0x0

    invoke-virtual {v5}, Lkotlinx/coroutines/debug/internal/d;->d()Lkotlin/coroutines/jvm/internal/e;

    move-result-object v6

    const/4 v14, 0x5

    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v5}, Lkotlinx/coroutines/debug/internal/d;->e()Ljava/lang/Thread;

    move-result-object v5

    const/4 v14, 0x1

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v14, 0x1

    goto/16 :goto_0

    :cond_3
    const/4 v14, 0x0

    const/4 v1, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v14, 0x4

    new-instance v13, Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x6

    const/16 v5, 0x5b

    const/4 v14, 0x0

    invoke-virtual {v13, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v5, 0x0

    const/4 v14, 0x7

    const/4 v6, 0x0

    const/4 v14, 0x1

    const/4 v7, 0x0

    const/4 v14, 0x1

    const/4 v8, 0x0

    const/4 v14, 0x7

    const/4 v9, 0x0

    const/4 v14, 0x5

    const/4 v10, 0x0

    const/4 v14, 0x6

    const/16 v11, 0x3f

    const/4 v14, 0x1

    const/4 v12, 0x0

    const/4 v14, 0x2

    invoke-static/range {v4 .. v12}, Lkotlin/collections/u;->j3(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Li8/l;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const/4 v14, 0x6

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const/16 v4, 0x5d

    const/4 v14, 0x2

    invoke-virtual {v13, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v14, 0x1

    const/4 v5, 0x0

    const/4 v14, 0x7

    aput-object v4, v1, v5

    const/4 v14, 0x2

    new-array v4, v5, [Ljava/lang/Thread;

    const/4 v14, 0x4

    invoke-interface {v2, v4}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v2

    const/4 v14, 0x4

    const-string v4, "fsTboautA _clnTaue>ny.ay K.rrlyatysoiyt_ ktldro ko u saAtrl.aoonrlApinnpnrlJtcrKo roe ostt-Ai.nct<clMesVy net"

    const-string v4, " csATocrM.nno y>lArAsac.or tJuei_ulto_yyne.to   ylnVK koynk.Klirsoss-<naacoenttrrfpAetrbrTlalpyontla itatt ld"

    const-string v4, ".ynoorlpecKlii-AAtsTe an op.Tottckn sJo<r dt.pnlucaAAl n uy_s yMtnot. >atyKfryyrVbt_ialankcsrrlorttoolnral ee"

    const-string v4, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>"

    const/4 v14, 0x2

    if-eqz v2, :cond_6

    const/4 v14, 0x3

    const/4 v6, 0x1

    const/4 v14, 0x6

    aput-object v2, v1, v6

    const/4 v14, 0x2

    new-array v2, v5, [Lkotlin/coroutines/jvm/internal/e;

    invoke-interface {v3, v2}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v2

    const/4 v14, 0x0

    if-eqz v2, :cond_5

    const/4 v3, 0x2

    aput-object v2, v1, v3

    const/4 v14, 0x5

    new-array v2, v5, [Lkotlinx/coroutines/debug/internal/d;

    const/4 v14, 0x2

    invoke-interface {v0, v2}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v14, 0x0

    if-eqz v0, :cond_4

    const/4 v14, 0x4

    const/4 v2, 0x3

    const/4 v14, 0x6

    aput-object v0, v1, v2

    const/4 v14, 0x1

    return-object v1

    :cond_4
    const/4 v14, 0x7

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v14, 0x4

    invoke-direct {v0, v4}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v14, 0x1

    throw v0

    :cond_5
    const/4 v14, 0x1

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v14, 0x1

    invoke-direct {v0, v4}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v14, 0x7

    throw v0

    :cond_6
    const/4 v14, 0x2

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v14, 0x7

    invoke-direct {v0, v4}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v14, 0x0

    throw v0
.end method

.method public final k()Ljava/util/List;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lkotlinx/coroutines/debug/internal/j;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getWriteHoldCount()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v3, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-nez v2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getReadHoldCount()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v7, 0x1

    move v2, v3

    move v2, v3

    const/4 v7, 0x0

    move v2, v3

    move v2, v3

    :goto_0
    const/4 v6, 0x4

    const/4 v7, 0x1

    move v4, v3

    move v4, v3

    const/4 v7, 0x0

    move v4, v3

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-ge v4, v2, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v6, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x6

    goto :goto_1

    :cond_1
    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    sget-object v4, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v4}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result v5

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eqz v5, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-direct {v4}, Lkotlinx/coroutines/debug/internal/g;->q()Ljava/util/Set;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    check-cast v4, Ljava/lang/Iterable;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v4}, Lkotlin/collections/u;->x1(Ljava/lang/Iterable;)Lkotlin/sequences/m;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance v5, Lkotlinx/coroutines/debug/internal/g$d;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {v5}, Lkotlinx/coroutines/debug/internal/g$d;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v4, v5}, Lkotlin/sequences/p;->K2(Lkotlin/sequences/m;Ljava/util/Comparator;)Lkotlin/sequences/m;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    new-instance v5, Lkotlinx/coroutines/debug/internal/g$g;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-direct {v5}, Lkotlinx/coroutines/debug/internal/g$g;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v4, v5}, Lkotlin/sequences/p;->p1(Lkotlin/sequences/m;Li8/l;)Lkotlin/sequences/m;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v4}, Lkotlin/sequences/p;->c3(Lkotlin/sequences/m;)Ljava/util/List;

    move-result-object v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_2
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-ge v3, v2, :cond_2

    const/4 v6, 0x7

    move v7, v6

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v7, 0x6

    const/4 v6, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_2

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    return-object v4

    :cond_3
    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x2

    const-string v4, "enetludtqlorbDisee b  gasrmona"

    const-string v4, "lsdmlsuora inobgrte Dtee  nabe"

    const/4 v7, 0x6

    const-string v4, "oesatlDpd srnrse tboa eng biue"

    const-string v4, "Debug probes are not installed"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v5, Ljava/lang/IllegalStateException;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {v5, v4}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    throw v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception v4

    :goto_3
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-ge v3, v2, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v6, 0x4

    shr-int/2addr v7, v6

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_3

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    throw v4
.end method

.method public final l(Lkotlinx/coroutines/debug/internal/d;Ljava/util/List;)Ljava/util/List;
    .locals 3
    .param p1    # Lkotlinx/coroutines/debug/internal/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/debug/internal/d;",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;)",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/d;->g()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/d;->e()Ljava/lang/Thread;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, v0, p1, p2}, Lkotlinx/coroutines/debug/internal/g;->n(Ljava/lang/String;Ljava/lang/Thread;Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p1
.end method

.method public final m(Lkotlinx/coroutines/debug/internal/d;)Ljava/lang/String;
    .locals 11
    .param p1    # Lkotlinx/coroutines/debug/internal/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/d;->h()Ljava/util/List;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p0, p1, v0}, Lkotlinx/coroutines/debug/internal/g;->l(Lkotlinx/coroutines/debug/internal/d;Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    if-eqz v1, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x6

    check-cast v1, Ljava/lang/StackTraceElement;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    const-string v3, "  /m  /a    /  i / dg    s   o     ln n  Cl /r/  { c/   /ne:as "

    const-string/jumbo v3, "{/C o/i /s / s  g :  na c/ n l  /    an    /    e rl/ d        "

    const-string v3, "inl o / :gsr a   d  l  a   /    / / n /  e  C / {  sn   //     "

    const-string v3, "\n                {\n                    \"declaringClass\": \""

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v1}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    const-string v3, "t :  bn/ //ah e o/N/  / /   m  d  / m/  e, "

    const-string v3, "t :  bn/ //ah e o/N/  / /   m  d  / m/  e, "

    const/4 v10, 0x3

    const-string v3, "/ mt b ao     N  /  e/ h// n  d   //e/, m/:"

    const-string v3, "\",\n                    \"methodName\": \""

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v1}, Ljava/lang/StackTraceElement;->getMethodName()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string v3, "N  //,u  //   a  /m  nf/e   /:  i l e  "

    const/4 v10, 0x6

    const-string v3, " li a u    /Ne   m, /  e / : f  n/ / / "

    const-string v3, "\",\n                    \"fileName\": "

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v1}, Ljava/lang/StackTraceElement;->getFileName()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-eqz v3, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-direct {p0, v3}, Lkotlinx/coroutines/debug/internal/g;->P(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto :goto_1

    :cond_0
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/4 v3, 0x0

    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    const-string v3, " nb/   p  /e   /ir  pNm,:   un  l / e /"

    const-string v3, "rei le p   m /u n:b/ /  n    , N/  /   "

    const/4 v10, 0x6

    const-string v3, " //r    q:    u  N ,/ i   b  e /l /m en"

    const-string v3, ",\n                    \"lineNumber\": "

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v1}, Ljava/lang/StackTraceElement;->getLineNumber()I

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const-string v1, "  s          n       /       }   / n "

    const-string v1, "\n                }\n                "

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v1}, Lkotlin/text/v;->p(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    const/16 v1, 0x5b

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    const/4 v1, 0x0

    const/4 v10, 0x1

    const/4 v2, 0x0

    const/4 v10, 0x0

    move v9, v2

    move v9, v2

    const/4 v10, 0x4

    const/4 v3, 0x0

    const/4 v10, 0x0

    move v9, v3

    move v9, v3

    const/4 v10, 0x6

    const/4 v4, 0x6

    const/4 v10, 0x3

    const/4 v4, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v5, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    const/4 v6, 0x0

    const/4 v9, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    const/16 v7, 0x3f

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v8, 0x0

    move v10, v8

    const/4 v9, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static/range {v0 .. v8}, Lkotlin/collections/u;->j3(Ljava/lang/Iterable;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ILjava/lang/CharSequence;Li8/l;ILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/16 v0, 0x5d

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    return-object p1
.end method

.method public final u()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-boolean v0, Lkotlinx/coroutines/debug/internal/g;->j:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public final v()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    sget-boolean v0, Lkotlinx/coroutines/debug/internal/g;->i:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public final w(Lkotlinx/coroutines/n2;)Ljava/lang/String;
    .locals 11
    .param p1    # Lkotlinx/coroutines/n2;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getWriteHoldCount()I

    move-result v2

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-nez v2, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getReadHoldCount()I

    move-result v2

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    goto :goto_0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    move v2, v3

    move v2, v3

    const/4 v10, 0x0

    move v2, v3

    move v2, v3

    :goto_0
    const/4 v9, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    move v4, v3

    move v4, v3

    const/4 v10, 0x4

    move v4, v3

    move v4, v3

    :goto_1
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-ge v4, v2, :cond_1

    const/4 v9, 0x4

    move v10, v9

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v9, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    add-int/lit8 v4, v4, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    goto :goto_1

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    :try_start_0
    const/4 v9, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    sget-object v4, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v9, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {v4}, Lkotlinx/coroutines/debug/internal/g;->z()Z

    move-result v5

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-eqz v5, :cond_7

    const/4 v9, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-direct {v4}, Lkotlinx/coroutines/debug/internal/g;->q()Ljava/util/Set;

    move-result-object v4

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    check-cast v4, Ljava/lang/Iterable;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    new-instance v5, Ljava/util/ArrayList;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_2
    :goto_2
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-eqz v6, :cond_4

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    check-cast v7, Lkotlinx/coroutines/debug/internal/g$a;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object v7, v7, Lkotlinx/coroutines/debug/internal/g$a;->a:Lkotlin/coroutines/d;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-interface {v7}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v7

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    sget-object v8, Lkotlinx/coroutines/n2;->n0:Lkotlinx/coroutines/n2$b;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-interface {v7, v8}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object v7

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz v7, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 v7, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    goto :goto_3

    :cond_3
    const/4 v9, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    move v7, v3

    move v7, v3

    :goto_3
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-eqz v7, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-interface {v5, v6}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    goto :goto_2

    :cond_4
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    const/16 v4, 0xa

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {v5, v4}, Lkotlin/collections/u;->Y(Ljava/lang/Iterable;I)I

    move-result v4

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {v4}, Lkotlin/collections/x0;->j(I)I

    move-result v4

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    const/16 v6, 0x10

    const/4 v9, 0x4

    const/4 v9, 0x2

    invoke-static {v4, v6}, Lkotlin/ranges/s;->u(II)I

    move-result v4

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    new-instance v6, Ljava/util/LinkedHashMap;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-direct {v6, v4}, Ljava/util/LinkedHashMap;-><init>(I)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_4
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    if-eqz v5, :cond_5

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    move-object v7, v5

    move-object v7, v5

    move-object v7, v5

    const/4 v10, 0x4

    const/4 v9, 0x6

    check-cast v7, Lkotlinx/coroutines/debug/internal/g$a;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-object v7, v7, Lkotlinx/coroutines/debug/internal/g$a;->a:Lkotlin/coroutines/d;

    invoke-interface {v7}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v7

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {v7}, Lkotlinx/coroutines/r2;->B(Lkotlin/coroutines/g;)Lkotlinx/coroutines/n2;

    move-result-object v7

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    check-cast v5, Lkotlinx/coroutines/debug/internal/g$a;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-object v5, v5, Lkotlinx/coroutines/debug/internal/g$a;->b:Lkotlinx/coroutines/debug/internal/e;

    const/4 v10, 0x7

    invoke-interface {v6, v7, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    goto :goto_4

    :cond_5
    const/4 v10, 0x0

    const/4 v9, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    sget-object v5, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v10, 0x6

    const-string v7, ""

    const-string v7, ""

    const-string v7, ""

    const-string v7, ""

    const/4 v9, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-direct {v5, p1, v6, v4, v7}, Lkotlinx/coroutines/debug/internal/g;->d(Lkotlinx/coroutines/n2;Ljava/util/Map;Ljava/lang/StringBuilder;Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    const-string v4, "ni.mtiuryrb.rlidpu)oniS)dlagcnAiS((oBp)(qgteert"

    const-string/jumbo v4, "yBn)n(S.qipAir(llieSrulrr)dpi.otgaitcgtonb)(due"

    const/4 v10, 0x7

    const-string v4, "erboo.(u(pAopyeidn)icgaSuStt(ritrtldrl.gn)Bnl)i"

    const-string v4, "StringBuilder().apply(builderAction).toString()"

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {p1, v4}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_5
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-ge v3, v2, :cond_6

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto :goto_5

    :cond_6
    const/4 v10, 0x3

    const/4 v9, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    return-object p1

    :cond_7
    :try_start_1
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-string p1, "abre bs idlnls tpsagneu oebDro"

    const-string p1, "edsDutrl n inalps aogeb ersobt"

    const/4 v10, 0x1

    const-string p1, " Dariouteoprlsut nnegl esa bbd"

    const-string p1, "Debug probes are not installed"

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    new-instance v4, Ljava/lang/IllegalStateException;

    const/4 v10, 0x4

    const/4 v9, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {v4, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x5

    throw v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    :goto_6
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-ge v3, v2, :cond_8

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v10, 0x7

    const/4 v9, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    goto :goto_6

    :cond_8
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    throw p1
.end method

.method public final x()V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x2

    sget-object v0, Lkotlinx/coroutines/debug/internal/g;->h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->readLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getWriteHoldCount()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v3, 0x0

    move v7, v3

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-nez v2, :cond_0

    const/4 v6, 0x5

    move v7, v6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->getReadHoldCount()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    move v2, v3

    move v2, v3

    const/4 v7, 0x1

    move v2, v3

    move v2, v3

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    move v4, v3

    const/4 v7, 0x4

    move v4, v3

    move v4, v3

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x1

    if-ge v4, v2, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->unlock()V

    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    sget v4, Lkotlinx/coroutines/debug/internal/g;->installations:I

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v5, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x1

    add-int/2addr v4, v5

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    sput v4, Lkotlinx/coroutines/debug/internal/g;->installations:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    sget v4, Lkotlinx/coroutines/debug/internal/g;->installations:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-le v4, v5, :cond_3

    :goto_2
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-ge v3, v2, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x1

    goto :goto_2

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    return-void

    :cond_3
    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    sget-object v4, Lkotlinx/coroutines/debug/internal/g;->a:Lkotlinx/coroutines/debug/internal/g;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v4}, Lkotlinx/coroutines/debug/internal/g;->M()V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget-object v4, Lkotlinx/coroutines/debug/internal/a;->a:Lkotlinx/coroutines/debug/internal/a;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v4}, Lkotlinx/coroutines/debug/internal/a;->a()Z

    move-result v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eqz v4, :cond_5

    :goto_3
    const/4 v6, 0x2

    const/4 v7, 0x4

    if-ge v3, v2, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto :goto_3

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v6, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    return-void

    :cond_5
    :try_start_2
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    sget-object v4, Lkotlinx/coroutines/debug/internal/g;->k:Li8/l;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-eqz v4, :cond_6

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-interface {v4, v5}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_6
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    sget-object v4, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_4
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-ge v3, v2, :cond_7

    const/4 v6, 0x1

    shr-int/2addr v7, v6

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v7, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_4

    :cond_7
    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    return-void

    :catchall_0
    move-exception v4

    :goto_5
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-ge v3, v2, :cond_8

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;->lock()V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x7

    move v7, v6

    goto :goto_5

    :cond_8
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    throw v4
.end method

.method public final z()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget v0, Lkotlinx/coroutines/debug/internal/g;->installations:I

    const/4 v2, 0x7

    if-lez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v2, 0x6

    return v0
.end method
