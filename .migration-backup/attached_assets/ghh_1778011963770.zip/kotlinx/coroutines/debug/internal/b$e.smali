.class final Lkotlinx/coroutines/debug/internal/b$e;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/debug/internal/b;->b()Ljava/util/Set;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/p<",
        "TK;TV;TK;>;"
    }
.end annotation


# static fields
.field public static final a:Lkotlinx/coroutines/debug/internal/b$e;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lkotlinx/coroutines/debug/internal/b$e;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0}, Lkotlinx/coroutines/debug/internal/b$e;-><init>()V

    const/4 v2, 0x3

    sput-object v0, Lkotlinx/coroutines/debug/internal/b$e;->a:Lkotlinx/coroutines/debug/internal/b$e;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-direct {p0, v0}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)TK;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p1
.end method
