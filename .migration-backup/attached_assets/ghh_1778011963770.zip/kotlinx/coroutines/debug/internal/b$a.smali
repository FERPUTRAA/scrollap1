.class final Lkotlinx/coroutines/debug/internal/b$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/debug/internal/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/debug/internal/b$a$a;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nConcurrentWeakMap.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ConcurrentWeakMap.kt\nkotlinx/coroutines/debug/internal/ConcurrentWeakMap$Core\n+ 2 AtomicFU.common.kt\nkotlinx/atomicfu/AtomicFU_commonKt\n*L\n1#1,284:1\n360#2,4:285\n*S KotlinDebug\n*F\n+ 1 ConcurrentWeakMap.kt\nkotlinx/coroutines/debug/internal/ConcurrentWeakMap$Core\n*L\n132#1:285,4\n*E\n"
.end annotation


# static fields
.field private static final synthetic g:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;


# instance fields
.field private final a:I

.field private final b:I

.field private final c:I

.field synthetic d:Ljava/util/concurrent/atomic/AtomicReferenceArray;
    .annotation build Lia/d;
    .end annotation
.end field

.field synthetic e:Ljava/util/concurrent/atomic/AtomicReferenceArray;
    .annotation build Lia/d;
    .end annotation
.end field

.field final synthetic f:Lkotlinx/coroutines/debug/internal/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/debug/internal/b<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field private volatile synthetic load:I
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-class v0, Lkotlinx/coroutines/debug/internal/b$a;

    const-class v0, Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v3, 0x1

    const-class v0, Lkotlinx/coroutines/debug/internal/b$a;

    const-class v0, Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "olda"

    const-string v1, "load"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0, v1}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    sput-object v0, Lkotlinx/coroutines/debug/internal/b$a;->g:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>(Lkotlinx/coroutines/debug/internal/b;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/b$a;->f:Lkotlinx/coroutines/debug/internal/b;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p2, p0, Lkotlinx/coroutines/debug/internal/b$a;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p2}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    add-int/lit8 p1, p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p1, p0, Lkotlinx/coroutines/debug/internal/b$a;->b:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    mul-int/lit8 p1, p2, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x7

    div-int/lit8 p1, p1, 0x3

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p1, p0, Lkotlinx/coroutines/debug/internal/b$a;->c:I

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x0

    shl-int/2addr v0, p1

    const/4 v1, 0x2

    iput p1, p0, Lkotlinx/coroutines/debug/internal/b$a;->load:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicReferenceArray;-><init>(I)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/b$a;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v1, 0x4

    const/4 v0, 0x6

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicReferenceArray;-><init>(I)V

    const/4 v0, 0x1

    move v1, v0

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/b$a;->e:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public static final synthetic a(Lkotlinx/coroutines/debug/internal/b$a;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "v@s@ @od ~@o@-@an /t@tc @f~f~o~~i u~~~@i mo  ~b~@@~~@ @S~i ylb@o. brK@ os@~1/~   M~~~ @@~~~@@~l "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget p0, p0, Lkotlinx/coroutines/debug/internal/b$a;->a:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    return p0
.end method

.method private final d(I)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    const v0, -0x61c88647

    const/4 v2, 0x6

    mul-int/2addr p1, v0

    iget v0, p0, Lkotlinx/coroutines/debug/internal/b$a;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    ushr-int/2addr p1, v0

    return p1
.end method

.method public static synthetic g(Lkotlinx/coroutines/debug/internal/b$a;Ljava/lang/Object;Ljava/lang/Object;Lkotlinx/coroutines/debug/internal/k;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    and-int/lit8 p4, p4, 0x4

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    if-eqz p4, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    const/4 p3, 0x0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/debug/internal/b$a;->f(Ljava/lang/Object;Ljava/lang/Object;Lkotlinx/coroutines/debug/internal/k;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method

.method private final i(I)V
    .locals 5

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b$a;->e:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-nez v0, :cond_1

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    instance-of v1, v0, Lkotlinx/coroutines/debug/internal/l;

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/debug/internal/b$a;->e:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v1, p1, v0, v2}, Lcom/google/common/util/concurrent/y3;->a(Ljava/util/concurrent/atomic/AtomicReferenceArray;ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object p1, p0, Lkotlinx/coroutines/debug/internal/b$a;->f:Lkotlinx/coroutines/debug/internal/b;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p1}, Lkotlinx/coroutines/debug/internal/b;->e(Lkotlinx/coroutines/debug/internal/b;)V

    return-void
.end method


# virtual methods
.method public final b(Lkotlinx/coroutines/debug/internal/k;)V
    .locals 4
    .param p1    # Lkotlinx/coroutines/debug/internal/k;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/debug/internal/k<",
            "*>;)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v0, p1, Lkotlinx/coroutines/debug/internal/k;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Lkotlinx/coroutines/debug/internal/b$a;->d(I)I

    move-result v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/debug/internal/b$a;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    check-cast v1, Lkotlinx/coroutines/debug/internal/k;

    const/4 v2, 0x0

    move v3, v2

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ne v1, p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Lkotlinx/coroutines/debug/internal/b$a;->i(I)V

    const/4 v2, 0x2

    move v3, v2

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v0, p0, Lkotlinx/coroutines/debug/internal/b$a;->a:I

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0
.end method

.method public final c(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)TV;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {p0, v0}, Lkotlinx/coroutines/debug/internal/b$a;->d(I)I

    move-result v0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/debug/internal/b$a;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    check-cast v1, Lkotlinx/coroutines/debug/internal/k;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 p1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    return-object p1

    :cond_0
    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {p1, v1}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v2, :cond_2

    const/4 v4, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/debug/internal/b$a;->e:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    instance-of v0, p1, Lkotlinx/coroutines/debug/internal/l;

    const/4 v3, 0x7

    move v4, v3

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    check-cast p1, Lkotlinx/coroutines/debug/internal/l;

    const/4 v3, 0x5

    move v4, v3

    iget-object p1, p1, Lkotlinx/coroutines/debug/internal/l;->a:Ljava/lang/Object;

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object p1

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-nez v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p0, v0}, Lkotlinx/coroutines/debug/internal/b$a;->i(I)V

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-nez v0, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget v0, p0, Lkotlinx/coroutines/debug/internal/b$a;->a:I

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_0
.end method

.method public final e(Li8/p;)Ljava/util/Iterator;
    .locals 3
    .param p1    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Li8/p<",
            "-TK;-TV;+TE;>;)",
            "Ljava/util/Iterator<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    new-instance v0, Lkotlinx/coroutines/debug/internal/b$a$a;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1}, Lkotlinx/coroutines/debug/internal/b$a$a;-><init>(Lkotlinx/coroutines/debug/internal/b$a;Li8/p;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public final f(Ljava/lang/Object;Ljava/lang/Object;Lkotlinx/coroutines/debug/internal/k;)Ljava/lang/Object;
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/debug/internal/k;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;",
            "Lkotlinx/coroutines/debug/internal/k<",
            "TK;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {p0, v0}, Lkotlinx/coroutines/debug/internal/b$a;->d(I)I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v2, p0, Lkotlinx/coroutines/debug/internal/b$a;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v2, v0}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    check-cast v2, Lkotlinx/coroutines/debug/internal/k;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-nez v2, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez p2, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-object v2

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-nez v1, :cond_3

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v1, p0, Lkotlinx/coroutines/debug/internal/b$a;->load:I

    const/4 v6, 0x7

    iget v3, p0, Lkotlinx/coroutines/debug/internal/b$a;->c:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-lt v1, v3, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {}, Lkotlinx/coroutines/debug/internal/c;->a()Lkotlinx/coroutines/internal/r0;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-object p1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    sget-object v4, Lkotlinx/coroutines/debug/internal/b$a;->g:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v6, 0x3

    invoke-virtual {v4, p0, v1, v3}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->compareAndSet(Ljava/lang/Object;II)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-nez v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto :goto_1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v1, 0x4

    const/4 v1, 0x1

    :cond_3
    const/4 v6, 0x7

    if-nez p3, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-instance p3, Lkotlinx/coroutines/debug/internal/k;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v3, p0, Lkotlinx/coroutines/debug/internal/b$a;->f:Lkotlinx/coroutines/debug/internal/b;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v3}, Lkotlinx/coroutines/debug/internal/b;->f(Lkotlinx/coroutines/debug/internal/b;)Ljava/lang/ref/ReferenceQueue;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-direct {p3, p1, v3}, Lkotlinx/coroutines/debug/internal/k;-><init>(Ljava/lang/Object;Ljava/lang/ref/ReferenceQueue;)V

    :cond_4
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v3, p0, Lkotlinx/coroutines/debug/internal/b$a;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v3, v0, v2, p3}, Lcom/google/common/util/concurrent/y3;->a(Ljava/util/concurrent/atomic/AtomicReferenceArray;ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-nez v2, :cond_6

    const/4 v5, 0x2

    move v6, v5

    goto/16 :goto_0

    :cond_5
    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-static {p1, v2}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz v3, :cond_8

    const/4 v6, 0x4

    if-eqz v1, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    sget-object p1, Lkotlinx/coroutines/debug/internal/b$a;->g:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->decrementAndGet(Ljava/lang/Object;)I

    :cond_6
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/debug/internal/b$a;->e:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    invoke-virtual {p1, v0}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    instance-of p3, p1, Lkotlinx/coroutines/debug/internal/l;

    const/4 v5, 0x3

    move v6, v5

    if-eqz p3, :cond_7

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {}, Lkotlinx/coroutines/debug/internal/c;->a()Lkotlinx/coroutines/internal/r0;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-object p1

    :cond_7
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object p3, p0, Lkotlinx/coroutines/debug/internal/b$a;->e:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p3, v0, p1, p2}, Lcom/google/common/util/concurrent/y3;->a(Ljava/util/concurrent/atomic/AtomicReferenceArray;ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result p3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz p3, :cond_6

    const/4 v5, 0x4

    const/4 v6, 0x7

    return-object p1

    :cond_8
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v2, :cond_9

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-direct {p0, v0}, Lkotlinx/coroutines/debug/internal/b$a;->i(I)V

    :cond_9
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v0, :cond_a

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget v0, p0, Lkotlinx/coroutines/debug/internal/b$a;->a:I

    :cond_a
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    add-int/lit8 v0, v0, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto/16 :goto_0
.end method

.method public final h()Lkotlinx/coroutines/debug/internal/b$a;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/debug/internal/b<",
            "TK;TV;>.a;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b$a;->f:Lkotlinx/coroutines/debug/internal/b;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v0}, Lkotlin/collections/g;->size()I

    move-result v0

    const/4 v9, 0x3

    const/4 v1, 0x1

    const/4 v9, 0x5

    const/4 v1, 0x4

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v0, v1}, Lkotlin/ranges/s;->u(II)I

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {v0}, Ljava/lang/Integer;->highestOneBit(I)I

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    mul-int/2addr v0, v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    new-instance v1, Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/debug/internal/b$a;->f:Lkotlinx/coroutines/debug/internal/b;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-direct {v1, v2, v0}, Lkotlinx/coroutines/debug/internal/b$a;-><init>(Lkotlinx/coroutines/debug/internal/b;I)V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget v0, p0, Lkotlinx/coroutines/debug/internal/b$a;->a:I

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-ge v2, v0, :cond_5

    const/4 v8, 0x3

    const/4 v8, 0x3

    iget-object v3, p0, Lkotlinx/coroutines/debug/internal/b$a;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v3, v2}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x6

    check-cast v3, Lkotlinx/coroutines/debug/internal/k;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-eqz v3, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    goto :goto_1

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v4, 0x0

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-eqz v3, :cond_2

    const/4 v9, 0x6

    if-nez v4, :cond_2

    const/4 v9, 0x0

    invoke-direct {p0, v2}, Lkotlinx/coroutines/debug/internal/b$a;->i(I)V

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object v5, p0, Lkotlinx/coroutines/debug/internal/b$a;->e:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v5, v2}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    instance-of v6, v5, Lkotlinx/coroutines/debug/internal/l;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz v6, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    check-cast v5, Lkotlinx/coroutines/debug/internal/l;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v5, v5, Lkotlinx/coroutines/debug/internal/l;->a:Ljava/lang/Object;

    const/4 v9, 0x6

    goto :goto_2

    :cond_3
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v6, p0, Lkotlinx/coroutines/debug/internal/b$a;->e:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v8, 0x0

    move v9, v8

    invoke-static {v5}, Lkotlinx/coroutines/debug/internal/c;->b(Ljava/lang/Object;)Lkotlinx/coroutines/debug/internal/l;

    move-result-object v7

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {v6, v2, v5, v7}, Lcom/google/common/util/concurrent/y3;->a(Ljava/util/concurrent/atomic/AtomicReferenceArray;ILjava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-eqz v6, :cond_2

    :goto_2
    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eqz v4, :cond_4

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-eqz v5, :cond_4

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v1, v4, v5, v3}, Lkotlinx/coroutines/debug/internal/b$a;->f(Ljava/lang/Object;Ljava/lang/Object;Lkotlinx/coroutines/debug/internal/k;)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static {}, Lkotlinx/coroutines/debug/internal/c;->a()Lkotlinx/coroutines/internal/r0;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eq v3, v4, :cond_0

    :cond_4
    const/4 v8, 0x4

    move v9, v8

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    goto/16 :goto_0

    :cond_5
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    return-object v1
.end method
