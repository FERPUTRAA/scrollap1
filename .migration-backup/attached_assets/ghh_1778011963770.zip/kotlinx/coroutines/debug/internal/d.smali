.class public final Lkotlinx/coroutines/debug/internal/d;
.super Ljava/lang/Object;


# annotations
.annotation build Lkotlin/a1;
.end annotation


# instance fields
.field private final a:Lkotlin/coroutines/g;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final b:Lkotlin/coroutines/jvm/internal/e;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final c:J

.field private final d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private final e:Ljava/lang/String;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final f:Ljava/lang/Thread;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final g:Lkotlin/coroutines/jvm/internal/e;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final h:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/debug/internal/e;Lkotlin/coroutines/g;)V
    .locals 4
    .param p1    # Lkotlinx/coroutines/debug/internal/e;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    move v3, v2

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/d;->a:Lkotlin/coroutines/g;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/e;->d()Lkotlinx/coroutines/debug/internal/m;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/d;->b:Lkotlin/coroutines/jvm/internal/e;

    const/4 v2, 0x5

    move v3, v2

    iget-wide v0, p1, Lkotlinx/coroutines/debug/internal/e;->b:J

    const/4 v3, 0x1

    iput-wide v0, p0, Lkotlinx/coroutines/debug/internal/d;->c:J

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/e;->e()Ljava/util/List;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/d;->d:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/e;->g()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/d;->e:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p2, p1, Lkotlinx/coroutines/debug/internal/e;->e:Ljava/lang/Thread;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/d;->f:Ljava/lang/Thread;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/e;->f()Lkotlin/coroutines/jvm/internal/e;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/d;->g:Lkotlin/coroutines/jvm/internal/e;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/e;->h()Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/d;->h:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public final a()Lkotlin/coroutines/g;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@sd~itn@@/~obrl~oM ~a @~~.~ob ~~ l  @i@@o~    S ~@ vf~@cbo/1f~~~@s@ @to@@ mK ~~~@~y@~@  @@u~@-4"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/d;->a:Lkotlin/coroutines/g;

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public final b()Lkotlin/coroutines/jvm/internal/e;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/d;->b:Lkotlin/coroutines/jvm/internal/e;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public final c()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/d;->d:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public final d()Lkotlin/coroutines/jvm/internal/e;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/d;->g:Lkotlin/coroutines/jvm/internal/e;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public final e()Ljava/lang/Thread;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/d;->f:Ljava/lang/Thread;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public final f()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-wide v0, p0, Lkotlinx/coroutines/debug/internal/d;->c:J

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-wide v0
.end method

.method public final g()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/d;->e:Ljava/lang/String;

    const/4 v1, 0x5

    move v2, v1

    return-object v0
.end method

.method public final h()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/h;
        name = "lastObservedStackTrace"
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/d;->h:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method
