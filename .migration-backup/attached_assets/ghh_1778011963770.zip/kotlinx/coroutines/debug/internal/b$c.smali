.class final Lkotlinx/coroutines/debug/internal/b$c;
.super Lkotlin/collections/h;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/debug/internal/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlin/collections/h<",
        "TE;>;"
    }
.end annotation


# instance fields
.field private final a:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "TK;TV;TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field final synthetic b:Lkotlinx/coroutines/debug/internal/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/debug/internal/b<",
            "TK;TV;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/debug/internal/b;Li8/p;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/debug/internal/b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/p<",
            "-TK;-TV;+TE;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/b$c;->b:Lkotlinx/coroutines/debug/internal/b;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Lkotlin/collections/h;-><init>()V

    const/4 v0, 0x5

    xor-int/2addr v1, v0

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/b$c;->a:Li8/p;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ts@@~@mct@M @/if~ ~1 ~f  @i~@d@~~~-v~l ~a l~   @@.o4 oSusbr~b K/@~@~~o ~@~@ @~ @nb @@@~~ioo~~yo"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b$c;->b:Lkotlinx/coroutines/debug/internal/b;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lkotlin/collections/g;->size()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    return v0
.end method

.method public add(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)Z"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {}, Lkotlinx/coroutines/debug/internal/c;->c()Ljava/lang/Void;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    new-instance p1, Lkotlin/y;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p1}, Lkotlin/y;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    throw p1
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b$c;->b:Lkotlinx/coroutines/debug/internal/b;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, v0, Lkotlinx/coroutines/debug/internal/b;->core:Ljava/lang/Object;

    const/4 v2, 0x5

    move v3, v2

    check-cast v0, Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/debug/internal/b$c;->a:Li8/p;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lkotlinx/coroutines/debug/internal/b$a;->e(Li8/p;)Ljava/util/Iterator;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0
.end method
