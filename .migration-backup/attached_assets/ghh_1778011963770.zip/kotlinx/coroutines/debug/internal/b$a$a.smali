.class final Lkotlinx/coroutines/debug/internal/b$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Iterator;
.implements Lj8/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/debug/internal/b$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "TE;>;",
        "Lj8/d;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nConcurrentWeakMap.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ConcurrentWeakMap.kt\nkotlinx/coroutines/debug/internal/ConcurrentWeakMap$Core$KeyValueIterator\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,284:1\n1#2:285\n*E\n"
.end annotation


# instance fields
.field private final a:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "TK;TV;TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private b:I

.field private c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TK;"
        }
    .end annotation
.end field

.field private d:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field final synthetic e:Lkotlinx/coroutines/debug/internal/b$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/debug/internal/b<",
            "TK;TV;>.a;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/debug/internal/b$a;Li8/p;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/debug/internal/b$a;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/p<",
            "-TK;-TV;+TE;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->e:Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->a:Li8/p;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/4 p1, -0x1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput p1, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Lkotlinx/coroutines/debug/internal/b$a$a;->a()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method private final a()V
    .locals 4

    :cond_0
    :goto_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "i@sa l~@~btu @ r@@/o~@~m/~@~o~~  -~ 4d~c@~1@i @f@ ~~  o~~~@~.@i~~K@b @o vfon~ s@y@@t @ o  @MlSb~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget v0, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->b:I

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput v0, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->b:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->e:Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v1}, Lkotlinx/coroutines/debug/internal/b$a;->a(Lkotlinx/coroutines/debug/internal/b$a;)I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ge v0, v1, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->e:Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, v0, Lkotlinx/coroutines/debug/internal/b$a;->d:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v1, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->b:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    check-cast v0, Lkotlinx/coroutines/debug/internal/k;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->c:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->e:Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, v0, Lkotlinx/coroutines/debug/internal/b$a;->e:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v1, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    instance-of v1, v0, Lkotlinx/coroutines/debug/internal/l;

    const/4 v3, 0x4

    const/4 v2, 0x2

    if-eqz v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast v0, Lkotlinx/coroutines/debug/internal/l;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, v0, Lkotlinx/coroutines/debug/internal/l;->a:Ljava/lang/Object;

    :cond_2
    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v2, 0x3

    iput-object v0, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->d:Ljava/lang/Object;

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public b()Ljava/lang/Void;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {}, Lkotlinx/coroutines/debug/internal/c;->c()Ljava/lang/Void;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Lkotlin/y;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {v0}, Lkotlin/y;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    throw v0
.end method

.method public hasNext()Z
    .locals 4

    const/4 v3, 0x0

    iget v0, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->b:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->e:Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v1}, Lkotlinx/coroutines/debug/internal/b$a;->a(Lkotlinx/coroutines/debug/internal/b$a;)I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ge v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    return v0
.end method

.method public next()Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    const/4 v3, 0x2

    move v4, v3

    iget v0, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->b:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->e:Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v4, 0x0

    invoke-static {v1}, Lkotlinx/coroutines/debug/internal/b$a;->a(Lkotlinx/coroutines/debug/internal/b$a;)I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-ge v0, v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->a:Li8/p;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->c:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v1, "eyk"

    const-string/jumbo v1, "yke"

    const/4 v4, 0x2

    const-string v1, "key"

    const-string v1, "key"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    sget-object v1, Lkotlin/s2;->a:Lkotlin/s2;

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v2, p0, Lkotlinx/coroutines/debug/internal/b$a$a;->d:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v2, "avume"

    const-string v2, "aesvu"

    const/4 v4, 0x7

    const-string/jumbo v2, "value"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v4, 0x2

    sget-object v2, Lkotlin/s2;->a:Lkotlin/s2;

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {v0, v1, v2}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/debug/internal/b$a$a;->a()V

    const/4 v4, 0x1

    return-object v0

    :cond_2
    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method

.method public bridge synthetic remove()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0}, Lkotlinx/coroutines/debug/internal/b$a$a;->b()Ljava/lang/Void;

    const/4 v1, 0x2

    return-void
.end method
