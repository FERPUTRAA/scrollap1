.class public final Lkotlinx/coroutines/debug/internal/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Lkotlinx/coroutines/debug/internal/a;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static b:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    new-instance v0, Lkotlinx/coroutines/debug/internal/a;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {v0}, Lkotlinx/coroutines/debug/internal/a;-><init>()V

    const/4 v1, 0x3

    const/4 v1, 0x6

    sput-object v0, Lkotlinx/coroutines/debug/internal/a;->a:Lkotlinx/coroutines/debug/internal/a;

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "o~s@@@@~K ~ @~/~f~ao~ ~ @b@nt~ ~ut~ m @@d~~iy boo~  @~@-.1  /c@ ~@~@~rf  ~@@~SvMo@@ @ib~oil4l~@s"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-boolean v0, Lkotlinx/coroutines/debug/internal/a;->b:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public final b(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    sput-boolean p1, Lkotlinx/coroutines/debug/internal/a;->b:Z

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method
