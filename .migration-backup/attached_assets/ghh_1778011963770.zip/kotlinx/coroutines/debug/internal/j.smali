.class public final Lkotlinx/coroutines/debug/internal/j;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# annotations
.annotation build Lkotlin/a1;
.end annotation


# instance fields
.field private final coroutineId:Ljava/lang/Long;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final dispatcher:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final lastObservedStackTrace:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private final lastObservedThreadName:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final lastObservedThreadState:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final name:Ljava/lang/String;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final sequenceNumber:J

.field private final state:Ljava/lang/String;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/debug/internal/e;Lkotlin/coroutines/g;)V
    .locals 6
    .param p1    # Lkotlinx/coroutines/debug/internal/e;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v4, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    sget-object v0, Lkotlinx/coroutines/s0;->b:Lkotlinx/coroutines/s0$a;

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-interface {p2, v0}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    check-cast v0, Lkotlinx/coroutines/s0;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0}, Lkotlinx/coroutines/s0;->r0()J

    move-result-wide v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    iput-object v0, p0, Lkotlinx/coroutines/debug/internal/j;->coroutineId:Ljava/lang/Long;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget-object v0, Lkotlin/coroutines/e;->l0:Lkotlin/coroutines/e$b;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-interface {p2, v0}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    check-cast v0, Lkotlin/coroutines/e;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_1

    :cond_1
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput-object v0, p0, Lkotlinx/coroutines/debug/internal/j;->dispatcher:Ljava/lang/String;

    sget-object v0, Lkotlinx/coroutines/t0;->b:Lkotlinx/coroutines/t0$a;

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-interface {p2, v0}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    check-cast p2, Lkotlinx/coroutines/t0;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz p2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p2}, Lkotlinx/coroutines/t0;->r0()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto :goto_2

    :cond_2
    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :goto_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/j;->name:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/e;->g()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/j;->state:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x6

    iget-object p2, p1, Lkotlinx/coroutines/debug/internal/e;->e:Ljava/lang/Thread;

    const/4 v5, 0x7

    if-eqz p2, :cond_3

    const/4 v5, 0x1

    invoke-virtual {p2}, Ljava/lang/Thread;->getState()Ljava/lang/Thread$State;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz p2, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_3

    :cond_3
    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    move-object p2, v1

    :goto_3
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/j;->lastObservedThreadState:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p2, p1, Lkotlinx/coroutines/debug/internal/e;->e:Ljava/lang/Thread;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz p2, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p2}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v1

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput-object v1, p0, Lkotlinx/coroutines/debug/internal/j;->lastObservedThreadName:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1}, Lkotlinx/coroutines/debug/internal/e;->h()Ljava/util/List;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/j;->lastObservedStackTrace:Ljava/util/List;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-wide p1, p1, Lkotlinx/coroutines/debug/internal/e;->b:J

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    iput-wide p1, p0, Lkotlinx/coroutines/debug/internal/j;->sequenceNumber:J

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Long;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "d si b@~~~/@@ ~uo@in~ t1 @Sor@@~@v io ~@m @~~ ~~~~~ @b@~bf@cl.~ ~@t/   Mfo K-os~@@~o4~@~l@y @ ~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/j;->coroutineId:Ljava/lang/Long;

    const/4 v2, 0x4

    const/4 v1, 0x2

    return-object v0
.end method

.method public final b()Ljava/lang/String;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/j;->dispatcher:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public final c()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/StackTraceElement;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/j;->lastObservedStackTrace:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public final d()Ljava/lang/String;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/j;->lastObservedThreadName:Ljava/lang/String;

    const/4 v1, 0x1

    move v2, v1

    return-object v0
.end method

.method public final e()Ljava/lang/String;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/j;->lastObservedThreadState:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public final f()Ljava/lang/String;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/j;->name:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public final g()J
    .locals 4

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-wide v0, p0, Lkotlinx/coroutines/debug/internal/j;->sequenceNumber:J

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-wide v0
.end method

.method public final h()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/j;->state:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method
