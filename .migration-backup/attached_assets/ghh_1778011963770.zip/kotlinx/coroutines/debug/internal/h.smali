.class synthetic Lkotlinx/coroutines/debug/internal/h;
.super Ljava/lang/Object;


# instance fields
.field volatile sequenceNumber:J


# direct methods
.method public constructor <init>(J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-wide p1, p0, Lkotlinx/coroutines/debug/internal/h;->sequenceNumber:J

    const/4 v1, 0x7

    return-void
.end method
