.class public final Lkotlinx/coroutines/debug/internal/f;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "CREATED"
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "RUNNING"
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final c:Ljava/lang/String; = "SUSPENDED"
    .annotation build Lia/d;
    .end annotation
.end field
