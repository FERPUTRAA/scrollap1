.class public final Lkotlinx/coroutines/debug/internal/b;
.super Lkotlin/collections/g;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/debug/internal/b$a;,
        Lkotlinx/coroutines/debug/internal/b$b;,
        Lkotlinx/coroutines/debug/internal/b$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlin/collections/g<",
        "TK;TV;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nConcurrentWeakMap.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ConcurrentWeakMap.kt\nkotlinx/coroutines/debug/internal/ConcurrentWeakMap\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,284:1\n1#2:285\n*E\n"
.end annotation


# static fields
.field private static final synthetic b:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;


# instance fields
.field private volatile synthetic _size:I
    .annotation build Lia/d;
    .end annotation
.end field

.field private final a:Ljava/lang/ref/ReferenceQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/ReferenceQueue<",
            "TK;>;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field volatile synthetic core:Ljava/lang/Object;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x4

    const/4 v2, 0x3

    const-class v0, Lkotlinx/coroutines/debug/internal/b;

    const-class v0, Lkotlinx/coroutines/debug/internal/b;

    const/4 v3, 0x6

    const-class v0, Lkotlinx/coroutines/debug/internal/b;

    const-class v0, Lkotlinx/coroutines/debug/internal/b;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v1, "szsi_"

    const-string/jumbo v1, "zis_e"

    const/4 v3, 0x6

    const-string/jumbo v1, "zi_me"

    const-string v1, "_size"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0, v1}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    sput-object v0, Lkotlinx/coroutines/debug/internal/b;->b:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {p0, v2, v0, v1}, Lkotlinx/coroutines/debug/internal/b;-><init>(ZILkotlin/jvm/internal/w;)V

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void
.end method

.method public constructor <init>(Z)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0}, Lkotlin/collections/g;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput v0, p0, Lkotlinx/coroutines/debug/internal/b;->_size:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v0, Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/16 v1, 0x10

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, p0, v1}, Lkotlinx/coroutines/debug/internal/b$a;-><init>(Lkotlinx/coroutines/debug/internal/b;I)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Lkotlinx/coroutines/debug/internal/b;->core:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/ref/ReferenceQueue;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p1}, Ljava/lang/ref/ReferenceQueue;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    const/4 p1, 0x0

    move v3, p1

    :goto_0
    const/4 v2, 0x6

    move v3, v2

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/b;->a:Ljava/lang/ref/ReferenceQueue;

    const/4 v3, 0x1

    return-void
.end method

.method public synthetic constructor <init>(ZILkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    and-int/lit8 p2, p2, 0x1

    const/4 v0, 0x6

    move v1, v0

    if-eqz p2, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    const/4 p1, 0x0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lkotlinx/coroutines/debug/internal/b;-><init>(Z)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public static final synthetic e(Lkotlinx/coroutines/debug/internal/b;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "1@t~o~ ~~~~@4@@ y l@i r~@@f bf~@  ~@K@b@a@~ .s~M ~~v o/o@~~c@~l/@@ @@obui~ ooo~~t@  ~~  - nm~S@d"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-direct {p0}, Lkotlinx/coroutines/debug/internal/b;->h()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public static final synthetic f(Lkotlinx/coroutines/debug/internal/b;)Ljava/lang/ref/ReferenceQueue;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget-object p0, p0, Lkotlinx/coroutines/debug/internal/b;->a:Ljava/lang/ref/ReferenceQueue;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method private final g(Lkotlinx/coroutines/debug/internal/k;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/debug/internal/k<",
            "*>;)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b;->core:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast v0, Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/debug/internal/b$a;->b(Lkotlinx/coroutines/debug/internal/k;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method private final h()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lkotlinx/coroutines/debug/internal/b;->b:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->decrementAndGet(Ljava/lang/Object;)I

    const/4 v2, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method private final declared-synchronized i(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)TV;"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b;->core:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    check-cast v0, Lkotlinx/coroutines/debug/internal/b$a;

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v4, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/4 v5, 0x4

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v6, 0x0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/debug/internal/b$a;->g(Lkotlinx/coroutines/debug/internal/b$a;Ljava/lang/Object;Ljava/lang/Object;Lkotlinx/coroutines/debug/internal/k;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {}, Lkotlinx/coroutines/debug/internal/c;->a()Lkotlinx/coroutines/internal/r0;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-eq v1, v2, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    monitor-exit p0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    return-object v1

    :cond_0
    :try_start_1
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v0}, Lkotlinx/coroutines/debug/internal/b$a;->h()Lkotlinx/coroutines/debug/internal/b$a;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    iput-object v0, p0, Lkotlinx/coroutines/debug/internal/b;->core:Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    monitor-exit p0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    throw p1
.end method


# virtual methods
.method public a()Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Lkotlinx/coroutines/debug/internal/b$c;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object v1, Lkotlinx/coroutines/debug/internal/b$d;->a:Lkotlinx/coroutines/debug/internal/b$d;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0, p0, v1}, Lkotlinx/coroutines/debug/internal/b$c;-><init>(Lkotlinx/coroutines/debug/internal/b;Li8/p;)V

    const/4 v3, 0x3

    return-object v0
.end method

.method public b()Ljava/util/Set;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "TK;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Lkotlinx/coroutines/debug/internal/b$c;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object v1, Lkotlinx/coroutines/debug/internal/b$e;->a:Lkotlinx/coroutines/debug/internal/b$e;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0, p0, v1}, Lkotlinx/coroutines/debug/internal/b$c;-><init>(Lkotlinx/coroutines/debug/internal/b;Li8/p;)V

    const/4 v2, 0x1

    move v3, v2

    return-object v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lkotlinx/coroutines/debug/internal/b;->_size:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public clear()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lkotlin/collections/g;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Lkotlinx/coroutines/debug/internal/b;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    return-void
.end method

.method public get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")TV;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b;->core:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast v0, Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/debug/internal/b$a;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p1
.end method

.method public final k()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b;->a:Ljava/lang/ref/ReferenceQueue;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_2

    :goto_1
    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b;->a:Ljava/lang/ref/ReferenceQueue;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/ref/ReferenceQueue;->remove()Ljava/lang/ref/Reference;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Lkotlinx/coroutines/debug/internal/k;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Lkotlinx/coroutines/debug/internal/b;->g(Lkotlinx/coroutines/debug/internal/k;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const-string v1, "ce okbonpl R.t inH it-aft*cd.<ensuanc. tgstu oanmystnhWnxeelbulndaeen .rklaonultlbeo>oi"

    const-string v1, "eekm.a.uttldpon>c .slb-e notnnaruln annct cllatooH<sn uenogde WoeRb.eittus*aixlnhf keyi"

    const/4 v3, 0x5

    const-string v1, "t.n.tsukl<sbgn lrHnioibc uedecrlntaoukeapll>Reetonan*a-tu c leianod.foWn .oet tsn xneyu"

    const-string v1, "null cannot be cast to non-null type kotlinx.coroutines.debug.internal.HashedWeakRef<*>"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw v0
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void

    :cond_2
    const/4 v2, 0x3

    move v3, v2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "ceke rupru tMadQuhte  ewb=teR stu feaiew"

    const-string v1, "eectoeefetre= s rthku a udiMQ uRetuww ba"

    const/4 v3, 0x1

    const-string v1, " eeadesiqwae wcMutrQbter=utufee  h tu Re"

    const-string v1, "Must be created with weakRefQueue = true"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    throw v0
.end method

.method public put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)TV;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v7, 0x6

    const/4 v8, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/b;->core:Ljava/lang/Object;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    check-cast v1, Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    const/4 v4, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 v5, 0x4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/4 v6, 0x0

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/debug/internal/b$a;->g(Lkotlinx/coroutines/debug/internal/b$a;Ljava/lang/Object;Ljava/lang/Object;Lkotlinx/coroutines/debug/internal/k;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {}, Lkotlinx/coroutines/debug/internal/c;->a()Lkotlinx/coroutines/internal/r0;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-ne v0, v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-direct {p0, p1, p2}, Lkotlinx/coroutines/debug/internal/b;->i(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-nez v0, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    sget-object p1, Lkotlinx/coroutines/debug/internal/b;->b:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->incrementAndGet(Ljava/lang/Object;)I

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    return-object v0
.end method

.method public remove(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")TV;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/4 v0, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-nez p1, :cond_0

    return-object v0

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/debug/internal/b;->core:Ljava/lang/Object;

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    check-cast v2, Lkotlinx/coroutines/debug/internal/b$a;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    const/4 v5, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    const/4 v6, 0x4

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v7, 0x0

    move v9, v7

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static/range {v2 .. v7}, Lkotlinx/coroutines/debug/internal/b$a;->g(Lkotlinx/coroutines/debug/internal/b$a;Ljava/lang/Object;Ljava/lang/Object;Lkotlinx/coroutines/debug/internal/k;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {}, Lkotlinx/coroutines/debug/internal/c;->a()Lkotlinx/coroutines/internal/r0;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-ne v1, v2, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-direct {p0, p1, v0}, Lkotlinx/coroutines/debug/internal/b;->i(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x6

    if-eqz v1, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    sget-object p1, Lkotlinx/coroutines/debug/internal/b;->b:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->decrementAndGet(Ljava/lang/Object;)I

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    return-object v1
.end method
