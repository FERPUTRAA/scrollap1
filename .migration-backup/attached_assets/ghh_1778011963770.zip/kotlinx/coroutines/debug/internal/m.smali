.class public final Lkotlinx/coroutines/debug/internal/m;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlin/coroutines/jvm/internal/e;


# instance fields
.field private final a:Lkotlin/coroutines/jvm/internal/e;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final b:Ljava/lang/StackTraceElement;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/coroutines/jvm/internal/e;Ljava/lang/StackTraceElement;)V
    .locals 2
    .param p1    # Lkotlin/coroutines/jvm/internal/e;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Ljava/lang/StackTraceElement;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/m;->a:Lkotlin/coroutines/jvm/internal/e;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/debug/internal/m;->b:Ljava/lang/StackTraceElement;

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public getCallerFrame()Lkotlin/coroutines/jvm/internal/e;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/m;->a:Lkotlin/coroutines/jvm/internal/e;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public getStackTraceElement()Ljava/lang/StackTraceElement;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    iget-object v0, p0, Lkotlinx/coroutines/debug/internal/m;->b:Ljava/lang/StackTraceElement;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method
