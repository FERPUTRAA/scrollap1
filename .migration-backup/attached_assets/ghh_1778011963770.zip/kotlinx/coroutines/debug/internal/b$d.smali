.class final Lkotlinx/coroutines/debug/internal/b$d;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/debug/internal/b;->a()Ljava/util/Set;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/p<",
        "TK;TV;",
        "Ljava/util/Map$Entry<",
        "TK;TV;>;>;"
    }
.end annotation


# static fields
.field public static final a:Lkotlinx/coroutines/debug/internal/b$d;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    new-instance v0, Lkotlinx/coroutines/debug/internal/b$d;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Lkotlinx/coroutines/debug/internal/b$d;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    sput-object v0, Lkotlinx/coroutines/debug/internal/b$d;->a:Lkotlinx/coroutines/debug/internal/b$d;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map$Entry;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    new-instance v0, Lkotlinx/coroutines/debug/internal/b$b;

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-direct {v0, p1, p2}, Lkotlinx/coroutines/debug/internal/b$b;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/debug/internal/b$d;->c(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map$Entry;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p1
.end method
