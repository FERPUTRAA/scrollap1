.class final Lkotlinx/coroutines/debug/internal/e$b;
.super Lkotlin/coroutines/jvm/internal/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/debug/internal/e;->k(Lkotlin/sequences/o;Lkotlin/coroutines/jvm/internal/e;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.debug.internal.DebugCoroutineInfoImpl"
    f = "DebugCoroutineInfoImpl.kt"
    i = {}
    l = {
        0x50
    }
    m = "yieldFrames"
    n = {}
    s = {}
.end annotation


# instance fields
.field L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field label:I

.field synthetic result:Ljava/lang/Object;

.field final synthetic this$0:Lkotlinx/coroutines/debug/internal/e;


# direct methods
.method constructor <init>(Lkotlinx/coroutines/debug/internal/e;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/debug/internal/e;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/debug/internal/e$b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/e$b;->this$0:Lkotlinx/coroutines/debug/internal/e;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0, p2}, Lkotlin/coroutines/jvm/internal/d;-><init>(Lkotlin/coroutines/d;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ls~@ ~cub @o@is ~@@~bon/ y@/ o~~i~ ~~~Kv  ~4l@~@ a@@m@  fb ~ @~1~ oMt~@ot~  ~-@@ @o@.di@r@S~~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/debug/internal/e$b;->result:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget p1, p0, Lkotlinx/coroutines/debug/internal/e$b;->label:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/high16 v0, -0x80000000

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    or-int/2addr p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput p1, p0, Lkotlinx/coroutines/debug/internal/e$b;->label:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/debug/internal/e$b;->this$0:Lkotlinx/coroutines/debug/internal/e;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p1, v0, v0, p0}, Lkotlinx/coroutines/debug/internal/e;->a(Lkotlinx/coroutines/debug/internal/e;Lkotlin/sequences/o;Lkotlin/coroutines/jvm/internal/e;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p1
.end method
