.class public final Lkotlinx/coroutines/c4;
.super Lkotlinx/coroutines/internal/n0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/internal/n0<",
        "TT;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCoroutineContext.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CoroutineContext.kt\nkotlinx/coroutines/UndispatchedCoroutine\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 CoroutineContext.kt\nkotlinx/coroutines/CoroutineContextKt\n*L\n1#1,274:1\n1#2:275\n107#3,13:276\n*S KotlinDebug\n*F\n+ 1 CoroutineContext.kt\nkotlinx/coroutines/UndispatchedCoroutine\n*L\n232#1:276,13\n*E\n"
.end annotation


# instance fields
.field private d:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Lkotlin/u0<",
            "Lkotlin/coroutines/g;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/coroutines/g;Lkotlin/coroutines/d;)V
    .locals 4
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "Lkotlin/coroutines/d<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget-object v0, Lkotlinx/coroutines/d4;->a:Lkotlinx/coroutines/d4;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p1, v0}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {p1, v0}, Lkotlin/coroutines/g;->plus(Lkotlin/coroutines/g;)Lkotlin/coroutines/g;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0, v0, p2}, Lkotlinx/coroutines/internal/n0;-><init>(Lkotlin/coroutines/g;Lkotlin/coroutines/d;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/ThreadLocal;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lkotlinx/coroutines/c4;->d:Ljava/lang/ThreadLocal;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {p2}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    sget-object v0, Lkotlin/coroutines/e;->l0:Lkotlin/coroutines/e$b;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {p2, v0}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    instance-of p2, p2, Lkotlinx/coroutines/o0;

    const/4 v3, 0x6

    const/4 v2, 0x1

    if-nez p2, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 p2, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-static {p1, p2}, Lkotlinx/coroutines/internal/w0;->c(Lkotlin/coroutines/g;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p1, p2}, Lkotlinx/coroutines/internal/w0;->a(Lkotlin/coroutines/g;Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/c4;->l1(Lkotlin/coroutines/g;Ljava/lang/Object;)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method


# virtual methods
.method protected e1(Ljava/lang/Object;)V
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "Kbs/~ ~@~- c l i@~u@@~ i~ts@~o~~~ @ov~a r~fb4.~d i o@~/1@@o  @ @@~So y~ tl@@@~M@@ b ~no~~f ~@@@~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/c4;->d:Ljava/lang/ThreadLocal;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x7

    check-cast v0, Lkotlin/u0;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0}, Lkotlin/u0;->a()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    check-cast v2, Lkotlin/coroutines/g;

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Lkotlin/u0;->b()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v2, v0}, Lkotlinx/coroutines/internal/w0;->a(Lkotlin/coroutines/g;Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/c4;->d:Ljava/lang/ThreadLocal;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/internal/n0;->c:Lkotlin/coroutines/d;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p1, v0}, Lkotlinx/coroutines/k0;->a(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/internal/n0;->c:Lkotlin/coroutines/d;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-interface {v0}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v2, v1}, Lkotlinx/coroutines/internal/w0;->c(Lkotlin/coroutines/g;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    sget-object v4, Lkotlinx/coroutines/internal/w0;->a:Lkotlinx/coroutines/internal/r0;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eq v3, v4, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v0, v2, v3}, Lkotlinx/coroutines/n0;->g(Lkotlin/coroutines/d;Lkotlin/coroutines/g;Ljava/lang/Object;)Lkotlinx/coroutines/c4;

    move-result-object v1

    :cond_1
    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/internal/n0;->c:Lkotlin/coroutines/d;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-interface {v0, p1}, Lkotlin/coroutines/d;->resumeWith(Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v1}, Lkotlinx/coroutines/c4;->k1()Z

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz p1, :cond_3

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v2, v3}, Lkotlinx/coroutines/internal/w0;->a(Lkotlin/coroutines/g;Ljava/lang/Object;)V

    :cond_3
    const/4 v5, 0x4

    const/4 v5, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz v1, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1}, Lkotlinx/coroutines/c4;->k1()Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v0, :cond_5

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v2, v3}, Lkotlinx/coroutines/internal/w0;->a(Lkotlin/coroutines/g;Ljava/lang/Object;)V

    :cond_5
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    throw p1
.end method

.method public final k1()Z
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/c4;->d:Ljava/lang/ThreadLocal;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/c4;->d:Ljava/lang/ThreadLocal;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return v0
.end method

.method public final l1(Lkotlin/coroutines/g;Ljava/lang/Object;)V
    .locals 3
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/c4;->d:Ljava/lang/ThreadLocal;

    const/4 v1, 0x5

    move v2, v1

    invoke-static {p1, p2}, Lkotlin/q1;->a(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/u0;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    const/4 v2, 0x0

    return-void
.end method
