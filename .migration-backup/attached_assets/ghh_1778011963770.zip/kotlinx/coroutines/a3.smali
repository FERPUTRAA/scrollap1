.class public final Lkotlinx/coroutines/a3;
.super Lkotlinx/coroutines/internal/w;

# interfaces
.implements Lkotlinx/coroutines/g2;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nJobSupport.kt\nKotlin\n*S Kotlin\n*F\n+ 1 JobSupport.kt\nkotlinx/coroutines/NodeList\n+ 2 LockFreeLinkedList.kt\nkotlinx/coroutines/internal/LockFreeLinkedListHead\n*L\n1#1,1479:1\n645#2,6:1480\n*S KotlinDebug\n*F\n+ 1 JobSupport.kt\nkotlinx/coroutines/NodeList\n*L\n1371#1:1480,6\n*E\n"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Lkotlinx/coroutines/internal/w;-><init>()V

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final H0(Ljava/lang/String;)Ljava/lang/String;
    .locals 6
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  s@@u@@ 4a~/~@~~iobKo~1f~~cn f~@.@@~~  ~i @ @Mory@@ ott @@@/vo@  ~  b~@~sS@mbd~-  i@~l@~o ~~~~~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v1, "Ltsms"

    const-string v1, "sLs{t"

    const/4 v5, 0x3

    const-string v1, "tL{io"

    const-string v1, "List{"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo p1, "}["

    const-string/jumbo p1, "}["

    const/4 v5, 0x0

    const-string/jumbo p1, "}["

    const-string/jumbo p1, "}["

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/internal/y;->o0()Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    check-cast p1, Lkotlinx/coroutines/internal/y;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v1, 0x1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p1, p0}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-nez v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    instance-of v2, p1, Lkotlinx/coroutines/u2;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v2, :cond_1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    check-cast v2, Lkotlinx/coroutines/u2;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v1, :cond_0

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x7

    and-int/2addr v4, v1

    const/4 v5, 0x3

    goto :goto_1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string v3, ", "

    const-string v3, ", "

    const-string v3, ", "

    const-string v3, ", "

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p1}, Lkotlinx/coroutines/internal/y;->p0()Lkotlinx/coroutines/internal/y;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string p1, "]"

    const-string p1, "]"

    const/4 v5, 0x2

    const-string p1, "]"

    const-string p1, "]"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string v0, "ieS)Abbi(noi.muourgpd(t)lc)rBgtlir(.lidSrntepnt"

    const-string v0, "lrBmnbgS(tcSpe(etorl).uiri(ptlgAuno)iit)dry.ind"

    const/4 v5, 0x4

    const-string v0, "lutil)ulSbonuiA.yrBri(rcon.edi)(pg(ttna)etpdirS"

    const-string v0, "StringBuilder().apply(builderAction).toString()"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-object p1
.end method

.method public isActive()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public k()Lkotlinx/coroutines/a3;
    .locals 2
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-super {p0}, Lkotlinx/coroutines/internal/y;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-object v0
.end method
