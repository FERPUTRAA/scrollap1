.class public final Lkotlinx/coroutines/f1;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDelay.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/DelayKt\n+ 2 CancellableContinuation.kt\nkotlinx/coroutines/CancellableContinuationKt\n*L\n1#1,147:1\n314#2,11:148\n314#2,11:159\n*S KotlinDebug\n*F\n+ 1 Delay.kt\nkotlinx/coroutines/DelayKt\n*L\n93#1:148,11\n113#1:159,11\n*E\n"
.end annotation


# direct methods
.method public static final a(Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p0    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    instance-of v0, p0, Lkotlinx/coroutines/f1$a;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    check-cast v0, Lkotlinx/coroutines/f1$a;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget v1, v0, Lkotlinx/coroutines/f1$a;->label:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/high16 v2, -0x80000000

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    and-int v3, v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    sub-int/2addr v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput v1, v0, Lkotlinx/coroutines/f1$a;->label:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Lkotlinx/coroutines/f1$a;

    const/4 v5, 0x3

    invoke-direct {v0, p0}, Lkotlinx/coroutines/f1$a;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object p0, v0, Lkotlinx/coroutines/f1$a;->result:Ljava/lang/Object;

    const/4 v5, 0x4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    iget v2, v0, Lkotlinx/coroutines/f1$a;->label:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eq v2, v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string v0, "/ossn tit/to/wf/e/o/ea nerb oc/ lliekesm cvuh /eiru"

    const-string/jumbo v0, "uws  is///otb/cceelan mooo/vrhteif/ /ue l tioeeknr/"

    const/4 v5, 0x3

    const-string v0, " /vmhoeoii/ uo e/wnrlur/  //aeeeimtsr/fkcbo/c etolt"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    throw p0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p0}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x1

    goto :goto_1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p0}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    iput v3, v0, Lkotlinx/coroutines/f1$a;->label:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance p0, Lkotlinx/coroutines/r;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v0}, Lkotlin/coroutines/intrinsics/b;->e(Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {p0, v2, v3}, Lkotlinx/coroutines/r;-><init>(Lkotlin/coroutines/d;I)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/r;->R()V

    const/4 v5, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/r;->w()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-ne p0, v2, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0}, Lkotlin/coroutines/jvm/internal/h;->c(Lkotlin/coroutines/d;)V

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-ne p0, v1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-object v1

    :cond_4
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance p0, Lkotlin/y;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {p0}, Lkotlin/y;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    throw p0
.end method

.method public static final b(JLkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-wide/16 v0, 0x0

    const/4 v4, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    cmp-long v0, p0, v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-gtz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object p0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v0, Lkotlinx/coroutines/r;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p2}, Lkotlin/coroutines/intrinsics/b;->e(Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2}, Lkotlinx/coroutines/r;-><init>(Lkotlin/coroutines/d;I)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0}, Lkotlinx/coroutines/r;->R()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const/4 v4, 0x1

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    cmp-long v1, p0, v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-gez v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {v0}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v1}, Lkotlinx/coroutines/f1;->d(Lkotlin/coroutines/g;)Lkotlinx/coroutines/e1;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {v1, p0, p1, v0}, Lkotlinx/coroutines/e1;->d(JLkotlinx/coroutines/q;)V

    :cond_1
    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v0}, Lkotlinx/coroutines/r;->w()Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-ne p0, p1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p2}, Lkotlin/coroutines/jvm/internal/h;->c(Lkotlin/coroutines/d;)V

    :cond_2
    const/4 v4, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-ne p0, p1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object p0

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object p0
.end method

.method public static final c(JLkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lkotlinx/coroutines/f1;->e(J)J

    move-result-wide p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/f1;->b(JLkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    if-ne p0, p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p0
.end method

.method public static final d(Lkotlin/coroutines/g;)Lkotlinx/coroutines/e1;
    .locals 3
    .param p0    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    sget-object v0, Lkotlin/coroutines/e;->l0:Lkotlin/coroutines/e$b;

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-interface {p0, v0}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    instance-of v0, p0, Lkotlinx/coroutines/e1;

    const/4 v2, 0x5

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    check-cast p0, Lkotlinx/coroutines/e1;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez p0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lkotlinx/coroutines/b1;->a()Lkotlinx/coroutines/e1;

    move-result-object p0

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0
.end method

.method public static final e(J)J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object v0, Lkotlin/time/e;->b:Lkotlin/time/e$a;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Lkotlin/time/e$a;->W()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p0, p1, v0, v1}, Lkotlin/time/e;->h(JJ)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-lez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lkotlin/time/e;->L(J)J

    move-result-wide p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x0

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0, p1, v0, v1}, Lkotlin/ranges/s;->v(JJ)J

    move-result-wide p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-wide/16 p0, 0x0

    const-wide/16 p0, 0x0

    const/4 v3, 0x6

    const-wide/16 p0, 0x0

    const-wide/16 p0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-wide p0
.end method
