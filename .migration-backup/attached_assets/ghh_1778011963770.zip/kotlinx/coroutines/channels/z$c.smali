.class final Lkotlinx/coroutines/channels/z$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/z;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field public final a:Ljava/lang/Object;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public final b:[Lkotlinx/coroutines/channels/z$d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlinx/coroutines/channels/z$d<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Object;[Lkotlinx/coroutines/channels/z$d;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # [Lkotlinx/coroutines/channels/z$d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "[",
            "Lkotlinx/coroutines/channels/z$d<",
            "TE;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/channels/z$c;->a:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p2, p0, Lkotlinx/coroutines/channels/z$c;->b:[Lkotlinx/coroutines/channels/z$d;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method
