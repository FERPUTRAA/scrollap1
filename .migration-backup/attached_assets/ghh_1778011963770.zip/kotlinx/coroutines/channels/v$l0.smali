.class final Lkotlinx/coroutines/channels/v$l0;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/v;->f0(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/p<",
        "Ljava/lang/Object;",
        "Ljava/lang/Object;",
        "Lkotlin/u0<",
        "Ljava/lang/Object;",
        "Ljava/lang/Object;",
        ">;>;"
    }
.end annotation


# static fields
.field public static final a:Lkotlinx/coroutines/channels/v$l0;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    new-instance v0, Lkotlinx/coroutines/channels/v$l0;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0}, Lkotlinx/coroutines/channels/v$l0;-><init>()V

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    sput-object v0, Lkotlinx/coroutines/channels/v$l0;->a:Lkotlinx/coroutines/channels/v$l0;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/u0;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ")",
            "Lkotlin/u0<",
            "Ljava/lang/Object;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p1, p2}, Lkotlin/q1;->a(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/u0;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$l0;->c(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/u0;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method
