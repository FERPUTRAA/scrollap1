.class Lkotlinx/coroutines/channels/k;
.super Lkotlinx/coroutines/a;

# interfaces
.implements Lkotlinx/coroutines/channels/g0;
.implements Lkotlinx/coroutines/channels/i;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/a<",
        "Lkotlin/s2;",
        ">;",
        "Lkotlinx/coroutines/channels/g0<",
        "TE;>;",
        "Lkotlinx/coroutines/channels/i<",
        "TE;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nBroadcast.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Broadcast.kt\nkotlinx/coroutines/channels/BroadcastCoroutine\n+ 2 JobSupport.kt\nkotlinx/coroutines/JobSupport\n*L\n1#1,199:1\n702#2,2:200\n702#2,2:202\n*S KotlinDebug\n*F\n+ 1 Broadcast.kt\nkotlinx/coroutines/channels/BroadcastCoroutine\n*L\n149#1:200,2\n154#1:202,2\n*E\n"
.end annotation


# instance fields
.field private final c:Lkotlinx/coroutines/channels/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/channels/i;Z)V
    .locals 3
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/channels/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "Lkotlinx/coroutines/channels/i<",
            "TE;>;Z)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0, p1, v0, p3}, Lkotlinx/coroutines/a;-><init>(Lkotlin/coroutines/g;ZZ)V

    const/4 v1, 0x3

    move v2, v1

    iput-object p2, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v1, 0x0

    move v2, v1

    sget-object p2, Lkotlinx/coroutines/n2;->n0:Lkotlinx/coroutines/n2$b;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {p1, p2}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p1, Lkotlinx/coroutines/n2;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/v2;->v0(Lkotlinx/coroutines/n2;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public C(Ljava/lang/Throwable;)Z
    .locals 3
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ss @~yut@f~c@ln@@of~o~@@ @ d@~1~~ i~~ ~~~o@ a@v@loS~ ~@b4 ~   m  @@~ oi@~b -K/M@ ~rb i~@/t.~~o@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/m0;->C(Ljava/lang/Throwable;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lkotlinx/coroutines/v2;->start()Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return p1
.end method

.method public D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 3
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0, p1, p2}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p1
.end method

.method public E()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {v0}, Lkotlinx/coroutines/channels/m0;->E()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public V(Ljava/lang/Throwable;)V
    .locals 4
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x2

    and-int/2addr v2, v1

    const/4 v3, 0x3

    invoke-static {p0, p1, v0, v1, v0}, Lkotlinx/coroutines/v2;->X0(Lkotlinx/coroutines/v2;Ljava/lang/Throwable;Ljava/lang/String;ILjava/lang/Object;)Ljava/util/concurrent/CancellationException;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/i;->cancel(Ljava/util/concurrent/CancellationException;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/v2;->T(Ljava/lang/Throwable;)Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public final cancel(Ljava/util/concurrent/CancellationException;)V
    .locals 4
    .param p1    # Ljava/util/concurrent/CancellationException;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance p1, Lkotlinx/coroutines/o2;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p0}, Lkotlinx/coroutines/v2;->I(Lkotlinx/coroutines/v2;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p1, v0, v1, p0}, Lkotlinx/coroutines/o2;-><init>(Ljava/lang/String;Ljava/lang/Throwable;Lkotlinx/coroutines/n2;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/k;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method public final synthetic cancel(Ljava/lang/Throwable;)Z
    .locals 4
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Since 1.2.0, binary compatibility with versions <= 1.1.x"
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    new-instance p1, Lkotlinx/coroutines/o2;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p0}, Lkotlinx/coroutines/v2;->I(Lkotlinx/coroutines/v2;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p1, v0, v1, p0}, Lkotlinx/coroutines/o2;-><init>(Ljava/lang/String;Ljava/lang/Throwable;Lkotlinx/coroutines/n2;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/k;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return p1
.end method

.method protected g1(Ljava/lang/Throwable;Z)V
    .locals 3
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/m0;->C(Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    if-nez p2, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lkotlinx/coroutines/a;->getContext()Lkotlin/coroutines/g;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p2, p1}, Lkotlinx/coroutines/r0;->b(Lkotlin/coroutines/g;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public getChannel()Lkotlinx/coroutines/channels/m0;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/m0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p0
.end method

.method public bridge synthetic h1(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x5

    check-cast p1, Lkotlin/s2;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/k;->k1(Lkotlin/s2;)V

    const/4 v0, 0x2

    shl-int/2addr v1, v0

    return-void
.end method

.method public isActive()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-super {p0}, Lkotlinx/coroutines/a;->isActive()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method protected final j1()Lkotlinx/coroutines/channels/i;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/i<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public k()Lkotlinx/coroutines/selects/e;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/selects/e<",
            "TE;",
            "Lkotlinx/coroutines/channels/m0<",
            "TE;>;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0}, Lkotlinx/coroutines/channels/m0;->k()Lkotlinx/coroutines/selects/e;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method protected k1(Lkotlin/s2;)V
    .locals 4
    .param p1    # Lkotlin/s2;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x6

    move v2, v0

    move v2, v0

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x5

    move v2, v1

    const/4 v3, 0x3

    invoke-static {p1, v0, v1, v0}, Lkotlinx/coroutines/channels/m0$a;->a(Lkotlinx/coroutines/channels/m0;Ljava/lang/Throwable;ILjava/lang/Object;)Z

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public l()Lkotlinx/coroutines/channels/i0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {v0}, Lkotlinx/coroutines/channels/i;->l()Lkotlinx/coroutines/channels/i0;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public offer(Ljava/lang/Object;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)Z"
        }
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'trySend\' method"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "trySend(element).isSuccess"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/m0;->offer(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return p1
.end method

.method public p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/m0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p1
.end method

.method public x(Li8/l;)V
    .locals 3
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/l<",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    .annotation build Lkotlinx/coroutines/c2;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/channels/k;->c:Lkotlinx/coroutines/channels/i;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/m0;->x(Li8/l;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method
