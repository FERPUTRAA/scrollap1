.class public final synthetic Lkotlinx/coroutines/channels/h$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1001
    name = "a"
.end annotation


# static fields
.field public static final synthetic a:[I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {}, Lkotlinx/coroutines/channels/m;->values()[Lkotlinx/coroutines/channels/m;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    array-length v0, v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-array v0, v0, [I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    sget-object v1, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    aput v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    sget-object v1, Lkotlinx/coroutines/channels/m;->c:Lkotlinx/coroutines/channels/m;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v2, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    aput v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v1, Lkotlinx/coroutines/channels/m;->b:Lkotlinx/coroutines/channels/m;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x3

    const/4 v4, 0x4

    aput v2, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    sput-object v0, Lkotlinx/coroutines/channels/h$a;->a:[I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void
.end method
