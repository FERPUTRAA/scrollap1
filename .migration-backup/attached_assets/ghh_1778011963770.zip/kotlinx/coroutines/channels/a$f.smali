.class final Lkotlinx/coroutines/channels/a$f;
.super Lkotlinx/coroutines/g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "f"
.end annotation


# instance fields
.field private final a:Lkotlinx/coroutines/channels/h0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/h0<",
            "*>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field final synthetic b:Lkotlinx/coroutines/channels/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/a<",
            "TE;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/channels/a;Lkotlinx/coroutines/channels/h0;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/a;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/h0<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/channels/a$f;->b:Lkotlinx/coroutines/channels/a;

    const/4 v0, 0x5

    xor-int/2addr v1, v0

    invoke-direct {p0}, Lkotlinx/coroutines/g;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p2, p0, Lkotlinx/coroutines/channels/a$f;->a:Lkotlinx/coroutines/channels/h0;

    const/4 v1, 0x3

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public c(Ljava/lang/Throwable;)V
    .locals 2
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  s~li~~ @4/@@ @c~tS- ~@slo@1 tK~~bo~ o @@ fM~@o~@@/~@i@@b @ ~~.md@br~~@yu~f@n~  v~o@~i ~~ a @o~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/channels/a$f;->a:Lkotlinx/coroutines/channels/h0;

    const/4 v1, 0x5

    invoke-virtual {p1}, Lkotlinx/coroutines/internal/y;->w0()Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    iget-object p1, p0, Lkotlinx/coroutines/channels/a$f;->b:Lkotlinx/coroutines/channels/a;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/a;->h0()V

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    check-cast p1, Ljava/lang/Throwable;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/a$f;->c(Ljava/lang/Throwable;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v1, "nnseovecOecRe[iaRCmvle"

    const/4 v3, 0x6

    const-string v1, "necm[RncCeemelOeevavRo"

    const-string v1, "RemoveReceiveOnCancel["

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/channels/a$f;->a:Lkotlinx/coroutines/channels/h0;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/16 v1, 0x5d

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0
.end method
