.class Lkotlinx/coroutines/channels/a$b;
.super Lkotlinx/coroutines/channels/h0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/h0<",
        "TE;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAbstractChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AbstractChannel.kt\nkotlinx/coroutines/channels/AbstractChannel$ReceiveElement\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 AbstractChannel.kt\nkotlinx/coroutines/channels/AbstractChannelKt\n*L\n1#1,1132:1\n1#2:1133\n1131#3:1134\n*S KotlinDebug\n*F\n+ 1 AbstractChannel.kt\nkotlinx/coroutines/channels/AbstractChannel$ReceiveElement\n*L\n912#1:1134\n*E\n"
.end annotation


# instance fields
.field public final d:Lkotlinx/coroutines/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/q<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public final e:I
    .annotation build Lh8/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/q;I)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/q<",
            "Ljava/lang/Object;",
            ">;I)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/channels/h0;-><init>()V

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/channels/a$b;->d:Lkotlinx/coroutines/q;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p2, p0, Lkotlinx/coroutines/channels/a$b;->e:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public F0(Lkotlinx/coroutines/channels/w;)V
    .locals 4
    .param p1    # Lkotlinx/coroutines/channels/w;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/w<",
            "*>;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "m~sovlt@  1s@4br ~~@ ~S/ ~@~~to@@~ @i~od@@b    i   yb~@.@K~/@ @~ ~~M@ ao~@@~@n f~i-~@f~~uolo~~@c"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget v0, p0, Lkotlinx/coroutines/channels/a$b;->e:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$b;->d:Lkotlinx/coroutines/q;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object v1, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object p1, p1, Lkotlinx/coroutines/channels/w;->d:Ljava/lang/Throwable;

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-virtual {v1, p1}, Lkotlinx/coroutines/channels/r$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p1}, Lkotlinx/coroutines/channels/r;->b(Ljava/lang/Object;)Lkotlinx/coroutines/channels/r;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object v1, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p1}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Lkotlin/coroutines/d;->resumeWith(Ljava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$b;->d:Lkotlinx/coroutines/q;

    const/4 v3, 0x5

    const/4 v2, 0x2

    sget-object v1, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/w;->K0()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p1}, Lkotlin/e1;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lkotlin/coroutines/d;->resumeWith(Ljava/lang/Object;)V

    :goto_0
    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public final G0(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v0, p0, Lkotlinx/coroutines/channels/a$b;->e:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    sget-object v0, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/channels/r$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1}, Lkotlinx/coroutines/channels/r;->b(Ljava/lang/Object;)Lkotlinx/coroutines/channels/r;

    move-result-object p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    return-object p1
.end method

.method public X(Ljava/lang/Object;Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;
    .locals 6
    .param p2    # Lkotlinx/coroutines/internal/y$d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/internal/y$d;",
            ")",
            "Lkotlinx/coroutines/internal/r0;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$b;->d:Lkotlinx/coroutines/q;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/a$b;->G0(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz p2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v3, p2, Lkotlinx/coroutines/internal/y$d;->c:Lkotlinx/coroutines/internal/y$a;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/h0;->E0(Ljava/lang/Object;)Li8/l;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {v0, v1, v3, p1}, Lkotlinx/coroutines/q;->G(Ljava/lang/Object;Ljava/lang/Object;Li8/l;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez p1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object v2

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz p2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p2}, Lkotlinx/coroutines/internal/y$d;->d()V

    :cond_2
    sget-object p1, Lkotlinx/coroutines/s;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-object p1
.end method

.method public r(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/channels/a$b;->d:Lkotlinx/coroutines/q;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Lkotlinx/coroutines/s;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    invoke-interface {p1, v0}, Lkotlinx/coroutines/q;->Z(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v1, "ivemEelecRntsem"

    const-string v1, "iesteRlEmeneevc"

    const/4 v3, 0x4

    const-string v1, "ltveocnemRE@eie"

    const-string v1, "ReceiveElement@"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p0}, Lkotlinx/coroutines/z0;->b(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string v1, "oerm=biedMcev"

    const-string/jumbo v1, "ve[mMrcieoed="

    const/4 v3, 0x5

    const-string v1, "[receiveMode="

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v1, p0, Lkotlinx/coroutines/channels/a$b;->e:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/16 v1, 0x5d

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v0
.end method
