.class public Lkotlinx/coroutines/channels/n0;
.super Lkotlinx/coroutines/channels/l0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/l0;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAbstractChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AbstractChannel.kt\nkotlinx/coroutines/channels/SendElement\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1132:1\n1#2:1133\n*E\n"
.end annotation


# instance fields
.field private final d:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TE;"
        }
    .end annotation
.end field

.field public final e:Lkotlinx/coroutines/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/q<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Object;Lkotlinx/coroutines/q;)V
    .locals 2
    .param p2    # Lkotlinx/coroutines/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/q<",
            "-",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/channels/l0;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/channels/n0;->d:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p2, p0, Lkotlinx/coroutines/channels/n0;->e:Lkotlinx/coroutines/q;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public D0()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "ols~o  @@ S~1@r@u @  @4i~~@~  f fo.~b~t~@t@@b@  c@~@ /~~~d@/ M@~@~-@~@~~lm   ~oKa@o~vbn y~~iios@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/n0;->e:Lkotlinx/coroutines/q;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v1, Lkotlinx/coroutines/s;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Lkotlinx/coroutines/q;->Z(Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public E0()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/channels/n0;->d:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public F0(Lkotlinx/coroutines/channels/w;)V
    .locals 4
    .param p1    # Lkotlinx/coroutines/channels/w;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/w<",
            "*>;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/n0;->e:Lkotlinx/coroutines/q;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v1, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/w;->L0()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p1}, Lkotlin/e1;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0, p1}, Lkotlin/coroutines/d;->resumeWith(Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method public G0(Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;
    .locals 6
    .param p1    # Lkotlinx/coroutines/internal/y$d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/n0;->e:Lkotlinx/coroutines/q;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    sget-object v1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz p1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    iget-object v3, p1, Lkotlinx/coroutines/internal/y$d;->c:Lkotlinx/coroutines/internal/y$a;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v0, v1, v3}, Lkotlinx/coroutines/q;->d(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    if-nez v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-object v2

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    if-eqz p1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1}, Lkotlinx/coroutines/internal/y$d;->d()V

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    sget-object p1, Lkotlinx/coroutines/s;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p0}, Lkotlinx/coroutines/z0;->a(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/16 v1, 0x40

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0}, Lkotlinx/coroutines/z0;->b(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/16 v1, 0x28

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/n0;->E0()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/16 v1, 0x29

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method
