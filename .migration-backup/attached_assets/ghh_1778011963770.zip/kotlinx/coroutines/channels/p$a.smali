.class public final Lkotlinx/coroutines/channels/p$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/p;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static synthetic a(Lkotlinx/coroutines/channels/p;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .annotation build Lh8/h;
        name = "next"
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Since 1.3.0, binary compatibility with versions <= 1.2.x"
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    instance-of v0, p1, Lkotlinx/coroutines/channels/p$a$a;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    check-cast v0, Lkotlinx/coroutines/channels/p$a$a;

    const/4 v5, 0x4

    iget v1, v0, Lkotlinx/coroutines/channels/p$a$a;->label:I

    const/4 v5, 0x2

    const/high16 v2, -0x80000000

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    and-int v3, v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    sub-int/2addr v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    iput v1, v0, Lkotlinx/coroutines/channels/p$a$a;->label:I

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v0, Lkotlinx/coroutines/channels/p$a$a;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {v0, p1}, Lkotlinx/coroutines/channels/p$a$a;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object p1, v0, Lkotlinx/coroutines/channels/p$a$a;->result:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    iget v2, v0, Lkotlinx/coroutines/channels/p$a$a;->label:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v2, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-ne v2, v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object p0, v0, Lkotlinx/coroutines/channels/p$a$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    check-cast p0, Lkotlinx/coroutines/channels/p;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string p1, "eusn/lor/o/t/recteiemcs/ s/ efuw/ / to iheakvo rlbn"

    const-string p1, " /ssi/r efu  rice trvem//unoleaoeih/o /clok//nttweb"

    const/4 v5, 0x7

    const-string p1, "le/mnttw  ermoue//iole/sko/ i eovbrr cfteac//hniuo/"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    throw p0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput-object p0, v0, Lkotlinx/coroutines/channels/p$a$a;->L$0:Ljava/lang/Object;

    iput v3, v0, Lkotlinx/coroutines/channels/p$a$a;->label:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-interface {p0, v0}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-ne p1, v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-object v1

    :cond_3
    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    check-cast p1, Ljava/lang/Boolean;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz p1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-interface {p0}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-object p0

    :cond_4
    new-instance p0, Lkotlinx/coroutines/channels/x;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string p1, "smolonden eaCwhlsa"

    const-string p1, "enomaehlsClc swand"

    const/4 v5, 0x7

    const-string/jumbo p1, "wloshbacden l Cnae"

    const-string p1, "Channel was closed"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/x;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    throw p0
.end method
