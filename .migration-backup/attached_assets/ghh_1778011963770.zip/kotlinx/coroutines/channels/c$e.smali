.class public final Lkotlinx/coroutines/channels/c$e;
.super Lkotlinx/coroutines/internal/y$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/c;->i(Lkotlinx/coroutines/channels/l0;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLockFreeLinkedList.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LockFreeLinkedList.kt\nkotlinx/coroutines/internal/LockFreeLinkedListNode$makeCondAddOp$1\n+ 2 AbstractChannel.kt\nkotlinx/coroutines/channels/AbstractSendChannel\n*L\n1#1,671:1\n255#2:672\n*E\n"
.end annotation


# instance fields
.field final synthetic d:Lkotlinx/coroutines/channels/c;


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/internal/y;Lkotlinx/coroutines/channels/c;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p2, p0, Lkotlinx/coroutines/channels/c$e;->d:Lkotlinx/coroutines/channels/c;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lkotlinx/coroutines/internal/y$c;-><init>(Lkotlinx/coroutines/internal/y;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public bridge synthetic i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~rsm@~/oo~ o  @~toaK/ib@@~ ~bl @Mifd @ib~@@~f~ yS~ ~t-4@@ ~~ @nvsu @1 c~~@@o~  ~  ~@o@.@l~~@@@~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    check-cast p1, Lkotlinx/coroutines/internal/y;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/c$e;->k(Lkotlinx/coroutines/internal/y;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public k(Lkotlinx/coroutines/internal/y;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/internal/y;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/channels/c$e;->d:Lkotlinx/coroutines/channels/c;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/c;->I()Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-static {}, Lkotlinx/coroutines/internal/x;->a()Ljava/lang/Object;

    move-result-object p1

    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method
