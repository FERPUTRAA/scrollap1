.class final Lkotlinx/coroutines/channels/v$y;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/v;->G(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "-TR;>;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.ChannelsKt__DeprecatedKt$mapIndexed$1"
    f = "Deprecated.kt"
    i = {
        0x0,
        0x0,
        0x1,
        0x1,
        0x2,
        0x2
    }
    l = {
        0x158,
        0x159,
        0x159
    }
    m = "invokeSuspend"
    n = {
        "$this$produce",
        "index",
        "$this$produce",
        "index",
        "$this$produce",
        "index"
    }
    s = {
        "L$0",
        "I$0",
        "L$0",
        "I$0",
        "L$0",
        "I$0"
    }
.end annotation


# instance fields
.field final synthetic $this_mapIndexed:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation
.end field

.field final synthetic $transform:Li8/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/q<",
            "Ljava/lang/Integer;",
            "TE;",
            "Lkotlin/coroutines/d<",
            "-TR;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field I$0:I

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/i0;Li8/q;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Li8/q<",
            "-",
            "Ljava/lang/Integer;",
            "-TE;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/v$y;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/channels/v$y;->$this_mapIndexed:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p2, p0, Lkotlinx/coroutines/channels/v$y;->$transform:Li8/q;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 p1, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v0, Lkotlinx/coroutines/channels/v$y;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$y;->$this_mapIndexed:Lkotlinx/coroutines/channels/i0;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v2, p0, Lkotlinx/coroutines/channels/v$y;->$transform:Li8/q;

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/channels/v$y;-><init>(Lkotlinx/coroutines/channels/i0;Li8/q;Lkotlin/coroutines/d;)V

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$y;->L$0:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$y;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    iget v1, p0, Lkotlinx/coroutines/channels/v$y;->label:I

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    const/4 v2, 0x3

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x7

    const/4 v3, 0x2

    const/4 v11, 0x5

    shl-int/2addr v12, v11

    const/4 v4, 0x1

    or-int/2addr v12, v4

    const/4 v11, 0x3

    const/4 v12, 0x1

    if-eqz v1, :cond_3

    const/4 v11, 0x4

    move v12, v11

    if-eq v1, v4, :cond_2

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x6

    if-eq v1, v3, :cond_1

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x3

    if-ne v1, v2, :cond_0

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget v1, p0, Lkotlinx/coroutines/channels/v$y;->I$0:I

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$y;->L$1:Ljava/lang/Object;

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x7

    check-cast v5, Lkotlinx/coroutines/channels/p;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x1

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$y;->L$0:Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x3

    check-cast v6, Lkotlinx/coroutines/channels/g0;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x3

    goto/16 :goto_0

    :cond_0
    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x3

    const-string/jumbo v0, "v slseou/b /morreoi/ecun  st t/rank/eiw //litoo/hef"

    const-string v0, "k sbe /lmvtiric/tt w//ooaunr uoh/eci/nelrso /ef/o e"

    const/4 v12, 0x5

    const-string/jumbo v0, "uramrmoeo/hrtlceeowe o foniub/in/ev/cti tk /s/l e /"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x0

    throw p1

    :cond_1
    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x1

    iget v1, p0, Lkotlinx/coroutines/channels/v$y;->I$0:I

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x6

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$y;->L$2:Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x4

    check-cast v5, Lkotlinx/coroutines/channels/g0;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x1

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$y;->L$1:Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x7

    check-cast v6, Lkotlinx/coroutines/channels/p;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x7

    iget-object v7, p0, Lkotlinx/coroutines/channels/v$y;->L$0:Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    check-cast v7, Lkotlinx/coroutines/channels/g0;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v8, p0

    move-object v8, p0

    move-object v8, p0

    move-object v8, p0

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x3

    goto/16 :goto_2

    :cond_2
    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x3

    iget v1, p0, Lkotlinx/coroutines/channels/v$y;->I$0:I

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$y;->L$1:Ljava/lang/Object;

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x5

    check-cast v5, Lkotlinx/coroutines/channels/p;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$y;->L$0:Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x0

    check-cast v6, Lkotlinx/coroutines/channels/g0;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v7, p0

    move-object v7, p0

    move-object v7, p0

    move-object v7, p0

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x6

    goto :goto_1

    :cond_3
    const/4 v12, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/channels/v$y;->L$0:Ljava/lang/Object;

    const/4 v12, 0x4

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v11, 0x6

    and-int/2addr v12, v11

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$y;->$this_mapIndexed:Lkotlinx/coroutines/channels/i0;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-interface {v1}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v1

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x0

    const/4 v5, 0x0

    move-object v6, p0

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    move v10, v5

    move v10, v5

    const/4 v12, 0x5

    move v10, v5

    move v10, v5

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    move v1, v10

    move v1, v10

    :goto_0
    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    iput-object p1, v6, Lkotlinx/coroutines/channels/v$y;->L$0:Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    iput-object v5, v6, Lkotlinx/coroutines/channels/v$y;->L$1:Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x1

    iput v1, v6, Lkotlinx/coroutines/channels/v$y;->I$0:I

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x0

    iput v4, v6, Lkotlinx/coroutines/channels/v$y;->label:I

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-interface {v5, v6}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v7

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    if-ne v7, v0, :cond_4

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    return-object v0

    :cond_4
    move-object v10, v6

    move-object v10, v6

    move-object v10, v6

    move-object v10, v6

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object v7, v10

    move-object v7, v10

    move-object v7, v10

    move-object v7, v10

    :goto_1
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x5

    check-cast p1, Ljava/lang/Boolean;

    const/4 v11, 0x5

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x2

    if-eqz p1, :cond_7

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-interface {v5}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    iget-object v8, v7, Lkotlinx/coroutines/channels/v$y;->$transform:Li8/q;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x2

    add-int/lit8 v9, v1, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-static {v1}, Lkotlin/coroutines/jvm/internal/b;->f(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x5

    iput-object v6, v7, Lkotlinx/coroutines/channels/v$y;->L$0:Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    iput-object v5, v7, Lkotlinx/coroutines/channels/v$y;->L$1:Ljava/lang/Object;

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    iput-object v6, v7, Lkotlinx/coroutines/channels/v$y;->L$2:Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x2

    iput v9, v7, Lkotlinx/coroutines/channels/v$y;->I$0:I

    const/4 v12, 0x5

    iput v3, v7, Lkotlinx/coroutines/channels/v$y;->label:I

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-interface {v8, v1, p1, v7}, Li8/q;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x1

    if-ne p1, v0, :cond_5

    const/4 v12, 0x6

    const/4 v11, 0x3

    return-object v0

    :cond_5
    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    move v1, v9

    move v1, v9

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v6, v5

    move-object v6, v5

    move-object v5, v7

    move-object v5, v7

    move-object v5, v7

    move-object v5, v7

    :goto_2
    const/4 v12, 0x1

    const/4 v11, 0x0

    iput-object v7, v8, Lkotlinx/coroutines/channels/v$y;->L$0:Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x1

    iput-object v6, v8, Lkotlinx/coroutines/channels/v$y;->L$1:Ljava/lang/Object;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v9, 0x0

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x7

    iput-object v9, v8, Lkotlinx/coroutines/channels/v$y;->L$2:Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x2

    iput v1, v8, Lkotlinx/coroutines/channels/v$y;->I$0:I

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x2

    iput v2, v8, Lkotlinx/coroutines/channels/v$y;->label:I

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-interface {v5, p1, v8}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-ne p1, v0, :cond_6

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    return-object v0

    :cond_6
    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object v6, v8

    move-object v6, v8

    move-object v6, v8

    move-object v6, v8

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x1

    goto/16 :goto_0

    :cond_7
    const/4 v12, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x2

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$y;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    check-cast p1, Lkotlinx/coroutines/channels/v$y;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/v$y;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method
