.class public final Lkotlinx/coroutines/channels/i0$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/selects/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/i0$a;->d(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/selects/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/selects/d<",
        "TE;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/i0;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/channels/i0$a$a;->a:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public o(Lkotlinx/coroutines/selects/f;Li8/p;)V
    .locals 5
    .param p1    # Lkotlinx/coroutines/selects/f;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/selects/f<",
            "-TR;>;",
            "Li8/p<",
            "-TE;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    .annotation build Lkotlinx/coroutines/i2;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/channels/i0$a$a;->a:Lkotlinx/coroutines/channels/i0;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-interface {v0}, Lkotlinx/coroutines/channels/i0;->u()Lkotlinx/coroutines/selects/d;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v1, Lkotlinx/coroutines/channels/i0$a$a$a;

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x1

    or-int/2addr v3, v2

    const/4 v4, 0x3

    invoke-direct {v1, p2, v2}, Lkotlinx/coroutines/channels/i0$a$a$a;-><init>(Li8/p;Lkotlin/coroutines/d;)V

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {v0, p1, v1}, Lkotlinx/coroutines/selects/d;->o(Lkotlinx/coroutines/selects/f;Li8/p;)V

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-void
.end method
