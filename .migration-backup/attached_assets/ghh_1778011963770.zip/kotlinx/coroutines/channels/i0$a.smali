.class public final Lkotlinx/coroutines/channels/i0$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static synthetic a(Lkotlinx/coroutines/channels/i0;)V
    .locals 3
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Since 1.2.0, binary compatibility with versions <= 1.1.x"
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s @ bf ~-t ~ K/~tb~o @@~i@~l ~@oi@mMdS@  @@1o~afi~ ~y~os @n~ bo  ~~@~@c@ ~~/4~r@.~u~@@~v l o@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {p0, v0}, Lkotlinx/coroutines/channels/i0;->cancel(Ljava/util/concurrent/CancellationException;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public static synthetic b(Lkotlinx/coroutines/channels/i0;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    if-nez p3, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-eqz p2, :cond_0

    const/4 v1, 0x4

    const/4 p1, 0x0

    and-int/2addr v0, p1

    :cond_0
    const/4 v1, 0x3

    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/i0;->cancel(Ljava/util/concurrent/CancellationException;)V

    const/4 v1, 0x5

    return-void

    :cond_1
    const/4 v0, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    const-string p1, "logm ciatSruf mrtuu nieppactpngs hnetue e utdrlsiatrnho t tsfacss  oin:tw ecella,"

    const-string p1, "f scra ed nlh:ilseSt eniufsrmee ggntcta  pawoelit trtts picdusarlhuptntacnu , oou"

    const/4 v1, 0x2

    const-string p1, "ahr oe tlSemsenpa detrusuilhftfpcnlogt og,pe ntu nnecaut:dloitcwc rs  rnta iut si"

    const-string p1, "Super calls with default arguments not supported in this target, function: cancel"

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    throw p0
.end method

.method public static synthetic c(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;ILjava/lang/Object;)Z
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    if-nez p3, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    if-eqz p2, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    const/4 p1, 0x0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/i0;->cancel(Ljava/lang/Throwable;)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p0

    :cond_1
    const/4 v1, 0x6

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    const-string p1, "sufe bpaat e ml niaanehimdnrgitrthrc u aSw cdoelpul rtntiessofcg n,pe:ottu ttuncl"

    const-string p1, "c cmnlttta resuc np te:oufnro  pf e srmiSelasarlthsi,ltdi ggdtepuictun wnuaneoaht"

    const/4 v1, 0x2

    const-string p1, " tettwuuoid  rd  fslar,aalinogsatee phatSe tcccpeu mrnuo i hcrns:tuegn siplfttunn"

    const-string p1, "Super calls with default arguments not supported in this target, function: cancel"

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    throw p0
.end method

.method public static d(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/selects/d;
    .locals 3
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;)",
            "Lkotlinx/coroutines/selects/d<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Lkotlinx/coroutines/channels/i0$a$a;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lkotlinx/coroutines/channels/i0$a$a;-><init>(Lkotlinx/coroutines/channels/i0;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public static synthetic e()V
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in favor of onReceiveCatching extension"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "onReceiveCatching"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public static synthetic f()V
    .locals 2
    .annotation build Lkotlinx/coroutines/c2;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public static synthetic g()V
    .locals 2
    .annotation build Lkotlinx/coroutines/c2;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public static h(Lkotlinx/coroutines/channels/i0;)Ljava/lang/Object;
    .locals 3
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;)TE;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'tryReceive\'. Please note that the provided replacement does not rethrow channel\'s close cause as \'poll\' did, for the precise replacement please refer to the \'poll\' documentation"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "tryReceive().getOrNull()"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {p0}, Lkotlinx/coroutines/channels/i0;->y()Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p0}, Lkotlinx/coroutines/channels/r;->m(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    invoke-static {p0}, Lkotlinx/coroutines/channels/r;->i(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p0}, Lkotlinx/coroutines/channels/r;->f(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez p0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p0}, Lkotlinx/coroutines/internal/q0;->p(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    throw p0
.end method

.method public static i(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlin/coroutines/d<",
            "-TE;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation build Lkotlin/internal/h;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in favor of \'receiveCatching\'. Please note that the provided replacement does not rethrow channel\'s close cause as \'receiveOrNull\' did, for the detailed replacement please refer to the \'receiveOrNull\' documentation"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "receiveCatching().getOrNull()"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    instance-of v0, p1, Lkotlinx/coroutines/channels/i0$a$b;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    check-cast v0, Lkotlinx/coroutines/channels/i0$a$b;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget v1, v0, Lkotlinx/coroutines/channels/i0$a$b;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/high16 v2, -0x80000000

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    and-int v3, v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v3, :cond_0

    sub-int/2addr v1, v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput v1, v0, Lkotlinx/coroutines/channels/i0$a$b;->label:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v0, Lkotlinx/coroutines/channels/i0$a$b;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {v0, p1}, Lkotlinx/coroutines/channels/i0$a$b;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object p1, v0, Lkotlinx/coroutines/channels/i0$a$b;->result:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x6

    iget v2, v0, Lkotlinx/coroutines/channels/i0$a$b;->label:I

    const/4 v5, 0x7

    const/4 v3, 0x1

    const/4 v5, 0x3

    move v4, v3

    move v4, v3

    const/4 v5, 0x4

    if-eqz v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-ne v2, v3, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    check-cast p1, Lkotlinx/coroutines/channels/r;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/r;->o()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string p1, "innso//puewoto/ir eka cuebml/ che l oeti/ e/fo/vrot"

    const-string/jumbo p1, "voeuooc///toefoe/ irrcmtlae/n/h  k wob/iu sniet l/e"

    const/4 v5, 0x3

    const-string p1, "kr eb/l q/euaf/ o/eowr/ ios/ttu enne htioreiov//ccm"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    throw p0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput v3, v0, Lkotlinx/coroutines/channels/i0$a$b;->label:I

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {p0, v0}, Lkotlinx/coroutines/channels/i0;->A(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-ne p0, v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-object v1

    :cond_3
    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p0}, Lkotlinx/coroutines/channels/r;->h(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-object p0
.end method
