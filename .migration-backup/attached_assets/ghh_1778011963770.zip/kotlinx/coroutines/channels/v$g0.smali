.class final Lkotlinx/coroutines/channels/v$g0;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/v;->U(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "Ljava/lang/Object;",
        ">;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.ChannelsKt__DeprecatedKt$takeWhile$1"
    f = "Deprecated.kt"
    i = {
        0x0,
        0x1,
        0x1,
        0x2
    }
    l = {
        0x10d,
        0x10e,
        0x10f
    }
    m = "invokeSuspend"
    n = {
        "$this$produce",
        "$this$produce",
        "e",
        "$this$produce"
    }
    s = {
        "L$0",
        "L$0",
        "L$2",
        "L$0"
    }
.end annotation


# instance fields
.field final synthetic $predicate:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $this_takeWhile:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/i0;Li8/p;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;",
            "Li8/p<",
            "Ljava/lang/Object;",
            "-",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/v$g0;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/channels/v$g0;->$this_takeWhile:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/channels/v$g0;->$predicate:Li8/p;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    const/4 p1, 0x2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x5

    new-instance v0, Lkotlinx/coroutines/channels/v$g0;

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$g0;->$this_takeWhile:Lkotlinx/coroutines/channels/i0;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v2, p0, Lkotlinx/coroutines/channels/v$g0;->$predicate:Li8/p;

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/channels/v$g0;-><init>(Lkotlinx/coroutines/channels/i0;Li8/p;Lkotlin/coroutines/d;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$g0;->L$0:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$g0;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget v1, p0, Lkotlinx/coroutines/channels/v$g0;->label:I

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    const/4 v2, 0x3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v3, 0x2

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    const/4 v4, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eqz v1, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-eq v1, v4, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eq v1, v3, :cond_1

    const/4 v9, 0x4

    or-int/2addr v10, v9

    if-ne v1, v2, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$g0;->L$1:Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v10, 0x2

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$g0;->L$0:Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    check-cast v5, Lkotlinx/coroutines/channels/g0;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v10, 0x7

    goto/16 :goto_0

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string v0, "ktsl  oh/n /trwv /o/imi/i atrncoel //ueeceobuss/eef"

    const-string v0, "/rshseoiocv/nt e/lco/reoekefulb  mtrnwtia /i/e  u//"

    const/4 v10, 0x4

    const-string v0, " eom  eoilto//bniee or/ew/htcu t/nmleocf/k/s au/rvr"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    throw p1

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$g0;->L$2:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$g0;->L$1:Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    check-cast v5, Lkotlinx/coroutines/channels/p;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$g0;->L$0:Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    check-cast v6, Lkotlinx/coroutines/channels/g0;

    const/4 v10, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    goto/16 :goto_3

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$g0;->L$1:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$g0;->L$0:Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    check-cast v5, Lkotlinx/coroutines/channels/g0;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    goto :goto_2

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/channels/v$g0;->L$0:Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v9, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$g0;->$this_takeWhile:Lkotlinx/coroutines/channels/i0;

    const/4 v9, 0x3

    shr-int/2addr v10, v9

    invoke-interface {v1}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    :goto_0
    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    :goto_1
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    iput-object v5, p1, Lkotlinx/coroutines/channels/v$g0;->L$0:Ljava/lang/Object;

    iput-object v1, p1, Lkotlinx/coroutines/channels/v$g0;->L$1:Ljava/lang/Object;

    const/4 v10, 0x7

    iput v4, p1, Lkotlinx/coroutines/channels/v$g0;->label:I

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-interface {v1, p1}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-ne v6, v0, :cond_4

    const/4 v10, 0x4

    return-object v0

    :cond_4
    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    :goto_2
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    check-cast p1, Ljava/lang/Boolean;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-eqz p1, :cond_8

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-interface {v5}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x6

    iget-object v7, v0, Lkotlinx/coroutines/channels/v$g0;->$predicate:Li8/p;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    iput-object v6, v0, Lkotlinx/coroutines/channels/v$g0;->L$0:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    iput-object v5, v0, Lkotlinx/coroutines/channels/v$g0;->L$1:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$g0;->L$2:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    iput v3, v0, Lkotlinx/coroutines/channels/v$g0;->label:I

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-interface {v7, p1, v0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    if-ne v7, v1, :cond_5

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    return-object v1

    :cond_5
    move-object v8, v5

    move-object v8, v5

    move-object v8, v5

    move-object v8, v5

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v6, v8

    move-object v6, v8

    move-object v6, v8

    move-object v6, v8

    :goto_3
    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    check-cast p1, Ljava/lang/Boolean;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-nez p1, :cond_6

    const/4 v10, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    return-object p1

    :cond_6
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    iput-object v7, v0, Lkotlinx/coroutines/channels/v$g0;->L$0:Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    iput-object v6, v0, Lkotlinx/coroutines/channels/v$g0;->L$1:Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/4 p1, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$g0;->L$2:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    iput v2, v0, Lkotlinx/coroutines/channels/v$g0;->label:I

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-interface {v7, v5, v0}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-ne p1, v1, :cond_7

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    return-object v1

    :cond_7
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v5, v7

    move-object v5, v7

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    goto/16 :goto_1

    :cond_8
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$g0;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    check-cast p1, Lkotlinx/coroutines/channels/v$g0;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/v$g0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p1
.end method
