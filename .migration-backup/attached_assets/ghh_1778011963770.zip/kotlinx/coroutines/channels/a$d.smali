.class Lkotlinx/coroutines/channels/a$d;
.super Lkotlinx/coroutines/channels/h0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/h0<",
        "TE;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAbstractChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AbstractChannel.kt\nkotlinx/coroutines/channels/AbstractChannel$ReceiveHasNext\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1132:1\n1#2:1133\n*E\n"
.end annotation


# instance fields
.field public final d:Lkotlinx/coroutines/channels/a$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/a$a<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public final e:Lkotlinx/coroutines/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/q<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/channels/a$a;Lkotlinx/coroutines/q;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/a$a;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/a$a<",
            "TE;>;",
            "Lkotlinx/coroutines/q<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/channels/h0;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/channels/a$d;->d:Lkotlinx/coroutines/channels/a$a;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/channels/a$d;->e:Lkotlinx/coroutines/q;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public E0(Ljava/lang/Object;)Li8/l;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Li8/l<",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$d;->d:Lkotlinx/coroutines/channels/a$a;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, v0, Lkotlinx/coroutines/channels/a$a;->a:Lkotlinx/coroutines/channels/a;

    const/4 v3, 0x4

    const/4 v2, 0x7

    iget-object v0, v0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/channels/a$d;->e:Lkotlinx/coroutines/q;

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-interface {v1}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0, p1, v1}, Lkotlinx/coroutines/internal/i0;->a(Li8/l;Ljava/lang/Object;Lkotlin/coroutines/g;)Li8/l;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p1
.end method

.method public F0(Lkotlinx/coroutines/channels/w;)V
    .locals 6
    .param p1    # Lkotlinx/coroutines/channels/w;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/w<",
            "*>;)V"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v0, p1, Lkotlinx/coroutines/channels/w;->d:Ljava/lang/Throwable;

    const/4 v5, 0x2

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$d;->e:Lkotlinx/coroutines/q;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v5, 0x2

    const/4 v2, 0x2

    const/4 v5, 0x2

    move v4, v2

    move v4, v2

    const/4 v5, 0x2

    const/4 v3, 0x7

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v0, v1, v3, v2, v3}, Lkotlinx/coroutines/q$a;->b(Lkotlinx/coroutines/q;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$d;->e:Lkotlinx/coroutines/q;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/w;->K0()Ljava/lang/Throwable;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {v0, v1}, Lkotlinx/coroutines/q;->n(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/channels/a$d;->d:Lkotlinx/coroutines/channels/a$a;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1, p1}, Lkotlinx/coroutines/channels/a$a;->g(Ljava/lang/Object;)V

    const/4 v5, 0x6

    iget-object p1, p0, Lkotlinx/coroutines/channels/a$d;->e:Lkotlinx/coroutines/q;

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-interface {p1, v0}, Lkotlinx/coroutines/q;->Z(Ljava/lang/Object;)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    return-void
.end method

.method public X(Ljava/lang/Object;Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;
    .locals 6
    .param p2    # Lkotlinx/coroutines/internal/y$d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/internal/y$d;",
            ")",
            "Lkotlinx/coroutines/internal/r0;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$d;->e:Lkotlinx/coroutines/q;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz p2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v3, p2, Lkotlinx/coroutines/internal/y$d;->c:Lkotlinx/coroutines/internal/y$a;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/a$d;->E0(Ljava/lang/Object;)Li8/l;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-interface {v0, v1, v3, p1}, Lkotlinx/coroutines/q;->G(Ljava/lang/Object;Ljava/lang/Object;Li8/l;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-nez p1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-object v2

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz p2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p2}, Lkotlinx/coroutines/internal/y$d;->d()V

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-object p1, Lkotlinx/coroutines/s;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-object p1
.end method

.method public r(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$d;->d:Lkotlinx/coroutines/channels/a$a;

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/channels/a$a;->g(Ljava/lang/Object;)V

    const/4 v2, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/channels/a$d;->e:Lkotlinx/coroutines/q;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lkotlinx/coroutines/s;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {p1, v0}, Lkotlinx/coroutines/q;->Z(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v1, "asssxR@eHcevtNe"

    const-string v1, "e@sexetNvcaeRHs"

    const/4 v3, 0x6

    const-string v1, "extmReNceves@ia"

    const-string v1, "ReceiveHasNext@"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0}, Lkotlinx/coroutines/z0;->b(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0
.end method
