.class public final Lkotlinx/coroutines/channels/r;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/channels/r$c;,
        Lkotlinx/coroutines/channels/r$a;,
        Lkotlinx/coroutines/channels/r$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation runtime Lh8/f;
.end annotation


# static fields
.field public static final b:Lkotlinx/coroutines/channels/r$b;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final c:Lkotlinx/coroutines/channels/r$c;
    .annotation build Lia/d;
    .end annotation
.end field


# instance fields
.field private final a:Ljava/lang/Object;
    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Lkotlinx/coroutines/channels/r$b;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lkotlinx/coroutines/channels/r$b;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    sput-object v0, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Lkotlinx/coroutines/channels/r$c;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0}, Lkotlinx/coroutines/channels/r$c;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    sput-object v0, Lkotlinx/coroutines/channels/r;->c:Lkotlinx/coroutines/channels/r$c;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method private synthetic constructor <init>(Ljava/lang/Object;)V
    .locals 2
    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/channels/r;->a:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static final synthetic a()Lkotlinx/coroutines/channels/r$c;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "nrs ~u@@o@d/~t@@ o.f  @@l~@4~ @a~l~~@m@@~~~bo1~i~ c@@~@~  ~ib~ ~  @oo~-foK / v@@~~bMs @i@~ Sy t "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lkotlinx/coroutines/channels/r;->c:Lkotlinx/coroutines/channels/r$c;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public static final synthetic b(Ljava/lang/Object;)Lkotlinx/coroutines/channels/r;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Lkotlinx/coroutines/channels/r;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lkotlinx/coroutines/channels/r;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public static c(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p0    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Object;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public static d(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    instance-of v0, p1, Lkotlinx/coroutines/channels/r;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast p1, Lkotlinx/coroutines/channels/r;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/r;->o()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez p0, :cond_1

    const/4 v3, 0x6

    return v1

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p0
.end method

.method public static final e(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p0
.end method

.method public static final f(Ljava/lang/Object;)Ljava/lang/Throwable;
    .locals 4
    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    instance-of v0, p0, Lkotlinx/coroutines/channels/r$a;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast p0, Lkotlinx/coroutines/channels/r$a;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p0, :cond_1

    const/4 v2, 0x5

    move v3, v2

    iget-object v1, p0, Lkotlinx/coroutines/channels/r$a;->a:Ljava/lang/Throwable;

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v1
.end method

.method public static synthetic g()V
    .locals 2
    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method

.method public static final h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    instance-of v0, p0, Lkotlinx/coroutines/channels/r$c;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method public static final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    instance-of v0, p0, Lkotlinx/coroutines/channels/r$c;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object p0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    instance-of v0, p0, Lkotlinx/coroutines/channels/r$a;

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v4, 0x6

    const/4 v3, 0x7

    check-cast v0, Lkotlinx/coroutines/channels/r$a;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, v0, Lkotlinx/coroutines/channels/r$a;->a:Ljava/lang/Throwable;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    throw v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v2, "/gTmenng aiO totancy sld lTr cn ltlle/w r/ oarfursi/h:eah "

    const-string v2, "O soTttif n  herd/nllae/eruytiolane/ /al:c h c  grlTasnwgr"

    const/4 v4, 0x6

    const-string v2, "l c orOTraoatnlutoyei t hw s el/fane: /orl dTnn/lch r/gaei"

    const-string v2, "Trying to call \'getOrThrow\' on a failed channel result: "

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    throw v0
.end method

.method public static j(Ljava/lang/Object;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    if-nez p0, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    const/4 p0, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return p0
.end method

.method public static final k(Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    instance-of p0, p0, Lkotlinx/coroutines/channels/r$a;

    const/4 v1, 0x7

    const/4 v0, 0x4

    return p0
.end method

.method public static final l(Ljava/lang/Object;)Z
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    instance-of p0, p0, Lkotlinx/coroutines/channels/r$c;

    const/4 v1, 0x2

    return p0
.end method

.method public static final m(Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    instance-of p0, p0, Lkotlinx/coroutines/channels/r$c;

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    xor-int/lit8 p0, p0, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p0
.end method

.method public static n(Ljava/lang/Object;)Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    instance-of v0, p0, Lkotlinx/coroutines/channels/r$a;

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast p0, Lkotlinx/coroutines/channels/r$a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/r$a;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const-string v1, "aleVmb"

    const-string v1, "leamuV"

    const/4 v3, 0x2

    const-string/jumbo v1, "ulV(eu"

    const-string v1, "Value("

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/16 p0, 0x29

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/r;->a:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    invoke-static {v0, p1}, Lkotlinx/coroutines/channels/r;->d(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p1
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/r;->a:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v0}, Lkotlinx/coroutines/channels/r;->j(Ljava/lang/Object;)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public final synthetic o()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/r;->a:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/channels/r;->a:Ljava/lang/Object;

    const/4 v2, 0x5

    invoke-static {v0}, Lkotlinx/coroutines/channels/r;->n(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method
