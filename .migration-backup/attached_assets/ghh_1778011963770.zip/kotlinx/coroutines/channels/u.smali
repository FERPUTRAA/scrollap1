.class final synthetic Lkotlinx/coroutines/channels/u;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nChannels.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Channels.common.kt\nkotlinx/coroutines/channels/ChannelsKt__Channels_commonKt\n*L\n1#1,140:1\n80#1,11:141\n103#1:152\n80#1,6:153\n104#1,2:159\n90#1:161\n86#1,4:162\n31#1,5:166\n*S KotlinDebug\n*F\n+ 1 Channels.common.kt\nkotlinx/coroutines/channels/ChannelsKt__Channels_commonKt\n*L\n103#1:141,11\n115#1:152\n115#1:153,6\n115#1:159,2\n115#1:161\n115#1:162,4\n128#1:166,5\n*E\n"
.end annotation


# direct methods
.method public static final a(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V
    .locals 4
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "*>;",
            "Ljava/lang/Throwable;",
            ")V"
        }
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    instance-of v1, p1, Ljava/util/concurrent/CancellationException;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Ljava/util/concurrent/CancellationException;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string v0, "lwsfmCneen dsa nnau a  ismasrd,cdocheeohl"

    const-string v0, "ehsom ndeC easaaro,smuhelddnilcs cnw a fn"

    const-string v0, " ncmae eddsCdwsm la cn,hfhsmeoarluauoein "

    const-string v0, "Channel was consumed, consumer had failed"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lkotlinx/coroutines/y1;->a(Ljava/lang/String;Ljava/lang/Throwable;)Ljava/util/concurrent/CancellationException;

    move-result-object p1

    move-object v0, p1

    move-object v0, p1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {p0, v0}, Lkotlinx/coroutines/channels/i0;->cancel(Ljava/util/concurrent/CancellationException;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public static final b(Lkotlinx/coroutines/channels/i;Li8/l;)Ljava/lang/Object;
    .locals 4
    .param p0    # Lkotlinx/coroutines/channels/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i<",
            "TE;>;",
            "Li8/l<",
            "-",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;+TR;>;)TR;"
        }
    .end annotation

    .annotation build Lkotlinx/coroutines/e3;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {p0}, Lkotlinx/coroutines/channels/i;->l()Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    const/4 v1, 0x3

    const/4 v1, 0x1

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p1, p0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v1}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p0, v0, v1, v0}, Lkotlinx/coroutines/channels/i0$a;->b(Lkotlinx/coroutines/channels/i0;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v1}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v3, 0x6

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-static {v1}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0, v0, v1, v0}, Lkotlinx/coroutines/channels/i0$a;->b(Lkotlinx/coroutines/channels/i0;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v1}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw p1
.end method

.method public static final c(Lkotlinx/coroutines/channels/i0;Li8/l;)Ljava/lang/Object;
    .locals 4
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Li8/l<",
            "-",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;+TR;>;)TR;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x1

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {p1, p0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0, v1}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object p1

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    throw v1
.end method

.method public static final d(Lkotlinx/coroutines/channels/i;Li8/l;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 8
    .param p0    # Lkotlinx/coroutines/channels/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i<",
            "TE;>;",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation build Lkotlinx/coroutines/e3;
    .end annotation

    const/4 v6, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    instance-of v0, p2, Lkotlinx/coroutines/channels/u$b;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    check-cast v0, Lkotlinx/coroutines/channels/u$b;

    const/4 v7, 0x4

    const/4 v6, 0x2

    iget v1, v0, Lkotlinx/coroutines/channels/u$b;->label:I

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/high16 v2, -0x80000000

    const/4 v7, 0x3

    const/4 v6, 0x2

    and-int v3, v1, v2

    const/4 v6, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v3, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    sub-int/2addr v1, v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput v1, v0, Lkotlinx/coroutines/channels/u$b;->label:I

    const/4 v6, 0x0

    or-int/2addr v7, v6

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v7, 0x6

    new-instance v0, Lkotlinx/coroutines/channels/u$b;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {v0, p2}, Lkotlinx/coroutines/channels/u$b;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object p2, v0, Lkotlinx/coroutines/channels/u$b;->result:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget v2, v0, Lkotlinx/coroutines/channels/u$b;->label:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v4, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v2, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-ne v2, v4, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object p0, v0, Lkotlinx/coroutines/channels/u$b;->L$2:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    check-cast p0, Lkotlinx/coroutines/channels/p;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object p1, v0, Lkotlinx/coroutines/channels/u$b;->L$1:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    check-cast p1, Lkotlinx/coroutines/channels/i0;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v2, v0, Lkotlinx/coroutines/channels/u$b;->L$0:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    check-cast v2, Li8/l;

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v5, v0

    move-object v5, v0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    :goto_1
    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    const/4 v7, 0x5

    const/4 v6, 0x2

    goto :goto_3

    :catchall_0
    move-exception p0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto/16 :goto_4

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string/jumbo p1, "tvn/oil   /t/ bee//om//rrneuekeofootmeaulicc so rw/"

    const-string/jumbo p1, "tvrm r//b c ento k/eeouoit/oeofm/iwll/e a /scnre/hu"

    const/4 v7, 0x5

    const-string/jumbo p1, "uo ucbroiert/oeavm lbrhe/i  /no/tce etowlfi/ esn///"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    throw p0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-interface {p0}, Lkotlinx/coroutines/channels/i;->l()Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    :try_start_1
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-interface {p0}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    move-object p2, p0

    move-object p0, v5

    move-object p0, v5

    move-object p0, v5

    move-object p0, v5

    :goto_2
    :try_start_2
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    iput-object p1, v0, Lkotlinx/coroutines/channels/u$b;->L$0:Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    iput-object p2, v0, Lkotlinx/coroutines/channels/u$b;->L$1:Ljava/lang/Object;

    iput-object p0, v0, Lkotlinx/coroutines/channels/u$b;->L$2:Ljava/lang/Object;

    const/4 v7, 0x4

    iput v4, v0, Lkotlinx/coroutines/channels/u$b;->label:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-interface {p0, v0}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-ne v2, v1, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    return-object v1

    :cond_3
    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object p2, v2

    move-object p2, v2

    move-object p2, v2

    move-object p2, v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto :goto_1

    :goto_3
    :try_start_3
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    check-cast p2, Ljava/lang/Boolean;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-eqz p2, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-interface {p0}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-interface {p1, p2}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_2

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v7, 0x3

    const/4 v6, 0x2

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v0, v3, v4, v3}, Lkotlinx/coroutines/channels/i0$a;->b(Lkotlinx/coroutines/channels/i0;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-object p0

    :catchall_1
    move-exception p0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    goto :goto_4

    :catchall_2
    move-exception p0

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto :goto_4

    :catchall_3
    move-exception p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p0, v5

    move-object p0, v5

    move-object p0, v5

    move-object p0, v5

    :goto_4
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {p1, v3, v4, v3}, Lkotlinx/coroutines/channels/i0$a;->b(Lkotlinx/coroutines/channels/i0;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    const/4 v7, 0x0

    invoke-static {v4}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v6, 0x4

    const/4 v7, 0x7

    throw p0
.end method

.method public static final e(Lkotlinx/coroutines/channels/i0;Li8/l;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 7
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    instance-of v0, p2, Lkotlinx/coroutines/channels/u$a;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    check-cast v0, Lkotlinx/coroutines/channels/u$a;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v1, v0, Lkotlinx/coroutines/channels/u$a;->label:I

    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/high16 v2, -0x80000000

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    and-int v3, v1, v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    sub-int/2addr v1, v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    iput v1, v0, Lkotlinx/coroutines/channels/u$a;->label:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance v0, Lkotlinx/coroutines/channels/u$a;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-direct {v0, p2}, Lkotlinx/coroutines/channels/u$a;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object p2, v0, Lkotlinx/coroutines/channels/u$a;->result:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget v2, v0, Lkotlinx/coroutines/channels/u$a;->label:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v2, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-ne v2, v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object p0, v0, Lkotlinx/coroutines/channels/u$a;->L$2:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x7

    check-cast p0, Lkotlinx/coroutines/channels/p;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object p1, v0, Lkotlinx/coroutines/channels/u$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    check-cast p1, Lkotlinx/coroutines/channels/i0;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v2, v0, Lkotlinx/coroutines/channels/u$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    check-cast v2, Li8/l;

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_2

    :catchall_0
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto/16 :goto_3

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string p1, "e/io uuo erk/ cetmouno es/tf/l/we tacvb/rir /eionlh"

    const-string p1, "oe/uos// itieeraf/ /mk coeuhorro/ cbeewvn ilotlt n/"

    const-string p1, "/eohi opnec/ofbu m/l//o /sutec/ tr lokee nw/tiavrer"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    throw p0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    :try_start_1
    const/4 v5, 0x0

    move v6, v5

    invoke-interface {p0}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p0, p2

    move-object p0, p2

    move-object p0, p2

    move-object p0, p2

    move-object p2, v4

    move-object p2, v4

    move-object p2, v4

    move-object p2, v4

    :goto_1
    :try_start_2
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput-object p2, v0, Lkotlinx/coroutines/channels/u$a;->L$0:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput-object p1, v0, Lkotlinx/coroutines/channels/u$a;->L$1:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput-object p0, v0, Lkotlinx/coroutines/channels/u$a;->L$2:Ljava/lang/Object;

    const/4 v6, 0x7

    iput v3, v0, Lkotlinx/coroutines/channels/u$a;->label:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {p0, v0}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    if-ne v2, v1, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object v1

    :cond_3
    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object p2, v4

    move-object p2, v4

    move-object p2, v4

    move-object p2, v4

    :goto_2
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    check-cast p2, Ljava/lang/Boolean;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz p2, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {p0}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {v2, p2}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-object p2, v2

    move-object p2, v2

    move-object p2, v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_1

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v3}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 p2, 0x0

    move v6, p2

    const/4 v5, 0x5

    and-int/2addr v6, v5

    invoke-static {p1, p2}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    const/4 v6, 0x3

    invoke-static {v3}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    return-object p0

    :catchall_1
    move-exception p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p0, v4

    move-object p0, v4

    move-object p0, v4

    move-object p0, v4

    :goto_3
    :try_start_3
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    throw p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :catchall_2
    move-exception p2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v3}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1, p0}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v3}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    throw p2
.end method

.method private static final f(Lkotlinx/coroutines/channels/i;Li8/l;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i<",
            "TE;>;",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lkotlinx/coroutines/e3;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {p0}, Lkotlinx/coroutines/channels/i;->l()Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 p2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v0, 0x1

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {p0}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v1

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v2}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v2, 0x0

    move v4, v2

    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v2}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v1, p2}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    check-cast v2, Ljava/lang/Boolean;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {v1}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {p1, v2}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {p0, p2, v0, p2}, Lkotlinx/coroutines/channels/i0$a;->b(Lkotlinx/coroutines/channels/i0;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p0, p2, v0, p2}, Lkotlinx/coroutines/channels/i0$a;->b(Lkotlinx/coroutines/channels/i0;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    throw p1
.end method

.method private static final g(Lkotlinx/coroutines/channels/i0;Li8/l;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 p2, 0x1

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {p0}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v1}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    move v4, v1

    const/4 v3, 0x5

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p2}, Lkotlin/jvm/internal/i0;->e(I)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    check-cast v2, Ljava/lang/Boolean;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v2, :cond_0

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    invoke-interface {v0}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {p1, v1}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p2}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p0, v1}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    invoke-static {p2}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v4, 0x0

    return-object p1

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p2}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    or-int/2addr v4, v3

    invoke-static {p2}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    throw v0
.end method

.method public static final h(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/selects/d;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;)",
            "Lkotlinx/coroutines/selects/d<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'onReceiveCatching\'"
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-interface {p0}, Lkotlinx/coroutines/channels/i0;->w()Lkotlinx/coroutines/selects/d;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public static final i(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlin/coroutines/d<",
            "-TE;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'receiveCatching\'"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "receiveCatching().getOrNull()"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/i0;->z(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p0
.end method

.method public static final j(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 9
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/util/List<",
            "+TE;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    instance-of v0, p1, Lkotlinx/coroutines/channels/u$c;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    check-cast v0, Lkotlinx/coroutines/channels/u$c;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget v1, v0, Lkotlinx/coroutines/channels/u$c;->label:I

    const/high16 v2, -0x80000000

    const/4 v8, 0x5

    const/4 v7, 0x1

    and-int v3, v1, v2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-eqz v3, :cond_0

    const/4 v7, 0x6

    const/4 v8, 0x2

    sub-int/2addr v1, v2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iput v1, v0, Lkotlinx/coroutines/channels/u$c;->label:I

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    goto :goto_0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    new-instance v0, Lkotlinx/coroutines/channels/u$c;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {v0, p1}, Lkotlinx/coroutines/channels/u$c;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-object p1, v0, Lkotlinx/coroutines/channels/u$c;->result:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget v2, v0, Lkotlinx/coroutines/channels/u$c;->label:I

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 v3, 0x1

    const/4 v8, 0x2

    if-eqz v2, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-ne v2, v3, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget-object p0, v0, Lkotlinx/coroutines/channels/u$c;->L$3:Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    check-cast p0, Lkotlinx/coroutines/channels/p;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget-object v2, v0, Lkotlinx/coroutines/channels/u$c;->L$2:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    check-cast v2, Lkotlinx/coroutines/channels/i0;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v4, v0, Lkotlinx/coroutines/channels/u$c;->L$1:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    check-cast v4, Ljava/util/List;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget-object v5, v0, Lkotlinx/coroutines/channels/u$c;->L$0:Ljava/lang/Object;

    const/4 v8, 0x1

    check-cast v5, Ljava/util/List;

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x2

    goto :goto_2

    :catchall_0
    move-exception p0

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    goto/16 :goto_3

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string p1, "eort/ lvqcaeboter n// bne/oc rus//feilm/iueohw ktio"

    const-string/jumbo p1, "uo/eebftcbto wlmlraosehoe/ / vetnuri///eio/i / rknc"

    const/4 v8, 0x1

    const-string p1, "hes/ o/ewl/r tuvot/nl/ktn oi/ur aocee/ic o/sbire em"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    throw p0

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {}, Lkotlin/collections/u;->i()Ljava/util/List;

    move-result-object p1

    :try_start_1
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-interface {p0}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object p1, p0

    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    :goto_1
    :try_start_2
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    iput-object v5, v0, Lkotlinx/coroutines/channels/u$c;->L$0:Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    iput-object v4, v0, Lkotlinx/coroutines/channels/u$c;->L$1:Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    iput-object p1, v0, Lkotlinx/coroutines/channels/u$c;->L$2:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    iput-object p0, v0, Lkotlinx/coroutines/channels/u$c;->L$3:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    iput v3, v0, Lkotlinx/coroutines/channels/u$c;->label:I

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-interface {p0, v0}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-ne v2, v1, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    return-object v1

    :cond_3
    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    :goto_2
    :try_start_3
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    check-cast p1, Ljava/lang/Boolean;

    const/4 v8, 0x3

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eqz p1, :cond_4

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-interface {p0}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x1

    invoke-interface {v4, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    move-object p1, v2

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    goto :goto_1

    :cond_4
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 p0, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {v2, p0}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {v5}, Lkotlin/collections/u;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    return-object p0

    :catchall_1
    move-exception p0

    const/4 v8, 0x0

    const/4 v7, 0x4

    goto :goto_3

    :catchall_2
    move-exception p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p0, v6

    move-object p0, v6

    move-object p0, v6

    move-object p0, v6

    :goto_3
    :try_start_4
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    throw p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    :catchall_3
    move-exception v0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {p1, p0}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    throw v0
.end method
