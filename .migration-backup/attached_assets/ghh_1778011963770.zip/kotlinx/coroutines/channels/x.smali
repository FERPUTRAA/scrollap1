.class public final Lkotlinx/coroutines/channels/x;
.super Ljava/util/NoSuchElementException;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method
