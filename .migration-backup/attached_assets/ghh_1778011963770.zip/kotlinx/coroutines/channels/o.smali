.class public Lkotlinx/coroutines/channels/o;
.super Lkotlinx/coroutines/a;

# interfaces
.implements Lkotlinx/coroutines/channels/n;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/a<",
        "Lkotlin/s2;",
        ">;",
        "Lkotlinx/coroutines/channels/n<",
        "TE;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nChannelCoroutine.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ChannelCoroutine.kt\nkotlinx/coroutines/channels/ChannelCoroutine\n+ 2 JobSupport.kt\nkotlinx/coroutines/JobSupport\n*L\n1#1,41:1\n702#2,2:42\n702#2,2:44\n702#2,2:46\n*S KotlinDebug\n*F\n+ 1 ChannelCoroutine.kt\nkotlinx/coroutines/channels/ChannelCoroutine\n*L\n21#1:42,2\n26#1:44,2\n32#1:46,2\n*E\n"
.end annotation


# instance fields
.field private final c:Lkotlinx/coroutines/channels/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/n<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/channels/n;ZZ)V
    .locals 2
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/channels/n;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "Lkotlinx/coroutines/channels/n<",
            "TE;>;ZZ)V"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-direct {p0, p1, p3, p4}, Lkotlinx/coroutines/a;-><init>(Lkotlin/coroutines/g;ZZ)V

    const/4 v1, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public A(Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 3
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/r<",
            "+TE;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/i0;->A(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p1
.end method

.method public B(Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 3
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "-TE;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/i0;->B(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p1
.end method

.method public C(Ljava/lang/Throwable;)Z
    .locals 3
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/m0;->C(Ljava/lang/Throwable;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return p1
.end method

.method public D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 3
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0, p1, p2}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p1
.end method

.method public E()Z
    .locals 3

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x3

    invoke-interface {v0}, Lkotlinx/coroutines/channels/m0;->E()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public V(Ljava/lang/Throwable;)V
    .locals 4
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p0, p1, v0, v1, v0}, Lkotlinx/coroutines/v2;->X0(Lkotlinx/coroutines/v2;Ljava/lang/Throwable;Ljava/lang/String;ILjava/lang/Object;)Ljava/util/concurrent/CancellationException;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/i0;->cancel(Ljava/util/concurrent/CancellationException;)V

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/v2;->T(Ljava/lang/Throwable;)Z

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public synthetic cancel()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v0, Lkotlinx/coroutines/o2;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {p0}, Lkotlinx/coroutines/v2;->I(Lkotlinx/coroutines/v2;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2, p0}, Lkotlinx/coroutines/o2;-><init>(Ljava/lang/String;Ljava/lang/Throwable;Lkotlinx/coroutines/n2;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p0, v0}, Lkotlinx/coroutines/channels/o;->V(Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void
.end method

.method public final cancel(Ljava/util/concurrent/CancellationException;)V
    .locals 4
    .param p1    # Ljava/util/concurrent/CancellationException;
        .annotation build Lia/e;
        .end annotation
    .end param

    invoke-virtual {p0}, Lkotlinx/coroutines/v2;->isCancelled()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance p1, Lkotlinx/coroutines/o2;

    const/4 v2, 0x6

    const/4 v2, 0x7

    invoke-static {p0}, Lkotlinx/coroutines/v2;->I(Lkotlinx/coroutines/v2;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p1, v0, v1, p0}, Lkotlinx/coroutines/o2;-><init>(Ljava/lang/String;Ljava/lang/Throwable;Lkotlinx/coroutines/n2;)V

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/o;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public final synthetic cancel(Ljava/lang/Throwable;)Z
    .locals 4
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Since 1.2.0, binary compatibility with versions <= 1.1.x"
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance p1, Lkotlinx/coroutines/o2;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0}, Lkotlinx/coroutines/v2;->I(Lkotlinx/coroutines/v2;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p1, v0, v1, p0}, Lkotlinx/coroutines/o2;-><init>(Ljava/lang/String;Ljava/lang/Throwable;Lkotlinx/coroutines/n2;)V

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/o;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 p1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    return p1
.end method

.method public g()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {v0}, Lkotlinx/coroutines/channels/i0;->g()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public final getChannel()Lkotlinx/coroutines/channels/n;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/n<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x0

    invoke-interface {v0}, Lkotlinx/coroutines/channels/i0;->isEmpty()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public iterator()Lkotlinx/coroutines/channels/p;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/p<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {v0}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method protected final j1()Lkotlinx/coroutines/channels/n;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/n<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public k()Lkotlinx/coroutines/selects/e;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/selects/e<",
            "TE;",
            "Lkotlinx/coroutines/channels/m0<",
            "TE;>;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0}, Lkotlinx/coroutines/channels/m0;->k()Lkotlinx/coroutines/selects/e;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public offer(Ljava/lang/Object;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)Z"
        }
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'trySend\' method"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "trySend(element).isSuccess"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/m0;->offer(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return p1
.end method

.method public p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/m0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p1
.end method

.method public poll()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'tryReceive\'. Please note that the provided replacement does not rethrow channel\'s close cause as \'poll\' did, for the precise replacement please refer to the \'poll\' documentation"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "tryReceive().getOrNull()"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {v0}, Lkotlinx/coroutines/channels/i0;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public r()Lkotlinx/coroutines/selects/d;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/selects/d<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0}, Lkotlinx/coroutines/channels/i0;->r()Lkotlinx/coroutines/selects/d;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public u()Lkotlinx/coroutines/selects/d;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/selects/d<",
            "Lkotlinx/coroutines/channels/r<",
            "TE;>;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0}, Lkotlinx/coroutines/channels/i0;->u()Lkotlinx/coroutines/selects/d;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public w()Lkotlinx/coroutines/selects/d;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/selects/d<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-interface {v0}, Lkotlinx/coroutines/channels/i0;->w()Lkotlinx/coroutines/selects/d;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public x(Li8/l;)V
    .locals 3
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/l<",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    .annotation build Lkotlinx/coroutines/c2;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/m0;->x(Li8/l;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public y()Ljava/lang/Object;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {v0}, Lkotlinx/coroutines/channels/i0;->y()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public z(Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 3
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "-TE;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation build Lkotlin/internal/h;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in favor of \'receiveCatching\'. Please note that the provided replacement does not rethrow channel\'s close cause as \'receiveOrNull\' did, for the detailed replacement please refer to the \'receiveOrNull\' documentation"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "receiveCatching().getOrNull()"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/o;->c:Lkotlinx/coroutines/channels/n;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/i0;->z(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p1
.end method
