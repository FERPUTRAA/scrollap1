.class public Lkotlinx/coroutines/channels/r$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/r;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    xor-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "o4s~.d~@@br~ @f@ ~ ~ t~ ~ o@~~s Mco~- 1 n@oK~t@l/~~~/  @@ @~~ @b@f~@o@im~~@l voay @@@@ u~i@S ib~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const-string v0, "lesmFa"

    const-string v0, "alsieF"

    const/4 v2, 0x4

    const-string v0, "ledioa"

    const-string v0, "Failed"

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method
