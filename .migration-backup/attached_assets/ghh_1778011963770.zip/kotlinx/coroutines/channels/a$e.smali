.class final Lkotlinx/coroutines/channels/a$e;
.super Lkotlinx/coroutines/channels/h0;

# interfaces
.implements Lkotlinx/coroutines/p1;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<R:",
        "Ljava/lang/Object;",
        "E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/h0<",
        "TE;>;",
        "Lkotlinx/coroutines/p1;"
    }
.end annotation


# instance fields
.field public final d:Lkotlinx/coroutines/channels/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/a<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public final e:Lkotlinx/coroutines/selects/f;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/selects/f<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public final f:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-TR;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public final g:I
    .annotation build Lh8/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/channels/a;Lkotlinx/coroutines/selects/f;Li8/p;I)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/a;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/selects/f;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/a<",
            "TE;>;",
            "Lkotlinx/coroutines/selects/f<",
            "-TR;>;",
            "Li8/p<",
            "Ljava/lang/Object;",
            "-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;I)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Lkotlinx/coroutines/channels/h0;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/channels/a$e;->d:Lkotlinx/coroutines/channels/a;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/channels/a$e;->e:Lkotlinx/coroutines/selects/f;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p3, p0, Lkotlinx/coroutines/channels/a$e;->f:Li8/p;

    const/4 v1, 0x2

    const/4 v0, 0x3

    iput p4, p0, Lkotlinx/coroutines/channels/a$e;->g:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public E0(Ljava/lang/Object;)Li8/l;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Li8/l<",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$e;->d:Lkotlinx/coroutines/channels/a;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, v0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/a$e;->e:Lkotlinx/coroutines/selects/f;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v1}, Lkotlinx/coroutines/selects/f;->P()Lkotlin/coroutines/d;

    move-result-object v1

    const/4 v3, 0x3

    invoke-interface {v1}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0, p1, v1}, Lkotlinx/coroutines/internal/i0;->a(Li8/l;Ljava/lang/Object;Lkotlin/coroutines/g;)Li8/l;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p1
.end method

.method public F0(Lkotlinx/coroutines/channels/w;)V
    .locals 10
    .param p1    # Lkotlinx/coroutines/channels/w;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/w<",
            "*>;)V"
        }
    .end annotation

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$e;->e:Lkotlinx/coroutines/selects/f;

    const/4 v8, 0x2

    shl-int/2addr v9, v8

    invoke-interface {v0}, Lkotlinx/coroutines/selects/f;->I()Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-nez v0, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    return-void

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget v0, p0, Lkotlinx/coroutines/channels/a$e;->g:I

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-eqz v0, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/4 v1, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-eq v0, v1, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v2, p0, Lkotlinx/coroutines/channels/a$e;->f:Li8/p;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    sget-object v0, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget-object p1, p1, Lkotlinx/coroutines/channels/w;->d:Ljava/lang/Throwable;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/channels/r$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x6

    invoke-static {p1}, Lkotlinx/coroutines/channels/r;->b(Ljava/lang/Object;)Lkotlinx/coroutines/channels/r;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/channels/a$e;->e:Lkotlinx/coroutines/selects/f;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-interface {p1}, Lkotlinx/coroutines/selects/f;->P()Lkotlin/coroutines/d;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/4 v5, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    const/4 v6, 0x4

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/4 v7, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static/range {v2 .. v7}, Lu8/a;->f(Li8/p;Ljava/lang/Object;Lkotlin/coroutines/d;Li8/l;ILjava/lang/Object;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    goto :goto_0

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$e;->e:Lkotlinx/coroutines/selects/f;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/w;->K0()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-interface {v0, p1}, Lkotlinx/coroutines/selects/f;->T(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x0

    return-void
.end method

.method public X(Ljava/lang/Object;Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;
    .locals 2
    .param p2    # Lkotlinx/coroutines/internal/y$d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/internal/y$d;",
            ")",
            "Lkotlinx/coroutines/internal/r0;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/channels/a$e;->e:Lkotlinx/coroutines/selects/f;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-interface {p1, p2}, Lkotlinx/coroutines/selects/f;->D(Lkotlinx/coroutines/internal/y$d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    check-cast p1, Lkotlinx/coroutines/internal/r0;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/internal/y;->w0()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$e;->d:Lkotlinx/coroutines/channels/a;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, Lkotlinx/coroutines/channels/a;->h0()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public r(Ljava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)V"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$e;->f:Li8/p;

    const/4 v4, 0x7

    iget v1, p0, Lkotlinx/coroutines/channels/a$e;->g:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-ne v1, v2, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x7

    sget-object v1, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Lkotlinx/coroutines/channels/r$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v1}, Lkotlinx/coroutines/channels/r;->b(Ljava/lang/Object;)Lkotlinx/coroutines/channels/r;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    iget-object v2, p0, Lkotlinx/coroutines/channels/a$e;->e:Lkotlinx/coroutines/selects/f;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v2}, Lkotlinx/coroutines/selects/f;->P()Lkotlin/coroutines/d;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/a$e;->E0(Ljava/lang/Object;)Li8/l;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v0, v1, v2, p1}, Lu8/a;->d(Li8/p;Ljava/lang/Object;Lkotlin/coroutines/d;Li8/l;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "iesSveseReec@l"

    const-string v1, "eis@RecSevelce"

    const/4 v3, 0x2

    const-string v1, "SvemetlRciece@"

    const-string v1, "ReceiveSelect@"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0}, Lkotlinx/coroutines/z0;->b(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/16 v1, 0x5b

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/channels/a$e;->e:Lkotlinx/coroutines/selects/f;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, "Mcero,e=eemoi"

    const-string v1, "co=mMred,ieee"

    const/4 v3, 0x3

    const-string v1, "ecrMvbdie=ee,"

    const-string v1, ",receiveMode="

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, p0, Lkotlinx/coroutines/channels/a$e;->g:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/16 v1, 0x5d

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v0
.end method
