.class final Lkotlinx/coroutines/channels/p0$c;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/p0;->e(JJLkotlin/coroutines/g;Lkotlinx/coroutines/channels/q0;)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/channels/p0$c$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.TickerChannelsKt$ticker$3"
    f = "TickerChannels.kt"
    i = {}
    l = {
        0x48,
        0x49
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $delayMillis:J

.field final synthetic $initialDelayMillis:J

.field final synthetic $mode:Lkotlinx/coroutines/channels/q0;

.field private synthetic L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/q0;JJLkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/q0;",
            "JJ",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/p0$c;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/channels/p0$c;->$mode:Lkotlinx/coroutines/channels/q0;

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-wide p2, p0, Lkotlinx/coroutines/channels/p0$c;->$delayMillis:J

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-wide p4, p0, Lkotlinx/coroutines/channels/p0$c;->$initialDelayMillis:J

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    const/4 p1, 0x2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0, p1, p6}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 10
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    new-instance v7, Lkotlinx/coroutines/channels/p0$c;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/p0$c;->$mode:Lkotlinx/coroutines/channels/q0;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-wide v2, p0, Lkotlinx/coroutines/channels/p0$c;->$delayMillis:J

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    iget-wide v4, p0, Lkotlinx/coroutines/channels/p0$c;->$initialDelayMillis:J

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-direct/range {v0 .. v6}, Lkotlinx/coroutines/channels/p0$c;-><init>(Lkotlinx/coroutines/channels/q0;JJLkotlin/coroutines/d;)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    iput-object p1, v7, Lkotlinx/coroutines/channels/p0$c;->L$0:Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    return-object v7
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/p0$c;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget v1, p0, Lkotlinx/coroutines/channels/p0$c;->label:I

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    const/4 v2, 0x2

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x3

    const/4 v3, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    if-eqz v1, :cond_2

    const/4 v10, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-eq v1, v3, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-ne v1, v2, :cond_1

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v11, 0x7

    goto/16 :goto_0

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string v0, "o/sskr/tleuo/ ewcae/or  bi ouie//ome/ntnt/ lcefsvh "

    const-string v0, " lsee tbt//frrew/vta//ceos  nohuceo/o iiknro /ul/em"

    const/4 v11, 0x7

    const-string v0, "arem/nmre nbc  eii//e/rt co/olis/kwuu ef /oheo/ottl"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v11, 0x1

    const/4 v10, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    throw p1

    :cond_2
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/channels/p0$c;->L$0:Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/channels/p0$c;->$mode:Lkotlinx/coroutines/channels/q0;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    sget-object v4, Lkotlinx/coroutines/channels/p0$c$a;->a:[I

    const/4 v10, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    aget v1, v4, v1

    const/4 v11, 0x6

    const/4 v10, 0x5

    if-eq v1, v3, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-eq v1, v2, :cond_3

    const/4 v10, 0x5

    xor-int/2addr v11, v10

    goto :goto_0

    :cond_3
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget-wide v4, p0, Lkotlinx/coroutines/channels/p0$c;->$delayMillis:J

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    iget-wide v6, p0, Lkotlinx/coroutines/channels/p0$c;->$initialDelayMillis:J

    const/4 v10, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-interface {p1}, Lkotlinx/coroutines/channels/g0;->getChannel()Lkotlinx/coroutines/channels/m0;

    move-result-object v8

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    iput v2, p0, Lkotlinx/coroutines/channels/p0$c;->label:I

    move-object v9, p0

    move-object v9, p0

    move-object v9, p0

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-static/range {v4 .. v9}, Lkotlinx/coroutines/channels/p0;->a(JJLkotlinx/coroutines/channels/m0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    if-ne p1, v0, :cond_5

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x5

    return-object v0

    :cond_4
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x3

    iget-wide v1, p0, Lkotlinx/coroutines/channels/p0$c;->$delayMillis:J

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    iget-wide v4, p0, Lkotlinx/coroutines/channels/p0$c;->$initialDelayMillis:J

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-interface {p1}, Lkotlinx/coroutines/channels/g0;->getChannel()Lkotlinx/coroutines/channels/m0;

    move-result-object p1

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    iput v3, p0, Lkotlinx/coroutines/channels/p0$c;->label:I

    move-wide v3, v4

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-static/range {v1 .. v6}, Lkotlinx/coroutines/channels/p0;->b(JJLkotlinx/coroutines/channels/m0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    if-ne p1, v0, :cond_5

    const/4 v11, 0x7

    const/4 v10, 0x7

    return-object v0

    :cond_5
    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/p0$c;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    check-cast p1, Lkotlinx/coroutines/channels/p0$c;

    const/4 v1, 0x6

    const/4 v0, 0x0

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/p0$c;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method
