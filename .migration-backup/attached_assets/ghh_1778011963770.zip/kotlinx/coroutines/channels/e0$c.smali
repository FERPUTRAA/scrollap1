.class final Lkotlinx/coroutines/channels/e0$c;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/e0;->a(Lkotlinx/coroutines/channels/g0;Li8/a;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/l<",
        "Ljava/lang/Throwable;",
        "Lkotlin/s2;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic $cont:Lkotlinx/coroutines/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/q<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/q;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/q<",
            "-",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/channels/e0$c;->$cont:Lkotlinx/coroutines/q;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "los@ri@ @ @  t~ ~o /@b~o4o~@sb  @~ @@i i-@~S@@ M of~l~@.1~@cft  ~ n/o@y~~@b@@Kv~ua@~ ~m~ ~~d~~@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p1, Ljava/lang/Throwable;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/e0$c;->invoke(Ljava/lang/Throwable;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public final invoke(Ljava/lang/Throwable;)V
    .locals 3
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/channels/e0$c;->$cont:Lkotlinx/coroutines/q;

    const/4 v1, 0x0

    move v2, v1

    sget-object v0, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    sget-object v0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {p1, v0}, Lkotlin/coroutines/d;->resumeWith(Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method
