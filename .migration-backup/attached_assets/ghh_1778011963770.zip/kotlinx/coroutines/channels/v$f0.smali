.class final Lkotlinx/coroutines/channels/v$f0;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/v;->S(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/g;)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "Ljava/lang/Object;",
        ">;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeprecated.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Deprecated.kt\nkotlinx/coroutines/channels/ChannelsKt__DeprecatedKt$take$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,479:1\n1#2:480\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.ChannelsKt__DeprecatedKt$take$1"
    f = "Deprecated.kt"
    i = {
        0x0,
        0x0,
        0x1,
        0x1
    }
    l = {
        0xfe,
        0xff
    }
    m = "invokeSuspend"
    n = {
        "$this$produce",
        "remaining",
        "$this$produce",
        "remaining"
    }
    s = {
        "L$0",
        "I$0",
        "L$0",
        "I$0"
    }
.end annotation


# instance fields
.field final synthetic $n:I

.field final synthetic $this_take:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field I$0:I

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(ILkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/v$f0;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p1, p0, Lkotlinx/coroutines/channels/v$f0;->$n:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p2, p0, Lkotlinx/coroutines/channels/v$f0;->$this_take:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    const/4 p1, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x0

    new-instance v0, Lkotlinx/coroutines/channels/v$f0;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget v1, p0, Lkotlinx/coroutines/channels/v$f0;->$n:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v2, p0, Lkotlinx/coroutines/channels/v$f0;->$this_take:Lkotlinx/coroutines/channels/i0;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/channels/v$f0;-><init>(ILkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$f0;->L$0:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x3

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$f0;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget v1, p0, Lkotlinx/coroutines/channels/v$f0;->label:I

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/4 v2, 0x2

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 v3, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz v1, :cond_2

    const/4 v8, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-eq v1, v3, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-ne v1, v2, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x0

    iget v1, p0, Lkotlinx/coroutines/channels/v$f0;->I$0:I

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget-object v4, p0, Lkotlinx/coroutines/channels/v$f0;->L$1:Ljava/lang/Object;

    const/4 v9, 0x7

    check-cast v4, Lkotlinx/coroutines/channels/p;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$f0;->L$0:Ljava/lang/Object;

    const/4 v9, 0x6

    check-cast v5, Lkotlinx/coroutines/channels/g0;

    const/4 v9, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p1, v5

    move-object p1, v5

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    goto/16 :goto_2

    :cond_0
    const/4 v8, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string v0, "e/souisaftkoereico lruct/e/ lni/oms et nv/hw//rb/ e"

    const-string v0, "rhscteeriaovie ifo/ttbe// u /mwe  /elncrksol u///no"

    const/4 v9, 0x7

    const-string/jumbo v0, "uuhme/s  e/iwkl/reve  oir tlc /o/batrnimco/oeofnt/e"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    throw p1

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget v1, p0, Lkotlinx/coroutines/channels/v$f0;->I$0:I

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-object v4, p0, Lkotlinx/coroutines/channels/v$f0;->L$1:Ljava/lang/Object;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    check-cast v4, Lkotlinx/coroutines/channels/p;

    const/4 v9, 0x7

    const/4 v8, 0x6

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$f0;->L$0:Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    check-cast v5, Lkotlinx/coroutines/channels/g0;

    const/4 v9, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    goto :goto_1

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/channels/v$f0;->L$0:Ljava/lang/Object;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget v1, p0, Lkotlinx/coroutines/channels/v$f0;->$n:I

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-nez v1, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    return-object p1

    :cond_3
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-ltz v1, :cond_4

    move v4, v3

    move v4, v3

    const/4 v9, 0x1

    move v4, v3

    move v4, v3

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    goto :goto_0

    :cond_4
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    const/4 v4, 0x0

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-eqz v4, :cond_9

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-object v4, p0, Lkotlinx/coroutines/channels/v$f0;->$this_take:Lkotlinx/coroutines/channels/i0;

    const/4 v9, 0x1

    invoke-interface {v4}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v4

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    :cond_5
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    iput-object p1, v5, Lkotlinx/coroutines/channels/v$f0;->L$0:Ljava/lang/Object;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    iput-object v4, v5, Lkotlinx/coroutines/channels/v$f0;->L$1:Ljava/lang/Object;

    const/4 v9, 0x6

    const/4 v8, 0x1

    iput v1, v5, Lkotlinx/coroutines/channels/v$f0;->I$0:I

    const/4 v9, 0x6

    iput v3, v5, Lkotlinx/coroutines/channels/v$f0;->label:I

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-interface {v4, v5}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-ne v6, v0, :cond_6

    const/4 v9, 0x7

    const/4 v8, 0x0

    return-object v0

    :cond_6
    move-object v7, v5

    move-object v7, v5

    move-object v7, v5

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    :goto_1
    const/4 v9, 0x0

    const/4 v8, 0x1

    check-cast p1, Ljava/lang/Boolean;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-eqz p1, :cond_8

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-interface {v4}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    iput-object v5, v6, Lkotlinx/coroutines/channels/v$f0;->L$0:Ljava/lang/Object;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    iput-object v4, v6, Lkotlinx/coroutines/channels/v$f0;->L$1:Ljava/lang/Object;

    const/4 v8, 0x0

    shr-int/2addr v9, v8

    iput v1, v6, Lkotlinx/coroutines/channels/v$f0;->I$0:I

    const/4 v9, 0x3

    const/4 v8, 0x6

    iput v2, v6, Lkotlinx/coroutines/channels/v$f0;->label:I

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-interface {v5, p1, v6}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    if-ne p1, v0, :cond_7

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    return-object v0

    :cond_7
    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    :goto_2
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    add-int/lit8 v1, v1, -0x1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-nez v1, :cond_5

    const/4 v8, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    return-object p1

    :cond_8
    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    return-object p1

    :cond_9
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const-string v0, "mtenoe eduu tceomsnlR qt"

    const-string v0, "oRumenee  tqus emtnletdc"

    const/4 v9, 0x7

    const-string v0, "qutulbent eeeeeRstnmc do"

    const-string v0, "Requested element count "

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string v0, " ehao u ol. stssrez"

    const-string v0, " t  o zsraeehosls.n"

    const/4 v9, 0x6

    const-string v0, "aersst p esh  izln."

    const-string v0, " is less than zero."

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    throw v0
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$f0;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    check-cast p1, Lkotlinx/coroutines/channels/v$f0;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/v$f0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method
