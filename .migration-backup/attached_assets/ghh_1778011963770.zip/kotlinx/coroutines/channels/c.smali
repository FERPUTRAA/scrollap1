.class public abstract Lkotlinx/coroutines/channels/c;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/channels/m0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/channels/c$b;,
        Lkotlinx/coroutines/channels/c$d;,
        Lkotlinx/coroutines/channels/c$c;,
        Lkotlinx/coroutines/channels/c$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/channels/m0<",
        "TE;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAbstractChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AbstractChannel.kt\nkotlinx/coroutines/channels/AbstractSendChannel\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 LockFreeLinkedList.kt\nkotlinx/coroutines/internal/LockFreeLinkedListNode\n+ 4 CancellableContinuation.kt\nkotlinx/coroutines/CancellableContinuationKt\n+ 5 InlineList.kt\nkotlinx/coroutines/internal/InlineList\n+ 6 LockFreeLinkedList.kt\nkotlinx/coroutines/internal/LockFreeLinkedListHead\n*L\n1#1,1132:1\n1#2:1133\n297#3,12:1134\n165#3,4:1146\n165#3,4:1155\n177#3:1159\n91#3,3:1160\n178#3,6:1163\n165#3,4:1169\n297#3,12:1184\n332#4,5:1150\n37#5,11:1173\n645#6,6:1196\n*S KotlinDebug\n*F\n+ 1 AbstractChannel.kt\nkotlinx/coroutines/channels/AbstractSendChannel\n*L\n96#1:1134,12\n104#1:1146,4\n247#1:1155,4\n252#1:1159\n252#1:1160,3\n252#1:1163,6\n269#1:1169,4\n358#1:1184,12\n190#1:1150,5\n342#1:1173,11\n455#1:1196,6\n*E\n"
.end annotation


# static fields
.field private static final synthetic c:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;


# instance fields
.field protected final a:Li8/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/l<",
            "TE;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field private final b:Lkotlinx/coroutines/internal/w;
    .annotation build Lia/d;
    .end annotation
.end field

.field private volatile synthetic onCloseHandler:Ljava/lang/Object;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-class v0, Ljava/lang/Object;

    const/4 v4, 0x0

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const-string v1, "aosHlreoeCssln"

    const-string v1, "alssnHCelooner"

    const/4 v4, 0x1

    const-string v1, "enCmeoandolrHl"

    const-string v1, "onCloseHandler"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-class v2, Lkotlinx/coroutines/channels/c;

    const/4 v4, 0x5

    const-class v2, Lkotlinx/coroutines/channels/c;

    const-class v2, Lkotlinx/coroutines/channels/c;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v2, v0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    sput-object v0, Lkotlinx/coroutines/channels/c;->c:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v3, 0x3

    move v4, v3

    return-void
.end method

.method public constructor <init>(Li8/l;)V
    .locals 2
    .param p1    # Li8/l;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    new-instance p1, Lkotlinx/coroutines/internal/w;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p1}, Lkotlinx/coroutines/internal/w;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 p1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/channels/c;->onCloseHandler:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method private final F(Lkotlin/coroutines/d;Ljava/lang/Object;Lkotlinx/coroutines/channels/w;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "*>;TE;",
            "Lkotlinx/coroutines/channels/w<",
            "*>;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@@~@o@@ ro@i@ M f~i ~o@ ~o t ~S1a/ ~  ~y~4~-v us@ ~b@in@@oofd@ ~~bl@b@m~@~@~ t~~c/o~l  @ ~~~K~.@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    invoke-direct {p0, p3}, Lkotlinx/coroutines/channels/c;->s(Lkotlinx/coroutines/channels/w;)V

    const/4 v3, 0x1

    const/4 v3, 0x1

    invoke-virtual {p3}, Lkotlinx/coroutines/channels/w;->L0()Ljava/lang/Throwable;

    move-result-object p3

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v1, 0x2

    const/4 v4, 0x2

    xor-int/2addr v3, v1

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x0

    move v3, v2

    move v3, v2

    const/4 v4, 0x3

    invoke-static {v0, p2, v2, v1, v2}, Lkotlinx/coroutines/internal/i0;->d(Li8/l;Ljava/lang/Object;Lkotlinx/coroutines/internal/d1;ILjava/lang/Object;)Lkotlinx/coroutines/internal/d1;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz p2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p2, p3}, Lkotlin/o;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-object p3, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v3, 0x4

    move v4, v3

    invoke-static {p2}, Lkotlin/e1;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p2}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-interface {p1, p2}, Lkotlin/coroutines/d;->resumeWith(Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    sget-object p2, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p3}, Lkotlin/e1;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p2}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {p1, p2}, Lkotlin/coroutines/d;->resumeWith(Ljava/lang/Object;)V

    const/4 v3, 0x1

    and-int/2addr v4, v3

    return-void
.end method

.method private final G(Ljava/lang/Throwable;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->onCloseHandler:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    sget-object v1, Lkotlinx/coroutines/channels/b;->h:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eq v0, v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    sget-object v2, Lkotlinx/coroutines/channels/c;->c:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    invoke-static {v2, p0, v0, v1}, Landroidx/concurrent/futures/b;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v0, v1}, Lkotlin/jvm/internal/u1;->q(Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    check-cast v0, Li8/l;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {v0, p1}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void
.end method

.method private final J()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->p0()Lkotlinx/coroutines/internal/y;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    instance-of v0, v0, Lkotlinx/coroutines/channels/j0;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->I()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method private final N(Lkotlinx/coroutines/selects/f;Ljava/lang/Object;Li8/p;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/selects/f<",
            "-TR;>;TE;",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/channels/m0<",
            "-TE;>;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {p1}, Lkotlinx/coroutines/selects/f;->l()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p0}, Lkotlinx/coroutines/channels/c;->J()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_5

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Lkotlinx/coroutines/channels/c$c;

    const/4 v3, 0x6

    invoke-direct {v0, p2, p0, p1, p3}, Lkotlinx/coroutines/channels/c$c;-><init>(Ljava/lang/Object;Lkotlinx/coroutines/channels/c;Lkotlinx/coroutines/selects/f;Li8/p;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lkotlinx/coroutines/channels/c;->i(Lkotlinx/coroutines/channels/l0;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez v1, :cond_2

    const/4 v3, 0x4

    invoke-interface {p1, v0}, Lkotlinx/coroutines/selects/f;->C(Lkotlinx/coroutines/p1;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    instance-of v0, v1, Lkotlinx/coroutines/channels/w;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lkotlinx/coroutines/channels/b;->g:Lkotlinx/coroutines/internal/r0;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eq v1, v0, :cond_5

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    instance-of v0, v1, Lkotlinx/coroutines/channels/h0;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const-string p3, "eneeubnSm ueeretndd u"

    const-string p3, "ee mnuqtdnunrSdeue ee"

    const/4 v3, 0x3

    const-string p3, "nerurnu eedn uetSueeq"

    const-string p3, "enqueueSend returned "

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/16 p3, 0x20

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    throw p1

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x1

    check-cast v1, Lkotlinx/coroutines/channels/w;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p0, p2, v1}, Lkotlinx/coroutines/channels/c;->t(Ljava/lang/Object;Lkotlinx/coroutines/channels/w;)Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-static {p1}, Lkotlinx/coroutines/internal/q0;->p(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    throw p1

    :cond_5
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, p2, p1}, Lkotlinx/coroutines/channels/c;->L(Ljava/lang/Object;Lkotlinx/coroutines/selects/f;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ne v0, v1, :cond_6

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void

    :cond_6
    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v1, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eq v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v1, Lkotlinx/coroutines/internal/c;->b:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eq v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    sget-object v1, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-ne v0, v1, :cond_7

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-interface {p1}, Lkotlinx/coroutines/selects/f;->P()Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v3, 0x0

    invoke-static {p3, p0, p1}, Lu8/b;->d(Li8/p;Ljava/lang/Object;Lkotlin/coroutines/d;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void

    :cond_7
    const/4 v3, 0x3

    instance-of p1, v0, Lkotlinx/coroutines/channels/w;

    const/4 v3, 0x0

    if-eqz p1, :cond_8

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast v0, Lkotlinx/coroutines/channels/w;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0, p2, v0}, Lkotlinx/coroutines/channels/c;->t(Ljava/lang/Object;Lkotlinx/coroutines/channels/w;)Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Lkotlinx/coroutines/internal/q0;->p(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    throw p1

    :cond_8
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string p3, "nnlfreepoSl rdcoeetIenreftrtu"

    const-string p3, "rlnfotlena crntdeeIeSerutfreo"

    const/4 v3, 0x1

    const-string p3, "fe teerIqtntrualneSnrrdcoelfe"

    const-string p3, "offerSelectInternal returned "

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw p1
.end method

.method private final P(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p2}, Lkotlin/coroutines/intrinsics/b;->e(Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v0}, Lkotlinx/coroutines/t;->b(Lkotlin/coroutines/d;)Lkotlinx/coroutines/r;

    move-result-object v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p0}, Lkotlinx/coroutines/channels/c;->b(Lkotlinx/coroutines/channels/c;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v1, :cond_5

    const/4 v4, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v1, Lkotlinx/coroutines/channels/n0;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v1, p1, v0}, Lkotlinx/coroutines/channels/n0;-><init>(Ljava/lang/Object;Lkotlinx/coroutines/q;)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance v1, Lkotlinx/coroutines/channels/o0;

    const/4 v4, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v1, p1, v0, v2}, Lkotlinx/coroutines/channels/o0;-><init>(Ljava/lang/Object;Lkotlinx/coroutines/q;Li8/l;)V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p0, v1}, Lkotlinx/coroutines/channels/c;->i(Lkotlinx/coroutines/channels/l0;)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-nez v2, :cond_2

    const/4 v4, 0x7

    invoke-static {v0, v1}, Lkotlinx/coroutines/t;->c(Lkotlinx/coroutines/q;Lkotlinx/coroutines/internal/y;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto/16 :goto_2

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    instance-of v1, v2, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v1, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast v2, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p0, v0, p1, v2}, Lkotlinx/coroutines/channels/c;->a(Lkotlinx/coroutines/channels/c;Lkotlin/coroutines/d;Ljava/lang/Object;Lkotlinx/coroutines/channels/w;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto/16 :goto_2

    :cond_3
    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object v1, Lkotlinx/coroutines/channels/b;->g:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eq v2, v1, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    instance-of v1, v2, Lkotlinx/coroutines/channels/h0;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v1, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_1

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v0, "enqueueSend returned "

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    throw p1

    :cond_5
    :goto_1
    const/4 v4, 0x3

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/c;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    sget-object v2, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-ne v1, v2, :cond_6

    const/4 v4, 0x0

    const/4 v3, 0x0

    sget-object p1, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {v0, p1}, Lkotlin/coroutines/d;->resumeWith(Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto :goto_2

    :cond_6
    const/4 v3, 0x0

    const/4 v4, 0x7

    sget-object v2, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eq v1, v2, :cond_0

    const/4 v3, 0x1

    const/4 v4, 0x1

    instance-of v2, v1, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v2, :cond_9

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    check-cast v1, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p0, v0, p1, v1}, Lkotlinx/coroutines/channels/c;->a(Lkotlinx/coroutines/channels/c;Lkotlin/coroutines/d;Ljava/lang/Object;Lkotlinx/coroutines/channels/w;)V

    :goto_2
    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Lkotlinx/coroutines/r;->w()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-ne p1, v0, :cond_7

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p2}, Lkotlin/coroutines/jvm/internal/h;->c(Lkotlin/coroutines/d;)V

    :cond_7
    const/4 v4, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-ne p1, p2, :cond_8

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object p1

    :cond_8
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object p1

    :cond_9
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    move v4, v3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const-string v0, "Irsud elfertno fereanbt"

    const-string v0, "et urbnI oferrletenadnf"

    const/4 v4, 0x2

    const-string v0, "rarmttdor enIelerefnnf "

    const-string v0, "offerInternal returned "

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static final synthetic a(Lkotlinx/coroutines/channels/c;Lkotlin/coroutines/d;Ljava/lang/Object;Lkotlinx/coroutines/channels/w;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2, p3}, Lkotlinx/coroutines/channels/c;->F(Lkotlin/coroutines/d;Ljava/lang/Object;Lkotlinx/coroutines/channels/w;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public static final synthetic b(Lkotlinx/coroutines/channels/c;)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lkotlinx/coroutines/channels/c;->J()Z

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    return p0
.end method

.method public static final synthetic c(Lkotlinx/coroutines/channels/c;Lkotlinx/coroutines/selects/f;Ljava/lang/Object;Li8/p;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2, p3}, Lkotlinx/coroutines/channels/c;->N(Lkotlinx/coroutines/selects/f;Ljava/lang/Object;Li8/p;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public static final synthetic d(Lkotlinx/coroutines/channels/c;Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlinx/coroutines/channels/c;->P(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method private final e()I
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->o0()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    check-cast v1, Lkotlinx/coroutines/internal/y;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-nez v3, :cond_1

    const/4 v5, 0x3

    instance-of v3, v1, Lkotlinx/coroutines/internal/y;

    const/4 v5, 0x4

    const/4 v4, 0x4

    if-eqz v3, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    add-int/lit8 v2, v2, 0x1

    :cond_0
    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1}, Lkotlinx/coroutines/internal/y;->p0()Lkotlinx/coroutines/internal/y;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    return v2
.end method

.method private final q()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v4, 0x4

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->p0()Lkotlinx/coroutines/internal/y;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-ne v0, v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v0, "euEQomupyt"

    const-string v0, "QepyetuumE"

    const/4 v4, 0x2

    const-string/jumbo v0, "ueteQbypEu"

    const-string v0, "EmptyQueue"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object v0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    instance-of v1, v0, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    instance-of v1, v0, Lkotlinx/coroutines/channels/h0;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    const-string v1, "eudciuupRQeee"

    const-string v1, "eeeieuQpcuRde"

    const/4 v4, 0x6

    const-string v1, "educeiQpveeRe"

    const-string v1, "ReceiveQueued"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    instance-of v1, v0, Lkotlinx/coroutines/channels/l0;

    if-eqz v1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v1, "QeqdeunSqd"

    const-string v1, "neuSeddQqu"

    const/4 v4, 0x6

    const-string v1, "nusQeedSed"

    const-string v1, "SendQueued"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const-string v2, "X:DmsCNEUEP"

    const-string v2, "TEsUCED:XPN"

    const/4 v4, 0x6

    const-string v2, "CDEPoTENU:X"

    const-string v2, "UNEXPECTED:"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v2}, Lkotlinx/coroutines/internal/y;->q0()Lkotlinx/coroutines/internal/y;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eq v2, v0, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string v1, "mzeSube=eu,"

    const-string/jumbo v1, "uSzmeiee=,u"

    const/4 v4, 0x6

    const-string v1, "euSeieuzuq="

    const-string v1, ",queueSize="

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    move v4, v3

    invoke-direct {p0}, Lkotlinx/coroutines/channels/c;->e()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    instance-of v0, v2, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v0, :cond_4

    const/4 v3, 0x6

    move v4, v3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v1, "=ooesodperFdl,S"

    const-string v1, "ceFooSds,=ldore"

    const/4 v4, 0x0

    const-string v1, "odde=lcrqeF,oSn"

    const-string v1, ",closedForSend="

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_4
    const/4 v4, 0x3

    return-object v1
.end method

.method private final s(Lkotlinx/coroutines/channels/w;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/w<",
            "*>;)V"
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v0, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0, v1, v0}, Lkotlinx/coroutines/internal/q;->c(Ljava/lang/Object;ILkotlin/jvm/internal/w;)Ljava/lang/Object;

    move-result-object v2

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p1}, Lkotlinx/coroutines/internal/y;->q0()Lkotlinx/coroutines/internal/y;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    instance-of v4, v3, Lkotlinx/coroutines/channels/h0;

    const/4 v6, 0x0

    const/4 v5, 0x0

    if-eqz v4, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    check-cast v3, Lkotlinx/coroutines/channels/h0;

    const/4 v6, 0x7

    goto :goto_1

    :cond_0
    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-nez v3, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz v2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    instance-of v0, v2, Ljava/util/ArrayList;

    const/4 v6, 0x3

    const/4 v5, 0x7

    if-nez v0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    check-cast v2, Lkotlinx/coroutines/channels/h0;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v2, p1}, Lkotlinx/coroutines/channels/h0;->F0(Lkotlinx/coroutines/channels/w;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    goto :goto_3

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    check-cast v2, Ljava/util/ArrayList;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    sub-int/2addr v0, v1

    :goto_2
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v1, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ge v1, v0, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast v1, Lkotlinx/coroutines/channels/h0;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1, p1}, Lkotlinx/coroutines/channels/h0;->F0(Lkotlinx/coroutines/channels/w;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    add-int/lit8 v0, v0, -0x1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto :goto_2

    :cond_2
    :goto_3
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/c;->M(Lkotlinx/coroutines/internal/y;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v3}, Lkotlinx/coroutines/internal/y;->w0()Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-nez v4, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v3}, Lkotlinx/coroutines/internal/y;->r0()V

    const/4 v5, 0x4

    move v6, v5

    goto/16 :goto_0

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v2, v3}, Lkotlinx/coroutines/internal/q;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto/16 :goto_0
.end method

.method private final t(Ljava/lang/Object;Lkotlinx/coroutines/channels/w;)Ljava/lang/Throwable;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/channels/w<",
            "*>;)",
            "Ljava/lang/Throwable;"
        }
    .end annotation

    const/4 v4, 0x0

    invoke-direct {p0, p2}, Lkotlinx/coroutines/channels/c;->s(Lkotlinx/coroutines/channels/w;)V

    const/4 v3, 0x6

    move v4, v3

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v0, p1, v2, v1, v2}, Lkotlinx/coroutines/internal/i0;->d(Li8/l;Ljava/lang/Object;Lkotlinx/coroutines/internal/d1;ILjava/lang/Object;)Lkotlinx/coroutines/internal/d1;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-nez p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    invoke-virtual {p2}, Lkotlinx/coroutines/channels/w;->L0()Ljava/lang/Throwable;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-static {p1, p2}, Lkotlin/o;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    throw p1

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p2}, Lkotlinx/coroutines/channels/w;->L0()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object p1
.end method

.method private final v(Lkotlinx/coroutines/channels/w;)Ljava/lang/Throwable;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/w<",
            "*>;)",
            "Ljava/lang/Throwable;"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/c;->s(Lkotlinx/coroutines/channels/w;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/w;->L0()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method


# virtual methods
.method public C(Ljava/lang/Throwable;)Z
    .locals 7
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-instance v0, Lkotlinx/coroutines/channels/w;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {v0, p1}, Lkotlinx/coroutines/channels/w;-><init>(Ljava/lang/Throwable;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v1}, Lkotlinx/coroutines/internal/y;->q0()Lkotlinx/coroutines/internal/y;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    instance-of v3, v2, Lkotlinx/coroutines/channels/w;

    const/4 v6, 0x1

    const/4 v4, 0x1

    const/4 v6, 0x3

    move v5, v4

    move v5, v4

    const/4 v6, 0x1

    xor-int/2addr v3, v4

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-nez v3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v2, v0, v1}, Lkotlinx/coroutines/internal/y;->h0(Lkotlinx/coroutines/internal/y;Lkotlinx/coroutines/internal/y;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v2, :cond_0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz v4, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto :goto_1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->q0()Lkotlinx/coroutines/internal/y;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    check-cast v0, Lkotlinx/coroutines/channels/w;

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-direct {p0, v0}, Lkotlinx/coroutines/channels/c;->s(Lkotlinx/coroutines/channels/w;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz v4, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/c;->G(Ljava/lang/Throwable;)V

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    return v4
.end method

.method public final D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/c;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v1, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0, p1, p2}, Lkotlinx/coroutines/channels/c;->P(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x3

    if-ne p1, p2, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    return-object p1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x4

    return-object p1
.end method

.method public final E()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method protected abstract H()Z
.end method

.method protected abstract I()Z
.end method

.method protected K(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->Q()Lkotlinx/coroutines/channels/j0;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x7

    sget-object p1, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;

    const/4 v3, 0x3

    return-object p1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0, p1, v1}, Lkotlinx/coroutines/channels/j0;->X(Ljava/lang/Object;Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/j0;->r(Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {v0}, Lkotlinx/coroutines/channels/j0;->c()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p1
.end method

.method protected L(Ljava/lang/Object;Lkotlinx/coroutines/selects/f;)Ljava/lang/Object;
    .locals 3
    .param p2    # Lkotlinx/coroutines/selects/f;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/selects/f<",
            "*>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/c;->h(Ljava/lang/Object;)Lkotlinx/coroutines/channels/c$d;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {p2, v0}, Lkotlinx/coroutines/selects/f;->V(Lkotlinx/coroutines/internal/b;)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p2, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-object p2

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y$e;->o()Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast p2, Lkotlinx/coroutines/channels/j0;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {p2, p1}, Lkotlinx/coroutines/channels/j0;->r(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {p2}, Lkotlinx/coroutines/channels/j0;->c()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method protected M(Lkotlinx/coroutines/internal/y;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/internal/y;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method protected final O(Ljava/lang/Object;)Lkotlinx/coroutines/channels/j0;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Lkotlinx/coroutines/channels/j0<",
            "*>;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v1, Lkotlinx/coroutines/channels/c$a;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v1, p1}, Lkotlinx/coroutines/channels/c$a;-><init>(Ljava/lang/Object;)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->q0()Lkotlinx/coroutines/internal/y;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    instance-of v2, p1, Lkotlinx/coroutines/channels/j0;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    check-cast p1, Lkotlinx/coroutines/channels/j0;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object p1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1, v1, v0}, Lkotlinx/coroutines/internal/y;->h0(Lkotlinx/coroutines/internal/y;Lkotlinx/coroutines/internal/y;)Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object p1
.end method

.method protected Q()Lkotlinx/coroutines/channels/j0;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/j0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->o0()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    check-cast v1, Lkotlinx/coroutines/internal/y;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    if-ne v1, v0, :cond_0

    :goto_1
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_2

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    instance-of v3, v1, Lkotlinx/coroutines/channels/j0;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-nez v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    move-object v2, v1

    move-object v2, v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    check-cast v2, Lkotlinx/coroutines/channels/j0;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    instance-of v2, v2, Lkotlinx/coroutines/channels/w;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1}, Lkotlinx/coroutines/internal/y;->t0()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v2, :cond_2

    const/4 v5, 0x2

    goto :goto_2

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1}, Lkotlinx/coroutines/internal/y;->z0()Lkotlinx/coroutines/internal/y;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v2, :cond_3

    :goto_2
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    check-cast v1, Lkotlinx/coroutines/channels/j0;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-object v1

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2}, Lkotlinx/coroutines/internal/y;->s0()V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0
.end method

.method protected final R()Lkotlinx/coroutines/channels/l0;
    .locals 6
    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->o0()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    check-cast v1, Lkotlinx/coroutines/internal/y;

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x5

    if-ne v1, v0, :cond_0

    :goto_1
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_2

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    instance-of v3, v1, Lkotlinx/coroutines/channels/l0;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    check-cast v2, Lkotlinx/coroutines/channels/l0;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    instance-of v2, v2, Lkotlinx/coroutines/channels/w;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v1}, Lkotlinx/coroutines/internal/y;->t0()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_2

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1}, Lkotlinx/coroutines/internal/y;->z0()Lkotlinx/coroutines/internal/y;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-nez v2, :cond_3

    :goto_2
    const/4 v5, 0x3

    check-cast v1, Lkotlinx/coroutines/channels/l0;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-object v1

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v2}, Lkotlinx/coroutines/internal/y;->s0()V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_0
.end method

.method protected final f(Ljava/lang/Object;)Lkotlinx/coroutines/internal/y$b;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Lkotlinx/coroutines/internal/y$b<",
            "*>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Lkotlinx/coroutines/channels/c$b;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, v1, p1}, Lkotlinx/coroutines/channels/c$b;-><init>(Lkotlinx/coroutines/internal/w;Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method

.method protected final h(Ljava/lang/Object;)Lkotlinx/coroutines/channels/c$d;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Lkotlinx/coroutines/channels/c$d<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Lkotlinx/coroutines/channels/c$d;

    const/4 v3, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0, p1, v1}, Lkotlinx/coroutines/channels/c$d;-><init>(Ljava/lang/Object;Lkotlinx/coroutines/internal/w;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0
.end method

.method protected i(Lkotlinx/coroutines/channels/l0;)Ljava/lang/Object;
    .locals 6
    .param p1    # Lkotlinx/coroutines/channels/l0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->H()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v0, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->q0()Lkotlinx/coroutines/internal/y;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    instance-of v2, v1, Lkotlinx/coroutines/channels/j0;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object v1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1, p1, v0}, Lkotlinx/coroutines/internal/y;->h0(Lkotlinx/coroutines/internal/y;Lkotlinx/coroutines/internal/y;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_1

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v1, Lkotlinx/coroutines/channels/c$e;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v1, p1, p0}, Lkotlinx/coroutines/channels/c$e;-><init>(Lkotlinx/coroutines/internal/y;Lkotlinx/coroutines/channels/c;)V

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->q0()Lkotlinx/coroutines/internal/y;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    instance-of v3, v2, Lkotlinx/coroutines/channels/j0;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v3, :cond_3

    const/4 v5, 0x2

    return-object v2

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v2, p1, v0, v1}, Lkotlinx/coroutines/internal/y;->B0(Lkotlinx/coroutines/internal/y;Lkotlinx/coroutines/internal/y;Lkotlinx/coroutines/internal/y$c;)I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x7

    if-eq v2, v3, :cond_5

    const/4 v5, 0x5

    const/4 v3, 0x5

    const/4 v5, 0x5

    const/4 v3, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x7

    if-eq v2, v3, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_4
    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v3, 0x0

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v3, :cond_6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    sget-object p1, Lkotlinx/coroutines/channels/b;->g:Lkotlinx/coroutines/internal/r0;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-object p1

    :cond_6
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 p1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object p1
.end method

.method protected j()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public final k()Lkotlinx/coroutines/selects/e;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/selects/e<",
            "TE;",
            "Lkotlinx/coroutines/channels/m0<",
            "TE;>;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lkotlinx/coroutines/channels/c$f;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lkotlinx/coroutines/channels/c$f;-><init>(Lkotlinx/coroutines/channels/c;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method protected final m()Lkotlinx/coroutines/channels/w;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/w<",
            "*>;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->p0()Lkotlinx/coroutines/internal/y;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    instance-of v1, v0, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    check-cast v0, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Lkotlinx/coroutines/channels/c;->s(Lkotlinx/coroutines/channels/w;)V

    move-object v2, v0

    move-object v2, v0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object v2
.end method

.method protected final n()Lkotlinx/coroutines/channels/w;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/w<",
            "*>;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Lkotlinx/coroutines/internal/y;->q0()Lkotlinx/coroutines/internal/y;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    instance-of v1, v0, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    check-cast v0, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p0, v0}, Lkotlinx/coroutines/channels/c;->s(Lkotlinx/coroutines/channels/w;)V

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object v2
.end method

.method protected final o()Lkotlinx/coroutines/internal/w;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->b:Lkotlinx/coroutines/internal/w;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public offer(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)Z"
        }
    .end annotation

    :try_start_0
    const/4 v4, 0x0

    move v5, v4

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/m0$a;->c(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    return p1

    :catchall_0
    move-exception v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v1, p1, v3, v2, v3}, Lkotlinx/coroutines/internal/i0;->d(Li8/l;Ljava/lang/Object;Lkotlinx/coroutines/internal/d1;ILjava/lang/Object;)Lkotlinx/coroutines/internal/d1;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p1, v0}, Lkotlin/o;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    const/4 v4, 0x5

    move v5, v4

    throw p1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    throw v0
.end method

.method public final p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/c;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-object v0, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-ne p1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget-object p1, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget-object v0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Lkotlinx/coroutines/channels/r$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    sget-object v0, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x5

    if-ne p1, v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez p1, :cond_1

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget-object p1, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/r$b;->b()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object p1

    :cond_1
    const/4 v4, 0x6

    sget-object v0, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/c;->v(Lkotlinx/coroutines/channels/w;)Ljava/lang/Throwable;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/channels/r$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    instance-of v0, p1, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object v0, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v4, 0x2

    const/4 v3, 0x6

    check-cast p1, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/c;->v(Lkotlinx/coroutines/channels/w;)Ljava/lang/Throwable;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/channels/r$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object p1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v2, "S stdunbeeernrydr"

    const-string v2, " Srrtbddnuyeetnre"

    const/4 v4, 0x5

    const-string v2, "duSmnttry redner "

    const-string/jumbo v2, "trySend returned "

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    move v4, v3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    throw v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p0}, Lkotlinx/coroutines/z0;->a(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/16 v1, 0x40

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p0}, Lkotlinx/coroutines/z0;->b(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/16 v1, 0x7b

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    invoke-direct {p0}, Lkotlinx/coroutines/channels/c;->q()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/16 v1, 0x7d

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->j()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0
.end method

.method public x(Li8/l;)V
    .locals 5
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/l<",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    sget-object v0, Lkotlinx/coroutines/channels/c;->c:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0, p0, v1, p1}, Landroidx/concurrent/futures/b;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object p1, p0, Lkotlinx/coroutines/channels/c;->onCloseHandler:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v0, Lkotlinx/coroutines/channels/b;->h:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-ne p1, v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v0, " uaroe ave silashrwsndaf escdodesncl  uku lydgrreAernneleiohdta"

    const-string v0, "lddgr urvcoesa c e useAlaesaoefresalrhkntnnnrstdwiluy ed hi dae"

    const-string v0, " ryiobvaaheudrdtr l ruied acgssfdenyklehesAnne wtnlora ec sdael"

    const-string v0, "Another handler was already registered and successfully invoked"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    throw p1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v2, "nsregpudrrlrneai dthsdtewela oA a eye:ra"

    const-string v2, "heodeheprAtrgrnssraelr ydela adtwe i:na "

    const/4 v4, 0x6

    const-string v2, "arti sdpleoreew y rarldnas:h gheadtreA e"

    const-string v2, "Another handler was already registered: "

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    throw v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v1, :cond_2

    const/4 v3, 0x7

    const/4 v3, 0x2

    sget-object v2, Lkotlinx/coroutines/channels/b;->h:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0, p0, p1, v2}, Landroidx/concurrent/futures/b;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, v1, Lkotlinx/coroutines/channels/w;->d:Ljava/lang/Throwable;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {p1, v0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void
.end method
