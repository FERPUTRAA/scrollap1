.class final synthetic Lkotlinx/coroutines/channels/t;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nChannels.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Channels.kt\nkotlinx/coroutines/channels/ChannelsKt__ChannelsKt\n+ 2 Channel.kt\nkotlinx/coroutines/channels/ChannelKt\n*L\n1#1,61:1\n507#2,6:62\n*S KotlinDebug\n*F\n+ 1 Channels.kt\nkotlinx/coroutines/channels/ChannelsKt__ChannelsKt\n*L\n37#1:62,6\n*E\n"
.end annotation


# direct methods
.method public static final a(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;)V
    .locals 4
    .param p0    # Lkotlinx/coroutines/channels/m0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/m0<",
            "-TE;>;TE;)V"
        }
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'trySendBlocking\'. Consider handling the result of \'trySendBlocking\' explicitly and rethrow exception if necessary"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "trySendBlocking(element)"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/m0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0}, Lkotlinx/coroutines/channels/r;->m(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Lkotlinx/coroutines/channels/t$a;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0, p0, p1, v1}, Lkotlinx/coroutines/channels/t$a;-><init>(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;Lkotlin/coroutines/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v1, v0, p0, v1}, Lkotlinx/coroutines/j;->g(Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method public static final b(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .param p0    # Lkotlinx/coroutines/channels/m0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/m0<",
            "-TE;>;TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/m0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    instance-of v1, v0, Lkotlinx/coroutines/channels/r$c;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast v0, Lkotlin/s2;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    sget-object p0, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/r$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v0, Lkotlinx/coroutines/channels/t$b;

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    const/4 v1, 0x0

    and-int/2addr v3, v1

    const/4 v2, 0x3

    move v3, v2

    invoke-direct {v0, p0, p1, v1}, Lkotlinx/coroutines/channels/t$b;-><init>(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;Lkotlin/coroutines/d;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 p0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v1, v0, p0, v1}, Lkotlinx/coroutines/j;->g(Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast p0, Lkotlinx/coroutines/channels/r;

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/r;->o()Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object p0
.end method
