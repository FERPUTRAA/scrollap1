.class final Lkotlinx/coroutines/channels/v$k0;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/v;->d0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "-",
        "Lkotlin/collections/p0<",
        "Ljava/lang/Object;",
        ">;>;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.ChannelsKt__DeprecatedKt$withIndex$1"
    f = "Deprecated.kt"
    i = {
        0x0,
        0x0,
        0x1,
        0x1
    }
    l = {
        0x172,
        0x173
    }
    m = "invokeSuspend"
    n = {
        "$this$produce",
        "index",
        "$this$produce",
        "index"
    }
    s = {
        "L$0",
        "I$0",
        "L$0",
        "I$0"
    }
.end annotation


# instance fields
.field final synthetic $this_withIndex:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field I$0:I

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/v$k0;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/channels/v$k0;->$this_withIndex:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 p1, 0x2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Lkotlinx/coroutines/channels/v$k0;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$k0;->$this_withIndex:Lkotlinx/coroutines/channels/i0;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, v1, p2}, Lkotlinx/coroutines/channels/v$k0;-><init>(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$k0;->L$0:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$k0;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x3

    const/4 v11, 0x0

    iget v1, p0, Lkotlinx/coroutines/channels/v$k0;->label:I

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    const/4 v2, 0x2

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v3, 0x1

    const/4 v12, 0x7

    if-eqz v1, :cond_2

    const/4 v12, 0x1

    const/4 v11, 0x4

    if-eq v1, v3, :cond_1

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x6

    if-ne v1, v2, :cond_0

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget v1, p0, Lkotlinx/coroutines/channels/v$k0;->I$0:I

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    iget-object v4, p0, Lkotlinx/coroutines/channels/v$k0;->L$1:Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    check-cast v4, Lkotlinx/coroutines/channels/p;

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$k0;->L$0:Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x2

    check-cast v5, Lkotlinx/coroutines/channels/g0;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v9, v4

    move-object v9, v4

    move-object v9, v4

    move-object v9, v4

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x1

    move v4, v1

    move v4, v1

    const/4 v12, 0x4

    move v4, v1

    move v4, v1

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x7

    goto :goto_0

    :cond_0
    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x7

    const-string v0, "i/s/inucrcn/ms/av u re/oreh/oe /tt otow es o/fkeleb"

    const-string v0, "t/so/ oluremevcwfb ire/ toca t/e/eeknsuh r/nlio/o /"

    const/4 v12, 0x2

    const-string v0, "au mnteetokeeiln/wobirr l/ /hcft/ciu e/r/s/m/ovoo  "

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x5

    throw p1

    :cond_1
    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x5

    iget v1, p0, Lkotlinx/coroutines/channels/v$k0;->I$0:I

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    iget-object v4, p0, Lkotlinx/coroutines/channels/v$k0;->L$1:Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    check-cast v4, Lkotlinx/coroutines/channels/p;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x2

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$k0;->L$0:Ljava/lang/Object;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    check-cast v5, Lkotlinx/coroutines/channels/g0;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    goto :goto_1

    :cond_2
    const/4 v12, 0x2

    const/4 v11, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x1

    iget-object p1, p0, Lkotlinx/coroutines/channels/v$k0;->L$0:Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$k0;->$this_withIndex:Lkotlinx/coroutines/channels/i0;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-interface {v1}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v1

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 v4, 0x0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    :goto_0
    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x4

    iput-object p1, v5, Lkotlinx/coroutines/channels/v$k0;->L$0:Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x6

    iput-object v1, v5, Lkotlinx/coroutines/channels/v$k0;->L$1:Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x1

    iput v4, v5, Lkotlinx/coroutines/channels/v$k0;->I$0:I

    const/4 v12, 0x1

    const/4 v11, 0x6

    iput v3, v5, Lkotlinx/coroutines/channels/v$k0;->label:I

    const/4 v12, 0x2

    invoke-interface {v1, v5}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v6

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x7

    if-ne v6, v0, :cond_3

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    return-object v0

    :cond_3
    move-object v9, v5

    move-object v9, v5

    move-object v9, v5

    move-object v9, v5

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    move-object v6, v9

    move-object v6, v9

    move-object v6, v9

    move-object v6, v9

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    move v10, v4

    move v10, v4

    const/4 v12, 0x3

    move v10, v4

    move v10, v4

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    move v1, v10

    move v1, v10

    const/4 v12, 0x2

    move v1, v10

    move v1, v10

    :goto_1
    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    check-cast p1, Ljava/lang/Boolean;

    const/4 v12, 0x4

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x1

    if-eqz p1, :cond_5

    const/4 v12, 0x3

    invoke-interface {v4}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    new-instance v7, Lkotlin/collections/p0;

    add-int/lit8 v8, v1, 0x1

    const/4 v12, 0x7

    const/4 v11, 0x5

    invoke-direct {v7, v1, p1}, Lkotlin/collections/p0;-><init>(ILjava/lang/Object;)V

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    iput-object v5, v6, Lkotlinx/coroutines/channels/v$k0;->L$0:Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    iput-object v4, v6, Lkotlinx/coroutines/channels/v$k0;->L$1:Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x3

    iput v8, v6, Lkotlinx/coroutines/channels/v$k0;->I$0:I

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x1

    iput v2, v6, Lkotlinx/coroutines/channels/v$k0;->label:I

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-interface {v5, v7, v6}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    if-ne p1, v0, :cond_4

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x5

    return-object v0

    :cond_4
    move-object v1, v4

    move-object v1, v4

    move-object v1, v4

    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    move v4, v8

    move v4, v8

    const/4 v12, 0x1

    move v4, v8

    move v4, v8

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x0

    goto/16 :goto_0

    :cond_5
    const/4 v11, 0x0

    move v12, v11

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-",
            "Lkotlin/collections/p0<",
            "Ljava/lang/Object;",
            ">;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$k0;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    check-cast p1, Lkotlinx/coroutines/channels/v$k0;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/v$k0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    return-object p1
.end method
