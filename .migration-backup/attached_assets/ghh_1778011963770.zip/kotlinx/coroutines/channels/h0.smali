.class public abstract Lkotlinx/coroutines/channels/h0;
.super Lkotlinx/coroutines/internal/y;

# interfaces
.implements Lkotlinx/coroutines/channels/j0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/internal/y;",
        "Lkotlinx/coroutines/channels/j0<",
        "TE;>;"
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/internal/y;-><init>()V

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public D0()Lkotlinx/coroutines/internal/r0;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " os~t@  ~@f@~@@o~~ @lb@M1f4@~n~~~ ~~   o~ ~/~ b@ot@mS uvK~  rd~a @i~ c@/oy ~@i~oib@~l. @@-@@@~s@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    return-object v0
.end method

.method public E0(Ljava/lang/Object;)Li8/l;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Li8/l<",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p1
.end method

.method public abstract F0(Lkotlinx/coroutines/channels/w;)V
    .param p1    # Lkotlinx/coroutines/channels/w;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/w<",
            "*>;)V"
        }
    .end annotation
.end method

.method public bridge synthetic c()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/h0;->D0()Lkotlinx/coroutines/internal/r0;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method
