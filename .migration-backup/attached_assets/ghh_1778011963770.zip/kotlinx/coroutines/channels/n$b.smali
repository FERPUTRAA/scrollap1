.class public final Lkotlinx/coroutines/channels/n$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# static fields
.field static final synthetic a:Lkotlinx/coroutines/channels/n$b;

.field public static final b:I = 0x7fffffff

.field public static final c:I = 0x0

.field public static final d:I = -0x1

.field public static final e:I = -0x2

.field public static final f:I = -0x3

.field public static final g:Ljava/lang/String; = "kotlinx.coroutines.channels.defaultBuffer"
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final h:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    new-instance v0, Lkotlinx/coroutines/channels/n$b;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v0}, Lkotlinx/coroutines/channels/n$b;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    sput-object v0, Lkotlinx/coroutines/channels/n$b;->a:Lkotlinx/coroutines/channels/n$b;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const v1, 0x7ffffffe

    const/4 v5, 0x4

    const-string v2, ".uskiaxeodfufethtncorer.nlantuns.lBefsilo"

    const-string v2, "auseonsucfBatlo.tenodlketihnffle.nuxrri.s"

    const/4 v5, 0x7

    const-string v2, "cutmtfeaeuaxoiosnrentkB.frn.hdfoslucli.nl"

    const-string v2, "kotlinx.coroutines.channels.defaultBuffer"

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/16 v3, 0x40

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v2, v3, v0, v1}, Lkotlinx/coroutines/internal/t0;->b(Ljava/lang/String;III)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    sput v0, Lkotlinx/coroutines/channels/n$b;->h:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~~@o~ o@  f~i~ @fl~ @ lob~t@  ~@@~@~@~r~n.o~@@KM1 do@@-c~/~voub@~t@@y bs i~ i  @~@So@@ m~~~a/ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget v0, Lkotlinx/coroutines/channels/n$b;->h:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method
