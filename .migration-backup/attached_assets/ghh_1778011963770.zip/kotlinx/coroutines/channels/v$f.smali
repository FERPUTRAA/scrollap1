.class final Lkotlinx/coroutines/channels/v$f;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/v;->f(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "-TE;>;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.ChannelsKt__DeprecatedKt$distinctBy$1"
    f = "Deprecated.kt"
    i = {
        0x0,
        0x0,
        0x1,
        0x1,
        0x1,
        0x2,
        0x2,
        0x2
    }
    l = {
        0x183,
        0x184,
        0x186
    }
    m = "invokeSuspend"
    n = {
        "$this$produce",
        "keys",
        "$this$produce",
        "keys",
        "e",
        "$this$produce",
        "keys",
        "k"
    }
    s = {
        "L$0",
        "L$1",
        "L$0",
        "L$1",
        "L$3",
        "L$0",
        "L$1",
        "L$3"
    }
.end annotation


# instance fields
.field final synthetic $selector:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "TE;",
            "Lkotlin/coroutines/d<",
            "-TK;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $this_distinctBy:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field L$3:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/i0;Li8/p;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Li8/p<",
            "-TE;-",
            "Lkotlin/coroutines/d<",
            "-TK;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/v$f;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/channels/v$f;->$this_distinctBy:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p2, p0, Lkotlinx/coroutines/channels/v$f;->$selector:Li8/p;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Lkotlinx/coroutines/channels/v$f;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$f;->$this_distinctBy:Lkotlinx/coroutines/channels/i0;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v2, p0, Lkotlinx/coroutines/channels/v$f;->$selector:Li8/p;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/channels/v$f;-><init>(Lkotlinx/coroutines/channels/i0;Li8/p;Lkotlin/coroutines/d;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$f;->L$0:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$f;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 13
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget v1, p0, Lkotlinx/coroutines/channels/v$f;->label:I

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x1

    const/4 v2, 0x3

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    const/4 v3, 0x2

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x6

    const/4 v4, 0x1

    if-eqz v1, :cond_3

    const/4 v12, 0x3

    const/4 v11, 0x7

    if-eq v1, v4, :cond_2

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x2

    if-eq v1, v3, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    if-ne v1, v2, :cond_0

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$f;->L$3:Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$f;->L$2:Ljava/lang/Object;

    const/4 v11, 0x6

    check-cast v5, Lkotlinx/coroutines/channels/p;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$f;->L$1:Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    check-cast v6, Ljava/util/HashSet;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x3

    iget-object v7, p0, Lkotlinx/coroutines/channels/v$f;->L$0:Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x1

    check-cast v7, Lkotlinx/coroutines/channels/g0;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    goto/16 :goto_3

    :cond_0
    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x5

    const-string v0, "nestsieeioiv/et l euo/fmls/b//o catnhrukr/ /or/wc  "

    const-string v0, "ehs/uisi euma/n el tl//okrcn /e/oewborrcv/ oiott /f"

    const/4 v12, 0x0

    const-string v0, "ei/ma/mc/  hrwn//e/lutsieo uie contf/btooer/k  vlor"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v12, 0x1

    const/4 v11, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x7

    throw p1

    :cond_1
    const/4 v12, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$f;->L$3:Ljava/lang/Object;

    const/4 v11, 0x4

    move v12, v11

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$f;->L$2:Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x7

    check-cast v5, Lkotlinx/coroutines/channels/p;

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x4

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$f;->L$1:Ljava/lang/Object;

    const/4 v12, 0x7

    check-cast v6, Ljava/util/HashSet;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget-object v7, p0, Lkotlinx/coroutines/channels/v$f;->L$0:Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x1

    check-cast v7, Lkotlinx/coroutines/channels/g0;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x5

    goto/16 :goto_2

    :cond_2
    const/4 v12, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$f;->L$2:Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v12, 0x7

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x6

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$f;->L$1:Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x3

    check-cast v5, Ljava/util/HashSet;

    const/4 v11, 0x1

    xor-int/2addr v12, v11

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$f;->L$0:Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x2

    check-cast v6, Lkotlinx/coroutines/channels/g0;

    const/4 v11, 0x4

    const/4 v11, 0x7

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v7, v6

    move-object v7, v6

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x5

    goto/16 :goto_1

    :cond_3
    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x0

    iget-object p1, p0, Lkotlinx/coroutines/channels/v$f;->L$0:Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x3

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x1

    new-instance v1, Ljava/util/HashSet;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    const/4 v12, 0x2

    const/4 v11, 0x1

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$f;->$this_distinctBy:Lkotlinx/coroutines/channels/i0;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-interface {v5}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v5

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object v10, v5

    move-object v10, v5

    move-object v10, v5

    move-object v10, v5

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v1, v10

    move-object v1, v10

    move-object v1, v10

    move-object v1, v10

    :goto_0
    const/4 v12, 0x0

    const/4 v11, 0x7

    iput-object v6, p1, Lkotlinx/coroutines/channels/v$f;->L$0:Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x4

    iput-object v5, p1, Lkotlinx/coroutines/channels/v$f;->L$1:Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x0

    iput-object v1, p1, Lkotlinx/coroutines/channels/v$f;->L$2:Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x1

    const/4 v7, 0x0

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x0

    iput-object v7, p1, Lkotlinx/coroutines/channels/v$f;->L$3:Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    iput v4, p1, Lkotlinx/coroutines/channels/v$f;->label:I

    const/4 v12, 0x2

    const/4 v11, 0x7

    invoke-interface {v1, p1}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v7

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    if-ne v7, v0, :cond_4

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x0

    return-object v0

    :cond_4
    move-object v10, v0

    move-object v10, v0

    move-object v10, v0

    move-object v10, v0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v1, v10

    move-object v1, v10

    move-object v1, v10

    move-object v1, v10

    :goto_1
    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x5

    check-cast p1, Ljava/lang/Boolean;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x3

    if-eqz p1, :cond_8

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-interface {v5}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    iget-object v8, v0, Lkotlinx/coroutines/channels/v$f;->$selector:Li8/p;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    iput-object v7, v0, Lkotlinx/coroutines/channels/v$f;->L$0:Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x2

    iput-object v6, v0, Lkotlinx/coroutines/channels/v$f;->L$1:Ljava/lang/Object;

    const/4 v12, 0x2

    iput-object v5, v0, Lkotlinx/coroutines/channels/v$f;->L$2:Ljava/lang/Object;

    const/4 v12, 0x2

    const/4 v11, 0x7

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$f;->L$3:Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    iput v3, v0, Lkotlinx/coroutines/channels/v$f;->label:I

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-interface {v8, p1, v0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x5

    if-ne v8, v1, :cond_5

    const/4 v12, 0x4

    return-object v1

    :cond_5
    move-object v10, v6

    move-object v10, v6

    move-object v10, v6

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object p1, v8

    move-object p1, v8

    move-object p1, v8

    move-object p1, v8

    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    move-object v7, v10

    move-object v7, v10

    move-object v7, v10

    move-object v7, v10

    :goto_2
    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-virtual {v7, p1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v9

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x3

    if-nez v9, :cond_7

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x6

    iput-object v8, v0, Lkotlinx/coroutines/channels/v$f;->L$0:Ljava/lang/Object;

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    iput-object v7, v0, Lkotlinx/coroutines/channels/v$f;->L$1:Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x7

    iput-object v5, v0, Lkotlinx/coroutines/channels/v$f;->L$2:Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x2

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$f;->L$3:Ljava/lang/Object;

    const/4 v12, 0x4

    iput v2, v0, Lkotlinx/coroutines/channels/v$f;->label:I

    const/4 v12, 0x0

    invoke-interface {v8, v6, v0}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v6

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    if-ne v6, v1, :cond_6

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x3

    return-object v1

    :cond_6
    move-object v6, v7

    move-object v6, v7

    move-object v7, v8

    move-object v7, v8

    move-object v7, v8

    move-object v7, v8

    move-object v10, v1

    move-object v10, v1

    move-object v10, v1

    move-object v10, v1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    :goto_3
    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-interface {v6, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    goto/16 :goto_0

    :cond_7
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    move-object v5, v7

    move-object v5, v7

    move-object v5, v7

    move-object v5, v7

    move-object v6, v8

    move-object v6, v8

    move-object v6, v8

    move-object v6, v8

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x6

    goto/16 :goto_0

    :cond_8
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-TE;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$f;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    check-cast p1, Lkotlinx/coroutines/channels/v$f;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/v$f;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p1
.end method
