.class final Lkotlinx/coroutines/channels/p0$b;
.super Lkotlin/coroutines/jvm/internal/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/p0;->d(JJLkotlinx/coroutines/channels/m0;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.TickerChannelsKt"
    f = "TickerChannels.kt"
    i = {
        0x0,
        0x0,
        0x0,
        0x1,
        0x1,
        0x1,
        0x2,
        0x2,
        0x2,
        0x3,
        0x3,
        0x3
    }
    l = {
        0x54,
        0x58,
        0x5e,
        0x60
    }
    m = "fixedPeriodTicker"
    n = {
        "channel",
        "delayMillis",
        "deadline",
        "channel",
        "deadline",
        "delayNs",
        "channel",
        "deadline",
        "delayNs",
        "channel",
        "deadline",
        "delayNs"
    }
    s = {
        "L$0",
        "J$0",
        "J$1",
        "L$0",
        "J$0",
        "J$1",
        "L$0",
        "J$0",
        "J$1",
        "L$0",
        "J$0",
        "J$1"
    }
.end annotation


# instance fields
.field J$0:J

.field J$1:J

.field L$0:Ljava/lang/Object;

.field label:I

.field synthetic result:Ljava/lang/Object;


# direct methods
.method constructor <init>(Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/p0$b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lkotlin/coroutines/jvm/internal/d;-><init>(Lkotlin/coroutines/d;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/channels/p0$b;->result:Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget p1, p0, Lkotlinx/coroutines/channels/p0$b;->label:I

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/high16 v0, -0x80000000

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    or-int/2addr p1, v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    iput p1, p0, Lkotlinx/coroutines/channels/p0$b;->label:I

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v4, 0x0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static/range {v0 .. v5}, Lkotlinx/coroutines/channels/p0;->b(JJLkotlinx/coroutines/channels/m0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    return-object p1
.end method
