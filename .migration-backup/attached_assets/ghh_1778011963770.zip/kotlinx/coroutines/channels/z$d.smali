.class final Lkotlinx/coroutines/channels/z$d;
.super Lkotlinx/coroutines/channels/a0;

# interfaces
.implements Lkotlinx/coroutines/channels/i0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/z;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/a0<",
        "TE;>;",
        "Lkotlinx/coroutines/channels/i0<",
        "TE;>;"
    }
.end annotation


# instance fields
.field private final f:Lkotlinx/coroutines/channels/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/z<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/channels/z;)V
    .locals 3
    .param p1    # Lkotlinx/coroutines/channels/z;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/z<",
            "TE;>;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lkotlinx/coroutines/channels/a0;-><init>(Li8/l;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/channels/z$d;->f:Lkotlinx/coroutines/channels/z;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public K(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-super {p0, p1}, Lkotlinx/coroutines/channels/a0;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method

.method protected f0(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/channels/z$d;->f:Lkotlinx/coroutines/channels/z;

    const/4 v1, 0x5

    invoke-static {p1, p0}, Lkotlinx/coroutines/channels/z;->a(Lkotlinx/coroutines/channels/z;Lkotlinx/coroutines/channels/z$d;)V

    :cond_0
    const/4 v1, 0x6

    return-void
.end method
