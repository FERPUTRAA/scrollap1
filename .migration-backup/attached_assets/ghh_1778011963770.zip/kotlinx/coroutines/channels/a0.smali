.class public Lkotlinx/coroutines/channels/a0;
.super Lkotlinx/coroutines/channels/a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/a<",
        "TE;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nConflatedChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ConflatedChannel.kt\nkotlinx/coroutines/channels/ConflatedChannel\n+ 2 Concurrent.kt\nkotlinx/coroutines/internal/ConcurrentKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,144:1\n17#2:145\n17#2:146\n17#2:147\n17#2:149\n17#2:150\n17#2:151\n17#2:152\n17#2:153\n17#2:154\n1#3:148\n*S KotlinDebug\n*F\n+ 1 ConflatedChannel.kt\nkotlinx/coroutines/channels/ConflatedChannel\n*L\n22#1:145\n26#1:146\n35#1:147\n63#1:149\n96#1:150\n107#1:151\n119#1:152\n135#1:153\n142#1:154\n*E\n"
.end annotation


# instance fields
.field private final d:Ljava/util/concurrent/locks/ReentrantLock;
    .annotation build Lia/d;
    .end annotation
.end field

.field private e:Ljava/lang/Object;
    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Li8/l;)V
    .locals 2
    .param p1    # Li8/l;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/a;-><init>(Li8/l;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    new-instance p1, Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/channels/a0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    sget-object p1, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method private final p0(Ljava/lang/Object;)Lkotlinx/coroutines/internal/d1;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@fs~ @@@ /al~f ~@bo-~@iKl@ ~@i@ @d@@4~ .@ bsu o@~m~@r~y~ ~o in@c~t~ o~~@~1 ~/ ~b@@ o Mt S~ o~v@~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget-object v1, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x0

    xor-int/2addr v5, v2

    const/4 v4, 0x2

    move v5, v4

    if-ne v0, v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v1, v0, v2, v3, v2}, Lkotlinx/coroutines/internal/i0;->d(Li8/l;Ljava/lang/Object;Lkotlinx/coroutines/internal/d1;ILjava/lang/Object;)Lkotlinx/coroutines/internal/d1;

    move-result-object v2

    :cond_1
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-object v2
.end method


# virtual methods
.method protected final H()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method protected final I()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method protected K(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/channels/a0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object v1

    :cond_0
    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x2

    sget-object v2, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-ne v1, v2, :cond_4

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/a;->Q()Lkotlinx/coroutines/channels/j0;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    instance-of v2, v1, Lkotlinx/coroutines/channels/w;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    if-eqz v2, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object v1

    :cond_3
    :try_start_2
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v1}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {v1, p1, v2}, Lkotlinx/coroutines/channels/j0;->X(Ljava/lang/Object;Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object v2, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {v1, p1}, Lkotlinx/coroutines/channels/j0;->r(Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {v1}, Lkotlinx/coroutines/channels/j0;->c()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object p1

    :cond_4
    :goto_0
    :try_start_3
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/a0;->p0(Ljava/lang/Object;)Lkotlinx/coroutines/internal/d1;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez p1, :cond_5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget-object p1, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object p1

    :cond_5
    :try_start_4
    const/4 v4, 0x0

    const/4 v3, 0x1

    throw p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    throw p1
.end method

.method protected L(Ljava/lang/Object;Lkotlinx/coroutines/selects/f;)Ljava/lang/Object;
    .locals 5
    .param p2    # Lkotlinx/coroutines/selects/f;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/selects/f<",
            "*>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/a0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v1

    :cond_0
    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    sget-object v2, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-ne v1, v2, :cond_5

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/c;->h(Ljava/lang/Object;)Lkotlinx/coroutines/channels/c$d;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {p2, v1}, Lkotlinx/coroutines/selects/f;->V(Lkotlinx/coroutines/internal/b;)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x2

    if-nez v2, :cond_2

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1}, Lkotlinx/coroutines/internal/y$e;->o()Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    sget-object v1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-static {p2}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    check-cast p2, Lkotlinx/coroutines/channels/j0;

    const/4 v4, 0x1

    invoke-interface {p2, p1}, Lkotlinx/coroutines/channels/j0;->r(Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p2}, Lkotlinx/coroutines/channels/j0;->c()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object p1

    :cond_2
    :try_start_2
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    sget-object v1, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eq v2, v1, :cond_5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    sget-object v1, Lkotlinx/coroutines/internal/c;->b:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eq v2, v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eq v2, p1, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    instance-of p1, v2, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz p1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const-string v1, "iutmrrOfmcrfdytrpAer rrTsdeerne sT(etSmb)leeifcoey"

    const-string v1, "l(sefenrroAefecrmm ytptyOrrTriufTebrerd)dciSs teoe"

    const/4 v4, 0x2

    const-string v1, "imreoSseeT)f(ertncrlrrypbmcfr ftTteireAdudy eocOeo"

    const-string v1, "performAtomicTrySelect(describeTryOffer) returned "

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :cond_4
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object v2

    :cond_5
    :try_start_3
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {p2}, Lkotlinx/coroutines/selects/f;->I()Z

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez p2, :cond_6

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x3

    move v4, v3

    return-object p1

    :cond_6
    :try_start_4
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/a0;->p0(Ljava/lang/Object;)Lkotlinx/coroutines/internal/d1;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-nez p1, :cond_7

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    sget-object p1, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object p1

    :cond_7
    :try_start_5
    const/4 v4, 0x1

    const/4 v3, 0x7

    throw p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    throw p1
.end method

.method protected Z(Lkotlinx/coroutines/channels/h0;)Z
    .locals 3
    .param p1    # Lkotlinx/coroutines/channels/h0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/h0<",
            "-TE;>;)Z"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/a0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-super {p0, p1}, Lkotlinx/coroutines/channels/a;->Z(Lkotlinx/coroutines/channels/h0;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    throw p1
.end method

.method protected final c0()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    return v0
.end method

.method protected final d0()Z
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/a0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x6

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    sget-object v2, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-ne v1, v2, :cond_0

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x4

    xor-int/2addr v3, v1

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    return v1

    :catchall_0
    move-exception v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    throw v1
.end method

.method protected f0(Z)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/a0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object v1, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-direct {p0, v1}, Lkotlinx/coroutines/channels/a0;->p0(Ljava/lang/Object;)Lkotlinx/coroutines/internal/d1;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    sget-object v2, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-super {p0, p1}, Lkotlinx/coroutines/channels/a;->f0(Z)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-nez v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    throw v1

    :catchall_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    throw p1
.end method

.method public isEmpty()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/a0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/a;->e0()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw v1
.end method

.method protected j()Ljava/lang/String;
    .locals 5
    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/a0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v2, "m=evubl"

    const-string v2, "lu=m(ev"

    const-string v2, "=ua(lvu"

    const-string v2, "(value="

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/16 v2, 0x29

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    throw v1
.end method

.method protected j0()Ljava/lang/Object;
    .locals 5
    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/a0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget-object v2, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-ne v1, v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget-object v1, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object v1

    :cond_1
    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object v2, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget-object v2, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    throw v1
.end method

.method protected k0(Lkotlinx/coroutines/selects/f;)Ljava/lang/Object;
    .locals 5
    .param p1    # Lkotlinx/coroutines/selects/f;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/selects/f<",
            "*>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/a0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    sget-object v2, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-ne v1, v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-nez p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    sget-object p1, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x4

    const/4 v3, 0x4

    return-object p1

    :cond_1
    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {p1}, Lkotlinx/coroutines/selects/f;->I()Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez p1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object p1

    :cond_2
    :try_start_2
    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object p1, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v2, p0, Lkotlinx/coroutines/channels/a0;->e:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    sget-object v1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    throw p1
.end method
