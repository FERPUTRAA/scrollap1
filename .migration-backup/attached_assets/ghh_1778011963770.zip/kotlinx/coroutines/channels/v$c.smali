.class final Lkotlinx/coroutines/channels/v$c;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/v;->c([Lkotlinx/coroutines/channels/i0;)Li8/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/l<",
        "Ljava/lang/Throwable;",
        "Lkotlin/s2;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeprecated.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Deprecated.kt\nkotlinx/coroutines/channels/ChannelsKt__DeprecatedKt$consumesAll$1\n+ 2 Exceptions.kt\nkotlinx/coroutines/ExceptionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,479:1\n75#2:480\n1#3:481\n*S KotlinDebug\n*F\n+ 1 Deprecated.kt\nkotlinx/coroutines/channels/ChannelsKt__DeprecatedKt$consumesAll$1\n*L\n26#1:480\n*E\n"
.end annotation


# instance fields
.field final synthetic $channels:[Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlinx/coroutines/channels/i0<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>([Lkotlinx/coroutines/channels/i0;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lkotlinx/coroutines/channels/i0<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/channels/v$c;->$channels:[Lkotlinx/coroutines/channels/i0;

    const/4 v0, 0x0

    and-int/2addr v1, v0

    const/4 p1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s~@-~r4~~t  @@~M@o c~~~K/@  o Sob@ @f~@ l~s~@ t@~@~~@o@~b /o ~d@~vl@~@ i@an. ub1f~@~ yio@m  i~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    check-cast p1, Ljava/lang/Throwable;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/v$c;->invoke(Ljava/lang/Throwable;)V

    const/4 v0, 0x0

    const/4 v0, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p1
.end method

.method public final invoke(Ljava/lang/Throwable;)V
    .locals 7
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v6, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/channels/v$c;->$channels:[Lkotlinx/coroutines/channels/i0;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    array-length v1, v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v6, 0x1

    const/4 v3, 0x5

    const/4 v6, 0x7

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ge v3, v1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    aget-object v4, v0, v3

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v4, p1}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_1

    :catchall_0
    move-exception v4

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez v2, :cond_0

    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_1

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v2, v4}, Lkotlin/o;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v2, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    return-void

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    throw v2
.end method
