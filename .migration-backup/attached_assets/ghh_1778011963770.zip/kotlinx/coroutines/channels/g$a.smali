.class final Lkotlinx/coroutines/channels/g$a;
.super Lkotlinx/coroutines/channels/a;

# interfaces
.implements Lkotlinx/coroutines/channels/i0;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/a<",
        "TE;>;",
        "Lkotlinx/coroutines/channels/i0<",
        "TE;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nArrayBroadcastChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ArrayBroadcastChannel.kt\nkotlinx/coroutines/channels/ArrayBroadcastChannel$Subscriber\n+ 2 Concurrent.kt\nkotlinx/coroutines/internal/ConcurrentKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,385:1\n17#2:386\n17#2:388\n17#2:389\n1#3:387\n*S KotlinDebug\n*F\n+ 1 ArrayBroadcastChannel.kt\nkotlinx/coroutines/channels/ArrayBroadcastChannel$Subscriber\n*L\n233#1:386\n283#1:388\n312#1:389\n*E\n"
.end annotation


# instance fields
.field private volatile synthetic _subHead:J
    .annotation build Lia/d;
    .end annotation
.end field

.field private final d:Lkotlinx/coroutines/channels/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/g<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field private final e:Ljava/util/concurrent/locks/ReentrantLock;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/channels/g;)V
    .locals 4
    .param p1    # Lkotlinx/coroutines/channels/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g<",
            "TE;>;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v0, 0x0

    xor-int/2addr v3, v0

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {p0, v0}, Lkotlinx/coroutines/channels/a;-><init>(Li8/l;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/channels/g$a;->d:Lkotlinx/coroutines/channels/g;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance p1, Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p1}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/channels/g$a;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-wide v0, p0, Lkotlinx/coroutines/channels/g$a;->_subHead:J

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method private final r0()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@st~o@bM@i u~ ~@.@t@ ay @@ @b  /~-@~K il~o @o1/@ @c~~@rbv @~~d ~oo  ~~ ~ o~@n@~@~4sf~f@lSm ~i~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->m()Lkotlinx/coroutines/channels/w;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x0

    and-int/2addr v3, v1

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/g$a;->d0()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/g$a;->d:Lkotlinx/coroutines/channels/g;

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0}, Lkotlinx/coroutines/channels/c;->m()Lkotlinx/coroutines/channels/w;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x6

    return v1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    return v0
.end method

.method private final s0()Ljava/lang/Object;
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/g$a;->q0()J

    move-result-wide v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v2, p0, Lkotlinx/coroutines/channels/g$a;->d:Lkotlinx/coroutines/channels/g;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v2}, Lkotlinx/coroutines/channels/c;->m()Lkotlinx/coroutines/channels/w;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v3, p0, Lkotlinx/coroutines/channels/g$a;->d:Lkotlinx/coroutines/channels/g;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v3}, Lkotlinx/coroutines/channels/g;->T(Lkotlinx/coroutines/channels/g;)J

    move-result-wide v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    cmp-long v3, v0, v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-ltz v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-nez v2, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->m()Lkotlinx/coroutines/channels/w;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v2, :cond_0

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    sget-object v2, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    return-object v2

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/channels/g$a;->d:Lkotlinx/coroutines/channels/g;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v2, v0, v1}, Lkotlinx/coroutines/channels/g;->S(Lkotlinx/coroutines/channels/g;J)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->m()Lkotlinx/coroutines/channels/w;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x5

    move v6, v5

    return-object v1

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-object v0
.end method


# virtual methods
.method public C(Ljava/lang/Throwable;)Z
    .locals 5
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-super {p0, p1}, Lkotlinx/coroutines/channels/c;->C(Ljava/lang/Throwable;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/channels/g$a;->d:Lkotlinx/coroutines/channels/g;

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-static {v0, v2, p0, v1, v2}, Lkotlinx/coroutines/channels/g;->h0(Lkotlinx/coroutines/channels/g;Lkotlinx/coroutines/channels/g$a;Lkotlinx/coroutines/channels/g$a;ILjava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/g$a;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/g$a;->d:Lkotlinx/coroutines/channels/g;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v1}, Lkotlinx/coroutines/channels/g;->T(Lkotlinx/coroutines/channels/g;)J

    move-result-wide v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0, v1, v2}, Lkotlinx/coroutines/channels/g$a;->t0(J)V

    const/4 v4, 0x2

    sget-object v1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    throw p1

    :cond_0
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    return p1
.end method

.method protected H()Z
    .locals 4

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v1, "bu msdh sn utlSdeo"

    const-string/jumbo v1, "u so thsbo nuSdeld"

    const/4 v3, 0x6

    const-string v1, "h usonooleStub ed "

    const-string v1, "Should not be used"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw v0
.end method

.method protected I()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string/jumbo v1, "u lhtbomond Sdebe "

    const-string v1, "h umudbo oted enSl"

    const/4 v3, 0x4

    const-string v1, "h  nteuuodSs oelub"

    const-string v1, "Should not be used"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw v0
.end method

.method protected c0()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method protected d0()Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/g$a;->q0()J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v2, p0, Lkotlinx/coroutines/channels/g$a;->d:Lkotlinx/coroutines/channels/g;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v2}, Lkotlinx/coroutines/channels/g;->T(Lkotlinx/coroutines/channels/g;)J

    move-result-wide v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    cmp-long v0, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ltz v0, :cond_0

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x3

    and-int/2addr v4, v0

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    return v0
.end method

.method protected j0()Ljava/lang/Object;
    .locals 10
    .annotation build Lia/e;
    .end annotation

    const/4 v9, 0x7

    const/4 v8, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/g$a;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v8, 0x7

    and-int/2addr v9, v8

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v9, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g$a;->s0()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    instance-of v2, v1, Lkotlinx/coroutines/channels/w;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v3, 0x1

    and-int/2addr v9, v3

    const/4 v8, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-nez v2, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    sget-object v2, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-eq v1, v2, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/g$a;->q0()J

    move-result-wide v4

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v9, 0x7

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    add-long/2addr v4, v6

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p0, v4, v5}, Lkotlinx/coroutines/channels/g$a;->t0(J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    move v2, v3

    move v2, v3

    const/4 v9, 0x3

    move v2, v3

    move v2, v3

    const/4 v8, 0x2

    or-int/2addr v9, v8

    goto :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    instance-of v0, v1, Lkotlinx/coroutines/channels/w;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 v4, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz v0, :cond_1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    check-cast v0, Lkotlinx/coroutines/channels/w;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    goto :goto_1

    :cond_1
    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-eqz v0, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x1

    iget-object v0, v0, Lkotlinx/coroutines/channels/w;->d:Ljava/lang/Throwable;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p0, v0}, Lkotlinx/coroutines/channels/g$a;->C(Ljava/lang/Throwable;)Z

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/g$a;->p0()Z

    move-result v0

    const/4 v9, 0x2

    if-eqz v0, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    goto :goto_2

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    move v3, v2

    move v3, v2

    const/4 v9, 0x6

    move v3, v2

    move v3, v2

    :goto_2
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-eqz v3, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/channels/g$a;->d:Lkotlinx/coroutines/channels/g;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 v2, 0x3

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {v0, v4, v4, v2, v4}, Lkotlinx/coroutines/channels/g;->h0(Lkotlinx/coroutines/channels/g;Lkotlinx/coroutines/channels/g$a;Lkotlinx/coroutines/channels/g$a;ILjava/lang/Object;)V

    :cond_4
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v8, 0x4

    shr-int/2addr v9, v8

    throw v1
.end method

.method protected k0(Lkotlinx/coroutines/selects/f;)Ljava/lang/Object;
    .locals 10
    .param p1    # Lkotlinx/coroutines/selects/f;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/selects/f<",
            "*>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/g$a;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v8, 0x7

    move v9, v8

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g$a;->s0()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    instance-of v2, v1, Lkotlinx/coroutines/channels/w;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v3, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 v4, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-nez v2, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    sget-object v2, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eq v1, v2, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-interface {p1}, Lkotlinx/coroutines/selects/f;->I()Z

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-nez p1, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    goto :goto_0

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/g$a;->q0()J

    move-result-wide v4

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v9, 0x1

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    add-long/2addr v4, v6

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p0, v4, v5}, Lkotlinx/coroutines/channels/g$a;->t0(J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    move v4, v3

    move v4, v3

    const/4 v9, 0x7

    move v4, v3

    move v4, v3

    :cond_1
    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    instance-of p1, v1, Lkotlinx/coroutines/channels/w;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/4 v0, 0x0

    const/4 v8, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-eqz p1, :cond_2

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    check-cast p1, Lkotlinx/coroutines/channels/w;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_1

    :cond_2
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-eqz p1, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget-object p1, p1, Lkotlinx/coroutines/channels/w;->d:Ljava/lang/Throwable;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/g$a;->C(Ljava/lang/Throwable;)Z

    :cond_3
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/g$a;->p0()Z

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz p1, :cond_4

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    goto :goto_2

    :cond_4
    const/4 v8, 0x1

    move v9, v8

    move v3, v4

    move v3, v4

    move v3, v4

    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-eqz v3, :cond_5

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/channels/g$a;->d:Lkotlinx/coroutines/channels/g;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/4 v2, 0x3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {p1, v0, v0, v2, v0}, Lkotlinx/coroutines/channels/g;->h0(Lkotlinx/coroutines/channels/g;Lkotlinx/coroutines/channels/g$a;Lkotlinx/coroutines/channels/g$a;ILjava/lang/Object;)V

    :cond_5
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    return-object v1

    :catchall_0
    move-exception p1

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    throw p1
.end method

.method public final p0()Z
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v0, 0x0

    xor-int/2addr v9, v0

    :goto_0
    const/4 v8, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g$a;->r0()Z

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v2, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eqz v1, :cond_5

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/g$a;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->tryLock()Z

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-eqz v1, :cond_5

    :try_start_0
    const/4 v9, 0x3

    const/4 v8, 0x0

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g$a;->s0()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    sget-object v3, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-ne v1, v3, :cond_0

    :goto_1
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/channels/g$a;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto :goto_0

    :cond_0
    :try_start_1
    const/4 v9, 0x4

    instance-of v3, v1, Lkotlinx/coroutines/channels/w;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-eqz v3, :cond_1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    check-cast v2, Lkotlinx/coroutines/channels/w;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_2
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/g$a;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    goto :goto_3

    :cond_1
    :try_start_2
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/a;->Q()Lkotlinx/coroutines/channels/j0;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-nez v3, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_2

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    instance-of v4, v3, Lkotlinx/coroutines/channels/w;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eqz v4, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    goto :goto_2

    :cond_3
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-interface {v3, v1, v2}, Lkotlinx/coroutines/channels/j0;->X(Ljava/lang/Object;Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-nez v2, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    goto :goto_1

    :cond_4
    const/4 v9, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/g$a;->q0()J

    move-result-wide v4

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v9, 0x5

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    add-long/2addr v4, v6

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p0, v4, v5}, Lkotlinx/coroutines/channels/g$a;->t0(J)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/channels/g$a;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v9, 0x3

    invoke-interface {v3, v1}, Lkotlinx/coroutines/channels/j0;->r(Ljava/lang/Object;)V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    const/4 v0, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    const/4 v9, 0x6

    const/4 v8, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/g$a;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v9, 0x3

    throw v0

    :cond_5
    :goto_3
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-eqz v2, :cond_6

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    iget-object v1, v2, Lkotlinx/coroutines/channels/w;->d:Ljava/lang/Throwable;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {p0, v1}, Lkotlinx/coroutines/channels/g$a;->C(Ljava/lang/Throwable;)Z

    :cond_6
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    return v0
.end method

.method public final q0()J
    .locals 4

    const/4 v3, 0x6

    iget-wide v0, p0, Lkotlinx/coroutines/channels/g$a;->_subHead:J

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-wide v0
.end method

.method public final t0(J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-wide p1, p0, Lkotlinx/coroutines/channels/g$a;->_subHead:J

    const/4 v1, 0x2

    const/4 v0, 0x6

    return-void
.end method
