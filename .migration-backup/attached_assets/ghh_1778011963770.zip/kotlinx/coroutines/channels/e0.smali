.class public final Lkotlinx/coroutines/channels/e0;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nProduce.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Produce.kt\nkotlinx/coroutines/channels/ProduceKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 CancellableContinuation.kt\nkotlinx/coroutines/CancellableContinuationKt\n*L\n1#1,151:1\n1#2:152\n314#3,11:153\n*S KotlinDebug\n*F\n+ 1 Produce.kt\nkotlinx/coroutines/channels/ProduceKt\n*L\n48#1:153,11\n*E\n"
.end annotation


# direct methods
.method public static final a(Lkotlinx/coroutines/channels/g0;Li8/a;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p0    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/a;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "*>;",
            "Li8/a<",
            "Lkotlin/s2;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x0

    const-string v4, "@-sb~i~@or4d~  ~~f@bs o@@@t ~@~@  @1~nt~. ~~aly o~ v@ ~o@oi~~ ~~@/@MScK@u l@~~ b/o ~ m@i@~ @@ ~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    instance-of v0, p2, Lkotlinx/coroutines/channels/e0$a;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    check-cast v0, Lkotlinx/coroutines/channels/e0$a;

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget v1, v0, Lkotlinx/coroutines/channels/e0$a;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/high16 v2, -0x80000000

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    and-int v3, v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    sub-int/2addr v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput v1, v0, Lkotlinx/coroutines/channels/e0$a;->label:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v0, Lkotlinx/coroutines/channels/e0$a;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {v0, p2}, Lkotlinx/coroutines/channels/e0$a;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object p2, v0, Lkotlinx/coroutines/channels/e0$a;->result:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v2, v0, Lkotlinx/coroutines/channels/e0$a;->label:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-ne v2, v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object p0, v0, Lkotlinx/coroutines/channels/e0$a;->L$1:Ljava/lang/Object;

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    check-cast p1, Li8/a;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object p0, v0, Lkotlinx/coroutines/channels/e0$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    check-cast p0, Lkotlinx/coroutines/channels/g0;

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    goto/16 :goto_2

    :catchall_0
    move-exception p0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto/16 :goto_3

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const-string p1, "ei/m/chmslce/  o/ a/rturto/nel noui kvsoeew/r/f tib"

    const-string p1, "rtso eru/o/ri/ic /ofet/es  ewuo  vnkbma//cll/ehenit"

    const/4 v5, 0x3

    const-string p1, " rteoitekoicr t /l/enba/  soe/lnur/uic/ohef/omw v/e"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    throw p0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p2}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v0}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    sget-object v2, Lkotlinx/coroutines/n2;->n0:Lkotlinx/coroutines/n2$b;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {p2, v2}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-ne p2, p0, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    move p2, v3

    move p2, v3

    move p2, v3

    const/4 v5, 0x1

    const/4 v4, 0x1

    goto :goto_1

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 p2, 0x0

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz p2, :cond_6

    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput-object p0, v0, Lkotlinx/coroutines/channels/e0$a;->L$0:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    iput-object p1, v0, Lkotlinx/coroutines/channels/e0$a;->L$1:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput v3, v0, Lkotlinx/coroutines/channels/e0$a;->label:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance p2, Lkotlinx/coroutines/r;

    const/4 v4, 0x6

    move v5, v4

    invoke-static {v0}, Lkotlin/coroutines/intrinsics/b;->e(Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {p2, v2, v3}, Lkotlinx/coroutines/r;-><init>(Lkotlin/coroutines/d;I)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p2}, Lkotlinx/coroutines/r;->R()V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v2, Lkotlinx/coroutines/channels/e0$c;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {v2, p2}, Lkotlinx/coroutines/channels/e0$c;-><init>(Lkotlinx/coroutines/q;)V

    const/4 v4, 0x3

    shl-int/2addr v5, v4

    invoke-interface {p0, v2}, Lkotlinx/coroutines/channels/m0;->x(Li8/l;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p2}, Lkotlinx/coroutines/r;->w()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-ne p0, p2, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v0}, Lkotlin/coroutines/jvm/internal/h;->c(Lkotlin/coroutines/d;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-ne p0, v1, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object v1

    :cond_5
    :goto_2
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {p1}, Li8/a;->invoke()Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-object p0

    :goto_3
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {p1}, Li8/a;->invoke()Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    throw p0

    :cond_6
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string p1, "aaotsbwtptlcCmvnodnyxb enriornr oeemo)cfhuti( eeo adl k e "

    const-string p1, "C rmdoxblt chpctlou m nevntieaoen e roftoa)w kosaenyr(die "

    const-string/jumbo p1, "vl eonuarfbo  eintcoocoeweC eyl( ndc xetndt tkhipuro aarsm"

    const-string p1, "awaitClose() can only be invoked from the producer context"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    throw p0
.end method

.method public static synthetic b(Lkotlinx/coroutines/channels/g0;Li8/a;Lkotlin/coroutines/d;ILjava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    and-int/lit8 p3, p3, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-eqz p3, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    sget-object p1, Lkotlinx/coroutines/channels/e0$b;->a:Lkotlinx/coroutines/channels/e0$b;

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/e0;->a(Lkotlinx/coroutines/channels/g0;Li8/a;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p0
.end method

.method public static final c(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILi8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 9
    .param p0    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Li8/p;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlin/coroutines/g;",
            "I",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/channels/g0<",
            "-TE;>;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlinx/coroutines/c2;
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    sget-object v3, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    sget-object v4, Lkotlinx/coroutines/w0;->a:Lkotlinx/coroutines/w0;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    move v2, p2

    move v2, p2

    const/4 v8, 0x3

    move v2, p2

    move v2, p2

    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static/range {v0 .. v6}, Lkotlinx/coroutines/channels/e0;->e(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;Lkotlinx/coroutines/w0;Li8/l;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    return-object p0
.end method

.method public static final d(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/w0;Li8/l;Li8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 9
    .param p0    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/w0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Li8/l;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p5    # Li8/p;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/w0;",
            "Li8/l<",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/channels/g0<",
            "-TE;>;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlinx/coroutines/i2;
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    sget-object v3, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    move v2, p2

    move v2, p2

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static/range {v0 .. v6}, Lkotlinx/coroutines/channels/e0;->e(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;Lkotlinx/coroutines/w0;Li8/l;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    return-object p0
.end method

.method public static final e(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;Lkotlinx/coroutines/w0;Li8/l;Li8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 4
    .param p0    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Lkotlinx/coroutines/w0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p5    # Li8/l;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p6    # Li8/p;
        .annotation build Lia/d;
        .end annotation

        .annotation build Lkotlin/b;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/channels/m;",
            "Lkotlinx/coroutines/w0;",
            "Li8/l<",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/channels/g0<",
            "-TE;>;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x4

    const/4 v3, 0x5

    move v2, v1

    move v2, v1

    const/4 v3, 0x5

    invoke-static {p2, p3, v0, v1, v0}, Lkotlinx/coroutines/channels/q;->d(ILkotlinx/coroutines/channels/m;Li8/l;ILjava/lang/Object;)Lkotlinx/coroutines/channels/n;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p0, p1}, Lkotlinx/coroutines/n0;->e(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;)Lkotlin/coroutines/g;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p1, Lkotlinx/coroutines/channels/f0;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {p1, p0, p2}, Lkotlinx/coroutines/channels/f0;-><init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/channels/n;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz p5, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, p5}, Lkotlinx/coroutines/v2;->invokeOnCompletion(Li8/l;)Lkotlinx/coroutines/p1;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1, p4, p1, p6}, Lkotlinx/coroutines/a;->i1(Lkotlinx/coroutines/w0;Ljava/lang/Object;Li8/p;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object p1
.end method

.method public static synthetic f(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILi8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    and-int/lit8 p5, p4, 0x1

    const/4 v0, 0x2

    move v1, v0

    if-eqz p5, :cond_0

    const/4 v1, 0x2

    sget-object p1, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    and-int/lit8 p4, p4, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    if-eqz p4, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 p2, 0x0

    :cond_1
    const/4 v1, 0x0

    invoke-static {p0, p1, p2, p3}, Lkotlinx/coroutines/channels/e0;->c(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILi8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method public static synthetic g(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/w0;Li8/l;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 7

    const/4 v6, 0x7

    and-int/lit8 p7, p6, 0x1

    const/4 v6, 0x7

    if-eqz p7, :cond_0

    sget-object p1, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    :cond_0
    move-object v1, p1

    move-object v1, p1

    const/4 v6, 0x0

    and-int/lit8 p1, p6, 0x2

    const/4 v6, 0x1

    if-eqz p1, :cond_1

    const/4 v6, 0x1

    const/4 p2, 0x0

    :cond_1
    const/4 v6, 0x0

    move v2, p2

    move v2, p2

    move v2, p2

    const/4 v6, 0x0

    and-int/lit8 p1, p6, 0x4

    const/4 v6, 0x7

    if-eqz p1, :cond_2

    const/4 v6, 0x3

    sget-object p3, Lkotlinx/coroutines/w0;->a:Lkotlinx/coroutines/w0;

    :cond_2
    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    const/4 v6, 0x3

    and-int/lit8 p1, p6, 0x8

    const/4 v6, 0x5

    if-eqz p1, :cond_3

    const/4 v6, 0x7

    const/4 p4, 0x0

    :cond_3
    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    const/4 v6, 0x3

    invoke-static/range {v0 .. v5}, Lkotlinx/coroutines/channels/e0;->d(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/w0;Li8/l;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v6, 0x2

    return-object p0
.end method

.method public static synthetic h(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;Lkotlinx/coroutines/w0;Li8/l;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 7

    and-int/lit8 p8, p7, 0x1

    if-eqz p8, :cond_0

    sget-object p1, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    :cond_0
    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    and-int/lit8 p1, p7, 0x2

    if-eqz p1, :cond_1

    const/4 p2, 0x0

    :cond_1
    move v2, p2

    move v2, p2

    move v2, p2

    move v2, p2

    and-int/lit8 p1, p7, 0x4

    if-eqz p1, :cond_2

    sget-object p3, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    :cond_2
    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    and-int/lit8 p1, p7, 0x8

    if-eqz p1, :cond_3

    sget-object p4, Lkotlinx/coroutines/w0;->a:Lkotlinx/coroutines/w0;

    :cond_3
    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    and-int/lit8 p1, p7, 0x10

    if-eqz p1, :cond_4

    const/4 p5, 0x0

    :cond_4
    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v0, p0

    move-object v0, p0

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    invoke-static/range {v0 .. v6}, Lkotlinx/coroutines/channels/e0;->e(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/channels/m;Lkotlinx/coroutines/w0;Li8/l;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    return-object p0
.end method
