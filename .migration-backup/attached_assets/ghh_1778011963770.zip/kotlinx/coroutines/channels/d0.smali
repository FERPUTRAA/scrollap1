.class public Lkotlinx/coroutines/channels/d0;
.super Lkotlinx/coroutines/channels/a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/a<",
        "TE;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLinkedListChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LinkedListChannel.kt\nkotlinx/coroutines/channels/LinkedListChannel\n+ 2 InlineList.kt\nkotlinx/coroutines/internal/InlineList\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,77:1\n37#2,11:78\n1#3:89\n*S KotlinDebug\n*F\n+ 1 LinkedListChannel.kt\nkotlinx/coroutines/channels/LinkedListChannel\n*L\n64#1:78,11\n*E\n"
.end annotation


# direct methods
.method public constructor <init>(Li8/l;)V
    .locals 2
    .param p1    # Li8/l;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/a;-><init>(Li8/l;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected final H()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@/s~t~ dS ~@~o1 i~  @@n~~  /at@  @f@obs y@r mb~~ilb~4@~~Mc@~-@v@o o@@~.~~@  @@~ o~@u  ~@l@~~Kofi"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method protected final I()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method protected K(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-super {p0, p1}, Lkotlinx/coroutines/channels/c;->K(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget-object v1, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-ne v0, v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object v1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    sget-object v2, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-ne v0, v2, :cond_3

    const/4 v4, 0x1

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/c;->O(Ljava/lang/Object;)Lkotlinx/coroutines/channels/j0;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object v1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    instance-of v1, v0, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object v0

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    instance-of p1, v0, Lkotlinx/coroutines/channels/w;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz p1, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object v0

    :cond_4
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v2, "fvlmIonatne et Ifrnass rudlle"

    const-string v2, "nasnoidate II nltefelsfrlvr u"

    const/4 v4, 0x0

    const-string v2, "liInofurt te afIlonrrdensale "

    const-string v2, "Invalid offerInternal result "

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method protected L(Ljava/lang/Object;Lkotlinx/coroutines/selects/f;)Ljava/lang/Object;
    .locals 4
    .param p2    # Lkotlinx/coroutines/selects/f;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/selects/f<",
            "*>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/a;->b0()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-super {p0, p1, p2}, Lkotlinx/coroutines/channels/c;->L(Ljava/lang/Object;Lkotlinx/coroutines/selects/f;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/c;->f(Ljava/lang/Object;)Lkotlinx/coroutines/internal/y$b;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {p2, v0}, Lkotlinx/coroutines/selects/f;->V(Lkotlinx/coroutines/internal/b;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object v0, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;

    :cond_2
    :goto_0
    const/4 v2, 0x3

    move v3, v2

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ne v0, v1, :cond_3

    const/4 v3, 0x2

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p1

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v1, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v3, 0x2

    if-ne v0, v1, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v1

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget-object v1, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eq v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget-object v1, Lkotlinx/coroutines/internal/c;->b:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x3

    if-eq v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    instance-of p1, v0, Lkotlinx/coroutines/channels/w;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p1, :cond_5

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0

    :cond_5
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v1, "Ilinsb  talevum"

    const-string v1, "i Im snrleavlut"

    const/4 v3, 0x1

    const-string v1, "Invalid result "

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    throw p1
.end method

.method protected final c0()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method protected final d0()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method protected g0(Ljava/lang/Object;Lkotlinx/coroutines/channels/w;)V
    .locals 7
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/channels/w;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlinx/coroutines/channels/w<",
            "*>;)V"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz p1, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    instance-of v1, p1, Ljava/util/ArrayList;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-nez v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    check-cast p1, Lkotlinx/coroutines/channels/l0;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    instance-of v1, p1, Lkotlinx/coroutines/channels/c$a;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eqz v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object p2, p0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz p2, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    check-cast p1, Lkotlinx/coroutines/channels/c$a;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object p1, p1, Lkotlinx/coroutines/channels/c$a;->d:Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {p2, p1, v0}, Lkotlinx/coroutines/internal/i0;->c(Li8/l;Ljava/lang/Object;Lkotlinx/coroutines/internal/d1;)Lkotlinx/coroutines/internal/d1;

    move-result-object p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_2

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/l0;->F0(Lkotlinx/coroutines/channels/w;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_2

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    check-cast p1, Ljava/util/ArrayList;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    add-int/lit8 v1, v1, -0x1

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v3, -0x1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-ge v3, v1, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    check-cast v3, Lkotlinx/coroutines/channels/l0;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    instance-of v4, v3, Lkotlinx/coroutines/channels/c$a;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v4, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v4, p0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v4, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x2

    check-cast v3, Lkotlinx/coroutines/channels/c$a;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v3, v3, Lkotlinx/coroutines/channels/c$a;->d:Ljava/lang/Object;

    const/4 v6, 0x6

    invoke-static {v4, v3, v2}, Lkotlinx/coroutines/internal/i0;->c(Li8/l;Ljava/lang/Object;Lkotlinx/coroutines/internal/d1;)Lkotlinx/coroutines/internal/d1;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_1

    :cond_2
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_1

    :cond_3
    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v3, p2}, Lkotlinx/coroutines/channels/l0;->F0(Lkotlinx/coroutines/channels/w;)V

    :goto_1
    const/4 v5, 0x7

    const/4 v6, 0x5

    add-int/lit8 v1, v1, -0x1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_0

    :cond_4
    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_5
    :goto_2
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-nez v0, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-void

    :cond_6
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    throw v0
.end method
