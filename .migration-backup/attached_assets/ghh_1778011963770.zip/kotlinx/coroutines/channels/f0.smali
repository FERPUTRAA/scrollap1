.class final Lkotlinx/coroutines/channels/f0;
.super Lkotlinx/coroutines/channels/o;

# interfaces
.implements Lkotlinx/coroutines/channels/g0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/o<",
        "TE;>;",
        "Lkotlinx/coroutines/channels/g0<",
        "TE;>;"
    }
.end annotation


# direct methods
.method public constructor <init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/channels/n;)V
    .locals 3
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/channels/n;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "Lkotlinx/coroutines/channels/n<",
            "TE;>;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, v0, v0}, Lkotlinx/coroutines/channels/o;-><init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/channels/n;ZZ)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method protected g1(Ljava/lang/Throwable;Z)V
    .locals 3
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "o~sSo@@r ~inb~@f~b M@m~~~t  obf~~~ @@ @.t~~@y4 i@ic o@ va@ d@~@o~1K~ / @s@@@l~~~@@ ~~@- /   o~lu"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/o;->j1()Lkotlinx/coroutines/channels/n;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lkotlinx/coroutines/channels/m0;->C(Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez p2, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/a;->getContext()Lkotlin/coroutines/g;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p2, p1}, Lkotlinx/coroutines/r0;->b(Lkotlin/coroutines/g;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public bridge synthetic getChannel()Lkotlinx/coroutines/channels/m0;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/o;->getChannel()Lkotlinx/coroutines/channels/n;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    return-object v0
.end method

.method public bridge synthetic h1(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    check-cast p1, Lkotlin/s2;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/f0;->k1(Lkotlin/s2;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public isActive()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-super {p0}, Lkotlinx/coroutines/a;->isActive()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method protected k1(Lkotlin/s2;)V
    .locals 4
    .param p1    # Lkotlin/s2;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/o;->j1()Lkotlinx/coroutines/channels/n;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x1

    and-int/2addr v3, v1

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1, v0, v1, v0}, Lkotlinx/coroutines/channels/m0$a;->a(Lkotlinx/coroutines/channels/m0;Ljava/lang/Throwable;ILjava/lang/Object;)Z

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method
