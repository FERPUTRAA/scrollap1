.class public final Lkotlinx/coroutines/channels/o0;
.super Lkotlinx/coroutines/channels/n0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/n0<",
        "TE;>;"
    }
.end annotation


# instance fields
.field public final f:Li8/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/l<",
            "TE;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Object;Lkotlinx/coroutines/q;Li8/l;)V
    .locals 2
    .param p2    # Lkotlinx/coroutines/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/q<",
            "-",
            "Lkotlin/s2;",
            ">;",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Lkotlinx/coroutines/channels/n0;-><init>(Ljava/lang/Object;Lkotlinx/coroutines/q;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p3, p0, Lkotlinx/coroutines/channels/o0;->f:Li8/l;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public H0()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "b@s~@o~ u o ~@ @ vi @o@f~i r~ot~@@Mf-nl//@@1~@ o~ d~@~sb4@ c i~~~~   ~o@y~.~Sl@ @ma@@ ~~tK~ @b~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/o0;->f:Li8/l;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/n0;->E0()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v2, p0, Lkotlinx/coroutines/channels/n0;->e:Lkotlinx/coroutines/q;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v2}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0, v1, v2}, Lkotlinx/coroutines/internal/i0;->b(Li8/l;Ljava/lang/Object;Lkotlin/coroutines/g;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method public w0()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-super {p0}, Lkotlinx/coroutines/internal/y;->w0()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/o0;->H0()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    return v0
.end method
