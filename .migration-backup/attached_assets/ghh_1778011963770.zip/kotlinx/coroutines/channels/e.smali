.class public final Lkotlinx/coroutines/channels/e;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/w0;Li8/l;Li8/p;)Lkotlinx/coroutines/channels/m0;
    .locals 3
    .param p0    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlinx/coroutines/w0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Li8/l;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p5    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlin/coroutines/g;",
            "I",
            "Lkotlinx/coroutines/w0;",
            "Li8/l<",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/channels/f<",
            "TE;>;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/channels/m0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlinx/coroutines/e3;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p0, p1}, Lkotlinx/coroutines/n0;->e(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;)Lkotlin/coroutines/g;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x6

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p2, p1, p1, v0, p1}, Lkotlinx/coroutines/channels/q;->d(ILkotlinx/coroutines/channels/m;Li8/l;ILjava/lang/Object;)Lkotlinx/coroutines/channels/n;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p3}, Lkotlinx/coroutines/w0;->d()Z

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz p2, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance p2, Lkotlinx/coroutines/channels/b0;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p2, p0, p1, p5}, Lkotlinx/coroutines/channels/b0;-><init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/channels/n;Li8/p;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p2, Lkotlinx/coroutines/channels/d;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p2, p0, p1, v0}, Lkotlinx/coroutines/channels/d;-><init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/channels/n;Z)V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz p4, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p2, p4}, Lkotlinx/coroutines/v2;->invokeOnCompletion(Li8/l;)Lkotlinx/coroutines/p1;

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p2, p3, p2, p5}, Lkotlinx/coroutines/a;->i1(Lkotlinx/coroutines/w0;Ljava/lang/Object;Li8/p;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p2
.end method

.method public static synthetic b(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/w0;Li8/l;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/m0;
    .locals 7

    const/4 v6, 0x2

    and-int/lit8 p7, p6, 0x1

    const/4 v6, 0x0

    if-eqz p7, :cond_0

    sget-object p1, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    :cond_0
    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v6, 0x1

    and-int/lit8 p1, p6, 0x2

    const/4 v6, 0x5

    if-eqz p1, :cond_1

    const/4 v6, 0x5

    const/4 p2, 0x0

    :cond_1
    const/4 v6, 0x1

    move v2, p2

    move v2, p2

    move v2, p2

    move v2, p2

    const/4 v6, 0x0

    and-int/lit8 p1, p6, 0x4

    if-eqz p1, :cond_2

    const/4 v6, 0x4

    sget-object p3, Lkotlinx/coroutines/w0;->a:Lkotlinx/coroutines/w0;

    :cond_2
    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    const/4 v6, 0x2

    and-int/lit8 p1, p6, 0x8

    const/4 v6, 0x4

    if-eqz p1, :cond_3

    const/4 p4, 0x5

    const/4 p4, 0x0

    :cond_3
    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    const/4 v6, 0x1

    invoke-static/range {v0 .. v5}, Lkotlinx/coroutines/channels/e;->a(Lkotlinx/coroutines/u0;Lkotlin/coroutines/g;ILkotlinx/coroutines/w0;Li8/l;Li8/p;)Lkotlinx/coroutines/channels/m0;

    move-result-object p0

    const/4 v6, 0x1

    return-object p0
.end method
