.class public Lkotlinx/coroutines/channels/k0;
.super Lkotlinx/coroutines/channels/a;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/a<",
        "TE;>;"
    }
.end annotation


# direct methods
.method public constructor <init>(Li8/l;)V
    .locals 2
    .param p1    # Li8/l;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/a;-><init>(Li8/l;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method protected final H()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "m~s@4~~@~@o.o  @@~~ @~~llou@t~ v-~@ @ @aM@@i /~f~~ c~o~oK@/rb@ osi~@@ f ~~1@@ n b@i~St   @d~ ~~b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method protected final I()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method protected final c0()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method protected final d0()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method
