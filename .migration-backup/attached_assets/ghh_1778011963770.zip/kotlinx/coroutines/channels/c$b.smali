.class Lkotlinx/coroutines/channels/c$b;
.super Lkotlinx/coroutines/internal/y$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/internal/y$b<",
        "Lkotlinx/coroutines/channels/c$a<",
        "+TE;>;>;"
    }
.end annotation


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/internal/w;Ljava/lang/Object;)V
    .locals 3
    .param p1    # Lkotlinx/coroutines/internal/w;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/internal/w;",
            "TE;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance v0, Lkotlinx/coroutines/channels/c$a;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {v0, p2}, Lkotlinx/coroutines/channels/c$a;-><init>(Ljava/lang/Object;)V

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, p1, v0}, Lkotlinx/coroutines/internal/y$b;-><init>(Lkotlinx/coroutines/internal/y;Lkotlinx/coroutines/internal/y;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method protected e(Lkotlinx/coroutines/internal/y;)Ljava/lang/Object;
    .locals 3
    .param p1    # Lkotlinx/coroutines/internal/y;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "4~s~@u~t~/@ o~y~@M~o @co@@K@~v@i @   @-  @~n~o@@tb S ~~~sol~@@fd.a@ fm~~o@ r~1 i@ ~@ b~bl~i ~/ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    instance-of v0, p1, Lkotlinx/coroutines/channels/w;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    instance-of p1, p1, Lkotlinx/coroutines/channels/j0;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    sget-object p1, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p1
.end method
