.class final Lkotlinx/coroutines/channels/v$h;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/v;->j(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "Ljava/lang/Object;",
        ">;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.ChannelsKt__DeprecatedKt$dropWhile$1"
    f = "Deprecated.kt"
    i = {
        0x0,
        0x1,
        0x1,
        0x2,
        0x3,
        0x4
    }
    l = {
        0xb5,
        0xb6,
        0xb7,
        0xbb,
        0xbc
    }
    m = "invokeSuspend"
    n = {
        "$this$produce",
        "$this$produce",
        "e",
        "$this$produce",
        "$this$produce",
        "$this$produce"
    }
    s = {
        "L$0",
        "L$0",
        "L$2",
        "L$0",
        "L$0",
        "L$0"
    }
.end annotation


# instance fields
.field final synthetic $predicate:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $this_dropWhile:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/i0;Li8/p;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;",
            "Li8/p<",
            "Ljava/lang/Object;",
            "-",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/v$h;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/channels/v$h;->$this_dropWhile:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/channels/v$h;->$predicate:Li8/p;

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 v1, 0x2

    const/4 p1, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v0, Lkotlinx/coroutines/channels/v$h;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$h;->$this_dropWhile:Lkotlinx/coroutines/channels/i0;

    const/4 v3, 0x3

    move v4, v3

    iget-object v2, p0, Lkotlinx/coroutines/channels/v$h;->$predicate:Li8/p;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/channels/v$h;-><init>(Lkotlinx/coroutines/channels/i0;Li8/p;Lkotlin/coroutines/d;)V

    const/4 v4, 0x0

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v3, 0x4

    move v4, v3

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$h;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v13, 0x0

    const/4 v12, 0x4

    iget v1, p0, Lkotlinx/coroutines/channels/v$h;->label:I

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x1

    const/4 v2, 0x5

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x1

    const/4 v3, 0x4

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x7

    const/4 v4, 0x3

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x2

    const/4 v5, 0x2

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x3

    const/4 v6, 0x1

    const/4 v12, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x2

    const/4 v7, 0x0

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x6

    if-eqz v1, :cond_5

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x5

    if-eq v1, v6, :cond_4

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x1

    if-eq v1, v5, :cond_3

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x0

    if-eq v1, v4, :cond_2

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x6

    if-eq v1, v3, :cond_1

    if-ne v1, v2, :cond_0

    const/4 v13, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$h;->L$1:Ljava/lang/Object;

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x5

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x5

    iget-object v4, p0, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x1

    check-cast v4, Lkotlinx/coroutines/channels/g0;

    const/4 v13, 0x3

    const/4 v12, 0x1

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object v9, v4

    move-object v9, v4

    move-object v9, v4

    move-object v9, v4

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x7

    goto/16 :goto_5

    :cond_0
    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x3

    const-string v0, "  s/kt termu/ eefucsa/iner/ i/ /otoer/oiwl/lovbnces"

    const-string v0, "oos t ircoots/ ua/ /o/bi/kei  efnwmeernl/turvee/l/c"

    const/4 v13, 0x5

    const-string v0, "otemcrslt/v //iea n e nmcr/ef/ooo u/biwo/tkelhi /ue"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v13, 0x2

    const/4 v12, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x0

    throw p1

    :cond_1
    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$h;->L$1:Ljava/lang/Object;

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x6

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x6

    iget-object v4, p0, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x4

    check-cast v4, Lkotlinx/coroutines/channels/g0;

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v9, v4

    move-object v9, v4

    move-object v9, v4

    move-object v9, v4

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x0

    goto/16 :goto_6

    :cond_2
    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x2

    check-cast v1, Lkotlinx/coroutines/channels/g0;

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v10, v1

    move-object v10, v1

    move-object v10, v1

    move-object v10, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x2

    goto/16 :goto_3

    :cond_3
    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$h;->L$2:Ljava/lang/Object;

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x0

    iget-object v8, p0, Lkotlinx/coroutines/channels/v$h;->L$1:Ljava/lang/Object;

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x4

    check-cast v8, Lkotlinx/coroutines/channels/p;

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x1

    iget-object v9, p0, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x2

    check-cast v9, Lkotlinx/coroutines/channels/g0;

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v10, v9

    move-object v10, v9

    move-object v10, v9

    move-object v10, v9

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x1

    goto/16 :goto_2

    :cond_4
    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$h;->L$1:Ljava/lang/Object;

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x1

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v13, 0x3

    iget-object v8, p0, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x7

    check-cast v8, Lkotlinx/coroutines/channels/g0;

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x7

    goto :goto_1

    :cond_5
    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v13, 0x6

    const/4 v12, 0x4

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v13, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$h;->$this_dropWhile:Lkotlinx/coroutines/channels/i0;

    const/4 v13, 0x2

    invoke-interface {v1}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    :goto_0
    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x5

    iput-object v8, p1, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x3

    iput-object v1, p1, Lkotlinx/coroutines/channels/v$h;->L$1:Ljava/lang/Object;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x1

    iput-object v7, p1, Lkotlinx/coroutines/channels/v$h;->L$2:Ljava/lang/Object;

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x1

    iput v6, p1, Lkotlinx/coroutines/channels/v$h;->label:I

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x4

    invoke-interface {v1, p1}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v9

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x0

    if-ne v9, v0, :cond_6

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x5

    return-object v0

    :cond_6
    move-object v11, v0

    move-object v11, v0

    move-object v11, v0

    move-object v11, v0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object p1, v9

    move-object p1, v9

    move-object p1, v9

    move-object p1, v9

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v1, v11

    move-object v1, v11

    move-object v1, v11

    :goto_1
    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x1

    check-cast p1, Ljava/lang/Boolean;

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x2

    if-eqz p1, :cond_a

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-interface {v8}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x3

    iget-object v10, v0, Lkotlinx/coroutines/channels/v$h;->$predicate:Li8/p;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x4

    iput-object v9, v0, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v13, 0x5

    iput-object v8, v0, Lkotlinx/coroutines/channels/v$h;->L$1:Ljava/lang/Object;

    const/4 v12, 0x2

    xor-int/2addr v13, v12

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$h;->L$2:Ljava/lang/Object;

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x4

    iput v5, v0, Lkotlinx/coroutines/channels/v$h;->label:I

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-interface {v10, p1, v0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x2

    if-ne v10, v1, :cond_7

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x3

    return-object v1

    :cond_7
    move-object v11, v9

    move-object v11, v9

    move-object v11, v9

    move-object v11, v9

    move-object v9, p1

    move-object v9, p1

    move-object v9, p1

    move-object v9, p1

    move-object p1, v10

    move-object p1, v10

    move-object p1, v10

    move-object p1, v10

    move-object v10, v11

    move-object v10, v11

    move-object v10, v11

    move-object v10, v11

    :goto_2
    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x2

    check-cast p1, Ljava/lang/Boolean;

    const/4 v13, 0x7

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x2

    if-nez p1, :cond_9

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x5

    iput-object v10, v0, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x5

    iput-object v7, v0, Lkotlinx/coroutines/channels/v$h;->L$1:Ljava/lang/Object;

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x1

    iput-object v7, v0, Lkotlinx/coroutines/channels/v$h;->L$2:Ljava/lang/Object;

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x5

    iput v4, v0, Lkotlinx/coroutines/channels/v$h;->label:I

    const/4 v13, 0x4

    const/4 v12, 0x7

    invoke-interface {v10, v9, v0}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x3

    if-ne p1, v1, :cond_8

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x4

    return-object v1

    :cond_8
    :goto_3
    move-object v9, v10

    move-object v9, v10

    move-object v9, v10

    move-object v9, v10

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x0

    goto :goto_4

    :cond_9
    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x1

    goto/16 :goto_0

    :cond_a
    :goto_4
    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x3

    iget-object p1, v0, Lkotlinx/coroutines/channels/v$h;->$this_dropWhile:Lkotlinx/coroutines/channels/i0;

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-interface {p1}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object p1

    :goto_5
    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x6

    iput-object v9, v0, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x6

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$h;->L$1:Ljava/lang/Object;

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x3

    iput v3, v0, Lkotlinx/coroutines/channels/v$h;->label:I

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-interface {p1, v0}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v4

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x3

    if-ne v4, v1, :cond_b

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x3

    return-object v1

    :cond_b
    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v11, v4

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object p1, v11

    move-object p1, v11

    move-object p1, v11

    :goto_6
    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x4

    check-cast p1, Ljava/lang/Boolean;

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x3

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x2

    if-eqz p1, :cond_d

    const/4 v12, 0x2

    move v13, v12

    invoke-interface {v4}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x1

    iput-object v9, v0, Lkotlinx/coroutines/channels/v$h;->L$0:Ljava/lang/Object;

    const/4 v13, 0x6

    iput-object v4, v0, Lkotlinx/coroutines/channels/v$h;->L$1:Ljava/lang/Object;

    const/4 v13, 0x3

    const/4 v12, 0x7

    iput v2, v0, Lkotlinx/coroutines/channels/v$h;->label:I

    const/4 v13, 0x1

    const/4 v12, 0x3

    invoke-interface {v9, p1, v0}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x1

    if-ne p1, v1, :cond_c

    const/4 v12, 0x6

    move v13, v12

    return-object v1

    :cond_c
    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x1

    goto :goto_5

    :cond_d
    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x3

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$h;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    check-cast p1, Lkotlinx/coroutines/channels/v$h;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v0, 0x5

    and-int/2addr v1, v0

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/v$h;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p1
.end method
