.class public final Lkotlinx/coroutines/channels/s;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "Channel was closed"
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public static final synthetic A(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/channels/m0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "y~scr@@oimb@ @it ~b@o~ ~~ dfi/ o@o~@~~s ~b~@ a t~~~ l~ /~~    ~S@oo~K~.~u@1@@n@ l@@~@f4@@M@-  @~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->v(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/channels/m0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p0
.end method

.method public static final synthetic B(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->w(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method public static final synthetic C(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->x(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public static final synthetic D(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->y(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public static synthetic E(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->z(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final synthetic F(Lkotlinx/coroutines/channels/i0;Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->A(Lkotlinx/coroutines/channels/i0;Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method public static final synthetic G(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->B(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method public static final synthetic H(Lkotlinx/coroutines/channels/i0;Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->C(Lkotlinx/coroutines/channels/i0;Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method public static final synthetic I(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->D(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public static final J(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlin/coroutines/g;",
            "Li8/p<",
            "-TE;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/channels/i0<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->E(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x3

    return-object p0
.end method

.method public static synthetic K(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->F(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final L(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlin/coroutines/g;",
            "Li8/q<",
            "-",
            "Ljava/lang/Integer;",
            "-TE;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/channels/i0<",
            "TR;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->G(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method public static synthetic M(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->H(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final synthetic N(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->I(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method

.method public static synthetic O(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x5

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->J(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method

.method public static final synthetic P(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->K(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method public static synthetic Q(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->L(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final synthetic R(Lkotlinx/coroutines/channels/i0;Ljava/util/Comparator;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->M(Lkotlinx/coroutines/channels/i0;Ljava/util/Comparator;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method public static final synthetic S(Lkotlinx/coroutines/channels/i0;Ljava/util/Comparator;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->N(Lkotlinx/coroutines/channels/i0;Ljava/util/Comparator;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0
.end method

.method public static final synthetic T(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->O(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method public static final U(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/selects/d;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;)",
            "Lkotlinx/coroutines/selects/d<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'onReceiveCatching\'"
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p0}, Lkotlinx/coroutines/channels/u;->h(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/selects/d;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    return-object p0
.end method

.method public static final V(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlin/coroutines/d<",
            "-TE;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'receiveCatching\'"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "receiveCatching().getOrNull()"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/u;->i(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method

.method public static final synthetic W(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Left for binary compatibility"
    .end annotation

    const/4 v1, 0x2

    invoke-static {p0}, Lkotlinx/coroutines/channels/v;->P(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    return-object p0
.end method

.method public static final X(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;)V
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/m0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/m0<",
            "-TE;>;TE;)V"
        }
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'trySendBlocking\'. Consider handling the result of \'trySendBlocking\' explicitly and rethrow exception if necessary"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "trySendBlocking(element)"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/t;->a(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;)V

    const/4 v1, 0x1

    return-void
.end method

.method public static final synthetic Y(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->Q(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method public static final synthetic Z(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->R(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method public static final synthetic a(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->a(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p0
.end method

.method public static final synthetic a0(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/g;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->S(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/g;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method public static final b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "*>;",
            "Ljava/lang/Throwable;",
            ")V"
        }
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/u;->a(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    return-void
.end method

.method public static synthetic b0(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/g;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v0, 0x4

    move v1, v0

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->T(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/g;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p0
.end method

.method public static final c(Lkotlinx/coroutines/channels/i;Li8/l;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i<",
            "TE;>;",
            "Li8/l<",
            "-",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;+TR;>;)TR;"
        }
    .end annotation

    .annotation build Lkotlinx/coroutines/e3;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/u;->b(Lkotlinx/coroutines/channels/i;Li8/l;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method public static final synthetic c0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->U(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method public static final d(Lkotlinx/coroutines/channels/i0;Li8/l;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Li8/l<",
            "-",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;+TR;>;)TR;"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/u;->c(Lkotlinx/coroutines/channels/i0;Li8/l;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method public static synthetic d0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->V(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final e(Lkotlinx/coroutines/channels/i;Li8/l;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i<",
            "TE;>;",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation build Lkotlinx/coroutines/e3;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/u;->d(Lkotlinx/coroutines/channels/i;Li8/l;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method public static final e0(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/channels/m0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/channels/m0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            "C::",
            "Lkotlinx/coroutines/channels/m0<",
            "-TE;>;>(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;TC;",
            "Lkotlin/coroutines/d<",
            "-TC;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->W(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/channels/m0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method public static final f(Lkotlinx/coroutines/channels/i0;Li8/l;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/u;->e(Lkotlinx/coroutines/channels/i0;Li8/l;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final f0(Lkotlinx/coroutines/channels/i0;Ljava/util/Collection;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Ljava/util/Collection;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            "C::",
            "Ljava/util/Collection<",
            "-TE;>;>(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;TC;",
            "Lkotlin/coroutines/d<",
            "-TC;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->X(Lkotlinx/coroutines/channels/i0;Ljava/util/Collection;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final g(Lkotlinx/coroutines/channels/i0;)Li8/l;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "*>;)",
            "Li8/l<",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p0}, Lkotlinx/coroutines/channels/v;->b(Lkotlinx/coroutines/channels/i0;)Li8/l;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p0
.end method

.method public static final g0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/util/List<",
            "+TE;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/u;->j(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method public static final varargs h([Lkotlinx/coroutines/channels/i0;)Li8/l;
    .locals 2
    .param p0    # [Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lkotlinx/coroutines/channels/i0<",
            "*>;)",
            "Li8/l<",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static {p0}, Lkotlinx/coroutines/channels/v;->c([Lkotlinx/coroutines/channels/i0;)Li8/l;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final h0(Lkotlinx/coroutines/channels/i0;Ljava/util/Map;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Ljava/util/Map;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            "M::",
            "Ljava/util/Map<",
            "-TK;-TV;>;>(",
            "Lkotlinx/coroutines/channels/i0<",
            "+",
            "Lkotlin/u0<",
            "+TK;+TV;>;>;TM;",
            "Lkotlin/coroutines/d<",
            "-TM;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->Y(Lkotlinx/coroutines/channels/i0;Ljava/util/Map;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method public static final synthetic i(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->d(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method public static final synthetic i0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->Z(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final synthetic j(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p0}, Lkotlinx/coroutines/channels/v;->e(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method public static final synthetic j0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->a0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method public static final k(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            "K:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlin/coroutines/g;",
            "Li8/p<",
            "-TE;-",
            "Lkotlin/coroutines/d<",
            "-TK;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->f(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method public static final k0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/util/Set<",
            "TE;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->b0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method public static synthetic l(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->g(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final synthetic l0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->c0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x0

    return-object p0
.end method

.method public static final synthetic m(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/g;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->h(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/g;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method public static final m0(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/m0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/m0<",
            "-TE;>;TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/t;->b(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x7

    return-object p0
.end method

.method public static synthetic n(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/g;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->i(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/g;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method public static final synthetic n0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->d0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method public static final synthetic o(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->j(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public static synthetic o0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0, p1, p2, p3}, Lkotlinx/coroutines/channels/v;->e0(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method public static synthetic p(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->k(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method public static final synthetic p0(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/v;->f0(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method public static final synthetic q(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v0, 0x0

    const/4 v0, 0x6

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->l(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method public static final q0(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlinx/coroutines/channels/i0<",
            "+TR;>;",
            "Lkotlin/coroutines/g;",
            "Li8/p<",
            "-TE;-TR;+TV;>;)",
            "Lkotlinx/coroutines/channels/i0<",
            "TV;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p0, p1, p2, p3}, Lkotlinx/coroutines/channels/v;->g0(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x2

    return-object p0
.end method

.method public static final synthetic r(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->m(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method public static synthetic r0(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static/range {p0 .. p5}, Lkotlinx/coroutines/channels/v;->h0(Lkotlinx/coroutines/channels/i0;Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method public static final s(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlin/coroutines/g;",
            "Li8/p<",
            "-TE;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)",
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->n(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method public static synthetic t(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->o(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    return-object p0
.end method

.method public static final synthetic u(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->p(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method public static synthetic v(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->q(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/q;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public static final synthetic w(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->r(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method public static synthetic x(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p0, p1, p2, p3, p4}, Lkotlinx/coroutines/channels/v;->s(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;ILjava/lang/Object;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p0
.end method

.method public static final y(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/channels/i0;
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;)",
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlin/a1;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0}, Lkotlinx/coroutines/channels/v;->t(Lkotlinx/coroutines/channels/i0;)Lkotlinx/coroutines/channels/i0;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method public static final synthetic z(Lkotlinx/coroutines/channels/i0;Ljava/util/Collection;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Binary compatibility"
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, p1, p2}, Lkotlinx/coroutines/channels/v;->u(Lkotlinx/coroutines/channels/i0;Ljava/util/Collection;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    return-object p0
.end method
