.class public final Lkotlinx/coroutines/channels/z$e;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/selects/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/z;->k()Lkotlinx/coroutines/selects/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/selects/e<",
        "TE;",
        "Lkotlinx/coroutines/channels/m0<",
        "-TE;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lkotlinx/coroutines/channels/z;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/z<",
            "TE;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/z;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/z<",
            "TE;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/channels/z$e;->a:Lkotlinx/coroutines/channels/z;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public h(Lkotlinx/coroutines/selects/f;Ljava/lang/Object;Li8/p;)V
    .locals 3
    .param p1    # Lkotlinx/coroutines/selects/f;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/selects/f<",
            "-TR;>;TE;",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/channels/m0<",
            "-TE;>;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@/s~@o@ bK@uv l@   ~~  ~~c@f/~o@ d~~o~rnfbb~i ~@4@.t@m @~@1~o~  @a@ ~~@t~yi l@ sM@~o iS~@~@~o~-@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/channels/z$e;->a:Lkotlinx/coroutines/channels/z;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0, p1, p2, p3}, Lkotlinx/coroutines/channels/z;->b(Lkotlinx/coroutines/channels/z;Lkotlinx/coroutines/selects/f;Ljava/lang/Object;Li8/p;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method
