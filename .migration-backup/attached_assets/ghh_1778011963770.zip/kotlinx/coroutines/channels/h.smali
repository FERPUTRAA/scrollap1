.class public Lkotlinx/coroutines/channels/h;
.super Lkotlinx/coroutines/channels/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/channels/h$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/a<",
        "TE;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nArrayChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ArrayChannel.kt\nkotlinx/coroutines/channels/ArrayChannel\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Concurrent.kt\nkotlinx/coroutines/internal/ConcurrentKt\n*L\n1#1,308:1\n1#2:309\n17#3:310\n17#3:311\n17#3:312\n17#3:313\n17#3:314\n17#3:315\n17#3:316\n17#3:317\n17#3:318\n*S KotlinDebug\n*F\n+ 1 ArrayChannel.kt\nkotlinx/coroutines/channels/ArrayChannel\n*L\n52#1:310\n53#1:311\n58#1:312\n90#1:313\n129#1:314\n181#1:315\n221#1:316\n277#1:317\n286#1:318\n*E\n"
.end annotation


# instance fields
.field private final d:I

.field private final e:Lkotlinx/coroutines/channels/m;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final f:Ljava/util/concurrent/locks/ReentrantLock;
    .annotation build Lia/d;
    .end annotation
.end field

.field private g:[Ljava/lang/Object;
    .annotation build Lia/d;
    .end annotation
.end field

.field private h:I

.field private volatile synthetic size:I
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(ILkotlinx/coroutines/channels/m;Li8/l;)V
    .locals 8
    .param p2    # Lkotlinx/coroutines/channels/m;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Li8/l;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lkotlinx/coroutines/channels/m;",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {p0, p3}, Lkotlinx/coroutines/channels/a;-><init>(Li8/l;)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput p1, p0, Lkotlinx/coroutines/channels/h;->d:I

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/channels/h;->e:Lkotlinx/coroutines/channels/m;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 p2, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 p3, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-lt p1, p3, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    move p3, p2

    move p3, p2

    const/4 v7, 0x7

    move p3, p2

    move p3, p2

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz p3, :cond_1

    const/4 v6, 0x4

    const/4 v7, 0x1

    new-instance p3, Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v6, 0x2

    move v7, v6

    invoke-direct {p3}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x3

    iput-object p3, p0, Lkotlinx/coroutines/channels/h;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/16 p3, 0x8

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {p1, p3}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    sget-object v1, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v4, 0x6

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v5, 0x0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static/range {v0 .. v5}, Lkotlin/collections/l;->V1([Ljava/lang/Object;Ljava/lang/Object;IIILjava/lang/Object;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput p2, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v7, 0x5

    const/4 v6, 0x0

    return-void

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string p3, " usynnr  acatecatA  shatile emCt a1buyrp as,lt"

    const/4 v7, 0x1

    const-string p3, "mbsbh iuaan yly aal1a a tes Attu rC tcpnscet,r"

    const-string p3, "ArrayChannel capacity must be at least 1, but "

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string p1, "idwms eismaefp"

    const-string p1, "fi m eaisdeswp"

    const/4 v7, 0x0

    const-string p1, "i eeopcasfwi d"

    const-string p1, " was specified"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x3

    new-instance p2, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    throw p2
.end method

.method private final p0(ILjava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITE;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "d ~i@b1 ~@~~y~@~t~c/  ~bSf~@@@s~~o~ ~@/u~i@@ @~vm ~ @@t~o4~  ~a o@K@o .@Mr@nb b@l  oio -~@~lf~@@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget v0, p0, Lkotlinx/coroutines/channels/h;->d:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ge p1, v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/h;->q0(I)V

    const/4 v5, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget v1, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/2addr v1, p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    array-length p1, v0

    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    rem-int/2addr v1, p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    aput-object p2, v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget v1, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    array-length v2, v0

    const/4 v4, 0x1

    move v5, v4

    rem-int v2, v1, v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    aput-object v3, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    add-int/2addr p1, v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    array-length v2, v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    rem-int/2addr p1, v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    aput-object p2, v0, p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    array-length p1, v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    rem-int/2addr v1, p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput v1, p0, Lkotlinx/coroutines/channels/h;->h:I

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void
.end method

.method private final q0(I)V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    array-length v1, v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-lt p1, v1, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    array-length v0, v0

    const/4 v8, 0x0

    mul-int/lit8 v0, v0, 0x2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget v1, p0, Lkotlinx/coroutines/channels/h;->d:I

    const/4 v8, 0x6

    const/4 v7, 0x5

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    new-array v1, v0, [Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    move v3, v2

    move v3, v2

    const/4 v8, 0x5

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-ge v3, p1, :cond_0

    const/4 v7, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget-object v4, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget v5, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    add-int/2addr v5, v3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    array-length v6, v4

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    rem-int/2addr v5, v6

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    aget-object v4, v4, v5

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    aput-object v4, v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    goto :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    sget-object v3, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v7, 0x7

    and-int/2addr v8, v7

    invoke-static {v1, v3, p1, v0}, Lkotlin/collections/l;->M1([Ljava/lang/Object;Ljava/lang/Object;II)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    iput-object v1, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    iput v2, p0, Lkotlinx/coroutines/channels/h;->h:I

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    return-void
.end method

.method private final r0(I)Lkotlinx/coroutines/internal/r0;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget v0, p0, Lkotlinx/coroutines/channels/h;->d:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-ge p1, v0, :cond_0

    const/4 v3, 0x6

    move v4, v3

    add-int/2addr p1, v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput p1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v3, 0x2

    move v4, v3

    return-object v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/channels/h;->e:Lkotlinx/coroutines/channels/m;

    const/4 v4, 0x6

    sget-object v0, Lkotlinx/coroutines/channels/h$a;->a:[I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    aget p1, v0, p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eq p1, v2, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v0, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eq p1, v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v0, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ne p1, v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance p1, Lkotlin/j0;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {p1}, Lkotlin/j0;-><init>()V

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    throw p1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    sget-object v1, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    sget-object v1, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object v1
.end method


# virtual methods
.method protected final H()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method protected final I()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget v0, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, p0, Lkotlinx/coroutines/channels/h;->d:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->e:Lkotlinx/coroutines/channels/m;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v1, Lkotlinx/coroutines/channels/m;->a:Lkotlinx/coroutines/channels/m;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v0
.end method

.method protected K(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-object v2

    :cond_0
    :try_start_1
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {p0, v1}, Lkotlinx/coroutines/channels/h;->r0(I)Lkotlinx/coroutines/internal/r0;

    move-result-object v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v2, :cond_1

    const/4 v4, 0x1

    move v5, v4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object v2

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v1, :cond_5

    :cond_2
    :try_start_2
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/a;->Q()Lkotlinx/coroutines/channels/j0;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez v2, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto :goto_0

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    instance-of v3, v2, Lkotlinx/coroutines/channels/w;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v3, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput v1, p0, Lkotlinx/coroutines/channels/h;->size:I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-object v2

    :cond_4
    :try_start_3
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-interface {v2, p1, v3}, Lkotlinx/coroutines/channels/j0;->X(Ljava/lang/Object;Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    sget-object v1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {v2, p1}, Lkotlinx/coroutines/channels/j0;->r(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v2}, Lkotlinx/coroutines/channels/j0;->c()Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-object p1

    :cond_5
    :goto_0
    :try_start_4
    const/4 v5, 0x3

    invoke-direct {p0, v1, p1}, Lkotlinx/coroutines/channels/h;->p0(ILjava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    sget-object p1, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x0

    const/4 v4, 0x1

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x2

    const/4 v4, 0x2

    throw p1
.end method

.method protected L(Ljava/lang/Object;Lkotlinx/coroutines/selects/f;)Ljava/lang/Object;
    .locals 6
    .param p2    # Lkotlinx/coroutines/selects/f;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/selects/f<",
            "*>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v5, 0x0

    iget v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v2, :cond_0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object v2

    :cond_0
    :try_start_1
    const/4 v4, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {p0, v1}, Lkotlinx/coroutines/channels/h;->r0(I)Lkotlinx/coroutines/internal/r0;

    move-result-object v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x7

    return-object v2

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez v1, :cond_6

    :cond_2
    :try_start_2
    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/c;->h(Ljava/lang/Object;)Lkotlinx/coroutines/channels/c$d;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {p2, v2}, Lkotlinx/coroutines/selects/f;->V(Lkotlinx/coroutines/internal/b;)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez v3, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2}, Lkotlinx/coroutines/internal/y$e;->o()Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    sget-object v1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p2}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    check-cast p2, Lkotlinx/coroutines/channels/j0;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-interface {p2, p1}, Lkotlinx/coroutines/channels/j0;->r(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-interface {p2}, Lkotlinx/coroutines/channels/j0;->c()Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-object p1

    :cond_3
    :try_start_3
    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    sget-object v2, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eq v3, v2, :cond_6

    const/4 v4, 0x1

    and-int/2addr v5, v4

    sget-object v2, Lkotlinx/coroutines/internal/c;->b:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eq v3, v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eq v3, p1, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    instance-of p1, v3, Lkotlinx/coroutines/channels/w;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz p1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_4
    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x1

    const/4 v4, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string v1, "orcOetuflfcTeenetetr(AmrrS ipyo oeyiremurTbddfecs)"

    const-string v1, "f(etooftreerlTrdoyrTeidr )O etcAyiefeeSbrcmmucpsrn"

    const/4 v5, 0x7

    const-string v1, "rTyrrtepmbrurnem ryfTdSAid)pfec c(teeroecfoieOsrle"

    const-string v1, "performAtomicTrySelect(describeTryOffer) returned "

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    throw p1

    :cond_5
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput v1, p0, Lkotlinx/coroutines/channels/h;->size:I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-object v3

    :cond_6
    :try_start_4
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {p2}, Lkotlinx/coroutines/selects/f;->I()Z

    move-result p2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez p2, :cond_7

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    iput v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object p1

    :cond_7
    :try_start_5
    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-direct {p0, v1, p1}, Lkotlinx/coroutines/channels/h;->p0(ILjava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget-object p1, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    throw p1
.end method

.method protected Z(Lkotlinx/coroutines/channels/h0;)Z
    .locals 3
    .param p1    # Lkotlinx/coroutines/channels/h0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/h0<",
            "-TE;>;)Z"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-super {p0, p1}, Lkotlinx/coroutines/channels/a;->Z(Lkotlinx/coroutines/channels/h0;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    throw p1
.end method

.method protected final c0()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method protected final d0()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x1

    move v1, v0

    move v1, v0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method protected f0(Z)V
    .locals 11

    const/4 v9, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/c;->a:Li8/l;

    const/4 v9, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/channels/h;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v10, 0x5

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget v2, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    const/4 v3, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    const/4 v4, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    move v5, v3

    move v5, v3

    const/4 v10, 0x6

    move v5, v3

    move v5, v3

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-ge v5, v2, :cond_1

    const/4 v10, 0x6

    iget-object v6, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget v7, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    aget-object v6, v6, v7

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-eqz v0, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    sget-object v7, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    if-eq v6, v7, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {v0, v6, v4}, Lkotlinx/coroutines/internal/i0;->c(Li8/l;Ljava/lang/Object;Lkotlinx/coroutines/internal/d1;)Lkotlinx/coroutines/internal/d1;

    move-result-object v4

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v6, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget v7, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    sget-object v8, Lkotlinx/coroutines/channels/b;->c:Lkotlinx/coroutines/internal/r0;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    aput-object v8, v6, v7

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    add-int/lit8 v7, v7, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    array-length v6, v6

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    rem-int/2addr v7, v6

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    iput v7, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    add-int/lit8 v5, v5, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    goto :goto_0

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    iput v3, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v10, 0x0

    const/4 v9, 0x0

    sget-object v0, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v10, 0x2

    invoke-super {p0, p1}, Lkotlinx/coroutines/channels/a;->f0(Z)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-nez v4, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    return-void

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    throw v4

    :catchall_0
    move-exception p1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    throw p1
.end method

.method public g()Z
    .locals 4

    const/4 v3, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-super {p0}, Lkotlinx/coroutines/channels/a;->g()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    return v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    throw v1
.end method

.method protected i(Lkotlinx/coroutines/channels/l0;)Ljava/lang/Object;
    .locals 3
    .param p1    # Lkotlinx/coroutines/channels/l0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lkotlinx/coroutines/channels/c;->i(Lkotlinx/coroutines/channels/l0;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x2

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    throw p1
.end method

.method public isEmpty()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/a;->e0()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x6

    throw v1
.end method

.method protected j()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v1, "raauf:fcqe(p=iybb"

    const-string v1, "frpcibf(c:yabea=u"

    const/4 v3, 0x6

    const-string v1, ":isyaa(fertfbc=up"

    const-string v1, "(buffer:capacity="

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget v1, p0, Lkotlinx/coroutines/channels/h;->d:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    move v3, v2

    const-string v1, "=zimu,"

    const-string/jumbo v1, "us=zi,"

    const/4 v3, 0x2

    const-string v1, "sz,ioe"

    const-string v1, ",size="

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/16 v1, 0x29

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0
.end method

.method protected j0()Ljava/lang/Object;
    .locals 11
    .annotation build Lia/e;
    .end annotation

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-nez v1, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-nez v1, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    sget-object v1, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    return-object v1

    :cond_1
    :try_start_1
    const/4 v10, 0x4

    iget-object v2, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v9, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget v3, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    aget-object v4, v2, v3

    const/4 v5, 0x2

    move v10, v5

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    aput-object v5, v2, v3

    const/4 v10, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    iput v2, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    sget-object v2, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget v3, p0, Lkotlinx/coroutines/channels/h;->d:I

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    const/4 v6, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/4 v7, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-ne v1, v3, :cond_4

    move-object v3, v5

    move-object v3, v5

    move-object v3, v5

    move-object v3, v5

    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->R()Lkotlinx/coroutines/channels/l0;

    move-result-object v8

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-nez v8, :cond_2

    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    goto :goto_1

    :cond_2
    const/4 v10, 0x6

    const/4 v9, 0x2

    invoke-static {v8}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v8, v5}, Lkotlinx/coroutines/channels/l0;->G0(Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;

    move-result-object v3

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-eqz v3, :cond_3

    const/4 v10, 0x2

    invoke-virtual {v8}, Lkotlinx/coroutines/channels/l0;->E0()Ljava/lang/Object;

    move-result-object v2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    move v7, v6

    const/4 v10, 0x7

    move v7, v6

    move v7, v6

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    goto :goto_1

    :cond_3
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v8}, Lkotlinx/coroutines/channels/l0;->H0()V

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto :goto_0

    :cond_4
    :goto_1
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    sget-object v3, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-eq v2, v3, :cond_5

    const/4 v10, 0x2

    instance-of v3, v2, Lkotlinx/coroutines/channels/w;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-nez v3, :cond_5

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    iput v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v10, 0x1

    iget-object v3, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget v8, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    add-int/2addr v8, v1

    const/4 v9, 0x6

    move v10, v9

    array-length v1, v3

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    rem-int/2addr v8, v1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    aput-object v2, v3, v8

    :cond_5
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget v1, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    add-int/2addr v1, v6

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-object v2, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v10, 0x7

    array-length v2, v2

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    rem-int/2addr v1, v2

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    iput v1, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v10, 0x4

    const/4 v9, 0x6

    sget-object v1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v10, 0x2

    const/4 v9, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    if-eqz v7, :cond_6

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static {v5}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v5}, Lkotlinx/coroutines/channels/l0;->D0()V

    :cond_6
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    return-object v4

    :catchall_0
    move-exception v1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v10, 0x5

    const/4 v9, 0x3

    throw v1
.end method

.method protected k0(Lkotlinx/coroutines/selects/f;)Ljava/lang/Object;
    .locals 10
    .param p1    # Lkotlinx/coroutines/selects/f;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/selects/f<",
            "*>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/h;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    iget v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v9, 0x4

    if-nez v1, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-nez p1, :cond_0

    const/4 v9, 0x3

    sget-object p1, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    return-object p1

    :cond_1
    :try_start_1
    const/4 v9, 0x4

    iget-object v2, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v9, 0x5

    iget v3, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    aget-object v4, v2, v3

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    aput-object v5, v2, v3

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    iput v2, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    sget-object v2, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget v3, p0, Lkotlinx/coroutines/channels/h;->d:I

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    const/4 v6, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-ne v1, v3, :cond_6

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/a;->X()Lkotlinx/coroutines/channels/a$g;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-interface {p1, v3}, Lkotlinx/coroutines/selects/f;->V(Lkotlinx/coroutines/internal/b;)Ljava/lang/Object;

    move-result-object v7

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-nez v7, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x6

    invoke-virtual {v3}, Lkotlinx/coroutines/internal/y$e;->o()Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {v5}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    move-object v2, v5

    move-object v2, v5

    move-object v2, v5

    move-object v2, v5

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    check-cast v2, Lkotlinx/coroutines/channels/l0;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v2}, Lkotlinx/coroutines/channels/l0;->E0()Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    move v3, v6

    move v3, v6

    const/4 v9, 0x0

    move v3, v6

    move v3, v6

    const/4 v9, 0x1

    goto/16 :goto_0

    :cond_3
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    sget-object v3, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v8, 0x1

    move v9, v8

    if-eq v7, v3, :cond_6

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    sget-object v3, Lkotlinx/coroutines/internal/c;->b:Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-eq v7, v3, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-ne v7, v2, :cond_4

    iput v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v9, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    iget v1, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    aput-object v4, p1, v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    return-object v7

    :cond_4
    :try_start_2
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    instance-of v2, v7, Lkotlinx/coroutines/channels/w;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-eqz v2, :cond_5

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    move v3, v6

    move v3, v6

    const/4 v9, 0x6

    move v3, v6

    move v3, v6

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    move-object v5, v2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto :goto_0

    :cond_5
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string v2, "eetptbrnuodeTO)bisyeecm(dSrtflerTrmfoyfc prrcArier"

    const-string v2, "itfdserpeTtcrtibofycn)rdemerreoSmfuOArpyeTlrc(ee r"

    const/4 v9, 0x2

    const-string v2, "rti)fAuSemTbsepilrorfd nfmeeeec( uOcrrTycorteeryrt"

    const-string v2, "performAtomicTrySelect(describeTryOffer) returned "

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-direct {p1, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    throw p1

    :cond_6
    const/4 v8, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v3, 0x0

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x7

    sget-object v7, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-eq v2, v7, :cond_7

    const/4 v9, 0x3

    instance-of v7, v2, Lkotlinx/coroutines/channels/w;

    const/4 v8, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-nez v7, :cond_7

    const/4 v8, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    iput v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget v7, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    add-int/2addr v7, v1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    array-length v1, p1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    rem-int/2addr v7, v1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    aput-object v2, p1, v7

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    goto :goto_1

    :cond_7
    const/4 v8, 0x2

    move v9, v8

    invoke-interface {p1}, Lkotlinx/coroutines/selects/f;->I()Z

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-nez p1, :cond_8

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    iput v1, p0, Lkotlinx/coroutines/channels/h;->size:I

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-object p1, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget v1, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    aput-object v4, p1, v1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    return-object p1

    :cond_8
    :goto_1
    :try_start_3
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget p1, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    add-int/2addr p1, v6

    const/4 v8, 0x4

    move v9, v8

    iget-object v1, p0, Lkotlinx/coroutines/channels/h;->g:[Ljava/lang/Object;

    const/4 v8, 0x6

    and-int/2addr v9, v8

    array-length v1, v1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    rem-int/2addr p1, v1

    const/4 v9, 0x6

    iput p1, p0, Lkotlinx/coroutines/channels/h;->h:I

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-eqz v3, :cond_9

    const/4 v8, 0x2

    move v9, v8

    invoke-static {v5}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    check-cast v5, Lkotlinx/coroutines/channels/l0;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v5}, Lkotlinx/coroutines/channels/l0;->D0()V

    :cond_9
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    return-object v4

    :catchall_0
    move-exception p1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    throw p1
.end method
