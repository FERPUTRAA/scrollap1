.class final Lkotlinx/coroutines/channels/c0;
.super Lkotlinx/coroutines/channels/k;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/k<",
        "TE;>;"
    }
.end annotation


# instance fields
.field private final d:Lkotlin/coroutines/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/channels/i;Li8/p;)V
    .locals 3
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/channels/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "Lkotlinx/coroutines/channels/i<",
            "TE;>;",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/channels/g0<",
            "-TE;>;-",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2, v0}, Lkotlinx/coroutines/channels/k;-><init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/channels/i;Z)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p3, p0, p0}, Lkotlin/coroutines/intrinsics/b;->c(Li8/p;Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/channels/c0;->d:Lkotlin/coroutines/d;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method protected N0()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "u1simbl~~.~~o a@ ~ iMt  S~@ @~~o~~@ @b@@- @ /  y4~~~f@~to@@~ nc@ @~~~o@r K/@o@@o b fvi dls@~~~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/channels/c0;->d:Lkotlin/coroutines/d;

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p0}, Lu8/a;->e(Lkotlin/coroutines/d;Lkotlin/coroutines/d;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public l()Lkotlinx/coroutines/channels/i0;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/k;->j1()Lkotlinx/coroutines/channels/i;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0}, Lkotlinx/coroutines/channels/i;->l()Lkotlinx/coroutines/channels/i0;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lkotlinx/coroutines/v2;->start()Z

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method
