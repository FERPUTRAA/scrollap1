.class final Lkotlinx/coroutines/channels/u$b;
.super Lkotlin/coroutines/jvm/internal/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/u;->d(Lkotlinx/coroutines/channels/i;Li8/l;Lkotlin/coroutines/d;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlin/coroutines/jvm/internal/d;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nChannels.common.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Channels.common.kt\nkotlinx/coroutines/channels/ChannelsKt__Channels_commonKt$consumeEach$3\n*L\n1#1,140:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.ChannelsKt__Channels_commonKt"
    f = "Channels.common.kt"
    i = {
        0x0,
        0x0
    }
    l = {
        0x81
    }
    m = "consumeEach"
    n = {
        "action",
        "channel$iv"
    }
    s = {
        "L$0",
        "L$1"
    }
.end annotation


# instance fields
.field L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field label:I

.field synthetic result:Ljava/lang/Object;


# direct methods
.method constructor <init>(Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/u$b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lkotlin/coroutines/jvm/internal/d;-><init>(Lkotlin/coroutines/d;)V

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bMsf l~@@~o  @~@y/n-~i41b.ob @lt~a~f  ii~u m~@@@  ~o~~@~~  @@@ro@~@o~t@~d@ @ S @ co @K~~~~~v/ ~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/channels/u$b;->result:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget p1, p0, Lkotlinx/coroutines/channels/u$b;->label:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/high16 v0, -0x80000000

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    or-int/2addr p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput p1, p0, Lkotlinx/coroutines/channels/u$b;->label:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 p1, 0x0

    move v2, p1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1, p1, p0}, Lkotlinx/coroutines/channels/u;->d(Lkotlinx/coroutines/channels/i;Li8/l;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p1
.end method
