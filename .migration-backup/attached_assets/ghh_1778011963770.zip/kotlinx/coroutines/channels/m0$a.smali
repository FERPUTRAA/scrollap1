.class public final Lkotlinx/coroutines/channels/m0$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/m0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static synthetic a(Lkotlinx/coroutines/channels/m0;Ljava/lang/Throwable;ILjava/lang/Object;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "d sl@@v @ @~K @f uMtt~@oa -~4~~~ b~~~~@~@n~@~io/ So@@@o. @fb  ~@~@@ rs~@@@i   1~i~~~o@  l/~om~yb"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    if-nez p3, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    if-eqz p2, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p1, 0x0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/m0;->C(Ljava/lang/Throwable;)Z

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return p0

    :cond_1
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x2

    const-string p1, "f tmus nnttrpgaeront ealohlrscrcgtte f pe ,iteu utcadsi seld swh tluoi:nu mSsina"

    const-string p1, "oase nrtel gift e :hliioltstonauotwhintdtsecl re rac auc dp,neus umtgs fnpSturs "

    const/4 v1, 0x6

    const-string p1, "Super calls with default arguments not supported in this target, function: close"

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x3

    throw p0
.end method

.method public static synthetic b()V
    .locals 2
    .annotation build Lkotlinx/coroutines/c2;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public static c(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;)Z
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/m0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/m0<",
            "-TE;>;TE;)Z"
        }
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'trySend\' method"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "trySend(element).isSuccess"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/m0;->p(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0}, Lkotlinx/coroutines/channels/r;->m(Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p0, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    return p0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p0}, Lkotlinx/coroutines/channels/r;->f(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x1

    if-nez p0, :cond_1

    const/4 v1, 0x0

    const/4 p0, 0x0

    const/4 v1, 0x5

    const/4 p0, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p0

    :cond_1
    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p0}, Lkotlinx/coroutines/internal/q0;->p(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    throw p0
.end method
