.class Lkotlinx/coroutines/channels/d;
.super Lkotlinx/coroutines/channels/o;

# interfaces
.implements Lkotlinx/coroutines/channels/f;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/o<",
        "TE;>;",
        "Lkotlinx/coroutines/channels/f<",
        "TE;>;"
    }
.end annotation


# direct methods
.method public constructor <init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/channels/n;Z)V
    .locals 3
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/channels/n;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/g;",
            "Lkotlinx/coroutines/channels/n<",
            "TE;>;Z)V"
        }
    .end annotation

    const/4 v1, 0x5

    move v2, v1

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p1, p2, v0, p3}, Lkotlinx/coroutines/channels/o;-><init>(Lkotlin/coroutines/g;Lkotlinx/coroutines/channels/n;ZZ)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object p2, Lkotlinx/coroutines/n2;->n0:Lkotlinx/coroutines/n2$b;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {p1, p2}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast p1, Lkotlinx/coroutines/n2;

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/v2;->v0(Lkotlinx/coroutines/n2;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method protected L0(Ljava/lang/Throwable;)V
    .locals 5
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/o;->j1()Lkotlinx/coroutines/channels/n;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz p1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    instance-of v2, p1, Ljava/util/concurrent/CancellationException;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v1, Ljava/util/concurrent/CancellationException;

    :cond_0
    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez v1, :cond_1

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p0}, Lkotlinx/coroutines/z0;->a(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v2, "wdsl cnl essac"

    const-string v2, "snsdwe cacall "

    const/4 v4, 0x7

    const-string v2, "clwmeead  nacl"

    const-string v2, " was cancelled"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v1, p1}, Lkotlinx/coroutines/y1;->a(Ljava/lang/String;Ljava/lang/Throwable;)Ljava/util/concurrent/CancellationException;

    move-result-object p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {v0, v1}, Lkotlinx/coroutines/channels/i0;->cancel(Ljava/util/concurrent/CancellationException;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method

.method protected t0(Ljava/lang/Throwable;)Z
    .locals 3
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/a;->getContext()Lkotlin/coroutines/g;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lkotlinx/coroutines/r0;->b(Lkotlin/coroutines/g;Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return p1
.end method
