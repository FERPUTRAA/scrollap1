.class final Lkotlinx/coroutines/channels/a$c;
.super Lkotlinx/coroutines/channels/a$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/a$b<",
        "TE;>;"
    }
.end annotation


# instance fields
.field public final f:Li8/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/l<",
            "TE;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/q;ILi8/l;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/q<",
            "Ljava/lang/Object;",
            ">;I",
            "Li8/l<",
            "-TE;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lkotlinx/coroutines/channels/a$b;-><init>(Lkotlinx/coroutines/q;I)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p3, p0, Lkotlinx/coroutines/channels/a$c;->f:Li8/l;

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public E0(Ljava/lang/Object;)Li8/l;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Li8/l<",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x6

    const-string/jumbo v2, "~oso~~l  ft  @~ y~d~m-Sl@~@@~@t@@@  @@o ~~~i@~is@Kc~f@M ~b @~o~@ ~@~io/o.n1@ @ b ~a  b ~@4~/@rv~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/a$c;->f:Li8/l;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/channels/a$b;->d:Lkotlinx/coroutines/q;

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {v1}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0, p1, v1}, Lkotlinx/coroutines/internal/i0;->a(Li8/l;Ljava/lang/Object;Lkotlin/coroutines/g;)Li8/l;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object p1
.end method
