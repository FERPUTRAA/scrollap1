.class public final Lkotlinx/coroutines/channels/g;
.super Lkotlinx/coroutines/channels/c;

# interfaces
.implements Lkotlinx/coroutines/channels/i;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/channels/g$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/channels/c<",
        "TE;>;",
        "Lkotlinx/coroutines/channels/i<",
        "TE;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nArrayBroadcastChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ArrayBroadcastChannel.kt\nkotlinx/coroutines/channels/ArrayBroadcastChannel\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Concurrent.kt\nkotlinx/coroutines/internal/ConcurrentKt\n*L\n1#1,385:1\n1#2:386\n17#3:387\n17#3:388\n17#3:389\n*S KotlinDebug\n*F\n+ 1 ArrayBroadcastChannel.kt\nkotlinx/coroutines/channels/ArrayBroadcastChannel\n*L\n100#1:387\n117#1:388\n152#1:389\n*E\n"
.end annotation


# instance fields
.field private volatile synthetic _head:J
    .annotation build Lia/d;
    .end annotation
.end field

.field private volatile synthetic _size:I
    .annotation build Lia/d;
    .end annotation
.end field

.field private volatile synthetic _tail:J
    .annotation build Lia/d;
    .end annotation
.end field

.field private final d:I

.field private final e:Ljava/util/concurrent/locks/ReentrantLock;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final f:[Ljava/lang/Object;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lkotlinx/coroutines/channels/g$a<",
            "TE;>;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(I)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {p0, v0}, Lkotlinx/coroutines/channels/c;-><init>(Li8/l;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput p1, p0, Lkotlinx/coroutines/channels/g;->d:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-lt p1, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    move v1, v0

    move v1, v0

    const/4 v4, 0x0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v1, Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    iput-object v1, p0, Lkotlinx/coroutines/channels/g;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x6

    move v4, v3

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/channels/g;->f:[Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    iput-wide v1, p0, Lkotlinx/coroutines/channels/g;->_head:J

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-wide v1, p0, Lkotlinx/coroutines/channels/g;->_tail:J

    const/4 v4, 0x4

    iput v0, p0, Lkotlinx/coroutines/channels/g;->_size:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {}, Lkotlinx/coroutines/internal/f;->d()Ljava/util/List;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/channels/g;->g:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string v1, "ahsc u ae ed rralntpy ratuCmAssytoBa ts bnicataa,t1s eb"

    const-string v1, "btsdta tla cnAha rec lspi tousB,ame1bCu  stra antayerya"

    const/4 v4, 0x0

    const-string/jumbo v1, "ylem by tsa aam Alten dtCorceahctnsa a uutrbcpa s1rta,i"

    const-string v1, "ArrayBroadcastChannel capacity must be at least 1, but "

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string p1, "ifmco s ieedps"

    const-string p1, " ecmd siesfipw"

    const/4 v4, 0x4

    const-string p1, " was specified"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    throw v0
.end method

.method public static final synthetic S(Lkotlinx/coroutines/channels/g;J)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@osl ba@t~@o@~i@ .~@ @r@-y~ l@@o nbd@ 41~tc@ @~o~b  ~/@ ~~of o@S~m~~@~~K u@f@  i~i~M~b /  @~v~~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lkotlinx/coroutines/channels/g;->X(J)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method public static final synthetic T(Lkotlinx/coroutines/channels/g;)J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->c0()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-wide v0
.end method

.method private final U(Ljava/lang/Throwable;)Z
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/g;->C(Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/channels/g;->g:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    check-cast v2, Lkotlinx/coroutines/channels/g$a;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v2, p1}, Lkotlinx/coroutines/channels/a;->W(Ljava/lang/Throwable;)Z

    const/4 v4, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    return v0
.end method

.method private final V()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/channels/g;->g:Ljava/util/List;

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    move v5, v1

    :goto_0
    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    move v2, v1

    move v2, v1

    const/4 v5, 0x4

    move v2, v1

    move v2, v1

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    check-cast v2, Lkotlinx/coroutines/channels/g$a;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v2}, Lkotlinx/coroutines/channels/g$a;->p0()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    move v1, v3

    move v1, v3

    const/4 v5, 0x7

    move v1, v3

    move v1, v3

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez v1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v2, :cond_3

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v0, 0x3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p0, v1, v1, v0, v1}, Lkotlinx/coroutines/channels/g;->h0(Lkotlinx/coroutines/channels/g;Lkotlinx/coroutines/channels/g$a;Lkotlinx/coroutines/channels/g$a;ILjava/lang/Object;)V

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void
.end method

.method private final W()J
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/g;->g:Ljava/util/List;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    check-cast v3, Lkotlinx/coroutines/channels/g$a;

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-virtual {v3}, Lkotlinx/coroutines/channels/g$a;->q0()J

    move-result-wide v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v1, v2, v3, v4}, Lkotlin/ranges/s;->C(JJ)J

    move-result-wide v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-wide v1
.end method

.method private final X(J)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J)TE;"
        }
    .end annotation

    const/4 v4, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/g;->f:[Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget v1, p0, Lkotlinx/coroutines/channels/g;->d:I

    const/4 v4, 0x3

    int-to-long v1, v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    rem-long/2addr p1, v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    long-to-int p1, p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    aget-object p1, v0, p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object p1
.end method

.method private final Z()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    iget-wide v0, p0, Lkotlinx/coroutines/channels/g;->_head:J

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-wide v0
.end method

.method private final a0()I
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    iget v0, p0, Lkotlinx/coroutines/channels/g;->_size:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method private static synthetic b0()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method private final c0()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-wide v0, p0, Lkotlinx/coroutines/channels/g;->_tail:J

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-wide v0
.end method

.method private final d0(J)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-wide p1, p0, Lkotlinx/coroutines/channels/g;->_head:J

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method private final e0(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lkotlinx/coroutines/channels/g;->_size:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method private final f0(J)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    iput-wide p1, p0, Lkotlinx/coroutines/channels/g;->_tail:J

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method private final g0(Lkotlinx/coroutines/channels/g$a;Lkotlinx/coroutines/channels/g$a;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g$a<",
            "TE;>;",
            "Lkotlinx/coroutines/channels/g$a<",
            "TE;>;)V"
        }
    .end annotation

    :goto_0
    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/channels/g;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x3

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->c0()J

    move-result-wide v1

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {p1, v1, v2}, Lkotlinx/coroutines/channels/g$a;->t0(J)V

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/channels/g;->g:Ljava/util/List;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x6

    iget-object v2, p0, Lkotlinx/coroutines/channels/g;->g:Ljava/util/List;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-interface {v2, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x2

    if-nez v1, :cond_0

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x5

    goto/16 :goto_3

    :cond_0
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    if-eqz p2, :cond_1

    :try_start_1
    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget-object p1, p0, Lkotlinx/coroutines/channels/g;->g:Ljava/util/List;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-interface {p1, p2}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->Z()J

    move-result-wide v1

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-virtual {p2}, Lkotlinx/coroutines/channels/g$a;->q0()J

    move-result-wide p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v12, 0x6

    const/4 v11, 0x4

    cmp-long p1, v1, p1

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x1

    if-eqz p1, :cond_1

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    return-void

    :cond_1
    :try_start_2
    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->W()J

    move-result-wide p1

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->c0()J

    move-result-wide v1

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->Z()J

    move-result-wide v3

    const/4 v12, 0x0

    const/4 v11, 0x5

    invoke-static {p1, p2, v1, v2}, Lkotlin/ranges/s;->C(JJ)J

    move-result-wide p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x4

    cmp-long v5, p1, v3

    const/4 v12, 0x3

    if-gtz v5, :cond_2

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x7

    return-void

    :cond_2
    :try_start_3
    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->a0()I

    move-result v5

    :cond_3
    :goto_1
    const/4 v12, 0x4

    const/4 v11, 0x0

    cmp-long v6, v3, p1

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x7

    if-gez v6, :cond_7

    const/4 v12, 0x4

    iget-object v6, p0, Lkotlinx/coroutines/channels/g;->f:[Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget v7, p0, Lkotlinx/coroutines/channels/g;->d:I

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x0

    int-to-long v8, v7

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    rem-long v8, v3, v8

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x2

    long-to-int v8, v8

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x4

    const/4 v9, 0x0

    aput-object v9, v6, v8

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-lt v5, v7, :cond_4

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x2

    const/4 v6, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x0

    goto :goto_2

    :cond_4
    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    const/4 v6, 0x0

    :goto_2
    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x5

    const-wide/16 v7, 0x1

    const-wide/16 v7, 0x1

    const/4 v12, 0x7

    const-wide/16 v7, 0x1

    const-wide/16 v7, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x3

    add-long/2addr v3, v7

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-direct {p0, v3, v4}, Lkotlinx/coroutines/channels/g;->d0(J)V

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    add-int/lit8 v5, v5, -0x1

    const/4 v11, 0x0

    move v12, v11

    invoke-direct {p0, v5}, Lkotlinx/coroutines/channels/g;->e0(I)V

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x0

    if-eqz v6, :cond_3

    :cond_5
    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->R()Lkotlinx/coroutines/channels/l0;

    move-result-object v6

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x0

    if-nez v6, :cond_6

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    goto :goto_1

    :cond_6
    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x0

    instance-of v10, v6, Lkotlinx/coroutines/channels/w;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    if-nez v10, :cond_3

    const/4 v11, 0x1

    const/4 v11, 0x7

    invoke-static {v6}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v12, 0x7

    const/4 v11, 0x7

    invoke-virtual {v6, v9}, Lkotlinx/coroutines/channels/l0;->G0(Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;

    move-result-object v10

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    if-eqz v10, :cond_5

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/channels/g;->f:[Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget p2, p0, Lkotlinx/coroutines/channels/g;->d:I

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x2

    int-to-long v3, p2

    const/4 v11, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x5

    rem-long v3, v1, v3

    const/4 v11, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    long-to-int p2, v3

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {v6}, Lkotlinx/coroutines/channels/l0;->E0()Ljava/lang/Object;

    move-result-object v3

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    aput-object v3, p1, p2

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x6

    add-int/lit8 v5, v5, 0x1

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-direct {p0, v5}, Lkotlinx/coroutines/channels/g;->e0(I)V

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x3

    add-long/2addr v1, v7

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-direct {p0, v1, v2}, Lkotlinx/coroutines/channels/g;->f0(J)V

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {v6}, Lkotlinx/coroutines/channels/l0;->D0()V

    const/4 v12, 0x7

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->V()V

    move-object p1, v9

    move-object p1, v9

    move-object p1, v9

    move-object p1, v9

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x1

    goto/16 :goto_0

    :cond_7
    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v12, 0x2

    return-void

    :goto_3
    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v12, 0x6

    const/4 v11, 0x7

    throw p1
.end method

.method static synthetic h0(Lkotlinx/coroutines/channels/g;Lkotlinx/coroutines/channels/g$a;Lkotlinx/coroutines/channels/g$a;ILjava/lang/Object;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    and-int/lit8 p4, p3, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz p4, :cond_0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    and-int/lit8 p3, p3, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p3, :cond_1

    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2}, Lkotlinx/coroutines/channels/g;->g0(Lkotlinx/coroutines/channels/g$a;Lkotlinx/coroutines/channels/g$a;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public C(Ljava/lang/Throwable;)Z
    .locals 2
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lkotlinx/coroutines/channels/c;->C(Ljava/lang/Throwable;)Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    if-nez p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x1

    return p1

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x1

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->V()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return p1
.end method

.method protected H()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method protected I()Z
    .locals 4

    const/4 v3, 0x7

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->a0()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget v1, p0, Lkotlinx/coroutines/channels/g;->d:I

    const/4 v3, 0x7

    if-lt v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x1

    move v3, v0

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    return v0
.end method

.method protected K(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/g;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v8, 0x4

    const/4 v7, 0x6

    return-object v1

    :cond_0
    :try_start_1
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->a0()I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget v2, p0, Lkotlinx/coroutines/channels/g;->d:I

    const/4 v8, 0x7

    if-lt v1, v2, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    sget-object p1, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v8, 0x4

    return-object p1

    :cond_1
    :try_start_2
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->c0()J

    move-result-wide v2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    iget-object v4, p0, Lkotlinx/coroutines/channels/g;->f:[Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget v5, p0, Lkotlinx/coroutines/channels/g;->d:I

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    int-to-long v5, v5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    rem-long v5, v2, v5

    const/4 v8, 0x0

    const/4 v7, 0x0

    long-to-int v5, v5

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    aput-object p1, v4, v5

    const/4 v7, 0x4

    move v8, v7

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    invoke-direct {p0, v1}, Lkotlinx/coroutines/channels/g;->e0(I)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v8, 0x0

    const-wide/16 v4, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    add-long/2addr v2, v4

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {p0, v2, v3}, Lkotlinx/coroutines/channels/g;->f0(J)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->V()V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    sget-object p1, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    throw p1
.end method

.method protected L(Ljava/lang/Object;Lkotlinx/coroutines/selects/f;)Ljava/lang/Object;
    .locals 8
    .param p2    # Lkotlinx/coroutines/selects/f;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/selects/f<",
            "*>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/g;->e:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v7, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/c;->n()Lkotlinx/coroutines/channels/w;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz v1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v7, 0x3

    return-object v1

    :cond_0
    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->a0()I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget v2, p0, Lkotlinx/coroutines/channels/g;->d:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-lt v1, v2, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    sget-object p1, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-object p1

    :cond_1
    :try_start_2
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-interface {p2}, Lkotlinx/coroutines/selects/f;->I()Z

    move-result p2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-nez p2, :cond_2

    const/4 v6, 0x2

    xor-int/2addr v7, v6

    invoke-static {}, Lkotlinx/coroutines/selects/g;->d()Ljava/lang/Object;

    move-result-object p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v6, 0x7

    const/4 v7, 0x7

    return-object p1

    :cond_2
    :try_start_3
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->c0()J

    move-result-wide v2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object p2, p0, Lkotlinx/coroutines/channels/g;->f:[Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget v4, p0, Lkotlinx/coroutines/channels/g;->d:I

    const/4 v6, 0x6

    const/4 v7, 0x0

    int-to-long v4, v4

    const/4 v7, 0x4

    const/4 v6, 0x4

    rem-long v4, v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    long-to-int v4, v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    aput-object p1, p2, v4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {p0, v1}, Lkotlinx/coroutines/channels/g;->e0(I)V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-wide/16 p1, 0x1

    const-wide/16 p1, 0x1

    const/4 v7, 0x5

    const-wide/16 p1, 0x1

    const-wide/16 p1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    add-long/2addr v2, p1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-direct {p0, v2, v3}, Lkotlinx/coroutines/channels/g;->f0(J)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v7, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->V()V

    const/4 v7, 0x5

    sget-object p1, Lkotlinx/coroutines/channels/b;->d:Lkotlinx/coroutines/internal/r0;

    const/4 v6, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    throw p1
.end method

.method public final Y()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lkotlinx/coroutines/channels/g;->d:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public cancel(Ljava/util/concurrent/CancellationException;)V
    .locals 2
    .param p1    # Ljava/util/concurrent/CancellationException;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/g;->U(Ljava/lang/Throwable;)Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public synthetic cancel(Ljava/lang/Throwable;)Z
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Since 1.2.0, binary compatibility with versions <= 1.1.x"
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/g;->U(Ljava/lang/Throwable;)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p1
.end method

.method protected j()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v1, "e(bfofr=ct:cpayiu"

    const-string v1, "ca=beuui:ytpacffr"

    const-string v1, "(buffer:capacity="

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/channels/g;->f:[Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    array-length v1, v1

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string v1, "spz,e="

    const-string v1, ",size="

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p0}, Lkotlinx/coroutines/channels/g;->a0()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/16 v1, 0x29

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object v0
.end method

.method public l()Lkotlinx/coroutines/channels/i0;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v0, Lkotlinx/coroutines/channels/g$a;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0, p0}, Lkotlinx/coroutines/channels/g$a;-><init>(Lkotlinx/coroutines/channels/g;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    move v4, v3

    invoke-static {p0, v0, v1, v2, v1}, Lkotlinx/coroutines/channels/g;->h0(Lkotlinx/coroutines/channels/g;Lkotlinx/coroutines/channels/g$a;Lkotlinx/coroutines/channels/g$a;ILjava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object v0
.end method
