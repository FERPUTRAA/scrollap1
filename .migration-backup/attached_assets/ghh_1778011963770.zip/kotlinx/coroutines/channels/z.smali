.class public final Lkotlinx/coroutines/channels/z;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/channels/i;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/channels/z$b;,
        Lkotlinx/coroutines/channels/z$c;,
        Lkotlinx/coroutines/channels/z$a;,
        Lkotlinx/coroutines/channels/z$d;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/channels/i<",
        "TE;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nConflatedBroadcastChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ConflatedBroadcastChannel.kt\nkotlinx/coroutines/channels/ConflatedBroadcastChannel\n+ 2 AtomicFU.common.kt\nkotlinx/atomicfu/AtomicFU_commonKt\n+ 3 Symbol.kt\nkotlinx/coroutines/internal/Symbol\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 5 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,295:1\n155#2,2:296\n155#2,2:299\n155#2,2:301\n155#2,2:304\n155#2,2:308\n18#3:298\n1#4:303\n13536#5,2:306\n13536#5,2:310\n*S KotlinDebug\n*F\n+ 1 ConflatedBroadcastChannel.kt\nkotlinx/coroutines/channels/ConflatedBroadcastChannel\n*L\n74#1:296,2\n101#1:299,2\n121#1:301,2\n160#1:304,2\n245#1:308,2\n92#1:298\n166#1:306,2\n254#1:310,2\n*E\n"
.end annotation

.annotation build Lkotlinx/coroutines/e3;
.end annotation


# static fields
.field private static final a:Lkotlinx/coroutines/channels/z$b;
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final synthetic b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

.field private static final synthetic c:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

.field private static final synthetic d:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

.field private static final e:Lkotlinx/coroutines/channels/z$a;
    .annotation build Lia/d;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field private static final f:Lkotlinx/coroutines/internal/r0;
    .annotation build Lia/d;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field private static final g:Lkotlinx/coroutines/channels/z$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/z$c<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field private volatile synthetic _state:Ljava/lang/Object;
    .annotation build Lia/d;
    .end annotation
.end field

.field private volatile synthetic _updating:I
    .annotation build Lia/d;
    .end annotation
.end field

.field private volatile synthetic onCloseHandler:Ljava/lang/Object;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v0, Lkotlinx/coroutines/channels/z$b;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v0, v1}, Lkotlinx/coroutines/channels/z$b;-><init>(Lkotlin/jvm/internal/w;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    sput-object v0, Lkotlinx/coroutines/channels/z;->a:Lkotlinx/coroutines/channels/z$b;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Lkotlinx/coroutines/channels/z$a;

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Lkotlinx/coroutines/channels/z$a;-><init>(Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    sput-object v0, Lkotlinx/coroutines/channels/z;->e:Lkotlinx/coroutines/channels/z$a;

    const/4 v4, 0x1

    const/4 v3, 0x4

    new-instance v0, Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v2, "NDsDFIUEE"

    const-string v2, "UNDEFINED"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v0, v2}, Lkotlinx/coroutines/internal/r0;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    sput-object v0, Lkotlinx/coroutines/channels/z;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v2, Lkotlinx/coroutines/channels/z$c;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v2, v0, v1}, Lkotlinx/coroutines/channels/z$c;-><init>(Ljava/lang/Object;[Lkotlinx/coroutines/channels/z$d;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    sput-object v2, Lkotlinx/coroutines/channels/z;->g:Lkotlinx/coroutines/channels/z$c;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v0, "ets_st"

    const/4 v4, 0x3

    const-string/jumbo v0, "ttemas"

    const-string v0, "_state"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-class v1, Lkotlinx/coroutines/channels/z;

    const-class v1, Lkotlinx/coroutines/channels/z;

    const/4 v4, 0x1

    const-class v1, Lkotlinx/coroutines/channels/z;

    const-class v1, Lkotlinx/coroutines/channels/z;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const-class v2, Ljava/lang/Object;

    const-class v2, Ljava/lang/Object;

    const-class v2, Ljava/lang/Object;

    const-class v2, Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v1, v2, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    sput-object v0, Lkotlinx/coroutines/channels/z;->b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v0, "anptom_ud"

    const-string v0, "ntamip_ud"

    const/4 v4, 0x2

    const-string v0, "pdgt_bnua"

    const-string v0, "_updating"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v1, v0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    sput-object v0, Lkotlinx/coroutines/channels/z;->c:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v0, "roeHenualooCds"

    const-string v0, "enHsooanrodleC"

    const/4 v4, 0x2

    const-string v0, "rnelHolpdaeoCs"

    const-string v0, "onCloseHandler"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v1, v2, v0}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    sput-object v0, Lkotlinx/coroutines/channels/z;->d:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object v0, Lkotlinx/coroutines/channels/z;->g:Lkotlinx/coroutines/channels/z$c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lkotlinx/coroutines/channels/z;->_state:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x0

    shr-int/2addr v2, v0

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput v0, p0, Lkotlinx/coroutines/channels/z;->_updating:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lkotlinx/coroutines/channels/z;->onCloseHandler:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)V"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p0}, Lkotlinx/coroutines/channels/z;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    sget-object v0, Lkotlinx/coroutines/channels/z;->b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v1, Lkotlinx/coroutines/channels/z$c;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {v1, p1, v2}, Lkotlinx/coroutines/channels/z$c;-><init>(Ljava/lang/Object;[Lkotlinx/coroutines/channels/z$d;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, p0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->lazySet(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void
.end method

.method public static final synthetic a(Lkotlinx/coroutines/channels/z;Lkotlinx/coroutines/channels/z$d;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "ooim~~@@q u   ~~@~@K 1o~t.rS4t@~@M@/b fo~bf @/~@ll~@a~- ~@  ~ys n~ b~ @@@i@ @o@co~~~ @vd~@@~~  i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/z;->d(Lkotlinx/coroutines/channels/z$d;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public static final synthetic b(Lkotlinx/coroutines/channels/z;Lkotlinx/coroutines/selects/f;Ljava/lang/Object;Li8/p;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    invoke-direct {p0, p1, p2, p3}, Lkotlinx/coroutines/channels/z;->j(Lkotlinx/coroutines/selects/f;Ljava/lang/Object;Li8/p;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method private final c([Lkotlinx/coroutines/channels/z$d;Lkotlinx/coroutines/channels/z$d;)[Lkotlinx/coroutines/channels/z$d;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lkotlinx/coroutines/channels/z$d<",
            "TE;>;",
            "Lkotlinx/coroutines/channels/z$d<",
            "TE;>;)[",
            "Lkotlinx/coroutines/channels/z$d<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-array p1, p1, [Lkotlinx/coroutines/channels/z$d;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    aput-object p2, p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p1

    :cond_0
    const/4 v2, 0x1

    invoke-static {p1, p2}, Lkotlin/collections/l;->w3([Ljava/lang/Object;Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast p1, [Lkotlinx/coroutines/channels/z$d;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p1
.end method

.method private final d(Lkotlinx/coroutines/channels/z$d;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/z$d<",
            "TE;>;)V"
        }
    .end annotation

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/channels/z;->_state:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    instance-of v1, v0, Lkotlinx/coroutines/channels/z$a;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    instance-of v1, v0, Lkotlinx/coroutines/channels/z$c;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-instance v1, Lkotlinx/coroutines/channels/z$c;

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    check-cast v2, Lkotlinx/coroutines/channels/z$c;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v3, v2, Lkotlinx/coroutines/channels/z$c;->a:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x7

    iget-object v2, v2, Lkotlinx/coroutines/channels/z$c;->b:[Lkotlinx/coroutines/channels/z$d;

    const/4 v4, 0x7

    or-int/2addr v5, v4

    invoke-static {v2}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {p0, v2, p1}, Lkotlinx/coroutines/channels/z;->m([Lkotlinx/coroutines/channels/z$d;Lkotlinx/coroutines/channels/z$d;)[Lkotlinx/coroutines/channels/z$d;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-direct {v1, v3, v2}, Lkotlinx/coroutines/channels/z$c;-><init>(Ljava/lang/Object;[Lkotlinx/coroutines/channels/z$d;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    sget-object v2, Lkotlinx/coroutines/channels/z;->b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-static {v2, p0, v0, v1}, Landroidx/concurrent/futures/b;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-void

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const-string/jumbo v2, "teatnbva ldsiI"

    const/4 v5, 0x3

    const-string v2, " dsIvleaisttn "

    const-string v2, "Invalid state "

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    throw p1
.end method

.method public static synthetic f()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method private final h(Ljava/lang/Throwable;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/z;->onCloseHandler:Ljava/lang/Object;

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v1, Lkotlinx/coroutines/channels/b;->h:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eq v0, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget-object v2, Lkotlinx/coroutines/channels/z;->d:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v2, p0, v0, v1}, Landroidx/concurrent/futures/b;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/u1;->q(Ljava/lang/Object;I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast v0, Li8/l;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {v0, p1}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    return-void
.end method

.method private final i(Ljava/lang/Object;)Lkotlinx/coroutines/channels/z$a;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Lkotlinx/coroutines/channels/z$a;"
        }
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget-object v0, Lkotlinx/coroutines/channels/z;->c:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/4 v1, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v0, p0, v2, v1}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->compareAndSet(Ljava/lang/Object;II)Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-nez v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    return-object v1

    :cond_0
    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/z;->_state:Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    instance-of v3, v0, Lkotlinx/coroutines/channels/z$a;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v3, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x4

    check-cast v0, Lkotlinx/coroutines/channels/z$a;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    iput v2, p0, Lkotlinx/coroutines/channels/z;->_updating:I

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-object v0

    :cond_1
    :try_start_1
    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    instance-of v3, v0, Lkotlinx/coroutines/channels/z$c;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v3, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-instance v3, Lkotlinx/coroutines/channels/z$c;

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    check-cast v4, Lkotlinx/coroutines/channels/z$c;

    const/4 v7, 0x0

    iget-object v4, v4, Lkotlinx/coroutines/channels/z$c;->b:[Lkotlinx/coroutines/channels/z$d;

    const/4 v7, 0x0

    invoke-direct {v3, p1, v4}, Lkotlinx/coroutines/channels/z$c;-><init>(Ljava/lang/Object;[Lkotlinx/coroutines/channels/z$d;)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    sget-object v4, Lkotlinx/coroutines/channels/z;->b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v4, p0, v0, v3}, Landroidx/concurrent/futures/b;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v3, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    check-cast v0, Lkotlinx/coroutines/channels/z$c;

    iget-object v0, v0, Lkotlinx/coroutines/channels/z$c;->b:[Lkotlinx/coroutines/channels/z$d;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v0, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    array-length v3, v0

    const/4 v7, 0x5

    move v4, v2

    move v4, v2

    const/4 v7, 0x3

    move v4, v2

    move v4, v2

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-ge v4, v3, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x3

    aget-object v5, v0, v4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v5, p1}, Lkotlinx/coroutines/channels/z$d;->K(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_0

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput v2, p0, Lkotlinx/coroutines/channels/z;->_updating:I

    return-object v1

    :cond_3
    :try_start_2
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    move v7, v6

    const-string v3, "a vmIitt uasnl"

    const-string v3, "ai nasuvld tIt"

    const/4 v7, 0x0

    const-string v3, "dea ottaisvnlI"

    const-string v3, "Invalid state "

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    iput v2, p0, Lkotlinx/coroutines/channels/z;->_updating:I

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    throw p1
.end method

.method private final j(Lkotlinx/coroutines/selects/f;Ljava/lang/Object;Li8/p;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/selects/f<",
            "-TR;>;TE;",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/channels/m0<",
            "-TE;>;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {p1}, Lkotlinx/coroutines/selects/f;->I()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p2}, Lkotlinx/coroutines/channels/z;->i(Ljava/lang/Object;)Lkotlinx/coroutines/channels/z$a;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x1

    if-eqz p2, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p2}, Lkotlinx/coroutines/channels/z$a;->a()Ljava/lang/Throwable;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {p1, p2}, Lkotlinx/coroutines/selects/f;->T(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {p1}, Lkotlinx/coroutines/selects/f;->P()Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p3, p0, p1}, Lu8/b;->d(Li8/p;Ljava/lang/Object;Lkotlin/coroutines/d;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method private final m([Lkotlinx/coroutines/channels/z$d;Lkotlinx/coroutines/channels/z$d;)[Lkotlinx/coroutines/channels/z$d;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lkotlinx/coroutines/channels/z$d<",
            "TE;>;",
            "Lkotlinx/coroutines/channels/z$d<",
            "TE;>;)[",
            "Lkotlinx/coroutines/channels/z$d<",
            "TE;>;"
        }
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    array-length v0, p1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {p1, p2}, Lkotlin/collections/l;->If([Ljava/lang/Object;Ljava/lang/Object;)I

    move-result p2

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/4 v1, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-ne v0, v1, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/4 p1, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    return-object p1

    :cond_0
    const/4 v9, 0x3

    sub-int/2addr v0, v1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    new-array v0, v0, [Lkotlinx/coroutines/channels/z$d;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/4 v3, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/4 v4, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/4 v6, 0x6

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v7, 0x0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    move v5, p2

    move v5, p2

    move v5, p2

    move v5, p2

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static/range {v1 .. v7}, Lkotlin/collections/l;->K0([Ljava/lang/Object;[Ljava/lang/Object;IIIILjava/lang/Object;)[Ljava/lang/Object;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    add-int/lit8 v4, p2, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/4 v5, 0x0

    const/4 v9, 0x2

    const/16 v6, 0x8

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    move v3, p2

    const/4 v9, 0x1

    move v3, p2

    move v3, p2

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static/range {v1 .. v7}, Lkotlin/collections/l;->K0([Ljava/lang/Object;[Ljava/lang/Object;IIIILjava/lang/Object;)[Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    return-object v0
.end method


# virtual methods
.method public C(Ljava/lang/Throwable;)Z
    .locals 6
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/z;->_state:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    instance-of v1, v0, Lkotlinx/coroutines/channels/z$a;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x0

    return v2

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    instance-of v1, v0, Lkotlinx/coroutines/channels/z$c;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v1, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez p1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget-object v1, Lkotlinx/coroutines/channels/z;->e:Lkotlinx/coroutines/channels/z$a;

    const/4 v5, 0x5

    const/4 v4, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v1, Lkotlinx/coroutines/channels/z$a;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {v1, p1}, Lkotlinx/coroutines/channels/z$a;-><init>(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    sget-object v3, Lkotlinx/coroutines/channels/z;->b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v3, p0, v0, v1}, Landroidx/concurrent/futures/b;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    move v5, v4

    check-cast v0, Lkotlinx/coroutines/channels/z$c;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, v0, Lkotlinx/coroutines/channels/z$c;->b:[Lkotlinx/coroutines/channels/z$d;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v0, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    array-length v1, v0

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ge v2, v1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    aget-object v3, v0, v2

    const/4 v5, 0x7

    invoke-virtual {v3, p1}, Lkotlinx/coroutines/channels/c;->C(Ljava/lang/Throwable;)Z

    const/4 v4, 0x1

    or-int/2addr v5, v4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_1

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/z;->h(Ljava/lang/Throwable;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 p1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    return p1

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    move v5, v4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v2, "aipetbsatn  lv"

    const-string v2, "a telt pInsvai"

    const/4 v5, 0x5

    const-string v2, "leaianu sttvId"

    const-string v2, "Invalid state "

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    throw p1
.end method

.method public D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/z;->i(Ljava/lang/Object;)Lkotlinx/coroutines/channels/z$a;

    move-result-object p1

    const/4 v1, 0x3

    if-nez p1, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-nez p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p1

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/z$a;->a()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    throw p1
.end method

.method public E()Z
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Lkotlinx/coroutines/channels/z;->_state:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    instance-of v0, v0, Lkotlinx/coroutines/channels/z$a;

    const/4 v2, 0x2

    const/4 v1, 0x2

    return v0
.end method

.method public cancel(Ljava/util/concurrent/CancellationException;)V
    .locals 2
    .param p1    # Ljava/util/concurrent/CancellationException;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/z;->C(Ljava/lang/Throwable;)Z

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public synthetic cancel(Ljava/lang/Throwable;)Z
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->c:Lkotlin/m;
        message = "Since 1.2.0, binary compatibility with versions <= 1.1.x"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/channels/z;->C(Ljava/lang/Throwable;)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    return p1
.end method

.method public final e()Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Lkotlinx/coroutines/channels/z;->_state:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    instance-of v1, v0, Lkotlinx/coroutines/channels/z$a;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-nez v1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    instance-of v1, v0, Lkotlinx/coroutines/channels/z$c;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    check-cast v0, Lkotlinx/coroutines/channels/z$c;

    const/4 v5, 0x0

    iget-object v0, v0, Lkotlinx/coroutines/channels/z$c;->a:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    sget-object v1, Lkotlinx/coroutines/channels/z;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eq v0, v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object v0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v1, "laqovNep"

    const-string v1, "qeoNlvau"

    const/4 v5, 0x7

    const-string v1, "qNelvua "

    const-string v1, "No value"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    throw v0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v3, "dlstteisaI nsv"

    const-string v3, "d s niIavettsl"

    const/4 v5, 0x1

    const-string v3, "eaim asvnttd l"

    const-string v3, "Invalid state "

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    throw v1

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    check-cast v0, Lkotlinx/coroutines/channels/z$a;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v0}, Lkotlinx/coroutines/channels/z$a;->b()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    throw v0
.end method

.method public final g()Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TE;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, p0, Lkotlinx/coroutines/channels/z;->_state:Ljava/lang/Object;

    const/4 v4, 0x6

    and-int/2addr v5, v4

    instance-of v1, v0, Lkotlinx/coroutines/channels/z$a;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    instance-of v1, v0, Lkotlinx/coroutines/channels/z$c;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-object v1, Lkotlinx/coroutines/channels/z;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    check-cast v0, Lkotlinx/coroutines/channels/z$c;

    const/4 v5, 0x0

    iget-object v0, v0, Lkotlinx/coroutines/channels/z$c;->a:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-ne v0, v1, :cond_1

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-object v2

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const-string v3, "itatoleIadsn  "

    const-string v3, "Invalid state "

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    throw v1
.end method

.method public k()Lkotlinx/coroutines/selects/e;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/selects/e<",
            "TE;",
            "Lkotlinx/coroutines/channels/m0<",
            "TE;>;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Lkotlinx/coroutines/channels/z$e;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Lkotlinx/coroutines/channels/z$e;-><init>(Lkotlinx/coroutines/channels/z;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public l()Lkotlinx/coroutines/channels/i0;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-instance v0, Lkotlinx/coroutines/channels/z$d;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {v0, p0}, Lkotlinx/coroutines/channels/z$d;-><init>(Lkotlinx/coroutines/channels/z;)V

    :cond_0
    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/channels/z;->_state:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    instance-of v2, v1, Lkotlinx/coroutines/channels/z$a;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x0

    check-cast v1, Lkotlinx/coroutines/channels/z$a;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v1, v1, Lkotlinx/coroutines/channels/z$a;->a:Ljava/lang/Throwable;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Lkotlinx/coroutines/channels/c;->C(Ljava/lang/Throwable;)Z

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-object v0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    instance-of v2, v1, Lkotlinx/coroutines/channels/z$c;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v2, :cond_3

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    check-cast v2, Lkotlinx/coroutines/channels/z$c;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v3, v2, Lkotlinx/coroutines/channels/z$c;->a:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    sget-object v4, Lkotlinx/coroutines/channels/z;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eq v3, v4, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0, v3}, Lkotlinx/coroutines/channels/z$d;->K(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v3, Lkotlinx/coroutines/channels/z$c;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v4, v2, Lkotlinx/coroutines/channels/z$c;->a:Ljava/lang/Object;

    const/4 v6, 0x3

    iget-object v2, v2, Lkotlinx/coroutines/channels/z$c;->b:[Lkotlinx/coroutines/channels/z$d;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {p0, v2, v0}, Lkotlinx/coroutines/channels/z;->c([Lkotlinx/coroutines/channels/z$d;Lkotlinx/coroutines/channels/z$d;)[Lkotlinx/coroutines/channels/z$d;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {v3, v4, v2}, Lkotlinx/coroutines/channels/z$c;-><init>(Ljava/lang/Object;[Lkotlinx/coroutines/channels/z$d;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    sget-object v2, Lkotlinx/coroutines/channels/z;->b:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v2, p0, v1, v3}, Landroidx/concurrent/futures/b;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-object v0

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const-string v3, "aImtabvdtinl e"

    const-string v3, "ldImi eavt ant"

    const-string v3, "ltiav uIne sda"

    const-string v3, "Invalid state "

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    throw v0
.end method

.method public offer(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)Z"
        }
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'trySend\' method"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "trySend(element).isSuccess"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/i$a;->c(Lkotlinx/coroutines/channels/i;Ljava/lang/Object;)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    return p1
.end method

.method public p(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lkotlinx/coroutines/channels/z;->i(Ljava/lang/Object;)Lkotlinx/coroutines/channels/z$a;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v1, 0x3

    or-int/2addr v2, v1

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/z$a;->a()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/channels/r$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object p1, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Lkotlinx/coroutines/channels/r$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p1
.end method

.method public x(Li8/l;)V
    .locals 5
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/l<",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object v0, Lkotlinx/coroutines/channels/z;->d:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x5

    move v3, v1

    move v3, v1

    const/4 v4, 0x6

    invoke-static {v0, p0, v1, p1}, Landroidx/concurrent/futures/b;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/channels/z;->onCloseHandler:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget-object v0, Lkotlinx/coroutines/channels/b;->h:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-ne p1, v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v0, "teucha p e ar nrwnogydloh s  nidrfiAouseevdenresyedslrtaeclkdaa"

    const-string v0, "syedoehol te anlrA eedlvd euwusaa ahcdyieorekcin nfrtrslgasd nr"

    const/4 v4, 0x7

    const-string v0, " leencvsq dadnsretltohfgeywueAekdray il cendsrarlio as hs rande"

    const-string v0, "Another handler was already registered and successfully invoked"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    throw p1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const-string v2, "rds a ineaetrrAg hho t r:syeawaesledlder"

    const-string v2, "Another handler was already registered: "

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    throw v0

    :cond_1
    const/4 v4, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/z;->_state:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    instance-of v2, v1, Lkotlinx/coroutines/channels/z$a;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v2, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    sget-object v2, Lkotlinx/coroutines/channels/b;->h:Lkotlinx/coroutines/internal/r0;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v0, p0, p1, v2}, Landroidx/concurrent/futures/b;->a(Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    check-cast v1, Lkotlinx/coroutines/channels/z$a;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, v1, Lkotlinx/coroutines/channels/z$a;->a:Ljava/lang/Throwable;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {p1, v0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void
.end method
