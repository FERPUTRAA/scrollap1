.class public final Lkotlinx/coroutines/channels/a$g;
.super Lkotlinx/coroutines/internal/y$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1c
    name = "g"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/internal/y$e<",
        "Lkotlinx/coroutines/channels/l0;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAbstractChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AbstractChannel.kt\nkotlinx/coroutines/channels/AbstractChannel$TryPollDesc\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1132:1\n1#2:1133\n*E\n"
.end annotation


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/internal/w;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/internal/w;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lkotlinx/coroutines/internal/y$e;-><init>(Lkotlinx/coroutines/internal/y;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method protected e(Lkotlinx/coroutines/internal/y;)Ljava/lang/Object;
    .locals 3
    .param p1    # Lkotlinx/coroutines/internal/y;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@bs i @bn@@ ~y o~/o @b~@s@f~@1im@o@M cl  @@~ ~-u ~ta~ @l4iof @Kdoov~ t~/~~.~~S ~@@~~~@~@~@r@~   "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    instance-of v0, p1, Lkotlinx/coroutines/channels/w;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    instance-of p1, p1, Lkotlinx/coroutines/channels/l0;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object p1, Lkotlinx/coroutines/channels/b;->f:Lkotlinx/coroutines/internal/r0;

    const/4 v2, 0x0

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p1
.end method

.method public j(Lkotlinx/coroutines/internal/y$d;)Ljava/lang/Object;
    .locals 3
    .param p1    # Lkotlinx/coroutines/internal/y$d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p1, Lkotlinx/coroutines/internal/y$d;->a:Lkotlinx/coroutines/internal/y;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast v0, Lkotlinx/coroutines/channels/l0;

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/channels/l0;->G0(Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object p1, Lkotlinx/coroutines/internal/z;->a:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lkotlinx/coroutines/internal/c;->b:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-ne p1, v0, :cond_1

    const/4 v2, 0x3

    return-object v0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p1
.end method

.method public k(Lkotlinx/coroutines/internal/y;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/internal/y;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    check-cast p1, Lkotlinx/coroutines/channels/l0;

    const/4 v0, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1}, Lkotlinx/coroutines/channels/l0;->H0()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method
