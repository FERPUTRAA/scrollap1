.class final Lkotlinx/coroutines/channels/v$x;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/v;->E(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "-TR;>;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeprecated.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Deprecated.kt\nkotlinx/coroutines/channels/ChannelsKt__DeprecatedKt$map$1\n+ 2 Channels.common.kt\nkotlinx/coroutines/channels/ChannelsKt__Channels_commonKt\n*L\n1#1,479:1\n103#2:480\n80#2,6:481\n104#2,2:487\n90#2:489\n86#2,4:490\n*S KotlinDebug\n*F\n+ 1 Deprecated.kt\nkotlinx/coroutines/channels/ChannelsKt__DeprecatedKt$map$1\n*L\n332#1:480\n332#1:481,6\n332#1:487,2\n332#1:489\n332#1:490,4\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.ChannelsKt__DeprecatedKt$map$1"
    f = "Deprecated.kt"
    i = {
        0x0,
        0x0,
        0x1,
        0x1,
        0x2,
        0x2
    }
    l = {
        0x1e7,
        0x14d,
        0x14d
    }
    m = "invokeSuspend"
    n = {
        "$this$produce",
        "$this$consume$iv$iv",
        "$this$produce",
        "$this$consume$iv$iv",
        "$this$produce",
        "$this$consume$iv$iv"
    }
    s = {
        "L$0",
        "L$2",
        "L$0",
        "L$2",
        "L$0",
        "L$2"
    }
.end annotation


# instance fields
.field final synthetic $this_map:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation
.end field

.field final synthetic $transform:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "TE;",
            "Lkotlin/coroutines/d<",
            "-TR;>;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field L$2:Ljava/lang/Object;

.field L$3:Ljava/lang/Object;

.field L$4:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/i0;Li8/p;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Li8/p<",
            "-TE;-",
            "Lkotlin/coroutines/d<",
            "-TR;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/v$x;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/channels/v$x;->$this_map:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p2, p0, Lkotlinx/coroutines/channels/v$x;->$transform:Li8/p;

    const/4 v1, 0x5

    const/4 p1, 0x5

    const/4 v1, 0x4

    const/4 p1, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Lkotlinx/coroutines/channels/v$x;

    const/4 v4, 0x3

    const/4 v3, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$x;->$this_map:Lkotlinx/coroutines/channels/i0;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v2, p0, Lkotlinx/coroutines/channels/v$x;->$transform:Li8/p;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/channels/v$x;-><init>(Lkotlinx/coroutines/channels/i0;Li8/p;Lkotlin/coroutines/d;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$x;->L$0:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x6

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$x;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 14
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x4

    iget v1, p0, Lkotlinx/coroutines/channels/v$x;->label:I

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x2

    const/4 v2, 0x0

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x7

    const/4 v3, 0x3

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x6

    const/4 v4, 0x2

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x2

    const/4 v5, 0x1

    const/4 v13, 0x2

    if-eqz v1, :cond_3

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x1

    if-eq v1, v5, :cond_2

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x6

    if-eq v1, v4, :cond_1

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x2

    if-ne v1, v3, :cond_0

    const/4 v13, 0x7

    const/4 v12, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$x;->L$3:Ljava/lang/Object;

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x1

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x5

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$x;->L$2:Ljava/lang/Object;

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x1

    check-cast v6, Lkotlinx/coroutines/channels/i0;

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x4

    iget-object v7, p0, Lkotlinx/coroutines/channels/v$x;->L$1:Ljava/lang/Object;

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x5

    check-cast v7, Li8/p;

    const/4 v13, 0x0

    const/4 v12, 0x4

    iget-object v8, p0, Lkotlinx/coroutines/channels/v$x;->L$0:Ljava/lang/Object;

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x5

    check-cast v8, Lkotlinx/coroutines/channels/g0;

    :try_start_0
    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object p1, v8

    move-object p1, v8

    move-object p1, v8

    move-object p1, v8

    move-object v8, p0

    move-object v8, p0

    move-object v8, p0

    move-object v8, p0

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x3

    goto/16 :goto_0

    :cond_0
    const/4 v13, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x4

    const-string v0, "e s /trlos elstu/an irh//efivouwkrenomiob/ eoec/ t/"

    const-string/jumbo v0, "thslcio/oroalcm/n i/kbieot uven/s /eo /werr fe/teu "

    const/4 v13, 0x0

    const-string/jumbo v0, "urmmferslatcrothi  /b iv/te//oe / o/ekcew/o /linoeu"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x7

    move v13, v12

    throw p1

    :cond_1
    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$x;->L$4:Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x0

    check-cast v1, Lkotlinx/coroutines/channels/g0;

    const/4 v12, 0x1

    or-int/2addr v13, v12

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$x;->L$3:Ljava/lang/Object;

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x4

    check-cast v6, Lkotlinx/coroutines/channels/p;

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x6

    iget-object v7, p0, Lkotlinx/coroutines/channels/v$x;->L$2:Ljava/lang/Object;

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x6

    check-cast v7, Lkotlinx/coroutines/channels/i0;

    const/4 v13, 0x7

    const/4 v12, 0x2

    iget-object v8, p0, Lkotlinx/coroutines/channels/v$x;->L$1:Ljava/lang/Object;

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x6

    check-cast v8, Li8/p;

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x1

    iget-object v9, p0, Lkotlinx/coroutines/channels/v$x;->L$0:Ljava/lang/Object;

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x6

    check-cast v9, Lkotlinx/coroutines/channels/g0;

    :try_start_1
    const/4 v12, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v10, p0

    move-object v10, p0

    move-object v10, p0

    move-object v10, p0

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x4

    goto/16 :goto_2

    :catchall_0
    move-exception p1

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x1

    goto/16 :goto_3

    :cond_2
    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$x;->L$3:Ljava/lang/Object;

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x4

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x6

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$x;->L$2:Ljava/lang/Object;

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x5

    check-cast v6, Lkotlinx/coroutines/channels/i0;

    const/4 v13, 0x4

    const/4 v12, 0x0

    iget-object v7, p0, Lkotlinx/coroutines/channels/v$x;->L$1:Ljava/lang/Object;

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x6

    check-cast v7, Li8/p;

    const/4 v13, 0x2

    const/4 v12, 0x7

    iget-object v8, p0, Lkotlinx/coroutines/channels/v$x;->L$0:Ljava/lang/Object;

    const/4 v13, 0x1

    check-cast v8, Lkotlinx/coroutines/channels/g0;

    :try_start_2
    const/4 v13, 0x7

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    move-object v9, p0

    move-object v9, p0

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x5

    goto :goto_1

    :cond_3
    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v13, 0x1

    iget-object p1, p0, Lkotlinx/coroutines/channels/v$x;->L$0:Ljava/lang/Object;

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x4

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x3

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$x;->$this_map:Lkotlinx/coroutines/channels/i0;

    const/4 v12, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$x;->$transform:Li8/p;

    :try_start_3
    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x1

    invoke-interface {v6}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v7

    move-object v8, p0

    move-object v8, p0

    move-object v8, p0

    move-object v8, p0

    move-object v11, v7

    move-object v11, v7

    move-object v11, v7

    move-object v11, v7

    move-object v7, v1

    move-object v7, v1

    move-object v7, v1

    move-object v7, v1

    move-object v1, v11

    move-object v1, v11

    move-object v1, v11

    :goto_0
    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x2

    iput-object p1, v8, Lkotlinx/coroutines/channels/v$x;->L$0:Ljava/lang/Object;

    const/4 v13, 0x0

    iput-object v7, v8, Lkotlinx/coroutines/channels/v$x;->L$1:Ljava/lang/Object;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x1

    iput-object v6, v8, Lkotlinx/coroutines/channels/v$x;->L$2:Ljava/lang/Object;

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x2

    iput-object v1, v8, Lkotlinx/coroutines/channels/v$x;->L$3:Ljava/lang/Object;

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x4

    iput v5, v8, Lkotlinx/coroutines/channels/v$x;->label:I

    const/4 v13, 0x6

    invoke-interface {v1, v8}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v9

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x3

    if-ne v9, v0, :cond_4

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x4

    return-object v0

    :cond_4
    move-object v11, v8

    move-object v11, v8

    move-object v11, v8

    move-object v11, v8

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object p1, v9

    move-object p1, v9

    move-object p1, v9

    move-object p1, v9

    move-object v9, v11

    move-object v9, v11

    move-object v9, v11

    move-object v9, v11

    :goto_1
    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x1

    check-cast p1, Ljava/lang/Boolean;

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x7

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x7

    if-eqz p1, :cond_7

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-interface {v1}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x1

    iput-object v8, v9, Lkotlinx/coroutines/channels/v$x;->L$0:Ljava/lang/Object;

    const/4 v13, 0x1

    iput-object v7, v9, Lkotlinx/coroutines/channels/v$x;->L$1:Ljava/lang/Object;

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x6

    iput-object v6, v9, Lkotlinx/coroutines/channels/v$x;->L$2:Ljava/lang/Object;

    const/4 v13, 0x5

    iput-object v1, v9, Lkotlinx/coroutines/channels/v$x;->L$3:Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v13, 0x0

    iput-object v8, v9, Lkotlinx/coroutines/channels/v$x;->L$4:Ljava/lang/Object;

    const/4 v13, 0x1

    iput v4, v9, Lkotlinx/coroutines/channels/v$x;->label:I

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-interface {v7, p1, v9}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x1

    if-ne p1, v0, :cond_5

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x6

    return-object v0

    :cond_5
    move-object v10, v9

    move-object v10, v9

    move-object v10, v9

    move-object v10, v9

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    move-object v8, v7

    move-object v7, v6

    move-object v7, v6

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    :goto_2
    :try_start_4
    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x3

    iput-object v9, v10, Lkotlinx/coroutines/channels/v$x;->L$0:Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x5

    iput-object v8, v10, Lkotlinx/coroutines/channels/v$x;->L$1:Ljava/lang/Object;

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x1

    iput-object v7, v10, Lkotlinx/coroutines/channels/v$x;->L$2:Ljava/lang/Object;

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x3

    iput-object v6, v10, Lkotlinx/coroutines/channels/v$x;->L$3:Ljava/lang/Object;

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x3

    iput-object v2, v10, Lkotlinx/coroutines/channels/v$x;->L$4:Ljava/lang/Object;

    const/4 v13, 0x2

    const/4 v12, 0x2

    iput v3, v10, Lkotlinx/coroutines/channels/v$x;->label:I

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x5

    invoke-interface {v1, p1, v10}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x2

    if-ne p1, v0, :cond_6

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x7

    return-object v0

    :cond_6
    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v7, v8

    move-object v7, v8

    move-object v7, v8

    move-object v7, v8

    move-object p1, v9

    move-object p1, v9

    move-object p1, v9

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x1

    goto/16 :goto_0

    :cond_7
    :try_start_5
    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x0

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x0

    invoke-static {v6, v2}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x5

    return-object p1

    :catchall_1
    move-exception p1

    :goto_3
    :try_start_6
    const/4 v13, 0x7

    const/4 v12, 0x6

    throw p1
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    :catchall_2
    move-exception v0

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x5

    invoke-static {v6, p1}, Lkotlinx/coroutines/channels/s;->b(Lkotlinx/coroutines/channels/i0;Ljava/lang/Throwable;)V

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x5

    throw v0
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-TR;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$x;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    check-cast p1, Lkotlinx/coroutines/channels/v$x;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/v$x;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method
