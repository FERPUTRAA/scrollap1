.class final Lkotlinx/coroutines/channels/e0$b;
.super Lkotlin/jvm/internal/n0;

# interfaces
.implements Li8/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/e0;->b(Lkotlinx/coroutines/channels/g0;Li8/a;Lkotlin/coroutines/d;ILjava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/n0;",
        "Li8/a<",
        "Lkotlin/s2;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Lkotlinx/coroutines/channels/e0$b;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Lkotlinx/coroutines/channels/e0$b;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0}, Lkotlinx/coroutines/channels/e0$b;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    sput-object v0, Lkotlinx/coroutines/channels/e0$b;->a:Lkotlinx/coroutines/channels/e0$b;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lkotlin/jvm/internal/n0;-><init>(I)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~si~~K~-o4@~b r  aMu~@@~o vc@/d@i@s / o~@l~@~oi t~l@.@ f@y @o @~S~~ mt ~@ ~1~~@~fb @bn@~@o  @~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/e0$b;->invoke()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public final invoke()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method
