.class final Lkotlinx/coroutines/channels/z$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/z;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "a"
.end annotation


# instance fields
.field public final a:Ljava/lang/Throwable;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Throwable;)V
    .locals 2
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/channels/z$a;->a:Ljava/lang/Throwable;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Throwable;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s~~~@@~~oSi~  @ou~bM b @ n~4@o c~@K~a@o@r ~.lmi    f@~t1@/@~@lbi@y@~~fd/sv   -@~t ~@~@~o~~@@o@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/channels/z$a;->a:Ljava/lang/Throwable;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v0, Lkotlinx/coroutines/channels/y;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v1, "dlwmnelas oeCh nas"

    const-string v1, "s snsaaehlel nCowd"

    const/4 v3, 0x0

    const-string v1, "sCsnooe  cllnedaah"

    const-string v1, "Channel was closed"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lkotlinx/coroutines/channels/y;-><init>(Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0
.end method

.method public final b()Ljava/lang/Throwable;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/channels/z$a;->a:Ljava/lang/Throwable;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v1, "h snableacw sCendo"

    const-string v1, "Channel was closed"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0
.end method
