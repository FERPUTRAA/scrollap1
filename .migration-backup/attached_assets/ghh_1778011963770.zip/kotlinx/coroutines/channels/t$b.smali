.class final Lkotlinx/coroutines/channels/t$b;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/t;->b(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/u0;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlinx/coroutines/channels/r<",
        "+",
        "Lkotlin/s2;",
        ">;>;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nChannels.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Channels.kt\nkotlinx/coroutines/channels/ChannelsKt__ChannelsKt$trySendBlocking$2\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,61:1\n1#2:62\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.ChannelsKt__ChannelsKt$trySendBlocking$2"
    f = "Channels.kt"
    i = {}
    l = {
        0x27
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $element:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TE;"
        }
    .end annotation
.end field

.field final synthetic $this_trySendBlocking:Lkotlinx/coroutines/channels/m0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/m0<",
            "TE;>;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/m0<",
            "-TE;>;TE;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/t$b;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lkotlinx/coroutines/channels/t$b;->$this_trySendBlocking:Lkotlinx/coroutines/channels/m0;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p2, p0, Lkotlinx/coroutines/channels/t$b;->$element:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 p1, 0x0

    const/4 p1, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v0, Lkotlinx/coroutines/channels/t$b;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/channels/t$b;->$this_trySendBlocking:Lkotlinx/coroutines/channels/m0;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v2, p0, Lkotlinx/coroutines/channels/t$b;->$element:Ljava/lang/Object;

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/channels/t$b;-><init>(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;Lkotlin/coroutines/d;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object p1, v0, Lkotlinx/coroutines/channels/t$b;->L$0:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/t$b;->invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1
.end method

.method public final invoke(Lkotlinx/coroutines/u0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/u0;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/r<",
            "Lkotlin/s2;",
            ">;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/t$b;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    check-cast p1, Lkotlinx/coroutines/channels/t$b;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/t$b;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v1, p0, Lkotlinx/coroutines/channels/t$b;->label:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-ne v1, v2, :cond_0

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v0, "ohs//is/trn e/  n otvlcireouwfemsecotbkua/ /i/rloe "

    const-string v0, "nts//eok  / btarr /o/vhmcoenefu/ ti i/eeorliusolwc/"

    const/4 v5, 0x5

    const-string v0, "ehfm/itec loo// m/ k/eo uoaeeule nirt/snowri/c/rt b"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    throw p1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object p1, p0, Lkotlinx/coroutines/channels/t$b;->L$0:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    check-cast p1, Lkotlinx/coroutines/u0;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object p1, p0, Lkotlinx/coroutines/channels/t$b;->$this_trySendBlocking:Lkotlinx/coroutines/channels/m0;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/channels/t$b;->$element:Ljava/lang/Object;

    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    sget-object v3, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    iput v2, p0, Lkotlinx/coroutines/channels/t$b;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {p1, v1, p0}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-ne p1, v0, :cond_2

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-object v0

    :cond_2
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p1}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    sget-object v0, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {p1}, Lkotlin/e1;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p1}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {p1}, Lkotlin/d1;->j(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v0, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    sget-object p1, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v5, 0x2

    const/4 v4, 0x4

    sget-object v0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Lkotlinx/coroutines/channels/r$b;->c(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_2

    :cond_3
    const/4 v4, 0x6

    const/4 v5, 0x7

    sget-object v0, Lkotlinx/coroutines/channels/r;->b:Lkotlinx/coroutines/channels/r$b;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p1}, Lkotlin/d1;->e(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/channels/r$b;->a(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    :goto_2
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p1}, Lkotlinx/coroutines/channels/r;->b(Ljava/lang/Object;)Lkotlinx/coroutines/channels/r;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-object p1
.end method
