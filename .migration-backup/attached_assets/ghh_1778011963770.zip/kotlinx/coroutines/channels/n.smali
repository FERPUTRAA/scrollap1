.class public interface abstract Lkotlinx/coroutines/channels/n;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/channels/m0;
.implements Lkotlinx/coroutines/channels/i0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/channels/n$b;,
        Lkotlinx/coroutines/channels/n$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlinx/coroutines/channels/m0<",
        "TE;>;",
        "Lkotlinx/coroutines/channels/i0<",
        "TE;>;"
    }
.end annotation


# static fields
.field public static final o0:Lkotlinx/coroutines/channels/n$b;
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final p0:I = 0x7fffffff

.field public static final q0:I = 0x0

.field public static final r0:I = -0x1

.field public static final s0:I = -0x2

.field public static final t0:I = -0x3

.field public static final u0:Ljava/lang/String; = "kotlinx.coroutines.channels.defaultBuffer"
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lkotlinx/coroutines/channels/n$b;->a:Lkotlinx/coroutines/channels/n$b;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    sput-object v0, Lkotlinx/coroutines/channels/n;->o0:Lkotlinx/coroutines/channels/n$b;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method
