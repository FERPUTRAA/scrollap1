.class final Lkotlinx/coroutines/channels/l$c;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/l;->b(Lkotlinx/coroutines/channels/i0;ILkotlinx/coroutines/w0;)Lkotlinx/coroutines/channels/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "-TE;>;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.BroadcastKt$broadcast$2"
    f = "Broadcast.kt"
    i = {
        0x0,
        0x1
    }
    l = {
        0x35,
        0x36
    }
    m = "invokeSuspend"
    n = {
        "$this$broadcast",
        "$this$broadcast"
    }
    s = {
        "L$0",
        "L$0"
    }
.end annotation


# instance fields
.field final synthetic $this_broadcast:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "TE;>;"
        }
    .end annotation
.end field

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/i0<",
            "+TE;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/l$c;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lkotlinx/coroutines/channels/l$c;->$this_broadcast:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Lkotlinx/coroutines/channels/l$c;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/l$c;->$this_broadcast:Lkotlinx/coroutines/channels/i0;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0, v1, p2}, Lkotlinx/coroutines/channels/l$c;-><init>(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object p1, v0, Lkotlinx/coroutines/channels/l$c;->L$0:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/l$c;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x6

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    iget v1, p0, Lkotlinx/coroutines/channels/l$c;->label:I

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v2, 0x2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v3, 0x1

    or-int/2addr v8, v3

    const/4 v7, 0x1

    move v8, v7

    if-eqz v1, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eq v1, v3, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-ne v1, v2, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/channels/l$c;->L$1:Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget-object v4, p0, Lkotlinx/coroutines/channels/l$c;->L$0:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    check-cast v4, Lkotlinx/coroutines/channels/g0;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v7, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string v0, "/tse noera/er wkcfote/irt csieuluso no/b/ meohiv/l/"

    const-string/jumbo v0, "tcsiretveileimeol/oo//t/h/boe/  au ukns fn/ercw or "

    const/4 v8, 0x4

    const-string v0, "lekmrronto hwoi///fea  /eivceeueimbc un/l sort ///t"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    throw p1

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/channels/l$c;->L$1:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v4, p0, Lkotlinx/coroutines/channels/l$c;->L$0:Ljava/lang/Object;

    const/4 v8, 0x6

    check-cast v4, Lkotlinx/coroutines/channels/g0;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_2

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x0

    iget-object p1, p0, Lkotlinx/coroutines/channels/l$c;->L$0:Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/channels/l$c;->$this_broadcast:Lkotlinx/coroutines/channels/i0;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-interface {v1}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v1

    :goto_0
    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    :goto_1
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    iput-object p1, v4, Lkotlinx/coroutines/channels/l$c;->L$0:Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    iput-object v1, v4, Lkotlinx/coroutines/channels/l$c;->L$1:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    iput v3, v4, Lkotlinx/coroutines/channels/l$c;->label:I

    invoke-interface {v1, v4}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-ne v5, v0, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x3

    return-object v0

    :cond_3
    move-object v6, v4

    move-object v6, v4

    move-object v6, v4

    move-object v6, v4

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    :goto_2
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    check-cast p1, Ljava/lang/Boolean;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    if-eqz p1, :cond_5

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-interface {v1}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    iput-object v4, v5, Lkotlinx/coroutines/channels/l$c;->L$0:Ljava/lang/Object;

    const/4 v8, 0x2

    iput-object v1, v5, Lkotlinx/coroutines/channels/l$c;->L$1:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v8, 0x3

    iput v2, v5, Lkotlinx/coroutines/channels/l$c;->label:I

    const/4 v8, 0x4

    invoke-interface {v4, p1, v5}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-ne p1, v0, :cond_4

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    return-object v0

    :cond_4
    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object v4, v5

    move-object v4, v5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    goto :goto_1

    :cond_5
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    return-object p1
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "-TE;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/l$c;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    check-cast p1, Lkotlinx/coroutines/channels/l$c;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/l$c;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method
