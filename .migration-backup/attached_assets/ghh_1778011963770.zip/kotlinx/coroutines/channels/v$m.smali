.class final Lkotlinx/coroutines/channels/v$m;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/v;->r(Lkotlinx/coroutines/channels/i0;Lkotlin/coroutines/g;Li8/p;)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Ljava/lang/Object;",
        "Lkotlin/coroutines/d<",
        "-",
        "Ljava/lang/Boolean;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.ChannelsKt__DeprecatedKt$filterNot$1"
    f = "Deprecated.kt"
    i = {}
    l = {
        0xde
    }
    m = "invokeSuspend"
    n = {}
    s = {}
.end annotation


# instance fields
.field final synthetic $predicate:Li8/p;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/p<",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field synthetic L$0:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(Li8/p;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/p<",
            "Ljava/lang/Object;",
            "-",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/v$m;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lkotlinx/coroutines/channels/v$m;->$predicate:Li8/p;

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Lkotlinx/coroutines/channels/v$m;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$m;->$predicate:Li8/p;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0, v1, p2}, Lkotlinx/coroutines/channels/v$m;-><init>(Li8/p;Lkotlin/coroutines/d;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$m;->L$0:Ljava/lang/Object;

    const/4 v3, 0x4

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$m;->k(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v1, p0, Lkotlinx/coroutines/channels/v$m;->label:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-ne v1, v2, :cond_0

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v0, "ems/ iooek wt/cosl/eeb vtrainrr/e/et/ hu/ cflno/iou"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    throw p1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/channels/v$m;->L$0:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$m;->$predicate:Li8/p;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput v2, p0, Lkotlinx/coroutines/channels/v$m;->label:I

    const/4 v3, 0x3

    move v4, v3

    invoke-interface {v1, p1, p0}, Li8/p;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-ne p1, v0, :cond_2

    const/4 v4, 0x6

    return-object v0

    :cond_2
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    check-cast p1, Ljava/lang/Boolean;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    xor-int/2addr p1, v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p1}, Lkotlin/coroutines/jvm/internal/b;->a(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    return-object p1
.end method

.method public final k(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$m;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    check-cast p1, Lkotlinx/coroutines/channels/v$m;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/v$m;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p1
.end method
