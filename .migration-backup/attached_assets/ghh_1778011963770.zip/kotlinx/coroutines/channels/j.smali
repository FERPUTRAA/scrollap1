.class public final Lkotlinx/coroutines/channels/j;
.super Ljava/lang/Object;


# direct methods
.method public static final a(I)Lkotlinx/coroutines/channels/i;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(I)",
            "Lkotlinx/coroutines/channels/i<",
            "TE;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlinx/coroutines/e3;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, -0x2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eq p0, v0, :cond_3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eq p0, v0, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz p0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const v0, 0x7fffffff

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eq p0, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Lkotlinx/coroutines/channels/g;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lkotlinx/coroutines/channels/g;-><init>(I)V

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x1

    const-string v0, "p soIasssteefrDTiahrUInMyNpUoc rauCtc apBdL ndlEcao"

    const-string v0, "ansfpsUcyBEtd spe uloaLnorMIhc dainecICt DpNaaroTUr"

    const/4 v2, 0x1

    const-string v0, "nctmden iUrthooyrBosafcdIaaELctaU Me r CDTIpulNpapn"

    const-string v0, "Unsupported UNLIMITED capacity for BroadcastChannel"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    throw p0

    :cond_1
    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "aoueonfB r d ceUrtis csaholadoCpr0ntcnppaya"

    const-string v0, "Unsupported 0 capacity for BroadcastChannel"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    throw p0

    :cond_2
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance v0, Lkotlinx/coroutines/channels/z;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {v0}, Lkotlinx/coroutines/channels/z;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_3
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Lkotlinx/coroutines/channels/g;

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object p0, Lkotlinx/coroutines/channels/n;->o0:Lkotlinx/coroutines/channels/n$b;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/channels/n$b;->a()I

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lkotlinx/coroutines/channels/g;-><init>(I)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method
