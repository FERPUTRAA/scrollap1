.class public final Lkotlinx/coroutines/channels/c$d;
.super Lkotlinx/coroutines/internal/y$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1c
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<E:",
        "Ljava/lang/Object;",
        ">",
        "Lkotlinx/coroutines/internal/y$e<",
        "Lkotlinx/coroutines/channels/j0<",
        "-TE;>;>;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAbstractChannel.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AbstractChannel.kt\nkotlinx/coroutines/channels/AbstractSendChannel$TryOfferDesc\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1132:1\n1#2:1133\n*E\n"
.end annotation


# instance fields
.field public final e:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TE;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Object;Lkotlinx/coroutines/internal/w;)V
    .locals 2
    .param p2    # Lkotlinx/coroutines/internal/w;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TE;",
            "Lkotlinx/coroutines/internal/w;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0, p2}, Lkotlinx/coroutines/internal/y$e;-><init>(Lkotlinx/coroutines/internal/y;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    iput-object p1, p0, Lkotlinx/coroutines/channels/c$d;->e:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected e(Lkotlinx/coroutines/internal/y;)Ljava/lang/Object;
    .locals 3
    .param p1    # Lkotlinx/coroutines/internal/y;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " bs@~~@@l~~~ ~  f~M~@ @~~d~@ c~   to@~a ~~@@~r.o/u@ol-K~@o @ ii nsi@1@@ @~~~bb @~m@vfy/ 4@oS~t o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    instance-of v0, p1, Lkotlinx/coroutines/channels/w;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    instance-of p1, p1, Lkotlinx/coroutines/channels/j0;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez p1, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object p1, Lkotlinx/coroutines/channels/b;->e:Lkotlinx/coroutines/internal/r0;

    const/4 v2, 0x5

    goto :goto_0

    :cond_1
    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method public j(Lkotlinx/coroutines/internal/y$d;)Ljava/lang/Object;
    .locals 4
    .param p1    # Lkotlinx/coroutines/internal/y$d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p1, Lkotlinx/coroutines/internal/y$d;->a:Lkotlinx/coroutines/internal/y;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast v0, Lkotlinx/coroutines/channels/j0;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Lkotlinx/coroutines/channels/c$d;->e:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v0, v1, p1}, Lkotlinx/coroutines/channels/j0;->X(Ljava/lang/Object;Lkotlinx/coroutines/internal/y$d;)Lkotlinx/coroutines/internal/r0;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object p1, Lkotlinx/coroutines/internal/z;->a:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    sget-object v0, Lkotlinx/coroutines/internal/c;->b:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-ne p1, v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p1
.end method
