.class public final Lkotlinx/coroutines/channels/i$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/channels/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static synthetic a(Lkotlinx/coroutines/channels/i;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    if-nez p3, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    if-eqz p2, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    const/4 p1, 0x0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/i;->cancel(Ljava/util/concurrent/CancellationException;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const-string/jumbo p1, "tgsuetco h tlu:  c saftrnit dneottpas an uehaslaSfrpe, ncsdrlnnluwcip oseu iemirg"

    const-string/jumbo p1, "uasse fltnnu:ntlpttr ieuelafgS,g  ntmtssco spoeaiirr lna   etwcpac hitocre undudh"

    const/4 v1, 0x7

    const-string p1, "t  muesln  gatsacaou tcftsdlhtitesSr   uiprc nllthioaenep ogtpr:unnr a,efumwnctei"

    const-string p1, "Super calls with default arguments not supported in this target, function: cancel"

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    throw p0
.end method

.method public static synthetic b(Lkotlinx/coroutines/channels/i;Ljava/lang/Throwable;ILjava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-nez p3, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    and-int/lit8 p2, p2, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-eqz p2, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 p1, 0x0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/i;->cancel(Ljava/lang/Throwable;)Z

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return p0

    :cond_1
    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    const-string p1, "arproet taonne an:cdls olnrtauipmnl i rhnioSs gettg ich,pdesc mu tu tffetuetulc a"

    const-string p1, "pdom ip:tnlg cmashafnoueul trenftacch,seueawSasuutc prgntd  t eir i trlol tnn eit"

    const/4 v1, 0x6

    const-string/jumbo p1, "tr tebhgieio udmilnohf  rc tcstaenna tuunerw  satoecntd  up ltprf,aaipstcgn:sSuel"

    const-string p1, "Super calls with default arguments not supported in this target, function: cancel"

    const/4 v0, 0x0

    move v1, v0

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    throw p0
.end method

.method public static c(Lkotlinx/coroutines/channels/i;Ljava/lang/Object;)Z
    .locals 2
    .param p0    # Lkotlinx/coroutines/channels/i;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlinx/coroutines/channels/i<",
            "TE;>;TE;)Z"
        }
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated in the favour of \'trySend\' method"
        replaceWith = .subannotation Lkotlin/b1;
            expression = "trySend(element).isSuccess"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lkotlinx/coroutines/channels/m0$a;->c(Lkotlinx/coroutines/channels/m0;Ljava/lang/Object;)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return p0
.end method
