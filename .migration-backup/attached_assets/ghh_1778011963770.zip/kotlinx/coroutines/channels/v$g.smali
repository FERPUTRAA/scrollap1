.class final Lkotlinx/coroutines/channels/v$g;
.super Lkotlin/coroutines/jvm/internal/o;

# interfaces
.implements Li8/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lkotlinx/coroutines/channels/v;->h(Lkotlinx/coroutines/channels/i0;ILkotlin/coroutines/g;)Lkotlinx/coroutines/channels/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/o;",
        "Li8/p<",
        "Lkotlinx/coroutines/channels/g0<",
        "Ljava/lang/Object;",
        ">;",
        "Lkotlin/coroutines/d<",
        "-",
        "Lkotlin/s2;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeprecated.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Deprecated.kt\nkotlinx/coroutines/channels/ChannelsKt__DeprecatedKt$drop$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,479:1\n1#2:480\n*E\n"
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/f;
    c = "kotlinx.coroutines.channels.ChannelsKt__DeprecatedKt$drop$1"
    f = "Deprecated.kt"
    i = {
        0x0,
        0x0,
        0x1,
        0x2
    }
    l = {
        0xa4,
        0xa9,
        0xaa
    }
    m = "invokeSuspend"
    n = {
        "$this$produce",
        "remaining",
        "$this$produce",
        "$this$produce"
    }
    s = {
        "L$0",
        "I$0",
        "L$0",
        "L$0"
    }
.end annotation


# instance fields
.field final synthetic $n:I

.field final synthetic $this_drop:Lkotlinx/coroutines/channels/i0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field I$0:I

.field private synthetic L$0:Ljava/lang/Object;

.field L$1:Ljava/lang/Object;

.field label:I


# direct methods
.method constructor <init>(ILkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lkotlinx/coroutines/channels/i0<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlinx/coroutines/channels/v$g;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p1, p0, Lkotlinx/coroutines/channels/v$g;->$n:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p2, p0, Lkotlinx/coroutines/channels/v$g;->$this_drop:Lkotlinx/coroutines/channels/i0;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p1, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/o;-><init>(ILkotlin/coroutines/d;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/d<",
            "*>;)",
            "Lkotlin/coroutines/d<",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v0, Lkotlinx/coroutines/channels/v$g;

    const/4 v3, 0x0

    const/4 v3, 0x2

    iget v1, p0, Lkotlinx/coroutines/channels/v$g;->$n:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v2, p0, Lkotlinx/coroutines/channels/v$g;->$this_drop:Lkotlinx/coroutines/channels/i0;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2, p2}, Lkotlinx/coroutines/channels/v$g;-><init>(ILkotlinx/coroutines/channels/i0;Lkotlin/coroutines/d;)V

    const/4 v4, 0x4

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$g;->L$0:Ljava/lang/Object;

    const/4 v4, 0x7

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    check-cast p2, Lkotlin/coroutines/d;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$g;->k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 11
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/e;
    .end annotation

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget v1, p0, Lkotlinx/coroutines/channels/v$g;->label:I

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v2, 0x3

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    const/4 v3, 0x2

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    const/4 v4, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz v1, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-eq v1, v4, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-eq v1, v3, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    if-ne v1, v2, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$g;->L$1:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v4, p0, Lkotlinx/coroutines/channels/v$g;->L$0:Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    check-cast v4, Lkotlinx/coroutines/channels/g0;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v10, 0x2

    const/4 v9, 0x2

    goto/16 :goto_5

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-string v0, "fesc/i/te t/brilou n iho//vle ner a /o/uwoksrtc/eoe"

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v10, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    throw p1

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/channels/v$g;->L$1:Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    check-cast v1, Lkotlinx/coroutines/channels/p;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-object v4, p0, Lkotlinx/coroutines/channels/v$g;->L$0:Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    check-cast v4, Lkotlinx/coroutines/channels/g0;

    const/4 v10, 0x1

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v4, v1

    move-object v4, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    goto/16 :goto_6

    :cond_2
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget v1, p0, Lkotlinx/coroutines/channels/v$g;->I$0:I

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$g;->L$1:Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x5

    check-cast v5, Lkotlinx/coroutines/channels/p;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-object v6, p0, Lkotlinx/coroutines/channels/v$g;->L$0:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    check-cast v6, Lkotlinx/coroutines/channels/g0;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object v7, v6

    move-object v7, v6

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    move v5, v1

    move v5, v1

    const/4 v10, 0x6

    move v5, v1

    move v5, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    goto/16 :goto_2

    :cond_3
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/channels/v$g;->L$0:Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    check-cast p1, Lkotlinx/coroutines/channels/g0;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget v1, p0, Lkotlinx/coroutines/channels/v$g;->$n:I

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-ltz v1, :cond_4

    const/4 v10, 0x3

    move v5, v4

    const/4 v10, 0x3

    move v5, v4

    move v5, v4

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    goto :goto_0

    :cond_4
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/4 v5, 0x0

    :goto_0
    const/4 v9, 0x5

    const/4 v10, 0x0

    if-eqz v5, :cond_c

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-lez v1, :cond_8

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget-object v5, p0, Lkotlinx/coroutines/channels/v$g;->$this_drop:Lkotlinx/coroutines/channels/i0;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {v5}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v5

    move-object v6, p1

    move-object v6, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    iput-object v6, p1, Lkotlinx/coroutines/channels/v$g;->L$0:Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    iput-object v5, p1, Lkotlinx/coroutines/channels/v$g;->L$1:Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    iput v1, p1, Lkotlinx/coroutines/channels/v$g;->I$0:I

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    iput v4, p1, Lkotlinx/coroutines/channels/v$g;->label:I

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-interface {v5, p1}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v7

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-ne v7, v0, :cond_5

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    return-object v0

    :cond_5
    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v8, v0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    move v5, v1

    move v5, v1

    const/4 v10, 0x1

    move v5, v1

    move v5, v1

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    :goto_2
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    check-cast p1, Ljava/lang/Boolean;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    if-eqz p1, :cond_7

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-interface {v6}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    add-int/lit8 p1, v5, -0x1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-nez p1, :cond_6

    const/4 v10, 0x3

    goto :goto_3

    :cond_6
    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    move v1, p1

    const/4 v10, 0x5

    move v1, p1

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    goto/16 :goto_1

    :cond_7
    :goto_3
    move-object p1, v7

    move-object p1, v7

    move-object p1, v7

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto :goto_4

    :cond_8
    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :goto_4
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v4, v0, Lkotlinx/coroutines/channels/v$g;->$this_drop:Lkotlinx/coroutines/channels/i0;

    const/4 v10, 0x1

    invoke-interface {v4}, Lkotlinx/coroutines/channels/i0;->iterator()Lkotlinx/coroutines/channels/p;

    move-result-object v4

    :goto_5
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    iput-object p1, v0, Lkotlinx/coroutines/channels/v$g;->L$0:Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    iput-object v4, v0, Lkotlinx/coroutines/channels/v$g;->L$1:Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    iput v3, v0, Lkotlinx/coroutines/channels/v$g;->label:I

    const/4 v10, 0x6

    invoke-interface {v4, v0}, Lkotlinx/coroutines/channels/p;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v5

    const/4 v10, 0x5

    const/4 v9, 0x6

    if-ne v5, v1, :cond_9

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    return-object v1

    :cond_9
    move-object v8, v5

    move-object v8, v5

    move-object v8, v5

    move-object v8, v5

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object p1, v8

    move-object p1, v8

    move-object p1, v8

    move-object p1, v8

    :goto_6
    const/4 v10, 0x2

    const/4 v9, 0x0

    check-cast p1, Ljava/lang/Boolean;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    if-eqz p1, :cond_b

    const/4 v10, 0x0

    const/4 v9, 0x3

    invoke-interface {v4}, Lkotlinx/coroutines/channels/p;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x7

    iput-object v5, v0, Lkotlinx/coroutines/channels/v$g;->L$0:Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    iput-object v4, v0, Lkotlinx/coroutines/channels/v$g;->L$1:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    iput v2, v0, Lkotlinx/coroutines/channels/v$g;->label:I

    const/4 v10, 0x4

    invoke-interface {v5, p1, v0}, Lkotlinx/coroutines/channels/m0;->D(Ljava/lang/Object;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-ne p1, v1, :cond_a

    const/4 v9, 0x2

    shr-int/2addr v10, v9

    return-object v1

    :cond_a
    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    move-object p1, v5

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto :goto_5

    :cond_b
    const/4 v9, 0x3

    move v10, v9

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    return-object p1

    :cond_c
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    const-string/jumbo v0, "u emu etenRtsecemoeqdls "

    const-string v0, "qRstelt  csuutodemeeen e"

    const/4 v10, 0x4

    const-string/jumbo v0, "teeno telnR soe dqtucume"

    const-string v0, "Requested element count "

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const-string v0, "nm iebs.s rl ahe zo"

    const-string v0, " ssm nlzs. e irehoa"

    const/4 v10, 0x0

    const-string v0, "sest.au ieh  lzro s"

    const-string v0, " is less than zero."

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    throw v0
.end method

.method public final k(Lkotlinx/coroutines/channels/g0;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p1    # Lkotlinx/coroutines/channels/g0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Lkotlin/coroutines/d;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/channels/g0<",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/channels/v$g;->create(Ljava/lang/Object;Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    check-cast p1, Lkotlinx/coroutines/channels/v$g;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    sget-object p2, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-virtual {p1, p2}, Lkotlinx/coroutines/channels/v$g;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p1
.end method
