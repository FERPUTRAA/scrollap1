.class public final Lkotlinx/coroutines/b1;
.super Ljava/lang/Object;


# static fields
.field private static final a:Z

.field private static final b:Lkotlinx/coroutines/e1;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v0, "t.smiotci.aiollde.kronysnuxea"

    const-string v0, ".asdmnelsanliixo.tryotcu.ieko"

    const-string v0, "li.mtlmnra.kennaosucodoiieyx."

    const-string v0, "kotlinx.coroutines.main.delay"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lkotlinx/coroutines/internal/t0;->e(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    sput-boolean v0, Lkotlinx/coroutines/b1;->a:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {}, Lkotlinx/coroutines/b1;->b()Lkotlinx/coroutines/e1;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    sput-object v0, Lkotlinx/coroutines/b1;->b:Lkotlinx/coroutines/e1;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method public static final a()Lkotlinx/coroutines/e1;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@.1@o@ b~@ b ~@~f ~~@@yol  ~ -/o@r@@@~~@ocsi~a o~~t/@v@ot~ mS~u  ~~~~~ n@~~b @~ lfd@o  4K~@@M@ii"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lkotlinx/coroutines/b1;->b:Lkotlinx/coroutines/e1;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method private static final b()Lkotlinx/coroutines/e1;
    .locals 4

    const/4 v2, 0x5

    move v3, v2

    sget-boolean v0, Lkotlinx/coroutines/b1;->a:Z

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object v0, Lkotlinx/coroutines/a1;->g:Lkotlinx/coroutines/a1;

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-static {}, Lkotlinx/coroutines/m1;->e()Lkotlinx/coroutines/z2;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0}, Lkotlinx/coroutines/internal/f0;->d(Lkotlinx/coroutines/z2;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez v1, :cond_2

    const/4 v2, 0x1

    move v3, v2

    instance-of v1, v0, Lkotlinx/coroutines/e1;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Lkotlinx/coroutines/e1;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    sget-object v0, Lkotlinx/coroutines/a1;->g:Lkotlinx/coroutines/a1;

    :goto_1
    const/4 v3, 0x0

    return-object v0
.end method
