.class public final Lkotlinx/coroutines/f0;
.super Ljava/lang/Object;


# instance fields
.field public final a:Ljava/lang/Object;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public final b:Li8/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/l<",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Object;Li8/l;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Li8/l<",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/f0;->a:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p2, p0, Lkotlinx/coroutines/f0;->b:Li8/l;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public static synthetic d(Lkotlinx/coroutines/f0;Ljava/lang/Object;Li8/l;ILjava/lang/Object;)Lkotlinx/coroutines/f0;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    and-int/lit8 p4, p3, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-eqz p4, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget-object p1, p0, Lkotlinx/coroutines/f0;->a:Ljava/lang/Object;

    :cond_0
    const/4 v1, 0x5

    and-int/lit8 p3, p3, 0x2

    const/4 v1, 0x4

    if-eqz p3, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget-object p2, p0, Lkotlinx/coroutines/f0;->b:Li8/l;

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lkotlinx/coroutines/f0;->c(Ljava/lang/Object;Li8/l;)Lkotlinx/coroutines/f0;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Lkotlinx/coroutines/f0;->a:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public final b()Li8/l;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Li8/l<",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/f0;->b:Li8/l;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public final c(Ljava/lang/Object;Li8/l;)Lkotlinx/coroutines/f0;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Li8/l<",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;)",
            "Lkotlinx/coroutines/f0;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Lkotlinx/coroutines/f0;

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-direct {v0, p1, p2}, Lkotlinx/coroutines/f0;-><init>(Ljava/lang/Object;Li8/l;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-ne p0, p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    return v0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    instance-of v1, p1, Lkotlinx/coroutines/f0;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x4

    if-nez v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    return v2

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    check-cast p1, Lkotlinx/coroutines/f0;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/f0;->a:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v3, p1, Lkotlinx/coroutines/f0;->a:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x4

    return v2

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/f0;->b:Li8/l;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object p1, p1, Lkotlinx/coroutines/f0;->b:Li8/l;

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v1, p1}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez p1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    return v2

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    return v0
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/f0;->a:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    mul-int/lit8 v0, v0, 0x1f

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/f0;->b:Li8/l;

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    add-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    move v3, v2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v1, "C=scteiolmsopreaWlh(unaetitlCldte"

    const-string v1, "CompletedWithCancellation(result="

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lkotlinx/coroutines/f0;->a:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v1, "eo=mi ca,anltsCon"

    const-string v1, "olsl=ntciC ,aaone"

    const/4 v3, 0x0

    const-string v1, "nioCoe=lcnatoln,a"

    const-string v1, ", onCancellation="

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/f0;->b:Li8/l;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/16 v1, 0x29

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    return-object v0
.end method
