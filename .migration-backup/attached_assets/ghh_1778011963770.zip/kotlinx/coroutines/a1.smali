.class public final Lkotlinx/coroutines/a1;
.super Lkotlinx/coroutines/u1;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDefaultExecutor.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DefaultExecutor.kt\nkotlinx/coroutines/DefaultExecutor\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,186:1\n1#2:187\n*E\n"
.end annotation


# static fields
.field private static volatile _thread:Ljava/lang/Thread; = null
    .annotation build Lia/e;
    .end annotation
.end field

.field private static volatile debugStatus:I = 0x0

.field public static final g:Lkotlinx/coroutines/a1;
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final h:Ljava/lang/String; = "kotlinx.coroutines.DefaultExecutor"
    .annotation build Lia/d;
    .end annotation
.end field

.field private static final i:J = 0x3e8L

.field private static final j:J

.field private static final k:I = 0x0

.field private static final l:I = 0x1

.field private static final m:I = 0x2

.field private static final n:I = 0x3

.field private static final o:I = 0x4


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v0, Lkotlinx/coroutines/a1;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {v0}, Lkotlinx/coroutines/a1;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    sput-object v0, Lkotlinx/coroutines/a1;->g:Lkotlinx/coroutines/a1;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0, v3, v1, v2}, Lkotlinx/coroutines/t1;->Q0(Lkotlinx/coroutines/t1;ZILjava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-wide/16 v1, 0x3e8

    const-wide/16 v1, 0x3e8

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v3, "..stu.xifeoclcanepsiEiutrlvosoxnDeeeAeuklktt"

    const-string v3, "issevcaokteo.rDiefliupln.AututonEocxeetlx.ek"

    const/4 v5, 0x6

    const-string v3, "kotlinx.coroutines.DefaultExecutor.keepAlive"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v3, v1, v2}, Ljava/lang/Long;->getLong(Ljava/lang/String;J)Ljava/lang/Long;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :catch_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/TimeUnit;->toNanos(J)J

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    sput-wide v0, Lkotlinx/coroutines/a1;->j:J

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Lkotlinx/coroutines/u1;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method private final declared-synchronized Q1()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->b2()Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x3

    :try_start_1
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    sput v0, Lkotlinx/coroutines/a1;->debugStatus:I

    const/4 v2, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/u1;->C1()V

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v1, 0x2

    move v2, v1

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    throw v0
.end method

.method private final declared-synchronized T1()Ljava/lang/Thread;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v0, Lkotlinx/coroutines/a1;->_thread:Ljava/lang/Thread;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/Thread;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string v1, "euamofrxEnkuuiri.mttoec.tsnleoDtxc"

    const-string/jumbo v1, "xxemetDuarofntlsrotliuc.tEkceiou.n"

    const/4 v3, 0x3

    const-string/jumbo v1, "xotxorecloftucenaEkno.itelisr.ouut"

    const-string v1, "kotlinx.coroutines.DefaultExecutor"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0, p0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    sput-object v0, Lkotlinx/coroutines/a1;->_thread:Ljava/lang/Thread;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setDaemon(Z)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw v0
.end method

.method private static synthetic X1()V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method private final Y1()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget v0, Lkotlinx/coroutines/a1;->debugStatus:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return v0
.end method

.method private final b2()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    sget v0, Lkotlinx/coroutines/a1;->debugStatus:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x6

    if-eq v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v1, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    return v0
.end method

.method private final declared-synchronized i2()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->b2()Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v1, 0x0

    and-int/2addr v2, v1

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    return v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x1

    :try_start_1
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    sput v0, Lkotlinx/coroutines/a1;->debugStatus:I

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/Object;->notifyAll()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v1, 0x6

    move v2, v1

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    throw v0
.end method

.method private final k2()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Ljava/util/concurrent/RejectedExecutionException;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const-string v1, "am .tbn,awueseot ahtds tcoitconostp fa t.ps  rs(tDnlerntDcf tnh. on) Edriiaiodeap wioh.do tshec vr Dessfud eo otooeeto m shenh raiuirhdnemus ci ottr  aiu Psxneofgnieipceanirvllaproonmlureto gieiwxotcrcklsetielsTns toiurasdi oouew sewetrtca rt"

    const-string v1, "t(onocfrxee eePshtrifgpsw.nart foimht o vicD,   rl  rhacpssaaoocwtnsoaxD)erDii ice poseps dhtceheuinEnlpogo lnctteniacTiulhs e oudeta.tdwctdsimsnftrrt l eddessa ootr  u tsewt ikonrsr e.e taidoirw  nunmuvi eahaorul otosrettiuotmnste.aoo nneoii"

    const/4 v3, 0x3

    const-string v1, "DeeTaputin elr,omot uioifr w p i twurdei.sooEindte rtewtoxrvpdo D ofitstimePso klienegcoc on ioior n to)omealhcrlaenwidene.eeecnhdts auttDoh.cso ssaisate eoetmisc  rr uaiur re e tot csshulsonn xtauloicatitpdsnrwpastadfnhg(vcurthats  nn.fse hr"

    const-string v1, "DefaultExecutor was shut down. This error indicates that Dispatchers.shutdown() was invoked prior to completion of exiting coroutines, leaving coroutines in incomplete state. Please refer to Dispatchers.shutdown documentation for more details"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/util/concurrent/RejectedExecutionException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    and-int/2addr v3, v2

    throw v0
.end method


# virtual methods
.method public final declared-synchronized U1()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    monitor-enter p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    sput v0, Lkotlinx/coroutines/a1;->debugStatus:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->T1()Ljava/lang/Thread;

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget v0, Lkotlinx/coroutines/a1;->debugStatus:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->wait()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    move v2, v1

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    throw v0
.end method

.method protected e1()Ljava/lang/Thread;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget-object v0, Lkotlinx/coroutines/a1;->_thread:Ljava/lang/Thread;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->T1()Ljava/lang/Thread;

    move-result-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public final f2()Z
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lkotlinx/coroutines/a1;->_thread:Ljava/lang/Thread;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method protected i1(JLkotlinx/coroutines/u1$c;)V
    .locals 2
    .param p3    # Lkotlinx/coroutines/u1$c;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->k2()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public l(JLjava/lang/Runnable;Lkotlin/coroutines/g;)Lkotlinx/coroutines/p1;
    .locals 2
    .param p3    # Ljava/lang/Runnable;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2, p3}, Lkotlinx/coroutines/u1;->I1(JLjava/lang/Runnable;)Lkotlinx/coroutines/p1;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p1
.end method

.method public final declared-synchronized l2(J)V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    add-long/2addr v0, p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->b2()Z

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x4

    if-nez v2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v2, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    sput v2, Lkotlinx/coroutines/a1;->debugStatus:I

    :cond_0
    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget v2, Lkotlinx/coroutines/a1;->debugStatus:I

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x3

    move v7, v3

    const/4 v6, 0x0

    move v7, v6

    if-eq v2, v3, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    sget-object v2, Lkotlinx/coroutines/a1;->_thread:Ljava/lang/Thread;

    const/4 v7, 0x1

    if-eqz v2, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    sget-object v2, Lkotlinx/coroutines/a1;->_thread:Ljava/lang/Thread;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz v2, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {}, Lkotlinx/coroutines/c;->b()Lkotlinx/coroutines/b;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz v3, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v3, v2}, Lkotlinx/coroutines/b;->g(Ljava/lang/Thread;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    sget-object v3, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    goto :goto_1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/4 v3, 0x0

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-nez v3, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v2}, Ljava/util/concurrent/locks/LockSupport;->unpark(Ljava/lang/Thread;)V

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    sub-long v2, v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    cmp-long v2, v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-lez v2, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p0, p1, p2}, Ljava/lang/Object;->wait(J)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto :goto_0

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/4 p1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    sput p1, Lkotlinx/coroutines/a1;->debugStatus:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x4

    monitor-exit p0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    monitor-exit p0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    throw p1
.end method

.method public run()V
    .locals 14

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x7

    sget-object v0, Lkotlinx/coroutines/u3;->a:Lkotlinx/coroutines/u3;

    const/4 v13, 0x1

    const/4 v12, 0x6

    invoke-virtual {v0, p0}, Lkotlinx/coroutines/u3;->d(Lkotlinx/coroutines/t1;)V

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x1

    invoke-static {}, Lkotlinx/coroutines/c;->b()Lkotlinx/coroutines/b;

    move-result-object v0

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x7

    if-eqz v0, :cond_0

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-virtual {v0}, Lkotlinx/coroutines/b;->d()V

    :cond_0
    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->i2()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x2

    if-nez v1, :cond_3

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x4

    sput-object v0, Lkotlinx/coroutines/a1;->_thread:Ljava/lang/Thread;

    const/4 v13, 0x0

    const/4 v12, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->Q1()V

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x2

    invoke-static {}, Lkotlinx/coroutines/c;->b()Lkotlinx/coroutines/b;

    move-result-object v0

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x6

    if-eqz v0, :cond_1

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x4

    invoke-virtual {v0}, Lkotlinx/coroutines/b;->h()V

    :cond_1
    const/4 v12, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/u1;->S0()Z

    move-result v0

    const/4 v13, 0x6

    const/4 v12, 0x2

    if-nez v0, :cond_2

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/a1;->e1()Ljava/lang/Thread;

    :cond_2
    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x2

    return-void

    :cond_3
    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x3

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const/4 v13, 0x3

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    move-wide v3, v1

    :cond_4
    :goto_0
    :try_start_1
    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x2

    invoke-static {}, Ljava/lang/Thread;->interrupted()Z

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/u1;->b1()J

    move-result-wide v5

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x0

    cmp-long v7, v5, v1

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x5

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x0

    if-nez v7, :cond_a

    const/4 v13, 0x6

    const/4 v12, 0x4

    invoke-static {}, Lkotlinx/coroutines/c;->b()Lkotlinx/coroutines/b;

    move-result-object v7

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x6

    if-eqz v7, :cond_5

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-virtual {v7}, Lkotlinx/coroutines/b;->b()J

    move-result-wide v10

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x7

    goto :goto_1

    :cond_5
    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x3

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v10

    :goto_1
    const/4 v13, 0x7

    const/4 v12, 0x1

    cmp-long v7, v3, v1

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x7

    if-nez v7, :cond_6

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x6

    sget-wide v3, Lkotlinx/coroutines/a1;->j:J
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x0

    add-long/2addr v3, v10

    :cond_6
    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x5

    sub-long v10, v3, v10

    const/4 v13, 0x3

    const/4 v12, 0x4

    cmp-long v7, v10, v8

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x3

    if-gtz v7, :cond_9

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x1

    sput-object v0, Lkotlinx/coroutines/a1;->_thread:Ljava/lang/Thread;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x4

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->Q1()V

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-static {}, Lkotlinx/coroutines/c;->b()Lkotlinx/coroutines/b;

    move-result-object v0

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x4

    if-eqz v0, :cond_7

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-virtual {v0}, Lkotlinx/coroutines/b;->h()V

    :cond_7
    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/u1;->S0()Z

    move-result v0

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x7

    if-nez v0, :cond_8

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x5

    invoke-virtual {p0}, Lkotlinx/coroutines/a1;->e1()Ljava/lang/Thread;

    :cond_8
    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x5

    return-void

    :cond_9
    :try_start_2
    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-static {v5, v6, v10, v11}, Lkotlin/ranges/s;->C(JJ)J

    move-result-wide v5

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x5

    goto :goto_2

    :cond_a
    move-wide v3, v1

    :goto_2
    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x3

    cmp-long v7, v5, v8

    const/4 v13, 0x5

    const/4 v12, 0x1

    if-lez v7, :cond_4

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x6

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->b2()Z

    move-result v7
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x6

    if-eqz v7, :cond_d

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x6

    sput-object v0, Lkotlinx/coroutines/a1;->_thread:Ljava/lang/Thread;

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x7

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->Q1()V

    const/4 v13, 0x5

    const/4 v12, 0x3

    invoke-static {}, Lkotlinx/coroutines/c;->b()Lkotlinx/coroutines/b;

    move-result-object v0

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x0

    if-eqz v0, :cond_b

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-virtual {v0}, Lkotlinx/coroutines/b;->h()V

    :cond_b
    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x4

    invoke-virtual {p0}, Lkotlinx/coroutines/u1;->S0()Z

    move-result v0

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x4

    if-nez v0, :cond_c

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/a1;->e1()Ljava/lang/Thread;

    :cond_c
    const/4 v13, 0x5

    const/4 v12, 0x2

    return-void

    :cond_d
    :try_start_3
    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x6

    invoke-static {}, Lkotlinx/coroutines/c;->b()Lkotlinx/coroutines/b;

    move-result-object v7

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x1

    if-eqz v7, :cond_e

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x6

    invoke-virtual {v7, p0, v5, v6}, Lkotlinx/coroutines/b;->c(Ljava/lang/Object;J)V

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x3

    sget-object v7, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x0

    goto :goto_3

    :cond_e
    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    :goto_3
    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x5

    if-nez v7, :cond_4

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x1

    invoke-static {p0, v5, v6}, Ljava/util/concurrent/locks/LockSupport;->parkNanos(Ljava/lang/Object;J)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x5

    goto/16 :goto_0

    :catchall_0
    move-exception v1

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x3

    sput-object v0, Lkotlinx/coroutines/a1;->_thread:Ljava/lang/Thread;

    const/4 v13, 0x1

    const/4 v12, 0x7

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->Q1()V

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x6

    invoke-static {}, Lkotlinx/coroutines/c;->b()Lkotlinx/coroutines/b;

    move-result-object v0

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x0

    if-eqz v0, :cond_f

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x1

    invoke-virtual {v0}, Lkotlinx/coroutines/b;->h()V

    :cond_f
    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x5

    invoke-virtual {p0}, Lkotlinx/coroutines/u1;->S0()Z

    move-result v0

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x5

    if-nez v0, :cond_10

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/a1;->e1()Ljava/lang/Thread;

    :cond_10
    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x4

    throw v1
.end method

.method public shutdown()V
    .locals 3

    const/4 v2, 0x6

    const/4 v0, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    sput v0, Lkotlinx/coroutines/a1;->debugStatus:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-super {p0}, Lkotlinx/coroutines/u1;->shutdown()V

    const/4 v2, 0x2

    return-void
.end method

.method public t1(Ljava/lang/Runnable;)V
    .locals 3
    .param p1    # Ljava/lang/Runnable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->Y1()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/a1;->k2()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-super {p0, p1}, Lkotlinx/coroutines/u1;->t1(Ljava/lang/Runnable;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method
