.class public final Lkotlinx/coroutines/c3;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/p1;
.implements Lkotlinx/coroutines/w;


# annotations
.annotation build Lkotlinx/coroutines/i2;
.end annotation


# static fields
.field public static final a:Lkotlinx/coroutines/c3;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Lkotlinx/coroutines/c3;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0}, Lkotlinx/coroutines/c3;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    sput-object v0, Lkotlinx/coroutines/c3;->a:Lkotlinx/coroutines/c3;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public e()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "bfsv~@ Kli   ~.t~@@bSfa~mb @ i~@c  o @~~~~yr@ @~@d/~@~o~i -@oto@~u ~l ~~~~~M@@ o@@@@s/~on~ @@1 4"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    return-void
.end method

.method public getParent()Lkotlinx/coroutines/n2;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public j(Ljava/lang/Throwable;)Z
    .locals 2
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x2

    return p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, "dDNmllobasnHepesian"

    const-string v0, "dnslpbioDHslNsaeean"

    const/4 v2, 0x2

    const-string v0, "HsbsoaoNdnieelnalDp"

    const-string v0, "NonDisposableHandle"

    const/4 v2, 0x6

    const/4 v1, 0x2

    return-object v0
.end method
