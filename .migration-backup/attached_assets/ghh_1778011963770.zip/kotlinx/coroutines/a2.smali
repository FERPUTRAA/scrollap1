.class public final Lkotlinx/coroutines/a2;
.super Lkotlinx/coroutines/z1;

# interfaces
.implements Lkotlinx/coroutines/e1;


# instance fields
.field private final c:Ljava/util/concurrent/Executor;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Executor;)V
    .locals 2
    .param p1    # Ljava/util/concurrent/Executor;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Lkotlinx/coroutines/z1;-><init>()V

    const/4 v1, 0x4

    iput-object p1, p0, Lkotlinx/coroutines/a2;->c:Ljava/util/concurrent/Executor;

    const/4 v0, 0x1

    move v1, v0

    invoke-virtual {p0}, Lkotlinx/coroutines/a2;->u0()Ljava/util/concurrent/Executor;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p1}, Lkotlinx/coroutines/internal/f;->c(Ljava/util/concurrent/Executor;)Z

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method private final A0(Ljava/util/concurrent/ScheduledExecutorService;Ljava/lang/Runnable;Lkotlin/coroutines/g;J)Ljava/util/concurrent/ScheduledFuture;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/ScheduledExecutorService;",
            "Ljava/lang/Runnable;",
            "Lkotlin/coroutines/g;",
            "J)",
            "Ljava/util/concurrent/ScheduledFuture<",
            "*>;"
        }
    .end annotation

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "S@slyfui  o~K mr@ 4@~~b  @@t bo~ s ~@/t-o~ o c~ai~@ 1~~ o .@b@~v~~ @~~~@ @o~ ~M@/lfdn@~@i@~@@@@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x2

    invoke-interface {p1, p2, p4, p5, v0}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p1
    :try_end_0
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0, p3, p1}, Lkotlinx/coroutines/a2;->v0(Lkotlin/coroutines/g;Ljava/util/concurrent/RejectedExecutionException;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p1
.end method

.method private final v0(Lkotlin/coroutines/g;Ljava/util/concurrent/RejectedExecutionException;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string v0, "acdmherse ektajwtse T"

    const-string v0, "j sedsekheTsr cetwaat"

    const/4 v2, 0x6

    const-string v0, "eeweot jtas kserdc ha"

    const-string v0, "The task was rejected"

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0, p2}, Lkotlinx/coroutines/y1;->a(Ljava/lang/String;Ljava/lang/Throwable;)Ljava/util/concurrent/CancellationException;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p1, p2}, Lkotlinx/coroutines/r2;->f(Lkotlin/coroutines/g;Ljava/util/concurrent/CancellationException;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public J(JLkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Deprecated without replacement as an internal method never intended for public use"
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p0, p1, p2, p3}, Lkotlinx/coroutines/e1$a;->a(Lkotlinx/coroutines/e1;JLkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public close()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lkotlinx/coroutines/a2;->u0()Ljava/util/concurrent/Executor;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/util/concurrent/ExecutorService;

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Ljava/util/concurrent/ExecutorService;

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method public d(JLkotlinx/coroutines/q;)V
    .locals 11
    .param p3    # Lkotlinx/coroutines/q;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lkotlinx/coroutines/q<",
            "-",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v9, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/a2;->u0()Ljava/util/concurrent/Executor;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    instance-of v1, v0, Ljava/util/concurrent/ScheduledExecutorService;

    const/4 v10, 0x2

    const/4 v2, 0x4

    const/4 v10, 0x7

    const/4 v2, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x6

    if-eqz v1, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    check-cast v0, Ljava/util/concurrent/ScheduledExecutorService;

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    goto :goto_0

    :cond_0
    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x0

    if-eqz v4, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x4

    new-instance v5, Lkotlinx/coroutines/j3;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-direct {v5, p0, p3}, Lkotlinx/coroutines/j3;-><init>(Lkotlinx/coroutines/o0;Lkotlinx/coroutines/q;)V

    const/4 v9, 0x0

    move v10, v9

    invoke-interface {p3}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v6

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-wide v7, p1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-direct/range {v3 .. v8}, Lkotlinx/coroutines/a2;->A0(Ljava/util/concurrent/ScheduledExecutorService;Ljava/lang/Runnable;Lkotlin/coroutines/g;J)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v2

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-eqz v2, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static {p3, v2}, Lkotlinx/coroutines/r2;->w(Lkotlinx/coroutines/q;Ljava/util/concurrent/Future;)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    return-void

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    sget-object v0, Lkotlinx/coroutines/a1;->g:Lkotlinx/coroutines/a1;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v0, p1, p2, p3}, Lkotlinx/coroutines/u1;->d(JLkotlinx/coroutines/q;)V

    const/4 v9, 0x4

    shl-int/2addr v10, v9

    return-void
.end method

.method public d0(Lkotlin/coroutines/g;Ljava/lang/Runnable;)V
    .locals 4
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Runnable;
        .annotation build Lia/d;
        .end annotation
    .end param

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Lkotlinx/coroutines/a2;->u0()Ljava/util/concurrent/Executor;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {}, Lkotlinx/coroutines/c;->b()Lkotlinx/coroutines/b;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v1, p2}, Lkotlinx/coroutines/b;->i(Ljava/lang/Runnable;)Ljava/lang/Runnable;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v1, :cond_1

    :cond_0
    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {}, Lkotlinx/coroutines/c;->b()Lkotlinx/coroutines/b;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v1}, Lkotlinx/coroutines/b;->f()V

    :cond_2
    const/4 v3, 0x2

    invoke-direct {p0, p1, v0}, Lkotlinx/coroutines/a2;->v0(Lkotlin/coroutines/g;Ljava/util/concurrent/RejectedExecutionException;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lkotlinx/coroutines/m1;->c()Lkotlinx/coroutines/o0;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p1, p2}, Lkotlinx/coroutines/o0;->d0(Lkotlin/coroutines/g;Ljava/lang/Runnable;)V

    :goto_0
    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    instance-of v0, p1, Lkotlinx/coroutines/a2;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast p1, Lkotlinx/coroutines/a2;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1}, Lkotlinx/coroutines/a2;->u0()Ljava/util/concurrent/Executor;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lkotlinx/coroutines/a2;->u0()Ljava/util/concurrent/Executor;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-ne p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return p1
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lkotlinx/coroutines/a2;->u0()Ljava/util/concurrent/Executor;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public l(JLjava/lang/Runnable;Lkotlin/coroutines/g;)Lkotlinx/coroutines/p1;
    .locals 11
    .param p3    # Ljava/lang/Runnable;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p4    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {p0}, Lkotlinx/coroutines/a2;->u0()Ljava/util/concurrent/Executor;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    instance-of v1, v0, Ljava/util/concurrent/ScheduledExecutorService;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/4 v2, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    if-eqz v1, :cond_0

    check-cast v0, Ljava/util/concurrent/ScheduledExecutorService;

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    goto :goto_0

    :cond_0
    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    move-object v4, v2

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-eqz v4, :cond_1

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-wide v7, p1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-direct/range {v3 .. v8}, Lkotlinx/coroutines/a2;->A0(Ljava/util/concurrent/ScheduledExecutorService;Ljava/lang/Runnable;Lkotlin/coroutines/g;J)Ljava/util/concurrent/ScheduledFuture;

    move-result-object v2

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    if-eqz v2, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    new-instance p1, Lkotlinx/coroutines/o1;

    const/4 v10, 0x7

    invoke-direct {p1, v2}, Lkotlinx/coroutines/o1;-><init>(Ljava/util/concurrent/Future;)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto :goto_1

    :cond_2
    const/4 v10, 0x7

    sget-object v0, Lkotlinx/coroutines/a1;->g:Lkotlinx/coroutines/a1;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0, p1, p2, p3, p4}, Lkotlinx/coroutines/a1;->l(JLjava/lang/Runnable;Lkotlin/coroutines/g;)Lkotlinx/coroutines/p1;

    move-result-object p1

    :goto_1
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    invoke-virtual {p0}, Lkotlinx/coroutines/a2;->u0()Ljava/util/concurrent/Executor;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public u0()Ljava/util/concurrent/Executor;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    iget-object v0, p0, Lkotlinx/coroutines/a2;->c:Ljava/util/concurrent/Executor;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method
