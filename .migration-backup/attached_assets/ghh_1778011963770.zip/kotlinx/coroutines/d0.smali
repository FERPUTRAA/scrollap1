.class final Lkotlinx/coroutines/d0;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCancellableContinuationImpl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CancellableContinuationImpl.kt\nkotlinx/coroutines/CompletedContinuation\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,593:1\n1#2:594\n*E\n"
.end annotation


# instance fields
.field public final a:Ljava/lang/Object;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public final b:Lkotlinx/coroutines/o;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public final c:Li8/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/l<",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public final d:Ljava/lang/Object;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field

.field public final e:Ljava/lang/Throwable;
    .annotation build Lh8/e;
    .end annotation

    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Object;Lkotlinx/coroutines/o;Li8/l;Ljava/lang/Object;Ljava/lang/Throwable;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/o;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p3    # Li8/l;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p5    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlinx/coroutines/o;",
            "Li8/l<",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            "Ljava/lang/Throwable;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/d0;->a:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p2, p0, Lkotlinx/coroutines/d0;->b:Lkotlinx/coroutines/o;

    const/4 v1, 0x7

    iput-object p3, p0, Lkotlinx/coroutines/d0;->c:Li8/l;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p4, p0, Lkotlinx/coroutines/d0;->d:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p5, p0, Lkotlinx/coroutines/d0;->e:Ljava/lang/Throwable;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Lkotlinx/coroutines/o;Li8/l;Ljava/lang/Object;Ljava/lang/Throwable;ILkotlin/jvm/internal/w;)V
    .locals 8

    const/4 v7, 0x7

    and-int/lit8 p7, p6, 0x2

    const/4 v7, 0x2

    const/4 v0, 0x0

    const/4 v7, 0x4

    if-eqz p7, :cond_0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    :goto_0
    const/4 v7, 0x7

    and-int/lit8 p2, p6, 0x4

    const/4 v7, 0x1

    if-eqz p2, :cond_1

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    const/4 v7, 0x1

    goto :goto_1

    :cond_1
    move-object v4, p3

    move-object v4, p3

    :goto_1
    const/4 v7, 0x0

    and-int/lit8 p2, p6, 0x8

    const/4 v7, 0x1

    if-eqz p2, :cond_2

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    const/4 v7, 0x7

    goto :goto_2

    :cond_2
    move-object v5, p4

    move-object v5, p4

    :goto_2
    const/4 v7, 0x5

    and-int/lit8 p2, p6, 0x10

    if-eqz p2, :cond_3

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v7, 0x2

    goto :goto_3

    :cond_3
    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    :goto_3
    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v7, 0x4

    invoke-direct/range {v1 .. v6}, Lkotlinx/coroutines/d0;-><init>(Ljava/lang/Object;Lkotlinx/coroutines/o;Li8/l;Ljava/lang/Object;Ljava/lang/Throwable;)V

    const/4 v7, 0x5

    return-void
.end method

.method public static synthetic g(Lkotlinx/coroutines/d0;Ljava/lang/Object;Lkotlinx/coroutines/o;Li8/l;Ljava/lang/Object;Ljava/lang/Throwable;ILjava/lang/Object;)Lkotlinx/coroutines/d0;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@yst@-/m~bo@l~4~ ~o  o b1@@oonrs @ i@~~@al~t@~@K~~~uf @ o  M~v@S ~@@.d~@~~~~~i/ ~@b@f@@ c~@i~   "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    and-int/lit8 p7, p6, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz p7, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object p1, p0, Lkotlinx/coroutines/d0;->a:Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    and-int/lit8 p7, p6, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz p7, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object p2, p0, Lkotlinx/coroutines/d0;->b:Lkotlinx/coroutines/o;

    :cond_1
    move-object p7, p2

    move-object p7, p2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    and-int/lit8 p2, p6, 0x4

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    if-eqz p2, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object p3, p0, Lkotlinx/coroutines/d0;->c:Li8/l;

    :cond_2
    move-object v0, p3

    move-object v0, p3

    move-object v0, p3

    move-object v0, p3

    const/4 v4, 0x0

    const/4 v3, 0x2

    and-int/lit8 p2, p6, 0x8

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz p2, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object p4, p0, Lkotlinx/coroutines/d0;->d:Ljava/lang/Object;

    :cond_3
    move-object v1, p4

    move-object v1, p4

    move-object v1, p4

    move-object v1, p4

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    and-int/lit8 p2, p6, 0x10

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz p2, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object p5, p0, Lkotlinx/coroutines/d0;->e:Ljava/lang/Throwable;

    :cond_4
    move-object v2, p5

    move-object v2, p5

    move-object v2, p5

    move-object v2, p5

    move-object p2, p0

    move-object p2, p0

    move-object p3, p1

    move-object p3, p1

    move-object p3, p1

    move-object p4, p7

    move-object p4, p7

    move-object p4, p7

    move-object p4, p7

    move-object p5, v0

    move-object p5, v0

    move-object p5, v0

    move-object p5, v0

    move-object p6, v1

    move-object p6, v1

    move-object p6, v1

    move-object p6, v1

    move-object p7, v2

    move-object p7, v2

    move-object p7, v2

    move-object p7, v2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual/range {p2 .. p7}, Lkotlinx/coroutines/d0;->f(Ljava/lang/Object;Lkotlinx/coroutines/o;Li8/l;Ljava/lang/Object;Ljava/lang/Throwable;)Lkotlinx/coroutines/d0;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object p0
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/d0;->a:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public final b()Lkotlinx/coroutines/o;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/d0;->b:Lkotlinx/coroutines/o;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public final c()Li8/l;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Li8/l<",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/d0;->c:Li8/l;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public final d()Ljava/lang/Object;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/d0;->d:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public final e()Ljava/lang/Throwable;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lkotlinx/coroutines/d0;->e:Ljava/lang/Throwable;

    const/4 v2, 0x3

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-ne p0, p1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    return v0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    instance-of v1, p1, Lkotlinx/coroutines/d0;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x7

    if-nez v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    return v2

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    check-cast p1, Lkotlinx/coroutines/d0;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/d0;->a:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v3, p1, Lkotlinx/coroutines/d0;->a:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-nez v1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    return v2

    :cond_2
    const/4 v4, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v1, p0, Lkotlinx/coroutines/d0;->b:Lkotlinx/coroutines/o;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v3, p1, Lkotlinx/coroutines/d0;->b:Lkotlinx/coroutines/o;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    if-nez v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v2

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, p0, Lkotlinx/coroutines/d0;->c:Li8/l;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v3, p1, Lkotlinx/coroutines/d0;->c:Li8/l;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-nez v1, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    return v2

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/d0;->d:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v3, p1, Lkotlinx/coroutines/d0;->d:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v1, v3}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-nez v1, :cond_5

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    return v2

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/d0;->e:Ljava/lang/Throwable;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object p1, p1, Lkotlinx/coroutines/d0;->e:Ljava/lang/Throwable;

    const/4 v4, 0x6

    move v5, v4

    invoke-static {v1, p1}, Lkotlin/jvm/internal/l0;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-nez p1, :cond_6

    const/4 v5, 0x7

    return v2

    :cond_6
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    return v0
.end method

.method public final f(Ljava/lang/Object;Lkotlinx/coroutines/o;Li8/l;Ljava/lang/Object;Ljava/lang/Throwable;)Lkotlinx/coroutines/d0;
    .locals 9
    .param p1    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Lkotlinx/coroutines/o;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p3    # Li8/l;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p4    # Ljava/lang/Object;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p5    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlinx/coroutines/o;",
            "Li8/l<",
            "-",
            "Ljava/lang/Throwable;",
            "Lkotlin/s2;",
            ">;",
            "Ljava/lang/Object;",
            "Ljava/lang/Throwable;",
            ")",
            "Lkotlinx/coroutines/d0;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance v6, Lkotlinx/coroutines/d0;

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v4, p4

    move-object v4, p4

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-direct/range {v0 .. v5}, Lkotlinx/coroutines/d0;-><init>(Ljava/lang/Object;Lkotlinx/coroutines/o;Li8/l;Ljava/lang/Object;Ljava/lang/Throwable;)V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-object v6
.end method

.method public final h()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lkotlinx/coroutines/d0;->e:Ljava/lang/Throwable;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    return v0
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/d0;->a:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    move v0, v1

    move v0, v1

    const/4 v4, 0x2

    move v0, v1

    move v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    mul-int/lit8 v0, v0, 0x1f

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v2, p0, Lkotlinx/coroutines/d0;->b:Lkotlinx/coroutines/o;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    move v2, v1

    move v2, v1

    const/4 v4, 0x6

    move v2, v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto :goto_1

    :cond_1
    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    add-int/2addr v0, v2

    const/4 v3, 0x4

    or-int/2addr v4, v3

    mul-int/lit8 v0, v0, 0x1f

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v2, p0, Lkotlinx/coroutines/d0;->c:Li8/l;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-nez v2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    move v2, v1

    move v2, v1

    const/4 v4, 0x0

    move v2, v1

    move v2, v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_2

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_2
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    add-int/2addr v0, v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    mul-int/lit8 v0, v0, 0x1f

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v2, p0, Lkotlinx/coroutines/d0;->d:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez v2, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    move v2, v1

    move v2, v1

    const/4 v4, 0x4

    move v2, v1

    move v2, v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_3

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_3
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    add-int/2addr v0, v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    mul-int/lit8 v0, v0, 0x1f

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v2, p0, Lkotlinx/coroutines/d0;->e:Ljava/lang/Throwable;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez v2, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_4

    :cond_4
    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_4
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    add-int/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    return v0
.end method

.method public final i(Lkotlinx/coroutines/r;Ljava/lang/Throwable;)V
    .locals 3
    .param p1    # Lkotlinx/coroutines/r;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Throwable;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/r<",
            "*>;",
            "Ljava/lang/Throwable;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/d0;->b:Lkotlinx/coroutines/o;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    invoke-virtual {p1, v0, p2}, Lkotlinx/coroutines/r;->l(Lkotlinx/coroutines/o;Ljava/lang/Throwable;)V

    :cond_0
    iget-object v0, p0, Lkotlinx/coroutines/d0;->c:Li8/l;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1, v0, p2}, Lkotlinx/coroutines/r;->o(Li8/l;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v1, "tClmoirndatnnteC=s(ouutlpemse"

    const-string v1, "ndslleatmiurtC=uonsoonCp(eett"

    const/4 v3, 0x7

    const-string v1, "Cn=lot(euoeoarCtmnitdulesoint"

    const-string v1, "CompletedContinuation(result="

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/d0;->a:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string v1, "aHme blnrced,acn"

    const-string v1, "Hccmld =nreaaen,"

    const/4 v3, 0x7

    const-string v1, "ence cul,dn=rHaa"

    const-string v1, ", cancelHandler="

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lkotlinx/coroutines/d0;->b:Lkotlinx/coroutines/o;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v1, "lncnlt,peonC=aoai"

    const-string v1, "Cnnaoco=,etoillan"

    const/4 v3, 0x7

    const-string v1, " naeCconq=lainlto"

    const-string v1, ", onCancellation="

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Lkotlinx/coroutines/d0;->c:Li8/l;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v1, "etsmbu,ei =etneRmdp"

    const-string v1, "pe,mubnRet=medieot "

    const/4 v3, 0x6

    const-string/jumbo v1, "tm,moeetndR=iee spm"

    const-string v1, ", idempotentResume="

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v1, p0, Lkotlinx/coroutines/d0;->d:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, "leCuo,csn =eca"

    const-string v1, "=nCcueuea,l sc"

    const/4 v3, 0x6

    const-string v1, "cCeusba=cne,a "

    const-string v1, ", cancelCause="

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v1, p0, Lkotlinx/coroutines/d0;->e:Ljava/lang/Throwable;

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0x29

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0
.end method
