.class public final Lkotlinx/coroutines/e2;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/u0;


# annotations
.annotation build Lkotlinx/coroutines/g1;
.end annotation


# static fields
.field public static final a:Lkotlinx/coroutines/e2;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Lkotlinx/coroutines/e2;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0}, Lkotlinx/coroutines/e2;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    sput-object v0, Lkotlinx/coroutines/e2;->a:Lkotlinx/coroutines/e2;

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public getCoroutineContext()Lkotlin/coroutines/g;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s d~~@~@ ~~~Sft ob@@y@- ~f @@ur@1  oi@i~~@M@  l@c~.n o/l@v~@   4a~i o@Kb~b@o~ o@~@/m@ @t ~~~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lkotlin/coroutines/i;->a:Lkotlin/coroutines/i;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method
