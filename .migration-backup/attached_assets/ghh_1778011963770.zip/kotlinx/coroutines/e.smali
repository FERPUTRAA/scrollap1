.class final Lkotlinx/coroutines/e;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlinx/coroutines/e$b;,
        Lkotlinx/coroutines/e$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAwait.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Await.kt\nkotlinx/coroutines/AwaitAll\n+ 2 CancellableContinuation.kt\nkotlinx/coroutines/CancellableContinuationKt\n+ 3 CompletionHandler.kt\nkotlinx/coroutines/CompletionHandlerKt\n+ 4 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,127:1\n314#2,9:128\n323#2,2:141\n13#3:137\n19#3:140\n13536#4,2:138\n*S KotlinDebug\n*F\n+ 1 Await.kt\nkotlinx/coroutines/AwaitAll\n*L\n71#1:128,9\n71#1:141,2\n78#1:137\n90#1:140\n83#1:138,2\n*E\n"
.end annotation


# static fields
.field static final synthetic b:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;


# instance fields
.field private final a:[Lkotlinx/coroutines/c1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lkotlinx/coroutines/c1<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field volatile synthetic notCompletedCount:I
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const-class v0, Lkotlinx/coroutines/e;

    const-class v0, Lkotlinx/coroutines/e;

    const/4 v3, 0x1

    const-class v0, Lkotlinx/coroutines/e;

    const-class v0, Lkotlinx/coroutines/e;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, "dnsttlotCseoCmnuo"

    const-string v1, "ClsmuotoentConetd"

    const/4 v3, 0x3

    const-string v1, "notCompletedCount"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0, v1}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->newUpdater(Ljava/lang/Class;Ljava/lang/String;)Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    sput-object v0, Lkotlinx/coroutines/e;->b:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method public constructor <init>([Lkotlinx/coroutines/c1;)V
    .locals 2
    .param p1    # [Lkotlinx/coroutines/c1;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lkotlinx/coroutines/c1<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lkotlinx/coroutines/e;->a:[Lkotlinx/coroutines/c1;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    array-length p1, p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p1, p0, Lkotlinx/coroutines/e;->notCompletedCount:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    return-void
.end method

.method public static final synthetic a(Lkotlinx/coroutines/e;)[Lkotlinx/coroutines/c1;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~o~m u-~@si @ /fl.1~@@ot@@a~d ~@~Mot~ n i@ ~~~4 @o S @yK~@ o@v~f ~ b@~@/ rm lo@@~c~bb@@i~@  ~~~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lkotlinx/coroutines/e;->a:[Lkotlinx/coroutines/c1;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p0
.end method


# virtual methods
.method public final b(Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 9
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/util/List<",
            "+TT;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-instance v0, Lkotlinx/coroutines/r;

    const/4 v7, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {p1}, Lkotlin/coroutines/intrinsics/b;->e(Lkotlin/coroutines/d;)Lkotlin/coroutines/d;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/4 v2, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {v0, v1, v2}, Lkotlinx/coroutines/r;-><init>(Lkotlin/coroutines/d;I)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v0}, Lkotlinx/coroutines/r;->R()V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {p0}, Lkotlinx/coroutines/e;->a(Lkotlinx/coroutines/e;)[Lkotlinx/coroutines/c1;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    array-length v1, v1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    new-array v2, v1, [Lkotlinx/coroutines/e$a;

    const/4 v8, 0x7

    const/4 v3, 0x0

    const/4 v8, 0x0

    or-int/2addr v7, v3

    const/4 v8, 0x1

    move v4, v3

    move v4, v3

    const/4 v8, 0x4

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v7, 0x1

    const/4 v8, 0x7

    if-ge v4, v1, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {p0}, Lkotlinx/coroutines/e;->a(Lkotlinx/coroutines/e;)[Lkotlinx/coroutines/c1;

    move-result-object v5

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    aget-object v5, v5, v4

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-interface {v5}, Lkotlinx/coroutines/n2;->start()Z

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    new-instance v6, Lkotlinx/coroutines/e$a;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {v6, p0, v0}, Lkotlinx/coroutines/e$a;-><init>(Lkotlinx/coroutines/e;Lkotlinx/coroutines/q;)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-interface {v5, v6}, Lkotlinx/coroutines/n2;->invokeOnCompletion(Li8/l;)Lkotlinx/coroutines/p1;

    move-result-object v5

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v6, v5}, Lkotlinx/coroutines/e$a;->J0(Lkotlinx/coroutines/p1;)V

    const/4 v8, 0x7

    sget-object v5, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    aput-object v6, v2, v4

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    new-instance v4, Lkotlinx/coroutines/e$b;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {v4, p0, v2}, Lkotlinx/coroutines/e$b;-><init>(Lkotlinx/coroutines/e;[Lkotlinx/coroutines/e$a;)V

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-ge v3, v1, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    aget-object v5, v2, v3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v5, v4}, Lkotlinx/coroutines/e$a;->I0(Lkotlinx/coroutines/e$b;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    goto :goto_1

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-interface {v0}, Lkotlinx/coroutines/q;->isCompleted()Z

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eqz v1, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v4}, Lkotlinx/coroutines/e$b;->d()V

    const/4 v8, 0x0

    const/4 v7, 0x2

    goto :goto_2

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-interface {v0, v4}, Lkotlinx/coroutines/q;->s(Li8/l;)V

    :goto_2
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v0}, Lkotlinx/coroutines/r;->w()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-ne v0, v1, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {p1}, Lkotlin/coroutines/jvm/internal/h;->c(Lkotlin/coroutines/d;)V

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    return-object v0
.end method
