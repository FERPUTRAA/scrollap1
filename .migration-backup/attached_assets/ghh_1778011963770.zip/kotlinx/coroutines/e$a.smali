.class final Lkotlinx/coroutines/e$a;
.super Lkotlinx/coroutines/u2;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlinx/coroutines/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAwait.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Await.kt\nkotlinx/coroutines/AwaitAll$AwaitAllNode\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,127:1\n11328#2:128\n11663#2,3:129\n*S KotlinDebug\n*F\n+ 1 Await.kt\nkotlinx/coroutines/AwaitAll$AwaitAllNode\n*L\n121#1:128\n121#1:129,3\n*E\n"
.end annotation


# instance fields
.field private volatile synthetic _disposer:Ljava/lang/Object;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final e:Lkotlinx/coroutines/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/q<",
            "Ljava/util/List<",
            "+TT;>;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation
.end field

.field public f:Lkotlinx/coroutines/p1;

.field final synthetic g:Lkotlinx/coroutines/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlinx/coroutines/e<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/e;Lkotlinx/coroutines/q;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/e;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/q<",
            "-",
            "Ljava/util/List<",
            "+TT;>;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/e$a;->g:Lkotlinx/coroutines/e;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Lkotlinx/coroutines/u2;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p2, p0, Lkotlinx/coroutines/e$a;->e:Lkotlinx/coroutines/q;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x1

    iput-object p1, p0, Lkotlinx/coroutines/e$a;->_disposer:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public D0(Ljava/lang/Throwable;)V
    .locals 7
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "o1s ~id ot @@ @4~ o~fm ~i b@@~y@@r ~b .K- @@ cf@ @vo~@S~ lb~@@n@Mt~ s~u@~~~~~~ @~~~/@ ooai~~l @/"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    if-eqz p1, :cond_0

    const/4 v5, 0x7

    move v6, v5

    iget-object v0, p0, Lkotlinx/coroutines/e$a;->e:Lkotlinx/coroutines/q;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {v0, p1}, Lkotlinx/coroutines/q;->n(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz p1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/e$a;->e:Lkotlinx/coroutines/q;

    const/4 v6, 0x1

    invoke-interface {v0, p1}, Lkotlinx/coroutines/q;->Z(Ljava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p0}, Lkotlinx/coroutines/e$a;->G0()Lkotlinx/coroutines/e$b;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz p1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p1}, Lkotlinx/coroutines/e$b;->d()V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_1

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object p1, p0, Lkotlinx/coroutines/e$a;->g:Lkotlinx/coroutines/e;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    sget-object v0, Lkotlinx/coroutines/e;->b:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->decrementAndGet(Ljava/lang/Object;)I

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-nez p1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object p1, p0, Lkotlinx/coroutines/e$a;->e:Lkotlinx/coroutines/q;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/e$a;->g:Lkotlinx/coroutines/e;

    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0}, Lkotlinx/coroutines/e;->a(Lkotlinx/coroutines/e;)[Lkotlinx/coroutines/c1;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance v1, Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    array-length v2, v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    array-length v2, v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x0

    if-ge v3, v2, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    aget-object v4, v0, v3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-interface {v4}, Lkotlinx/coroutines/c1;->getCompleted()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v1, v4}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    sget-object v0, Lkotlin/d1;->a:Lkotlin/d1$a;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v1}, Lkotlin/d1;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {p1, v0}, Lkotlin/coroutines/d;->resumeWith(Ljava/lang/Object;)V

    :cond_2
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-void
.end method

.method public final G0()Lkotlinx/coroutines/e$b;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lkotlinx/coroutines/e<",
            "TT;>.b;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lkotlinx/coroutines/e$a;->_disposer:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast v0, Lkotlinx/coroutines/e$b;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public final H0()Lkotlinx/coroutines/p1;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lkotlinx/coroutines/e$a;->f:Lkotlinx/coroutines/p1;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string v0, "dlhmsn"

    const-string v0, "nhsdel"

    const/4 v2, 0x4

    const-string v0, "hleaon"

    const-string v0, "handle"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->S(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x5

    move v1, v0

    move v1, v0

    const/4 v2, 0x5

    return-object v0
.end method

.method public final I0(Lkotlinx/coroutines/e$b;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/e$b;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/e<",
            "TT;>.b;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lkotlinx/coroutines/e$a;->_disposer:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public final J0(Lkotlinx/coroutines/p1;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/p1;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v0, 0x2

    move v1, v0

    iput-object p1, p0, Lkotlinx/coroutines/e$a;->f:Lkotlinx/coroutines/p1;

    const/4 v0, 0x3

    or-int/2addr v1, v0

    return-void
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    check-cast p1, Ljava/lang/Throwable;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lkotlinx/coroutines/e$a;->D0(Ljava/lang/Throwable;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    sget-object p1, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method
