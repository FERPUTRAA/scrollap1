.class public final Lkotlinx/coroutines/a4;
.super Ljava/lang/Object;


# direct methods
.method public static final a(JLkotlinx/coroutines/n2;)Lkotlinx/coroutines/y3;
    .locals 5
    .param p2    # Lkotlinx/coroutines/n2;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@@s~~@~@~   ao @~~4@K /u~@t -fo~@@@.  @i@lri~~@~  bvo @n @c /~1~mo~@@~~~~ f~ S@lityb@o~d~o bM ~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    new-instance v0, Lkotlinx/coroutines/y3;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v2, "n fmid gtwitaou iTro e"

    const-string v2, "nos tiedtfg Twu oiair "

    const/4 v4, 0x4

    const-string v2, " uT oigfoomtiwdrie na "

    const-string v2, "Timed out waiting for "

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string p0, "sm "

    const-string p0, "s m"

    const/4 v4, 0x3

    const-string p0, " ms"

    const-string p0, " ms"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0, p0, p2}, Lkotlinx/coroutines/y3;-><init>(Ljava/lang/String;Lkotlinx/coroutines/n2;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object v0
.end method

.method private static final b(Lkotlinx/coroutines/z3;Li8/p;)Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<U:",
            "Ljava/lang/Object;",
            "T::TU;>(",
            "Lkotlinx/coroutines/z3<",
            "TU;-TT;>;",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/u0;",
            "-",
            "Lkotlin/coroutines/d<",
            "-TT;>;+",
            "Ljava/lang/Object;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v0, p0, Lkotlinx/coroutines/internal/n0;->c:Lkotlin/coroutines/d;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v0}, Lkotlin/coroutines/d;->getContext()Lkotlin/coroutines/g;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v0}, Lkotlinx/coroutines/f1;->d(Lkotlin/coroutines/g;)Lkotlinx/coroutines/e1;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    iget-wide v1, p0, Lkotlinx/coroutines/z3;->d:J

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0}, Lkotlinx/coroutines/a;->getContext()Lkotlin/coroutines/g;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-interface {v0, v1, v2, p0, v3}, Lkotlinx/coroutines/e1;->l(JLjava/lang/Runnable;Lkotlin/coroutines/g;)Lkotlinx/coroutines/p1;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p0, v0}, Lkotlinx/coroutines/r2;->y(Lkotlinx/coroutines/n2;Lkotlinx/coroutines/p1;)Lkotlinx/coroutines/p1;

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-static {p0, p0, p1}, Lu8/b;->g(Lkotlinx/coroutines/internal/n0;Ljava/lang/Object;Li8/p;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-object p0
.end method

.method public static final c(JLi8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p2    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(J",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/u0;",
            "-",
            "Lkotlin/coroutines/d<",
            "-TT;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-TT;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    cmp-long v0, p0, v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-lez v0, :cond_1

    const/4 v2, 0x5

    move v3, v2

    new-instance v0, Lkotlinx/coroutines/z3;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0, p0, p1, p3}, Lkotlinx/coroutines/z3;-><init>(JLkotlin/coroutines/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-static {v0, p2}, Lkotlinx/coroutines/a4;->b(Lkotlinx/coroutines/z3;Li8/p;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-ne p0, p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p3}, Lkotlin/coroutines/jvm/internal/h;->c(Lkotlin/coroutines/d;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance p0, Lkotlinx/coroutines/y3;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string p1, "aumeebiot dyilTd time"

    const-string p1, "Timed out immediately"

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Lkotlinx/coroutines/y3;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    throw p0
.end method

.method public static final d(JLi8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p2    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(J",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/u0;",
            "-",
            "Lkotlin/coroutines/d<",
            "-TT;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-TT;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lkotlinx/coroutines/f1;->e(J)J

    move-result-wide p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p0, p1, p2, p3}, Lkotlinx/coroutines/a4;->c(JLi8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method public static final e(JLi8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 9
    .param p2    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(J",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/u0;",
            "-",
            "Lkotlin/coroutines/d<",
            "-TT;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-TT;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    instance-of v0, p3, Lkotlinx/coroutines/a4$a;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-eqz v0, :cond_0

    move-object v0, p3

    move-object v0, p3

    move-object v0, p3

    move-object v0, p3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    check-cast v0, Lkotlinx/coroutines/a4$a;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget v1, v0, Lkotlinx/coroutines/a4$a;->label:I

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/high16 v2, -0x80000000

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    and-int v3, v1, v2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz v3, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    sub-int/2addr v1, v2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    iput v1, v0, Lkotlinx/coroutines/a4$a;->label:I

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    new-instance v0, Lkotlinx/coroutines/a4$a;

    const/4 v8, 0x3

    const/4 v7, 0x1

    invoke-direct {v0, p3}, Lkotlinx/coroutines/a4$a;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v7, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object p3, v0, Lkotlinx/coroutines/a4$a;->result:Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget v2, v0, Lkotlinx/coroutines/a4$a;->label:I

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    const/4 v3, 0x0

    const/4 v8, 0x1

    const/4 v4, 0x4

    const/4 v8, 0x2

    const/4 v4, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-eqz v2, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x2

    if-ne v2, v4, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget-object p0, v0, Lkotlinx/coroutines/a4$a;->L$1:Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    check-cast p0, Lkotlin/jvm/internal/k1$h;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object p1, v0, Lkotlinx/coroutines/a4$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    check-cast p1, Li8/p;

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {p3}, Lkotlin/e1;->n(Ljava/lang/Object;)V
    :try_end_0
    .catch Lkotlinx/coroutines/y3; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    goto/16 :goto_1

    :catch_0
    move-exception p1

    const/4 v8, 0x5

    const/4 v7, 0x6

    goto/16 :goto_2

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-string p1, "///lsnurvo ureir/n ewl/mhb eeico/fetica  /moetkotu/"

    const-string p1, "l/cmei/l oto/t/ou/fhnn etwioum ko/err are/ev/ siecb"

    const/4 v8, 0x0

    const-string p1, "/ /tf/tpekiroeemuv/lu//o c  t/raohl oiesnnbwireo /c"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    throw p0

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {p3}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-wide/16 v5, 0x0

    const/4 v8, 0x5

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    cmp-long p3, p0, v5

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-gtz p3, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    return-object v3

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    new-instance p3, Lkotlin/jvm/internal/k1$h;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {p3}, Lkotlin/jvm/internal/k1$h;-><init>()V

    :try_start_1
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    iput-object p2, v0, Lkotlinx/coroutines/a4$a;->L$0:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    iput-object p3, v0, Lkotlinx/coroutines/a4$a;->L$1:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    iput-wide p0, v0, Lkotlinx/coroutines/a4$a;->J$0:J

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    iput v4, v0, Lkotlinx/coroutines/a4$a;->label:I

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v2, Lkotlinx/coroutines/z3;

    invoke-direct {v2, p0, p1, v0}, Lkotlinx/coroutines/z3;-><init>(JLkotlin/coroutines/d;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    iput-object v2, p3, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {v2, p2}, Lkotlinx/coroutines/a4;->b(Lkotlinx/coroutines/z3;Li8/p;)Ljava/lang/Object;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-ne p0, p1, :cond_4

    const/4 v8, 0x0

    invoke-static {v0}, Lkotlin/coroutines/jvm/internal/h;->c(Lkotlin/coroutines/d;)V
    :try_end_1
    .catch Lkotlinx/coroutines/y3; {:try_start_1 .. :try_end_1} :catch_1

    :cond_4
    const/4 v8, 0x5

    const/4 v7, 0x0

    if-ne p0, v1, :cond_5

    const/4 v7, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    return-object v1

    :cond_5
    move-object p3, p0

    move-object p3, p0

    move-object p3, p0

    move-object p3, p0

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    return-object p3

    :catch_1
    move-exception p1

    move-object p0, p3

    move-object p0, p3

    move-object p0, p3

    move-object p0, p3

    :goto_2
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object p2, p1, Lkotlinx/coroutines/y3;->a:Lkotlinx/coroutines/n2;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object p0, p0, Lkotlin/jvm/internal/k1$h;->element:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-ne p2, p0, :cond_6

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    return-object v3

    :cond_6
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    throw p1
.end method

.method public static final f(JLi8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 2
    .param p2    # Li8/p;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p3    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(J",
            "Li8/p<",
            "-",
            "Lkotlinx/coroutines/u0;",
            "-",
            "Lkotlin/coroutines/d<",
            "-TT;>;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-TT;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-static {p0, p1}, Lkotlinx/coroutines/f1;->e(J)J

    move-result-wide p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-static {p0, p1, p2, p3}, Lkotlinx/coroutines/a4;->e(JLi8/p;Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x6

    return-object p0
.end method
