.class public final Lkotlinx/coroutines/b4;
.super Lkotlinx/coroutines/o0;


# static fields
.field public static final b:Lkotlinx/coroutines/b4;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Lkotlinx/coroutines/b4;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {v0}, Lkotlinx/coroutines/b4;-><init>()V

    const/4 v1, 0x5

    move v2, v1

    sput-object v0, Lkotlinx/coroutines/b4;->b:Lkotlinx/coroutines/b4;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Lkotlinx/coroutines/o0;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public d0(Lkotlin/coroutines/g;Ljava/lang/Runnable;)V
    .locals 2
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Runnable;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@sfa@d~@@fK n @@/oblot@u @ M v m@~b~@ @ y  ~tii @4~~~~@@/~@~S~~~  oc@~  @~~~~-b~1@.ro~@i s~ ~oo"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    sget-object p2, Lkotlinx/coroutines/e4;->b:Lkotlinx/coroutines/e4$a;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-interface {p1, p2}, Lkotlin/coroutines/g;->get(Lkotlin/coroutines/g$c;)Lkotlin/coroutines/g$b;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    check-cast p1, Lkotlinx/coroutines/e4;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    const/4 p2, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-boolean p2, p1, Lkotlinx/coroutines/e4;->a:Z

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    const-string p2, "nrhm.uadercrauni  csesdpeio csoydefid hp hwlhsn ec,eaienrseslpkrDi ednrimceDoioi ot ac eu ty nthgd ttlnUnleb eniteicet o fccyeus a.cec p upNsicld sf plfna fd.thsnoeudydnnUis adorpaup.y Iabto oaydn "

    const-string p2, "cus ynuINi.dilclser  uyfeakynh e oifnhidhniiDy cpst dyil noaunacbes  byeeeot tt ff hah .nd dgnapcnsrteasyUalduD.   ctsi papwooserccdhdpo dmenlsUeeiil t,nneost urn  iaresepipdccreop  r.edotoacecnfdu"

    const/4 v1, 0x0

    const-string p2, " eosoelishDsi.ro   .pcfuecce lrpendgieeobnscodnehcedniaeDnstnutscc ulnftdynUaunrtdphtn   dyysyopriu  fecips.dyloaaeiy  tsakbu  to , ed oplida dawnIcenNimci tenf yrd iolsfprn echatcai oharhUe p uea."

    const-string p2, "Dispatchers.Unconfined.dispatch function can only be used by the yield function. If you wrap Unconfined dispatcher in your code, make sure you properly delegate isDispatchNeeded and dispatch calls."

    const/4 v1, 0x5

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    throw p1
.end method

.method public p0(Lkotlin/coroutines/g;)Z
    .locals 2
    .param p1    # Lkotlin/coroutines/g;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p1
.end method

.method public r0(I)Lkotlinx/coroutines/o0;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlinx/coroutines/c2;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x3

    const-string v0, " lacUb.ora scrpdtl eDifitmintnirdelonmadntm lPeerisfs eosiopsp"

    const-string v0, "e nmcaiilmUaaifntsd.olonmplDe tritscplfoenorsteuirdsr sd Pe ip"

    const/4 v2, 0x7

    const-string v0, "freUisude e.alPoiototiltndehauarpic  mrdsislnnDpfntsopmc ei lr"

    const-string v0, "limitedParallelism is not supported for Dispatchers.Unconfined"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    throw p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string v0, "isiUetfpoDcso.necrpnnd"

    const-string v0, "irnpoceisdUfDnsontc.ae"

    const-string v0, "idosUnenqtfDrshpea.icn"

    const-string v0, "Dispatchers.Unconfined"

    const/4 v2, 0x7

    return-object v0
.end method
