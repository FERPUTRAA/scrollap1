.class public final Lkotlinx/coroutines/b2;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()V
    .locals 2
    .annotation build Lkotlinx/coroutines/c2;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "nls / ~~@oo~ @@~@Mot~y~a.~@~ @o~1~@@b@i~S@ @ t@ofm@ K  o@~fv 4s/l  ~ i~ri@b@b~d ~-~~@@~@ ~c  @u~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    return-void
.end method

.method public static final b(Lkotlinx/coroutines/o0;)Ljava/util/concurrent/Executor;
    .locals 3
    .param p0    # Lkotlinx/coroutines/o0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    instance-of v0, p0, Lkotlinx/coroutines/z1;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast v0, Lkotlinx/coroutines/z1;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Lkotlinx/coroutines/z1;->u0()Ljava/util/concurrent/Executor;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_2

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance v0, Lkotlinx/coroutines/l1;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Lkotlinx/coroutines/l1;-><init>(Lkotlinx/coroutines/o0;)V

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public static final c(Ljava/util/concurrent/Executor;)Lkotlinx/coroutines/o0;
    .locals 3
    .param p0    # Ljava/util/concurrent/Executor;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/h;
        name = "from"
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    instance-of v0, p0, Lkotlinx/coroutines/l1;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    check-cast v0, Lkotlinx/coroutines/l1;

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, v0, Lkotlinx/coroutines/l1;->a:Lkotlinx/coroutines/o0;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez v0, :cond_2

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Lkotlinx/coroutines/a2;

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lkotlinx/coroutines/a2;-><init>(Ljava/util/concurrent/Executor;)V

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public static final d(Ljava/util/concurrent/ExecutorService;)Lkotlinx/coroutines/z1;
    .locals 3
    .param p0    # Ljava/util/concurrent/ExecutorService;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/h;
        name = "from"
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    new-instance v0, Lkotlinx/coroutines/a2;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lkotlinx/coroutines/a2;-><init>(Ljava/util/concurrent/Executor;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method
