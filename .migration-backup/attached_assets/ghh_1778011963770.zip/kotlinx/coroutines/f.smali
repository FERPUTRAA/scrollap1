.class public final Lkotlinx/coroutines/f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAwait.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Await.kt\nkotlinx/coroutines/AwaitKt\n+ 2 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,127:1\n37#2:128\n36#2,3:129\n13536#3,2:132\n1849#4,2:134\n*S KotlinDebug\n*F\n+ 1 Await.kt\nkotlinx/coroutines/AwaitKt\n*L\n42#1:128\n42#1:129,3\n54#1:132,2\n66#1:134,2\n*E\n"
.end annotation


# direct methods
.method public static final a(Ljava/util/Collection;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 4
    .param p0    # Ljava/util/Collection;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Collection<",
            "+",
            "Lkotlinx/coroutines/c1<",
            "+TT;>;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/util/List<",
            "+TT;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {}, Lkotlin/collections/u;->E()Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    new-instance v0, Lkotlinx/coroutines/e;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-array v1, v1, [Lkotlinx/coroutines/c1;

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {p0, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz p0, :cond_1

    const/4 v3, 0x5

    check-cast p0, [Lkotlinx/coroutines/c1;

    const/4 v3, 0x5

    invoke-direct {v0, p0}, Lkotlinx/coroutines/e;-><init>([Lkotlinx/coroutines/c1;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/e;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object p0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/NullPointerException;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo p1, "y snbtrTttoeTlanac AltnnJKdllsc orloe>syreleaiVnA oko nn sa-frl oscy.nort_kol.r.Mrc<trptp.ayty tAsui iAo_nauK"

    const-string p1, "ATskenpontnsatirady on_ycotT.sfeMracJ t.toa>oal ryl- nsyAln _A orknrluioc reAsy.Ki l<netKl botplltcurtyna.orV"

    const/4 v3, 0x5

    const-string p1, "stJmrK- ArTtkiMol.dksuyou_rKf tytryrTn<niye t> rsct.l.rereltlolaoo son cepyaoao_nbltA.  apticonlnlyAnnacAVnt "

    const-string p1, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    throw p0
.end method

.method public static final b([Lkotlinx/coroutines/c1;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 3
    .param p0    # [Lkotlinx/coroutines/c1;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([",
            "Lkotlinx/coroutines/c1<",
            "+TT;>;",
            "Lkotlin/coroutines/d<",
            "-",
            "Ljava/util/List<",
            "+TT;>;>;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    array-length v0, p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v0, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    invoke-static {}, Lkotlin/collections/u;->E()Ljava/util/List;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Lkotlinx/coroutines/e;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lkotlinx/coroutines/e;-><init>([Lkotlinx/coroutines/c1;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lkotlinx/coroutines/e;->b(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0
.end method

.method public static final c(Ljava/util/Collection;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 6
    .param p0    # Ljava/util/Collection;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "+",
            "Lkotlinx/coroutines/n2;",
            ">;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    instance-of v0, p1, Lkotlinx/coroutines/f$b;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    check-cast v0, Lkotlinx/coroutines/f$b;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget v1, v0, Lkotlinx/coroutines/f$b;->label:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/high16 v2, -0x80000000

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    and-int v3, v1, v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    sub-int/2addr v1, v2

    const/4 v4, 0x5

    or-int/2addr v5, v4

    iput v1, v0, Lkotlinx/coroutines/f$b;->label:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    new-instance v0, Lkotlinx/coroutines/f$b;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v0, p1}, Lkotlinx/coroutines/f$b;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object p1, v0, Lkotlinx/coroutines/f$b;->result:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v2, v0, Lkotlinx/coroutines/f$b;->label:I

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v3, 0x1

    const/4 v5, 0x7

    if-eqz v2, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-ne v2, v3, :cond_1

    const/4 v5, 0x6

    iget-object p0, v0, Lkotlinx/coroutines/f$b;->L$0:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    check-cast p0, Ljava/util/Iterator;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x3

    move v5, v4

    const-string p1, " ueeo/r/lnt ecuei/voelf/nmtc e/bt /sk/omoor ao wrhi"

    const-string p1, "/ em/seiu/k o at ore/t/ollnbov thce/rinom wr/eifceu"

    const/4 v5, 0x7

    const-string p1, "keei/b ua/fl//cso o rnrcoremuvi toe /et/ oebth/inlw"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    throw p0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    check-cast p0, Ljava/lang/Iterable;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_3
    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz p1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    check-cast p1, Lkotlinx/coroutines/n2;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput-object p0, v0, Lkotlinx/coroutines/f$b;->L$0:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput v3, v0, Lkotlinx/coroutines/f$b;->label:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {p1, v0}, Lkotlinx/coroutines/n2;->join(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-ne p1, v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-object v1

    :cond_4
    const/4 v5, 0x1

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object p0
.end method

.method public static final d([Lkotlinx/coroutines/n2;Lkotlin/coroutines/d;)Ljava/lang/Object;
    .locals 8
    .param p0    # [Lkotlinx/coroutines/n2;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lkotlin/coroutines/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lkotlinx/coroutines/n2;",
            "Lkotlin/coroutines/d<",
            "-",
            "Lkotlin/s2;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    instance-of v0, p1, Lkotlinx/coroutines/f$a;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    check-cast v0, Lkotlinx/coroutines/f$a;

    const/4 v7, 0x5

    iget v1, v0, Lkotlinx/coroutines/f$a;->label:I

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/high16 v2, -0x80000000

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    and-int v3, v1, v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v3, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x5

    sub-int/2addr v1, v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    iput v1, v0, Lkotlinx/coroutines/f$a;->label:I

    const/4 v7, 0x0

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v0, Lkotlinx/coroutines/f$a;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v0, p1}, Lkotlinx/coroutines/f$a;-><init>(Lkotlin/coroutines/d;)V

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object p1, v0, Lkotlinx/coroutines/f$a;->result:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {}, Lkotlin/coroutines/intrinsics/b;->l()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget v2, v0, Lkotlinx/coroutines/f$a;->label:I

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz v2, :cond_2

    const/4 v7, 0x3

    if-ne v2, v3, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget p0, v0, Lkotlinx/coroutines/f$a;->I$1:I

    const/4 v6, 0x4

    move v7, v6

    iget v2, v0, Lkotlinx/coroutines/f$a;->I$0:I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v4, v0, Lkotlinx/coroutines/f$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    check-cast v4, [Lkotlinx/coroutines/n2;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    move-object p1, v4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_2

    :cond_1
    const/4 v6, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const-string p1, "/ui trutbrik/eomhcl/ fo net//oveewiulaooe n ce// sr"

    const-string p1, "s/e oinl buewn ihoorr//ecei/ot/t/mtv krc /ooeeaulf "

    const/4 v7, 0x3

    const-string p1, "orceabiprimc loioe/ltu nr/e ek efne /v//tou ts/o/wh"

    const-string p1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    throw p0

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p1}, Lkotlin/e1;->n(Ljava/lang/Object;)V

    const/4 v7, 0x4

    array-length p1, p0

    const/4 v7, 0x5

    const/4 v2, 0x2

    const/4 v7, 0x3

    const/4 v2, 0x0

    const/4 v7, 0x6

    move v5, p1

    const/4 v7, 0x1

    move v5, p1

    move v5, p1

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    move p0, v5

    move p0, v5

    const/4 v7, 0x3

    move p0, v5

    move p0, v5

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x0

    if-ge v2, p0, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    aget-object v4, p1, v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput-object p1, v0, Lkotlinx/coroutines/f$a;->L$0:Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    iput v2, v0, Lkotlinx/coroutines/f$a;->I$0:I

    const/4 v6, 0x2

    move v7, v6

    iput p0, v0, Lkotlinx/coroutines/f$a;->I$1:I

    const/4 v7, 0x2

    iput v3, v0, Lkotlinx/coroutines/f$a;->label:I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v4, v0}, Lkotlinx/coroutines/n2;->join(Lkotlin/coroutines/d;)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-ne v4, v1, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-object v1

    :cond_3
    :goto_2
    const/4 v7, 0x3

    add-int/2addr v2, v3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto :goto_1

    :cond_4
    const/4 v7, 0x3

    sget-object p0, Lkotlin/s2;->a:Lkotlin/s2;

    const/4 v6, 0x2

    move v7, v6

    return-object p0
.end method
