.class public final Lkotlinx/coroutines/f2;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlinx/coroutines/g2;


# instance fields
.field private final a:Lkotlinx/coroutines/a3;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lkotlinx/coroutines/a3;)V
    .locals 2
    .param p1    # Lkotlinx/coroutines/a3;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lkotlinx/coroutines/f2;->a:Lkotlinx/coroutines/a3;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public isActive()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~os~oubt~/@ @   l  o~@ ~/ ~f@r@i~~~~ o~@ ~d~@@1~b@ @  @@@~@~~y~t.@ ~ li@iS~c ombKa ~-s@@4~fo@@Mv"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public k()Lkotlinx/coroutines/a3;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lkotlinx/coroutines/f2;->a:Lkotlinx/coroutines/a3;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method
