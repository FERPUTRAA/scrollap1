.class public final Lcom/google/android/material/R$interpolator;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "interpolator"
.end annotation


# static fields
.field public static final btn_checkbox_checked_mtrl_animation_interpolator_0:I = 0x7f0b0000

.field public static final btn_checkbox_checked_mtrl_animation_interpolator_1:I = 0x7f0b0001

.field public static final btn_checkbox_unchecked_mtrl_animation_interpolator_0:I = 0x7f0b0002

.field public static final btn_checkbox_unchecked_mtrl_animation_interpolator_1:I = 0x7f0b0003

.field public static final btn_radio_to_off_mtrl_animation_interpolator_0:I = 0x7f0b0004

.field public static final btn_radio_to_on_mtrl_animation_interpolator_0:I = 0x7f0b0005

.field public static final fast_out_slow_in:I = 0x7f0b0006

.field public static final mtrl_fast_out_linear_in:I = 0x7f0b0007

.field public static final mtrl_fast_out_slow_in:I = 0x7f0b0008

.field public static final mtrl_linear:I = 0x7f0b0009

.field public static final mtrl_linear_out_slow_in:I = 0x7f0b000a


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method
