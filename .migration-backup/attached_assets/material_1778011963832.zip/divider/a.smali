.class public Lcom/google/android/material/divider/a;
.super Landroidx/recyclerview/widget/RecyclerView$o;


# static fields
.field public static final i:I = 0x0

.field public static final j:I = 0x1

.field private static final k:I


# instance fields
.field private a:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private b:I

.field private c:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private d:I

.field private e:I

.field private f:I

.field private g:Z

.field private final h:Landroid/graphics/Rect;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_MaterialDivider:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput v0, Lcom/google/android/material/divider/a;->k:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0, p1, v0, p2}, Lcom/google/android/material/divider/a;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x4

    move v2, v1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget v0, Lcom/google/android/material/R$attr;->materialDividerStyle:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2, v0, p3}, Lcom/google/android/material/divider/a;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$o;-><init>()V

    const/4 v8, 0x4

    new-instance v0, Landroid/graphics/Rect;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    iput-object v0, p0, Lcom/google/android/material/divider/a;->h:Landroid/graphics/Rect;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    sget-object v3, Lcom/google/android/material/R$styleable;->MaterialDivider:[I

    const/4 v8, 0x5

    sget v5, Lcom/google/android/material/divider/a;->k:I

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v0, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    new-array v6, v0, [I

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    move v4, p3

    move v4, p3

    const/4 v8, 0x0

    move v4, p3

    move v4, p3

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static/range {v1 .. v6}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->MaterialDivider_dividerColor:I

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {p1, p2, p3}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object p3

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p3}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result p3

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    iput p3, p0, Lcom/google/android/material/divider/a;->c:I

    const/4 v8, 0x5

    const/4 v7, 0x3

    sget p3, Lcom/google/android/material/R$styleable;->MaterialDivider_dividerThickness:I

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    sget v1, Lcom/google/android/material/R$dimen;->material_divider_thickness:I

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p1, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p2, p3, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    iput p1, p0, Lcom/google/android/material/divider/a;->b:I

    const/4 v7, 0x6

    shl-int/2addr v8, v7

    sget p1, Lcom/google/android/material/R$styleable;->MaterialDivider_dividerInsetStart:I

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p2, p1, v0}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    iput p1, p0, Lcom/google/android/material/divider/a;->e:I

    const/4 v8, 0x2

    sget p1, Lcom/google/android/material/R$styleable;->MaterialDivider_dividerInsetEnd:I

    const/4 v8, 0x7

    const/4 v7, 0x3

    invoke-virtual {p2, p1, v0}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    iput p1, p0, Lcom/google/android/material/divider/a;->f:I

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    sget p1, Lcom/google/android/material/R$styleable;->MaterialDivider_lastItemDecorated:I

    const/4 p3, 0x0

    const/4 p3, 0x1

    shl-int/2addr v7, p3

    const/4 v8, 0x1

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/divider/a;->g:Z

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-instance p1, Landroid/graphics/drawable/ShapeDrawable;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p1}, Landroid/graphics/drawable/ShapeDrawable;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    iput-object p1, p0, Lcom/google/android/material/divider/a;->a:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x1

    iget p1, p0, Lcom/google/android/material/divider/a;->c:I

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/divider/a;->i(I)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p0, p4}, Lcom/google/android/material/divider/a;->r(I)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    return-void
.end method

.method private a(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 9
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "1~s~c ~  ~ ~uoai@~t ir ~@ ~f/~i~@ @l~oKl@o bo~nb~@@~@4@@-@S@bv~@~d@ ~~y@@osm/.@ t@  ~M~@@ f~ o ~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView;->getClipToPadding()Z

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-eqz v0, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getPaddingTop()I

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p2}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    sub-int/2addr v2, v3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p2}, Landroid/view/View;->getPaddingLeft()I

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p2}, Landroid/view/View;->getWidth()I

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p2}, Landroid/view/View;->getPaddingRight()I

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    sub-int/2addr v4, v5

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p1, v3, v0, v4, v2}, Landroid/graphics/Canvas;->clipRect(IIII)Z

    const/4 v8, 0x7

    goto :goto_0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    move-result v2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    move v0, v1

    move v0, v1

    const/4 v8, 0x7

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v7, 0x2

    const/4 v8, 0x6

    iget v3, p0, Lcom/google/android/material/divider/a;->e:I

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    add-int/2addr v0, v3

    const/4 v8, 0x4

    iget v3, p0, Lcom/google/android/material/divider/a;->f:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    sub-int/2addr v2, v3

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-ge v1, v3, :cond_1

    const/4 v7, 0x7

    const/4 v7, 0x6

    invoke-virtual {p2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$p;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object v6, p0, Lcom/google/android/material/divider/a;->h:Landroid/graphics/Rect;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v5, v4, v6}, Landroidx/recyclerview/widget/RecyclerView$p;->getDecoratedBoundsWithMargins(Landroid/view/View;Landroid/graphics/Rect;)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object v5, p0, Lcom/google/android/material/divider/a;->h:Landroid/graphics/Rect;

    const/4 v7, 0x2

    or-int/2addr v8, v7

    iget v5, v5, Landroid/graphics/Rect;->right:I

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v4}, Landroid/view/View;->getTranslationX()F

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x0

    add-int/2addr v5, v4

    const/4 v8, 0x2

    iget-object v4, p0, Lcom/google/android/material/divider/a;->a:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x1

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    sub-int v4, v5, v4

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget v6, p0, Lcom/google/android/material/divider/a;->b:I

    const/4 v7, 0x5

    sub-int/2addr v4, v6

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-object v6, p0, Lcom/google/android/material/divider/a;->a:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v6, v4, v0, v5, v2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object v4, p0, Lcom/google/android/material/divider/a;->a:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v4, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    goto :goto_1

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    return-void
.end method

.method private b(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 9
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v8, 0x4

    const/4 v7, 0x2

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView;->getClipToPadding()Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v1, 0x0

    move v8, v1

    const/4 v7, 0x7

    xor-int/2addr v8, v7

    if-eqz v0, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p2}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getWidth()I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p2}, Landroid/view/View;->getPaddingRight()I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    sub-int/2addr v2, v3

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p2}, Landroid/view/View;->getPaddingTop()I

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    move-result v4

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {p2}, Landroid/view/View;->getPaddingBottom()I

    move-result v5

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    sub-int/2addr v4, v5

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p1, v0, v3, v2, v4}, Landroid/graphics/Canvas;->clipRect(IIII)Z

    const/4 v8, 0x4

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v8, 0x6

    invoke-virtual {p2}, Landroid/view/View;->getWidth()I

    move-result v2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    move v0, v1

    move v0, v1

    const/4 v8, 0x4

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v7, 0x1

    const/4 v7, 0x5

    invoke-static {p2}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/4 v4, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-ne v3, v4, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x0

    goto :goto_1

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    move v4, v1

    const/4 v8, 0x2

    move v4, v1

    move v4, v1

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz v4, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget v3, p0, Lcom/google/android/material/divider/a;->f:I

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    goto :goto_2

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x6

    iget v3, p0, Lcom/google/android/material/divider/a;->e:I

    :goto_2
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    add-int/2addr v0, v3

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eqz v4, :cond_3

    const/4 v8, 0x4

    iget v3, p0, Lcom/google/android/material/divider/a;->e:I

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    goto :goto_3

    :cond_3
    const/4 v8, 0x0

    iget v3, p0, Lcom/google/android/material/divider/a;->f:I

    :goto_3
    const/4 v8, 0x7

    sub-int/2addr v2, v3

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p2}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    iget-boolean v4, p0, Lcom/google/android/material/divider/a;->g:Z

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-eqz v4, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto :goto_4

    :cond_4
    const/4 v8, 0x3

    add-int/lit8 v3, v3, -0x1

    :goto_4
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-ge v1, v3, :cond_5

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p2, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-object v5, p0, Lcom/google/android/material/divider/a;->h:Landroid/graphics/Rect;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {p2, v4, v5}, Landroidx/recyclerview/widget/RecyclerView;->getDecoratedBoundsWithMargins(Landroid/view/View;Landroid/graphics/Rect;)V

    const/4 v7, 0x3

    shl-int/2addr v8, v7

    iget-object v5, p0, Lcom/google/android/material/divider/a;->h:Landroid/graphics/Rect;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget v5, v5, Landroid/graphics/Rect;->bottom:I

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v4}, Landroid/view/View;->getTranslationY()F

    move-result v4

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    add-int/2addr v5, v4

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-object v4, p0, Lcom/google/android/material/divider/a;->a:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x2

    const/4 v7, 0x5

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    sub-int v4, v5, v4

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget v6, p0, Lcom/google/android/material/divider/a;->b:I

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    sub-int/2addr v4, v6

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object v6, p0, Lcom/google/android/material/divider/a;->a:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v6, v0, v4, v2, v5}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-object v4, p0, Lcom/google/android/material/divider/a;->a:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v4, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    goto :goto_4

    :cond_5
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    const/4 v7, 0x1

    and-int/2addr v8, v7

    return-void
.end method


# virtual methods
.method public c()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/divider/a;->c:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public d()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/divider/a;->f:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public e()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/divider/a;->e:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public f()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v1, 0x1

    const/4 v1, 0x1

    iget v0, p0, Lcom/google/android/material/divider/a;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/divider/a;->d:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$c0;)V
    .locals 2
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroidx/recyclerview/widget/RecyclerView$c0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    const/4 p2, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1, p2, p2, p2, p2}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget p2, p0, Lcom/google/android/material/divider/a;->d:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 p3, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-ne p2, p3, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget-object p2, p0, Lcom/google/android/material/divider/a;->a:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p2}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result p2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget p3, p0, Lcom/google/android/material/divider/a;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    add-int/2addr p2, p3

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p2, p1, Landroid/graphics/Rect;->bottom:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p2, p0, Lcom/google/android/material/divider/a;->a:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p2}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result p2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget p3, p0, Lcom/google/android/material/divider/a;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    add-int/2addr p2, p3

    iput p2, p1, Landroid/graphics/Rect;->right:I

    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public h()Z
    .locals 3

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/divider/a;->g:Z

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public i(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/android/material/divider/a;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/divider/a;->a:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x0

    const/4 v1, 0x2

    invoke-static {v0}, Landroidx/core/graphics/drawable/d;->r(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/material/divider/a;->a:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/d;->n(Landroid/graphics/drawable/Drawable;I)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public j(Landroid/content/Context;I)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v1, 0x0

    invoke-static {p1, p2}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/divider/a;->i(I)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public k(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/divider/a;->f:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public l(Landroid/content/Context;I)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/divider/a;->k(I)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public m(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/divider/a;->e:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public n(Landroid/content/Context;I)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v1, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/divider/a;->m(I)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public o(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/divider/a;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public onDraw(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$c0;)V
    .locals 3
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroidx/recyclerview/widget/RecyclerView$c0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p2}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$p;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez p3, :cond_0

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget p3, p0, Lcom/google/android/material/divider/a;->d:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-ne p3, v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/divider/a;->b(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/divider/a;->a(Landroid/graphics/Canvas;Landroidx/recyclerview/widget/RecyclerView;)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public p(Landroid/content/Context;I)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/divider/a;->o(I)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public q(Z)V
    .locals 2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/divider/a;->g:Z

    const/4 v1, 0x4

    const/4 v0, 0x1

    return-void
.end method

.method public r(I)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz p1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-ne p1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const-string/jumbo v2, "i sntnidoo:vaatiIre l"

    const/4 v4, 0x6

    const-string v2, ":idmenotirIn ialaot v"

    const-string v2, "Invalid orientation: "

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    shr-int/2addr v4, v3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const-string/jumbo p1, "tIeRosI rN hbRuT   ATmhrILodC AEOitOlo V.eLe"

    const-string p1, "IthmhA biooZeRsCIldrTL OVILrNutTA   R.ee E O"

    const/4 v4, 0x0

    const-string p1, "esVb.bR hRreh OoZtAA LrIHo IITN CTL t iOeldE"

    const-string p1, ". It should be either HORIZONTAL or VERTICAL"

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw v0

    :cond_1
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput p1, p0, Lcom/google/android/material/divider/a;->d:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void
.end method
