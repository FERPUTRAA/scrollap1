.class public Lcom/google/android/material/divider/MaterialDivider;
.super Landroid/view/View;


# static fields
.field private static final f:I


# instance fields
.field private final a:Lcom/google/android/material/shape/j;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private b:I

.field private c:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private d:I

.field private e:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_MaterialDivider:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    sput v0, Lcom/google/android/material/divider/MaterialDivider;->f:I

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/divider/MaterialDivider;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/R$attr;->materialDividerStyle:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/divider/MaterialDivider;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    sget v4, Lcom/google/android/material/divider/MaterialDivider;->f:I

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {p1, p2, p3, v4}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-direct {p0, p1, p2, p3}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v8, 0x7

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    new-instance v0, Lcom/google/android/material/shape/j;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {v0}, Lcom/google/android/material/shape/j;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/google/android/material/divider/MaterialDivider;->a:Lcom/google/android/material/shape/j;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    sget-object v2, Lcom/google/android/material/R$styleable;->MaterialDivider:[I

    const/4 v8, 0x2

    const/4 v6, 0x0

    const/4 v8, 0x1

    and-int/2addr v7, v6

    const/4 v8, 0x5

    new-array v5, v6, [I

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    move v3, p3

    move v3, p3

    const/4 v8, 0x5

    move v3, p3

    move v3, p3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    sget p3, Lcom/google/android/material/R$styleable;->MaterialDivider_dividerThickness:I

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    sget v1, Lcom/google/android/material/R$dimen;->material_divider_thickness:I

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {p2, p3, v0}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    iput p3, p0, Lcom/google/android/material/divider/MaterialDivider;->b:I

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    sget p3, Lcom/google/android/material/R$styleable;->MaterialDivider_dividerInsetStart:I

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p2, p3, v6}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result p3

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    iput p3, p0, Lcom/google/android/material/divider/MaterialDivider;->d:I

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    sget p3, Lcom/google/android/material/R$styleable;->MaterialDivider_dividerInsetEnd:I

    const/4 v8, 0x2

    const/4 v7, 0x7

    invoke-virtual {p2, p3, v6}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result p3

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    iput p3, p0, Lcom/google/android/material/divider/MaterialDivider;->e:I

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    sget p3, Lcom/google/android/material/R$styleable;->MaterialDivider_dividerColor:I

    const/4 v8, 0x3

    invoke-static {p1, p2, p3}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result p1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/divider/MaterialDivider;->setDividerColor(I)V

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    return-void
.end method


# virtual methods
.method public getDividerColor()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/divider/MaterialDivider;->c:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public getDividerInsetEnd()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/divider/MaterialDivider;->e:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public getDividerInsetStart()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    iget v0, p0, Lcom/google/android/material/divider/MaterialDivider;->d:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public getDividerThickness()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/divider/MaterialDivider;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 8
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x5

    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v2, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-ne v0, v2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    move v2, v1

    move v2, v1

    const/4 v7, 0x7

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget v0, p0, Lcom/google/android/material/divider/MaterialDivider;->e:I

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    goto :goto_1

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget v0, p0, Lcom/google/android/material/divider/MaterialDivider;->d:I

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x0

    if-eqz v2, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget v3, p0, Lcom/google/android/material/divider/MaterialDivider;->d:I

    const/4 v6, 0x0

    shr-int/2addr v7, v6

    goto :goto_2

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget v3, p0, Lcom/google/android/material/divider/MaterialDivider;->e:I

    :goto_2
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    sub-int/2addr v2, v3

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/google/android/material/divider/MaterialDivider;->a:Lcom/google/android/material/shape/j;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getBottom()I

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getTop()I

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    sub-int/2addr v4, v5

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v3, v0, v1, v2, v4}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/android/material/divider/MaterialDivider;->a:Lcom/google/android/material/shape/j;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->draw(Landroid/graphics/Canvas;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    return-void
.end method

.method protected onMeasure(II)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-super {p0, p1, p2}, Landroid/view/View;->onMeasure(II)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/high16 v0, -0x80000000

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eq p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez p1, :cond_2

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget p1, p0, Lcom/google/android/material/divider/MaterialDivider;->b:I

    if-lez p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eq p2, p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    move p2, p1

    move p2, p1

    const/4 v2, 0x1

    move p2, p1

    move p2, p1

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public setDividerColor(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/divider/MaterialDivider;->c:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/android/material/divider/MaterialDivider;->c:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/divider/MaterialDivider;->a:Lcom/google/android/material/shape/j;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public setDividerColorResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0, p1}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/divider/MaterialDivider;->setDividerColor(I)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public setDividerInsetEnd(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/divider/MaterialDivider;->e:I

    const/4 v1, 0x2

    return-void
.end method

.method public setDividerInsetEndResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/divider/MaterialDivider;->setDividerInsetEnd(I)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public setDividerInsetStart(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/divider/MaterialDivider;->d:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public setDividerInsetStartResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/divider/MaterialDivider;->setDividerInsetStart(I)V

    const/4 v2, 0x3

    return-void
.end method

.method public setDividerThickness(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/divider/MaterialDivider;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eq v0, p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/android/material/divider/MaterialDivider;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public setDividerThicknessResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/divider/MaterialDivider;->setDividerThickness(I)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method
