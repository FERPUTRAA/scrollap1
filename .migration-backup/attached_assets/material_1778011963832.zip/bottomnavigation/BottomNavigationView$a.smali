.class Lcom/google/android/material/bottomnavigation/BottomNavigationView$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/internal/y$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/bottomnavigation/BottomNavigationView;->l()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/bottomnavigation/BottomNavigationView;


# direct methods
.method constructor <init>(Lcom/google/android/material/bottomnavigation/BottomNavigationView;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationView$a;->a:Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;Landroidx/core/view/y2;Lcom/google/android/material/internal/y$f;)Landroidx/core/view/y2;
    .locals 7
    .param p2    # Landroidx/core/view/y2;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/internal/y$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " 4sfn~ f@~o~~~~ ~~ri@liioa~~ @ @@ /l@@~~ @1@d~~ @@y~bv@@buoc~@~  t  @@ omsK~~/tM S~  o~@ b~@@.@-"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    iget v0, p3, Lcom/google/android/material/internal/y$f;->d:I

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p2}, Landroidx/core/view/y2;->o()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    add-int/2addr v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    iput v0, p3, Lcom/google/android/material/internal/y$f;->d:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-static {p1}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v1, 0x1

    const/4 v6, 0x3

    if-ne v0, v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p2}, Landroidx/core/view/y2;->p()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p2}, Landroidx/core/view/y2;->q()I

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v3, p3, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v5, 0x4

    move v6, v5

    if-eqz v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    move v4, v2

    move v4, v2

    const/4 v6, 0x4

    move v4, v2

    move v4, v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    move v4, v0

    move v4, v0

    const/4 v6, 0x3

    move v4, v0

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    add-int/2addr v3, v4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iput v3, p3, Lcom/google/android/material/internal/y$f;->a:I

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget v3, p3, Lcom/google/android/material/internal/y$f;->c:I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz v1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    goto :goto_2

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    move v0, v2

    move v0, v2

    const/4 v6, 0x0

    move v0, v2

    move v0, v2

    :goto_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    add-int/2addr v3, v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    iput v3, p3, Lcom/google/android/material/internal/y$f;->c:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    invoke-virtual {p3, p1}, Lcom/google/android/material/internal/y$f;->a(Landroid/view/View;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-object p2
.end method
