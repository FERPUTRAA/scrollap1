.class public interface abstract Lcom/google/android/material/bottomnavigation/BottomNavigationView$c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/navigation/NavigationBarView$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/bottomnavigation/BottomNavigationView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "c"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation
