.class public Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;
.super Lcom/google/android/material/navigation/NavigationBarMenuView;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# instance fields
.field private final G:I

.field private final H:I

.field private final I:I

.field private final J:I

.field private K:Z

.field private L:[I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/navigation/NavigationBarMenuView;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, -0x2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p1, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/16 v0, 0x11

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput v0, p1, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget v0, Lcom/google/android/material/R$dimen;->design_bottom_navigation_item_max_width:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->G:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget v0, Lcom/google/android/material/R$dimen;->design_bottom_navigation_item_min_width:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->H:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget v0, Lcom/google/android/material/R$dimen;->design_bottom_navigation_active_item_max_width:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput v0, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->I:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget v0, Lcom/google/android/material/R$dimen;->design_bottom_navigation_active_item_min_width:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->J:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p1, 0x5

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-array p1, p1, [I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->L:[I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method protected g(Landroid/content/Context;)Lcom/google/android/material/navigation/NavigationBarItemView;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s/~~o ~~i~@~~ ~@@@Mr@~@.  o@u a@@~ ~o~4~ -@~t nt@s  1@o i~b /K@l yb~ v@om@~l f~~~@ c Sb@~d@iof"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    new-instance v0, Lcom/google/android/material/bottomnavigation/BottomNavigationItemView;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0, p1}, Lcom/google/android/material/bottomnavigation/BottomNavigationItemView;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method protected onLayout(ZIIII)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    sub-int/2addr p4, p2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    sub-int/2addr p5, p3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 p2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    move p3, p2

    move p3, p2

    const/4 v5, 0x5

    move p3, p2

    move p3, p2

    const/4 v5, 0x2

    move v0, p3

    move v0, p3

    const/4 v5, 0x6

    move v0, p3

    move v0, p3

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-ge p3, p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0, p3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/16 v3, 0x8

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-ne v2, v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_2

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-ne v2, v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    sub-int v2, p4, v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v1}, Landroid/view/View;->getMeasuredWidth()I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    sub-int v3, v2, v3

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1, v3, p2, v2, p5}, Landroid/view/View;->layout(IIII)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1}, Landroid/view/View;->getMeasuredWidth()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    add-int/2addr v2, v0

    const/4 v5, 0x7

    invoke-virtual {v1, v0, p2, v2, p5}, Landroid/view/View;->layout(IIII)V

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroid/view/View;->getMeasuredWidth()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    add-int/2addr v0, v1

    :goto_2
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int/lit8 p3, p3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-void
.end method

.method protected onMeasure(II)V
    .locals 13

    const/4 v12, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getMenu()Landroidx/appcompat/view/menu/g;

    move-result-object v0

    const/4 v12, 0x7

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    const/4 v12, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->H()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v12, 0x7

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v12, 0x7

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v12, 0x5

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v2

    const/4 v12, 0x0

    const/high16 v3, 0x40000000    # 2.0f

    const/4 v12, 0x5

    invoke-static {v2, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v4

    const/4 v12, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getLabelVisibilityMode()I

    move-result v5

    const/4 v12, 0x0

    invoke-virtual {p0, v5, v0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->l(II)Z

    move-result v5

    const/4 v12, 0x3

    const/16 v6, 0x8

    const/4 v12, 0x0

    const/4 v7, 0x1

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v12, 0x6

    if-eqz v5, :cond_6

    const/4 v12, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->u()Z

    move-result v5

    const/4 v12, 0x5

    if-eqz v5, :cond_6

    const/4 v12, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getSelectedItemPosition()I

    move-result v5

    const/4 v12, 0x6

    invoke-virtual {p0, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    const/4 v12, 0x4

    iget v9, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->J:I

    const/4 v12, 0x1

    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    move-result v10

    const/4 v12, 0x3

    if-eq v10, v6, :cond_0

    const/4 v12, 0x4

    iget v10, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->I:I

    const/4 v12, 0x0

    const/high16 v11, -0x80000000

    const/4 v12, 0x2

    invoke-static {v10, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v10

    const/4 v12, 0x3

    invoke-virtual {v5, v10, v4}, Landroid/view/View;->measure(II)V

    const/4 v12, 0x3

    invoke-virtual {v5}, Landroid/view/View;->getMeasuredWidth()I

    move-result v10

    const/4 v12, 0x4

    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v9

    :cond_0
    const/4 v12, 0x0

    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    move-result v5

    const/4 v12, 0x2

    if-eq v5, v6, :cond_1

    const/4 v12, 0x0

    move v5, v7

    move v5, v7

    const/4 v12, 0x2

    goto :goto_0

    :cond_1
    const/4 v12, 0x1

    move v5, v8

    move v5, v8

    move v5, v8

    move v5, v8

    :goto_0
    const/4 v12, 0x1

    sub-int/2addr v0, v5

    const/4 v12, 0x7

    iget v5, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->H:I

    const/4 v12, 0x4

    mul-int/2addr v5, v0

    const/4 v12, 0x7

    sub-int v5, p1, v5

    const/4 v12, 0x4

    iget v10, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->I:I

    invoke-static {v9, v10}, Ljava/lang/Math;->min(II)I

    move-result v9

    const/4 v12, 0x2

    invoke-static {v5, v9}, Ljava/lang/Math;->min(II)I

    move-result v5

    const/4 v12, 0x4

    sub-int/2addr p1, v5

    const/4 v12, 0x1

    if-nez v0, :cond_2

    const/4 v12, 0x6

    move v9, v7

    move v9, v7

    move v9, v7

    const/4 v12, 0x2

    goto :goto_1

    :cond_2
    const/4 v12, 0x5

    move v9, v0

    move v9, v0

    move v9, v0

    move v9, v0

    :goto_1
    div-int v9, p1, v9

    const/4 v12, 0x2

    iget v10, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->G:I

    const/4 v12, 0x7

    invoke-static {v9, v10}, Ljava/lang/Math;->min(II)I

    move-result v9

    const/4 v12, 0x2

    mul-int/2addr v0, v9

    const/4 v12, 0x6

    sub-int/2addr p1, v0

    const/4 v12, 0x0

    move v0, v8

    move v0, v8

    move v0, v8

    move v0, v8

    :goto_2
    const/4 v12, 0x6

    if-ge v0, v1, :cond_a

    const/4 v12, 0x3

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v10

    const/4 v12, 0x1

    invoke-virtual {v10}, Landroid/view/View;->getVisibility()I

    move-result v10

    const/4 v12, 0x3

    if-eq v10, v6, :cond_4

    iget-object v10, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->L:[I

    const/4 v12, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/navigation/NavigationBarMenuView;->getSelectedItemPosition()I

    move-result v11

    const/4 v12, 0x2

    if-ne v0, v11, :cond_3

    const/4 v12, 0x5

    move v11, v5

    move v11, v5

    move v11, v5

    move v11, v5

    const/4 v12, 0x2

    goto :goto_3

    :cond_3
    const/4 v12, 0x4

    move v11, v9

    move v11, v9

    move v11, v9

    move v11, v9

    :goto_3
    const/4 v12, 0x4

    aput v11, v10, v0

    const/4 v12, 0x2

    if-lez p1, :cond_5

    const/4 v12, 0x1

    iget-object v10, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->L:[I

    const/4 v12, 0x2

    aget v11, v10, v0

    const/4 v12, 0x7

    add-int/2addr v11, v7

    const/4 v12, 0x2

    aput v11, v10, v0

    const/4 v12, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v12, 0x3

    goto :goto_4

    :cond_4
    const/4 v12, 0x3

    iget-object v10, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->L:[I

    const/4 v12, 0x1

    aput v8, v10, v0

    :cond_5
    :goto_4
    const/4 v12, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v12, 0x2

    goto :goto_2

    :cond_6
    const/4 v12, 0x2

    if-nez v0, :cond_7

    const/4 v12, 0x4

    goto :goto_5

    :cond_7
    const/4 v12, 0x6

    move v7, v0

    move v7, v0

    move v7, v0

    :goto_5
    const/4 v12, 0x7

    div-int v5, p1, v7

    const/4 v12, 0x0

    iget v7, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->I:I

    const/4 v12, 0x2

    invoke-static {v5, v7}, Ljava/lang/Math;->min(II)I

    move-result v5

    mul-int/2addr v0, v5

    const/4 v12, 0x0

    sub-int/2addr p1, v0

    const/4 v12, 0x1

    move v0, v8

    move v0, v8

    move v0, v8

    :goto_6
    const/4 v12, 0x0

    if-ge v0, v1, :cond_a

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    const/4 v12, 0x7

    invoke-virtual {v7}, Landroid/view/View;->getVisibility()I

    move-result v7

    const/4 v12, 0x4

    if-eq v7, v6, :cond_8

    iget-object v7, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->L:[I

    const/4 v12, 0x3

    aput v5, v7, v0

    const/4 v12, 0x7

    if-lez p1, :cond_9

    const/4 v12, 0x2

    add-int/lit8 v9, v5, 0x1

    aput v9, v7, v0

    const/4 v12, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v12, 0x4

    goto :goto_7

    :cond_8
    const/4 v12, 0x3

    iget-object v7, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->L:[I

    const/4 v12, 0x1

    aput v8, v7, v0

    :cond_9
    :goto_7
    const/4 v12, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v12, 0x7

    goto :goto_6

    :cond_a
    move p1, v8

    move p1, v8

    const/4 v12, 0x3

    move v0, p1

    move v0, p1

    move v0, p1

    move v0, p1

    :goto_8
    const/4 v12, 0x2

    if-ge p1, v1, :cond_c

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v5

    const/4 v12, 0x6

    invoke-virtual {v5}, Landroid/view/View;->getVisibility()I

    move-result v7

    const/4 v12, 0x1

    if-ne v7, v6, :cond_b

    const/4 v12, 0x5

    goto :goto_9

    :cond_b
    iget-object v7, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->L:[I

    const/4 v12, 0x0

    aget v7, v7, p1

    invoke-static {v7, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v7

    const/4 v12, 0x7

    invoke-virtual {v5, v7, v4}, Landroid/view/View;->measure(II)V

    const/4 v12, 0x0

    invoke-virtual {v5}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v7

    const/4 v12, 0x3

    invoke-virtual {v5}, Landroid/view/View;->getMeasuredWidth()I

    move-result v9

    const/4 v12, 0x4

    iput v9, v7, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v12, 0x4

    invoke-virtual {v5}, Landroid/view/View;->getMeasuredWidth()I

    move-result v5

    const/4 v12, 0x6

    add-int/2addr v0, v5

    :goto_9
    const/4 v12, 0x0

    add-int/lit8 p1, p1, 0x1

    const/4 v12, 0x7

    goto :goto_8

    :cond_c
    const/4 v12, 0x7

    invoke-static {v0, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    const/4 v12, 0x3

    invoke-static {v0, p1, v8}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result p1

    const/4 v12, 0x6

    invoke-static {v2, p2, v8}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result p2

    const/4 v12, 0x3

    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    const/4 v12, 0x5

    return-void
.end method

.method public setItemHorizontalTranslationEnabled(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->K:Z

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public u()Z
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/bottomnavigation/BottomNavigationMenuView;->K:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method
