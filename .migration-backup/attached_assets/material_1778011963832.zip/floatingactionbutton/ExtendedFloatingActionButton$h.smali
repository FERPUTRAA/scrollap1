.class Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;
.super Lcom/google/android/material/floatingactionbutton/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "h"
.end annotation


# instance fields
.field private final g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

.field private final h:Z

.field final synthetic i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;


# direct methods
.method constructor <init>(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;Lcom/google/android/material/floatingactionbutton/a;Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v0, 0x4

    or-int/2addr v1, v0

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/floatingactionbutton/b;-><init>(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;Lcom/google/android/material/floatingactionbutton/a;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-boolean p4, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->h:Z

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public b()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  su l~m~~ @b~ @ d~K@1c@ @@@oa ~fb~b@ y~o@sit@@.o~@4~M@~@@~no~~~v~ ~@i@S~@   ~fr~/o @@i/~o t l-~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-boolean v1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->h:Z

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->w(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;Z)Z

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-nez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

    const/4 v6, 0x5

    invoke-interface {v1}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;->a()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v1, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v5, 0x4

    shr-int/2addr v6, v5

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v1}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;->a()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget v1, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v6, 0x3

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-interface {v1}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;->getPaddingStart()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v2}, Landroid/view/View;->getPaddingTop()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-interface {v3}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;->getPaddingEnd()I

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v4, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v4}, Landroid/view/View;->getPaddingBottom()I

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0, v1, v2, v3, v4}, Landroidx/core/view/k1;->d2(Landroid/view/View;IIII)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v6, 0x3

    invoke-virtual {v0}, Landroid/view/View;->requestLayout()V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-void
.end method

.method public d()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->h:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v1}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->v(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eq v0, v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/button/MaterialButton;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x1

    :goto_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->h:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/R$animator;->mtrl_extended_fab_change_size_expand_motion_spec:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget v0, Lcom/google/android/material/R$animator;->mtrl_extended_fab_change_size_collapse_motion_spec:I

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public i()V
    .locals 4

    const/4 v3, 0x4

    invoke-super {p0}, Lcom/google/android/material/floatingactionbutton/b;->i()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->x(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;Z)Z

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setHorizontallyScrolling(Z)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {v1}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;->a()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, v1, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-interface {v1}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;->a()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v1, v1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v2, 0x2

    move v3, v2

    return-void
.end method

.method public k()Landroid/animation/AnimatorSet;
    .locals 12
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v11, 0x2

    const/4 v10, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/b;->a()Lcom/google/android/material/animation/h;

    move-result-object v0

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x2

    const-string/jumbo v1, "wdsmi"

    const-string/jumbo v1, "idstw"

    const/4 v11, 0x4

    const-string/jumbo v1, "ihwdo"

    const-string/jumbo v1, "width"

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    const/4 v3, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v4, 0x2

    const/4 v11, 0x4

    const/4 v5, 0x0

    const/4 v11, 0x0

    move v10, v5

    move v10, v5

    if-eqz v2, :cond_0

    const/4 v10, 0x2

    move v11, v10

    invoke-virtual {v0, v1}, Lcom/google/android/material/animation/h;->g(Ljava/lang/String;)[Landroid/animation/PropertyValuesHolder;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x5

    aget-object v6, v2, v5

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    new-array v7, v4, [F

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    iget-object v8, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v11, 0x3

    invoke-virtual {v8}, Landroid/view/View;->getWidth()I

    move-result v8

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    int-to-float v8, v8

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    aput v8, v7, v5

    const/4 v11, 0x6

    const/4 v10, 0x5

    iget-object v8, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

    const/4 v10, 0x5

    and-int/2addr v11, v10

    invoke-interface {v8}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;->f()I

    move-result v8

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    int-to-float v8, v8

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x6

    aput v8, v7, v3

    invoke-virtual {v6, v7}, Landroid/animation/PropertyValuesHolder;->setFloatValues([F)V

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/animation/h;->l(Ljava/lang/String;[Landroid/animation/PropertyValuesHolder;)V

    :cond_0
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    const-string/jumbo v1, "mehthb"

    const-string/jumbo v1, "hhemgt"

    const/4 v11, 0x0

    const-string/jumbo v1, "uhtieg"

    const-string/jumbo v1, "height"

    const/4 v11, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-eqz v2, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/material/animation/h;->g(Ljava/lang/String;)[Landroid/animation/PropertyValuesHolder;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    aget-object v6, v2, v5

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x3

    new-array v7, v4, [F

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    iget-object v8, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {v8}, Landroid/view/View;->getHeight()I

    move-result v8

    const/4 v11, 0x5

    const/4 v10, 0x4

    int-to-float v8, v8

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    aput v8, v7, v5

    const/4 v10, 0x6

    or-int/2addr v11, v10

    iget-object v8, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-interface {v8}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;->b()I

    move-result v8

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    int-to-float v8, v8

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    aput v8, v7, v3

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v6, v7}, Landroid/animation/PropertyValuesHolder;->setFloatValues([F)V

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/animation/h;->l(Ljava/lang/String;[Landroid/animation/PropertyValuesHolder;)V

    :cond_1
    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    const-string/jumbo v1, "gSprdaoptdnt"

    const-string/jumbo v1, "radSonpgdatt"

    const/4 v11, 0x4

    const-string v1, "dagptStaqrnd"

    const-string/jumbo v1, "paddingStart"

    const/4 v11, 0x2

    const/4 v10, 0x3

    invoke-virtual {v0, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-eqz v2, :cond_2

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v0, v1}, Lcom/google/android/material/animation/h;->g(Ljava/lang/String;)[Landroid/animation/PropertyValuesHolder;

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x0

    aget-object v6, v2, v5

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    new-array v7, v4, [F

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    iget-object v8, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-static {v8}, Landroidx/core/view/k1;->k0(Landroid/view/View;)I

    move-result v8

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x1

    int-to-float v8, v8

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    aput v8, v7, v5

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    iget-object v8, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-interface {v8}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;->getPaddingStart()I

    move-result v8

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    int-to-float v8, v8

    const/4 v10, 0x1

    shr-int/2addr v11, v10

    aput v8, v7, v3

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v6, v7}, Landroid/animation/PropertyValuesHolder;->setFloatValues([F)V

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/animation/h;->l(Ljava/lang/String;[Landroid/animation/PropertyValuesHolder;)V

    :cond_2
    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    const-string v1, "disndbpdan"

    const-string v1, "dEiadbnndp"

    const/4 v11, 0x1

    const-string/jumbo v1, "gdnmEpdadi"

    const-string/jumbo v1, "paddingEnd"

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    if-eqz v2, :cond_3

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v0, v1}, Lcom/google/android/material/animation/h;->g(Ljava/lang/String;)[Landroid/animation/PropertyValuesHolder;

    move-result-object v2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    aget-object v6, v2, v5

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-array v7, v4, [F

    const/4 v10, 0x6

    const/4 v11, 0x7

    iget-object v8, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-static {v8}, Landroidx/core/view/k1;->j0(Landroid/view/View;)I

    move-result v8

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    int-to-float v8, v8

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x5

    aput v8, v7, v5

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    iget-object v8, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->g:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;

    const/4 v10, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-interface {v8}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;->getPaddingEnd()I

    move-result v8

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    int-to-float v8, v8

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    aput v8, v7, v3

    const/4 v11, 0x6

    const/4 v10, 0x0

    invoke-virtual {v6, v7}, Landroid/animation/PropertyValuesHolder;->setFloatValues([F)V

    const/4 v11, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/animation/h;->l(Ljava/lang/String;[Landroid/animation/PropertyValuesHolder;)V

    :cond_3
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string v1, "etabopulaiOc"

    const-string v1, "aciteaupllOb"

    const/4 v11, 0x0

    const-string/jumbo v1, "lyaObbpelaci"

    const-string/jumbo v1, "labelOpacity"

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    if-eqz v2, :cond_6

    const/4 v11, 0x6

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/material/animation/h;->g(Ljava/lang/String;)[Landroid/animation/PropertyValuesHolder;

    move-result-object v2

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    iget-boolean v6, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->h:Z

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    const/4 v7, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x1

    const/high16 v8, 0x3f800000    # 1.0f

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-eqz v6, :cond_4

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    move v9, v7

    move v9, v7

    move v9, v7

    const/4 v11, 0x6

    const/4 v10, 0x2

    goto :goto_0

    :cond_4
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    move v9, v8

    move v9, v8

    const/4 v11, 0x5

    move v9, v8

    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-eqz v6, :cond_5

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    move v7, v8

    move v7, v8

    :cond_5
    const/4 v11, 0x4

    const/4 v10, 0x4

    aget-object v6, v2, v5

    const/4 v11, 0x0

    const/4 v10, 0x7

    new-array v4, v4, [F

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    aput v9, v4, v5

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x2

    aput v7, v4, v3

    const/4 v11, 0x5

    const/4 v10, 0x5

    invoke-virtual {v6, v4}, Landroid/animation/PropertyValuesHolder;->setFloatValues([F)V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/animation/h;->l(Ljava/lang/String;[Landroid/animation/PropertyValuesHolder;)V

    :cond_6
    const/4 v11, 0x1

    invoke-super {p0, v0}, Lcom/google/android/material/floatingactionbutton/b;->o(Lcom/google/android/material/animation/h;)Landroid/animation/AnimatorSet;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    return-object v0
.end method

.method public m(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$j;)V
    .locals 3
    .param p1    # Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$j;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez p1, :cond_0

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->h:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$j;->a(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$j;->d(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;)V

    :goto_0
    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-super {p0, p1}, Lcom/google/android/material/floatingactionbutton/b;->onAnimationStart(Landroid/animation/Animator;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v2, 0x7

    const/4 v1, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->h:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->w(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;Z)Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->x(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;Z)Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$h;->i:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setHorizontallyScrolling(Z)V

    const/4 v2, 0x0

    return-void
.end method
