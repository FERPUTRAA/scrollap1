.class Lcom/google/android/material/floatingactionbutton/e;
.super Lcom/google/android/material/floatingactionbutton/d;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x15
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/floatingactionbutton/e$a;
    }
.end annotation


# direct methods
.method constructor <init>(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Lcom/google/android/material/shadow/c;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/floatingactionbutton/d;-><init>(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Lcom/google/android/material/shadow/c;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method private m0(FF)Landroid/animation/Animator;
    .locals 9
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, " ds~b@~@u@i@~bi  @l~~~~Sf~  /t M@ca~/@@mo~~ so~ @K to o@ n @4~@o@~oif.y@@1@~~v~~~ @~lb@r-@~ @   "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x3

    new-instance v0, Landroid/animation/AnimatorSet;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-direct {v0}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/4 v2, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    new-array v3, v2, [F

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v4, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    aput p1, v3, v4

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string/jumbo p1, "lovmietns"

    const-string/jumbo p1, "tesilnoev"

    const/4 v8, 0x1

    const-string/jumbo p1, "neilovteo"

    const-string p1, "elevation"

    const/4 v8, 0x0

    invoke-static {v1, p1, v3}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x7

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {p1, v5, v6}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v0, p1}, Landroid/animation/AnimatorSet;->play(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    sget-object v3, Landroid/view/View;->TRANSLATION_Z:Landroid/util/Property;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-array v2, v2, [F

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    aput p2, v2, v4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {v1, v3, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object p2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-wide/16 v1, 0x64

    const-wide/16 v1, 0x64

    const/4 v8, 0x3

    const-wide/16 v1, 0x64

    const-wide/16 v1, 0x64

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {p2, v1, v2}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p1, p2}, Landroid/animation/AnimatorSet$Builder;->with(Landroid/animation/Animator;)Landroid/animation/AnimatorSet$Builder;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    sget-object p1, Lcom/google/android/material/floatingactionbutton/d;->D:Landroid/animation/TimeInterpolator;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0, p1}, Landroid/animation/AnimatorSet;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    return-object v0
.end method


# virtual methods
.method A()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method C()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->i0()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method E([I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method F(FFF)V
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    new-instance v1, Landroid/animation/StateListAnimator;

    const/4 v9, 0x2

    invoke-direct {v1}, Landroid/animation/StateListAnimator;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    sget-object v2, Lcom/google/android/material/floatingactionbutton/d;->S:[I

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-direct {p0, p1, p3}, Lcom/google/android/material/floatingactionbutton/e;->m0(FF)Landroid/animation/Animator;

    move-result-object p3

    const/4 v9, 0x4

    const/4 v8, 0x0

    invoke-virtual {v1, v2, p3}, Landroid/animation/StateListAnimator;->addState([ILandroid/animation/Animator;)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    sget-object p3, Lcom/google/android/material/floatingactionbutton/d;->T:[I

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/floatingactionbutton/e;->m0(FF)Landroid/animation/Animator;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v1, p3, v2}, Landroid/animation/StateListAnimator;->addState([ILandroid/animation/Animator;)V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    sget-object p3, Lcom/google/android/material/floatingactionbutton/d;->U:[I

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/floatingactionbutton/e;->m0(FF)Landroid/animation/Animator;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v1, p3, v2}, Landroid/animation/StateListAnimator;->addState([ILandroid/animation/Animator;)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    sget-object p3, Lcom/google/android/material/floatingactionbutton/d;->V:[I

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/floatingactionbutton/e;->m0(FF)Landroid/animation/Animator;

    move-result-object p2

    const/4 v9, 0x6

    const/4 v8, 0x3

    invoke-virtual {v1, p3, p2}, Landroid/animation/StateListAnimator;->addState([ILandroid/animation/Animator;)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-instance p2, Landroid/animation/AnimatorSet;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-direct {p2}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v8, 0x7

    xor-int/2addr v9, v8

    new-instance p3, Ljava/util/ArrayList;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x5

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    const/4 v3, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    new-array v4, v3, [F

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    const/4 v5, 0x0

    const/4 v9, 0x0

    aput p1, v4, v5

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string/jumbo p1, "oimevblta"

    const-string/jumbo p1, "otamvleei"

    const/4 v9, 0x2

    const-string/jumbo p1, "venotauei"

    const-string p1, "elevation"

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {v2, p1, v4}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p1, v6, v7}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-interface {p3, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/16 p1, 0x18

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-wide/16 v6, 0x64

    const-wide/16 v6, 0x64

    const/4 v9, 0x7

    const-wide/16 v6, 0x64

    const-wide/16 v6, 0x64

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-gt v0, p1, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    sget-object v0, Landroid/view/View;->TRANSLATION_Z:Landroid/util/Property;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    new-array v2, v3, [F

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getTranslationZ()F

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    aput v4, v2, v5

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {p1, v0, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p1, v6, v7}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-interface {p3, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    sget-object v0, Landroid/view/View;->TRANSLATION_Z:Landroid/util/Property;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    new-array v2, v3, [F

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 v3, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    aput v3, v2, v5

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {p1, v0, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {p1, v6, v7}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-interface {p3, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    new-array p1, v5, [Landroid/animation/Animator;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-interface {p3, p1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x4

    check-cast p1, [Landroid/animation/Animator;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p2, p1}, Landroid/animation/AnimatorSet;->playSequentially([Landroid/animation/Animator;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    sget-object p1, Lcom/google/android/material/floatingactionbutton/d;->D:Landroid/animation/TimeInterpolator;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {p2, p1}, Landroid/animation/AnimatorSet;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    sget-object p1, Lcom/google/android/material/floatingactionbutton/d;->W:[I

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v1, p1, p2}, Landroid/animation/StateListAnimator;->addState([ILandroid/animation/Animator;)V

    const/4 v8, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    sget-object p1, Lcom/google/android/material/floatingactionbutton/d;->X:[I

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-direct {p0, v3, v3}, Lcom/google/android/material/floatingactionbutton/e;->m0(FF)Landroid/animation/Animator;

    move-result-object p2

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v1, p1, p2}, Landroid/animation/StateListAnimator;->addState([ILandroid/animation/Animator;)V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {p1, v1}, Landroid/view/View;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/e;->c0()Z

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-eqz p1, :cond_1

    const/4 v9, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->i0()V

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    return-void
.end method

.method N()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v0, 0x0

    shr-int/2addr v2, v0

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method Y(Landroid/content/res/ColorStateList;)V
    .locals 4
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->c:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x4

    instance-of v1, v0, Landroid/graphics/drawable/RippleDrawable;

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Landroid/graphics/drawable/RippleDrawable;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/RippleDrawable;->setColor(Landroid/content/res/ColorStateList;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-super {p0, p1}, Lcom/google/android/material/floatingactionbutton/d;->Y(Landroid/content/res/ColorStateList;)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method c0()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->x:Lcom/google/android/material/shadow/c;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0}, Lcom/google/android/material/shadow/c;->b()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->e0()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method g0()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method l()Lcom/google/android/material/shape/j;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->a:Lcom/google/android/material/shape/o;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast v0, Lcom/google/android/material/shape/o;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v1, Lcom/google/android/material/floatingactionbutton/e$a;

    const/4 v3, 0x0

    invoke-direct {v1, v0}, Lcom/google/android/material/floatingactionbutton/e$a;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v1
.end method

.method l0(ILandroid/content/res/ColorStateList;)Lcom/google/android/material/floatingactionbutton/c;
    .locals 8
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance v1, Lcom/google/android/material/floatingactionbutton/c;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/d;->a:Lcom/google/android/material/shape/o;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v2}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    check-cast v2, Lcom/google/android/material/shape/o;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-direct {v1, v2}, Lcom/google/android/material/floatingactionbutton/c;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    sget v2, Lcom/google/android/material/R$color;->design_fab_stroke_top_outer_color:I

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v0, v2}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    sget v3, Lcom/google/android/material/R$color;->design_fab_stroke_top_inner_color:I

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v0, v3}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    sget v4, Lcom/google/android/material/R$color;->design_fab_stroke_end_inner_color:I

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {v0, v4}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    sget v5, Lcom/google/android/material/R$color;->design_fab_stroke_end_outer_color:I

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v0, v5}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v1, v2, v3, v4, v0}, Lcom/google/android/material/floatingactionbutton/c;->f(IIII)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    int-to-float p1, p1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1, p1}, Lcom/google/android/material/floatingactionbutton/c;->e(F)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v1, p2}, Lcom/google/android/material/floatingactionbutton/c;->d(Landroid/content/res/ColorStateList;)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    return-object v1
.end method

.method public n()F
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getElevation()F

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method s(Landroid/graphics/Rect;)V
    .locals 4
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->x:Lcom/google/android/material/shadow/c;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {v0}, Lcom/google/android/material/shadow/c;->b()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-super {p0, p1}, Lcom/google/android/material/floatingactionbutton/d;->s(Landroid/graphics/Rect;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->e0()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->k:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getSizeDimension()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    sub-int/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    div-int/lit8 v0, v0, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v0, v0, v0}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v0, v0, v0}, Landroid/graphics/Rect;->set(IIII)V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method x(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;Landroid/content/res/ColorStateList;I)V
    .locals 4
    .param p2    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/e;->l()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->setTintList(Landroid/content/res/ColorStateList;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p2}, Lcom/google/android/material/shape/j;->setTintMode(Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p2, v0}, Lcom/google/android/material/shape/j;->Z(Landroid/content/Context;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 p2, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-lez p4, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, p4, p1}, Lcom/google/android/material/floatingactionbutton/e;->l0(ILandroid/content/res/ColorStateList;)Lcom/google/android/material/floatingactionbutton/c;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->d:Lcom/google/android/material/floatingactionbutton/c;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance p1, Landroid/graphics/drawable/LayerDrawable;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p4, 0x2

    const/4 v2, 0x0

    and-int/2addr v3, v2

    new-array p4, p4, [Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x7

    move v3, v2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->d:Lcom/google/android/material/floatingactionbutton/c;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast v0, Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    aput-object v0, p4, v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast v0, Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x5

    aput-object v0, p4, v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p1, p4}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x5

    move v3, v2

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->d:Lcom/google/android/material/floatingactionbutton/c;

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance p4, Landroid/graphics/drawable/RippleDrawable;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p3}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object p3

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p4, p3, p1, p2}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x1

    const/4 v2, 0x7

    iput-object p4, p0, Lcom/google/android/material/floatingactionbutton/d;->c:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object p4, p0, Lcom/google/android/material/floatingactionbutton/d;->e:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method
