.class Lcom/google/android/material/floatingactionbutton/c$b;
.super Landroid/graphics/drawable/Drawable$ConstantState;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/floatingactionbutton/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/floatingactionbutton/c;


# direct methods
.method private constructor <init>(Lcom/google/android/material/floatingactionbutton/c;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/c$b;->a:Lcom/google/android/material/floatingactionbutton/c;

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/material/floatingactionbutton/c;Lcom/google/android/material/floatingactionbutton/c$a;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/material/floatingactionbutton/c$b;-><init>(Lcom/google/android/material/floatingactionbutton/c;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public getChangingConfigurations()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i~so@@y~/  ~@otl@@ ~1 K l~~~ u@~@~ ~voS~ ~@~f@.~M~- ~ir~@~@m@@/~@~oaono  c@ @@@t@  @ bb~~4f is b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public newDrawable()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c$b;->a:Lcom/google/android/material/floatingactionbutton/c;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method
