.class Lcom/google/android/material/floatingactionbutton/c;
.super Landroid/graphics/drawable/Drawable;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/floatingactionbutton/c$b;
    }
.end annotation


# static fields
.field private static final q:F = 1.3333f


# instance fields
.field private final a:Lcom/google/android/material/shape/p;

.field private final b:Landroid/graphics/Paint;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final c:Landroid/graphics/Path;

.field private final d:Landroid/graphics/Rect;

.field private final e:Landroid/graphics/RectF;

.field private final f:Landroid/graphics/RectF;

.field private final g:Lcom/google/android/material/floatingactionbutton/c$b;

.field h:F
    .annotation build Landroidx/annotation/r;
    .end annotation
.end field

.field private i:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private j:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private k:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private l:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private m:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private n:Z

.field private o:Lcom/google/android/material/shape/o;

.field private p:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/android/material/shape/o;)V
    .locals 4

    const/4 v3, 0x7

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {}, Lcom/google/android/material/shape/p;->k()Lcom/google/android/material/shape/p;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->a:Lcom/google/android/material/shape/p;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Landroid/graphics/Path;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0}, Landroid/graphics/Path;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->c:Landroid/graphics/Path;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Landroid/graphics/Rect;

    const/4 v3, 0x5

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->d:Landroid/graphics/Rect;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Landroid/graphics/RectF;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->e:Landroid/graphics/RectF;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance v0, Landroid/graphics/RectF;

    const/4 v2, 0x5

    shl-int/2addr v3, v2

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->f:Landroid/graphics/RectF;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/material/floatingactionbutton/c$b;

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, p0, v1}, Lcom/google/android/material/floatingactionbutton/c$b;-><init>(Lcom/google/android/material/floatingactionbutton/c;Lcom/google/android/material/floatingactionbutton/c$a;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->g:Lcom/google/android/material/floatingactionbutton/c$b;

    const/4 v3, 0x0

    const/4 v0, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/c;->n:Z

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/c;->o:Lcom/google/android/material/shape/o;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance p1, Landroid/graphics/Paint;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p1, v0}, Landroid/graphics/Paint;-><init>(I)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/c;->b:Landroid/graphics/Paint;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method private a()Landroid/graphics/Shader;
    .locals 13
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v11, "~ slt@@ 4n@f @l~~ @~~s@~~~~~~o@ @@b / M@vK dmo@  ~~1/t .~ui@oSo -bc~fyb@ ~o@~~i~ @@o@~ai@ ~~@ @r"

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->d:Landroid/graphics/Rect;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-virtual {p0, v0}, Landroid/graphics/drawable/Drawable;->copyBounds(Landroid/graphics/Rect;)V

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x6

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/c;->h:F

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v2

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x1

    int-to-float v2, v2

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x3

    div-float/2addr v1, v2

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x4

    const/4 v2, 0x6

    const/4 v12, 0x5

    new-array v8, v2, [I

    const/4 v11, 0x7

    and-int/2addr v12, v11

    iget v3, p0, Lcom/google/android/material/floatingactionbutton/c;->i:I

    const/4 v12, 0x2

    const/4 v11, 0x2

    iget v4, p0, Lcom/google/android/material/floatingactionbutton/c;->m:I

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-static {v3, v4}, Landroidx/core/graphics/b0;->t(II)I

    move-result v3

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x4

    const/4 v4, 0x0

    const/4 v12, 0x7

    aput v3, v8, v4

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    iget v3, p0, Lcom/google/android/material/floatingactionbutton/c;->j:I

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x2

    iget v5, p0, Lcom/google/android/material/floatingactionbutton/c;->m:I

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-static {v3, v5}, Landroidx/core/graphics/b0;->t(II)I

    move-result v3

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    const/4 v5, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x2

    aput v3, v8, v5

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    iget v3, p0, Lcom/google/android/material/floatingactionbutton/c;->j:I

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-static {v3, v4}, Landroidx/core/graphics/b0;->B(II)I

    move-result v3

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget v6, p0, Lcom/google/android/material/floatingactionbutton/c;->m:I

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-static {v3, v6}, Landroidx/core/graphics/b0;->t(II)I

    move-result v3

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    const/4 v6, 0x2

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x2

    aput v3, v8, v6

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget v3, p0, Lcom/google/android/material/floatingactionbutton/c;->l:I

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-static {v3, v4}, Landroidx/core/graphics/b0;->B(II)I

    move-result v3

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    iget v7, p0, Lcom/google/android/material/floatingactionbutton/c;->m:I

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {v3, v7}, Landroidx/core/graphics/b0;->t(II)I

    move-result v3

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x6

    const/4 v7, 0x3

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    aput v3, v8, v7

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget v3, p0, Lcom/google/android/material/floatingactionbutton/c;->l:I

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x5

    iget v9, p0, Lcom/google/android/material/floatingactionbutton/c;->m:I

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-static {v3, v9}, Landroidx/core/graphics/b0;->t(II)I

    move-result v3

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    const/4 v9, 0x4

    const/4 v11, 0x6

    or-int/2addr v12, v11

    aput v3, v8, v9

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget v3, p0, Lcom/google/android/material/floatingactionbutton/c;->k:I

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    iget v10, p0, Lcom/google/android/material/floatingactionbutton/c;->m:I

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-static {v3, v10}, Landroidx/core/graphics/b0;->t(II)I

    move-result v3

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    const/4 v10, 0x5

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x3

    aput v3, v8, v10

    const/4 v11, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    new-array v2, v2, [F

    const/4 v11, 0x1

    shr-int/2addr v12, v11

    const/4 v3, 0x0

    move v12, v3

    const/4 v11, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x3

    aput v3, v2, v4

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x3

    aput v1, v2, v5

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/high16 v3, 0x3f000000    # 0.5f

    const/4 v11, 0x7

    const/4 v11, 0x3

    aput v3, v2, v6

    const/4 v11, 0x6

    shl-int/2addr v12, v11

    aput v3, v2, v7

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x3

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x7

    sub-float v1, v3, v1

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    aput v1, v2, v9

    const/4 v12, 0x7

    aput v3, v2, v10

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    new-instance v1, Landroid/graphics/LinearGradient;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x2

    const/4 v4, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    iget v3, v0, Landroid/graphics/Rect;->top:I

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x6

    int-to-float v5, v3

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x1

    const/4 v6, 0x0

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v12, 0x5

    int-to-float v7, v0

    const/4 v12, 0x1

    sget-object v10, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v9, v2

    move-object v9, v2

    move-object v9, v2

    move-object v9, v2

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-direct/range {v3 .. v10}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x7

    return-object v1
.end method


# virtual methods
.method protected b()Landroid/graphics/RectF;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->f:Landroid/graphics/RectF;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->f:Landroid/graphics/RectF;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0
.end method

.method public c()Lcom/google/android/material/shape/o;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->o:Lcom/google/android/material/shape/o;

    const/4 v1, 0x5

    shr-int/2addr v2, v1

    return-object v0
.end method

.method d(Landroid/content/res/ColorStateList;)V
    .locals 4
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/c;->m:I

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {p1, v0, v1}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput v0, p0, Lcom/google/android/material/floatingactionbutton/c;->m:I

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/c;->p:Landroid/content/res/ColorStateList;

    const/4 v3, 0x0

    const/4 p1, 0x1

    const/4 v3, 0x2

    move v2, p1

    move v2, p1

    const/4 v3, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/c;->n:Z

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v3, 0x4

    return-void
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 6
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/c;->n:Z

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->b:Landroid/graphics/Paint;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/c;->a()Landroid/graphics/Shader;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/c;->n:Z

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->b:Landroid/graphics/Paint;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/graphics/Paint;->getStrokeWidth()F

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/high16 v1, 0x40000000    # 2.0f

    const/4 v5, 0x4

    div-float/2addr v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/c;->d:Landroid/graphics/Rect;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0, v2}, Landroid/graphics/drawable/Drawable;->copyBounds(Landroid/graphics/Rect;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/c;->e:Landroid/graphics/RectF;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v3, p0, Lcom/google/android/material/floatingactionbutton/c;->d:Landroid/graphics/Rect;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/c;->o:Lcom/google/android/material/shape/o;

    const/4 v5, 0x5

    invoke-virtual {v2}, Lcom/google/android/material/shape/o;->r()Lcom/google/android/material/shape/d;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/c;->b()Landroid/graphics/RectF;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x7

    invoke-interface {v2, v3}, Lcom/google/android/material/shape/d;->a(Landroid/graphics/RectF;)F

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/google/android/material/floatingactionbutton/c;->e:Landroid/graphics/RectF;

    const/4 v5, 0x0

    invoke-virtual {v3}, Landroid/graphics/RectF;->width()F

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    div-float/2addr v3, v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/c;->o:Lcom/google/android/material/shape/o;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/c;->b()Landroid/graphics/RectF;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Lcom/google/android/material/shape/o;->u(Landroid/graphics/RectF;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/c;->e:Landroid/graphics/RectF;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v2, v0, v0}, Landroid/graphics/RectF;->inset(FF)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->e:Landroid/graphics/RectF;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/c;->b:Landroid/graphics/Paint;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p1, v0, v1, v1, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-void
.end method

.method public e(F)V
    .locals 4
    .param p1    # F
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/c;->h:F

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    cmpl-float v0, v0, p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/c;->h:F

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->b:Landroid/graphics/Paint;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const v1, 0x3faaa993    # 1.3333f

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    mul-float/2addr p1, v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 p1, 0x1

    const/4 v3, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/c;->n:Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method f(IIII)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/c;->i:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p2, p0, Lcom/google/android/material/floatingactionbutton/c;->j:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p3, p0, Lcom/google/android/material/floatingactionbutton/c;->k:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p4, p0, Lcom/google/android/material/floatingactionbutton/c;->l:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    return-void
.end method

.method public g(Lcom/google/android/material/shape/o;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/c;->o:Lcom/google/android/material/shape/o;

    const/4 v1, 0x0

    const/4 v0, 0x2

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v1, 0x1

    return-void
.end method

.method public getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->g:Lcom/google/android/material/floatingactionbutton/c$b;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public getOpacity()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/c;->h:F

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    cmpl-float v0, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-lez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v0, -0x6

    const/4 v0, -0x3

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, -0x2

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return v0
.end method

.method public getOutline(Landroid/graphics/Outline;)V
    .locals 7
    .param p1    # Landroid/graphics/Outline;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->o:Lcom/google/android/material/shape/o;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/c;->b()Landroid/graphics/RectF;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/shape/o;->u(Landroid/graphics/RectF;)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->o:Lcom/google/android/material/shape/o;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/shape/o;->r()Lcom/google/android/material/shape/d;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/c;->b()Landroid/graphics/RectF;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v0, v1}, Lcom/google/android/material/shape/d;->a(Landroid/graphics/RectF;)F

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1, v1, v0}, Landroid/graphics/Outline;->setRoundRect(Landroid/graphics/Rect;F)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->d:Landroid/graphics/Rect;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0, v0}, Landroid/graphics/drawable/Drawable;->copyBounds(Landroid/graphics/Rect;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->e:Landroid/graphics/RectF;

    const/4 v6, 0x7

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/c;->d:Landroid/graphics/Rect;

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->a:Lcom/google/android/material/shape/p;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/c;->o:Lcom/google/android/material/shape/o;

    const/4 v6, 0x3

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/c;->e:Landroid/graphics/RectF;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/google/android/material/floatingactionbutton/c;->c:Landroid/graphics/Path;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, v1, v4, v2, v3}, Lcom/google/android/material/shape/p;->d(Lcom/google/android/material/shape/o;FLandroid/graphics/RectF;Landroid/graphics/Path;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->c:Landroid/graphics/Path;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/graphics/Path;->isConvex()Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->c:Landroid/graphics/Path;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1, v0}, Landroid/graphics/Outline;->setConvexPath(Landroid/graphics/Path;)V

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-void
.end method

.method public getPadding(Landroid/graphics/Rect;)Z
    .locals 4
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->o:Lcom/google/android/material/shape/o;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/c;->b()Landroid/graphics/RectF;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/material/shape/o;->u(Landroid/graphics/RectF;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/c;->h:F

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1, v0, v0, v0, v0}, Landroid/graphics/Rect;->set(IIII)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    return p1
.end method

.method public isStateful()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->p:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->isStateful()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_2

    :cond_1
    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method protected onBoundsChange(Landroid/graphics/Rect;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/c;->n:Z

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method protected onStateChange([I)Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->p:Landroid/content/res/ColorStateList;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/c;->m:I

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, p1, v1}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/c;->m:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eq p1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/c;->n:Z

    const/4 v2, 0x4

    move v3, v2

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/c;->m:I

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/c;->n:Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/c;->n:Z

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return p1
.end method

.method public setAlpha(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
            to = 0xffL
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->b:Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 3
    .param p1    # Landroid/graphics/ColorFilter;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/c;->b:Landroid/graphics/Paint;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    return-void
.end method
