.class Lcom/google/android/material/floatingactionbutton/d$l;
.super Lcom/google/android/material/floatingactionbutton/d$m;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/floatingactionbutton/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "l"
.end annotation


# instance fields
.field final synthetic e:Lcom/google/android/material/floatingactionbutton/d;


# direct methods
.method constructor <init>(Lcom/google/android/material/floatingactionbutton/d;)V
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d$l;->e:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/floatingactionbutton/d$m;-><init>(Lcom/google/android/material/floatingactionbutton/d;Lcom/google/android/material/floatingactionbutton/d$a;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method protected a()F
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s@@t/~~@ f-1@ ~ @~~~l~i~b@@a@   o ~y@ ~b~o@of~ K4 u~o@~ n@~o@mdi~@~scot lb@~v  i~@S.r / ~@ @~M"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$l;->e:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, v0, Lcom/google/android/material/floatingactionbutton/d;->h:F

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method
