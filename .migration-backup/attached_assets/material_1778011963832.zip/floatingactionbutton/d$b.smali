.class Lcom/google/android/material/floatingactionbutton/d$b;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/floatingactionbutton/d;->f0(Lcom/google/android/material/floatingactionbutton/d$k;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Z

.field final synthetic b:Lcom/google/android/material/floatingactionbutton/d$k;

.field final synthetic c:Lcom/google/android/material/floatingactionbutton/d;


# direct methods
.method constructor <init>(Lcom/google/android/material/floatingactionbutton/d;ZLcom/google/android/material/floatingactionbutton/d$k;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d$b;->c:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p2, p0, Lcom/google/android/material/floatingactionbutton/d$b;->a:Z

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/google/android/material/floatingactionbutton/d$b;->b:Lcom/google/android/material/floatingactionbutton/d$k;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s@M~/~bli@u@i~~v@ o~   t~bo@ nol.os~  @@/by @ ~~~@~~f~@a@@t @ K r~i@  @@@~ o~~1- f@S~~~4@c@~od"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d$b;->c:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lcom/google/android/material/floatingactionbutton/d;->a(Lcom/google/android/material/floatingactionbutton/d;I)I

    const/4 v1, 0x3

    or-int/2addr v2, v1

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d$b;->c:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x0

    shl-int/2addr v2, v1

    invoke-static {p1, v0}, Lcom/google/android/material/floatingactionbutton/d;->b(Lcom/google/android/material/floatingactionbutton/d;Landroid/animation/Animator;)Landroid/animation/Animator;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d$b;->b:Lcom/google/android/material/floatingactionbutton/d$k;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {p1}, Lcom/google/android/material/floatingactionbutton/d$k;->a()V

    :cond_0
    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$b;->c:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-boolean v2, p0, Lcom/google/android/material/floatingactionbutton/d$b;->a:Z

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/internal/VisibilityAwareImageButton;->a(IZ)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$b;->c:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lcom/google/android/material/floatingactionbutton/d;->a(Lcom/google/android/material/floatingactionbutton/d;I)I

    const/4 v4, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$b;->c:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->b(Lcom/google/android/material/floatingactionbutton/d;Landroid/animation/Animator;)Landroid/animation/Animator;

    const/4 v3, 0x2

    move v4, v3

    return-void
.end method
