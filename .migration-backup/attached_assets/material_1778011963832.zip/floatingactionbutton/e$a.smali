.class Lcom/google/android/material/floatingactionbutton/e$a;
.super Lcom/google/android/material/shape/j;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/floatingactionbutton/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# direct methods
.method constructor <init>(Lcom/google/android/material/shape/o;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/shape/j;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public isStateful()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l@soyb~@@ .@~~ -~iiau~~@ ~@c~ d~@~f to S@r  f@~ 1t@ n~~ib@~v @@~@b @@  ~ ~@@l~oK4o~ Mm~o@s/o~ ~/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method
