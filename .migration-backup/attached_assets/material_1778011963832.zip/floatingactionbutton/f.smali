.class interface abstract Lcom/google/android/material/floatingactionbutton/f;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()Lcom/google/android/material/animation/h;
.end method

.method public abstract b()V
.end method

.method public abstract c()Lcom/google/android/material/animation/h;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end method

.method public abstract d()Z
.end method

.method public abstract e(Landroid/animation/Animator$AnimatorListener;)V
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract f()V
.end method

.method public abstract g()I
    .annotation build Landroidx/annotation/b;
    .end annotation
.end method

.method public abstract h(Landroid/animation/Animator$AnimatorListener;)V
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract i()V
.end method

.method public abstract j(Lcom/google/android/material/animation/h;)V
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
.end method

.method public abstract k()Landroid/animation/AnimatorSet;
.end method

.method public abstract l()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/animation/Animator$AnimatorListener;",
            ">;"
        }
    .end annotation
.end method

.method public abstract m(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$j;)V
    .param p1    # Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$j;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
.end method

.method public abstract onAnimationStart(Landroid/animation/Animator;)V
.end method
