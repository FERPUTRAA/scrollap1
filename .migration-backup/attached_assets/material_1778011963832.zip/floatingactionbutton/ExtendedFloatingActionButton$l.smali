.class interface abstract Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$l;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "l"
.end annotation


# virtual methods
.method public abstract a()Landroid/view/ViewGroup$LayoutParams;
.end method

.method public abstract b()I
.end method

.method public abstract f()I
.end method

.method public abstract getPaddingEnd()I
.end method

.method public abstract getPaddingStart()I
.end method
