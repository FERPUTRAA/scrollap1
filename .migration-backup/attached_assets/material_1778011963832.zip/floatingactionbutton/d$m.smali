.class abstract Lcom/google/android/material/floatingactionbutton/d$m;
.super Landroid/animation/AnimatorListenerAdapter;

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/floatingactionbutton/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x402
    name = "m"
.end annotation


# instance fields
.field private a:Z

.field private b:F

.field private c:F

.field final synthetic d:Lcom/google/android/material/floatingactionbutton/d;


# direct methods
.method private constructor <init>(Lcom/google/android/material/floatingactionbutton/d;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d$m;->d:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/material/floatingactionbutton/d;Lcom/google/android/material/floatingactionbutton/d$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/floatingactionbutton/d$m;-><init>(Lcom/google/android/material/floatingactionbutton/d;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected abstract a()F
.end method

.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bvs@4~ ~/~@@@n y-~o~tS ~o~~ @ t @@ ~d@c ~sfi~~.~M@~ b@l @~ ~@or@b@o~l~@ @/ ~~1m ai@~oK@@ f~oi@ u"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d$m;->d:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v2, 0x4

    const/4 v1, 0x2

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d$m;->c:F

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    float-to-int v0, v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    int-to-float v0, v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Lcom/google/android/material/floatingactionbutton/d;->j0(F)V

    const/4 v2, 0x4

    const/4 p1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/d$m;->a:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 5
    .param p1    # Landroid/animation/ValueAnimator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/d$m;->a:Z

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-nez v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$m;->d:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, v0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/shape/j;->x()F

    move-result v0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/android/material/floatingactionbutton/d$m;->b:F

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d$m;->a()F

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput v0, p0, Lcom/google/android/material/floatingactionbutton/d$m;->c:F

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/d$m;->a:Z

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$m;->d:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d$m;->b:F

    const/4 v4, 0x5

    const/4 v3, 0x2

    iget v2, p0, Lcom/google/android/material/floatingactionbutton/d$m;->c:F

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    sub-float/2addr v2, v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedFraction()F

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    mul-float/2addr v2, p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    add-float/2addr v1, v2

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    float-to-int p1, v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    int-to-float p1, p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->j0(F)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void
.end method
