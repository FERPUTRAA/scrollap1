.class Lcom/google/android/material/floatingactionbutton/d$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/floatingactionbutton/d;->j(FFF)Landroid/animation/AnimatorSet;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:F

.field final synthetic b:F

.field final synthetic c:F

.field final synthetic d:F

.field final synthetic e:F

.field final synthetic f:F

.field final synthetic g:F

.field final synthetic h:Landroid/graphics/Matrix;

.field final synthetic i:Lcom/google/android/material/floatingactionbutton/d;


# direct methods
.method constructor <init>(Lcom/google/android/material/floatingactionbutton/d;FFFFFFFLandroid/graphics/Matrix;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d$d;->i:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p2, p0, Lcom/google/android/material/floatingactionbutton/d$d;->a:F

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p3, p0, Lcom/google/android/material/floatingactionbutton/d$d;->b:F

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p4, p0, Lcom/google/android/material/floatingactionbutton/d$d;->c:F

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p5, p0, Lcom/google/android/material/floatingactionbutton/d$d;->d:F

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p6, p0, Lcom/google/android/material/floatingactionbutton/d$d;->e:F

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p7, p0, Lcom/google/android/material/floatingactionbutton/d$d;->f:F

    const/4 v0, 0x3

    move v1, v0

    iput p8, p0, Lcom/google/android/material/floatingactionbutton/d$d;->g:F

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p9, p0, Lcom/google/android/material/floatingactionbutton/d$d;->h:Landroid/graphics/Matrix;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "f1sf@@dr@  ~@-@ @b@@ l~~@Su@~o @/~o~ ~iMy~ s ~ ~c~b@ K.ia   b@~i@@~lm /4no@@t@@~~ @ t~~~ ~~ooov~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    check-cast p1, Ljava/lang/Float;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$d;->i:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v0, v0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d$d;->a:F

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget v2, p0, Lcom/google/android/material/floatingactionbutton/d$d;->b:F

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v3, 0x0

    const/4 v6, 0x5

    const v4, 0x3e4ccccd    # 0.2f

    const/4 v6, 0x5

    invoke-static {v1, v2, v3, v4, p1}, Lcom/google/android/material/animation/a;->b(FFFFF)F

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    const/4 v5, 0x3

    move v6, v5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$d;->i:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, v0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d$d;->c:F

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget v2, p0, Lcom/google/android/material/floatingactionbutton/d$d;->d:F

    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-static {v1, v2, p1}, Lcom/google/android/material/animation/a;->a(FFF)F

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setScaleX(F)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$d;->i:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, v0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d$d;->e:F

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget v2, p0, Lcom/google/android/material/floatingactionbutton/d$d;->d:F

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v1, v2, p1}, Lcom/google/android/material/animation/a;->a(FFF)F

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setScaleY(F)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$d;->i:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d$d;->f:F

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget v2, p0, Lcom/google/android/material/floatingactionbutton/d$d;->g:F

    const/4 v5, 0x3

    or-int/2addr v6, v5

    invoke-static {v1, v2, p1}, Lcom/google/android/material/animation/a;->a(FFF)F

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/google/android/material/floatingactionbutton/d;->c(Lcom/google/android/material/floatingactionbutton/d;F)F

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$d;->i:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d$d;->f:F

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget v2, p0, Lcom/google/android/material/floatingactionbutton/d$d;->g:F

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v1, v2, p1}, Lcom/google/android/material/animation/a;->a(FFF)F

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d$d;->h:Landroid/graphics/Matrix;

    const/4 v5, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v0, p1, v1}, Lcom/google/android/material/floatingactionbutton/d;->d(Lcom/google/android/material/floatingactionbutton/d;FLandroid/graphics/Matrix;)V

    const/4 v5, 0x4

    shr-int/2addr v6, v5

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d$d;->i:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v5, 0x7

    shr-int/2addr v6, v5

    iget-object p1, p1, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v6, 0x4

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$d;->h:Landroid/graphics/Matrix;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageMatrix(Landroid/graphics/Matrix;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void
.end method
