.class abstract Lcom/google/android/material/floatingactionbutton/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/floatingactionbutton/f;


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/animation/Animator$AnimatorListener;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Lcom/google/android/material/floatingactionbutton/a;

.field private e:Lcom/google/android/material/animation/h;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private f:Lcom/google/android/material/animation/h;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;Lcom/google/android/material/floatingactionbutton/a;)V
    .locals 3
    .param p1    # Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->c:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/b;->b:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/b;->a:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object p2, p0, Lcom/google/android/material/floatingactionbutton/b;->d:Lcom/google/android/material/floatingactionbutton/a;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method static synthetic n(Lcom/google/android/material/floatingactionbutton/b;)Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @s~~o@~@ ~1c~ ar/tto@~f ~ i lu@@K~ ~~nl~@  ~~@ob~~~ @ 4@@@M @~bds~@m y@ o /v~~@b@@-ooi~.if ~@S@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/material/floatingactionbutton/b;->b:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method


# virtual methods
.method public final a()Lcom/google/android/material/animation/h;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->f:Lcom/google/android/material/animation/h;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->e:Lcom/google/android/material/animation/h;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->a:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {p0}, Lcom/google/android/material/floatingactionbutton/f;->g()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-static {v0, v1}, Lcom/google/android/material/animation/h;->d(Landroid/content/Context;I)Lcom/google/android/material/animation/h;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->e:Lcom/google/android/material/animation/h;

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->e:Lcom/google/android/material/animation/h;

    const/4 v2, 0x1

    or-int/2addr v3, v2

    invoke-static {v0}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v0, Lcom/google/android/material/animation/h;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0
.end method

.method public c()Lcom/google/android/material/animation/h;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->f:Lcom/google/android/material/animation/h;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public final e(Landroid/animation/Animator$AnimatorListener;)V
    .locals 3
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->c:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public f()V
    .locals 3
    .annotation build Landroidx/annotation/i;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->d:Lcom/google/android/material/floatingactionbutton/a;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/a;->b()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public final h(Landroid/animation/Animator$AnimatorListener;)V
    .locals 3
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->c:Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x6

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public i()V
    .locals 3
    .annotation build Landroidx/annotation/i;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->d:Lcom/google/android/material/floatingactionbutton/a;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/a;->b()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public final j(Lcom/google/android/material/animation/h;)V
    .locals 2
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/b;->f:Lcom/google/android/material/animation/h;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public k()Landroid/animation/AnimatorSet;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/b;->a()Lcom/google/android/material/animation/h;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0, v0}, Lcom/google/android/material/floatingactionbutton/b;->o(Lcom/google/android/material/animation/h;)Landroid/animation/AnimatorSet;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public final l()Ljava/util/List;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/animation/Animator$AnimatorListener;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->c:Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method o(Lcom/google/android/material/animation/h;)Landroid/animation/AnimatorSet;
    .locals 8
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x3

    or-int/2addr v7, v6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const-string/jumbo v1, "itspoac"

    const/4 v7, 0x6

    const-string/jumbo v1, "tiymapo"

    const-string/jumbo v1, "opacity"

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p1, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz v2, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/b;->b:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    sget-object v3, Landroid/view/View;->ALPHA:Landroid/util/Property;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p1, v1, v2, v3}, Lcom/google/android/material/animation/h;->f(Ljava/lang/String;Ljava/lang/Object;Landroid/util/Property;)Landroid/animation/ObjectAnimator;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string/jumbo v1, "scmlo"

    const-string v1, "escml"

    const/4 v7, 0x3

    const-string/jumbo v1, "scale"

    const/4 v7, 0x1

    invoke-virtual {p1, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v2, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/b;->b:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    sget-object v3, Landroid/view/View;->SCALE_Y:Landroid/util/Property;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p1, v1, v2, v3}, Lcom/google/android/material/animation/h;->f(Ljava/lang/String;Ljava/lang/Object;Landroid/util/Property;)Landroid/animation/ObjectAnimator;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/b;->b:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    sget-object v3, Landroid/view/View;->SCALE_X:Landroid/util/Property;

    const/4 v7, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1, v1, v2, v3}, Lcom/google/android/material/animation/h;->f(Ljava/lang/String;Ljava/lang/Object;Landroid/util/Property;)Landroid/animation/ObjectAnimator;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x6

    const-string v1, "bohwi"

    const-string/jumbo v1, "wdiho"

    const/4 v7, 0x1

    const-string/jumbo v1, "wuitd"

    const-string/jumbo v1, "width"

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p1, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz v2, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/b;->b:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v7, 0x1

    sget-object v3, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->P:Landroid/util/Property;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p1, v1, v2, v3}, Lcom/google/android/material/animation/h;->f(Ljava/lang/String;Ljava/lang/Object;Landroid/util/Property;)Landroid/animation/ObjectAnimator;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v1, "hpgieh"

    const-string/jumbo v1, "iehghb"

    const/4 v7, 0x3

    const-string v1, "ehqigh"

    const-string/jumbo v1, "height"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p1, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz v2, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/b;->b:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget-object v3, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->Q:Landroid/util/Property;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p1, v1, v2, v3}, Lcom/google/android/material/animation/h;->f(Ljava/lang/String;Ljava/lang/Object;Landroid/util/Property;)Landroid/animation/ObjectAnimator;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string v1, "austrtpgdnad"

    const-string v1, "aitradugptnd"

    const/4 v7, 0x6

    const-string/jumbo v1, "gtdmidprtaan"

    const-string/jumbo v1, "paddingStart"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p1, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz v2, :cond_4

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/b;->b:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    sget-object v3, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->R:Landroid/util/Property;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p1, v1, v2, v3}, Lcom/google/android/material/animation/h;->f(Ljava/lang/String;Ljava/lang/Object;Landroid/util/Property;)Landroid/animation/ObjectAnimator;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string/jumbo v1, "gnpdopnddE"

    const-string/jumbo v1, "nEpgnddpdi"

    const/4 v7, 0x6

    const-string/jumbo v1, "pnganbdddE"

    const-string/jumbo v1, "paddingEnd"

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p1, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x7

    if-eqz v2, :cond_5

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/b;->b:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    sget-object v3, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;->S:Landroid/util/Property;

    const/4 v7, 0x4

    const/4 v6, 0x5

    invoke-virtual {p1, v1, v2, v3}, Lcom/google/android/material/animation/h;->f(Ljava/lang/String;Ljava/lang/Object;Landroid/util/Property;)Landroid/animation/ObjectAnimator;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_5
    const/4 v7, 0x0

    const/4 v6, 0x6

    const-string/jumbo v1, "qcObteuyillp"

    const-string v1, "Olalpietqycb"

    const/4 v7, 0x3

    const-string/jumbo v1, "yailcpOpbtel"

    const-string/jumbo v1, "labelOpacity"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p1, v1}, Lcom/google/android/material/animation/h;->j(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v2, :cond_6

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/b;->b:Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    new-instance v3, Lcom/google/android/material/floatingactionbutton/b$a;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-class v4, Ljava/lang/Float;

    const-class v4, Ljava/lang/Float;

    const/4 v7, 0x2

    const-class v4, Ljava/lang/Float;

    const-class v4, Ljava/lang/Float;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string v5, "YL__OPTAqACPOPTYRBLEsR"

    const-string v5, "LAsO__EOYCALETTYRBRPPP"

    const/4 v7, 0x3

    const-string v5, "_EsOPRRYPEYOCTITLAP_LA"

    const-string v5, "LABEL_OPACITY_PROPERTY"

    const/4 v6, 0x1

    move v7, v6

    invoke-direct {v3, p0, v4, v5}, Lcom/google/android/material/floatingactionbutton/b$a;-><init>(Lcom/google/android/material/floatingactionbutton/b;Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p1, v1, v2, v3}, Lcom/google/android/material/animation/h;->f(Ljava/lang/String;Ljava/lang/Object;Landroid/util/Property;)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_6
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    new-instance p1, Landroid/animation/AnimatorSet;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {p1}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x5

    invoke-static {p1, v0}, Lcom/google/android/material/animation/b;->a(Landroid/animation/AnimatorSet;Ljava/util/List;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    return-object p1
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 3
    .annotation build Landroidx/annotation/i;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/b;->d:Lcom/google/android/material/floatingactionbutton/a;

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/a;->c(Landroid/animation/Animator;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method
