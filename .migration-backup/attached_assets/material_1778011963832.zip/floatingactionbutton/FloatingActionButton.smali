.class public Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
.super Lcom/google/android/material/internal/VisibilityAwareImageButton;

# interfaces
.implements Landroidx/core/view/g1;
.implements Landroidx/core/widget/w;
.implements Lt4/a;
.implements Lcom/google/android/material/shape/s;
.implements Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/floatingactionbutton/FloatingActionButton$c;,
        Lcom/google/android/material/floatingactionbutton/FloatingActionButton$e;,
        Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;,
        Lcom/google/android/material/floatingactionbutton/FloatingActionButton$Behavior;,
        Lcom/google/android/material/floatingactionbutton/FloatingActionButton$d;,
        Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;
    }
.end annotation


# static fields
.field private static final r:Ljava/lang/String; = "FloatingActionButton"

.field private static final s:Ljava/lang/String; = "expandableWidgetHelper"

.field private static final t:I

.field public static final u:I = 0x1

.field public static final v:I = 0x0

.field public static final w:I = -0x1

.field public static final x:I = 0x0

.field private static final y:I = 0x1d6


# instance fields
.field private b:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private c:Landroid/graphics/PorterDuff$Mode;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private d:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private e:Landroid/graphics/PorterDuff$Mode;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private f:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:I

.field l:Z

.field final m:Landroid/graphics/Rect;

.field private final n:Landroid/graphics/Rect;

.field private final o:Landroidx/appcompat/widget/x;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final p:Lt4/c;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private q:Lcom/google/android/material/floatingactionbutton/d;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget v0, Lcom/google/android/material/R$style;->Widget_Design_FloatingActionButton:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    sput v0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->t:I

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget v0, Lcom/google/android/material/R$attr;->floatingActionButtonStyle:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 12
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    sget v6, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->t:I

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-static {p1, p2, p3, v6}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/material/internal/VisibilityAwareImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v10, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    new-instance p1, Landroid/graphics/Rect;

    const/4 v11, 0x3

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x0

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->m:Landroid/graphics/Rect;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    new-instance p1, Landroid/graphics/Rect;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->n:Landroid/graphics/Rect;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    sget-object v2, Lcom/google/android/material/R$styleable;->FloatingActionButton:[I

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    const/4 v7, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    new-array v5, v7, [I

    move-object v0, p1

    move-object v0, p1

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v11, 0x0

    const/4 v10, 0x4

    move v3, p3

    move v3, p3

    const/4 v11, 0x0

    move v3, p3

    move v3, p3

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    move v4, v6

    move v4, v6

    const/4 v11, 0x6

    move v4, v6

    move v4, v6

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x5

    sget v1, Lcom/google/android/material/R$styleable;->FloatingActionButton_backgroundTint:I

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-static {p1, v0, v1}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v11, 0x5

    const/4 v10, 0x1

    iput-object v1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->b:Landroid/content/res/ColorStateList;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget v1, Lcom/google/android/material/R$styleable;->FloatingActionButton_backgroundTintMode:I

    const/4 v10, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    const/4 v2, -0x1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/4 v3, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-static {v1, v3}, Lcom/google/android/material/internal/y;->l(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    move-result-object v1

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    iput-object v1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->c:Landroid/graphics/PorterDuff$Mode;

    const/4 v10, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x3

    sget v1, Lcom/google/android/material/R$styleable;->FloatingActionButton_rippleColor:I

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {p1, v0, v1}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    iput-object v1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->f:Landroid/content/res/ColorStateList;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    sget v1, Lcom/google/android/material/R$styleable;->FloatingActionButton_fabSize:I

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x1

    iput v1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->h:I

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    sget v1, Lcom/google/android/material/R$styleable;->FloatingActionButton_fabCustomSize:I

    const/4 v11, 0x3

    const/4 v10, 0x1

    invoke-virtual {v0, v1, v7}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v1

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    iput v1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->i:I

    const/4 v11, 0x7

    const/4 v10, 0x4

    sget v1, Lcom/google/android/material/R$styleable;->FloatingActionButton_borderWidth:I

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v0, v1, v7}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v1

    const/4 v11, 0x3

    const/4 v10, 0x3

    iput v1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->g:I

    sget v1, Lcom/google/android/material/R$styleable;->FloatingActionButton_elevation:I

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    const/4 v2, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    sget v3, Lcom/google/android/material/R$styleable;->FloatingActionButton_hoveredFocusedTranslationZ:I

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v0, v3, v2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v3

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    sget v4, Lcom/google/android/material/R$styleable;->FloatingActionButton_pressedTranslationZ:I

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v0, v4, v2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v2

    const/4 v11, 0x0

    const/4 v10, 0x0

    sget v4, Lcom/google/android/material/R$styleable;->FloatingActionButton_useCompatPadding:I

    const/4 v10, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {v0, v4, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    iput-boolean v4, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->l:Z

    const/4 v11, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const/4 v11, 0x6

    const/4 v10, 0x5

    sget v5, Lcom/google/android/material/R$dimen;->mtrl_fab_min_touch_target:I

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v4

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    sget v5, Lcom/google/android/material/R$styleable;->FloatingActionButton_maxImageSize:I

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {v0, v5, v7}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v5

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {p0, v5}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setMaxImageSize(I)V

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x7

    sget v5, Lcom/google/android/material/R$styleable;->FloatingActionButton_showMotionSpec:I

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-static {p1, v0, v5}, Lcom/google/android/material/animation/h;->c(Landroid/content/Context;Landroid/content/res/TypedArray;I)Lcom/google/android/material/animation/h;

    move-result-object v5

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x2

    sget v8, Lcom/google/android/material/R$styleable;->FloatingActionButton_hideMotionSpec:I

    invoke-static {p1, v0, v8}, Lcom/google/android/material/animation/h;->c(Landroid/content/Context;Landroid/content/res/TypedArray;I)Lcom/google/android/material/animation/h;

    move-result-object v8

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    sget-object v9, Lcom/google/android/material/shape/o;->m:Lcom/google/android/material/shape/d;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {p1, p2, p3, v6, v9}, Lcom/google/android/material/shape/o;->g(Landroid/content/Context;Landroid/util/AttributeSet;IILcom/google/android/material/shape/d;)Lcom/google/android/material/shape/o$b;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/shape/o$b;->m()Lcom/google/android/material/shape/o;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    sget v6, Lcom/google/android/material/R$styleable;->FloatingActionButton_ensureMinTouchTargetSize:I

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v0, v6, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v6

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    sget v7, Lcom/google/android/material/R$styleable;->FloatingActionButton_android_enabled:I

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    const/4 v9, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {v0, v7, v9}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v7

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {p0, v7}, Landroid/view/View;->setEnabled(Z)V

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x7

    new-instance v0, Landroidx/appcompat/widget/x;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-direct {v0, p0}, Landroidx/appcompat/widget/x;-><init>(Landroid/widget/ImageView;)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->o:Landroidx/appcompat/widget/x;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v0, p2, p3}, Landroidx/appcompat/widget/x;->g(Landroid/util/AttributeSet;I)V

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x3

    new-instance p2, Lt4/c;

    const/4 v11, 0x0

    invoke-direct {p2, p0}, Lt4/c;-><init>(Lt4/b;)V

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    iput-object p2, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->p:Lt4/c;

    const/4 v11, 0x3

    const/4 v10, 0x0

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p2

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {p2, p1}, Lcom/google/android/material/floatingactionbutton/d;->a0(Lcom/google/android/material/shape/o;)V

    const/4 v11, 0x0

    const/4 v10, 0x5

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->b:Landroid/content/res/ColorStateList;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    iget-object p3, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->c:Landroid/graphics/PorterDuff$Mode;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->f:Landroid/content/res/ColorStateList;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    iget v7, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->g:I

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {p1, p2, p3, v0, v7}, Lcom/google/android/material/floatingactionbutton/d;->x(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;Landroid/content/res/ColorStateList;I)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {p1, v4}, Lcom/google/android/material/floatingactionbutton/d;->W(I)V

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {p1, v1}, Lcom/google/android/material/floatingactionbutton/d;->Q(F)V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v11, 0x3

    const/4 v10, 0x2

    invoke-virtual {p1, v3}, Lcom/google/android/material/floatingactionbutton/d;->T(F)V

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {p1, v2}, Lcom/google/android/material/floatingactionbutton/d;->X(F)V

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {p1, v5}, Lcom/google/android/material/floatingactionbutton/d;->b0(Lcom/google/android/material/animation/h;)V

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {p1, v8}, Lcom/google/android/material/floatingactionbutton/d;->S(Lcom/google/android/material/animation/h;)V

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p1, v6}, Lcom/google/android/material/floatingactionbutton/d;->R(Z)V

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x6

    sget-object p1, Landroid/widget/ImageView$ScaleType;->MATRIX:Landroid/widget/ImageView$ScaleType;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {p0, p1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    return-void
.end method

.method private A(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;)Lcom/google/android/material/floatingactionbutton/d$k;
    .locals 3
    .param p1    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p1

    :cond_0
    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$a;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {v0, p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$a;-><init>(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic b(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget p0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->j:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic c(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Landroid/graphics/drawable/Drawable;)V
    .locals 2

    const/4 v1, 0x4

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method private getImpl()Lcom/google/android/material/floatingactionbutton/d;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->q:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->h()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->q:Lcom/google/android/material/floatingactionbutton/d;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->q:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method private h()Lcom/google/android/material/floatingactionbutton/d;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/material/floatingactionbutton/e;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v1, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$c;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$c;-><init>(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V

    const/4 v3, 0x6

    invoke-direct {v0, p0, v1}, Lcom/google/android/material/floatingactionbutton/e;-><init>(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Lcom/google/android/material/shadow/c;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0
.end method

.method private k(I)I
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->i:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    return v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eq p1, v1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eq p1, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    sget p1, Lcom/google/android/material/R$dimen;->design_fab_size_normal:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    return p1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    sget p1, Lcom/google/android/material/R$dimen;->design_fab_size_mini:I

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    return p1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget p1, p1, Landroid/content/res/Configuration;->screenWidthDp:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v0, v0, Landroid/content/res/Configuration;->screenHeightDp:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/16 v0, 0x1d6

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-ge p1, v0, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p0, v2}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->k(I)I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto :goto_0

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->k(I)I

    move-result p1

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    return p1
.end method

.method private q(Landroid/graphics/Rect;)V
    .locals 5
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v0, p1, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->m:Landroid/graphics/Rect;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget v2, v1, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    add-int/2addr v0, v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    iput v0, p1, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget v0, p1, Landroid/graphics/Rect;->top:I

    const/4 v4, 0x0

    iget v2, v1, Landroid/graphics/Rect;->top:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    add-int/2addr v0, v2

    const/4 v4, 0x6

    const/4 v3, 0x5

    iput v0, p1, Landroid/graphics/Rect;->top:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v0, p1, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v2, v1, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x5

    sub-int/2addr v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput v0, p1, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v0, p1, Landroid/graphics/Rect;->bottom:I

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget v1, v1, Landroid/graphics/Rect;->bottom:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    sub-int/2addr v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput v0, p1, Landroid/graphics/Rect;->bottom:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method

.method private r()V
    .locals 6

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->d:Landroid/content/res/ColorStateList;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0}, Landroidx/core/graphics/drawable/d;->c(Landroid/graphics/drawable/Drawable;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v3}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->e:Landroid/graphics/PorterDuff$Mode;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-nez v2, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object v2, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v1, v2}, Landroidx/appcompat/widget/r;->e(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    return-void
.end method

.method private static v(II)I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v0

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/high16 v1, -0x80000000

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eq v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/high16 p0, 0x40000000    # 2.0f

    const/4 v3, 0x3

    if-ne v0, p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    move p0, p1

    move p0, p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    throw p0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p0, p1}, Ljava/lang/Math;->min(II)I

    move-result p0

    :cond_2
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return p0
.end method


# virtual methods
.method public d(Landroid/animation/Animator$AnimatorListener;)V
    .locals 3
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->e(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method protected drawableStateChanged()V
    .locals 4

    const/4 v3, 0x4

    invoke-super {p0}, Landroid/widget/ImageButton;->drawableStateChanged()V

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/google/android/material/floatingactionbutton/d;->E([I)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public e(Landroid/animation/Animator$AnimatorListener;)V
    .locals 3
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->f(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public f(Lcom/google/android/material/animation/k;)V
    .locals 4
    .param p1    # Lcom/google/android/material/animation/k;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/animation/k<",
            "+",
            "Lcom/google/android/material/floatingactionbutton/FloatingActionButton;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v1, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$e;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v1, p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$e;-><init>(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Lcom/google/android/material/animation/k;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/google/android/material/floatingactionbutton/d;->g(Lcom/google/android/material/floatingactionbutton/d$j;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public g()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setCustomSize(I)V

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public getBackgroundTintList()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->b:Landroid/content/res/ColorStateList;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public getBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->c:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout$c<",
            "Lcom/google/android/material/floatingactionbutton/FloatingActionButton;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$Behavior;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$Behavior;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public getCompatElevation()F
    .locals 3

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->n()F

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public getCompatHoveredFocusedTranslationZ()F
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->q()F

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public getCompatPressedTranslationZ()F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->t()F

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public getContentBackground()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->m()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public getCustomSize()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->i:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public getExpandedComponentIdHint()I
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->p:Lt4/c;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Lt4/c;->b()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public getHideMotionSpec()Lcom/google/android/material/animation/h;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->p()Lcom/google/android/material/animation/h;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getRippleColor()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->f:Landroid/content/res/ColorStateList;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public getRippleColorStateList()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->f:Landroid/content/res/ColorStateList;

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public getShapeAppearanceModel()Lcom/google/android/material/shape/o;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->u()Lcom/google/android/material/shape/o;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-static {v0}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/material/shape/o;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public getShowMotionSpec()Lcom/google/android/material/animation/h;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->v()Lcom/google/android/material/animation/h;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-object v0
.end method

.method public getSize()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->h:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    return v0
.end method

.method getSizeDimension()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->h:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->k(I)I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public getSupportBackgroundTintList()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getBackgroundTintList()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public getSupportBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public getSupportImageTintList()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->d:Landroid/content/res/ColorStateList;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public getSupportImageTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->e:Landroid/graphics/PorterDuff$Mode;

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    return-object v0
.end method

.method public getUseCompatPadding()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->l:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public i(Landroid/graphics/Rect;)Z
    .locals 5
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p0}, Landroidx/core/view/k1;->U0(Landroid/view/View;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1, v1, v1, v0, v2}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->q(Landroid/graphics/Rect;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 p1, 0x1

    return p1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    return v1
.end method

.method public isExpanded()Z
    .locals 3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->p:Lt4/c;

    const/4 v2, 0x2

    invoke-virtual {v0}, Lt4/c;->c()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public j(Landroid/graphics/Rect;)V
    .locals 5
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1, v2, v2, v0, v1}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->q(Landroid/graphics/Rect;)V

    const/4 v4, 0x7

    return-void
.end method

.method public jumpDrawablesToCurrentState()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-super {p0}, Landroid/widget/ImageButton;->jumpDrawablesToCurrentState()V

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->A()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public l()V
    .locals 3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->m(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public m(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;)V
    .locals 3
    .param p1    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->n(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;Z)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method n(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;Z)V
    .locals 3
    .param p1    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->A(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;)Lcom/google/android/material/floatingactionbutton/d$k;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1, p2}, Lcom/google/android/material/floatingactionbutton/d;->w(Lcom/google/android/material/floatingactionbutton/d$k;Z)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public o()Z
    .locals 3

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->y()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method protected onAttachedToWindow()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-super {p0}, Landroid/widget/ImageButton;->onAttachedToWindow()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->B()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method protected onDetachedFromWindow()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-super {p0}, Landroid/widget/ImageButton;->onDetachedFromWindow()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->D()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method protected onMeasure(II)V
    .locals 4

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getSizeDimension()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->k:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    sub-int v1, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    div-int/lit8 v1, v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput v1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->j:I

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-virtual {v1}, Lcom/google/android/material/floatingactionbutton/d;->i0()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->v(II)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, p2}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->v(II)I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p1, p2}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->m:Landroid/graphics/Rect;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v0, p2, Landroid/graphics/Rect;->left:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    add-int/2addr v0, p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    iget v1, p2, Landroid/graphics/Rect;->right:I

    const/4 v3, 0x6

    add-int/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v1, p2, Landroid/graphics/Rect;->top:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    add-int/2addr p1, v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget p2, p2, Landroid/graphics/Rect;->bottom:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    add-int/2addr p1, p2

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0, v0, p1}, Landroid/view/View;->setMeasuredDimension(II)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method protected onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    instance-of v0, p1, Lcom/google/android/material/stateful/ExtendableSavedState;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast p1, Lcom/google/android/material/stateful/ExtendableSavedState;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroidx/customview/view/AbsSavedState;->a()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-super {p0, v0}, Landroid/widget/ImageButton;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->p:Lt4/c;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object p1, p1, Lcom/google/android/material/stateful/ExtendableSavedState;->c:Landroidx/collection/m;

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string/jumbo v1, "lssWeieHlreagbxpatendp"

    const-string v1, "desdtelxlpaHiergepnabW"

    const/4 v3, 0x7

    const-string/jumbo v1, "pgemaeeebtxipedldWnlaH"

    const-string/jumbo v1, "expandableWidgetHelper"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, v1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-static {p1}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast p1, Landroid/os/Bundle;

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lt4/c;->d(Landroid/os/Bundle;)V

    const/4 v2, 0x2

    and-int/2addr v3, v2

    return-void
.end method

.method protected onSaveInstanceState()Landroid/os/Parcelable;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-super {p0}, Landroid/widget/ImageButton;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v0, Landroid/os/Bundle;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v1, Lcom/google/android/material/stateful/ExtendableSavedState;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v1, v0}, Lcom/google/android/material/stateful/ExtendableSavedState;-><init>(Landroid/os/Parcelable;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, v1, Lcom/google/android/material/stateful/ExtendableSavedState;->c:Landroidx/collection/m;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->p:Lt4/c;

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-virtual {v2}, Lt4/c;->e()Landroid/os/Bundle;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const-string v3, "endtoxpaebHarWleemilge"

    const-string/jumbo v3, "lpdmleinpHeexearaeWgtb"

    const/4 v5, 0x5

    const-string/jumbo v3, "nedHebigtebpaplxdeaWrl"

    const-string/jumbo v3, "expandableWidgetHelper"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, v3, v2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-object v1
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 5
    .param p1    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->n:Landroid/graphics/Rect;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->i(Landroid/graphics/Rect;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->n:Landroid/graphics/Rect;

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    float-to-int v1, v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    float-to-int v2, v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Rect;->contains(II)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 p1, 0x0

    move v4, p1

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    return p1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    return p1
.end method

.method public p()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->z()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public s(Landroid/animation/Animator$AnimatorListener;)V
    .locals 3
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->K(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public setBackgroundColor(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string p1, "BoatocnntioFtgoinlAu"

    const/4 v2, 0x5

    const-string/jumbo p1, "louiinutcnnottoaFtAg"

    const-string p1, "FloatingActionButton"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string/jumbo v0, "t.os bgsndotenctrptouSarts gu  c di bpiamekuo"

    const/4 v2, 0x1

    const-string v0, "Setting a custom background is not supported."

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-static {p1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 3

    const-string/jumbo p1, "noulFtgptcotuBtnaAno"

    const-string/jumbo p1, "itootFulcnAaBtntuogn"

    const-string p1, "AntacoBnqntuoiliFtot"

    const-string p1, "FloatingActionButton"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string v0, "cus.rngo gdessnr pcttbooetSmkst  ouppdu atiin"

    const-string/jumbo v0, "nmouisuptrntegsdStocepudtg.oropcaia  snt   kb"

    const/4 v2, 0x5

    const-string/jumbo v0, "uammrtipsicngot  d tos etrou pSgancu tno.edks"

    const-string v0, "Setting a custom background is not supported."

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public setBackgroundResource(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo p1, "totioonniqAugaFotlnt"

    const-string/jumbo p1, "ionacutFqtiltoAtognn"

    const/4 v2, 0x0

    const-string p1, "AFotubtlnioaoitnBcnt"

    const-string p1, "FloatingActionButton"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo v0, "poaip ug kutid srnda ottsumcrose.co tnnsbStue"

    const-string/jumbo v0, "ussdtscgbtS sk pmd tiru otpnuaeo rn.nit coaeo"

    const-string/jumbo v0, "ooabo .pudSuse ucginsarert n ppsticttngm tod "

    const-string v0, "Setting a custom background is not supported."

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public setBackgroundTintList(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->b:Landroid/content/res/ColorStateList;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->b:Landroid/content/res/ColorStateList;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->O(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public setBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 3
    .param p1    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->c:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eq v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->c:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->P(Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public setCompatElevation(F)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->Q(F)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public setCompatElevationResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setCompatElevation(F)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public setCompatHoveredFocusedTranslationZ(F)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->T(F)V

    const/4 v2, 0x3

    return-void
.end method

.method public setCompatHoveredFocusedTranslationZResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setCompatHoveredFocusedTranslationZ(F)V

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public setCompatPressedTranslationZ(F)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->X(F)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public setCompatPressedTranslationZResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setCompatPressedTranslationZ(F)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public setCustomSize(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-ltz p1, :cond_1

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->i:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eq p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->i:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x6

    const-string v0, "Custom size must be non-negative"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    throw p1
.end method

.method public setElevation(F)V
    .locals 3
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setElevation(F)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->j0(F)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public setEnsureMinTouchTargetSize(Z)V
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->o()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eq p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->R(Z)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public setExpanded(Z)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->p:Lt4/c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lt4/c;->f(Z)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return p1
.end method

.method public setExpandedComponentIdHint(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->p:Lt4/c;

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lt4/c;->g(I)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public setHideMotionSpec(Lcom/google/android/material/animation/h;)V
    .locals 3
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->S(Lcom/google/android/material/animation/h;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public setHideMotionSpecResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/b;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lcom/google/android/material/animation/h;->d(Landroid/content/Context;I)Lcom/google/android/material/animation/h;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setHideMotionSpec(Lcom/google/android/material/animation/h;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public setImageDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    if-eq v0, p1, :cond_0

    const/4 v1, 0x5

    move v2, v1

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/android/material/floatingactionbutton/d;->h0()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->d:Landroid/content/res/ColorStateList;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->r()V

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public setImageResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->o:Landroidx/appcompat/widget/x;

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/x;->i(I)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->r()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public setMaxImageSize(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->k:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->V(I)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public setRippleColor(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setRippleColor(Landroid/content/res/ColorStateList;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public setRippleColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->f:Landroid/content/res/ColorStateList;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->f:Landroid/content/res/ColorStateList;

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->f:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/material/floatingactionbutton/d;->Y(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public setScaleX(F)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setScaleX(F)V

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/floatingactionbutton/d;->I()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public setScaleY(F)V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setScaleY(F)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/floatingactionbutton/d;->I()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public setShadowPaddingEnabled(Z)V
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->Z(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V
    .locals 3
    .param p1    # Lcom/google/android/material/shape/o;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->a0(Lcom/google/android/material/shape/o;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public setShowMotionSpec(Lcom/google/android/material/animation/h;)V
    .locals 3
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->b0(Lcom/google/android/material/animation/h;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public setShowMotionSpecResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/b;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-static {v0, p1}, Lcom/google/android/material/animation/h;->d(Landroid/content/Context;I)Lcom/google/android/material/animation/h;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setShowMotionSpec(Lcom/google/android/material/animation/h;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public setSize(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x3

    iput v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->i:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->h:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eq p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->h:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public setSupportBackgroundTintList(Landroid/content/res/ColorStateList;)V
    .locals 2
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public setSupportBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 2
    .param p1    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V

    const/4 v1, 0x6

    return-void
.end method

.method public setSupportImageTintList(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->d:Landroid/content/res/ColorStateList;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eq v0, p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->d:Landroid/content/res/ColorStateList;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->r()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public setSupportImageTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 3
    .param p1    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->e:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eq v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->e:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->r()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public setTranslationX(F)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setTranslationX(F)V

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/google/android/material/floatingactionbutton/d;->J()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public setTranslationY(F)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setTranslationY(F)V

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-virtual {p1}, Lcom/google/android/material/floatingactionbutton/d;->J()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public setTranslationZ(F)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroid/widget/ImageButton;->setTranslationZ(F)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/floatingactionbutton/d;->J()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public setUseCompatPadding(Z)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->l:Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->l:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/android/material/floatingactionbutton/d;->C()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public setVisibility(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/android/material/internal/VisibilityAwareImageButton;->setVisibility(I)V

    const/4 v1, 0x7

    return-void
.end method

.method public t(Landroid/animation/Animator$AnimatorListener;)V
    .locals 3
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/d;->L(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public u(Lcom/google/android/material/animation/k;)V
    .locals 4
    .param p1    # Lcom/google/android/material/animation/k;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/animation/k<",
            "+",
            "Lcom/google/android/material/floatingactionbutton/FloatingActionButton;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v1, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$e;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v1, p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$e;-><init>(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Lcom/google/android/material/animation/k;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/floatingactionbutton/d;->M(Lcom/google/android/material/floatingactionbutton/d$j;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public w()Z
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/d;->o()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public x()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->y(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public y(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;)V
    .locals 3
    .param p1    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->z(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;Z)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method z(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;Z)V
    .locals 3
    .param p1    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getImpl()Lcom/google/android/material/floatingactionbutton/d;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->A(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;)Lcom/google/android/material/floatingactionbutton/d$k;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    invoke-virtual {v0, p1, p2}, Lcom/google/android/material/floatingactionbutton/d;->f0(Lcom/google/android/material/floatingactionbutton/d$k;Z)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method
