.class public Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;
.super Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xc
    name = "BaseBehavior"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Lcom/google/android/material/floatingactionbutton/FloatingActionButton;",
        ">",
        "Landroidx/coordinatorlayout/widget/CoordinatorLayout$c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final d:Z = true


# instance fields
.field private a:Landroid/graphics/Rect;

.field private b:Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;

.field private c:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->c:Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/material/R$styleable;->FloatingActionButton_Behavior_Layout:[I

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget p2, Lcom/google/android/material/R$styleable;->FloatingActionButton_Behavior_Layout_behavior_autoHide:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-virtual {p1, p2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-boolean p2, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->c:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method private static c(Landroid/view/View;)Z
    .locals 3
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~1s fi o~s ~  @ ~rivb @l@@~~-Sm~~t @~~@@~ @@oK@@atb/fl/@ ~.~uo~~@4~@~@ ~@ @  od~b  ~@o@~Mi@oc n~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    instance-of v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    check-cast p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    instance-of p0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return p0

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p0, 0x0

    const/4 v2, 0x4

    return p0
.end method

.method private d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V
    .locals 8
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x2

    const/4 v6, 0x4

    iget-object v0, p2, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->m:Landroid/graphics/Rect;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v0, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0}, Landroid/graphics/Rect;->centerX()I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-lez v1, :cond_5

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0}, Landroid/graphics/Rect;->centerY()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-lez v1, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    check-cast v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p2}, Landroid/view/View;->getRight()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget v4, v1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    sub-int/2addr v3, v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/4 v4, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-lt v2, v3, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget v2, v0, Landroid/graphics/Rect;->right:I

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget v3, v1, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-gt v2, v3, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget v2, v0, Landroid/graphics/Rect;->left:I

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    neg-int v2, v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto :goto_0

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    move v2, v4

    move v2, v4

    const/4 v7, 0x0

    move v2, v4

    move v2, v4

    :goto_0
    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p2}, Landroid/view/View;->getBottom()I

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget v5, v1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    sub-int/2addr p1, v5

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-lt v3, p1, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget v4, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_1

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget v1, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-gt p1, v1, :cond_3

    const/4 v7, 0x2

    iget p1, v0, Landroid/graphics/Rect;->top:I

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    neg-int v4, p1

    :cond_3
    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eqz v4, :cond_4

    const/4 v7, 0x1

    invoke-static {p2, v4}, Landroidx/core/view/k1;->f1(Landroid/view/View;I)V

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz v2, :cond_5

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {p2, v2}, Landroidx/core/view/k1;->e1(Landroid/view/View;I)V

    :cond_5
    const/4 v7, 0x5

    return-void
.end method

.method private i(Landroid/view/View;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)Z
    .locals 5
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v4, 0x5

    iget-boolean v1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->c:Z

    const/4 v4, 0x4

    const/4 v2, 0x5

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    return v2

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->e()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eq v0, p1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v2

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2}, Lcom/google/android/material/internal/VisibilityAwareImageButton;->getUserSetVisibility()I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz p1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    return v2

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x4

    const/4 v3, 0x3

    return p1
.end method

.method private j(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)Z
    .locals 4
    .param p2    # Lcom/google/android/material/appbar/AppBarLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x1

    invoke-direct {p0, p2, p3}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->i(Landroid/view/View;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v1

    :cond_0
    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->a:Landroid/graphics/Rect;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x5

    move v3, v2

    new-instance v0, Landroid/graphics/Rect;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->a:Landroid/graphics/Rect;

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->a:Landroid/graphics/Rect;

    const/4 v3, 0x1

    invoke-static {p1, p2, v0}, Lcom/google/android/material/internal/d;->a(Landroid/view/ViewGroup;Landroid/view/View;Landroid/graphics/Rect;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget p1, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p2}, Lcom/google/android/material/appbar/AppBarLayout;->getMinimumHeightForVisibleOverlappingContent()I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-gt p1, p2, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->b:Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p3, p1, v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->n(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;Z)V

    const/4 v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->b:Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p3, p1, v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->z(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;Z)V

    :goto_0
    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 p1, 0x1

    const/4 v3, 0x1

    return p1
.end method

.method private k(Landroid/view/View;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)Z
    .locals 5
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->i(Landroid/view/View;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    return v1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-virtual {p2}, Landroid/view/View;->getHeight()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    div-int/lit8 v2, v2, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    add-int/2addr v2, v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-ge p1, v2, :cond_1

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->b:Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p2, p1, v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->n(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;Z)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->b:Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p2, p1, v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->z(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;Z)V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 p1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    return p1
.end method


# virtual methods
.method public a(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Landroid/graphics/Rect;)Z
    .locals 6
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object p1, p2, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->m:Landroid/graphics/Rect;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget v1, p1, Landroid/graphics/Rect;->left:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    add-int/2addr v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget v2, p1, Landroid/graphics/Rect;->top:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    add-int/2addr v1, v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p2}, Landroid/view/View;->getRight()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget v3, p1, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x2

    move v5, v4

    sub-int/2addr v2, v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p2}, Landroid/view/View;->getBottom()I

    move-result p2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    sub-int/2addr p2, p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p3, v0, v1, v2, p2}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 p1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    return p1
.end method

.method public b()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->c:Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    return v0
.end method

.method public e(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Landroid/view/View;)Z
    .locals 3
    .param p2    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    instance-of v0, p3, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast p3, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0, p1, p3, p2}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->j(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p3}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->c(Landroid/view/View;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, p3, p2}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->k(Landroid/view/View;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)Z

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return p1
.end method

.method public f(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;I)Z
    .locals 7
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->q(Landroid/view/View;)Ljava/util/List;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-ge v2, v1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    check-cast v3, Landroid/view/View;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    instance-of v4, v3, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v4, :cond_0

    const/4 v6, 0x6

    check-cast v3, Lcom/google/android/material/appbar/AppBarLayout;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {p0, p1, v3, p2}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->j(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/appbar/AppBarLayout;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)Z

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz v3, :cond_1

    const/4 v5, 0x5

    or-int/2addr v6, v5

    goto :goto_1

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v3}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->c(Landroid/view/View;)Z

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v4, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-direct {p0, v3, p2}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->k(Landroid/view/View;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_1

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v5, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->H(Landroid/view/View;I)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 p1, 0x1

    const/4 v6, 0x2

    return p1
.end method

.method public g(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->c:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public bridge synthetic getInsetDodgeRect(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/graphics/Rect;)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    check-cast p2, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->a(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Landroid/graphics/Rect;)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    return p1
.end method

.method public h(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;)V
    .locals 2
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->b:Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public onAttachedToLayoutParams(Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;)V
    .locals 3
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget v0, p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->h:I

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/16 v0, 0x50

    const/4 v2, 0x4

    const/4 v1, 0x0

    iput v0, p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->h:I

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public bridge synthetic onDependentViewChanged(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    .locals 2
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    check-cast p2, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v1, 0x7

    const/4 v0, 0x3

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->e(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Landroid/view/View;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return p1
.end method

.method public bridge synthetic onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x5

    const/4 v1, 0x7

    check-cast p2, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$BaseBehavior;->f(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;I)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return p1
.end method
