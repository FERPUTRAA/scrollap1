.class Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$d;
.super Landroid/util/Property;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "Landroid/view/View;",
        "Ljava/lang/Float;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/Class;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;)Ljava/lang/Float;
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "fssl~~ ~@odlf~~ @b/ @o@i~ci- t  u  ~ ~vb@@ i~~~~~ ~@@aobo @.@@@@r@~y/mM1~@ ~~@@o~@n@  ~oK~~ 4 @t"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget p1, p1, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    int-to-float p1, p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    return-object p1
.end method

.method public b(Landroid/view/View;Ljava/lang/Float;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Float;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p2}, Ljava/lang/Float;->intValue()I

    move-result p2

    const/4 v2, 0x5

    const/4 v1, 0x1

    iput p2, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    const/4 v2, 0x2

    return-void
.end method

.method public bridge synthetic get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    check-cast p1, Landroid/view/View;

    const/4 v0, 0x1

    move v1, v0

    invoke-virtual {p0, p1}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$d;->a(Landroid/view/View;)Ljava/lang/Float;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    check-cast p1, Landroid/view/View;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    check-cast p2, Ljava/lang/Float;

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton$d;->b(Landroid/view/View;Ljava/lang/Float;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method
