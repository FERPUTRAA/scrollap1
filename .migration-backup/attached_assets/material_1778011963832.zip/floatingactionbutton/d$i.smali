.class Lcom/google/android/material/floatingactionbutton/d$i;
.super Lcom/google/android/material/floatingactionbutton/d$m;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/floatingactionbutton/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "i"
.end annotation


# instance fields
.field final synthetic e:Lcom/google/android/material/floatingactionbutton/d;


# direct methods
.method constructor <init>(Lcom/google/android/material/floatingactionbutton/d;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d$i;->e:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/floatingactionbutton/d$m;-><init>(Lcom/google/android/material/floatingactionbutton/d;Lcom/google/android/material/floatingactionbutton/d$a;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected a()F
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "l.s@@ ao~@S @~@i ys@/@@ibt~~@v~of/oc@@o~uo1~~ i~ m @ @~-t4~ ~~b d~~n~@  MK ~~~@@@b~~~lr@  f@@   "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d$i;->e:Lcom/google/android/material/floatingactionbutton/d;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, v0, Lcom/google/android/material/floatingactionbutton/d;->h:F

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget v0, v0, Lcom/google/android/material/floatingactionbutton/d;->j:F

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    add-float/2addr v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return v1
.end method
