.class Lcom/google/android/material/floatingactionbutton/d;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/floatingactionbutton/d$g;,
        Lcom/google/android/material/floatingactionbutton/d$i;,
        Lcom/google/android/material/floatingactionbutton/d$h;,
        Lcom/google/android/material/floatingactionbutton/d$l;,
        Lcom/google/android/material/floatingactionbutton/d$m;,
        Lcom/google/android/material/floatingactionbutton/d$k;,
        Lcom/google/android/material/floatingactionbutton/d$j;
    }
.end annotation


# static fields
.field static final D:Landroid/animation/TimeInterpolator;

.field static final E:J = 0x64L

.field static final F:J = 0x64L

.field static final G:I = 0x0

.field static final H:I = 0x1

.field static final I:I = 0x2

.field static final J:F = 1.5f

.field private static final K:F = 0.0f

.field private static final L:F = 0.4f

.field private static final M:F = 0.4f

.field private static final N:F = 1.0f

.field private static final O:F = 1.0f

.field private static final P:F = 1.0f

.field private static final Q:F

.field private static final R:F

.field static final S:[I

.field static final T:[I

.field static final U:[I

.field static final V:[I

.field static final W:[I

.field static final X:[I


# instance fields
.field private final A:Landroid/graphics/RectF;

.field private final B:Landroid/graphics/Matrix;

.field private C:Landroid/view/ViewTreeObserver$OnPreDrawListener;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field a:Lcom/google/android/material/shape/o;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field b:Lcom/google/android/material/shape/j;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field c:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field d:Lcom/google/android/material/floatingactionbutton/c;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field e:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field f:Z

.field g:Z

.field h:F

.field i:F

.field j:F

.field k:I

.field private final l:Lcom/google/android/material/internal/l;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private m:Landroid/animation/Animator;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private n:Lcom/google/android/material/animation/h;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private o:Lcom/google/android/material/animation/h;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private p:F

.field private q:F

.field private r:I

.field private s:I

.field private t:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/animation/Animator$AnimatorListener;",
            ">;"
        }
    .end annotation
.end field

.field private u:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/animation/Animator$AnimatorListener;",
            ">;"
        }
    .end annotation
.end field

.field private v:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/google/android/material/floatingactionbutton/d$j;",
            ">;"
        }
    .end annotation
.end field

.field final w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

.field final x:Lcom/google/android/material/shadow/c;

.field private final y:Landroid/graphics/Rect;

.field private final z:Landroid/graphics/RectF;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    sget-object v0, Lcom/google/android/material/animation/a;->c:Landroid/animation/TimeInterpolator;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    sput-object v0, Lcom/google/android/material/floatingactionbutton/d;->D:Landroid/animation/TimeInterpolator;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    const v0, 0x10100a7

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const v1, 0x101009e

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    filled-new-array {v0, v1}, [I

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    sput-object v0, Lcom/google/android/material/floatingactionbutton/d;->S:[I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    const v0, 0x1010367

    const/4 v5, 0x5

    const/4 v4, 0x2

    const v2, 0x101009c

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    filled-new-array {v0, v2, v1}, [I

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    sput-object v3, Lcom/google/android/material/floatingactionbutton/d;->T:[I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    filled-new-array {v2, v1}, [I

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    sput-object v2, Lcom/google/android/material/floatingactionbutton/d;->U:[I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    filled-new-array {v0, v1}, [I

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    sput-object v0, Lcom/google/android/material/floatingactionbutton/d;->V:[I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    filled-new-array {v1}, [I

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    sput-object v0, Lcom/google/android/material/floatingactionbutton/d;->W:[I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-array v0, v0, [I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    sput-object v0, Lcom/google/android/material/floatingactionbutton/d;->X:[I

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-void
.end method

.method constructor <init>(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;Lcom/google/android/material/shadow/c;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/d;->g:Z

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput v0, p0, Lcom/google/android/material/floatingactionbutton/d;->q:F

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput v0, p0, Lcom/google/android/material/floatingactionbutton/d;->s:I

    const/4 v2, 0x4

    move v3, v2

    new-instance v0, Landroid/graphics/Rect;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->y:Landroid/graphics/Rect;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Landroid/graphics/RectF;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->z:Landroid/graphics/RectF;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Landroid/graphics/RectF;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0}, Landroid/graphics/RectF;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->A:Landroid/graphics/RectF;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Landroid/graphics/Matrix;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {v0}, Landroid/graphics/Matrix;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->B:Landroid/graphics/Matrix;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v3, 0x7

    const/4 v2, 0x0

    iput-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->x:Lcom/google/android/material/shadow/c;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance p2, Lcom/google/android/material/internal/l;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p2}, Lcom/google/android/material/internal/l;-><init>()V

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->l:Lcom/google/android/material/internal/l;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v0, Lcom/google/android/material/floatingactionbutton/d;->S:[I

    const/4 v3, 0x1

    const/4 v2, 0x1

    new-instance v1, Lcom/google/android/material/floatingactionbutton/d$i;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v1, p0}, Lcom/google/android/material/floatingactionbutton/d$i;-><init>(Lcom/google/android/material/floatingactionbutton/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0, v1}, Lcom/google/android/material/floatingactionbutton/d;->k(Lcom/google/android/material/floatingactionbutton/d$m;)Landroid/animation/ValueAnimator;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p2, v0, v1}, Lcom/google/android/material/internal/l;->a([ILandroid/animation/ValueAnimator;)V

    const/4 v3, 0x4

    sget-object v0, Lcom/google/android/material/floatingactionbutton/d;->T:[I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v1, Lcom/google/android/material/floatingactionbutton/d$h;

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/google/android/material/floatingactionbutton/d$h;-><init>(Lcom/google/android/material/floatingactionbutton/d;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0, v1}, Lcom/google/android/material/floatingactionbutton/d;->k(Lcom/google/android/material/floatingactionbutton/d$m;)Landroid/animation/ValueAnimator;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p2, v0, v1}, Lcom/google/android/material/internal/l;->a([ILandroid/animation/ValueAnimator;)V

    const/4 v3, 0x6

    sget-object v0, Lcom/google/android/material/floatingactionbutton/d;->U:[I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v1, Lcom/google/android/material/floatingactionbutton/d$h;

    const/4 v2, 0x6

    const/4 v2, 0x7

    invoke-direct {v1, p0}, Lcom/google/android/material/floatingactionbutton/d$h;-><init>(Lcom/google/android/material/floatingactionbutton/d;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {p0, v1}, Lcom/google/android/material/floatingactionbutton/d;->k(Lcom/google/android/material/floatingactionbutton/d$m;)Landroid/animation/ValueAnimator;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p2, v0, v1}, Lcom/google/android/material/internal/l;->a([ILandroid/animation/ValueAnimator;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v0, Lcom/google/android/material/floatingactionbutton/d;->V:[I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v1, Lcom/google/android/material/floatingactionbutton/d$h;

    const/4 v3, 0x7

    invoke-direct {v1, p0}, Lcom/google/android/material/floatingactionbutton/d$h;-><init>(Lcom/google/android/material/floatingactionbutton/d;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0, v1}, Lcom/google/android/material/floatingactionbutton/d;->k(Lcom/google/android/material/floatingactionbutton/d$m;)Landroid/animation/ValueAnimator;

    move-result-object v1

    const/4 v3, 0x2

    invoke-virtual {p2, v0, v1}, Lcom/google/android/material/internal/l;->a([ILandroid/animation/ValueAnimator;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v0, Lcom/google/android/material/floatingactionbutton/d;->W:[I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v1, Lcom/google/android/material/floatingactionbutton/d$l;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/google/android/material/floatingactionbutton/d$l;-><init>(Lcom/google/android/material/floatingactionbutton/d;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p0, v1}, Lcom/google/android/material/floatingactionbutton/d;->k(Lcom/google/android/material/floatingactionbutton/d$m;)Landroid/animation/ValueAnimator;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p2, v0, v1}, Lcom/google/android/material/internal/l;->a([ILandroid/animation/ValueAnimator;)V

    const/4 v2, 0x4

    move v3, v2

    sget-object v0, Lcom/google/android/material/floatingactionbutton/d;->X:[I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v1, Lcom/google/android/material/floatingactionbutton/d$g;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v1, p0}, Lcom/google/android/material/floatingactionbutton/d$g;-><init>(Lcom/google/android/material/floatingactionbutton/d;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0, v1}, Lcom/google/android/material/floatingactionbutton/d;->k(Lcom/google/android/material/floatingactionbutton/d$m;)Landroid/animation/ValueAnimator;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p2, v0, v1}, Lcom/google/android/material/internal/l;->a([ILandroid/animation/ValueAnimator;)V

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p1}, Landroid/view/View;->getRotation()F

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/d;->p:F

    const/4 v3, 0x4

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/floatingactionbutton/d;I)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b~s~@ o~@  n @K@@st~.f4 b@~o~/@~ @~lf~o1 ~v@Mbi@S~@l@@ @  im~uot~@~c@d~ ~~ooy~a @ ~r -/ @~@i~~ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/d;->s:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return p1
.end method

.method static synthetic b(Lcom/google/android/material/floatingactionbutton/d;Landroid/animation/Animator;)Landroid/animation/Animator;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->m:Landroid/animation/Animator;

    const/4 v0, 0x7

    xor-int/2addr v1, v0

    return-object p1
.end method

.method static synthetic c(Lcom/google/android/material/floatingactionbutton/d;F)F
    .locals 2

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/d;->q:F

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic d(Lcom/google/android/material/floatingactionbutton/d;FLandroid/graphics/Matrix;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/floatingactionbutton/d;->h(FLandroid/graphics/Matrix;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-void
.end method

.method private d0()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0}, Landroidx/core/view/k1;->U0(Landroid/view/View;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/view/View;->isInEditMode()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method private h(FLandroid/graphics/Matrix;)V
    .locals 7
    .param p2    # Landroid/graphics/Matrix;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p2}, Landroid/graphics/Matrix;->reset()V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d;->r:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->z:Landroid/graphics/RectF;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/d;->A:Landroid/graphics/RectF;

    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    int-to-float v3, v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    int-to-float v0, v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v4, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1, v4, v4, v3, v0}, Landroid/graphics/RectF;->set(FFFF)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->r:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    int-to-float v3, v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    int-to-float v0, v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v2, v4, v4, v3, v0}, Landroid/graphics/RectF;->set(FFFF)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    sget-object v0, Landroid/graphics/Matrix$ScaleToFit;->CENTER:Landroid/graphics/Matrix$ScaleToFit;

    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {p2, v1, v2, v0}, Landroid/graphics/Matrix;->setRectToRect(Landroid/graphics/RectF;Landroid/graphics/RectF;Landroid/graphics/Matrix$ScaleToFit;)Z

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->r:I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    int-to-float v1, v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    div-float/2addr v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    int-to-float v0, v0

    const/4 v6, 0x7

    div-float/2addr v0, v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p2, p1, p1, v1, v0}, Landroid/graphics/Matrix;->postScale(FFFF)Z

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-void
.end method

.method private i(Lcom/google/android/material/animation/h;FFF)Landroid/animation/AnimatorSet;
    .locals 8
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x3

    const/4 v6, 0x3

    sget-object v2, Landroid/view/View;->ALPHA:Landroid/util/Property;

    const/4 v3, 0x0

    or-int/2addr v7, v3

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    new-array v4, v3, [F

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 v5, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    aput p2, v4, v5

    const/4 v7, 0x7

    invoke-static {v1, v2, v4}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object p2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const-string/jumbo v1, "tspmaci"

    const-string v1, "aisctpy"

    const/4 v7, 0x3

    const-string/jumbo v1, "itoyoca"

    const-string/jumbo v1, "opacity"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p1, v1}, Lcom/google/android/material/animation/h;->h(Ljava/lang/String;)Lcom/google/android/material/animation/i;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v1, p2}, Lcom/google/android/material/animation/i;->a(Landroid/animation/Animator;)V

    const/4 v7, 0x1

    invoke-interface {v0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x2

    sget-object v1, Landroid/view/View;->SCALE_X:Landroid/util/Property;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-array v2, v3, [F

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    aput p3, v2, v5

    const/4 v6, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {p2, v1, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v1, "casme"

    const/4 v7, 0x2

    const-string v1, "besca"

    const-string/jumbo v1, "scale"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p1, v1}, Lcom/google/android/material/animation/h;->h(Ljava/lang/String;)Lcom/google/android/material/animation/i;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v2, p2}, Lcom/google/android/material/animation/i;->a(Landroid/animation/Animator;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {p0, p2}, Lcom/google/android/material/floatingactionbutton/d;->k0(Landroid/animation/ObjectAnimator;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-interface {v0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    sget-object v2, Landroid/view/View;->SCALE_Y:Landroid/util/Property;

    const/4 v6, 0x1

    move v7, v6

    new-array v4, v3, [F

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    aput p3, v4, v5

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {p2, v2, v4}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object p2

    const/4 v7, 0x3

    const/4 v6, 0x7

    invoke-virtual {p1, v1}, Lcom/google/android/material/animation/h;->h(Ljava/lang/String;)Lcom/google/android/material/animation/i;

    move-result-object p3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p3, p2}, Lcom/google/android/material/animation/i;->a(Landroid/animation/Animator;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-direct {p0, p2}, Lcom/google/android/material/floatingactionbutton/d;->k0(Landroid/animation/ObjectAnimator;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-interface {v0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x7

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->B:Landroid/graphics/Matrix;

    const/4 v7, 0x6

    invoke-direct {p0, p4, p2}, Lcom/google/android/material/floatingactionbutton/d;->h(FLandroid/graphics/Matrix;)V

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x3

    const/4 v6, 0x1

    new-instance p3, Lcom/google/android/material/animation/f;

    const/4 v7, 0x4

    invoke-direct {p3}, Lcom/google/android/material/animation/f;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    new-instance p4, Lcom/google/android/material/floatingactionbutton/d$c;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {p4, p0}, Lcom/google/android/material/floatingactionbutton/d$c;-><init>(Lcom/google/android/material/floatingactionbutton/d;)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-array v1, v3, [Landroid/graphics/Matrix;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-instance v2, Landroid/graphics/Matrix;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v3, p0, Lcom/google/android/material/floatingactionbutton/d;->B:Landroid/graphics/Matrix;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {v2, v3}, Landroid/graphics/Matrix;-><init>(Landroid/graphics/Matrix;)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    aput-object v2, v1, v5

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p2, p3, p4, v1}, Landroid/animation/ObjectAnimator;->ofObject(Ljava/lang/Object;Landroid/util/Property;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/ObjectAnimator;

    move-result-object p2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string/jumbo p3, "ilceSouoa"

    const-string p3, "cacSoolei"

    const/4 v7, 0x0

    const-string/jumbo p3, "nSlcceipa"

    const-string/jumbo p3, "iconScale"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p1, p3}, Lcom/google/android/material/animation/h;->h(Ljava/lang/String;)Lcom/google/android/material/animation/i;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p1, p2}, Lcom/google/android/material/animation/i;->a(Landroid/animation/Animator;)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-interface {v0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    new-instance p1, Landroid/animation/AnimatorSet;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-direct {p1}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {p1, v0}, Lcom/google/android/material/animation/b;->a(Landroid/animation/AnimatorSet;Ljava/util/List;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    return-object p1
.end method

.method private j(FFF)Landroid/animation/AnimatorSet;
    .locals 15

    move-object v10, p0

    move-object v10, p0

    move-object v10, p0

    move-object v10, p0

    new-instance v11, Landroid/animation/AnimatorSet;

    invoke-direct {v11}, Landroid/animation/AnimatorSet;-><init>()V

    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    const/4 v0, 0x2

    new-array v0, v0, [F

    fill-array-data v0, :array_0

    invoke-static {v0}, Landroid/animation/ValueAnimator;->ofFloat([F)Landroid/animation/ValueAnimator;

    move-result-object v13

    iget-object v0, v10, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    invoke-virtual {v0}, Landroid/view/View;->getAlpha()F

    move-result v2

    iget-object v0, v10, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    invoke-virtual {v0}, Landroid/view/View;->getScaleX()F

    move-result v4

    iget-object v0, v10, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    invoke-virtual {v0}, Landroid/view/View;->getScaleY()F

    move-result v6

    iget v7, v10, Lcom/google/android/material/floatingactionbutton/d;->q:F

    new-instance v9, Landroid/graphics/Matrix;

    iget-object v0, v10, Lcom/google/android/material/floatingactionbutton/d;->B:Landroid/graphics/Matrix;

    invoke-direct {v9, v0}, Landroid/graphics/Matrix;-><init>(Landroid/graphics/Matrix;)V

    new-instance v14, Lcom/google/android/material/floatingactionbutton/d$d;

    move-object v0, v14

    move-object v0, v14

    move-object v0, v14

    move-object v0, v14

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move/from16 v3, p1

    move/from16 v3, p1

    move/from16 v3, p1

    move/from16 v3, p1

    move/from16 v5, p2

    move/from16 v8, p3

    move/from16 v8, p3

    invoke-direct/range {v0 .. v9}, Lcom/google/android/material/floatingactionbutton/d$d;-><init>(Lcom/google/android/material/floatingactionbutton/d;FFFFFFFLandroid/graphics/Matrix;)V

    invoke-virtual {v13, v14}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    invoke-interface {v12, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-static {v11, v12}, Lcom/google/android/material/animation/b;->a(Landroid/animation/AnimatorSet;Ljava/util/List;)V

    iget-object v0, v10, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    sget v1, Lcom/google/android/material/R$attr;->motionDurationLong1:I

    iget-object v2, v10, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    sget v3, Lcom/google/android/material/R$integer;->material_motion_duration_long_1:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getInteger(I)I

    move-result v2

    invoke-static {v0, v1, v2}, Lv4/a;->d(Landroid/content/Context;II)I

    move-result v0

    int-to-long v0, v0

    invoke-virtual {v11, v0, v1}, Landroid/animation/AnimatorSet;->setDuration(J)Landroid/animation/AnimatorSet;

    iget-object v0, v10, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    sget v1, Lcom/google/android/material/R$attr;->motionEasingStandard:I

    sget-object v2, Lcom/google/android/material/animation/a;->b:Landroid/animation/TimeInterpolator;

    invoke-static {v0, v1, v2}, Lv4/a;->e(Landroid/content/Context;ILandroid/animation/TimeInterpolator;)Landroid/animation/TimeInterpolator;

    move-result-object v0

    invoke-virtual {v11, v0}, Landroid/animation/AnimatorSet;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    return-object v11

    nop

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method private k(Lcom/google/android/material/floatingactionbutton/d$m;)Landroid/animation/ValueAnimator;
    .locals 5
    .param p1    # Lcom/google/android/material/floatingactionbutton/d$m;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v0, Landroid/animation/ValueAnimator;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {v0}, Landroid/animation/ValueAnimator;-><init>()V

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v1, Lcom/google/android/material/floatingactionbutton/d;->D:Landroid/animation/TimeInterpolator;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const-wide/16 v1, 0x64

    const-wide/16 v1, 0x64

    const/4 v4, 0x0

    const-wide/16 v1, 0x64

    const-wide/16 v1, 0x64

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Landroid/animation/ValueAnimator;->addUpdateListener(Landroid/animation/ValueAnimator$AnimatorUpdateListener;)V

    const/4 v4, 0x6

    const/4 p1, 0x2

    const/4 v4, 0x0

    move v3, p1

    move v3, p1

    const/4 v4, 0x7

    new-array p1, p1, [F

    const/4 v4, 0x1

    const/4 v3, 0x2

    fill-array-data p1, :array_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Landroid/animation/ValueAnimator;->setFloatValues([F)V

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object v0

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method private k0(Landroid/animation/ObjectAnimator;)V
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/16 v1, 0x1a

    const/4 v3, 0x0

    const/4 v2, 0x0

    if-eq v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    new-instance v0, Lcom/google/android/material/floatingactionbutton/d$e;

    const/4 v3, 0x2

    invoke-direct {v0, p0}, Lcom/google/android/material/floatingactionbutton/d$e;-><init>(Lcom/google/android/material/floatingactionbutton/d;)V

    invoke-virtual {p1, v0}, Landroid/animation/ValueAnimator;->setEvaluator(Landroid/animation/TypeEvaluator;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method private r()Landroid/view/ViewTreeObserver$OnPreDrawListener;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->C:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/floatingactionbutton/d$f;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/google/android/material/floatingactionbutton/d$f;-><init>(Lcom/google/android/material/floatingactionbutton/d;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->C:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->C:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    const/4 v2, 0x0

    const/4 v1, 0x1

    return-object v0
.end method


# virtual methods
.method A()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->l:Lcom/google/android/material/internal/l;

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/internal/l;->c()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method B()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/google/android/material/shape/k;->f(Landroid/view/View;Lcom/google/android/material/shape/j;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->N()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/d;->r()Landroid/view/ViewTreeObserver$OnPreDrawListener;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method C()V
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method D()V
    .locals 4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->C:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->C:Landroid/view/ViewTreeObserver$OnPreDrawListener;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method E([I)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->l:Lcom/google/android/material/internal/l;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/l;->d([I)V

    const/4 v2, 0x7

    return-void
.end method

.method F(FFF)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->i0()V

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/floatingactionbutton/d;->j0(F)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method G(Landroid/graphics/Rect;)V
    .locals 9
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->e:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string/jumbo v1, "t  iudoiqnn reiecoadnt/tcbnlikignbtaz"

    const-string v1, "e/otrbdenkdzDbi nauniicil tn cniagott"

    const/4 v8, 0x0

    const-string v1, "Didn\'t initialize content background"

    const/4 v8, 0x7

    invoke-static {v0, v1}, Landroidx/core/util/q;->m(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x2

    shl-int/2addr v8, v7

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->c0()Z

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    new-instance v0, Landroid/graphics/drawable/InsetDrawable;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object v2, p0, Lcom/google/android/material/floatingactionbutton/d;->e:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget v3, p1, Landroid/graphics/Rect;->left:I

    const/4 v7, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget v4, p1, Landroid/graphics/Rect;->top:I

    const/4 v8, 0x4

    iget v5, p1, Landroid/graphics/Rect;->right:I

    const/4 v8, 0x6

    const/4 v7, 0x2

    iget v6, p1, Landroid/graphics/Rect;->bottom:I

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct/range {v1 .. v6}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    const/4 v7, 0x4

    move v8, v7

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->x:Lcom/google/android/material/shadow/c;

    const/4 v7, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-interface {p1, v0}, Lcom/google/android/material/shadow/c;->c(Landroid/graphics/drawable/Drawable;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->x:Lcom/google/android/material/shadow/c;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->e:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x3

    invoke-interface {p1, v0}, Lcom/google/android/material/shadow/c;->c(Landroid/graphics/drawable/Drawable;)V

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    return-void
.end method

.method H()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getRotation()F

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d;->p:F

    cmpl-float v1, v1, v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput v0, p0, Lcom/google/android/material/floatingactionbutton/d;->p:F

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->g0()V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method I()V
    .locals 4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->v:Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v1, Lcom/google/android/material/floatingactionbutton/d$j;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-interface {v1}, Lcom/google/android/material/floatingactionbutton/d$j;->b()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method J()V
    .locals 4

    const/4 v2, 0x3

    move v3, v2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->v:Ljava/util/ArrayList;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    check-cast v1, Lcom/google/android/material/floatingactionbutton/d$j;

    const/4 v2, 0x1

    move v3, v2

    invoke-interface {v1}, Lcom/google/android/material/floatingactionbutton/d$j;->a()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public K(Landroid/animation/Animator$AnimatorListener;)V
    .locals 3
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->u:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method L(Landroid/animation/Animator$AnimatorListener;)V
    .locals 3
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->t:Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method M(Lcom/google/android/material/floatingactionbutton/d$j;)V
    .locals 3
    .param p1    # Lcom/google/android/material/floatingactionbutton/d$j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->v:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method N()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method O(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->setTintList(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->d:Lcom/google/android/material/floatingactionbutton/c;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/c;->d(Landroid/content/res/ColorStateList;)V

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method P(Landroid/graphics/PorterDuff$Mode;)V
    .locals 3
    .param p1    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->setTintMode(Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method final Q(F)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->h:F

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    cmpl-float v0, v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/d;->h:F

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->i:F

    const/4 v3, 0x0

    const/4 v2, 0x3

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d;->j:F

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0, v1}, Lcom/google/android/material/floatingactionbutton/d;->F(FFF)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method R(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/d;->f:Z

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method final S(Lcom/google/android/material/animation/h;)V
    .locals 2
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->o:Lcom/google/android/material/animation/h;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method final T(F)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->i:F

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    cmpl-float v0, v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/d;->i:F

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->h:F

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d;->j:F

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0, v0, p1, v1}, Lcom/google/android/material/floatingactionbutton/d;->F(FFF)V

    :cond_0
    const/4 v3, 0x4

    return-void
.end method

.method final U(F)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/d;->q:F

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->B:Landroid/graphics/Matrix;

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/floatingactionbutton/d;->h(FLandroid/graphics/Matrix;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageMatrix(Landroid/graphics/Matrix;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method final V(I)V
    .locals 3

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->r:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eq v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/d;->r:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->h0()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method W(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/d;->k:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method final X(F)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->j:F

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    cmpl-float v0, v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput p1, p0, Lcom/google/android/material/floatingactionbutton/d;->j:F

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->h:F

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d;->i:F

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/android/material/floatingactionbutton/d;->F(FFF)V

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    return-void
.end method

.method Y(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x1

    move v2, v1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x0

    return-void
.end method

.method Z(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/floatingactionbutton/d;->g:Z

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->i0()V

    const/4 v1, 0x2

    return-void
.end method

.method final a0(Lcom/google/android/material/shape/o;)V
    .locals 4
    .param p1    # Lcom/google/android/material/shape/o;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    move v3, v2

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->a:Lcom/google/android/material/shape/o;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    instance-of v1, v0, Lcom/google/android/material/shape/s;

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast v0, Lcom/google/android/material/shape/s;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lcom/google/android/material/shape/s;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->d:Lcom/google/android/material/floatingactionbutton/c;

    const/4 v3, 0x5

    if-eqz v0, :cond_2

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {v0, p1}, Lcom/google/android/material/floatingactionbutton/c;->g(Lcom/google/android/material/shape/o;)V

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method final b0(Lcom/google/android/material/animation/h;)V
    .locals 2
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->n:Lcom/google/android/material/animation/h;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method c0()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public e(Landroid/animation/Animator$AnimatorListener;)V
    .locals 3
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->u:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->u:Ljava/util/ArrayList;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->u:Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method final e0()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/d;->f:Z

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getSizeDimension()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d;->k:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-lt v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    move v3, v2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x1

    :goto_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    return v0
.end method

.method f(Landroid/animation/Animator$AnimatorListener;)V
    .locals 3
    .param p1    # Landroid/animation/Animator$AnimatorListener;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->t:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->t:Ljava/util/ArrayList;

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->t:Ljava/util/ArrayList;

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    return-void
.end method

.method f0(Lcom/google/android/material/floatingactionbutton/d$k;Z)V
    .locals 8
    .param p1    # Lcom/google/android/material/floatingactionbutton/d$k;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->z()Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz v0, :cond_0

    const/4 v7, 0x1

    return-void

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->m:Landroid/animation/Animator;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz v0, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/animation/Animator;->cancel()V

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->n:Lcom/google/android/material/animation/h;

    const/4 v6, 0x2

    xor-int/2addr v7, v6

    const/4 v1, 0x0

    move v7, v1

    const/4 v6, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez v0, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 v0, 0x1

    const/4 v6, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    goto :goto_0

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x0

    move v0, v1

    move v0, v1

    const/4 v7, 0x0

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v6, 0x2

    move v7, v6

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/d;->d0()Z

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-eqz v2, :cond_9

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v1}, Landroid/view/View;->getVisibility()I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-eqz v1, :cond_6

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v2, 0x0

    shr-int/2addr v7, v2

    move v6, v2

    move v6, v2

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Landroid/view/View;->setAlpha(F)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x7

    const v4, 0x3ecccccd    # 0.4f

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eqz v0, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    move v5, v4

    move v5, v4

    const/4 v7, 0x1

    move v5, v4

    move v5, v4

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    goto :goto_1

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    move v5, v2

    move v5, v2

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v1, v5}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setScaleY(F)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v0, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x2

    move v5, v4

    move v5, v4

    const/4 v7, 0x3

    move v5, v4

    move v5, v4

    const/4 v7, 0x4

    goto :goto_2

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    move v5, v2

    move v5, v2

    const/4 v7, 0x5

    move v5, v2

    move v5, v2

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v1, v5}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setScaleX(F)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-eqz v0, :cond_5

    const/4 v6, 0x3

    move v2, v4

    move v2, v4

    const/4 v7, 0x2

    move v2, v4

    move v2, v4

    :cond_5
    const/4 v7, 0x4

    invoke-virtual {p0, v2}, Lcom/google/android/material/floatingactionbutton/d;->U(F)V

    :cond_6
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->n:Lcom/google/android/material/animation/h;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v0, :cond_7

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {p0, v0, v3, v3, v3}, Lcom/google/android/material/floatingactionbutton/d;->i(Lcom/google/android/material/animation/h;FFF)Landroid/animation/AnimatorSet;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto :goto_3

    :cond_7
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-direct {p0, v3, v3, v3}, Lcom/google/android/material/floatingactionbutton/d;->j(FFF)Landroid/animation/AnimatorSet;

    move-result-object v0

    :goto_3
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v1, Lcom/google/android/material/floatingactionbutton/d$b;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v1, p0, p2, p1}, Lcom/google/android/material/floatingactionbutton/d$b;-><init>(Lcom/google/android/material/floatingactionbutton/d;ZLcom/google/android/material/floatingactionbutton/d$k;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->t:Ljava/util/ArrayList;

    const/4 v6, 0x3

    or-int/2addr v7, v6

    if-eqz p1, :cond_8

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_4
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz p2, :cond_8

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    check-cast p2, Landroid/animation/Animator$AnimatorListener;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0, p2}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_4

    :cond_8
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    goto :goto_5

    :cond_9
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x6

    invoke-virtual {v0, v1, p2}, Lcom/google/android/material/internal/VisibilityAwareImageButton;->a(IZ)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p2, v3}, Landroid/view/View;->setAlpha(F)V

    const/4 v7, 0x4

    const/4 v6, 0x5

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p2, v3}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setScaleY(F)V

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p2, v3}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setScaleX(F)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0, v3}, Lcom/google/android/material/floatingactionbutton/d;->U(F)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-eqz p1, :cond_a

    const/4 v7, 0x0

    invoke-interface {p1}, Lcom/google/android/material/floatingactionbutton/d$k;->a()V

    :cond_a
    :goto_5
    const/4 v7, 0x5

    const/4 v6, 0x2

    return-void
.end method

.method g(Lcom/google/android/material/floatingactionbutton/d$j;)V
    .locals 3
    .param p1    # Lcom/google/android/material/floatingactionbutton/d$j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->v:Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->v:Ljava/util/ArrayList;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->v:Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method g0()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/android/material/floatingactionbutton/d;->p:F

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    float-to-int v1, v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/shape/j;->w0(I)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method final h0()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->q:F

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/google/android/material/floatingactionbutton/d;->U(F)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method final i0()V
    .locals 7

    const/4 v5, 0x3

    move v6, v5

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->y:Landroid/graphics/Rect;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p0, v0}, Lcom/google/android/material/floatingactionbutton/d;->s(Landroid/graphics/Rect;)V

    const/4 v6, 0x6

    invoke-virtual {p0, v0}, Lcom/google/android/material/floatingactionbutton/d;->G(Landroid/graphics/Rect;)V

    const/4 v5, 0x7

    move v6, v5

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->x:Lcom/google/android/material/shadow/c;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget v2, v0, Landroid/graphics/Rect;->left:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v3, v0, Landroid/graphics/Rect;->top:I

    const/4 v6, 0x4

    iget v4, v0, Landroid/graphics/Rect;->right:I

    const/4 v6, 0x4

    const/4 v5, 0x5

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v6, 0x6

    invoke-interface {v1, v2, v3, v4, v0}, Lcom/google/android/material/shadow/c;->a(IIII)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-void
.end method

.method j0(F)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->n0(F)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method l()Lcom/google/android/material/shape/j;
    .locals 4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->a:Lcom/google/android/material/shape/o;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    check-cast v0, Lcom/google/android/material/shape/o;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v1, Lcom/google/android/material/shape/j;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v1, v0}, Lcom/google/android/material/shape/j;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v1
.end method

.method final m()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->e:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method n()F
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->h:F

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method o()Z
    .locals 3

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/d;->f:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method final p()Lcom/google/android/material/animation/h;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->o:Lcom/google/android/material/animation/h;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method q()F
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->i:F

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method s(Landroid/graphics/Rect;)V
    .locals 7
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/floatingactionbutton/d;->f:Z

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->k:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getSizeDimension()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    sub-int/2addr v0, v1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    div-int/lit8 v0, v0, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-boolean v1, p0, Lcom/google/android/material/floatingactionbutton/d;->g:Z

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v1, :cond_1

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->n()F

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget v2, p0, Lcom/google/android/material/floatingactionbutton/d;->j:F

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    add-float/2addr v1, v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v1, 0x0

    :goto_1
    const/4 v6, 0x3

    float-to-double v2, v1

    const/4 v6, 0x5

    invoke-static {v2, v3}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    double-to-int v2, v2

    const/4 v5, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/high16 v3, 0x3fc00000    # 1.5f

    const/4 v6, 0x6

    const/4 v5, 0x0

    mul-float/2addr v1, v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    float-to-double v3, v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-static {v3, v4}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    double-to-int v1, v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p1, v2, v0, v2, v0}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    return-void
.end method

.method t()F
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->j:F

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method final u()Lcom/google/android/material/shape/o;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->a:Lcom/google/android/material/shape/o;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method final v()Lcom/google/android/material/animation/h;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->n:Lcom/google/android/material/animation/h;

    const/4 v1, 0x4

    move v2, v1

    return-object v0
.end method

.method w(Lcom/google/android/material/floatingactionbutton/d$k;Z)V
    .locals 4
    .param p1    # Lcom/google/android/material/floatingactionbutton/d$k;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->y()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->m:Landroid/animation/Animator;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/animation/Animator;->cancel()V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/d;->d0()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->o:Lcom/google/android/material/animation/h;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p0, v0, v1, v1, v1}, Lcom/google/android/material/floatingactionbutton/d;->i(Lcom/google/android/material/animation/h;FFF)Landroid/animation/AnimatorSet;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const v0, 0x3ecccccd    # 0.4f

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0, v1, v0, v0}, Lcom/google/android/material/floatingactionbutton/d;->j(FFF)Landroid/animation/AnimatorSet;

    move-result-object v0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v1, Lcom/google/android/material/floatingactionbutton/d$a;

    const/4 v3, 0x3

    invoke-direct {v1, p0, p2, p1}, Lcom/google/android/material/floatingactionbutton/d$a;-><init>(Lcom/google/android/material/floatingactionbutton/d;ZLcom/google/android/material/floatingactionbutton/d$k;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->u:Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz p1, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz p2, :cond_3

    const/4 v3, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast p2, Landroid/animation/Animator$AnimatorListener;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p2}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    goto :goto_1

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/animation/AnimatorSet;->start()V

    const/4 v3, 0x3

    goto :goto_3

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz p2, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/16 v1, 0x8

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_2

    :cond_5
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x4

    :goto_2
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1, p2}, Lcom/google/android/material/internal/VisibilityAwareImageButton;->a(IZ)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    if-eqz p1, :cond_6

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-interface {p1}, Lcom/google/android/material/floatingactionbutton/d$k;->b()V

    :cond_6
    :goto_3
    const/4 v3, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method x(Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;Landroid/content/res/ColorStateList;I)V
    .locals 2
    .param p2    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/floatingactionbutton/d;->l()Lcom/google/android/material/shape/j;

    move-result-object p4

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p4, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p4, p1}, Lcom/google/android/material/shape/j;->setTintList(Landroid/content/res/ColorStateList;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    if-eqz p2, :cond_0

    const/4 v0, 0x7

    xor-int/2addr v1, v0

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Lcom/google/android/material/shape/j;->setTintMode(Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    const/4 v0, 0x5

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    const p2, -0xbbbbbc

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Lcom/google/android/material/shape/j;->v0(I)V

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v1, 0x0

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p2}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Lcom/google/android/material/shape/j;->Z(Landroid/content/Context;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    new-instance p1, Lcom/google/android/material/ripple/a;

    const/4 v1, 0x3

    iget-object p2, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p2}, Lcom/google/android/material/shape/j;->getShapeAppearanceModel()Lcom/google/android/material/shape/o;

    move-result-object p2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p1, p2}, Lcom/google/android/material/ripple/a;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    invoke-static {p3}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object p2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Lcom/google/android/material/ripple/a;->setTintList(Landroid/content/res/ColorStateList;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->c:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    const/4 p2, 0x2

    const/4 v1, 0x4

    new-array p2, p2, [Landroid/graphics/drawable/Drawable;

    const/4 v0, 0x1

    move v1, v0

    iget-object p3, p0, Lcom/google/android/material/floatingactionbutton/d;->b:Lcom/google/android/material/shape/j;

    const/4 v1, 0x6

    invoke-static {p3}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    check-cast p3, Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    const/4 p4, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    aput-object p3, p2, p4

    const/4 v1, 0x7

    const/4 p3, 0x1

    const/4 v1, 0x1

    move v0, p3

    move v0, p3

    const/4 v1, 0x2

    aput-object p1, p2, p3

    const/4 v1, 0x7

    new-instance p1, Landroid/graphics/drawable/LayerDrawable;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p1, p2}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/floatingactionbutton/d;->e:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method y()Z
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x2

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->s:I

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-ne v0, v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    move v1, v2

    move v1, v2

    const/4 v5, 0x4

    move v1, v2

    move v1, v2

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    return v1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->s:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v3, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eq v0, v3, :cond_2

    move v1, v2

    move v1, v2

    const/4 v5, 0x5

    move v1, v2

    move v1, v2

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    return v1
.end method

.method z()Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/material/floatingactionbutton/d;->w:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v5, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->s:I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v3, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x7

    if-ne v0, v3, :cond_0

    const/4 v4, 0x7

    move v5, v4

    move v1, v2

    move v1, v2

    const/4 v5, 0x3

    move v1, v2

    move v1, v2

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/android/material/floatingactionbutton/d;->s:I

    const/4 v5, 0x7

    const/4 v4, 0x5

    if-eq v0, v2, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    move v1, v2

    move v1, v2

    const/4 v5, 0x5

    move v1, v2

    move v1, v2

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    return v1
.end method
