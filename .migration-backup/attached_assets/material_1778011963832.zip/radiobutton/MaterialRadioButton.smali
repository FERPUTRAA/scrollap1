.class public Lcom/google/android/material/radiobutton/MaterialRadioButton;
.super Landroidx/appcompat/widget/AppCompatRadioButton;


# static fields
.field private static final g:I

.field private static final h:[[I


# instance fields
.field private e:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private f:Z


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_CompoundButton_RadioButton:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    sput v0, Lcom/google/android/material/radiobutton/MaterialRadioButton;->g:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v0, 0x4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-array v0, v0, [[I

    const/4 v6, 0x4

    const v1, 0x101009e

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    const v2, 0x10100a0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    filled-new-array {v1, v2}, [I

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    aput-object v3, v0, v4

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    const v3, -0x10100a0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    filled-new-array {v1, v3}, [I

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 v4, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    aput-object v1, v0, v4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    const v1, -0x101009e

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    filled-new-array {v1, v2}, [I

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v4, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    aput-object v2, v0, v4

    const/4 v5, 0x0

    and-int/2addr v6, v5

    const/4 v2, 0x3

    move v6, v2

    const/4 v5, 0x7

    xor-int/2addr v6, v5

    filled-new-array {v1, v3}, [I

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    aput-object v1, v0, v2

    const/4 v6, 0x0

    sput-object v0, Lcom/google/android/material/radiobutton/MaterialRadioButton;->h:[[I

    const/4 v6, 0x7

    const/4 v5, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/radiobutton/MaterialRadioButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget v0, Lcom/google/android/material/R$attr;->radioButtonStyle:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/radiobutton/MaterialRadioButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    sget v4, Lcom/google/android/material/radiobutton/MaterialRadioButton;->g:I

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {p1, p2, p3, v4}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/widget/AppCompatRadioButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    sget-object v2, Lcom/google/android/material/R$styleable;->MaterialRadioButton:[I

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v6, 0x0

    const/4 v8, 0x2

    new-array v5, v6, [I

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    move v3, p3

    move v3, p3

    const/4 v8, 0x4

    move v3, p3

    move v3, p3

    const/4 v8, 0x4

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x2

    sget p3, Lcom/google/android/material/R$styleable;->MaterialRadioButton_buttonTint:I

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-static {p1, p2, p3}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-static {p0, p1}, Landroidx/core/widget/d;->d(Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    sget p1, Lcom/google/android/material/R$styleable;->MaterialRadioButton_useMaterialThemeColors:I

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p2, p1, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/radiobutton/MaterialRadioButton;->f:Z

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    return-void
.end method

.method private getMaterialThemeColorsTintList()Landroid/content/res/ColorStateList;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "a~s~~ no b @@@ @@ ~@@iv@@ slofoS~~@~K @~i/~f1 ~iy4b@@~octl~ oM~~r~/ o @td  @-~  @~~m@~u~@b@ ~ .@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/google/android/material/radiobutton/MaterialRadioButton;->e:Landroid/content/res/ColorStateList;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-nez v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    sget v0, Lcom/google/android/material/R$attr;->colorControlActivated:I

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {p0, v0}, Lcom/google/android/material/color/s;->d(Landroid/view/View;I)I

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    sget v1, Lcom/google/android/material/R$attr;->colorOnSurface:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {p0, v1}, Lcom/google/android/material/color/s;->d(Landroid/view/View;I)I

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    sget v2, Lcom/google/android/material/R$attr;->colorSurface:I

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {p0, v2}, Lcom/google/android/material/color/s;->d(Landroid/view/View;I)I

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    sget-object v3, Lcom/google/android/material/radiobutton/MaterialRadioButton;->h:[[I

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    array-length v4, v3

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-array v4, v4, [I

    const/4 v8, 0x2

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v2, v0, v5}, Lcom/google/android/material/color/s;->m(IIF)I

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/4 v5, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    aput v0, v4, v5

    const/4 v8, 0x4

    const/4 v7, 0x1

    const v0, 0x3f0a3d71    # 0.54f

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v2, v1, v0}, Lcom/google/android/material/color/s;->m(IIF)I

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v5, 0x1

    const/4 v8, 0x7

    aput v0, v4, v5

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v0, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    const v5, 0x3ec28f5c    # 0.38f

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {v2, v1, v5}, Lcom/google/android/material/color/s;->m(IIF)I

    move-result v6

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    aput v6, v4, v0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v0, 0x3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v2, v1, v5}, Lcom/google/android/material/color/s;->m(IIF)I

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    aput v1, v4, v0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    new-instance v0, Landroid/content/res/ColorStateList;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {v0, v3, v4}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    iput-object v0, p0, Lcom/google/android/material/radiobutton/MaterialRadioButton;->e:Landroid/content/res/ColorStateList;

    :cond_0
    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/android/material/radiobutton/MaterialRadioButton;->e:Landroid/content/res/ColorStateList;

    const/4 v8, 0x5

    return-object v0
.end method


# virtual methods
.method public a()Z
    .locals 3

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/radiobutton/MaterialRadioButton;->f:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method protected onAttachedToWindow()V
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-super {p0}, Landroid/widget/RadioButton;->onAttachedToWindow()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/radiobutton/MaterialRadioButton;->f:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0}, Landroidx/core/widget/d;->b(Landroid/widget/CompoundButton;)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/android/material/radiobutton/MaterialRadioButton;->setUseMaterialThemeColors(Z)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public setUseMaterialThemeColors(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/radiobutton/MaterialRadioButton;->f:Z

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v0, 0x0

    move v1, v0

    invoke-direct {p0}, Lcom/google/android/material/radiobutton/MaterialRadioButton;->getMaterialThemeColorsTintList()Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p0, p1}, Landroidx/core/widget/d;->d(Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p0, p1}, Landroidx/core/widget/d;->d(Landroid/widget/CompoundButton;Landroid/content/res/ColorStateList;)V

    :goto_0
    const/4 v1, 0x7

    return-void
.end method
