.class public final Lcom/google/android/material/R$xml;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "xml"
.end annotation


# static fields
.field public static final standalone_badge:I = 0x7f140009

.field public static final standalone_badge_gravity_bottom_end:I = 0x7f14000a

.field public static final standalone_badge_gravity_bottom_start:I = 0x7f14000b

.field public static final standalone_badge_gravity_top_start:I = 0x7f14000c

.field public static final standalone_badge_offset:I = 0x7f14000d


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method
