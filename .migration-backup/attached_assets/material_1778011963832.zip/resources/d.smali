.class public Lcom/google/android/material/resources/d;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field private static final r:Ljava/lang/String; = "TextAppearance"

.field private static final s:I = 0x1

.field private static final t:I = 0x2

.field private static final u:I = 0x3


# instance fields
.field public final a:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field public final b:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field public final c:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field public final d:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field public final e:I

.field public final f:I

.field public final g:Z

.field public final h:F

.field public final i:F

.field public final j:F

.field public final k:Z

.field public final l:F

.field private m:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private n:F

.field private final o:I
    .annotation build Landroidx/annotation/y;
    .end annotation
.end field

.field private p:Z

.field private q:Landroid/graphics/Typeface;


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .locals 7
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput-boolean v0, p0, Lcom/google/android/material/resources/d;->p:Z

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    sget-object v1, Lcom/google/android/material/R$styleable;->TextAppearance:[I

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p1, p2, v1}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    move-result-object v1

    const/4 v5, 0x7

    move v6, v5

    sget v2, Lcom/google/android/material/R$styleable;->TextAppearance_android_textSize:I

    const/4 v6, 0x4

    const/4 v3, 0x1

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v1, v2, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p0, v2}, Lcom/google/android/material/resources/d;->l(F)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    sget v2, Lcom/google/android/material/R$styleable;->TextAppearance_android_textColor:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {p1, v1, v2}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p0, v2}, Lcom/google/android/material/resources/d;->k(Landroid/content/res/ColorStateList;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    sget v2, Lcom/google/android/material/R$styleable;->TextAppearance_android_textColorHint:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {p1, v1, v2}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    iput-object v2, p0, Lcom/google/android/material/resources/d;->a:Landroid/content/res/ColorStateList;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    sget v2, Lcom/google/android/material/R$styleable;->TextAppearance_android_textColorLink:I

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {p1, v1, v2}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput-object v2, p0, Lcom/google/android/material/resources/d;->b:Landroid/content/res/ColorStateList;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    sget v2, Lcom/google/android/material/R$styleable;->TextAppearance_android_textStyle:I

    const/4 v5, 0x0

    shl-int/2addr v6, v5

    invoke-virtual {v1, v2, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    iput v2, p0, Lcom/google/android/material/resources/d;->e:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    sget v2, Lcom/google/android/material/R$styleable;->TextAppearance_android_typeface:I

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v4, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, v2, v4}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    iput v2, p0, Lcom/google/android/material/resources/d;->f:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    sget v2, Lcom/google/android/material/R$styleable;->TextAppearance_fontFamily:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    sget v4, Lcom/google/android/material/R$styleable;->TextAppearance_android_fontFamily:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v1, v2, v4}, Lcom/google/android/material/resources/c;->f(Landroid/content/res/TypedArray;II)I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v1, v2, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v4

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    iput v4, p0, Lcom/google/android/material/resources/d;->o:I

    const/4 v6, 0x1

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    iput-object v2, p0, Lcom/google/android/material/resources/d;->d:Ljava/lang/String;

    const/4 v6, 0x7

    sget v2, Lcom/google/android/material/R$styleable;->TextAppearance_textAllCaps:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v1, v2, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    const/4 v6, 0x6

    iput-boolean v0, p0, Lcom/google/android/material/resources/d;->g:Z

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    sget v0, Lcom/google/android/material/R$styleable;->TextAppearance_android_shadowColor:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p1, v1, v0}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    iput-object v0, p0, Lcom/google/android/material/resources/d;->c:Landroid/content/res/ColorStateList;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    sget v0, Lcom/google/android/material/R$styleable;->TextAppearance_android_shadowDx:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1, v0, v3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    iput v0, p0, Lcom/google/android/material/resources/d;->h:F

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    sget v0, Lcom/google/android/material/R$styleable;->TextAppearance_android_shadowDy:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1, v0, v3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput v0, p0, Lcom/google/android/material/resources/d;->i:F

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    sget v0, Lcom/google/android/material/R$styleable;->TextAppearance_android_shadowRadius:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v1, v0, v3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput v0, p0, Lcom/google/android/material/resources/d;->j:F

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    sget-object v0, Lcom/google/android/material/R$styleable;->MaterialTextAppearance:[I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    sget p2, Lcom/google/android/material/R$styleable;->MaterialTextAppearance_android_letterSpacing:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1, p2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    iput-boolean v0, p0, Lcom/google/android/material/resources/d;->k:Z

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1, p2, v3}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result p2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput p2, p0, Lcom/google/android/material/resources/d;->l:F

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v5, 0x1

    shr-int/2addr v6, v5

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/resources/d;)Landroid/graphics/Typeface;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "ios~bo/~@obv4t 1 c @Koo @@~ u~~-i~ sr/b l@~~~@t~y~@ ~@@@.~@i  f  a@~  ~@ @@d  Sfl~~~@@~~~Mn@m@o@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic b(Lcom/google/android/material/resources/d;Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-object p1
.end method

.method static synthetic c(Lcom/google/android/material/resources/d;Z)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/resources/d;->p:Z

    return p1
.end method

.method private d()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/resources/d;->d:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/android/material/resources/d;->e:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/material/resources/d;->f:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eq v0, v1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x3

    if-eq v0, v1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v2, 0x6

    if-eq v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object v0, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v2, 0x7

    move v3, v2

    iput-object v0, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v0, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    const/4 v3, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_2
    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v0, Landroid/graphics/Typeface;->SERIF:Landroid/graphics/Typeface;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object v0, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    const/4 v3, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/material/resources/d;->e:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0, v1}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method private m(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/android/material/resources/e;->b()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v1, 0x1

    move v3, v1

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    return v1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/android/material/resources/d;->o:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1, v0}, Landroidx/core/content/res/i;->d(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x5

    if-eqz p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_1

    :cond_2
    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x0

    move v3, v1

    :goto_1
    const/4 v2, 0x5

    const/4 v3, 0x0

    return v1
.end method


# virtual methods
.method public e()Landroid/graphics/Typeface;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/resources/d;->d()V

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public f(Landroid/content/Context;)Landroid/graphics/Typeface;
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/resources/d;->p:Z

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v3, 0x0

    const/4 v2, 0x6

    return-object p1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->isRestricted()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v0, :cond_1

    :try_start_0
    const/4 v2, 0x1

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/resources/d;->o:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p1, v0}, Landroidx/core/content/res/i;->j(Landroid/content/Context;I)Landroid/graphics/Typeface;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/android/material/resources/d;->e:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p1, v0}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;
    :try_end_0
    .catch Ljava/lang/UnsupportedOperationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v1, "snimf tdgar or rolo"

    const-string/jumbo v1, "itsrglEro  frn odoa"

    const/4 v3, 0x7

    const-string v1, "doa otrfirglrEnn oo"

    const-string v1, "Error loading font "

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/resources/d;->d:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string/jumbo v1, "peexpbTrAaetna"

    const-string v1, "TextAppearance"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v1, v0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :catch_1
    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/resources/d;->d()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 p1, 0x1

    const/4 v3, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/resources/d;->p:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p1
.end method

.method public g(Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/text/TextPaint;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/resources/f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/resources/d;->e()Landroid/graphics/Typeface;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/android/material/resources/d;->p(Landroid/content/Context;Landroid/text/TextPaint;Landroid/graphics/Typeface;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Lcom/google/android/material/resources/d$b;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/google/android/material/resources/d$b;-><init>(Lcom/google/android/material/resources/d;Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/resources/d;->h(Landroid/content/Context;Lcom/google/android/material/resources/f;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public h(Landroid/content/Context;Lcom/google/android/material/resources/f;)V
    .locals 6
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/resources/f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/resources/d;->m(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/resources/d;->f(Landroid/content/Context;)Landroid/graphics/Typeface;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/google/android/material/resources/d;->d()V

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/android/material/resources/d;->o:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-boolean v1, p0, Lcom/google/android/material/resources/d;->p:Z

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-boolean v2, p0, Lcom/google/android/material/resources/d;->p:Z

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v2, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/google/android/material/resources/d;->q:Landroid/graphics/Typeface;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p2, p1, v1}, Lcom/google/android/material/resources/f;->b(Landroid/graphics/Typeface;Z)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void

    :cond_2
    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v2, Lcom/google/android/material/resources/d$a;

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    invoke-direct {v2, p0, p2}, Lcom/google/android/material/resources/d$a;-><init>(Lcom/google/android/material/resources/d;Lcom/google/android/material/resources/f;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p1, v0, v2, v3}, Landroidx/core/content/res/i;->l(Landroid/content/Context;ILandroidx/core/content/res/i$g;Landroid/os/Handler;)V
    :try_end_0
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x3

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const-string v2, " tg nounoafrEorlrid"

    const-string v2, "Error loading font "

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/android/material/resources/d;->d:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v2, "cerAxneptpapTa"

    const-string v2, "TextAppearance"

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v2, v0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-boolean v1, p0, Lcom/google/android/material/resources/d;->p:Z

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 p1, -0x3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Lcom/google/android/material/resources/f;->a(I)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_1

    :catch_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-boolean v1, p0, Lcom/google/android/material/resources/d;->p:Z

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p2, v1}, Lcom/google/android/material/resources/f;->a(I)V

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method

.method public i()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/resources/d;->m:Landroid/content/res/ColorStateList;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public j()F
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/resources/d;->n:F

    const/4 v2, 0x4

    return v0
.end method

.method public k(Landroid/content/res/ColorStateList;)V
    .locals 2
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/resources/d;->m:Landroid/content/res/ColorStateList;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public l(F)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/android/material/resources/d;->n:F

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public n(Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V
    .locals 6
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/text/TextPaint;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/resources/f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/resources/d;->o(Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/google/android/material/resources/d;->m:Landroid/content/res/ColorStateList;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz p1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object p3, p2, Landroid/text/TextPaint;->drawableState:[I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p1, p3, v0}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/high16 p1, -0x1000000

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p2, p1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget p1, p0, Lcom/google/android/material/resources/d;->j:F

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget p3, p0, Lcom/google/android/material/resources/d;->h:F

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/android/material/resources/d;->i:F

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/material/resources/d;->c:Landroid/content/res/ColorStateList;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    iget-object v2, p2, Landroid/text/TextPaint;->drawableState:[I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v1, 0x0

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {p2, p1, p3, v0, v1}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void
.end method

.method public o(Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/text/TextPaint;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/resources/f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/resources/d;->m(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/resources/d;->f(Landroid/content/Context;)Landroid/graphics/Typeface;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/resources/d;->p(Landroid/content/Context;Landroid/text/TextPaint;Landroid/graphics/Typeface;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/resources/d;->g(Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V

    :goto_0
    const/4 v2, 0x6

    return-void
.end method

.method public p(Landroid/content/Context;Landroid/text/TextPaint;Landroid/graphics/Typeface;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/text/TextPaint;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/graphics/Typeface;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p1, p3}, Lcom/google/android/material/resources/i;->a(Landroid/content/Context;Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    if-eqz p1, :cond_0

    move-object p3, p1

    move-object p3, p1

    move-object p3, p1

    move-object p3, p1

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget p1, p0, Lcom/google/android/material/resources/d;->e:I

    const/4 v0, 0x0

    shr-int/2addr v1, v0

    invoke-virtual {p3}, Landroid/graphics/Typeface;->getStyle()I

    move-result p3

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    not-int p3, p3

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    and-int/2addr p1, p3

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    and-int/lit8 p3, p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    if-eqz p3, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p3, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    goto :goto_0

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    const/4 p3, 0x0

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    and-int/lit8 p1, p1, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    if-eqz p1, :cond_2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/high16 p1, -0x41800000    # -0.25f

    const/4 v0, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    goto :goto_1

    :cond_2
    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    const/4 p1, 0x0

    :goto_1
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p2, p1}, Landroid/graphics/Paint;->setTextSkewX(F)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    iget p1, p0, Lcom/google/android/material/resources/d;->n:F

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p2, p1}, Landroid/graphics/Paint;->setTextSize(F)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-boolean p1, p0, Lcom/google/android/material/resources/d;->k:Z

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    if-eqz p1, :cond_3

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget p1, p0, Lcom/google/android/material/resources/d;->l:F

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p2, p1}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    :cond_3
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method
