.class Lcom/google/android/material/resources/d$a;
.super Landroidx/core/content/res/i$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/resources/d;->h(Landroid/content/Context;Lcom/google/android/material/resources/f;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/resources/f;

.field final synthetic b:Lcom/google/android/material/resources/d;


# direct methods
.method constructor <init>(Lcom/google/android/material/resources/d;Lcom/google/android/material/resources/f;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/google/android/material/resources/d$a;->b:Lcom/google/android/material/resources/d;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/material/resources/d$a;->a:Lcom/google/android/material/resources/f;

    const/4 v0, 0x3

    or-int/2addr v1, v0

    invoke-direct {p0}, Landroidx/core/content/res/i$g;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public h(I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/resources/d$a;->b:Lcom/google/android/material/resources/d;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/google/android/material/resources/d;->c(Lcom/google/android/material/resources/d;Z)Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/resources/d$a;->a:Lcom/google/android/material/resources/f;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/resources/f;->a(I)V

    const/4 v3, 0x5

    return-void
.end method

.method public i(Landroid/graphics/Typeface;)V
    .locals 4
    .param p1    # Landroid/graphics/Typeface;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/resources/d$a;->b:Lcom/google/android/material/resources/d;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v1, v0, Lcom/google/android/material/resources/d;->e:I

    const/4 v3, 0x1

    invoke-static {p1, v1}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v0, p1}, Lcom/google/android/material/resources/d;->b(Lcom/google/android/material/resources/d;Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/material/resources/d$a;->b:Lcom/google/android/material/resources/d;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x1

    move v3, v0

    const/4 v2, 0x5

    move v3, v2

    invoke-static {p1, v0}, Lcom/google/android/material/resources/d;->c(Lcom/google/android/material/resources/d;Z)Z

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/android/material/resources/d$a;->a:Lcom/google/android/material/resources/f;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/resources/d$a;->b:Lcom/google/android/material/resources/d;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/android/material/resources/d;->a(Lcom/google/android/material/resources/d;)Landroid/graphics/Typeface;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Lcom/google/android/material/resources/f;->b(Landroid/graphics/Typeface;Z)V

    const/4 v2, 0x3

    or-int/2addr v3, v2

    return-void
.end method
