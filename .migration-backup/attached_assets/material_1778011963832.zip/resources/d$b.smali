.class Lcom/google/android/material/resources/d$b;
.super Lcom/google/android/material/resources/f;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/resources/d;->g(Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Landroid/text/TextPaint;

.field final synthetic c:Lcom/google/android/material/resources/f;

.field final synthetic d:Lcom/google/android/material/resources/d;


# direct methods
.method constructor <init>(Lcom/google/android/material/resources/d;Landroid/content/Context;Landroid/text/TextPaint;Lcom/google/android/material/resources/f;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/resources/d$b;->d:Lcom/google/android/material/resources/d;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/android/material/resources/d$b;->a:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/google/android/material/resources/d$b;->b:Landroid/text/TextPaint;

    const/4 v0, 0x4

    move v1, v0

    iput-object p4, p0, Lcom/google/android/material/resources/d$b;->c:Lcom/google/android/material/resources/f;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/material/resources/f;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/resources/d$b;->c:Lcom/google/android/material/resources/f;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/resources/f;->a(I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public b(Landroid/graphics/Typeface;Z)V
    .locals 5
    .param p1    # Landroid/graphics/Typeface;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/resources/d$b;->d:Lcom/google/android/material/resources/d;

    const/4 v3, 0x6

    move v4, v3

    iget-object v1, p0, Lcom/google/android/material/resources/d$b;->a:Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/android/material/resources/d$b;->b:Landroid/text/TextPaint;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2, p1}, Lcom/google/android/material/resources/d;->p(Landroid/content/Context;Landroid/text/TextPaint;Landroid/graphics/Typeface;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/resources/d$b;->c:Lcom/google/android/material/resources/f;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, p1, p2}, Lcom/google/android/material/resources/f;->b(Landroid/graphics/Typeface;Z)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method
