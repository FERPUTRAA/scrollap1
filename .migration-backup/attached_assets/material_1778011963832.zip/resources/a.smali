.class public final Lcom/google/android/material/resources/a;
.super Lcom/google/android/material/resources/f;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/resources/a$a;
    }
.end annotation


# instance fields
.field private final a:Landroid/graphics/Typeface;

.field private final b:Lcom/google/android/material/resources/a$a;

.field private c:Z


# direct methods
.method public constructor <init>(Lcom/google/android/material/resources/a$a;Landroid/graphics/Typeface;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-direct {p0}, Lcom/google/android/material/resources/f;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/google/android/material/resources/a;->a:Landroid/graphics/Typeface;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/resources/a;->b:Lcom/google/android/material/resources/a$a;

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method private d(Landroid/graphics/Typeface;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ts~r@-~~ol@K u@~Si@i@fmf~ @@a @@M~ ~~~@bl~o@o  ~s o/4~~~@ @y@ @ nb  @~oto ~@/@~~ ~c@i@d1.b   ~v"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-boolean v0, p0, Lcom/google/android/material/resources/a;->c:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/resources/a;->b:Lcom/google/android/material/resources/a$a;

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-interface {v0, p1}, Lcom/google/android/material/resources/a$a;->a(Landroid/graphics/Typeface;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public a(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/google/android/material/resources/a;->a:Landroid/graphics/Typeface;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/material/resources/a;->d(Landroid/graphics/Typeface;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public b(Landroid/graphics/Typeface;Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/resources/a;->d(Landroid/graphics/Typeface;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public c()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/google/android/material/resources/a;->c:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method
