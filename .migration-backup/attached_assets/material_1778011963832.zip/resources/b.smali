.class public Lcom/google/android/material/resources/b;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Landroid/content/Context;I)Landroid/util/TypedValue;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@sM@@c~/ @@@~~@t4~@o@lK~o~ i~.f~ ~bb@- ~ib@uo@~ t ~~m  rv~ y~no@ 1  ~~ @id~o~/~@@S @@@~@o  af s"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    new-instance v0, Landroid/util/TypedValue;

    const/4 v2, 0x6

    move v3, v2

    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, p1, v0, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0
.end method

.method public static b(Landroid/content/Context;IZ)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0, p1}, Lcom/google/android/material/resources/b;->a(Landroid/content/Context;I)Landroid/util/TypedValue;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p0, :cond_1

    const/4 v1, 0x6

    move v2, v1

    iget p1, p0, Landroid/util/TypedValue;->type:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/16 v0, 0x12

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-ne p1, v0, :cond_1

    const/4 v1, 0x6

    and-int/2addr v2, v1

    iget p0, p0, Landroid/util/TypedValue;->data:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 p2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p2, 0x0

    :cond_1
    :goto_0
    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return p2
.end method

.method public static c(Landroid/content/Context;ILjava/lang/String;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lcom/google/android/material/resources/b;->g(Landroid/content/Context;ILjava/lang/String;)I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    if-eqz p0, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 p0, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    return p0
.end method

.method public static d(Landroid/content/Context;II)I
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p0, p1}, Lcom/google/android/material/resources/b;->a(Landroid/content/Context;I)Landroid/util/TypedValue;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v0, p1, Landroid/util/TypedValue;->type:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x5

    const/4 v3, 0x6

    if-eq v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_1

    :cond_0
    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, p0}, Landroid/util/TypedValue;->getDimension(Landroid/util/DisplayMetrics;)F

    move-result p0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    float-to-int p0, p0

    const/4 v3, 0x5

    return p0

    :cond_1
    :goto_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0, p2}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0
.end method

.method public static e(Landroid/content/Context;II)I
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p0, p1}, Lcom/google/android/material/resources/b;->a(Landroid/content/Context;I)Landroid/util/TypedValue;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget p1, p0, Landroid/util/TypedValue;->type:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/16 v0, 0x10

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-ne p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget p2, p0, Landroid/util/TypedValue;->data:I

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return p2
.end method

.method public static f(Landroid/content/Context;)I
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget v0, Lcom/google/android/material/R$attr;->minTouchTargetSize:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget v1, Lcom/google/android/material/R$dimen;->mtrl_min_touch_target_size:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p0, v0, v1}, Lcom/google/android/material/resources/b;->d(Landroid/content/Context;II)I

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    return p0
.end method

.method public static g(Landroid/content/Context;ILjava/lang/String;)I
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p0, p1}, Lcom/google/android/material/resources/b;->a(Landroid/content/Context;I)Landroid/util/TypedValue;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget p0, v0, Landroid/util/TypedValue;->data:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    return p0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    aput-object p2, v1, v2

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v4, 0x2

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 p1, 0x1

    move v4, p1

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    aput-object p0, v1, p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo p0, "uatmuh o saetso t uiest  te in  atmd ef.fatvy toe ) oteMrosua ttherahheTu sneeenbaho o de iatm%nepo.nicolr hepeeyr re$as nmbYilmrorr eut a  star( senr$ue %y te2u bnrhmrtri ce1otp oiueetm p dete tiCiqtr"

    const-string p0, "  sefp ttiuevutho mloo oreeecYn o eherl$ be he.me ntenen esttt oiuymt) oia rma1  ntobhersdsa r%dh he tsf  auyaptbu.sr i rtTcmta tuosatreeait(% oi tyu  ierroitmtnneCtuore $ rqn2  deaeseerhpM ipaeat hrue"

    const/4 v4, 0x6

    const-string/jumbo p0, "taafoeta.eeoYv drmmayee uqtef(eoa r)eMro    1otdht he  as$ %t t eeunbourp Crcumhosi   urhribtst rptim  onr .nr eeetlearaoiuitue  st pn. o 2ttyiyber oenTs hse nt  nputmouih restihcm lterieoe$%eaethtaadn"

    const-string p0, "%1$s requires a value for the %2$s attribute to be set in your app theme. You can either set the attribute in your theme or update your theme to inherit from Theme.MaterialComponents (or a descendant)."

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    throw v0
.end method

.method public static h(Landroid/view/View;I)I
    .locals 3
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0, p1, p0}, Lcom/google/android/material/resources/b;->g(Landroid/content/Context;ILjava/lang/String;)I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return p0
.end method
