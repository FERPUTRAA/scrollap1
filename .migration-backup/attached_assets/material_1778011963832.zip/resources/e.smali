.class public Lcom/google/android/material/resources/e;
.super Ljava/lang/Object;


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field private static a:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Z)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "d so@Mb@@   1b~i ~i~yto~~ir~ oc@  ~@s ~@@@@4@u @~a @t~/  @nl@@S@/~~~lof o~ o~v-~f@~ K@~.b~~~~@@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    sput-boolean p0, Lcom/google/android/material/resources/e;->a:Z

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public static b()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-boolean v0, Lcom/google/android/material/resources/e;->a:Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method
