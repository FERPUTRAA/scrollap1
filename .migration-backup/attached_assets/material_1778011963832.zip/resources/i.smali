.class public Lcom/google/android/material/resources/i;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Landroid/content/Context;Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/graphics/Typeface;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s ub~S @ @@o ~~@r@@~~@@@liv ~~ 4bo b c  a@o~i@fol~io~  ~/~~t@m@@  n. ~~~/y f@@K@1t~o@@~~dM~s-@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/google/android/material/resources/i;->b(Landroid/content/res/Configuration;Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method public static b(Landroid/content/res/Configuration;Landroid/graphics/Typeface;)Landroid/graphics/Typeface;
    .locals 4
    .param p0    # Landroid/content/res/Configuration;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/graphics/Typeface;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/16 v1, 0x1f

    const/4 v2, 0x0

    move v3, v2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/google/android/material/resources/g;->a(Landroid/content/res/Configuration;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const v1, 0x7fffffff

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eq v0, v1, :cond_0

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/google/android/material/resources/g;->a(Landroid/content/res/Configuration;)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/google/android/material/resources/h;->a(Landroid/graphics/Typeface;)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p0}, Lcom/google/android/material/resources/g;->a(Landroid/content/res/Configuration;)I

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    add-int/2addr v0, p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/16 v1, 0x3e8

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0, p0, v1}, Lo/a;->e(III)I

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/graphics/Typeface;->isItalic()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1, p0, v0}, Landroidx/appcompat/widget/r0;->a(Landroid/graphics/Typeface;IZ)Landroid/graphics/Typeface;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p0
.end method
