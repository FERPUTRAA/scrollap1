.class public final synthetic Lcom/google/android/material/resources/h;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/graphics/Typeface;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b@su@@m@@  ~ ~@/r@@/@fny~~@~~t~o@~cs@@odb~Si~~~b~~@ao ~o Mft  1 @~l  o-.@vKl~@~  ~~ ~ iio@@@ 4~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/graphics/Typeface;->getWeight()I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return p0
.end method
