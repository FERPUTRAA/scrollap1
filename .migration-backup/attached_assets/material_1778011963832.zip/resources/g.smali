.class public final synthetic Lcom/google/android/material/resources/g;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/res/Configuration;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "y.s o~@m ~ -o @@ i~/b~@sia~@@@ d@   @ @~~~K@~~ t  @oillf@bo~u@ot4~ c@@~r@M~b~~@f~/ n1@S~o ~~~~@v"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget p0, p0, Landroid/content/res/Configuration;->fontWeightAdjustment:I

    const/4 v1, 0x5

    return p0
.end method
