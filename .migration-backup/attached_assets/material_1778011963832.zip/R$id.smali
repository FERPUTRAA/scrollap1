.class public final Lcom/google/android/material/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final BOTTOM_END:I = 0x7f090001

.field public static final BOTTOM_START:I = 0x7f090002

.field public static final NO_DEBUG:I = 0x7f090011

.field public static final SHOW_ALL:I = 0x7f090015

.field public static final SHOW_PATH:I = 0x7f090016

.field public static final SHOW_PROGRESS:I = 0x7f090017

.field public static final TOP_END:I = 0x7f09001a

.field public static final TOP_START:I = 0x7f09001b

.field public static final accelerate:I = 0x7f09001f

.field public static final accessibility_action_clickable_span:I = 0x7f090020

.field public static final accessibility_custom_action_0:I = 0x7f090021

.field public static final accessibility_custom_action_1:I = 0x7f090022

.field public static final accessibility_custom_action_10:I = 0x7f090023

.field public static final accessibility_custom_action_11:I = 0x7f090024

.field public static final accessibility_custom_action_12:I = 0x7f090025

.field public static final accessibility_custom_action_13:I = 0x7f090026

.field public static final accessibility_custom_action_14:I = 0x7f090027

.field public static final accessibility_custom_action_15:I = 0x7f090028

.field public static final accessibility_custom_action_16:I = 0x7f090029

.field public static final accessibility_custom_action_17:I = 0x7f09002a

.field public static final accessibility_custom_action_18:I = 0x7f09002b

.field public static final accessibility_custom_action_19:I = 0x7f09002c

.field public static final accessibility_custom_action_2:I = 0x7f09002d

.field public static final accessibility_custom_action_20:I = 0x7f09002e

.field public static final accessibility_custom_action_21:I = 0x7f09002f

.field public static final accessibility_custom_action_22:I = 0x7f090030

.field public static final accessibility_custom_action_23:I = 0x7f090031

.field public static final accessibility_custom_action_24:I = 0x7f090032

.field public static final accessibility_custom_action_25:I = 0x7f090033

.field public static final accessibility_custom_action_26:I = 0x7f090034

.field public static final accessibility_custom_action_27:I = 0x7f090035

.field public static final accessibility_custom_action_28:I = 0x7f090036

.field public static final accessibility_custom_action_29:I = 0x7f090037

.field public static final accessibility_custom_action_3:I = 0x7f090038

.field public static final accessibility_custom_action_30:I = 0x7f090039

.field public static final accessibility_custom_action_31:I = 0x7f09003a

.field public static final accessibility_custom_action_4:I = 0x7f09003b

.field public static final accessibility_custom_action_5:I = 0x7f09003c

.field public static final accessibility_custom_action_6:I = 0x7f09003d

.field public static final accessibility_custom_action_7:I = 0x7f09003e

.field public static final accessibility_custom_action_8:I = 0x7f09003f

.field public static final accessibility_custom_action_9:I = 0x7f090040

.field public static final action_bar:I = 0x7f09004b

.field public static final action_bar_activity_content:I = 0x7f09004c

.field public static final action_bar_container:I = 0x7f09004d

.field public static final action_bar_root:I = 0x7f09004e

.field public static final action_bar_spinner:I = 0x7f09004f

.field public static final action_bar_subtitle:I = 0x7f090050

.field public static final action_bar_title:I = 0x7f090051

.field public static final action_container:I = 0x7f090052

.field public static final action_context_bar:I = 0x7f090053

.field public static final action_divider:I = 0x7f090054

.field public static final action_image:I = 0x7f090055

.field public static final action_menu_divider:I = 0x7f090056

.field public static final action_menu_presenter:I = 0x7f090057

.field public static final action_mode_bar:I = 0x7f090058

.field public static final action_mode_bar_stub:I = 0x7f090059

.field public static final action_mode_close_button:I = 0x7f09005a

.field public static final action_text:I = 0x7f09005b

.field public static final actions:I = 0x7f09005d

.field public static final activity_chooser_view_content:I = 0x7f09005f

.field public static final add:I = 0x7f090061

.field public static final alertTitle:I = 0x7f090071

.field public static final aligned:I = 0x7f090072

.field public static final animateToEnd:I = 0x7f090079

.field public static final animateToStart:I = 0x7f09007a

.field public static final arc:I = 0x7f090080

.field public static final asConfigured:I = 0x7f090081

.field public static final async:I = 0x7f090082

.field public static final auto:I = 0x7f090083

.field public static final autoComplete:I = 0x7f090084

.field public static final autoCompleteToEnd:I = 0x7f090085

.field public static final autoCompleteToStart:I = 0x7f090086

.field public static final barrier:I = 0x7f0900a2

.field public static final baseline:I = 0x7f0900ab

.field public static final blocking:I = 0x7f0900b8

.field public static final bottom:I = 0x7f0900bb

.field public static final bounce:I = 0x7f0900cd

.field public static final buttonPanel:I = 0x7f090133

.field public static final cancel_button:I = 0x7f09013b

.field public static final center:I = 0x7f090143

.field public static final centerCrop:I = 0x7f090144

.field public static final centerInside:I = 0x7f090145

.field public static final chain:I = 0x7f09014b

.field public static final checkbox:I = 0x7f090155

.field public static final checked:I = 0x7f090156

.field public static final chip:I = 0x7f090157

.field public static final chip1:I = 0x7f090158

.field public static final chip2:I = 0x7f090159

.field public static final chip3:I = 0x7f09015a

.field public static final chip_group:I = 0x7f090160

.field public static final chronometer:I = 0x7f090161

.field public static final circle_center:I = 0x7f090165

.field public static final clear_text:I = 0x7f090186

.field public static final clockwise:I = 0x7f090189

.field public static final compress:I = 0x7f090199

.field public static final confirm_button:I = 0x7f0901a2

.field public static final container:I = 0x7f0901b3

.field public static final content:I = 0x7f0901b5

.field public static final contentPanel:I = 0x7f0901b7

.field public static final contiguous:I = 0x7f0901bb

.field public static final coordinator:I = 0x7f0901be

.field public static final cos:I = 0x7f0901c4

.field public static final counterclockwise:I = 0x7f0901c8

.field public static final custom:I = 0x7f0901de

.field public static final customPanel:I = 0x7f0901df

.field public static final cut:I = 0x7f0901ec

.field public static final date_picker_actions:I = 0x7f0901f3

.field public static final decelerate:I = 0x7f0901f7

.field public static final decelerateAndComplete:I = 0x7f0901f8

.field public static final decor_content_parent:I = 0x7f0901f9

.field public static final default_activity_button:I = 0x7f0901fb

.field public static final deltaRelative:I = 0x7f0901ff

.field public static final design_bottom_sheet:I = 0x7f090201

.field public static final design_menu_item_action_area:I = 0x7f090202

.field public static final design_menu_item_action_area_stub:I = 0x7f090203

.field public static final design_menu_item_text:I = 0x7f090204

.field public static final design_navigation_view:I = 0x7f090205

.field public static final dialog_button:I = 0x7f09020c

.field public static final disjoint:I = 0x7f090226

.field public static final dragDown:I = 0x7f09022a

.field public static final dragEnd:I = 0x7f09022b

.field public static final dragLeft:I = 0x7f09022c

.field public static final dragRight:I = 0x7f09022d

.field public static final dragStart:I = 0x7f09022e

.field public static final dragUp:I = 0x7f09022f

.field public static final dropdown_editable:I = 0x7f090231

.field public static final dropdown_menu:I = 0x7f090232

.field public static final dropdown_noneditable:I = 0x7f090233

.field public static final easeIn:I = 0x7f090235

.field public static final easeInOut:I = 0x7f090236

.field public static final easeOut:I = 0x7f090237

.field public static final edit_query:I = 0x7f090247

.field public static final edittext_dropdown_editable:I = 0x7f09024b

.field public static final edittext_dropdown_noneditable:I = 0x7f09024c

.field public static final elastic:I = 0x7f090257

.field public static final end:I = 0x7f09025f

.field public static final endToStart:I = 0x7f090260

.field public static final expand_activities_button:I = 0x7f090280

.field public static final expanded_menu:I = 0x7f090281

.field public static final fade:I = 0x7f090283

.field public static final fill:I = 0x7f090286

.field public static final filled:I = 0x7f090289

.field public static final fitCenter:I = 0x7f09028c

.field public static final fitEnd:I = 0x7f09028d

.field public static final fitStart:I = 0x7f09028e

.field public static final fitXY:I = 0x7f090290

.field public static final fixed:I = 0x7f090291

.field public static final flip:I = 0x7f0902a4

.field public static final floating:I = 0x7f0902a5

.field public static final forever:I = 0x7f0902a7

.field public static final fragment_container_view_tag:I = 0x7f0902aa

.field public static final fullscreen_header:I = 0x7f0902b1

.field public static final ghost_view:I = 0x7f0902c6

.field public static final ghost_view_holder:I = 0x7f0902c7

.field public static final gone:I = 0x7f0902db

.field public static final group_divider:I = 0x7f0902eb

.field public static final guideline:I = 0x7f0902f0

.field public static final header_title:I = 0x7f090300

.field public static final home:I = 0x7f090307

.field public static final honorRequest:I = 0x7f09030a

.field public static final icon:I = 0x7f090318

.field public static final icon_group:I = 0x7f09031a

.field public static final ignore:I = 0x7f09031d

.field public static final ignoreRequest:I = 0x7f09031e

.field public static final image:I = 0x7f09031f

.field public static final info:I = 0x7f090385

.field public static final invisible:I = 0x7f09038a

.field public static final inward:I = 0x7f09038c

.field public static final italic:I = 0x7f090391

.field public static final item_touch_helper_previous_elevation:I = 0x7f09039e

.field public static final jumpToEnd:I = 0x7f09046d

.field public static final jumpToStart:I = 0x7f09046e

.field public static final labeled:I = 0x7f090499

.field public static final layout:I = 0x7f0904a6

.field public static final left:I = 0x7f0904db

.field public static final leftToRight:I = 0x7f0904dc

.field public static final line1:I = 0x7f0904ef

.field public static final line3:I = 0x7f0904f1

.field public static final linear:I = 0x7f0904f5

.field public static final listMode:I = 0x7f0904fb

.field public static final list_item:I = 0x7f0904fd

.field public static final masked:I = 0x7f090594

.field public static final material_clock_display:I = 0x7f090597

.field public static final material_clock_face:I = 0x7f090598

.field public static final material_clock_hand:I = 0x7f090599

.field public static final material_clock_period_am_button:I = 0x7f09059a

.field public static final material_clock_period_pm_button:I = 0x7f09059b

.field public static final material_clock_period_toggle:I = 0x7f09059c

.field public static final material_hour_text_input:I = 0x7f09059d

.field public static final material_hour_tv:I = 0x7f09059e

.field public static final material_label:I = 0x7f09059f

.field public static final material_minute_text_input:I = 0x7f0905a0

.field public static final material_minute_tv:I = 0x7f0905a1

.field public static final material_textinput_timepicker:I = 0x7f0905a2

.field public static final material_timepicker_cancel_button:I = 0x7f0905a3

.field public static final material_timepicker_container:I = 0x7f0905a4

.field public static final material_timepicker_edit_text:I = 0x7f0905a5

.field public static final material_timepicker_mode_button:I = 0x7f0905a6

.field public static final material_timepicker_ok_button:I = 0x7f0905a7

.field public static final material_timepicker_view:I = 0x7f0905a8

.field public static final material_value_index:I = 0x7f0905a9

.field public static final matrix:I = 0x7f0905aa

.field public static final message:I = 0x7f0905b3

.field public static final middle:I = 0x7f0905ba

.field public static final mini:I = 0x7f0905bc

.field public static final month_grid:I = 0x7f0905c4

.field public static final month_navigation_bar:I = 0x7f0905c5

.field public static final month_navigation_fragment_toggle:I = 0x7f0905c6

.field public static final month_navigation_next:I = 0x7f0905c7

.field public static final month_navigation_previous:I = 0x7f0905c8

.field public static final month_title:I = 0x7f0905c9

.field public static final motion_base:I = 0x7f0905cb

.field public static final mtrl_anchor_parent:I = 0x7f0905cc

.field public static final mtrl_calendar_day_selector_frame:I = 0x7f0905cd

.field public static final mtrl_calendar_days_of_week:I = 0x7f0905ce

.field public static final mtrl_calendar_frame:I = 0x7f0905cf

.field public static final mtrl_calendar_main_pane:I = 0x7f0905d0

.field public static final mtrl_calendar_months:I = 0x7f0905d1

.field public static final mtrl_calendar_selection_frame:I = 0x7f0905d2

.field public static final mtrl_calendar_text_input_frame:I = 0x7f0905d3

.field public static final mtrl_calendar_year_selector_frame:I = 0x7f0905d4

.field public static final mtrl_card_checked_layer_id:I = 0x7f0905d5

.field public static final mtrl_child_content_container:I = 0x7f0905d6

.field public static final mtrl_internal_children_alpha_tag:I = 0x7f0905d7

.field public static final mtrl_motion_snapshot_view:I = 0x7f0905d8

.field public static final mtrl_picker_fullscreen:I = 0x7f0905d9

.field public static final mtrl_picker_header:I = 0x7f0905da

.field public static final mtrl_picker_header_selection_text:I = 0x7f0905db

.field public static final mtrl_picker_header_title_and_selection:I = 0x7f0905dc

.field public static final mtrl_picker_header_toggle:I = 0x7f0905dd

.field public static final mtrl_picker_text_input_date:I = 0x7f0905de

.field public static final mtrl_picker_text_input_range_end:I = 0x7f0905df

.field public static final mtrl_picker_text_input_range_start:I = 0x7f0905e0

.field public static final mtrl_picker_title_text:I = 0x7f0905e1

.field public static final mtrl_view_tag_bottom_padding:I = 0x7f0905e2

.field public static final multiply:I = 0x7f0905e3

.field public static final navigation_bar_item_active_indicator_view:I = 0x7f0905e8

.field public static final navigation_bar_item_icon_container:I = 0x7f0905e9

.field public static final navigation_bar_item_icon_view:I = 0x7f0905ea

.field public static final navigation_bar_item_labels_group:I = 0x7f0905eb

.field public static final navigation_bar_item_large_label_view:I = 0x7f0905ec

.field public static final navigation_bar_item_small_label_view:I = 0x7f0905ed

.field public static final navigation_header_container:I = 0x7f0905ee

.field public static final none:I = 0x7f0905fe

.field public static final normal:I = 0x7f0905ff

.field public static final notification_background:I = 0x7f090602

.field public static final notification_main_column:I = 0x7f090603

.field public static final notification_main_column_container:I = 0x7f090604

.field public static final off:I = 0x7f090626

.field public static final on:I = 0x7f09062a

.field public static final outline:I = 0x7f090639

.field public static final outward:I = 0x7f09063b

.field public static final packed:I = 0x7f09063e

.field public static final parallax:I = 0x7f090644

.field public static final parent:I = 0x7f090645

.field public static final parentPanel:I = 0x7f090646

.field public static final parentRelative:I = 0x7f090647

.field public static final parent_matrix:I = 0x7f090648

.field public static final password_toggle:I = 0x7f09064e

.field public static final path:I = 0x7f09064f

.field public static final pathRelative:I = 0x7f090650

.field public static final percent:I = 0x7f09065b

.field public static final pin:I = 0x7f090664

.field public static final position:I = 0x7f090678

.field public static final postLayout:I = 0x7f09067c

.field public static final progress_circular:I = 0x7f090687

.field public static final progress_horizontal:I = 0x7f090688

.field public static final radio:I = 0x7f0906aa

.field public static final rectangles:I = 0x7f0906b0

.field public static final reverseSawtooth:I = 0x7f0906c6

.field public static final right:I = 0x7f0906c8

.field public static final rightToLeft:I = 0x7f0906c9

.field public static final right_icon:I = 0x7f0906ca

.field public static final right_side:I = 0x7f0906cb

.field public static final rounded:I = 0x7f0906de

.field public static final row_index_key:I = 0x7f0906e0

.field public static final save_non_transition_alpha:I = 0x7f090702

.field public static final save_overlay_view:I = 0x7f090703

.field public static final sawtooth:I = 0x7f090705

.field public static final scale:I = 0x7f090707

.field public static final screen:I = 0x7f090709

.field public static final scrollIndicatorDown:I = 0x7f09070b

.field public static final scrollIndicatorUp:I = 0x7f09070c

.field public static final scrollView:I = 0x7f09070d

.field public static final scrollable:I = 0x7f090710

.field public static final search_badge:I = 0x7f090713

.field public static final search_bar:I = 0x7f090714

.field public static final search_button:I = 0x7f090715

.field public static final search_close_btn:I = 0x7f090716

.field public static final search_edit_frame:I = 0x7f090718

.field public static final search_go_btn:I = 0x7f090719

.field public static final search_mag_icon:I = 0x7f09071a

.field public static final search_plate:I = 0x7f09071b

.field public static final search_src_text:I = 0x7f09071c

.field public static final search_voice_btn:I = 0x7f09071d

.field public static final select_dialog_listview:I = 0x7f090727

.field public static final selected:I = 0x7f09072b

.field public static final selection_type:I = 0x7f09072c

.field public static final shortcut:I = 0x7f090737

.field public static final sin:I = 0x7f09073d

.field public static final slide:I = 0x7f090742

.field public static final snackbar_action:I = 0x7f090744

.field public static final snackbar_text:I = 0x7f090745

.field public static final spacer:I = 0x7f090752

.field public static final spline:I = 0x7f090755

.field public static final split_action_bar:I = 0x7f090756

.field public static final spread:I = 0x7f090757

.field public static final spread_inside:I = 0x7f090758

.field public static final square:I = 0x7f09075a

.field public static final src_atop:I = 0x7f09075b

.field public static final src_in:I = 0x7f09075c

.field public static final src_over:I = 0x7f09075d

.field public static final standard:I = 0x7f090767

.field public static final start:I = 0x7f090768

.field public static final startHorizontal:I = 0x7f090769

.field public static final startToEnd:I = 0x7f09076a

.field public static final startVertical:I = 0x7f09076b

.field public static final staticLayout:I = 0x7f09076e

.field public static final staticPostLayout:I = 0x7f09076f

.field public static final stop:I = 0x7f090776

.field public static final stretch:I = 0x7f090777

.field public static final submenuarrow:I = 0x7f090778

.field public static final submit_area:I = 0x7f09077b

.field public static final tabMode:I = 0x7f09079c

.field public static final tag_accessibility_actions:I = 0x7f0907a1

.field public static final tag_accessibility_clickable_spans:I = 0x7f0907a2

.field public static final tag_accessibility_heading:I = 0x7f0907a3

.field public static final tag_accessibility_pane_title:I = 0x7f0907a4

.field public static final tag_on_apply_window_listener:I = 0x7f0907a7

.field public static final tag_on_receive_content_listener:I = 0x7f0907a8

.field public static final tag_on_receive_content_mime_types:I = 0x7f0907a9

.field public static final tag_screen_reader_focusable:I = 0x7f0907aa

.field public static final tag_state_description:I = 0x7f0907ab

.field public static final tag_transition_group:I = 0x7f0907ad

.field public static final tag_unhandled_key_event_manager:I = 0x7f0907af

.field public static final tag_unhandled_key_listeners:I = 0x7f0907b0

.field public static final tag_window_insets_animation_callback:I = 0x7f0907b1

.field public static final test_checkbox_android_button_tint:I = 0x7f0907b3

.field public static final test_checkbox_app_button_tint:I = 0x7f0907b4

.field public static final test_radiobutton_android_button_tint:I = 0x7f0907b5

.field public static final test_radiobutton_app_button_tint:I = 0x7f0907b6

.field public static final text:I = 0x7f0907b7

.field public static final text2:I = 0x7f0907ba

.field public static final textSpacerNoButtons:I = 0x7f0907c0

.field public static final textSpacerNoTitle:I = 0x7f0907c1

.field public static final text_input_end_icon:I = 0x7f090822

.field public static final text_input_error_icon:I = 0x7f090823

.field public static final text_input_start_icon:I = 0x7f090824

.field public static final textinput_counter:I = 0x7f090825

.field public static final textinput_error:I = 0x7f090826

.field public static final textinput_helper_text:I = 0x7f090827

.field public static final textinput_placeholder:I = 0x7f090828

.field public static final textinput_prefix_text:I = 0x7f090829

.field public static final textinput_suffix_text:I = 0x7f09082a

.field public static final time:I = 0x7f09082f

.field public static final title:I = 0x7f090834

.field public static final titleDividerNoCustom:I = 0x7f090836

.field public static final title_template:I = 0x7f09083d

.field public static final top:I = 0x7f090845

.field public static final topPanel:I = 0x7f090846

.field public static final touch_outside:I = 0x7f090852

.field public static final transition_current_scene:I = 0x7f090859

.field public static final transition_layout_save:I = 0x7f09085a

.field public static final transition_position:I = 0x7f09085b

.field public static final transition_scene_layoutid_cache:I = 0x7f09085c

.field public static final transition_transform:I = 0x7f09085d

.field public static final triangle:I = 0x7f090862

.field public static final unchecked:I = 0x7f090a88

.field public static final uniform:I = 0x7f090a89

.field public static final unlabeled:I = 0x7f090a8a

.field public static final up:I = 0x7f090a8c

.field public static final view_offset_helper:I = 0x7f090abc

.field public static final visible:I = 0x7f090ac6

.field public static final visible_removing_fragment_view_tag:I = 0x7f090ac7

.field public static final withinBounds:I = 0x7f090aea

.field public static final wrap:I = 0x7f090aec

.field public static final wrap_content:I = 0x7f090aed

.field public static final zero_corner_chip:I = 0x7f090af8


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method
