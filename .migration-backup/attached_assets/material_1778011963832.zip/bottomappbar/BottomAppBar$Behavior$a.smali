.class Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;


# direct methods
.method constructor <init>(Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior$a;->a:Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onLayoutChange(Landroid/view/View;IIIIIIII)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s@ ~K@ro  f@~ ~~  ~  @m~otsS~l-@@~@4o1@  o@ ~@M@~b. ~~f~~i~@ y /ntl@o@@do@vi~@~cbb a~u~ @i@~/ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior$a;->a:Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p2}, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->j(Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;)Ljava/lang/ref/WeakReference;

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    check-cast p2, Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    if-eqz p2, :cond_3

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    instance-of p3, p1, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    if-nez p3, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    goto/16 :goto_1

    :cond_0
    move-object p3, p1

    move-object p3, p1

    move-object p3, p1

    move-object p3, p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    check-cast p3, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object p4, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior$a;->a:Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    const/4 v0, 0x6

    move v1, v0

    invoke-static {p4}, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->k(Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;)Landroid/graphics/Rect;

    move-result-object p4

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p3, p4}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->j(Landroid/graphics/Rect;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p4, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior$a;->a:Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p4}, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->k(Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;)Landroid/graphics/Rect;

    move-result-object p4

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p4}, Landroid/graphics/Rect;->height()I

    move-result p4

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p2, p4}, Lcom/google/android/material/bottomappbar/BottomAppBar;->b1(I)Z

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p3}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getShapeAppearanceModel()Lcom/google/android/material/shape/o;

    move-result-object p5

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p5}, Lcom/google/android/material/shape/o;->r()Lcom/google/android/material/shape/d;

    move-result-object p5

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    new-instance p6, Landroid/graphics/RectF;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iget-object p7, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior$a;->a:Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    const/4 v0, 0x5

    move v1, v0

    invoke-static {p7}, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->k(Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;)Landroid/graphics/Rect;

    move-result-object p7

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p6, p7}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    invoke-interface {p5, p6}, Lcom/google/android/material/shape/d;->a(Landroid/graphics/RectF;)F

    move-result p5

    const/4 v1, 0x4

    invoke-virtual {p2, p5}, Lcom/google/android/material/bottomappbar/BottomAppBar;->setFabCornerSize(F)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    check-cast p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v1, 0x0

    const/4 v0, 0x3

    iget-object p5, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior$a;->a:Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {p5}, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->l(Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;)I

    move-result p5

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    if-nez p5, :cond_2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p3}, Landroid/view/View;->getMeasuredHeight()I

    move-result p5

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    sub-int/2addr p5, p4

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    div-int/lit8 p5, p5, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p2}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p4

    const/4 v1, 0x3

    const/4 v0, 0x5

    sget p6, Lcom/google/android/material/R$dimen;->mtrl_bottomappbar_fab_bottom_margin:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p4, p6}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p4

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    sub-int/2addr p4, p5

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->m0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I

    move-result p5

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    add-int/2addr p5, p4

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p5, p1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->n0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I

    move-result p4

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p4, p1, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->o0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I

    move-result p4

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p4, p1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p3}, Lcom/google/android/material/internal/y;->k(Landroid/view/View;)Z

    move-result p3

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    if-eqz p3, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x4

    iget p3, p1, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->q0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I

    move-result p2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    add-int/2addr p3, p2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p3, p1, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    goto :goto_0

    :cond_1
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget p3, p1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->q0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    add-int/2addr p3, p2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p3, p1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    :cond_2
    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void

    :cond_3
    :goto_1
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method
