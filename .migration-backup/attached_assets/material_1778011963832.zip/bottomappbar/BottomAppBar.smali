.class public Lcom/google/android/material/bottomappbar/BottomAppBar;
.super Landroidx/appcompat/widget/Toolbar;

# interfaces
.implements Landroidx/coordinatorlayout/widget/CoordinatorLayout$b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/bottomappbar/BottomAppBar$SavedState;,
        Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;,
        Lcom/google/android/material/bottomappbar/BottomAppBar$j;,
        Lcom/google/android/material/bottomappbar/BottomAppBar$l;,
        Lcom/google/android/material/bottomappbar/BottomAppBar$k;
    }
.end annotation


# static fields
.field private static final Q0:I

.field private static final R0:J = 0x12cL

.field public static final S0:I = 0x0

.field public static final T0:I = 0x1

.field public static final U0:I = 0x0

.field public static final V0:I = 0x1

.field private static final W0:I


# instance fields
.field private A0:I

.field private B0:Z

.field private final C0:Z

.field private final D0:Z

.field private final E0:Z

.field private F0:I

.field private G0:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/google/android/material/bottomappbar/BottomAppBar$j;",
            ">;"
        }
    .end annotation
.end field

.field private H0:I
    .annotation build Landroidx/annotation/m0;
    .end annotation
.end field

.field private I0:Z

.field private J0:Z

.field private K0:Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

.field private L0:I

.field private M0:I

.field private N0:I

.field O0:Landroid/animation/AnimatorListenerAdapter;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field P0:Lcom/google/android/material/animation/k;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/animation/k<",
            "Lcom/google/android/material/floatingactionbutton/FloatingActionButton;",
            ">;"
        }
    .end annotation
.end field

.field private S:Ljava/lang/Integer;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final T:I

.field private final U:Lcom/google/android/material/shape/j;

.field private V:Landroid/animation/Animator;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private W:Landroid/animation/Animator;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private k0:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_BottomAppBar:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    sput v0, Lcom/google/android/material/bottomappbar/BottomAppBar;->Q0:I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget v0, Lcom/google/android/material/R$attr;->bottomAppBarStyle:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 12
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    sget v6, Lcom/google/android/material/bottomappbar/BottomAppBar;->Q0:I

    const/4 v11, 0x6

    const/4 v10, 0x2

    invoke-static {p1, p2, p3, v6}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/widget/Toolbar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    new-instance p1, Lcom/google/android/material/shape/j;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-direct {p1}, Lcom/google/android/material/shape/j;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x6

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    const/4 v7, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    iput v7, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->F0:I

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    iput v7, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->H0:I

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    iput-boolean v7, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->I0:Z

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x6

    const/4 v0, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    iput-boolean v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->J0:Z

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    new-instance v0, Lcom/google/android/material/bottomappbar/BottomAppBar$a;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-direct {v0, p0}, Lcom/google/android/material/bottomappbar/BottomAppBar$a;-><init>(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    const/4 v10, 0x6

    move v11, v10

    iput-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->O0:Landroid/animation/AnimatorListenerAdapter;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    new-instance v0, Lcom/google/android/material/bottomappbar/BottomAppBar$b;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-direct {v0, p0}, Lcom/google/android/material/bottomappbar/BottomAppBar$b;-><init>(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x4

    iput-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->P0:Lcom/google/android/material/animation/k;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v8

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    sget-object v2, Lcom/google/android/material/R$styleable;->BottomAppBar:[I

    const/4 v11, 0x3

    const/4 v10, 0x1

    new-array v5, v7, [I

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v11, 0x3

    const/4 v10, 0x1

    move v3, p3

    move v3, p3

    const/4 v11, 0x4

    move v3, p3

    move v3, p3

    const/4 v10, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x0

    move v4, v6

    move v4, v6

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    sget v1, Lcom/google/android/material/R$styleable;->BottomAppBar_backgroundTint:I

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {v8, v0, v1}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x3

    sget v2, Lcom/google/android/material/R$styleable;->BottomAppBar_navigationIconTint:I

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v0, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v3

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    if-eqz v3, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    const/4 v3, -0x1

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {v0, v2, v3}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {p0, v2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->setNavigationIconTint(I)V

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x7

    sget v2, Lcom/google/android/material/R$styleable;->BottomAppBar_elevation:I

    const/4 v11, 0x0

    const/4 v10, 0x5

    invoke-virtual {v0, v2, v7}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v2

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    sget v3, Lcom/google/android/material/R$styleable;->BottomAppBar_fabCradleMargin:I

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v0, v3, v7}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v3

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    int-to-float v3, v3

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    sget v4, Lcom/google/android/material/R$styleable;->BottomAppBar_fabCradleRoundedCornerRadius:I

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v0, v4, v7}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v4

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    int-to-float v4, v4

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    sget v5, Lcom/google/android/material/R$styleable;->BottomAppBar_fabCradleVerticalOffset:I

    const/4 v11, 0x4

    const/4 v10, 0x3

    invoke-virtual {v0, v5, v7}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v5

    const/4 v11, 0x2

    const/4 v10, 0x4

    int-to-float v5, v5

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    sget v9, Lcom/google/android/material/R$styleable;->BottomAppBar_fabAlignmentMode:I

    const/4 v11, 0x7

    const/4 v10, 0x5

    invoke-virtual {v0, v9, v7}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v9

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    iput v9, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->k0:I

    const/4 v11, 0x0

    sget v9, Lcom/google/android/material/R$styleable;->BottomAppBar_fabAnimationMode:I

    const/4 v11, 0x1

    invoke-virtual {v0, v9, v7}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v9

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x3

    iput v9, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->A0:I

    const/4 v10, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    sget v9, Lcom/google/android/material/R$styleable;->BottomAppBar_hideOnScroll:I

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v0, v9, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v9

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    iput-boolean v9, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->B0:Z

    const/4 v10, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x3

    sget v9, Lcom/google/android/material/R$styleable;->BottomAppBar_paddingBottomSystemWindowInsets:I

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v0, v9, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v9

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    iput-boolean v9, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->C0:Z

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    sget v9, Lcom/google/android/material/R$styleable;->BottomAppBar_paddingLeftSystemWindowInsets:I

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {v0, v9, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v9

    const/4 v11, 0x3

    const/4 v10, 0x1

    iput-boolean v9, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->D0:Z

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    sget v9, Lcom/google/android/material/R$styleable;->BottomAppBar_paddingRightSystemWindowInsets:I

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v0, v9, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v7

    const/4 v11, 0x2

    const/4 v10, 0x6

    iput-boolean v7, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->E0:Z

    const/4 v11, 0x4

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x6

    sget v7, Lcom/google/android/material/R$dimen;->mtrl_bottomappbar_fabOffsetEndMode:I

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {v0, v7}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    iput v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->T:I

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    new-instance v0, Lcom/google/android/material/bottomappbar/a;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-direct {v0, v3, v4, v5}, Lcom/google/android/material/bottomappbar/a;-><init>(FFF)V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-static {}, Lcom/google/android/material/shape/o;->a()Lcom/google/android/material/shape/o$b;

    move-result-object v3

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v3, v0}, Lcom/google/android/material/shape/o$b;->G(Lcom/google/android/material/shape/g;)Lcom/google/android/material/shape/o$b;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/shape/o$b;->m()Lcom/google/android/material/shape/o;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {p1, v0}, Lcom/google/android/material/shape/j;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    const/4 v0, 0x2

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {p1, v0}, Lcom/google/android/material/shape/j;->x0(I)V

    const/4 v11, 0x5

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/material/shape/j;->r0(Landroid/graphics/Paint$Style;)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {p1, v8}, Lcom/google/android/material/shape/j;->Z(Landroid/content/Context;)V

    const/4 v11, 0x4

    int-to-float v0, v2

    const/4 v10, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p0, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->setElevation(F)V

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {p1, v1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {p0, p1}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    new-instance p1, Lcom/google/android/material/bottomappbar/BottomAppBar$c;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-direct {p1, p0}, Lcom/google/android/material/bottomappbar/BottomAppBar$c;-><init>(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-static {p0, p2, p3, v6, p1}, Lcom/google/android/material/internal/y;->c(Landroid/view/View;Landroid/util/AttributeSet;IILcom/google/android/material/internal/y$e;)V

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    return-void
.end method

.method private B0(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V
    .locals 3
    .param p1    # Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b@sd~ vo ~@@yo@ ff~@~@iKt4~ a @@bo@~o~~c@@ ~S-~ @ ~@.inb@@ll 1i r~toM//~~@s~ ~o~~  @~  ~@~~@ u@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->O0:Landroid/animation/AnimatorListenerAdapter;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->d(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v1, 0x2

    const/4 v1, 0x5

    new-instance v0, Lcom/google/android/material/bottomappbar/BottomAppBar$i;

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-direct {v0, p0}, Lcom/google/android/material/bottomappbar/BottomAppBar$i;-><init>(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->e(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->P0:Lcom/google/android/material/animation/k;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->f(Lcom/google/android/material/animation/k;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method private C0()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->W:Landroid/animation/Animator;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/animation/Animator;->cancel()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->V:Landroid/animation/Animator;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/animation/Animator;->cancel()V

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method private E0(ILjava/util/List;)V
    .locals 5
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Landroid/animation/Animator;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->I0()Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x4

    new-array v1, v1, [F

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->L0(I)F

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    aput p1, v1, v2

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo p1, "ntXmtlonaiar"

    const-string p1, "Xrsannlttaoi"

    const/4 v4, 0x0

    const-string/jumbo p1, "sonloaitrtaX"

    const-string/jumbo p1, "translationX"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0, p1, v1}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-wide/16 v0, 0x12c

    const-wide/16 v0, 0x12c

    const/4 v4, 0x6

    const-wide/16 v0, 0x12c

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {p2, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void
.end method

.method private F0(IZLjava/util/List;)V
    .locals 10
    .param p3    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(IZ",
            "Ljava/util/List<",
            "Landroid/animation/Animator;",
            ">;)V"
        }
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getActionMenuView()Landroidx/appcompat/widget/ActionMenuView;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-nez v0, :cond_0

    const/4 v8, 0x5

    and-int/2addr v9, v8

    return-void

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/4 v1, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    new-array v2, v1, [F

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/4 v3, 0x0

    const/4 v9, 0x0

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    aput v4, v2, v3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string v5, "blpah"

    const-string/jumbo v5, "lhamp"

    const-string v5, "alpha"

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {v0, v5, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getTranslationX()F

    move-result v6

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p0, v0, p1, p2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->K0(Landroidx/appcompat/widget/ActionMenuView;IZ)I

    move-result v7

    const/4 v9, 0x7

    const/4 v8, 0x1

    int-to-float v7, v7

    const/4 v9, 0x6

    const/4 v8, 0x2

    sub-float/2addr v6, v7

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    move-result v6

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    cmpl-float v6, v6, v4

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-lez v6, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    new-array v4, v1, [F

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    const/4 v6, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    aput v6, v4, v3

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {v0, v5, v4}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Ljava/lang/String;[F)Landroid/animation/ObjectAnimator;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    new-instance v5, Lcom/google/android/material/bottomappbar/BottomAppBar$g;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-direct {v5, p0, v0, p1, p2}, Lcom/google/android/material/bottomappbar/BottomAppBar$g;-><init>(Lcom/google/android/material/bottomappbar/BottomAppBar;Landroidx/appcompat/widget/ActionMenuView;IZ)V

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v4, v5}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    new-instance p1, Landroid/animation/AnimatorSet;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-direct {p1}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-wide/16 v5, 0x96

    const-wide/16 v5, 0x96

    const-wide/16 v5, 0x96

    const-wide/16 v5, 0x96

    const/4 v8, 0x0

    xor-int/2addr v9, v8

    invoke-virtual {p1, v5, v6}, Landroid/animation/AnimatorSet;->setDuration(J)Landroid/animation/AnimatorSet;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 p2, 0x2

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    new-array p2, p2, [Landroid/animation/Animator;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    aput-object v4, p2, v3

    const/4 v9, 0x6

    const/4 v8, 0x0

    aput-object v2, p2, v1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p1, p2}, Landroid/animation/AnimatorSet;->playSequentially([Landroid/animation/Animator;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-interface {p3, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    goto :goto_0

    :cond_1
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getAlpha()F

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    cmpg-float p1, p1, v4

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-gez p1, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-interface {p3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    return-void
.end method

.method private G0()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->F0:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->F0:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->G0:Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast v1, Lcom/google/android/material/bottomappbar/BottomAppBar$j;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v1, p0}, Lcom/google/android/material/bottomappbar/BottomAppBar$j;->a(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method private H0()V
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->F0:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/lit8 v1, v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->F0:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->G0:Ljava/util/ArrayList;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v1, Lcom/google/android/material/bottomappbar/BottomAppBar$j;

    const/4 v3, 0x5

    invoke-interface {v1, p0}, Lcom/google/android/material/bottomappbar/BottomAppBar$j;->b(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method private I0()Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->J0()Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    instance-of v1, v0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    check-cast v0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0
.end method

.method private J0()Landroid/view/View;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    instance-of v0, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object v1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    check-cast v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0, p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->r(Landroid/view/View;)Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    check-cast v2, Landroid/view/View;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    instance-of v3, v2, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v3, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    instance-of v3, v2, Lcom/google/android/material/floatingactionbutton/ExtendedFloatingActionButton;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v3, :cond_1

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object v2

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-object v1
.end method

.method private L0(I)F
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/google/android/material/internal/y;->k(Landroid/view/View;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-ne p1, v1, :cond_2

    const/4 v3, 0x5

    and-int/2addr v4, v3

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->N0:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    iget p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->M0:I

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v2, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->T:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    add-int/2addr v2, p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    div-int/lit8 p1, p1, 0x2

    const/4 v4, 0x2

    sub-int/2addr p1, v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v1, -0x1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    mul-int/2addr p1, v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    int-to-float p1, p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    return p1

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    return p1
.end method

.method private M0()Z
    .locals 3

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->I0()Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->p()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private P0(IZ)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p0}, Landroidx/core/view/k1;->U0(Landroid/view/View;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-boolean v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->I0:Z

    const/4 v4, 0x2

    iget p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->H0:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->X0(I)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->W:Landroid/animation/Animator;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/animation/Animator;->cancel()V

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->M0()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-nez v2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    move p1, v1

    move p1, v1

    const/4 v4, 0x1

    move p1, v1

    move p1, v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    move p2, p1

    move p2, p1

    const/4 v4, 0x1

    move p2, p1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->F0(IZLjava/util/List;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance p1, Landroid/animation/AnimatorSet;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {p1}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Landroid/animation/AnimatorSet;->playTogether(Ljava/util/Collection;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->W:Landroid/animation/Animator;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance p2, Lcom/google/android/material/bottomappbar/BottomAppBar$f;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p2, p0}, Lcom/google/android/material/bottomappbar/BottomAppBar$f;-><init>(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, p2}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->W:Landroid/animation/Animator;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/animation/Animator;->start()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void
.end method

.method private Q0(I)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->k0:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eq v0, p1, :cond_3

    const/4 v4, 0x4

    invoke-static {p0}, Landroidx/core/view/k1;->U0(Landroid/view/View;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    goto :goto_1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->V:Landroid/animation/Animator;

    const/4 v4, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/animation/Animator;->cancel()V

    :cond_1
    const/4 v4, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->A0:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v2, 0x1

    if-ne v1, v2, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->E0(ILjava/util/List;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->D0(ILjava/util/List;)V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance p1, Landroid/animation/AnimatorSet;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p1}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Landroid/animation/AnimatorSet;->playTogether(Ljava/util/Collection;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->V:Landroid/animation/Animator;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v0, Lcom/google/android/material/bottomappbar/BottomAppBar$d;

    const/4 v3, 0x4

    move v4, v3

    invoke-direct {v0, p0}, Lcom/google/android/material/bottomappbar/BottomAppBar$d;-><init>(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->V:Landroid/animation/Animator;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/animation/Animator;->start()V

    :cond_3
    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method

.method private R0(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    and-int/2addr v2, v1

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->S:Ljava/lang/Integer;

    const/4 v2, 0x4

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1}, Landroidx/core/graphics/drawable/d;->r(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->S:Ljava/lang/Integer;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->n(Landroid/graphics/drawable/Drawable;I)V

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p1
.end method

.method static synthetic T(Lcom/google/android/material/bottomappbar/BottomAppBar;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget-boolean p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->I0:Z

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic U(Lcom/google/android/material/bottomappbar/BottomAppBar;Z)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->I0:Z

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return p1
.end method

.method static synthetic V(Lcom/google/android/material/bottomappbar/BottomAppBar;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->k0:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic W(Lcom/google/android/material/bottomappbar/BottomAppBar;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget-boolean p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->E0:Z

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic X(Lcom/google/android/material/bottomappbar/BottomAppBar;)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->M0:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic Y(Lcom/google/android/material/bottomappbar/BottomAppBar;I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->M0:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p1
.end method

.method private Y0()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getActionMenuView()Landroidx/appcompat/widget/ActionMenuView;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->W:Landroid/animation/Animator;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-nez v1, :cond_1

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setAlpha(F)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->M0()Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p0, v0, v1, v1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->c1(Landroidx/appcompat/widget/ActionMenuView;IZ)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    iget v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->k0:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-boolean v2, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->J0:Z

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p0, v0, v1, v2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->c1(Landroidx/appcompat/widget/ActionMenuView;IZ)V

    :cond_1
    :goto_0
    const/4 v4, 0x2

    return-void
.end method

.method static synthetic Z(Lcom/google/android/material/bottomappbar/BottomAppBar;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->C0()V

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method private Z0()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getFabTranslationX()F

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/bottomappbar/a;->o(F)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->J0()Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-boolean v2, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->J0:Z

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->M0()Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Lcom/google/android/material/shape/j;->p0(F)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getFabTranslationY()F

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationY(F)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getFabTranslationX()F

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationX(F)V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method

.method static synthetic a0(Lcom/google/android/material/bottomappbar/BottomAppBar;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->Z0()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    return-void
.end method

.method static synthetic b0(Lcom/google/android/material/bottomappbar/BottomAppBar;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->Y0()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic c0(Lcom/google/android/material/bottomappbar/BottomAppBar;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->H0()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method private c1(Landroidx/appcompat/widget/ActionMenuView;IZ)V
    .locals 3
    .param p1    # Landroidx/appcompat/widget/ActionMenuView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, p3, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->d1(Landroidx/appcompat/widget/ActionMenuView;IZZ)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method static synthetic d0(Lcom/google/android/material/bottomappbar/BottomAppBar;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->G0()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method private d1(Landroidx/appcompat/widget/ActionMenuView;IZZ)V
    .locals 3
    .param p1    # Landroidx/appcompat/widget/ActionMenuView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/material/bottomappbar/BottomAppBar$h;

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/google/android/material/bottomappbar/BottomAppBar$h;-><init>(Lcom/google/android/material/bottomappbar/BottomAppBar;Landroidx/appcompat/widget/ActionMenuView;IZ)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p4, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method static synthetic e0(Lcom/google/android/material/bottomappbar/BottomAppBar;Landroid/animation/Animator;)Landroid/animation/Animator;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->V:Landroid/animation/Animator;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method static synthetic f0(Lcom/google/android/material/bottomappbar/BottomAppBar;I)F
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->L0(I)F

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic g0(Lcom/google/android/material/bottomappbar/BottomAppBar;Landroid/animation/Animator;)Landroid/animation/Animator;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->W:Landroid/animation/Animator;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method

.method private getActionMenuView()Landroidx/appcompat/widget/ActionMenuView;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-ge v0, v1, :cond_1

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    instance-of v2, v1, Landroidx/appcompat/widget/ActionMenuView;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    check-cast v1, Landroidx/appcompat/widget/ActionMenuView;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object v1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object v0
.end method

.method private getBottomInset()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->L0:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method private getFabTranslationX()F
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->k0:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->L0(I)F

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method private getFabTranslationY()F
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/bottomappbar/a;->d()F

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    neg-float v0, v0

    const/4 v1, 0x0

    const/4 v1, 0x5

    return v0
.end method

.method private getLeftInset()I
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->N0:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method private getRightInset()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->M0:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    return v0
.end method

.method private getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v1, 0x1

    move v2, v1

    invoke-virtual {v0}, Lcom/google/android/material/shape/j;->getShapeAppearanceModel()Lcom/google/android/material/shape/o;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/shape/o;->p()Lcom/google/android/material/shape/g;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/material/bottomappbar/a;

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic h0(Lcom/google/android/material/bottomappbar/BottomAppBar;)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-boolean p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->J0:Z

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic i0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->H0:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic j0(Lcom/google/android/material/bottomappbar/BottomAppBar;Landroidx/appcompat/widget/ActionMenuView;IZZ)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/android/material/bottomappbar/BottomAppBar;->d1(Landroidx/appcompat/widget/ActionMenuView;IZZ)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic k0(Lcom/google/android/material/bottomappbar/BottomAppBar;)Lcom/google/android/material/floatingactionbutton/FloatingActionButton;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->I0()Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic l0(Lcom/google/android/material/bottomappbar/BottomAppBar;)F
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getFabTranslationX()F

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic m0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getBottomInset()I

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic n0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getLeftInset()I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic o0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getRightInset()I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x1

    return p0
.end method

.method static synthetic p0(Lcom/google/android/material/bottomappbar/BottomAppBar;IZ)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->P0(IZ)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic q0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->T:I

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic r0(Lcom/google/android/material/bottomappbar/BottomAppBar;)Landroid/view/View;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->J0()Landroid/view/View;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-object p0
.end method

.method static synthetic s0(Lcom/google/android/material/bottomappbar/BottomAppBar;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->B0(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic t0(Lcom/google/android/material/bottomappbar/BottomAppBar;)Lcom/google/android/material/shape/j;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic u0(Lcom/google/android/material/bottomappbar/BottomAppBar;)Lcom/google/android/material/bottomappbar/a;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic v0(Lcom/google/android/material/bottomappbar/BottomAppBar;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget-boolean p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->C0:Z

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic w0(Lcom/google/android/material/bottomappbar/BottomAppBar;I)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->L0:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic x0(Lcom/google/android/material/bottomappbar/BottomAppBar;)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget-boolean p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->D0:Z

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic y0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->N0:I

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic z0(Lcom/google/android/material/bottomappbar/BottomAppBar;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->N0:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p1
.end method


# virtual methods
.method A0(Lcom/google/android/material/bottomappbar/BottomAppBar$j;)V
    .locals 3
    .param p1    # Lcom/google/android/material/bottomappbar/BottomAppBar$j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->G0:Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->G0:Ljava/util/ArrayList;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->G0:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method protected D0(ILjava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Landroid/animation/Animator;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->I0()Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz p2, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p2}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->o()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->H0()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/bottomappbar/BottomAppBar$e;

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1}, Lcom/google/android/material/bottomappbar/BottomAppBar$e;-><init>(Lcom/google/android/material/bottomappbar/BottomAppBar;I)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p2, v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->m(Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;)V

    :cond_1
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method protected K0(Landroidx/appcompat/widget/ActionMenuView;IZ)I
    .locals 8
    .param p1    # Landroidx/appcompat/widget/ActionMenuView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-ne p2, v1, :cond_8

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-nez p3, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto/16 :goto_6

    :cond_0
    const/4 v6, 0x6

    move v7, v6

    invoke-static {p0}, Lcom/google/android/material/internal/y;->k(Landroid/view/View;)Z

    move-result p2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz p2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    move p3, v0

    move p3, v0

    const/4 v7, 0x3

    move p3, v0

    move p3, v0

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    move v2, v0

    move v2, v0

    const/4 v7, 0x2

    move v2, v0

    move v2, v0

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-ge v2, v3, :cond_5

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x7

    instance-of v4, v4, Landroidx/appcompat/widget/Toolbar$e;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v4, :cond_2

    const/4 v7, 0x5

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    check-cast v4, Landroidx/appcompat/widget/Toolbar$e;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget v4, v4, Landroidx/appcompat/app/a$b;->a:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    const v5, 0x800007

    const/4 v6, 0x0

    move v7, v6

    and-int/2addr v4, v5

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    const v5, 0x800003

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-ne v4, v5, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x5

    move v4, v1

    move v4, v1

    const/4 v7, 0x1

    move v4, v1

    move v4, v1

    const/4 v7, 0x5

    const/4 v6, 0x7

    goto :goto_2

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    move v4, v0

    move v4, v0

    const/4 v7, 0x7

    move v4, v0

    move v4, v0

    :goto_2
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v4, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz p2, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {p3, v3}, Ljava/lang/Math;->min(II)I

    move-result p3

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    goto :goto_3

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v3}, Landroid/view/View;->getRight()I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {p3, v3}, Ljava/lang/Math;->max(II)I

    move-result p3

    :cond_4
    :goto_3
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto/16 :goto_1

    :cond_5
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz p2, :cond_6

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getRight()I

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_4

    :cond_6
    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p1

    :goto_4
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz p2, :cond_7

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget p2, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->M0:I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_5

    :cond_7
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget p2, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->N0:I

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    neg-int p2, p2

    :goto_5
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    add-int/2addr p1, p2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    sub-int/2addr p3, p1

    const/4 v7, 0x4

    return p3

    :cond_8
    :goto_6
    const/4 v7, 0x6

    return v0
.end method

.method public N0()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getBehavior()Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->c()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public O0()Z
    .locals 3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getBehavior()Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->d()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public S0()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->T0(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public T0(Z)V
    .locals 3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getBehavior()Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p0, p1}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->g(Landroid/view/View;Z)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public U0()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->V0(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public V0(Z)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getBehavior()Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p0, p1}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->i(Landroid/view/View;Z)V

    const/4 v2, 0x0

    return-void
.end method

.method W0(Lcom/google/android/material/bottomappbar/BottomAppBar$j;)V
    .locals 3
    .param p1    # Lcom/google/android/material/bottomappbar/BottomAppBar$j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->G0:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public X0(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/m0;
        .end annotation
    .end param

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->H0:I

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->getMenu()Landroid/view/Menu;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {v0}, Landroid/view/Menu;->clear()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/Toolbar;->x(I)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public a1(II)V
    .locals 2
    .param p2    # I
        .annotation build Landroidx/annotation/m0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p2, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->H0:I

    const/4 v1, 0x2

    const/4 p2, 0x1

    const/4 v1, 0x7

    move v0, p2

    move v0, p2

    const/4 v1, 0x6

    iput-boolean p2, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->I0:Z

    const/4 v1, 0x1

    const/4 v0, 0x0

    iget-boolean p2, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->J0:Z

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->P0(IZ)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->Q0(I)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->k0:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method b1(I)Z
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    int-to-float p1, p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/bottomappbar/a;->h()F

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    cmpl-float v0, p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/bottomappbar/a;->n(F)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 p1, 0x6

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x3

    return p1
.end method

.method public getBackgroundTint()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/shape/j;->R()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic getBehavior()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getBehavior()Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public getBehavior()Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->K0:Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-nez v0, :cond_0

    new-instance v0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->K0:Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->K0:Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public getCradleVerticalOffset()F
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/bottomappbar/a;->d()F

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public getFabAlignmentMode()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->k0:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public getFabAnimationMode()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->A0:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public getFabCradleMargin()F
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/bottomappbar/a;->f()F

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public getFabCradleRoundedCornerRadius()F
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/bottomappbar/a;->g()F

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public getHideOnScroll()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->B0:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method protected onAttachedToWindow()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-super {p0}, Landroid/view/ViewGroup;->onAttachedToWindow()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p0, v0}, Lcom/google/android/material/shape/k;->f(Landroid/view/View;Lcom/google/android/material/shape/j;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    instance-of v0, v0, Landroid/view/ViewGroup;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setClipChildren(Z)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 2

    const/4 v1, 0x3

    invoke-super/range {p0 .. p5}, Landroidx/appcompat/widget/Toolbar;->onLayout(ZIIII)V

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v0, 0x6

    move v1, v0

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->C0()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->Z0()V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->Y0()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method protected onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    instance-of v0, p1, Lcom/google/android/material/bottomappbar/BottomAppBar$SavedState;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-super {p0, p1}, Landroidx/appcompat/widget/Toolbar;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast p1, Lcom/google/android/material/bottomappbar/BottomAppBar$SavedState;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroidx/customview/view/AbsSavedState;->a()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-super {p0, v0}, Landroidx/appcompat/widget/Toolbar;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    iget v0, p1, Lcom/google/android/material/bottomappbar/BottomAppBar$SavedState;->c:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->k0:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-boolean p1, p1, Lcom/google/android/material/bottomappbar/BottomAppBar$SavedState;->d:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->J0:Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method protected onSaveInstanceState()Landroid/os/Parcelable;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-super {p0}, Landroidx/appcompat/widget/Toolbar;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v1, Lcom/google/android/material/bottomappbar/BottomAppBar$SavedState;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v1, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar$SavedState;-><init>(Landroid/os/Parcelable;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->k0:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput v0, v1, Lcom/google/android/material/bottomappbar/BottomAppBar$SavedState;->c:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->J0:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-boolean v0, v1, Lcom/google/android/material/bottomappbar/BottomAppBar$SavedState;->d:Z

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v1
.end method

.method public setBackgroundTint(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public setCradleVerticalOffset(F)V
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getCradleVerticalOffset()F

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    cmpl-float v0, p1, v0

    const/4 v1, 0x6

    and-int/2addr v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/bottomappbar/a;->j(F)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->Z0()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public setElevation(F)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->n0(F)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/shape/j;->K()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/shape/j;->J()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    sub-int/2addr p1, v0

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getBehavior()Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p0, p1}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->e(Landroid/view/View;I)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public setFabAlignmentMode(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->a1(II)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public setFabAnimationMode(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->A0:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method setFabCornerSize(F)V
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/bottomappbar/a;->e()F

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    cmpl-float v0, p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/bottomappbar/a;->k(F)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public setFabCradleMargin(F)V
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getFabCradleMargin()F

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    cmpl-float v0, p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/bottomappbar/a;->l(F)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x7

    return-void
.end method

.method public setFabCradleRoundedCornerRadius(F)V
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getFabCradleRoundedCornerRadius()F

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    cmpl-float v0, p1, v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getTopEdgeTreatment()Lcom/google/android/material/bottomappbar/a;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lcom/google/android/material/bottomappbar/a;->m(F)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->U:Lcom/google/android/material/shape/j;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public setHideOnScroll(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->B0:Z

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public setNavigationIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->R0(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroidx/appcompat/widget/Toolbar;->setNavigationIcon(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public setNavigationIconTint(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar;->S:Ljava/lang/Integer;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/widget/Toolbar;->getNavigationIcon()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->setNavigationIcon(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public setSubtitle(Ljava/lang/CharSequence;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 2

    const/4 v1, 0x3

    return-void
.end method
