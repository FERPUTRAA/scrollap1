.class public Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;
.super Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/bottomappbar/BottomAppBar;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Behavior"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior<",
        "Lcom/google/android/material/bottomappbar/BottomAppBar;",
        ">;"
    }
.end annotation


# instance fields
.field private final i:Landroid/graphics/Rect;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private j:Ljava/lang/ref/WeakReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcom/google/android/material/bottomappbar/BottomAppBar;",
            ">;"
        }
    .end annotation
.end field

.field private k:I

.field private final l:Landroid/view/View$OnLayoutChangeListener;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior$a;

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior$a;-><init>(Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->l:Landroid/view/View$OnLayoutChangeListener;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Landroid/graphics/Rect;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->i:Landroid/graphics/Rect;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x0

    new-instance p1, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior$a;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p1, p0}, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior$a;-><init>(Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->l:Landroid/view/View$OnLayoutChangeListener;

    const/4 v1, 0x3

    const/4 v0, 0x0

    new-instance p1, Landroid/graphics/Rect;

    const/4 v0, 0x0

    shl-int/2addr v1, v0

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->i:Landroid/graphics/Rect;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic j(Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;)Ljava/lang/ref/WeakReference;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @s~1ooo~~ ~  ~f~~t ~@Kl@@i b@4  ~@~@ df~ @@/.a~@~b @m@ n@M@~~@@s~ ~lb~ io@yc@/ot ~ro~~ i~ Su-@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->j:Ljava/lang/ref/WeakReference;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic k(Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;)Landroid/graphics/Rect;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->i:Landroid/graphics/Rect;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic l(Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    iget p0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->k:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p0
.end method


# virtual methods
.method public m(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/bottomappbar/BottomAppBar;I)Z
    .locals 5
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/bottomappbar/BottomAppBar;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v0, p2}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->j:Ljava/lang/ref/WeakReference;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->r0(Lcom/google/android/material/bottomappbar/BottomAppBar;)Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v0, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v0}, Landroidx/core/view/k1;->U0(Landroid/view/View;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-nez v1, :cond_3

    const/4 v4, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/16 v2, 0x31

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput v2, v1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->d:I

    const/4 v3, 0x0

    move v4, v3

    iget v1, v1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->k:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    instance-of v1, v0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    check-cast v0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getShowMotionSpec()Lcom/google/android/material/animation/h;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget v1, Lcom/google/android/material/R$animator;->mtrl_fab_show_motion_spec:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setShowMotionSpecResource(I)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->getHideMotionSpec()Lcom/google/android/material/animation/h;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-nez v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    sget v1, Lcom/google/android/material/R$animator;->mtrl_fab_hide_motion_spec:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setHideMotionSpecResource(I)V

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->l:Landroid/view/View$OnLayoutChangeListener;

    const/4 v3, 0x7

    move v4, v3

    invoke-virtual {v0, v1}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p2, v0}, Lcom/google/android/material/bottomappbar/BottomAppBar;->s0(Lcom/google/android/material/bottomappbar/BottomAppBar;Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->a0(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->H(Landroid/view/View;I)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-super {p0, p1, p2, p3}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    return p1
.end method

.method public n(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/bottomappbar/BottomAppBar;Landroid/view/View;Landroid/view/View;II)Z
    .locals 3
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/bottomappbar/BottomAppBar;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->getHideOnScroll()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-super/range {p0 .. p6}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->onStartNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;II)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p1
.end method

.method public bridge synthetic onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    check-cast p2, Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->m(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/bottomappbar/BottomAppBar;I)Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p1
.end method

.method public bridge synthetic onStartNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;II)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    check-cast p2, Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v0, 0x5

    shr-int/2addr v1, v0

    invoke-virtual/range {p0 .. p6}, Lcom/google/android/material/bottomappbar/BottomAppBar$Behavior;->n(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Lcom/google/android/material/bottomappbar/BottomAppBar;Landroid/view/View;Landroid/view/View;II)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p1
.end method
