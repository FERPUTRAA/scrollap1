.class Lcom/google/android/material/bottomappbar/BottomAppBar$c;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/internal/y$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/bottomappbar/BottomAppBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/bottomappbar/BottomAppBar;


# direct methods
.method constructor <init>(Lcom/google/android/material/bottomappbar/BottomAppBar;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;Landroidx/core/view/y2;Lcom/google/android/material/internal/y$f;)Landroidx/core/view/y2;
    .locals 5
    .param p2    # Landroidx/core/view/y2;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/internal/y$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~st @~~@ov ib S @~y4 @@   1o@ o@s K~~a@  r@c~~b@~t~  ~/b@@/@@@nlli.oi@~udMm~f-~ o~f~@ o~~~@@ ~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->v0(Lcom/google/android/material/bottomappbar/BottomAppBar;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroidx/core/view/y2;->o()I

    move-result p3

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1, p3}, Lcom/google/android/material/bottomappbar/BottomAppBar;->w0(Lcom/google/android/material/bottomappbar/BottomAppBar;I)I

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->x0(Lcom/google/android/material/bottomappbar/BottomAppBar;)Z

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 p3, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz p1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->y0(Lcom/google/android/material/bottomappbar/BottomAppBar;)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p2}, Landroidx/core/view/y2;->p()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eq p1, v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    move p1, p3

    move p1, p3

    const/4 v4, 0x0

    move p1, p3

    move p1, p3

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x4

    move p1, v0

    move p1, v0

    const/4 v4, 0x2

    move p1, v0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p2}, Landroidx/core/view/y2;->p()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v1, v2}, Lcom/google/android/material/bottomappbar/BottomAppBar;->z0(Lcom/google/android/material/bottomappbar/BottomAppBar;I)I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_1

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    move p1, v0

    move p1, v0

    const/4 v4, 0x5

    move p1, v0

    move p1, v0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-static {v1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->W(Lcom/google/android/material/bottomappbar/BottomAppBar;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v1, :cond_4

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->X(Lcom/google/android/material/bottomappbar/BottomAppBar;)I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p2}, Landroidx/core/view/y2;->q()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eq v1, v2, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_2

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    move p3, v0

    move p3, v0

    const/4 v4, 0x3

    move p3, v0

    move p3, v0

    :goto_2
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p2}, Landroidx/core/view/y2;->q()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->Y(Lcom/google/android/material/bottomappbar/BottomAppBar;I)I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    move v0, p3

    const/4 v4, 0x1

    move v0, p3

    move v0, p3

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez p1, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_6

    :cond_5
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->Z(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->a0(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$c;->a:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-static {p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->b0(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    :cond_6
    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object p2
.end method
