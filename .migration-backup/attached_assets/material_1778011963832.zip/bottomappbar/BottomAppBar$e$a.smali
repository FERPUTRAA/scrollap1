.class Lcom/google/android/material/bottomappbar/BottomAppBar$e$a;
.super Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/bottomappbar/BottomAppBar$e;->a(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/bottomappbar/BottomAppBar$e;


# direct methods
.method constructor <init>(Lcom/google/android/material/bottomappbar/BottomAppBar$e;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$e$a;->a:Lcom/google/android/material/bottomappbar/BottomAppBar$e;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton$b;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public b(Lcom/google/android/material/floatingactionbutton/FloatingActionButton;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ss c~u~@ao- f~~o~~ @@~~l@ y@@@b@i1~/@~lo~~v  /o@o ~ Sf 4@~~ i t~~@tK ~M @d.~bb~~m o@  @ n@i@~r@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$e$a;->a:Lcom/google/android/material/bottomappbar/BottomAppBar$e;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget-object p1, p1, Lcom/google/android/material/bottomappbar/BottomAppBar$e;->b:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/google/android/material/bottomappbar/BottomAppBar;->d0(Lcom/google/android/material/bottomappbar/BottomAppBar;)V

    const/4 v1, 0x0

    return-void
.end method
