.class Lcom/google/android/material/bottomappbar/BottomAppBar$h;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/bottomappbar/BottomAppBar;->d1(Landroidx/appcompat/widget/ActionMenuView;IZZ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/widget/ActionMenuView;

.field final synthetic b:I

.field final synthetic c:Z

.field final synthetic d:Lcom/google/android/material/bottomappbar/BottomAppBar;


# direct methods
.method constructor <init>(Lcom/google/android/material/bottomappbar/BottomAppBar;Landroidx/appcompat/widget/ActionMenuView;IZ)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$h;->d:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$h;->a:Landroidx/appcompat/widget/ActionMenuView;

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput p3, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$h;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-boolean p4, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$h;->c:Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$h;->a:Landroidx/appcompat/widget/ActionMenuView;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$h;->d:Lcom/google/android/material/bottomappbar/BottomAppBar;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v2, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$h;->b:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-boolean v3, p0, Lcom/google/android/material/bottomappbar/BottomAppBar$h;->c:Z

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v0, v2, v3}, Lcom/google/android/material/bottomappbar/BottomAppBar;->K0(Landroidx/appcompat/widget/ActionMenuView;IZ)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    int-to-float v1, v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->setTranslationX(F)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void
.end method
