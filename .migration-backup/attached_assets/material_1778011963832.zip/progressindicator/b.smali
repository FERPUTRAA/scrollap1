.class public abstract Lcom/google/android/material/progressindicator/b;
.super Ljava/lang/Object;


# instance fields
.field public a:I
    .annotation build Landroidx/annotation/u0;
    .end annotation
.end field

.field public b:I
    .annotation build Landroidx/annotation/u0;
    .end annotation
.end field

.field public c:[I
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public d:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field public e:I

.field public f:I


# direct methods
.method protected constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 10
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    const/4 v0, 0x0

    const/4 v8, 0x5

    xor-int/2addr v9, v8

    new-array v1, v0, [I

    const/4 v9, 0x0

    iput-object v1, p0, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    sget v2, Lcom/google/android/material/R$dimen;->mtrl_progress_track_thickness:I

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    sget-object v4, Lcom/google/android/material/R$styleable;->BaseProgressIndicator:[I

    const/4 v9, 0x7

    new-array v7, v0, [I

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v9, 0x0

    const/4 v8, 0x6

    move v5, p3

    move v5, p3

    const/4 v9, 0x1

    move v5, p3

    move v5, p3

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    move v6, p4

    move v6, p4

    const/4 v9, 0x7

    move v6, p4

    move v6, p4

    const/4 v9, 0x1

    const/4 v8, 0x5

    invoke-static/range {v2 .. v7}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v9, 0x2

    const/4 v8, 0x4

    sget p3, Lcom/google/android/material/R$styleable;->BaseProgressIndicator_trackThickness:I

    const/4 v8, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static {p1, p2, p3, v1}, Lcom/google/android/material/resources/c;->d(Landroid/content/Context;Landroid/content/res/TypedArray;II)I

    move-result p3

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    iput p3, p0, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    sget p3, Lcom/google/android/material/R$styleable;->BaseProgressIndicator_trackCornerRadius:I

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {p1, p2, p3, v0}, Lcom/google/android/material/resources/c;->d(Landroid/content/Context;Landroid/content/res/TypedArray;II)I

    move-result p3

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget p4, p0, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    div-int/lit8 p4, p4, 0x2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {p3, p4}, Ljava/lang/Math;->min(II)I

    move-result p3

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    iput p3, p0, Lcom/google/android/material/progressindicator/b;->b:I

    const/4 v9, 0x4

    const/4 v8, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->BaseProgressIndicator_showAnimationBehavior:I

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {p2, p3, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p3

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    iput p3, p0, Lcom/google/android/material/progressindicator/b;->e:I

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    sget p3, Lcom/google/android/material/R$styleable;->BaseProgressIndicator_hideAnimationBehavior:I

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p2, p3, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p3

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    iput p3, p0, Lcom/google/android/material/progressindicator/b;->f:I

    const/4 v9, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/progressindicator/b;->c(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/progressindicator/b;->d(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    const/4 v9, 0x6

    const/4 v8, 0x3

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    return-void
.end method

.method private c(Landroid/content/Context;Landroid/content/res/TypedArray;)V
    .locals 6
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/TypedArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~os@@y ~@io@ab flK~  @ Mo  ~@-~1todt@ ~u4cf@~@ i r~ /~o  b@ ~~~~n @ i@@@ lb~~@/~~@~~@@.S@om~~~vs"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    sget v0, Lcom/google/android/material/R$styleable;->BaseProgressIndicator_indicatorColor:I

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p2, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v2, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    sget p2, Lcom/google/android/material/R$attr;->colorPrimary:I

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {p1, p2, v2}, Lcom/google/android/material/color/s;->b(Landroid/content/Context;II)I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    filled-new-array {p1}, [I

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput-object p1, p0, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v5, 0x6

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p2, v0}, Landroid/content/res/TypedArray;->peekValue(I)Landroid/util/TypedValue;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget v1, v1, Landroid/util/TypedValue;->type:I

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eq v1, v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p2, v0, v2}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    filled-new-array {p1}, [I

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput-object p1, p0, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-void

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p2, v0, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1, p2}, Landroid/content/res/Resources;->getIntArray(I)[I

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput-object p1, p0, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    array-length p1, p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz p1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-void

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x1

    const-string p2, "cicmnoCitro h  nct et sraotsnobC ualrdsy.oae ondplernotidiei wom"

    const-string/jumbo p2, "indicatorColors cannot be empty when indicatorColor is not used."

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    throw p1
.end method

.method private d(Landroid/content/Context;Landroid/content/res/TypedArray;)V
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/TypedArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget v0, Lcom/google/android/material/R$styleable;->BaseProgressIndicator_trackColor:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p2, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {p2, v0, p1}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput p1, p0, Lcom/google/android/material/progressindicator/b;->d:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    or-int/2addr v3, v0

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    aget p2, p2, v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput p2, p0, Lcom/google/android/material/progressindicator/b;->d:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    const p2, 0x1010033

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    filled-new-array {p2}, [I

    move-result-object p2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const p2, 0x3e4ccccd    # 0.2f

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1, v0, p2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/high16 p1, 0x437f0000    # 255.0f

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    mul-float/2addr p2, p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    float-to-int p1, p2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget p2, p0, Lcom/google/android/material/progressindicator/b;->d:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p2, p1}, Lcom/google/android/material/color/s;->a(II)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput p1, p0, Lcom/google/android/material/progressindicator/b;->d:I

    const/4 v3, 0x4

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/progressindicator/b;->f:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public b()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    iget v0, p0, Lcom/google/android/material/progressindicator/b;->e:I

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    and-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method abstract e()V
.end method
