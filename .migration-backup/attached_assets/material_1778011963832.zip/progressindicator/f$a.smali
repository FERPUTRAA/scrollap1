.class Lcom/google/android/material/progressindicator/f$a;
.super Landroidx/dynamicanimation/animation/g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/progressindicator/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/dynamicanimation/animation/g<",
        "Lcom/google/android/material/progressindicator/f;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Landroidx/dynamicanimation/animation/g;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x3

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public bridge synthetic b(Ljava/lang/Object;)F
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o s~r@o  .~i~at M~t ll@fyso~@@n@~b@~~i ob@ i /~@  ~K@@~~4@~~o~ -c@f @~S@@1 v/ ~ ~u@@~ob d ~@@~m@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p1, Lcom/google/android/material/progressindicator/f;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/progressindicator/f$a;->d(Lcom/google/android/material/progressindicator/f;)F

    move-result p1

    const/4 v1, 0x6

    return p1
.end method

.method public bridge synthetic c(Ljava/lang/Object;F)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    check-cast p1, Lcom/google/android/material/progressindicator/f;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/progressindicator/f$a;->e(Lcom/google/android/material/progressindicator/f;F)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public d(Lcom/google/android/material/progressindicator/f;)F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/google/android/material/progressindicator/f;->x(Lcom/google/android/material/progressindicator/f;)F

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const v0, 0x461c4000    # 10000.0f

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    mul-float/2addr p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return p1
.end method

.method public e(Lcom/google/android/material/progressindicator/f;F)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    const v0, 0x461c4000    # 10000.0f

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    div-float/2addr p2, v0

    const/4 v2, 0x5

    invoke-static {p1, p2}, Lcom/google/android/material/progressindicator/f;->y(Lcom/google/android/material/progressindicator/f;F)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method
