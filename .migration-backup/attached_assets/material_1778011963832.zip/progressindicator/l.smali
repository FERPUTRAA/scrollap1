.class final Lcom/google/android/material/progressindicator/l;
.super Lcom/google/android/material/progressindicator/i;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/material/progressindicator/i<",
        "Landroid/animation/ObjectAnimator;",
        ">;"
    }
.end annotation


# static fields
.field private static final j:I = 0x29b

.field private static final k:I = 0x14d

.field private static final l:Landroid/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/Property<",
            "Lcom/google/android/material/progressindicator/l;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private d:Landroid/animation/ObjectAnimator;

.field private e:Landroidx/interpolator/view/animation/b;

.field private final f:Lcom/google/android/material/progressindicator/b;

.field private g:I

.field private h:Z

.field private i:F


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v0, Lcom/google/android/material/progressindicator/l$b;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-class v1, Ljava/lang/Float;

    const-class v1, Ljava/lang/Float;

    const/4 v4, 0x6

    const-class v1, Ljava/lang/Float;

    const-class v1, Ljava/lang/Float;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v2, "Fisariotiosncnmaa"

    const-string v2, "Fcsatmotrainoiain"

    const/4 v4, 0x6

    const-string/jumbo v2, "iFamnamorottcnini"

    const-string v2, "animationFraction"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Lcom/google/android/material/progressindicator/l$b;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    sput-object v0, Lcom/google/android/material/progressindicator/l;->l:Landroid/util/Property;

    return-void
.end method

.method public constructor <init>(Lcom/google/android/material/progressindicator/n;)V
    .locals 3
    .param p1    # Lcom/google/android/material/progressindicator/n;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/material/progressindicator/i;-><init>(I)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/android/material/progressindicator/l;->g:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/material/progressindicator/l;->f:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance p1, Landroidx/interpolator/view/animation/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p1}, Landroidx/interpolator/view/animation/b;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/material/progressindicator/l;->e:Landroidx/interpolator/view/animation/b;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic i(Lcom/google/android/material/progressindicator/l;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@oso  v l~.~u@- ~@b o @M~  @a@fmd~@@o ~~t ~~@~t@o @@ ~@io@@b@/iofr /li~~b~~nS @@ ~@~@1K~~ y4~ c"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iget p0, p0, Lcom/google/android/material/progressindicator/l;->g:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic j(Lcom/google/android/material/progressindicator/l;I)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    iput p1, p0, Lcom/google/android/material/progressindicator/l;->g:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return p1
.end method

.method static synthetic k(Lcom/google/android/material/progressindicator/l;)Lcom/google/android/material/progressindicator/b;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/material/progressindicator/l;->f:Lcom/google/android/material/progressindicator/b;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic l(Lcom/google/android/material/progressindicator/l;Z)Z
    .locals 2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/progressindicator/l;->h:Z

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic m(Lcom/google/android/material/progressindicator/l;)F
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/l;->n()F

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p0
.end method

.method private n()F
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/progressindicator/l;->i:F

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method private o()V
    .locals 5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/l;->d:Landroid/animation/ObjectAnimator;

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    sget-object v0, Lcom/google/android/material/progressindicator/l;->l:Landroid/util/Property;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-array v1, v1, [F

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    fill-array-data v1, :array_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p0, v0, v1}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/google/android/material/progressindicator/l;->d:Landroid/animation/ObjectAnimator;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const-wide/16 v1, 0x14d

    const-wide/16 v1, 0x14d

    const/4 v4, 0x7

    const-wide/16 v1, 0x14d

    const-wide/16 v1, 0x14d

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const/4 v3, 0x6

    move v4, v3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/l;->d:Landroid/animation/ObjectAnimator;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/l;->d:Landroid/animation/ObjectAnimator;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setRepeatCount(I)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/l;->d:Landroid/animation/ObjectAnimator;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v1, Lcom/google/android/material/progressindicator/l$a;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v1, p0}, Lcom/google/android/material/progressindicator/l$a;-><init>(Lcom/google/android/material/progressindicator/l;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method private p()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/progressindicator/l;->h:Z

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v1, 0x3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    aget v0, v0, v1

    const/4 v5, 0x2

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    cmpg-float v0, v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-gez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/i;->c:[I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v1, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    aget v3, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    aput v3, v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x0

    xor-int/2addr v5, v4

    aget v3, v0, v1

    const/4 v5, 0x4

    aput v3, v0, v2

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/android/material/progressindicator/l;->f:Lcom/google/android/material/progressindicator/b;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v2, v2, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v3, p0, Lcom/google/android/material/progressindicator/l;->g:I

    aget v2, v2, v3

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v3, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v3}, Lcom/google/android/material/progressindicator/j;->getAlpha()I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v2, v3}, Lcom/google/android/material/color/s;->a(II)I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    aput v2, v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-boolean v1, p0, Lcom/google/android/material/progressindicator/l;->h:Z

    :cond_0
    const/4 v5, 0x6

    return-void
.end method

.method private s(I)V
    .locals 5

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x3

    aput v1, v0, v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/16 v0, 0x29b

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, p1, v2, v0}, Lcom/google/android/material/progressindicator/i;->b(III)F

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/material/progressindicator/l;->e:Landroidx/interpolator/view/animation/b;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Landroidx/interpolator/view/animation/b;->getInterpolation(F)F

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v2, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    aput v1, v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    aput v1, v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const v0, 0x3eff9dbf

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    add-float/2addr p1, v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/progressindicator/l;->e:Landroidx/interpolator/view/animation/b;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Landroidx/interpolator/view/animation/b;->getInterpolation(F)F

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v1, 0x4

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    aput p1, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    aput p1, v0, v1

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v0, 0x5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    aput v1, p1, v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/l;->d:Landroid/animation/ObjectAnimator;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-virtual {v0}, Landroid/animation/Animator;->cancel()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public c()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/l;->q()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public d(Landroidx/vectordrawable/graphics/drawable/b$a;)V
    .locals 2
    .param p1    # Landroidx/vectordrawable/graphics/drawable/b$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public f()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public g()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/l;->o()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/l;->q()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/l;->d:Landroid/animation/ObjectAnimator;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/animation/ObjectAnimator;->start()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public h()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method q()V
    .locals 5
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput-boolean v0, p0, Lcom/google/android/material/progressindicator/l;->h:Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput v0, p0, Lcom/google/android/material/progressindicator/l;->g:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/i;->c:[I

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/material/progressindicator/l;->f:Lcom/google/android/material/progressindicator/b;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v1, v1, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    aget v1, v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v2}, Lcom/google/android/material/progressindicator/j;->getAlpha()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x2

    invoke-static {v1, v2}, Lcom/google/android/material/color/s;->a(II)I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([II)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method r(F)V
    .locals 3
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/android/material/progressindicator/l;->i:F

    const/4 v2, 0x6

    const v0, 0x43a68000    # 333.0f

    const/4 v2, 0x1

    const/4 v1, 0x2

    mul-float/2addr p1, v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    float-to-int p1, p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/progressindicator/l;->s(I)V

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/l;->p()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    iget-object p1, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method
