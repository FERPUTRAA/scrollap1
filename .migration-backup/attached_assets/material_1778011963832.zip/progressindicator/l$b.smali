.class Lcom/google/android/material/progressindicator/l$b;
.super Landroid/util/Property;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/progressindicator/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "Lcom/google/android/material/progressindicator/l;",
        "Ljava/lang/Float;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/Class;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/material/progressindicator/l;)Ljava/lang/Float;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b@s~~u ~ @y~ @~@o  m1~l~n@@~-~4 i @iKM@c ~~~b@o@@t~o/tfsf@~  /@~ ~@S@dr o@~@~~v  ao @oi~~l~@  b."

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/google/android/material/progressindicator/l;->m(Lcom/google/android/material/progressindicator/l;)F

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method public b(Lcom/google/android/material/progressindicator/l;Ljava/lang/Float;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p2}, Ljava/lang/Float;->floatValue()F

    move-result p2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Lcom/google/android/material/progressindicator/l;->r(F)V

    return-void
.end method

.method public bridge synthetic get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    check-cast p1, Lcom/google/android/material/progressindicator/l;

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/progressindicator/l$b;->a(Lcom/google/android/material/progressindicator/l;)Ljava/lang/Float;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    check-cast p1, Lcom/google/android/material/progressindicator/l;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    check-cast p2, Ljava/lang/Float;

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/progressindicator/l$b;->b(Lcom/google/android/material/progressindicator/l;Ljava/lang/Float;)V

    const/4 v1, 0x1

    return-void
.end method
