.class Lcom/google/android/material/progressindicator/m$a;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/progressindicator/m;->o()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/progressindicator/m;


# direct methods
.method constructor <init>(Lcom/google/android/material/progressindicator/m;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/progressindicator/m$a;->a:Lcom/google/android/material/progressindicator/m;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v0, 0x6

    move v1, v0

    return-void
.end method


# virtual methods
.method public onAnimationRepeat(Landroid/animation/Animator;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@fs @ ~i@o@rub1/~@c S y4@ i~@s @/@ @@. ~~~Mln -~@f ~to@o@b@obla@~ ~~ ~ ~@oim ~K v@ d~~~~@t~o~~~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationRepeat(Landroid/animation/Animator;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/material/progressindicator/m$a;->a:Lcom/google/android/material/progressindicator/m;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/google/android/material/progressindicator/m;->i(Lcom/google/android/material/progressindicator/m;)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    add-int/2addr v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/android/material/progressindicator/m$a;->a:Lcom/google/android/material/progressindicator/m;

    invoke-static {v2}, Lcom/google/android/material/progressindicator/m;->k(Lcom/google/android/material/progressindicator/m;)Lcom/google/android/material/progressindicator/b;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v2, v2, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    array-length v2, v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    rem-int/2addr v0, v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lcom/google/android/material/progressindicator/m;->j(Lcom/google/android/material/progressindicator/m;I)I

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/google/android/material/progressindicator/m$a;->a:Lcom/google/android/material/progressindicator/m;

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1, v1}, Lcom/google/android/material/progressindicator/m;->l(Lcom/google/android/material/progressindicator/m;Z)Z

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void
.end method
