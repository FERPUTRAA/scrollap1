.class public abstract Lcom/google/android/material/progressindicator/BaseProgressIndicator;
.super Landroid/widget/ProgressBar;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/progressindicator/BaseProgressIndicator$e;,
        Lcom/google/android/material/progressindicator/BaseProgressIndicator$f;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Lcom/google/android/material/progressindicator/b;",
        ">",
        "Landroid/widget/ProgressBar;"
    }
.end annotation


# static fields
.field public static final o:I = 0x0

.field public static final p:I = 0x1

.field public static final q:I = 0x2

.field public static final r:I = 0x0

.field public static final s:I = 0x1

.field public static final t:I = 0x2

.field static final u:I

.field static final v:F = 0.2f

.field static final w:I = 0xff

.field static final x:I = 0x3e8


# instance fields
.field a:Lcom/google/android/material/progressindicator/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TS;"
        }
    .end annotation
.end field

.field private b:I

.field private c:Z

.field private d:Z

.field private final e:I

.field private final f:I

.field private g:J

.field h:Lcom/google/android/material/progressindicator/a;

.field private i:Z

.field private j:I

.field private final k:Ljava/lang/Runnable;

.field private final l:Ljava/lang/Runnable;

.field private final m:Landroidx/vectordrawable/graphics/drawable/b$a;

.field private final n:Landroidx/vectordrawable/graphics/drawable/b$a;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_ProgressIndicator:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    sput v0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->u:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method protected constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    sget v0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->u:I

    const/4 v7, 0x5

    move v8, v7

    invoke-static {p1, p2, p3, v0}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    iput-wide v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->g:J

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/4 p1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->i:Z

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v0, 0x4

    const/4 v8, 0x4

    iput v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->j:I

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    new-instance v0, Lcom/google/android/material/progressindicator/BaseProgressIndicator$a;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {v0, p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator$a;-><init>(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    iput-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->k:Ljava/lang/Runnable;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    new-instance v0, Lcom/google/android/material/progressindicator/BaseProgressIndicator$b;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {v0, p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator$b;-><init>(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)V

    const/4 v7, 0x2

    move v8, v7

    iput-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->l:Ljava/lang/Runnable;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    new-instance v0, Lcom/google/android/material/progressindicator/BaseProgressIndicator$c;

    const/4 v8, 0x4

    invoke-direct {v0, p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator$c;-><init>(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    iput-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->m:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-instance v0, Lcom/google/android/material/progressindicator/BaseProgressIndicator$d;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {v0, p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator$d;-><init>(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    iput-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->n:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v8, 0x0

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p0, v1, p2}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->i(Landroid/content/Context;Landroid/util/AttributeSet;)Lcom/google/android/material/progressindicator/b;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    iput-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    sget-object v3, Lcom/google/android/material/R$styleable;->BaseProgressIndicator:[I

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    new-array v6, p1, [I

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    move v4, p3

    move v4, p3

    move v4, p3

    move v4, p3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    move v5, p4

    move v5, p4

    const/4 v8, 0x4

    move v5, p4

    move v5, p4

    const/4 v8, 0x5

    invoke-static/range {v1 .. v6}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    sget p2, Lcom/google/android/material/R$styleable;->BaseProgressIndicator_showDelay:I

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 p3, -0x1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {p1, p2, p3}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p2

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    iput p2, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->e:I

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    sget p2, Lcom/google/android/material/R$styleable;->BaseProgressIndicator_minHideDelay:I

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p1, p2, p3}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/16 p3, 0x3e8

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {p2, p3}, Ljava/lang/Math;->min(II)I

    move-result p2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    iput p2, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->f:I

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    new-instance p1, Lcom/google/android/material/progressindicator/a;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-direct {p1}, Lcom/google/android/material/progressindicator/a;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    iput-object p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->h:Lcom/google/android/material/progressindicator/a;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 p1, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->d:Z

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s/~d~S~~@nois@@ ~@~@M~4o@t~@ol @ b @@u @o~@- ~~~@1~ ~~~ @Kvrio~~@f@@bl@ac~ my  t@ / o  @b .i f"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->l()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic b(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->k()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic c(Lcom/google/android/material/progressindicator/BaseProgressIndicator;J)J
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->g:J

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-wide p1
.end method

.method static synthetic d(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)I
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget p0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic e(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    iget-boolean p0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->c:Z

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic f(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget-boolean p0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->i:Z

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic g(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)I
    .locals 2

    const/4 v1, 0x6

    iget p0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->j:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return p0
.end method

.method private getCurrentDrawingDelegate()Lcom/google/android/material/progressindicator/h;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/material/progressindicator/h<",
            "TS;>;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/widget/ProgressBar;->isIndeterminate()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/j;->A()Lcom/google/android/material/progressindicator/h;

    move-result-object v1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v1

    :cond_1
    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_1

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/f;->C()Lcom/google/android/material/progressindicator/h;

    move-result-object v1

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v1
.end method

.method private k()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getCurrentDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v0, Lcom/google/android/material/progressindicator/g;

    const/4 v4, 0x7

    const/4 v1, 0x0

    move v3, v1

    move v3, v1

    const/4 v4, 0x0

    const/4 v2, 0x1

    move v3, v2

    move v3, v2

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v1, v2}, Lcom/google/android/material/progressindicator/g;->v(ZZZ)Z

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->n()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v0, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void
.end method

.method private l()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->f:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-lez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->g:J

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method private n()Z
    .locals 3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    if-nez v0, :cond_1

    :cond_0
    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x6

    return v0
.end method

.method private o()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/j;->z()Lcom/google/android/material/progressindicator/i;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->m:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/material/progressindicator/i;->d(Landroidx/vectordrawable/graphics/drawable/b$a;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    iget-object v1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->n:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/google/android/material/progressindicator/f;->b(Landroidx/vectordrawable/graphics/drawable/b$a;)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->n:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/google/android/material/progressindicator/j;->b(Landroidx/vectordrawable/graphics/drawable/b$a;)V

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method private r()V
    .locals 4

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->n:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/progressindicator/j;->d(Landroidx/vectordrawable/graphics/drawable/b$a;)Z

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/j;->z()Lcom/google/android/material/progressindicator/i;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/i;->h()V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->n:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/material/progressindicator/f;->d(Landroidx/vectordrawable/graphics/drawable/b$a;)Z

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method public getCurrentDrawable()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/widget/ProgressBar;->isIndeterminate()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getHideAnimationBehavior()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->f:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public bridge synthetic getIndeterminateDrawable()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/material/progressindicator/j<",
            "TS;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-super {p0}, Landroid/widget/ProgressBar;->getIndeterminateDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/material/progressindicator/j;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public getIndicatorColor()[I
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, v0, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic getProgressDrawable()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public getProgressDrawable()Lcom/google/android/material/progressindicator/f;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/material/progressindicator/f<",
            "TS;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-super {p0}, Landroid/widget/ProgressBar;->getProgressDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/material/progressindicator/f;

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-object v0
.end method

.method public getShowAnimationBehavior()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->e:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public getTrackColor()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->d:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public getTrackCornerRadius()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->b:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public getTrackThickness()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method protected h(Z)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->d:Z

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getCurrentDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    check-cast v0, Lcom/google/android/material/progressindicator/g;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->s()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    move v4, v2

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v0, v1, v2, p1}, Lcom/google/android/material/progressindicator/g;->v(ZZZ)Z

    const/4 v3, 0x5

    or-int/2addr v4, v3

    return-void
.end method

.method abstract i(Landroid/content/Context;Landroid/util/AttributeSet;)Lcom/google/android/material/progressindicator/b;
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/util/AttributeSet;",
            ")TS;"
        }
    .end annotation
.end method

.method public invalidate()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-super {p0}, Landroid/widget/ProgressBar;->invalidate()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getCurrentDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v1, 0x6

    and-int/2addr v2, v1

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getCurrentDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public j()V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->k:Ljava/lang/Runnable;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-void

    :cond_0
    const/4 v6, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->l:Ljava/lang/Runnable;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-wide v2, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->g:J

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    sub-long/2addr v0, v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget v2, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->f:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    int-to-long v3, v2

    const/4 v7, 0x7

    cmp-long v3, v0, v3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-ltz v3, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x6

    if-eqz v3, :cond_2

    const/4 v6, 0x2

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->l:Ljava/lang/Runnable;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    return-void

    :cond_2
    const/4 v7, 0x5

    iget-object v3, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->l:Ljava/lang/Runnable;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    int-to-long v4, v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    sub-long/2addr v4, v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0, v3, v4, v5}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    return-void
.end method

.method m()Z
    .locals 5

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getWindowVisibility()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x6

    move v2, v1

    move v2, v1

    const/4 v4, 0x5

    move v2, v1

    move v2, v1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    return v2

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x0

    instance-of v2, v0, Landroid/view/View;

    const/4 v4, 0x0

    if-nez v2, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    return v1

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast v0, Landroid/view/View;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_0
.end method

.method protected onAttachedToWindow()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-super {p0}, Landroid/widget/ProgressBar;->onAttachedToWindow()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->o()V

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->s()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->l()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method protected onDetachedFromWindow()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->l:Ljava/lang/Runnable;

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->k:Ljava/lang/Runnable;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getCurrentDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast v0, Lcom/google/android/material/progressindicator/g;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/g;->l()Z

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->r()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-super {p0}, Landroid/widget/ProgressBar;->onDetachedFromWindow()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method protected declared-synchronized onDraw(Landroid/graphics/Canvas;)V
    .locals 7
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez v1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    if-eqz v1, :cond_1

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    int-to-float v1, v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    int-to-float v2, v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    :cond_1
    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-nez v1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eqz v1, :cond_3

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    add-int/2addr v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    sub-int/2addr v1, v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    add-int/2addr v3, v4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    sub-int/2addr v2, v3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1, v3, v3, v1, v2}, Landroid/graphics/Canvas;->clipRect(IIII)Z

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getCurrentDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v5, 0x6

    move v6, v5

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    monitor-exit p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    monitor-exit p0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    throw p1
.end method

.method protected declared-synchronized onMeasure(II)V
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-super {p0, p1, p2}, Landroid/widget/ProgressBar;->onMeasure(II)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getCurrentDrawingDelegate()Lcom/google/android/material/progressindicator/h;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v1, 0x5

    move v2, v1

    return-void

    :cond_0
    :try_start_1
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/h;->e()I

    move-result p2

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/h;->d()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-gez p2, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    add-int/2addr p2, v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    add-int/2addr p2, v0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-gez p1, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    goto :goto_1

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    add-int/2addr p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    add-int/2addr p1, v0

    :goto_1
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, p2, p1}, Landroid/view/View;->setMeasuredDimension(II)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    monitor-exit p0

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    throw p1
.end method

.method protected onVisibilityChanged(Landroid/view/View;I)V
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-super {p0, p1, p2}, Landroid/widget/ProgressBar;->onVisibilityChanged(Landroid/view/View;I)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    if-nez p2, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->h(Z)V

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method protected onWindowVisibilityChanged(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-super {p0, p1}, Landroid/widget/ProgressBar;->onWindowVisibilityChanged(I)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->h(Z)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public p(IZ)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/widget/ProgressBar;->isIndeterminate()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-boolean p2, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->c:Z

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x5

    or-int/2addr v2, v1

    iput-boolean p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->i:Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->h:Lcom/google/android/material/progressindicator/a;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Lcom/google/android/material/progressindicator/a;->a(Landroid/content/ContentResolver;)F

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p2, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    cmpl-float p1, p1, p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/j;->z()Lcom/google/android/material/progressindicator/i;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/i;->f()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->m:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1, p2}, Landroidx/vectordrawable/graphics/drawable/b$a;->b(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_1

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz p1, :cond_3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez p2, :cond_3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/f;->jumpToCurrentState()V

    :cond_3
    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public q()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->e:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-lez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->k:Ljava/lang/Runnable;

    const/4 v4, 0x1

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->k:Ljava/lang/Runnable;

    const/4 v3, 0x5

    move v4, v3

    iget v1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->e:I

    const/4 v3, 0x2

    move v4, v3

    int-to-long v1, v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->k:Ljava/lang/Runnable;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :goto_0
    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method

.method s()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0}, Landroidx/core/view/k1;->O0(Landroid/view/View;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getWindowVisibility()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->m()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public setAnimatorDurationScaleProvider(Lcom/google/android/material/progressindicator/a;)V
    .locals 3
    .param p1    # Lcom/google/android/material/progressindicator/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->h:Lcom/google/android/material/progressindicator/a;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p1, v0, Lcom/google/android/material/progressindicator/g;->c:Lcom/google/android/material/progressindicator/a;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object p1, v0, Lcom/google/android/material/progressindicator/g;->c:Lcom/google/android/material/progressindicator/a;

    :cond_1
    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public setHideAnimationBehavior(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x2

    iput p1, v0, Lcom/google/android/material/progressindicator/b;->f:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->invalidate()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public declared-synchronized setIndeterminate(Z)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/widget/ProgressBar;->isIndeterminate()Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-ne p1, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    monitor-exit p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :cond_0
    :try_start_1
    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getCurrentDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast v0, Lcom/google/android/material/progressindicator/g;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/g;->l()Z

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-super {p0, p1}, Landroid/widget/ProgressBar;->setIndeterminate(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getCurrentDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast p1, Lcom/google/android/material/progressindicator/g;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p1, :cond_2

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->s()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1, v1, v0, v0}, Lcom/google/android/material/progressindicator/g;->v(ZZZ)Z

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    instance-of v1, p1, Lcom/google/android/material/progressindicator/j;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->s()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast p1, Lcom/google/android/material/progressindicator/j;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/j;->z()Lcom/google/android/material/progressindicator/i;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/i;->g()V

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->i:Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    throw p1
.end method

.method public setIndeterminateDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x2

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroid/widget/ProgressBar;->setIndeterminateDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    instance-of v0, p1, Lcom/google/android/material/progressindicator/j;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/material/progressindicator/g;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/g;->l()Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-super {p0, p1}, Landroid/widget/ProgressBar;->setIndeterminateDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x0

    return-void

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string v0, "Cadmamwnroet eraderanweftrblsotan bi i .lederast naemwak"

    const-string v0, " as.bteetrdklai neanwwsrCm iafaortsader obnemrl eanedtwa"

    const/4 v2, 0x5

    const-string v0, " aCeo rniab  reeedea baondtra.wlarkdreilswttonm wafasetn"

    const-string v0, "Cannot set framework drawable as indeterminate drawable."

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    move v2, v1

    throw p1
.end method

.method public varargs setIndicatorColor([I)V
    .locals 4
    .param p1    # [I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    array-length v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget v0, Lcom/google/android/material/R$attr;->colorPrimary:I

    const/4 v2, 0x5

    or-int/2addr v3, v2

    const/4 v1, -0x3

    const/4 v1, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1, v0, v1}, Lcom/google/android/material/color/s;->b(Landroid/content/Context;II)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    filled-new-array {p1}, [I

    move-result-object p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndicatorColor()[I

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0, p1}, Ljava/util/Arrays;->equals([I[I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v0, :cond_1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object p1, v0, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/j;->z()Lcom/google/android/material/progressindicator/i;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/i;->c()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->invalidate()V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public declared-synchronized setProgress(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/widget/ProgressBar;->isIndeterminate()Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    :try_start_1
    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->p(IZ)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    throw p1
.end method

.method public setProgressDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-super {p0, p1}, Landroid/widget/ProgressBar;->setProgressDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    instance-of v0, p1, Lcom/google/android/material/progressindicator/f;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    check-cast p1, Lcom/google/android/material/progressindicator/f;

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/f;->l()Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-super {p0, p1}, Landroid/widget/ProgressBar;->setProgressDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/widget/ProgressBar;->getProgress()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    int-to-float v0, v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/widget/ProgressBar;->getMax()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    int-to-float v1, v1

    const/4 v3, 0x6

    div-float/2addr v0, v1

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Lcom/google/android/material/progressindicator/f;->H(F)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v0, "asoanbskrCwettme  dmnaorwfar.b l sargrbls ea peraod"

    const-string v0, ".etmdgkawamsbbel rrrs aopnaaowwaa doreCf r ssetl nr"

    const/4 v3, 0x4

    const-string/jumbo v0, "rarCaeuap weddkalmgbasws  blwns.setrrnfrae  t oroae"

    const-string v0, "Cannot set framework drawable as progress drawable."

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    throw p1
.end method

.method public setShowAnimationBehavior(I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x4

    const/4 v1, 0x2

    iput p1, v0, Lcom/google/android/material/progressindicator/b;->e:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->invalidate()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public setTrackColor(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, v0, Lcom/google/android/material/progressindicator/b;->d:I

    const/4 v3, 0x1

    if-eq v1, p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput p1, v0, Lcom/google/android/material/progressindicator/b;->d:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->invalidate()V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public setTrackCornerRadius(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v3, 0x4

    const/4 v2, 0x4

    iget v1, v0, Lcom/google/android/material/progressindicator/b;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eq v1, p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v1, v0, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    div-int/lit8 v1, v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p1, v1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput p1, v0, Lcom/google/android/material/progressindicator/b;->b:I

    :cond_0
    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method public setTrackThickness(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v1, v0, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eq v1, p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput p1, v0, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method public setVisibilityAfterHide(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eq p1, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/16 v0, 0x8

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-ne p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo v0, "osLBEimpB O/tnvipV ohinea , GE,ienw n ns eluIo  ftybIoi.EedSceLseITmb /io eIfNVSVndI dNt"

    const-string v0, "NVEbouin cebEaediLoiE/sIBeVO dI fdtoNn/s ni.  IlSB eV GoLmpnItToei Iniwe ,vesmyinf St ,h"

    const-string/jumbo v0, "ionSn  sqNfI eiVIt,TEi lnbs/Ns tiaIdieeO nIeI f,B/b i.dyG hVeLnomewv Vco  o imeEpSEdBuLt"

    const-string v0, "The component\'s visibility must be one of VISIBLE, INVISIBLE, and GONE defined in View."

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    throw p1

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->j:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method
