.class Lcom/google/android/material/progressindicator/m$b;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/progressindicator/m;->o()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/progressindicator/m;


# direct methods
.method constructor <init>(Lcom/google/android/material/progressindicator/m;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/google/android/material/progressindicator/m$b;->a:Lcom/google/android/material/progressindicator/m;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~si@ ~ ~~oi~   @~@s~-~@@   @ ~o~ ~tm@@@o~@@ 1o~bK f ~f~u@colnS  d/~bir~@oa~M4@y@@/b t@.@v@~~@l "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationEnd(Landroid/animation/Animator;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/google/android/material/progressindicator/m$b;->a:Lcom/google/android/material/progressindicator/m;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/m;->a()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/material/progressindicator/m$b;->a:Lcom/google/android/material/progressindicator/m;

    const/4 v2, 0x7

    iget-object v0, p1, Lcom/google/android/material/progressindicator/m;->k:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p1, p1, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/vectordrawable/graphics/drawable/b$a;->b(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method
