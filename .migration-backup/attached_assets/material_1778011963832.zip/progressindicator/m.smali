.class final Lcom/google/android/material/progressindicator/m;
.super Lcom/google/android/material/progressindicator/i;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/material/progressindicator/i<",
        "Landroid/animation/ObjectAnimator;",
        ">;"
    }
.end annotation


# static fields
.field private static final l:I = 0x708

.field private static final m:[I

.field private static final n:[I

.field private static final o:Landroid/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/Property<",
            "Lcom/google/android/material/progressindicator/m;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private d:Landroid/animation/ObjectAnimator;

.field private e:Landroid/animation/ObjectAnimator;

.field private final f:[Landroid/view/animation/Interpolator;

.field private final g:Lcom/google/android/material/progressindicator/b;

.field private h:I

.field private i:Z

.field private j:F

.field k:Landroidx/vectordrawable/graphics/drawable/b$a;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/16 v0, 0x352

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/16 v1, 0x2ee

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/16 v2, 0x215

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/16 v3, 0x237

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    sput-object v0, Lcom/google/android/material/progressindicator/m;->m:[I

    const/4 v4, 0x5

    move v5, v4

    const/16 v0, 0x14d

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/16 v2, 0x4f3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/16 v3, 0x3e8

    const/4 v5, 0x6

    const/4 v4, 0x3

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    sput-object v0, Lcom/google/android/material/progressindicator/m;->n:[I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v0, Lcom/google/android/material/progressindicator/m$c;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-class v1, Ljava/lang/Float;

    const-class v1, Ljava/lang/Float;

    const/4 v5, 0x4

    const-class v1, Ljava/lang/Float;

    const-class v1, Ljava/lang/Float;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const-string/jumbo v2, "itsmsicoaoinFratn"

    const-string/jumbo v2, "insiatcooatrianmF"

    const/4 v5, 0x7

    const-string/jumbo v2, "ntimoFianoamatcir"

    const-string v2, "animationFraction"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v0, v1, v2}, Lcom/google/android/material/progressindicator/m$c;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    sput-object v0, Lcom/google/android/material/progressindicator/m;->o:Landroid/util/Property;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/n;)V
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/progressindicator/n;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v0, 0x2

    const/4 v4, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/material/progressindicator/i;-><init>(I)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput v1, p0, Lcom/google/android/material/progressindicator/m;->h:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput-object v2, p0, Lcom/google/android/material/progressindicator/m;->k:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput-object p2, p0, Lcom/google/android/material/progressindicator/m;->g:Lcom/google/android/material/progressindicator/b;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 p2, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-array p2, p2, [Landroid/view/animation/Interpolator;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget v2, Lcom/google/android/material/R$animator;->linear_indeterminate_line1_head_interpolator:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p1, v2}, Landroidx/vectordrawable/graphics/drawable/d;->b(Landroid/content/Context;I)Landroid/view/animation/Interpolator;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x5

    aput-object v2, p2, v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    sget v1, Lcom/google/android/material/R$animator;->linear_indeterminate_line1_tail_interpolator:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p1, v1}, Landroidx/vectordrawable/graphics/drawable/d;->b(Landroid/content/Context;I)Landroid/view/animation/Interpolator;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    aput-object v1, p2, v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    sget v1, Lcom/google/android/material/R$animator;->linear_indeterminate_line2_head_interpolator:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1, v1}, Landroidx/vectordrawable/graphics/drawable/d;->b(Landroid/content/Context;I)Landroid/view/animation/Interpolator;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    aput-object v1, p2, v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget v0, Lcom/google/android/material/R$animator;->linear_indeterminate_line2_tail_interpolator:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1, v0}, Landroidx/vectordrawable/graphics/drawable/d;->b(Landroid/content/Context;I)Landroid/view/animation/Interpolator;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v0, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    aput-object p1, p2, v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object p2, p0, Lcom/google/android/material/progressindicator/m;->f:[Landroid/view/animation/Interpolator;

    return-void
.end method

.method static synthetic i(Lcom/google/android/material/progressindicator/m;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " i@oo~lv~o~@-~@~t @K ~~@d~~r~ o~ @@~ /o  @/@~t i@s fb4@~y~ ~ b@  nl@ ~@1i c.Su@o@o~~ ~f@@@a@b~M~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget p0, p0, Lcom/google/android/material/progressindicator/m;->h:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic j(Lcom/google/android/material/progressindicator/m;I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/progressindicator/m;->h:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic k(Lcom/google/android/material/progressindicator/m;)Lcom/google/android/material/progressindicator/b;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/android/material/progressindicator/m;->g:Lcom/google/android/material/progressindicator/b;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic l(Lcom/google/android/material/progressindicator/m;Z)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/progressindicator/m;->i:Z

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p1
.end method

.method static synthetic m(Lcom/google/android/material/progressindicator/m;)F
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/m;->n()F

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    return p0
.end method

.method private n()F
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/progressindicator/m;->j:F

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method private o()V
    .locals 9

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->d:Landroid/animation/ObjectAnimator;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v1, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-wide/16 v2, 0x708

    const-wide/16 v2, 0x708

    const/4 v8, 0x4

    const-wide/16 v2, 0x708

    const-wide/16 v2, 0x708

    if-nez v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    sget-object v0, Lcom/google/android/material/progressindicator/m;->o:Landroid/util/Property;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/4 v4, 0x2

    const/4 v8, 0x6

    const/4 v7, 0x7

    new-array v4, v4, [F

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    fill-array-data v4, :array_0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {p0, v0, v4}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    iput-object v0, p0, Lcom/google/android/material/progressindicator/m;->d:Landroid/animation/ObjectAnimator;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v0, v2, v3}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->d:Landroid/animation/ObjectAnimator;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->d:Landroid/animation/ObjectAnimator;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/4 v4, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v0, v4}, Landroid/animation/ValueAnimator;->setRepeatCount(I)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->d:Landroid/animation/ObjectAnimator;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    new-instance v4, Lcom/google/android/material/progressindicator/m$a;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-direct {v4, p0}, Lcom/google/android/material/progressindicator/m$a;-><init>(Lcom/google/android/material/progressindicator/m;)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v0, v4}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->e:Landroid/animation/ObjectAnimator;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    if-nez v0, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    sget-object v0, Lcom/google/android/material/progressindicator/m;->o:Landroid/util/Property;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v4, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-array v4, v4, [F

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v5, 0x0

    const/high16 v6, 0x3f800000    # 1.0f

    const/4 v7, 0x2

    shr-int/2addr v8, v7

    aput v6, v4, v5

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {p0, v0, v4}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    iput-object v0, p0, Lcom/google/android/material/progressindicator/m;->e:Landroid/animation/ObjectAnimator;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->e:Landroid/animation/ObjectAnimator;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v8, 0x5

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->e:Landroid/animation/ObjectAnimator;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-instance v1, Lcom/google/android/material/progressindicator/m$b;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {v1, p0}, Lcom/google/android/material/progressindicator/m$b;-><init>(Lcom/google/android/material/progressindicator/m;)V

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method private p()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/progressindicator/m;->i:Z

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/i;->c:[I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/material/progressindicator/m;->g:Lcom/google/android/material/progressindicator/b;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, v1, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget v2, p0, Lcom/google/android/material/progressindicator/m;->h:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    aget v1, v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v4, 0x3

    invoke-virtual {v2}, Lcom/google/android/material/progressindicator/j;->getAlpha()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v1, v2}, Lcom/google/android/material/color/s;->a(II)I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([II)V

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-boolean v0, p0, Lcom/google/android/material/progressindicator/m;->i:Z

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void
.end method

.method private s(I)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v1, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-ge v0, v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object v1, Lcom/google/android/material/progressindicator/m;->n:[I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    aget v1, v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget-object v2, Lcom/google/android/material/progressindicator/m;->m:[I

    const/4 v5, 0x1

    aget v2, v2, v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0, p1, v1, v2}, Lcom/google/android/material/progressindicator/i;->b(III)F

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/google/android/material/progressindicator/m;->f:[Landroid/view/animation/Interpolator;

    const/4 v5, 0x6

    aget-object v2, v2, v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {v2, v1}, Landroid/animation/TimeInterpolator;->getInterpolation(F)F

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v3, v1}, Ljava/lang/Math;->min(FF)F

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v3, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    aput v1, v2, v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->d:Landroid/animation/ObjectAnimator;

    const/4 v2, 0x7

    const/4 v1, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/animation/Animator;->cancel()V

    :cond_0
    const/4 v2, 0x7

    return-void
.end method

.method public c()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/m;->q()V

    const/4 v1, 0x4

    return-void
.end method

.method public d(Landroidx/vectordrawable/graphics/drawable/b$a;)V
    .locals 2
    .param p1    # Landroidx/vectordrawable/graphics/drawable/b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/progressindicator/m;->k:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public f()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->e:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/animation/Animator;->isRunning()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/m;->a()V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->e:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v1, 0x2

    const/4 v5, 0x0

    new-array v1, v1, [F

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x1

    iget v3, p0, Lcom/google/android/material/progressindicator/m;->j:F

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    aput v3, v1, v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    aput v3, v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroid/animation/ObjectAnimator;->setFloatValues([F)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->e:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget v1, p0, Lcom/google/android/material/progressindicator/m;->j:F

    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    sub-float/2addr v3, v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/high16 v1, 0x44e10000    # 1800.0f

    const/4 v5, 0x6

    const/4 v4, 0x7

    mul-float/2addr v3, v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    float-to-long v1, v3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->e:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/animation/ObjectAnimator;->start()V

    :cond_1
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-void
.end method

.method public g()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/m;->o()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/m;->q()V

    const/4 v1, 0x6

    or-int/2addr v2, v1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/m;->d:Landroid/animation/ObjectAnimator;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/animation/ObjectAnimator;->start()V

    const/4 v2, 0x4

    return-void
.end method

.method public h()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/progressindicator/m;->k:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v2, 0x4

    return-void
.end method

.method q()V
    .locals 5
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput v0, p0, Lcom/google/android/material/progressindicator/m;->h:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/android/material/progressindicator/m;->g:Lcom/google/android/material/progressindicator/b;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, v1, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    aget v1, v1, v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v2}, Lcom/google/android/material/progressindicator/j;->getAlpha()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-static {v1, v2}, Lcom/google/android/material/color/s;->a(II)I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/google/android/material/progressindicator/i;->c:[I

    const/4 v4, 0x3

    aput v1, v2, v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x3

    aput v1, v2, v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method r(F)V
    .locals 3
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/progressindicator/m;->j:F

    const/4 v1, 0x0

    move v2, v1

    const/high16 v0, 0x44e10000    # 1800.0f

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    mul-float/2addr p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    float-to-int p1, p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/progressindicator/m;->s(I)V

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/m;->p()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    return-void
.end method
