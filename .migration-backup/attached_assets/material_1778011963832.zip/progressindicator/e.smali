.class public final Lcom/google/android/material/progressindicator/e;
.super Lcom/google/android/material/progressindicator/b;


# instance fields
.field public g:I
    .annotation build Landroidx/annotation/u0;
    .end annotation
.end field

.field public h:I
    .annotation build Landroidx/annotation/u0;
    .end annotation
.end field

.field public i:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/R$attr;->circularProgressIndicatorStyle:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/progressindicator/e;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget v0, Lcom/google/android/material/progressindicator/CircularProgressIndicator;->y:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, p3, v0}, Lcom/google/android/material/progressindicator/e;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 11
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/android/material/progressindicator/b;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    sget v1, Lcom/google/android/material/R$dimen;->mtrl_progress_circular_size_medium:I

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v10, 0x4

    sget v2, Lcom/google/android/material/R$dimen;->mtrl_progress_circular_inset_medium:I

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x0

    sget-object v4, Lcom/google/android/material/R$styleable;->CircularProgressIndicator:[I

    const/4 v10, 0x4

    const/4 v8, 0x0

    const/4 v10, 0x1

    move v9, v8

    move v9, v8

    const/4 v10, 0x7

    new-array v7, v8, [I

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    move v5, p3

    move v5, p3

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    move v6, p4

    move v6, p4

    const/4 v10, 0x0

    move v6, p4

    move v6, p4

    const/4 v9, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static/range {v2 .. v7}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    sget p3, Lcom/google/android/material/R$styleable;->CircularProgressIndicator_indicatorSize:I

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-static {p1, p2, p3, v0}, Lcom/google/android/material/resources/c;->d(Landroid/content/Context;Landroid/content/res/TypedArray;II)I

    move-result p3

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget p4, p0, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    mul-int/lit8 p4, p4, 0x2

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {p3, p4}, Ljava/lang/Math;->max(II)I

    move-result p3

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    iput p3, p0, Lcom/google/android/material/progressindicator/e;->g:I

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    sget p3, Lcom/google/android/material/R$styleable;->CircularProgressIndicator_indicatorInset:I

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {p1, p2, p3, v1}, Lcom/google/android/material/resources/c;->d(Landroid/content/Context;Landroid/content/res/TypedArray;II)I

    move-result p1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    iput p1, p0, Lcom/google/android/material/progressindicator/e;->h:I

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    sget p1, Lcom/google/android/material/R$styleable;->CircularProgressIndicator_indicatorDirectionCircular:I

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p2, p1, v8}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p1

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    iput p1, p0, Lcom/google/android/material/progressindicator/e;->i:I

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/e;->e()V

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    return-void
.end method


# virtual methods
.method e()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    return-void
.end method
