.class abstract Lcom/google/android/material/progressindicator/g;
.super Landroid/graphics/drawable/Drawable;

# interfaces
.implements Landroidx/vectordrawable/graphics/drawable/b;


# static fields
.field private static final o:Z = false

.field private static final p:I = 0x1f4

.field private static final q:Landroid/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/Property<",
            "Lcom/google/android/material/progressindicator/g;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field final a:Landroid/content/Context;

.field final b:Lcom/google/android/material/progressindicator/b;

.field c:Lcom/google/android/material/progressindicator/a;

.field private d:Landroid/animation/ValueAnimator;

.field private e:Landroid/animation/ValueAnimator;

.field private f:Z

.field private g:Z

.field private h:F

.field private i:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/vectordrawable/graphics/drawable/b$a;",
            ">;"
        }
    .end annotation
.end field

.field private j:Landroidx/vectordrawable/graphics/drawable/b$a;

.field private k:Z

.field private l:F

.field final m:Landroid/graphics/Paint;

.field private n:I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance v0, Lcom/google/android/material/progressindicator/g$c;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-class v1, Ljava/lang/Float;

    const-class v1, Ljava/lang/Float;

    const/4 v4, 0x1

    const-class v1, Ljava/lang/Float;

    const-class v1, Ljava/lang/Float;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const-string/jumbo v2, "nrscrgwotFio"

    const-string/jumbo v2, "gtscwrrFioon"

    const/4 v4, 0x5

    const-string/jumbo v2, "rirmtFocwnao"

    const-string/jumbo v2, "growFraction"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0, v1, v2}, Lcom/google/android/material/progressindicator/g$c;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    sput-object v0, Lcom/google/android/material/progressindicator/g;->q:Landroid/util/Property;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/b;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/progressindicator/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance v0, Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/progressindicator/g;->m:Landroid/graphics/Paint;

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/material/progressindicator/g;->a:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/android/material/progressindicator/g;->b:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance p1, Lcom/google/android/material/progressindicator/a;

    const/4 v1, 0x4

    move v2, v1

    invoke-direct {p1}, Lcom/google/android/material/progressindicator/a;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/material/progressindicator/g;->c:Lcom/google/android/material/progressindicator/a;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/16 p1, 0xff

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/progressindicator/g;->setAlpha(I)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/progressindicator/g;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o~~mosc@~~-Ko@i@~@a @@~4Mo@iy@f~~~nb~ @lbo @t~ /   @d@or@@~v@ ~@t  @@S~f  l iu o ~ /~@~ ~~~~@b~."

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/g;->h()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic e(Lcom/google/android/material/progressindicator/g;ZZ)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-super {p0, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic f(Lcom/google/android/material/progressindicator/g;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/g;->g()V

    const/4 v1, 0x2

    return-void
.end method

.method private g()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->j:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, p0}, Landroidx/vectordrawable/graphics/drawable/b$a;->b(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-boolean v1, p0, Lcom/google/android/material/progressindicator/g;->k:Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast v1, Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v3, 0x2

    invoke-virtual {v1, p0}, Landroidx/vectordrawable/graphics/drawable/b$a;->b(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method private h()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->j:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Landroidx/vectordrawable/graphics/drawable/b$a;->c(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-boolean v1, p0, Lcom/google/android/material/progressindicator/g;->k:Z

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast v1, Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v1, p0}, Landroidx/vectordrawable/graphics/drawable/b$a;->c(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method private varargs i([Landroid/animation/ValueAnimator;)V
    .locals 6
    .param p1    # [Landroid/animation/ValueAnimator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/progressindicator/g;->k:Z

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-boolean v1, p0, Lcom/google/android/material/progressindicator/g;->k:Z

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    array-length v1, p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x1

    if-ge v2, v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    aget-object v3, p1, v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v3}, Landroid/animation/ValueAnimator;->end()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-boolean v0, p0, Lcom/google/android/material/progressindicator/g;->k:Z

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-void
.end method

.method private o()V
    .locals 7

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->d:Landroid/animation/ValueAnimator;

    const/4 v5, 0x4

    move v6, v5

    const-wide/16 v1, 0x1f4

    const-wide/16 v1, 0x1f4

    const/4 v6, 0x7

    const-wide/16 v1, 0x1f4

    const-wide/16 v1, 0x1f4

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v3, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-nez v0, :cond_0

    const/4 v6, 0x0

    sget-object v0, Lcom/google/android/material/progressindicator/g;->q:Landroid/util/Property;

    const/4 v6, 0x3

    new-array v4, v3, [F

    const/4 v6, 0x5

    fill-array-data v4, :array_0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p0, v0, v4}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    iput-object v0, p0, Lcom/google/android/material/progressindicator/g;->d:Landroid/animation/ValueAnimator;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->d:Landroid/animation/ValueAnimator;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    sget-object v4, Lcom/google/android/material/animation/a;->b:Landroid/animation/TimeInterpolator;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, v4}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->d:Landroid/animation/ValueAnimator;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/material/progressindicator/g;->u(Landroid/animation/ValueAnimator;)V

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->e:Landroid/animation/ValueAnimator;

    const/4 v5, 0x0

    and-int/2addr v6, v5

    if-nez v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    sget-object v0, Lcom/google/android/material/progressindicator/g;->q:Landroid/util/Property;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-array v3, v3, [F

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    fill-array-data v3, :array_1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {p0, v0, v3}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/google/android/material/progressindicator/g;->e:Landroid/animation/ValueAnimator;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/animation/ValueAnimator;->setDuration(J)Landroid/animation/ValueAnimator;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->e:Landroid/animation/ValueAnimator;

    const/4 v6, 0x2

    sget-object v1, Lcom/google/android/material/animation/a;->b:Landroid/animation/TimeInterpolator;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Landroid/animation/ValueAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->e:Landroid/animation/ValueAnimator;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/material/progressindicator/g;->q(Landroid/animation/ValueAnimator;)V

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-void

    nop

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data

    :array_1
    .array-data 4
        0x3f800000    # 1.0f
        0x0
    .end array-data
.end method

.method private q(Landroid/animation/ValueAnimator;)V
    .locals 3
    .param p1    # Landroid/animation/ValueAnimator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->e:Landroid/animation/ValueAnimator;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, " rraob nw tAn A duihusndr C.isneiiio nhrmmttmeieenare hnilatgtctoe"

    const-string/jumbo v0, "rh maruiteaee .e htC clttArgownriinntodi mmoit  Asadhusnhre innein"

    const/4 v2, 0x3

    const-string/jumbo v0, "r nraiuhtrthewlih niuetteasnertiegnmocdti e  mroh dnnoAACs iun. an"

    const-string v0, "Cannot set hideAnimator while the current hideAnimator is running."

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    throw p1

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/material/progressindicator/g;->e:Landroid/animation/ValueAnimator;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/progressindicator/g$b;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/google/android/material/progressindicator/g$b;-><init>(Lcom/google/android/material/progressindicator/g;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    return-void
.end method

.method private u(Landroid/animation/ValueAnimator;)V
    .locals 3
    .param p1    # Landroid/animation/ValueAnimator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->d:Landroid/animation/ValueAnimator;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x6

    move v2, v1

    const-string v0, "Cannot set showAnimator while the current showAnimator is running."

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    throw p1

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/material/progressindicator/g;->d:Landroid/animation/ValueAnimator;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/progressindicator/g$a;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Lcom/google/android/material/progressindicator/g$a;-><init>(Lcom/google/android/material/progressindicator/g;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public b(Landroidx/vectordrawable/graphics/drawable/b$a;)V
    .locals 3
    .param p1    # Landroidx/vectordrawable/graphics/drawable/b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public c()V
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    const/4 v2, 0x6

    return-void
.end method

.method public d(Landroidx/vectordrawable/graphics/drawable/b$a;)Z
    .locals 3
    .param p1    # Landroidx/vectordrawable/graphics/drawable/b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/material/progressindicator/g;->i:Ljava/util/List;

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    return p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p1
.end method

.method public getAlpha()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/progressindicator/g;->n:I

    const/4 v1, 0x1

    const/4 v1, 0x6

    return v0
.end method

.method public getOpacity()I
    .locals 3

    const/4 v2, 0x4

    const/4 v0, -0x7

    const/4 v2, 0x3

    const/4 v0, -0x3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public isRunning()Z
    .locals 3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/g;->n()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/g;->m()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    move v2, v1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x1

    :goto_1
    const/4 v1, 0x0

    move v2, v1

    return v0
.end method

.method j()F
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->b:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/b;->b()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->b:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/b;->a()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/progressindicator/g;->g:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_2

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/progressindicator/g;->f:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/progressindicator/g;->l:F

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0

    :cond_2
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/progressindicator/g;->h:F

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method k()Landroid/animation/ValueAnimator;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->e:Landroid/animation/ValueAnimator;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public l()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, v0, v0, v0}, Lcom/google/android/material/progressindicator/g;->v(ZZZ)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public m()Z
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->e:Landroid/animation/ValueAnimator;

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-nez v0, :cond_1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/progressindicator/g;->g:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_2

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    move v2, v1

    goto :goto_0

    :cond_2
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public n()Z
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->d:Landroid/animation/ValueAnimator;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-nez v0, :cond_1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/progressindicator/g;->f:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    if-eqz v0, :cond_2

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    or-int/2addr v2, v1

    goto :goto_0

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method p(F)V
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/progressindicator/g;->l:F

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    cmpl-float v0, v0, p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/material/progressindicator/g;->l:F

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method r(Landroidx/vectordrawable/graphics/drawable/b$a;)V
    .locals 2
    .param p1    # Landroidx/vectordrawable/graphics/drawable/b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/progressindicator/g;->j:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method s(ZF)V
    .locals 2
    .param p2    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/progressindicator/g;->g:Z

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p2, p0, Lcom/google/android/material/progressindicator/g;->h:F

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public setAlpha(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/progressindicator/g;->n:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v1, 0x2

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 3
    .param p1    # Landroid/graphics/ColorFilter;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->m:Landroid/graphics/Paint;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public setVisible(ZZ)Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/android/material/progressindicator/g;->v(ZZZ)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p1
.end method

.method public start()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v0, v1}, Lcom/google/android/material/progressindicator/g;->w(ZZZ)Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method public stop()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v0, v1, v0}, Lcom/google/android/material/progressindicator/g;->w(ZZZ)Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method t(ZF)V
    .locals 2
    .param p2    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/progressindicator/g;->f:Z

    const/4 v1, 0x4

    iput p2, p0, Lcom/google/android/material/progressindicator/g;->h:F

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public v(ZZZ)Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->c:Lcom/google/android/material/progressindicator/a;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/progressindicator/g;->a:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/material/progressindicator/a;->a(Landroid/content/ContentResolver;)F

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz p3, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p3, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    cmpl-float p3, v0, p3

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-lez p3, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 p3, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p3, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/progressindicator/g;->w(ZZZ)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return p1
.end method

.method w(ZZZ)Z
    .locals 5

    const/4 v3, 0x1

    move v4, v3

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/g;->o()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x2

    and-int/2addr v4, v3

    if-nez p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    return v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz p1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->d:Landroid/animation/ValueAnimator;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->e:Landroid/animation/ValueAnimator;

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez p3, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz p2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->end()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-array p2, v2, [Landroid/animation/ValueAnimator;

    const/4 v4, 0x6

    const/4 v3, 0x7

    aput-object v0, p2, v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p0, p2}, Lcom/google/android/material/progressindicator/g;->i([Landroid/animation/ValueAnimator;)V

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-super {p0, p1, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    return p1

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz p3, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->isRunning()Z

    move-result p3

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz p3, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    return v1

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz p1, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-super {p0, p1, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    move-result p3

    const/4 v4, 0x7

    const/4 v3, 0x2

    if-eqz p3, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x7

    goto :goto_2

    :cond_5
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    move p3, v1

    const/4 v4, 0x7

    move p3, v1

    move p3, v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_3

    :cond_6
    :goto_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    move p3, v2

    :goto_3
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz p1, :cond_7

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/google/android/material/progressindicator/g;->b:Lcom/google/android/material/progressindicator/b;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/b;->b()Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_4

    :cond_7
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/material/progressindicator/g;->b:Lcom/google/android/material/progressindicator/b;

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/b;->a()Z

    move-result p1

    :goto_4
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-nez p1, :cond_8

    const/4 v4, 0x7

    new-array p1, v2, [Landroid/animation/ValueAnimator;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    aput-object v0, p1, v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/progressindicator/g;->i([Landroid/animation/ValueAnimator;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    return p3

    :cond_8
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez p2, :cond_a

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/animation/Animator;->isPaused()Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez p1, :cond_9

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_5

    :cond_9
    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->resume()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_6

    :cond_a
    :goto_5
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->start()V

    :goto_6
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    return p3
.end method
