.class final Lcom/google/android/material/progressindicator/k;
.super Lcom/google/android/material/progressindicator/h;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/material/progressindicator/h<",
        "Lcom/google/android/material/progressindicator/n;",
        ">;"
    }
.end annotation


# instance fields
.field private c:F

.field private d:F

.field private e:F


# direct methods
.method public constructor <init>(Lcom/google/android/material/progressindicator/n;)V
    .locals 2
    .param p1    # Lcom/google/android/material/progressindicator/n;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/progressindicator/h;-><init>(Lcom/google/android/material/progressindicator/b;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/high16 p1, 0x43960000    # 300.0f

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/progressindicator/k;->c:F

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Landroid/graphics/Canvas;F)V
    .locals 9
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~~sv4@~~~~ @ol~~@i~~~~@@~@Muia n~t@y s~@@~ b  @-bSf ~   . i@ @ b @c~@ /oo@1f~odoo@ r~@ @@mK@~~/l"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x5

    invoke-virtual {p1}, Landroid/graphics/Canvas;->getClipBounds()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    int-to-float v1, v1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    iput v1, p0, Lcom/google/android/material/progressindicator/k;->c:F

    const/4 v8, 0x1

    iget-object v1, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    check-cast v1, Lcom/google/android/material/progressindicator/n;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget v1, v1, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    int-to-float v1, v1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget v2, v0, Landroid/graphics/Rect;->left:I

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    int-to-float v2, v2

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v3

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    int-to-float v3, v3

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/high16 v4, 0x40000000    # 2.0f

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    div-float/2addr v3, v4

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    add-float/2addr v2, v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget v3, v0, Landroid/graphics/Rect;->top:I

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    int-to-float v3, v3

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    int-to-float v5, v5

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    div-float/2addr v5, v4

    const/4 v8, 0x3

    add-float/2addr v3, v5

    const/4 v7, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object v5, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    check-cast v5, Lcom/google/android/material/progressindicator/n;

    const/4 v8, 0x1

    iget v5, v5, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v8, 0x6

    sub-int/2addr v0, v5

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    int-to-float v0, v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    div-float/2addr v0, v4

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v5, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v5, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    add-float/2addr v3, v0

    const/4 v8, 0x6

    const/4 v7, 0x5

    invoke-virtual {p1, v2, v3}, Landroid/graphics/Canvas;->translate(FF)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-boolean v0, v0, Lcom/google/android/material/progressindicator/n;->i:Z

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/high16 v2, -0x40800000    # -1.0f

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-eqz v0, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p1, v2, v3}, Landroid/graphics/Canvas;->scale(FF)V

    :cond_0
    const/4 v8, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->b:Lcom/google/android/material/progressindicator/g;

    const/4 v8, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/g;->n()Z

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz v0, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->e:I

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eq v0, v6, :cond_2

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->b:Lcom/google/android/material/progressindicator/g;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/g;->m()Z

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eqz v0, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v8, 0x2

    const/4 v7, 0x4

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->f:I

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v6, 0x2

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-ne v0, v6, :cond_3

    :cond_2
    const/4 v7, 0x2

    invoke-virtual {p1, v3, v2}, Landroid/graphics/Canvas;->scale(FF)V

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->b:Lcom/google/android/material/progressindicator/g;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/g;->n()Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-nez v0, :cond_4

    const/4 v8, 0x3

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->b:Lcom/google/android/material/progressindicator/g;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/g;->m()Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-eqz v0, :cond_5

    :cond_4
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    int-to-float v0, v0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    sub-float v2, p2, v3

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    mul-float/2addr v0, v2

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    div-float/2addr v0, v4

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p1, v5, v0}, Landroid/graphics/Canvas;->translate(FF)V

    :cond_5
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget v0, p0, Lcom/google/android/material/progressindicator/k;->c:F

    const/4 v8, 0x7

    neg-float v2, v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    div-float/2addr v2, v4

    const/4 v7, 0x1

    move v8, v7

    neg-float v3, v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    div-float/2addr v3, v4

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    div-float/2addr v0, v4

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    div-float/2addr v1, v4

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p1, v2, v3, v0, v1}, Landroid/graphics/Canvas;->clipRect(FFFF)Z

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget-object p1, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    int-to-float v0, v0

    const/4 v8, 0x0

    mul-float/2addr v0, p2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    iput v0, p0, Lcom/google/android/material/progressindicator/k;->d:F

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    check-cast p1, Lcom/google/android/material/progressindicator/n;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget p1, p1, Lcom/google/android/material/progressindicator/b;->b:I

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    int-to-float p1, p1

    const/4 v8, 0x1

    const/4 v7, 0x0

    mul-float/2addr p1, p2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    iput p1, p0, Lcom/google/android/material/progressindicator/k;->e:F

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    return-void
.end method

.method public b(Landroid/graphics/Canvas;Landroid/graphics/Paint;FFI)V
    .locals 7
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Paint;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p4    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p5    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    cmpl-float v0, p3, p4

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-nez v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget v0, p0, Lcom/google/android/material/progressindicator/k;->c:F

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    neg-float v1, v0

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v6, 0x4

    div-float/2addr v1, v2

    const/4 v6, 0x1

    iget v3, p0, Lcom/google/android/material/progressindicator/k;->e:F

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    mul-float v4, v3, v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    sub-float v4, v0, v4

    const/4 v5, 0x6

    and-int/2addr v6, v5

    mul-float/2addr p3, v4

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    add-float/2addr v1, p3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    neg-float p3, v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    div-float/2addr p3, v2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    mul-float v4, v3, v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    sub-float/2addr v0, v4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    mul-float/2addr p4, v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    add-float/2addr p3, p4

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    mul-float/2addr v3, v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    add-float/2addr p3, v3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    sget-object p4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    const/4 v6, 0x7

    invoke-virtual {p2, p4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 p4, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p2, p4}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p2, p5}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-instance p4, Landroid/graphics/RectF;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget p5, p0, Lcom/google/android/material/progressindicator/k;->d:F

    const/4 v5, 0x3

    const/4 v5, 0x7

    neg-float v0, p5

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    div-float/2addr v0, v2

    const/4 v5, 0x2

    const/4 v5, 0x0

    div-float/2addr p5, v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-direct {p4, v1, v0, p3, p5}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget p3, p0, Lcom/google/android/material/progressindicator/k;->e:F

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p1, p4, p3, p3, p2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    return-void
.end method

.method c(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V
    .locals 8
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Paint;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->d:I

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/google/android/material/progressindicator/h;->b:Lcom/google/android/material/progressindicator/g;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v1}, Lcom/google/android/material/progressindicator/g;->getAlpha()I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    invoke-static {v0, v1}, Lcom/google/android/material/color/s;->a(II)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v1, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v0, Landroid/graphics/RectF;

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget v1, p0, Lcom/google/android/material/progressindicator/k;->c:F

    const/4 v6, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    neg-float v2, v1

    const/4 v7, 0x4

    const/high16 v3, 0x40000000    # 2.0f

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    div-float/2addr v2, v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget v4, p0, Lcom/google/android/material/progressindicator/k;->d:F

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    neg-float v5, v4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    div-float/2addr v5, v3

    const/4 v6, 0x3

    shr-int/2addr v7, v6

    div-float/2addr v1, v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    div-float/2addr v4, v3

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v0, v2, v5, v1, v4}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v7, 0x0

    iget v1, p0, Lcom/google/android/material/progressindicator/k;->e:F

    const/4 v6, 0x2

    move v7, v6

    invoke-virtual {p1, v0, v1, v1, p2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    return-void
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x5

    const/4 v1, 0x2

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public e()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method
