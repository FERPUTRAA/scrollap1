.class Lcom/google/android/material/progressindicator/BaseProgressIndicator$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/progressindicator/BaseProgressIndicator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/progressindicator/BaseProgressIndicator;


# direct methods
.method constructor <init>(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator$b;->a:Lcom/google/android/material/progressindicator/BaseProgressIndicator;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "/os@4i~@ @@~ -  @bf/m  r@@~@~.~~ ~~~~o@@1@~s  u ~~y~o~~ MvKdi@ool@~~@ nbo@@l  @~@ticft@S~~~ a@  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator$b;->a:Lcom/google/android/material/progressindicator/BaseProgressIndicator;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->b(Lcom/google/android/material/progressindicator/BaseProgressIndicator;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator$b;->a:Lcom/google/android/material/progressindicator/BaseProgressIndicator;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x0

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v0, v1, v2}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->c(Lcom/google/android/material/progressindicator/BaseProgressIndicator;J)J

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method
