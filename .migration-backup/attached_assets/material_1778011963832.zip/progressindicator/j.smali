.class public final Lcom/google/android/material/progressindicator/j;
.super Lcom/google/android/material/progressindicator/g;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Lcom/google/android/material/progressindicator/b;",
        ">",
        "Lcom/google/android/material/progressindicator/g;"
    }
.end annotation


# instance fields
.field private r:Lcom/google/android/material/progressindicator/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/progressindicator/h<",
            "TS;>;"
        }
    .end annotation
.end field

.field private s:Lcom/google/android/material/progressindicator/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/progressindicator/i<",
            "Landroid/animation/ObjectAnimator;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/b;Lcom/google/android/material/progressindicator/h;Lcom/google/android/material/progressindicator/i;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/progressindicator/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/progressindicator/h;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Lcom/google/android/material/progressindicator/i;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/google/android/material/progressindicator/b;",
            "Lcom/google/android/material/progressindicator/h<",
            "TS;>;",
            "Lcom/google/android/material/progressindicator/i<",
            "Landroid/animation/ObjectAnimator;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x0

    move v1, v0

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/progressindicator/g;-><init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/b;)V

    const/4 v0, 0x4

    invoke-virtual {p0, p3}, Lcom/google/android/material/progressindicator/j;->C(Lcom/google/android/material/progressindicator/h;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0, p4}, Lcom/google/android/material/progressindicator/j;->B(Lcom/google/android/material/progressindicator/i;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public static x(Landroid/content/Context;Lcom/google/android/material/progressindicator/e;)Lcom/google/android/material/progressindicator/j;
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/material/progressindicator/e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/google/android/material/progressindicator/e;",
            ")",
            "Lcom/google/android/material/progressindicator/j<",
            "Lcom/google/android/material/progressindicator/e;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v0, Lcom/google/android/material/progressindicator/j;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v1, Lcom/google/android/material/progressindicator/c;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v1, p1}, Lcom/google/android/material/progressindicator/c;-><init>(Lcom/google/android/material/progressindicator/e;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v2, Lcom/google/android/material/progressindicator/d;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v2, p1}, Lcom/google/android/material/progressindicator/d;-><init>(Lcom/google/android/material/progressindicator/e;)V

    const/4 v4, 0x3

    invoke-direct {v0, p0, p1, v1, v2}, Lcom/google/android/material/progressindicator/j;-><init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/b;Lcom/google/android/material/progressindicator/h;Lcom/google/android/material/progressindicator/i;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object v0
.end method

.method public static y(Landroid/content/Context;Lcom/google/android/material/progressindicator/n;)Lcom/google/android/material/progressindicator/j;
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/material/progressindicator/n;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/google/android/material/progressindicator/n;",
            ")",
            "Lcom/google/android/material/progressindicator/j<",
            "Lcom/google/android/material/progressindicator/n;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v0, Lcom/google/android/material/progressindicator/j;

    const/4 v4, 0x1

    new-instance v1, Lcom/google/android/material/progressindicator/k;

    const/4 v3, 0x1

    or-int/2addr v4, v3

    invoke-direct {v1, p1}, Lcom/google/android/material/progressindicator/k;-><init>(Lcom/google/android/material/progressindicator/n;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v2, p1, Lcom/google/android/material/progressindicator/n;->g:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-nez v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v2, Lcom/google/android/material/progressindicator/l;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v2, p1}, Lcom/google/android/material/progressindicator/l;-><init>(Lcom/google/android/material/progressindicator/n;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v2, Lcom/google/android/material/progressindicator/m;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v2, p0, p1}, Lcom/google/android/material/progressindicator/m;-><init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/n;)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v0, p0, p1, v1, v2}, Lcom/google/android/material/progressindicator/j;-><init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/b;Lcom/google/android/material/progressindicator/h;Lcom/google/android/material/progressindicator/i;)V

    const/4 v3, 0x1

    move v4, v3

    return-object v0
.end method


# virtual methods
.method A()Lcom/google/android/material/progressindicator/h;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/material/progressindicator/h<",
            "TS;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/j;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v2, 0x0

    return-object v0
.end method

.method B(Lcom/google/android/material/progressindicator/i;)V
    .locals 2
    .param p1    # Lcom/google/android/material/progressindicator/i;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/progressindicator/i<",
            "Landroid/animation/ObjectAnimator;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/progressindicator/j;->s:Lcom/google/android/material/progressindicator/i;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p1, p0}, Lcom/google/android/material/progressindicator/i;->e(Lcom/google/android/material/progressindicator/j;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method C(Lcom/google/android/material/progressindicator/h;)V
    .locals 2
    .param p1    # Lcom/google/android/material/progressindicator/h;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/progressindicator/h<",
            "TS;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/progressindicator/j;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p1, p0}, Lcom/google/android/material/progressindicator/h;->f(Lcom/google/android/material/progressindicator/g;)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public bridge synthetic b(Landroidx/vectordrawable/graphics/drawable/b$a;)V
    .locals 2
    .param p1    # Landroidx/vectordrawable/graphics/drawable/b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/android/material/progressindicator/g;->b(Landroidx/vectordrawable/graphics/drawable/b$a;)V

    const/4 v1, 0x0

    return-void
.end method

.method public bridge synthetic c()V
    .locals 2

    const/4 v1, 0x0

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->c()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public bridge synthetic d(Landroidx/vectordrawable/graphics/drawable/b$a;)Z
    .locals 2
    .param p1    # Landroidx/vectordrawable/graphics/drawable/b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x3

    move v1, v0

    invoke-super {p0, p1}, Lcom/google/android/material/progressindicator/g;->d(Landroidx/vectordrawable/graphics/drawable/b$a;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    return p1
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 12
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    new-instance v0, Landroid/graphics/Rect;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v1}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v1

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-nez v1, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-eqz v1, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->getClipBounds(Landroid/graphics/Rect;)Z

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-nez v0, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    goto :goto_1

    :cond_0
    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/j;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/g;->j()F

    move-result v1

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v0, p1, v1}, Lcom/google/android/material/progressindicator/h;->g(Landroid/graphics/Canvas;F)V

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/j;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    iget-object v1, p0, Lcom/google/android/material/progressindicator/g;->m:Landroid/graphics/Paint;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v0, p1, v1}, Lcom/google/android/material/progressindicator/h;->c(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    iget-object v1, p0, Lcom/google/android/material/progressindicator/j;->s:Lcom/google/android/material/progressindicator/i;

    const/4 v11, 0x2

    iget-object v2, v1, Lcom/google/android/material/progressindicator/i;->c:[I

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    array-length v3, v2

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-ge v0, v3, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    iget-object v4, p0, Lcom/google/android/material/progressindicator/j;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget-object v6, p0, Lcom/google/android/material/progressindicator/g;->m:Landroid/graphics/Paint;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    iget-object v1, v1, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x1

    mul-int/lit8 v3, v0, 0x2

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    aget v7, v1, v3

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x7

    aget v8, v1, v3

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    aget v9, v2, v0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual/range {v4 .. v9}, Lcom/google/android/material/progressindicator/h;->b(Landroid/graphics/Canvas;Landroid/graphics/Paint;FFI)V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    goto :goto_0

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    :cond_2
    :goto_1
    const/4 v11, 0x3

    return-void
.end method

.method public bridge synthetic getAlpha()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->getAlpha()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public getIntrinsicHeight()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/j;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/h;->d()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method public getIntrinsicWidth()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/progressindicator/j;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/h;->e()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public bridge synthetic getOpacity()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->getOpacity()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public bridge synthetic isRunning()Z
    .locals 3

    const/4 v2, 0x5

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->isRunning()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public bridge synthetic l()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->l()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public bridge synthetic m()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->m()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public bridge synthetic n()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->n()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public bridge synthetic setAlpha(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-super {p0, p1}, Lcom/google/android/material/progressindicator/g;->setAlpha(I)V

    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public bridge synthetic setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 2
    .param p1    # Landroid/graphics/ColorFilter;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/android/material/progressindicator/g;->setColorFilter(Landroid/graphics/ColorFilter;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public bridge synthetic setVisible(ZZ)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-super {p0, p1, p2}, Lcom/google/android/material/progressindicator/g;->setVisible(ZZ)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return p1
.end method

.method public bridge synthetic start()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->start()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public bridge synthetic stop()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->stop()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public bridge synthetic v(ZZZ)Z
    .locals 2

    const/4 v1, 0x2

    invoke-super {p0, p1, p2, p3}, Lcom/google/android/material/progressindicator/g;->v(ZZZ)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return p1
.end method

.method w(ZZZ)Z
    .locals 4

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-super {p0, p1, p2, p3}, Lcom/google/android/material/progressindicator/g;->w(ZZZ)Z

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/j;->isRunning()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/j;->s:Lcom/google/android/material/progressindicator/i;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/i;->a()V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->c:Lcom/google/android/material/progressindicator/a;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/progressindicator/g;->a:Landroid/content/Context;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/google/android/material/progressindicator/a;->a(Landroid/content/ContentResolver;)F

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p1, :cond_2

    const/4 v3, 0x4

    if-nez p3, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/android/material/progressindicator/j;->s:Lcom/google/android/material/progressindicator/i;

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/i;->g()V

    :cond_2
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return p2
.end method

.method z()Lcom/google/android/material/progressindicator/i;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/material/progressindicator/i<",
            "Landroid/animation/ObjectAnimator;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/j;->s:Lcom/google/android/material/progressindicator/i;

    const/4 v2, 0x3

    return-object v0
.end method
