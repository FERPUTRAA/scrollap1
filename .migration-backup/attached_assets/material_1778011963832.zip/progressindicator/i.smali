.class abstract Lcom/google/android/material/progressindicator/i;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Landroid/animation/Animator;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field protected a:Lcom/google/android/material/progressindicator/j;

.field protected final b:[F

.field protected final c:[I


# direct methods
.method protected constructor <init>(I)V
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    mul-int/lit8 v0, p1, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-array v0, v0, [F

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v2, 0x4

    const/4 v1, 0x6

    new-array p1, p1, [I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/material/progressindicator/i;->c:[I

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method abstract a()V
.end method

.method protected b(III)F
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~si@~ /~~ ~t  @ ~~rcy@od~ @@f ~@ oan@l@fo@~vo~-o@~o~@~KM. sS~~@i ~bi 1u ~tb@lm@~4@@~~ @ @b~ /@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    sub-int/2addr p1, p2

    const/4 v0, 0x0

    move v1, v0

    int-to-float p1, p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    int-to-float p2, p3

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    div-float/2addr p1, p2

    const/4 v1, 0x2

    const/4 v0, 0x2

    return p1
.end method

.method public abstract c()V
.end method

.method public abstract d(Landroidx/vectordrawable/graphics/drawable/b$a;)V
    .param p1    # Landroidx/vectordrawable/graphics/drawable/b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method protected e(Lcom/google/android/material/progressindicator/j;)V
    .locals 2
    .param p1    # Lcom/google/android/material/progressindicator/j;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method abstract f()V
.end method

.method abstract g()V
.end method

.method public abstract h()V
.end method
