.class public final Lcom/google/android/material/progressindicator/f;
.super Lcom/google/android/material/progressindicator/g;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<S:",
        "Lcom/google/android/material/progressindicator/b;",
        ">",
        "Lcom/google/android/material/progressindicator/g;"
    }
.end annotation


# static fields
.field private static final w:I = 0x2710

.field private static final x:F = 50.0f

.field private static final y:Landroidx/dynamicanimation/animation/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/dynamicanimation/animation/g<",
            "Lcom/google/android/material/progressindicator/f;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private r:Lcom/google/android/material/progressindicator/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/progressindicator/h<",
            "TS;>;"
        }
    .end annotation
.end field

.field private final s:Landroidx/dynamicanimation/animation/k;

.field private final t:Landroidx/dynamicanimation/animation/j;

.field private u:F

.field private v:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/material/progressindicator/f$a;

    const/4 v2, 0x2

    move v3, v2

    const-string v1, "edsavonrlcLiie"

    const/4 v3, 0x5

    const-string/jumbo v1, "icsnedroelaiLt"

    const-string/jumbo v1, "indicatorLevel"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/google/android/material/progressindicator/f$a;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    sput-object v0, Lcom/google/android/material/progressindicator/f;->y:Landroidx/dynamicanimation/animation/g;

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/b;Lcom/google/android/material/progressindicator/h;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/progressindicator/b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/progressindicator/h;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/google/android/material/progressindicator/b;",
            "Lcom/google/android/material/progressindicator/h<",
            "TS;>;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/progressindicator/g;-><init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/b;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/progressindicator/f;->v:Z

    const/4 v2, 0x2

    invoke-virtual {p0, p3}, Lcom/google/android/material/progressindicator/f;->F(Lcom/google/android/material/progressindicator/h;)V

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    new-instance p1, Landroidx/dynamicanimation/animation/k;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p1}, Landroidx/dynamicanimation/animation/k;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/material/progressindicator/f;->s:Landroidx/dynamicanimation/animation/k;

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/high16 p2, 0x3f800000    # 1.0f

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1, p2}, Landroidx/dynamicanimation/animation/k;->g(F)Landroidx/dynamicanimation/animation/k;

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/high16 p3, 0x42480000    # 50.0f

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    invoke-virtual {p1, p3}, Landroidx/dynamicanimation/animation/k;->i(F)Landroidx/dynamicanimation/animation/k;

    const/4 v2, 0x5

    const/4 v1, 0x4

    new-instance p3, Landroidx/dynamicanimation/animation/j;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/material/progressindicator/f;->y:Landroidx/dynamicanimation/animation/g;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p3, p0, v0}, Landroidx/dynamicanimation/animation/j;-><init>(Ljava/lang/Object;Landroidx/dynamicanimation/animation/g;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p3, p0, Lcom/google/android/material/progressindicator/f;->t:Landroidx/dynamicanimation/animation/j;

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-virtual {p3, p1}, Landroidx/dynamicanimation/animation/j;->D(Landroidx/dynamicanimation/animation/k;)Landroidx/dynamicanimation/animation/j;

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p2}, Lcom/google/android/material/progressindicator/g;->p(F)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public static A(Landroid/content/Context;Lcom/google/android/material/progressindicator/e;)Lcom/google/android/material/progressindicator/f;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/material/progressindicator/e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/google/android/material/progressindicator/e;",
            ")",
            "Lcom/google/android/material/progressindicator/f<",
            "Lcom/google/android/material/progressindicator/e;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/material/progressindicator/f;

    const/4 v2, 0x5

    and-int/2addr v3, v2

    new-instance v1, Lcom/google/android/material/progressindicator/c;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v1, p1}, Lcom/google/android/material/progressindicator/c;-><init>(Lcom/google/android/material/progressindicator/e;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, p0, p1, v1}, Lcom/google/android/material/progressindicator/f;-><init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/b;Lcom/google/android/material/progressindicator/h;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0
.end method

.method public static B(Landroid/content/Context;Lcom/google/android/material/progressindicator/n;)Lcom/google/android/material/progressindicator/f;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/material/progressindicator/n;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/google/android/material/progressindicator/n;",
            ")",
            "Lcom/google/android/material/progressindicator/f<",
            "Lcom/google/android/material/progressindicator/n;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/material/progressindicator/f;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v1, Lcom/google/android/material/progressindicator/k;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v1, p1}, Lcom/google/android/material/progressindicator/k;-><init>(Lcom/google/android/material/progressindicator/n;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, p0, p1, v1}, Lcom/google/android/material/progressindicator/f;-><init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/b;Lcom/google/android/material/progressindicator/h;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0
.end method

.method private D()F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/progressindicator/f;->u:F

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method private G(F)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/progressindicator/f;->u:F

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic x(Lcom/google/android/material/progressindicator/f;)F
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/f;->D()F

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic y(Lcom/google/android/material/progressindicator/f;F)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/progressindicator/f;->G(F)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method C()Lcom/google/android/material/progressindicator/h;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/android/material/progressindicator/h<",
            "TS;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/f;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public E(Landroidx/dynamicanimation/animation/b$q;)V
    .locals 3
    .param p1    # Landroidx/dynamicanimation/animation/b$q;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/f;->t:Landroidx/dynamicanimation/animation/j;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroidx/dynamicanimation/animation/b;->l(Landroidx/dynamicanimation/animation/b$q;)V

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method

.method F(Lcom/google/android/material/progressindicator/h;)V
    .locals 2
    .param p1    # Lcom/google/android/material/progressindicator/h;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/progressindicator/h<",
            "TS;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/progressindicator/f;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p1, p0}, Lcom/google/android/material/progressindicator/h;->f(Lcom/google/android/material/progressindicator/g;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method H(F)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    const v0, 0x461c4000    # 10000.0f

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    mul-float/2addr p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    float-to-int p1, p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public bridge synthetic b(Landroidx/vectordrawable/graphics/drawable/b$a;)V
    .locals 2
    .param p1    # Landroidx/vectordrawable/graphics/drawable/b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/android/material/progressindicator/g;->b(Landroidx/vectordrawable/graphics/drawable/b$a;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public bridge synthetic c()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->c()V

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public bridge synthetic d(Landroidx/vectordrawable/graphics/drawable/b$a;)Z
    .locals 2
    .param p1    # Landroidx/vectordrawable/graphics/drawable/b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x5

    invoke-super {p0, p1}, Lcom/google/android/material/progressindicator/g;->d(Landroidx/vectordrawable/graphics/drawable/b$a;)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return p1
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 10
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    new-instance v0, Landroid/graphics/Rect;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v1}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-nez v1, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eqz v1, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->getClipBounds(Landroid/graphics/Rect;)Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-nez v0, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    goto :goto_0

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/f;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/g;->j()F

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v0, p1, v1}, Lcom/google/android/material/progressindicator/h;->g(Landroid/graphics/Canvas;F)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/f;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/google/android/material/progressindicator/g;->m:Landroid/graphics/Paint;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v0, p1, v1}, Lcom/google/android/material/progressindicator/h;->c(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/g;->b:Lcom/google/android/material/progressindicator/b;

    const/4 v9, 0x7

    const/4 v8, 0x7

    iget-object v0, v0, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v9, 0x3

    const/4 v1, 0x0

    const/4 v9, 0x2

    move v8, v1

    move v8, v1

    const/4 v9, 0x4

    aget v0, v0, v1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/f;->getAlpha()I

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v0, v1}, Lcom/google/android/material/color/s;->a(II)I

    move-result v7

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v2, p0, Lcom/google/android/material/progressindicator/f;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v4, p0, Lcom/google/android/material/progressindicator/g;->m:Landroid/graphics/Paint;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v5, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/f;->D()F

    move-result v6

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual/range {v2 .. v7}, Lcom/google/android/material/progressindicator/h;->b(Landroid/graphics/Canvas;Landroid/graphics/Paint;FFI)V

    const/4 v9, 0x2

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    :cond_1
    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    return-void
.end method

.method public bridge synthetic getAlpha()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->getAlpha()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public getIntrinsicHeight()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/f;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/h;->d()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public getIntrinsicWidth()I
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/progressindicator/f;->r:Lcom/google/android/material/progressindicator/h;

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/h;->e()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public bridge synthetic getOpacity()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->getOpacity()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public bridge synthetic isRunning()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->isRunning()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public jumpToCurrentState()V
    .locals 4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/f;->t:Landroidx/dynamicanimation/animation/j;

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroidx/dynamicanimation/animation/j;->E()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getLevel()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    int-to-float v0, v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const v1, 0x461c4000    # 10000.0f

    const/4 v3, 0x6

    div-float/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/material/progressindicator/f;->G(F)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public bridge synthetic l()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->l()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public bridge synthetic m()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->m()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public bridge synthetic n()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->n()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method protected onLevelChange(I)Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/progressindicator/f;->v:Z

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    const v1, 0x461c4000    # 10000.0f

    const/4 v4, 0x3

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/f;->t:Landroidx/dynamicanimation/animation/j;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroidx/dynamicanimation/animation/j;->E()V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    int-to-float p1, p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    div-float/2addr p1, v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/progressindicator/f;->G(F)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/progressindicator/f;->t:Landroidx/dynamicanimation/animation/j;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/f;->D()F

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    mul-float/2addr v2, v1

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    invoke-virtual {v0, v2}, Landroidx/dynamicanimation/animation/b;->t(F)Landroidx/dynamicanimation/animation/b;

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/f;->t:Landroidx/dynamicanimation/animation/j;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    int-to-float p1, p1

    invoke-virtual {v0, p1}, Landroidx/dynamicanimation/animation/j;->z(F)V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 p1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    return p1
.end method

.method public bridge synthetic setAlpha(I)V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-super {p0, p1}, Lcom/google/android/material/progressindicator/g;->setAlpha(I)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public bridge synthetic setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 2
    .param p1    # Landroid/graphics/ColorFilter;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-super {p0, p1}, Lcom/google/android/material/progressindicator/g;->setColorFilter(Landroid/graphics/ColorFilter;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public bridge synthetic setVisible(ZZ)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-super {p0, p1, p2}, Lcom/google/android/material/progressindicator/g;->setVisible(ZZ)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return p1
.end method

.method public bridge synthetic start()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->start()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public bridge synthetic stop()V
    .locals 2

    const/4 v1, 0x2

    invoke-super {p0}, Lcom/google/android/material/progressindicator/g;->stop()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public bridge synthetic v(ZZZ)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-super {p0, p1, p2, p3}, Lcom/google/android/material/progressindicator/g;->v(ZZZ)Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p1
.end method

.method w(ZZZ)Z
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-super {p0, p1, p2, p3}, Lcom/google/android/material/progressindicator/g;->w(ZZZ)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object p2, p0, Lcom/google/android/material/progressindicator/g;->c:Lcom/google/android/material/progressindicator/a;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object p3, p0, Lcom/google/android/material/progressindicator/g;->a:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p3}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p2, p3}, Lcom/google/android/material/progressindicator/a;->a(Landroid/content/ContentResolver;)F

    move-result p2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 p3, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    cmpl-float p3, p2, p3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez p3, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 p2, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-boolean p2, p0, Lcom/google/android/material/progressindicator/f;->v:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p3, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-boolean p3, p0, Lcom/google/android/material/progressindicator/f;->v:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object p3, p0, Lcom/google/android/material/progressindicator/f;->s:Landroidx/dynamicanimation/animation/k;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/high16 v0, 0x42480000    # 50.0f

    const/4 v1, 0x7

    move v2, v1

    div-float/2addr v0, p2

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p3, v0}, Landroidx/dynamicanimation/animation/k;->i(F)Landroidx/dynamicanimation/animation/k;

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1
.end method

.method public z(Landroidx/dynamicanimation/animation/b$q;)V
    .locals 3
    .param p1    # Landroidx/dynamicanimation/animation/b$q;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/f;->t:Landroidx/dynamicanimation/animation/j;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroidx/dynamicanimation/animation/b;->b(Landroidx/dynamicanimation/animation/b$q;)Landroidx/dynamicanimation/animation/b;

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method
