.class Lcom/google/android/material/progressindicator/l$a;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/progressindicator/l;->o()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/progressindicator/l;


# direct methods
.method constructor <init>(Lcom/google/android/material/progressindicator/l;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/progressindicator/l$a;->a:Lcom/google/android/material/progressindicator/l;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onAnimationRepeat(Landroid/animation/Animator;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@os~~.i v~ yM @~o~cib~ @ /@~ f@s 4m~ut@  o-@@~~~lr@~  @@ol ~@ ~@nd@ ~ i~o@  aS@~~btK@~@~/@1b~~o@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationRepeat(Landroid/animation/Animator;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/google/android/material/progressindicator/l$a;->a:Lcom/google/android/material/progressindicator/l;

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/google/android/material/progressindicator/l;->i(Lcom/google/android/material/progressindicator/l;)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    add-int/2addr v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/android/material/progressindicator/l$a;->a:Lcom/google/android/material/progressindicator/l;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v2}, Lcom/google/android/material/progressindicator/l;->k(Lcom/google/android/material/progressindicator/l;)Lcom/google/android/material/progressindicator/b;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v2, v2, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    array-length v2, v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    rem-int/2addr v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p1, v0}, Lcom/google/android/material/progressindicator/l;->j(Lcom/google/android/material/progressindicator/l;I)I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/google/android/material/progressindicator/l$a;->a:Lcom/google/android/material/progressindicator/l;

    const/4 v4, 0x1

    invoke-static {p1, v1}, Lcom/google/android/material/progressindicator/l;->l(Lcom/google/android/material/progressindicator/l;Z)Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void
.end method
