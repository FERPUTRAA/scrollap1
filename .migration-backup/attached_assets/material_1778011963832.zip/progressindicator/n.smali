.class public final Lcom/google/android/material/progressindicator/n;
.super Lcom/google/android/material/progressindicator/b;


# instance fields
.field public g:I

.field public h:I

.field i:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget v0, Lcom/google/android/material/R$attr;->linearProgressIndicatorStyle:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/progressindicator/n;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->y:I

    invoke-direct {p0, p1, p2, p3, v0}, Lcom/google/android/material/progressindicator/n;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 8
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v7, 0x2

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/android/material/progressindicator/b;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    sget-object v2, Lcom/google/android/material/R$styleable;->LinearProgressIndicator:[I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    sget v3, Lcom/google/android/material/R$attr;->linearProgressIndicatorStyle:I

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    sget v4, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->y:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 p3, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    new-array v5, p3, [I

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v1, p2

    move-object v1, p2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    sget p2, Lcom/google/android/material/R$styleable;->LinearProgressIndicator_indeterminateAnimationType:I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 p4, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p1, p2, p4}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    iput p2, p0, Lcom/google/android/material/progressindicator/n;->g:I

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    sget p2, Lcom/google/android/material/R$styleable;->LinearProgressIndicator_indicatorDirectionLinear:I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p1, p2, p3}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    iput p2, p0, Lcom/google/android/material/progressindicator/n;->h:I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/n;->e()V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget p1, p0, Lcom/google/android/material/progressindicator/n;->h:I

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-ne p1, p4, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    move p3, p4

    const/4 v7, 0x2

    move p3, p4

    move p3, p4

    :cond_0
    const/4 v7, 0x5

    iput-boolean p3, p0, Lcom/google/android/material/progressindicator/n;->i:Z

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-void
.end method


# virtual methods
.method e()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " Ks~bt@a m@@s~@4~~ -v@ @ @~~~o~/ t1~@@S  @y@@i~f@l@l@n@~Mc@b/~~o~ i@~r     ~fo~~uio.~~~ o@b@d  ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/android/material/progressindicator/n;->g:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/progressindicator/b;->b:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-gtz v0, :cond_1

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    array-length v0, v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "rcimeotenstolumi  udt tihme dostno uiinCiiodaieeomotnssc tans r 3.u reroganrwm  "

    const-string v1, " lsi i dre actsu. dotis ntoorbr cuig setuonCe3ehi mmmdowunetrionr tieaonmtaosni "

    const/4 v3, 0x5

    const-string v1, "Cn aotneuoi oniuoatm sbc ianotdoliocueou. dei t3 r t eseti h mniadmwmsrrestrgroi"

    const-string v1, "Contiguous indeterminate animation must be used with 3 or more indicator colors."

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    throw v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const-string/jumbo v1, "t.mc bn gnnsrnruon ceuat   tRonpnseiroupentariridodaeaonmii o edtitedueo"

    const-string v1, "Rounded corners are not supported in contiguous indeterminate animation."

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    throw v0

    :cond_2
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method
