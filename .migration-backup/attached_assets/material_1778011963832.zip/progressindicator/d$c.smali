.class Lcom/google/android/material/progressindicator/d$c;
.super Landroid/util/Property;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/progressindicator/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "Lcom/google/android/material/progressindicator/d;",
        "Ljava/lang/Float;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/Class;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/material/progressindicator/d;)Ljava/lang/Float;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o s@@b o~@i@f ~b~@s@@ /@n.@doM4v~ @ ~a~ ~@of@ c ~/S~~li@ y o~@~@t@~m lK~r~  ~~t@ ~u~1@i~b-@ o@~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/google/android/material/progressindicator/d;->l(Lcom/google/android/material/progressindicator/d;)F

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method

.method public b(Lcom/google/android/material/progressindicator/d;Ljava/lang/Float;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p2}, Ljava/lang/Float;->floatValue()F

    move-result p2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Lcom/google/android/material/progressindicator/d;->t(F)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public bridge synthetic get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    check-cast p1, Lcom/google/android/material/progressindicator/d;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/progressindicator/d$c;->a(Lcom/google/android/material/progressindicator/d;)Ljava/lang/Float;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    check-cast p1, Lcom/google/android/material/progressindicator/d;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    check-cast p2, Ljava/lang/Float;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/progressindicator/d$c;->b(Lcom/google/android/material/progressindicator/d;Ljava/lang/Float;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method
