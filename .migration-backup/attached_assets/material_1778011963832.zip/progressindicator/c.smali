.class final Lcom/google/android/material/progressindicator/c;
.super Lcom/google/android/material/progressindicator/h;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/material/progressindicator/h<",
        "Lcom/google/android/material/progressindicator/e;",
        ">;"
    }
.end annotation


# instance fields
.field private c:I

.field private d:F

.field private e:F

.field private f:F


# direct methods
.method public constructor <init>(Lcom/google/android/material/progressindicator/e;)V
    .locals 2
    .param p1    # Lcom/google/android/material/progressindicator/e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/progressindicator/h;-><init>(Lcom/google/android/material/progressindicator/b;)V

    const/4 p1, 0x0

    move v1, p1

    const/4 p1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/progressindicator/c;->c:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method private h(Landroid/graphics/Canvas;Landroid/graphics/Paint;FFF)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~sob ~om l  S~b4@Mo~1. ob~f ~~@~@ @~ ~ @~ @c@rtv l~~~ @u@f~@@@@ /@i~@/~to~@s@~ iai@y~ on@~K@-~d"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1, p5}, Landroid/graphics/Canvas;->rotate(F)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance p5, Landroid/graphics/RectF;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/progressindicator/c;->f:F

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/high16 v1, 0x40000000    # 2.0f

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    div-float/2addr p3, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    sub-float v1, v0, p3

    const/4 v2, 0x7

    move v3, v2

    add-float/2addr v0, p3

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    neg-float p3, p4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p5, v1, p4, v0, p3}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1, p5, p4, p4, p2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method private i()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    move-object v1, v0

    move-object v1, v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v1, Lcom/google/android/material/progressindicator/e;

    const/4 v3, 0x1

    const/4 v2, 0x3

    iget v1, v1, Lcom/google/android/material/progressindicator/e;->g:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v0, v0, Lcom/google/android/material/progressindicator/e;->h:I

    const/4 v3, 0x5

    mul-int/lit8 v0, v0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x0

    return v1
.end method


# virtual methods
.method public a(Landroid/graphics/Canvas;F)V
    .locals 6
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    check-cast v1, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget v1, v1, Lcom/google/android/material/progressindicator/e;->g:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    int-to-float v1, v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    div-float/2addr v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget v0, v0, Lcom/google/android/material/progressindicator/e;->h:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    int-to-float v0, v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    add-float/2addr v1, v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p1, v1, v1}, Landroid/graphics/Canvas;->translate(FF)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/high16 v0, -0x3d4c0000    # -90.0f

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->rotate(F)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    neg-float v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1, v0, v0, v1, v1}, Landroid/graphics/Canvas;->clipRect(FFFF)Z

    const/4 v5, 0x3

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget v0, v0, Lcom/google/android/material/progressindicator/e;->i:I

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    move v0, v1

    const/4 v5, 0x7

    move v0, v1

    move v0, v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v0, -0x1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput v0, p0, Lcom/google/android/material/progressindicator/c;->c:I

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    int-to-float v0, v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    mul-float/2addr v0, p2

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    iput v0, p0, Lcom/google/android/material/progressindicator/c;->d:F

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->b:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    int-to-float v0, v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    mul-float/2addr v0, p2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput v0, p0, Lcom/google/android/material/progressindicator/c;->e:F

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget v0, v0, Lcom/google/android/material/progressindicator/e;->g:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    check-cast p1, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget p1, p1, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    sub-int/2addr v0, p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    int-to-float p1, v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    div-float/2addr p1, v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput p1, p0, Lcom/google/android/material/progressindicator/c;->f:F

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/google/android/material/progressindicator/h;->b:Lcom/google/android/material/progressindicator/g;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/g;->n()Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v3, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz p1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object p1, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v4, 0x3

    const/4 v4, 0x0

    check-cast p1, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x6

    iget p1, p1, Lcom/google/android/material/progressindicator/b;->e:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eq p1, v3, :cond_2

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/google/android/material/progressindicator/h;->b:Lcom/google/android/material/progressindicator/g;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/g;->m()Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz p1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    check-cast p1, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget p1, p1, Lcom/google/android/material/progressindicator/b;->f:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-ne p1, v1, :cond_3

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget p1, p0, Lcom/google/android/material/progressindicator/c;->f:F

    const/4 v4, 0x1

    shr-int/2addr v5, v4

    sub-float/2addr v0, p2

    const/4 v5, 0x0

    const/4 v4, 0x1

    iget-object p2, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast p2, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget p2, p2, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    int-to-float p2, p2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    mul-float/2addr v0, p2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    div-float/2addr v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    add-float/2addr p1, v0

    const/4 v4, 0x0

    move v5, v4

    iput p1, p0, Lcom/google/android/material/progressindicator/c;->f:F

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_1

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/google/android/material/progressindicator/h;->b:Lcom/google/android/material/progressindicator/g;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/g;->n()Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz p1, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    check-cast p1, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget p1, p1, Lcom/google/android/material/progressindicator/b;->e:I

    const/4 v5, 0x0

    if-eq p1, v1, :cond_5

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/google/android/material/progressindicator/h;->b:Lcom/google/android/material/progressindicator/g;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/g;->m()Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz p1, :cond_6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    check-cast p1, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget p1, p1, Lcom/google/android/material/progressindicator/b;->f:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-ne p1, v3, :cond_6

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget p1, p0, Lcom/google/android/material/progressindicator/c;->f:F

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    sub-float/2addr v0, p2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    check-cast p2, Lcom/google/android/material/progressindicator/e;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget p2, p2, Lcom/google/android/material/progressindicator/b;->a:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    int-to-float p2, p2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    mul-float/2addr v0, p2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    div-float/2addr v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    sub-float/2addr p1, v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput p1, p0, Lcom/google/android/material/progressindicator/c;->f:F

    :cond_6
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x4

    return-void
.end method

.method b(Landroid/graphics/Canvas;Landroid/graphics/Paint;FFI)V
    .locals 11
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Paint;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p4    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .param p5    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v7, p2

    move-object v7, p2

    cmpl-float v0, p3, p4

    if-nez v0, :cond_0

    return-void

    :cond_0
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    sget-object v0, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    const/4 v0, 0x1

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    move/from16 v0, p5

    move/from16 v0, p5

    move/from16 v0, p5

    move/from16 v0, p5

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setColor(I)V

    iget v0, v6, Lcom/google/android/material/progressindicator/c;->d:F

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/high16 v8, 0x43b40000    # 360.0f

    mul-float v0, p3, v8

    iget v1, v6, Lcom/google/android/material/progressindicator/c;->c:I

    int-to-float v2, v1

    mul-float v9, v0, v2

    cmpl-float v0, p4, p3

    if-ltz v0, :cond_1

    sub-float v0, p4, p3

    goto :goto_0

    :cond_1
    const/high16 v0, 0x3f800000    # 1.0f

    add-float/2addr v0, p4

    sub-float/2addr v0, p3

    :goto_0
    mul-float/2addr v0, v8

    int-to-float v1, v1

    mul-float/2addr v0, v1

    move v10, v0

    move v10, v0

    move v10, v0

    move v10, v0

    new-instance v1, Landroid/graphics/RectF;

    iget v0, v6, Lcom/google/android/material/progressindicator/c;->f:F

    neg-float v2, v0

    neg-float v3, v0

    invoke-direct {v1, v2, v3, v0, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v4, 0x0

    move-object v0, p1

    move-object v0, p1

    move v2, v9

    move v2, v9

    move v2, v9

    move v2, v9

    move v3, v10

    move v3, v10

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    iget v0, v6, Lcom/google/android/material/progressindicator/c;->e:F

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-lez v0, :cond_2

    invoke-static {v10}, Ljava/lang/Math;->abs(F)F

    move-result v0

    cmpg-float v0, v0, v8

    if-gez v0, :cond_2

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    iget v3, v6, Lcom/google/android/material/progressindicator/c;->d:F

    iget v4, v6, Lcom/google/android/material/progressindicator/c;->e:F

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move v5, v9

    move v5, v9

    move v5, v9

    move v5, v9

    invoke-direct/range {v0 .. v5}, Lcom/google/android/material/progressindicator/c;->h(Landroid/graphics/Canvas;Landroid/graphics/Paint;FFF)V

    iget v3, v6, Lcom/google/android/material/progressindicator/c;->d:F

    iget v4, v6, Lcom/google/android/material/progressindicator/c;->e:F

    add-float v5, v9, v10

    invoke-direct/range {v0 .. v5}, Lcom/google/android/material/progressindicator/c;->h(Landroid/graphics/Canvas;Landroid/graphics/Paint;FFF)V

    :cond_2
    return-void
.end method

.method c(Landroid/graphics/Canvas;Landroid/graphics/Paint;)V
    .locals 9
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Paint;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/h;->a:Lcom/google/android/material/progressindicator/b;

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v8, 0x2

    const/4 v7, 0x1

    iget v0, v0, Lcom/google/android/material/progressindicator/b;->d:I

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/google/android/material/progressindicator/h;->b:Lcom/google/android/material/progressindicator/g;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v1}, Lcom/google/android/material/progressindicator/g;->getAlpha()I

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {v0, v1}, Lcom/google/android/material/color/s;->a(II)I

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v8, 0x1

    sget-object v1, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v1, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p2, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v7, 0x4

    const/4 v8, 0x4

    iget v0, p0, Lcom/google/android/material/progressindicator/c;->d:F

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-instance v2, Landroid/graphics/RectF;

    const/4 v8, 0x1

    iget v0, p0, Lcom/google/android/material/progressindicator/c;->f:F

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    neg-float v1, v0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    neg-float v3, v0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-direct {v2, v1, v3, v0, v0}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v3, 0x0

    const/4 v7, 0x6

    move v8, v7

    const/high16 v4, 0x43b40000    # 360.0f

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v5, 0x0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    return-void
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/c;->i()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public e()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/c;->i()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method
