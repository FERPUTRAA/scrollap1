.class final Lcom/google/android/material/progressindicator/d;
.super Lcom/google/android/material/progressindicator/i;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/material/progressindicator/i<",
        "Landroid/animation/ObjectAnimator;",
        ">;"
    }
.end annotation


# static fields
.field private static final l:I = 0x4

.field private static final m:I = 0x1518

.field private static final n:I = 0x29b

.field private static final o:I = 0x29b

.field private static final p:I = 0x14d

.field private static final q:I = 0x14d

.field private static final r:[I

.field private static final s:[I

.field private static final t:[I

.field private static final u:I = -0x14

.field private static final v:I = 0xfa

.field private static final w:I = 0x5f0

.field private static final x:Landroid/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/Property<",
            "Lcom/google/android/material/progressindicator/d;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field

.field private static final y:Landroid/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/Property<",
            "Lcom/google/android/material/progressindicator/d;",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private d:Landroid/animation/ObjectAnimator;

.field private e:Landroid/animation/ObjectAnimator;

.field private final f:Landroidx/interpolator/view/animation/b;

.field private final g:Lcom/google/android/material/progressindicator/b;

.field private h:I

.field private i:F

.field private j:F

.field k:Landroidx/vectordrawable/graphics/drawable/b$a;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/16 v0, 0xa8c

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/16 v1, 0xfd2

    const/4 v4, 0x2

    and-int/2addr v5, v4

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/16 v3, 0x546

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    sput-object v0, Lcom/google/android/material/progressindicator/d;->r:[I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/16 v0, 0xd27

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/16 v1, 0x126d

    const/4 v5, 0x4

    const/16 v2, 0x29b

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/16 v3, 0x7e1

    const/4 v5, 0x5

    const/4 v4, 0x1

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    sput-object v0, Lcom/google/android/material/progressindicator/d;->s:[I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/16 v0, 0xe74

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/16 v1, 0x13ba

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/16 v2, 0x3e8

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/16 v3, 0x92e

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    filled-new-array {v2, v3, v0, v1}, [I

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    sput-object v0, Lcom/google/android/material/progressindicator/d;->t:[I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-instance v0, Lcom/google/android/material/progressindicator/d$c;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string/jumbo v1, "nnsionFtsmricaoaa"

    const-string v1, "cosonFamtaniirani"

    const/4 v5, 0x7

    const-string/jumbo v1, "tnamaamricnoinFti"

    const-string v1, "animationFraction"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-class v2, Ljava/lang/Float;

    const-class v2, Ljava/lang/Float;

    const/4 v5, 0x5

    const-class v2, Ljava/lang/Float;

    const-class v2, Ljava/lang/Float;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {v0, v2, v1}, Lcom/google/android/material/progressindicator/d$c;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    sput-object v0, Lcom/google/android/material/progressindicator/d;->x:Landroid/util/Property;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v0, Lcom/google/android/material/progressindicator/d$d;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string v1, "amnnoFicedetptEmlor"

    const-string/jumbo v1, "tEtmniocFdpmaoeernl"

    const/4 v5, 0x2

    const-string v1, "dtctrbFelaEioomncpn"

    const-string v1, "completeEndFraction"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v0, v2, v1}, Lcom/google/android/material/progressindicator/d$d;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    sput-object v0, Lcom/google/android/material/progressindicator/d;->y:Landroid/util/Property;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method

.method public constructor <init>(Lcom/google/android/material/progressindicator/e;)V
    .locals 3
    .param p1    # Lcom/google/android/material/progressindicator/e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/google/android/material/progressindicator/i;-><init>(I)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput v0, p0, Lcom/google/android/material/progressindicator/d;->h:I

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/progressindicator/d;->k:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/material/progressindicator/d;->g:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance p1, Landroidx/interpolator/view/animation/b;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p1}, Landroidx/interpolator/view/animation/b;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/material/progressindicator/d;->f:Landroidx/interpolator/view/animation/b;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method static synthetic i(Lcom/google/android/material/progressindicator/d;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget p0, p0, Lcom/google/android/material/progressindicator/d;->h:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic j(Lcom/google/android/material/progressindicator/d;I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/progressindicator/d;->h:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic k(Lcom/google/android/material/progressindicator/d;)Lcom/google/android/material/progressindicator/b;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/material/progressindicator/d;->g:Lcom/google/android/material/progressindicator/b;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic l(Lcom/google/android/material/progressindicator/d;)F
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/d;->o()F

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x2

    return p0
.end method

.method static synthetic m(Lcom/google/android/material/progressindicator/d;)F
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/d;->p()F

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p0
.end method

.method static synthetic n(Lcom/google/android/material/progressindicator/d;F)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/progressindicator/d;->u(F)V

    const/4 v1, 0x2

    return-void
.end method

.method private o()F
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/progressindicator/d;->i:F

    const/4 v2, 0x6

    return v0
.end method

.method private p()F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/progressindicator/d;->j:F

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method private q()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/progressindicator/d;->d:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v1, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    sget-object v0, Lcom/google/android/material/progressindicator/d;->x:Landroid/util/Property;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-array v2, v1, [F

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    fill-array-data v2, :array_0

    const/4 v5, 0x7

    invoke-static {p0, v0, v2}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput-object v0, p0, Lcom/google/android/material/progressindicator/d;->d:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-wide/16 v2, 0x1518

    const-wide/16 v2, 0x1518

    const/4 v5, 0x0

    const-wide/16 v2, 0x1518

    const-wide/16 v2, 0x1518

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v3}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/d;->d:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v2}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/d;->d:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v2, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v2}, Landroid/animation/ValueAnimator;->setRepeatCount(I)V

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/d;->d:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v2, Lcom/google/android/material/progressindicator/d$a;

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-direct {v2, p0}, Lcom/google/android/material/progressindicator/d$a;-><init>(Lcom/google/android/material/progressindicator/d;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/d;->e:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x4

    if-nez v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    sget-object v0, Lcom/google/android/material/progressindicator/d;->y:Landroid/util/Property;

    const/4 v5, 0x7

    const/4 v4, 0x6

    new-array v1, v1, [F

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    fill-array-data v1, :array_1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p0, v0, v1}, Landroid/animation/ObjectAnimator;->ofFloat(Ljava/lang/Object;Landroid/util/Property;[F)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/google/android/material/progressindicator/d;->e:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-wide/16 v1, 0x14d

    const-wide/16 v1, 0x14d

    const/4 v5, 0x5

    const-wide/16 v1, 0x14d

    const-wide/16 v1, 0x14d

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/d;->e:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/google/android/material/progressindicator/d;->f:Landroidx/interpolator/view/animation/b;

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/d;->e:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v1, Lcom/google/android/material/progressindicator/d$b;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {v1, p0}, Lcom/google/android/material/progressindicator/d$b;-><init>(Lcom/google/android/material/progressindicator/d;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-void

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data

    :array_1
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method private r(I)V
    .locals 7

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    move v1, v0

    move v1, v0

    const/4 v6, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v2, 0x4

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-ge v1, v2, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    sget-object v2, Lcom/google/android/material/progressindicator/d;->t:[I

    const/4 v6, 0x6

    aget v2, v2, v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/16 v3, 0x14d

    const/4 v5, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p0, p1, v2, v3}, Lcom/google/android/material/progressindicator/i;->b(III)F

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 v3, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    cmpl-float v3, v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-ltz v3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v5, 0x1

    move v6, v5

    cmpg-float v3, v2, v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-gtz v3, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget p1, p0, Lcom/google/android/material/progressindicator/d;->h:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    add-int/2addr v1, p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/google/android/material/progressindicator/d;->g:Lcom/google/android/material/progressindicator/b;

    const/4 v5, 0x1

    move v6, v5

    iget-object p1, p1, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    array-length v3, p1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    rem-int/2addr v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    array-length v4, p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    rem-int/2addr v3, v4

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    aget p1, p1, v1

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v1}, Lcom/google/android/material/progressindicator/j;->getAlpha()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {p1, v1}, Lcom/google/android/material/color/s;->a(II)I

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/android/material/progressindicator/d;->g:Lcom/google/android/material/progressindicator/b;

    const/4 v6, 0x6

    iget-object v1, v1, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    aget v1, v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v3}, Lcom/google/android/material/progressindicator/j;->getAlpha()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v1, v3}, Lcom/google/android/material/color/s;->a(II)I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/google/android/material/progressindicator/d;->f:Landroidx/interpolator/view/animation/b;

    const/4 v5, 0x5

    move v6, v5

    invoke-virtual {v3, v2}, Landroidx/interpolator/view/animation/b;->getInterpolation(F)F

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/android/material/progressindicator/i;->c:[I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {}, Lcom/google/android/material/animation/c;->b()Lcom/google/android/material/animation/c;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v4, v2, p1, v1}, Lcom/google/android/material/animation/c;->a(FLjava/lang/Integer;Ljava/lang/Integer;)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    aput p1, v3, v0

    const/4 v5, 0x3

    move v6, v5

    goto :goto_1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    goto/16 :goto_0

    :cond_1
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    return-void
.end method

.method private u(F)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/android/material/progressindicator/d;->j:F

    const/4 v0, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method private v(I)V
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget v1, p0, Lcom/google/android/material/progressindicator/d;->i:F

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/high16 v2, 0x44be0000    # 1520.0f

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    mul-float v3, v1, v2

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/high16 v4, -0x3e600000    # -20.0f

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    add-float/2addr v3, v4

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/4 v4, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    aput v3, v0, v4

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    mul-float/2addr v1, v2

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v2, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    aput v1, v0, v2

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    move v0, v4

    move v0, v4

    const/4 v9, 0x3

    move v0, v4

    move v0, v4

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/4 v1, 0x4

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-ge v0, v1, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x3

    sget-object v1, Lcom/google/android/material/progressindicator/d;->r:[I

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    aget v1, v1, v0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/16 v3, 0x29b

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {p0, p1, v1, v3}, Lcom/google/android/material/progressindicator/i;->b(III)F

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v5, p0, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    aget v6, v5, v2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v7, p0, Lcom/google/android/material/progressindicator/d;->f:Landroidx/interpolator/view/animation/b;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v7, v1}, Landroidx/interpolator/view/animation/b;->getInterpolation(F)F

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    const/high16 v7, 0x437a0000    # 250.0f

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    mul-float/2addr v1, v7

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    add-float/2addr v6, v1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    aput v6, v5, v2

    const/4 v9, 0x3

    sget-object v1, Lcom/google/android/material/progressindicator/d;->s:[I

    const/4 v8, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    aget v1, v1, v0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p0, p1, v1, v3}, Lcom/google/android/material/progressindicator/i;->b(III)F

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v3, p0, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    aget v5, v3, v4

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v6, p0, Lcom/google/android/material/progressindicator/d;->f:Landroidx/interpolator/view/animation/b;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v6, v1}, Landroidx/interpolator/view/animation/b;->getInterpolation(F)F

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    mul-float/2addr v1, v7

    const/4 v8, 0x6

    const/4 v9, 0x7

    add-float/2addr v5, v1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    aput v5, v3, v4

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v9, 0x7

    goto :goto_0

    :cond_0
    const/4 v9, 0x2

    iget-object p1, p0, Lcom/google/android/material/progressindicator/i;->b:[F

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    aget v0, p1, v4

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    aget v1, p1, v2

    const/4 v8, 0x2

    shr-int/2addr v9, v8

    sub-float v3, v1, v0

    const/4 v8, 0x7

    move v9, v8

    iget v5, p0, Lcom/google/android/material/progressindicator/d;->j:F

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    mul-float/2addr v3, v5

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    add-float/2addr v0, v3

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    aput v0, p1, v4

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    const/high16 v3, 0x43b40000    # 360.0f

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    div-float/2addr v0, v3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    aput v0, p1, v4

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    div-float/2addr v1, v3

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    aput v1, p1, v2

    const/4 v8, 0x5

    move v9, v8

    return-void
.end method


# virtual methods
.method a()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/d;->d:Landroid/animation/ObjectAnimator;

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/animation/Animator;->cancel()V

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public c()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/d;->s()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public d(Landroidx/vectordrawable/graphics/drawable/b$a;)V
    .locals 2
    .param p1    # Landroidx/vectordrawable/graphics/drawable/b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/android/material/progressindicator/d;->k:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v1, 0x2

    return-void
.end method

.method f()V
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/d;->e:Landroid/animation/ObjectAnimator;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_2

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/animation/Animator;->isRunning()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    and-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/d;->e:Landroid/animation/ObjectAnimator;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/animation/ObjectAnimator;->start()V

    const/4 v1, 0x4

    const/4 v1, 0x7

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/d;->a()V

    :cond_2
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method g()V
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/d;->q()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/d;->s()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/d;->d:Landroid/animation/ObjectAnimator;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/animation/ObjectAnimator;->start()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public h()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/progressindicator/d;->k:Landroidx/vectordrawable/graphics/drawable/b$a;

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method s()V
    .locals 6
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput v0, p0, Lcom/google/android/material/progressindicator/d;->h:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/android/material/progressindicator/i;->c:[I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/google/android/material/progressindicator/d;->g:Lcom/google/android/material/progressindicator/b;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v2, v2, Lcom/google/android/material/progressindicator/b;->c:[I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    aget v2, v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v3, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v3}, Lcom/google/android/material/progressindicator/j;->getAlpha()I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v2, v3}, Lcom/google/android/material/color/s;->a(II)I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    aput v2, v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v0, 0x0

    shr-int/2addr v5, v0

    const/4 v4, 0x2

    const/4 v4, 0x2

    iput v0, p0, Lcom/google/android/material/progressindicator/d;->j:F

    const/4 v5, 0x4

    return-void
.end method

.method t(F)V
    .locals 3
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput p1, p0, Lcom/google/android/material/progressindicator/d;->i:F

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    const v0, 0x45a8c000    # 5400.0f

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    mul-float/2addr p1, v0

    const/4 v2, 0x4

    float-to-int p1, p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/progressindicator/d;->v(I)V

    const/4 v1, 0x1

    move v2, v1

    invoke-direct {p0, p1}, Lcom/google/android/material/progressindicator/d;->r(I)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/material/progressindicator/i;->a:Lcom/google/android/material/progressindicator/j;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method
