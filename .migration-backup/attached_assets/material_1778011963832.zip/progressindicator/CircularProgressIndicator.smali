.class public final Lcom/google/android/material/progressindicator/CircularProgressIndicator;
.super Lcom/google/android/material/progressindicator/BaseProgressIndicator;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/progressindicator/CircularProgressIndicator$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/material/progressindicator/BaseProgressIndicator<",
        "Lcom/google/android/material/progressindicator/e;",
        ">;"
    }
.end annotation


# static fields
.field public static final A:I = 0x1

.field public static final y:I

.field public static final z:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_CircularProgressIndicator:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    sput v0, Lcom/google/android/material/progressindicator/CircularProgressIndicator;->y:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/progressindicator/CircularProgressIndicator;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/R$attr;->circularProgressIndicatorStyle:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/progressindicator/CircularProgressIndicator;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x7

    move v2, v1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param

    const/4 v2, 0x0

    sget v0, Lcom/google/android/material/progressindicator/CircularProgressIndicator;->y:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2, p3, v0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/CircularProgressIndicator;->u()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method private u()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v3, 0x1

    check-cast v1, Lcom/google/android/material/progressindicator/e;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/google/android/material/progressindicator/j;->x(Landroid/content/Context;Lcom/google/android/material/progressindicator/e;)Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->setIndeterminateDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    check-cast v1, Lcom/google/android/material/progressindicator/e;

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/google/android/material/progressindicator/f;->A(Landroid/content/Context;Lcom/google/android/material/progressindicator/e;)Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->setProgressDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method


# virtual methods
.method public getIndicatorDirection()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    iget v0, v0, Lcom/google/android/material/progressindicator/e;->i:I

    return v0
.end method

.method public getIndicatorInset()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, v0, Lcom/google/android/material/progressindicator/e;->h:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public getIndicatorSize()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget v0, v0, Lcom/google/android/material/progressindicator/e;->g:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method bridge synthetic i(Landroid/content/Context;Landroid/util/AttributeSet;)Lcom/google/android/material/progressindicator/b;
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/progressindicator/CircularProgressIndicator;->t(Landroid/content/Context;Landroid/util/AttributeSet;)Lcom/google/android/material/progressindicator/e;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1
.end method

.method public setIndicatorDirection(I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput p1, v0, Lcom/google/android/material/progressindicator/e;->i:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->invalidate()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public setIndicatorInset(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast v1, Lcom/google/android/material/progressindicator/e;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, v1, Lcom/google/android/material/progressindicator/e;->h:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eq v1, p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput p1, v0, Lcom/google/android/material/progressindicator/e;->h:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->invalidate()V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method public setIndicatorSize(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getTrackThickness()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    mul-int/lit8 v0, v0, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v1, Lcom/google/android/material/progressindicator/e;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, v1, Lcom/google/android/material/progressindicator/e;->g:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eq v1, p1, :cond_0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    check-cast v1, Lcom/google/android/material/progressindicator/e;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput p1, v1, Lcom/google/android/material/progressindicator/e;->g:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast v0, Lcom/google/android/material/progressindicator/e;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/e;->e()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->invalidate()V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public setTrackThickness(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->setTrackThickness(I)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    check-cast p1, Lcom/google/android/material/progressindicator/e;

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/e;->e()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method t(Landroid/content/Context;Landroid/util/AttributeSet;)Lcom/google/android/material/progressindicator/e;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Lcom/google/android/material/progressindicator/e;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0, p1, p2}, Lcom/google/android/material/progressindicator/e;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-object v0
.end method
