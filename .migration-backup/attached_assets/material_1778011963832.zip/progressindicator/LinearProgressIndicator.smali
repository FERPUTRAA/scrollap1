.class public final Lcom/google/android/material/progressindicator/LinearProgressIndicator;
.super Lcom/google/android/material/progressindicator/BaseProgressIndicator;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/progressindicator/LinearProgressIndicator$b;,
        Lcom/google/android/material/progressindicator/LinearProgressIndicator$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/android/material/progressindicator/BaseProgressIndicator<",
        "Lcom/google/android/material/progressindicator/n;",
        ">;"
    }
.end annotation


# static fields
.field public static final A:I = 0x1

.field public static final B:I = 0x0

.field public static final C:I = 0x1

.field public static final D:I = 0x2

.field public static final E:I = 0x3

.field public static final y:I

.field public static final z:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_LinearProgressIndicator:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    sput v0, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->y:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget v0, Lcom/google/android/material/R$attr;->linearProgressIndicatorStyle:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget v0, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->y:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2, p3, v0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v1, 0x7

    shr-int/2addr v2, v1

    invoke-direct {p0}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->u()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method private u()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~Ms @ff l.~@d4- o@ ioboS@1si @v ~~ y@@o~co~@~@/~~@at~~@~~ bm ~ lt~@ @ro u@/K~@i    @~@~~@@~b~~ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v1, Lcom/google/android/material/progressindicator/n;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/android/material/progressindicator/j;->y(Landroid/content/Context;Lcom/google/android/material/progressindicator/n;)Lcom/google/android/material/progressindicator/j;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->setIndeterminateDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast v1, Lcom/google/android/material/progressindicator/n;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/google/android/material/progressindicator/f;->B(Landroid/content/Context;Lcom/google/android/material/progressindicator/n;)Lcom/google/android/material/progressindicator/f;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->setProgressDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method


# virtual methods
.method public getIndeterminateAnimationType()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, v0, Lcom/google/android/material/progressindicator/n;->g:I

    const/4 v1, 0x0

    move v2, v1

    return v0
.end method

.method public getIndicatorDirection()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, v0, Lcom/google/android/material/progressindicator/n;->h:I

    const/4 v2, 0x3

    return v0
.end method

.method bridge synthetic i(Landroid/content/Context;Landroid/util/AttributeSet;)Lcom/google/android/material/progressindicator/b;
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->t(Landroid/content/Context;Landroid/util/AttributeSet;)Lcom/google/android/material/progressindicator/n;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method

.method protected onLayout(ZIIII)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    invoke-super/range {p0 .. p5}, Landroid/widget/ProgressBar;->onLayout(ZIIII)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    check-cast p2, Lcom/google/android/material/progressindicator/n;

    const/4 v1, 0x7

    check-cast p1, Lcom/google/android/material/progressindicator/n;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget p1, p1, Lcom/google/android/material/progressindicator/n;->h:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    const/4 p3, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    if-eq p1, p3, :cond_2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    if-ne p1, p3, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    check-cast p1, Lcom/google/android/material/progressindicator/n;

    const/4 v1, 0x2

    iget p1, p1, Lcom/google/android/material/progressindicator/n;->h:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 p4, 0x3

    const/4 p4, 0x2

    const/4 v0, 0x5

    xor-int/2addr v1, v0

    if-eq p1, p4, :cond_2

    :cond_0
    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-nez p1, :cond_1

    iget-object p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    check-cast p1, Lcom/google/android/material/progressindicator/n;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    iget p1, p1, Lcom/google/android/material/progressindicator/n;->h:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    const/4 p4, 0x3

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-ne p1, p4, :cond_1

    const/4 v0, 0x3

    const/4 v1, 0x5

    goto :goto_0

    :cond_1
    const/4 p3, 0x0

    const/4 v1, 0x0

    const/4 p3, 0x0

    :cond_2
    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-boolean p3, p2, Lcom/google/android/material/progressindicator/n;->i:Z

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result p3

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result p4

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    add-int/2addr p3, p4

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    sub-int/2addr p1, p3

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result p3

    const/4 v1, 0x6

    const/4 v0, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result p4

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    add-int/2addr p3, p4

    const/4 v0, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    sub-int/2addr p2, p3

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object p3

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p4, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    if-eqz p3, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p3, p4, p4, p1, p2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getProgressDrawable()Lcom/google/android/material/progressindicator/f;

    move-result-object p3

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    if-eqz p3, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p3, p4, p4, p1, p2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public p(IZ)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    iget v0, v0, Lcom/google/android/material/progressindicator/n;->g:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/widget/ProgressBar;->isIndeterminate()Z

    move-result v0

    const/4 v1, 0x7

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-super {p0, p1, p2}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->p(IZ)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public setIndeterminateAnimationType(I)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget v0, v0, Lcom/google/android/material/progressindicator/n;->g:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-ne v0, p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->s()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/widget/ProgressBar;->isIndeterminate()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-nez v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x6

    move v4, v3

    const-string v0, "dnomtihceert rn tmpe eianshittieinhsgwCarsliepnanwanodem immoht gnciroetoai  trt. nine eo aiena  esy d"

    const-string/jumbo v0, "icseeiyotrohtaagmtne Creotinmr. tasimhctespneglieedm trn  w r aiendeoe ih anonstnpni ow iisie adatnhn "

    const/4 v4, 0x4

    const-string v0, "e mroCporintepneamraiahidoi i ngnse ntwicagoset etdyie tt.nhrmees  oncea dmnlot  idthieoiawns ra tnihe"

    const-string v0, "Cannot change indeterminate animation type while the progress indicator is show in indeterminate mode."

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    throw p1

    :cond_2
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v1, Lcom/google/android/material/progressindicator/n;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput p1, v1, Lcom/google/android/material/progressindicator/n;->g:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/progressindicator/n;->e()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-nez p1, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v0, Lcom/google/android/material/progressindicator/l;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    check-cast v1, Lcom/google/android/material/progressindicator/n;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v0, v1}, Lcom/google/android/material/progressindicator/l;-><init>(Lcom/google/android/material/progressindicator/n;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Lcom/google/android/material/progressindicator/j;->B(Lcom/google/android/material/progressindicator/i;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->getIndeterminateDrawable()Lcom/google/android/material/progressindicator/j;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v0, Lcom/google/android/material/progressindicator/m;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    iget-object v2, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast v2, Lcom/google/android/material/progressindicator/n;

    const/4 v3, 0x0

    move v4, v3

    invoke-direct {v0, v1, v2}, Lcom/google/android/material/progressindicator/m;-><init>(Landroid/content/Context;Lcom/google/android/material/progressindicator/n;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Lcom/google/android/material/progressindicator/j;->B(Lcom/google/android/material/progressindicator/i;)V

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->invalidate()V

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void
.end method

.method public varargs setIndicatorColor([I)V
    .locals 2
    .param p1    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-super {p0, p1}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->setIndicatorColor([I)V

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v1, 0x5

    const/4 v0, 0x5

    check-cast p1, Lcom/google/android/material/progressindicator/n;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/n;->e()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public setIndicatorDirection(I)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    check-cast v1, Lcom/google/android/material/progressindicator/n;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput p1, v1, Lcom/google/android/material/progressindicator/n;->h:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    check-cast v0, Lcom/google/android/material/progressindicator/n;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eq p1, v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-ne v2, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    check-cast v2, Lcom/google/android/material/progressindicator/n;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget v2, v2, Lcom/google/android/material/progressindicator/n;->h:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v3, 0x2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eq v2, v3, :cond_2

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v2, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-ne p1, v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v1, 0x0

    :cond_2
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    iput-boolean v1, v0, Lcom/google/android/material/progressindicator/n;->i:Z

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->invalidate()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-void
.end method

.method public setTrackCornerRadius(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-super {p0, p1}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->setTrackCornerRadius(I)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    iget-object p1, p0, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->a:Lcom/google/android/material/progressindicator/b;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    check-cast p1, Lcom/google/android/material/progressindicator/n;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/progressindicator/n;->e()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/progressindicator/BaseProgressIndicator;->invalidate()V

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method

.method t(Landroid/content/Context;Landroid/util/AttributeSet;)Lcom/google/android/material/progressindicator/n;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance v0, Lcom/google/android/material/progressindicator/n;

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0, p1, p2}, Lcom/google/android/material/progressindicator/n;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method
