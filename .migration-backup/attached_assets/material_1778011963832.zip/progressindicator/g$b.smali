.class Lcom/google/android/material/progressindicator/g$b;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/progressindicator/g;->q(Landroid/animation/ValueAnimator;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/progressindicator/g;


# direct methods
.method constructor <init>(Lcom/google/android/material/progressindicator/g;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/google/android/material/progressindicator/g$b;->a:Lcom/google/android/material/progressindicator/g;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bfs~rvf~ @n@ Klu@tib~o@M@@ m~@i.~~~4@~ @ t@~ o  ~@~@a  @ @~ ~~c-y1Sso~do~ @~~~l~/~@@@b @  o~o @i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroid/animation/AnimatorListenerAdapter;->onAnimationEnd(Landroid/animation/Animator;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/google/android/material/progressindicator/g$b;->a:Lcom/google/android/material/progressindicator/g;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p1, v0, v0}, Lcom/google/android/material/progressindicator/g;->e(Lcom/google/android/material/progressindicator/g;ZZ)Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    iget-object p1, p0, Lcom/google/android/material/progressindicator/g$b;->a:Lcom/google/android/material/progressindicator/g;

    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/google/android/material/progressindicator/g;->f(Lcom/google/android/material/progressindicator/g;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method
