.class public final Lcom/google/android/material/circularreveal/a;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method

.method public static a(Lcom/google/android/material/circularreveal/c;FFF)Landroid/animation/Animator;
    .locals 8
    .param p0    # Lcom/google/android/material/circularreveal/c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "tiso@~@@~~~@b ~sy~/ r a ~~@~. ~  c@ @ f~~~Ko~~i@u@@oiS@@@4 v  @~f nl~~ @Mbod~~  1lo@@t @~@@mb-/~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    sget-object v0, Lcom/google/android/material/circularreveal/c$c;->a:Landroid/util/Property;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    sget-object v1, Lcom/google/android/material/circularreveal/c$b;->b:Landroid/animation/TypeEvaluator;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v2, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-array v3, v2, [Lcom/google/android/material/circularreveal/c$e;

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-instance v4, Lcom/google/android/material/circularreveal/c$e;

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {v4, p1, p2, p3}, Lcom/google/android/material/circularreveal/c$e;-><init>(FFF)V

    const/4 v7, 0x7

    const/4 v5, 0x0

    const/4 v7, 0x4

    shr-int/2addr v6, v5

    const/4 v7, 0x4

    aput-object v4, v3, v5

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {p0, v0, v1, v3}, Landroid/animation/ObjectAnimator;->ofObject(Ljava/lang/Object;Landroid/util/Property;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-interface {p0}, Lcom/google/android/material/circularreveal/c;->getRevealInfo()Lcom/google/android/material/circularreveal/c$e;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x6

    if-eqz v1, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget v1, v1, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    check-cast p0, Landroid/view/View;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    float-to-int p1, p1

    const/4 v6, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    float-to-int p2, p2

    invoke-static {p0, p1, p2, v1, p3}, Landroid/view/ViewAnimationUtils;->createCircularReveal(Landroid/view/View;IIFF)Landroid/animation/Animator;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    new-instance p1, Landroid/animation/AnimatorSet;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {p1}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 p2, 0x2

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    new-array p2, p2, [Landroid/animation/Animator;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    aput-object v0, p2, v5

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    aput-object p0, p2, v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p1, p2}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    return-object p1

    :cond_0
    const/4 v7, 0x1

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string/jumbo p1, "hecme ln .nnreC avl la ll-fmnatnrRotsogu seIoi i bfeseuslt"

    const-string/jumbo p1, "euslfeeleathiota ancf lm bi ao uet-o.nn Rvnnser Ilgl lsrCs"

    const/4 v7, 0x6

    const-string p1, "Caller must set a non-null RevealInfo before calling this."

    const/4 v7, 0x7

    const/4 v6, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    throw p0
.end method

.method public static b(Lcom/google/android/material/circularreveal/c;FFFF)Landroid/animation/Animator;
    .locals 9
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    sget-object v0, Lcom/google/android/material/circularreveal/c$c;->a:Landroid/util/Property;

    const/4 v8, 0x6

    const/4 v7, 0x3

    sget-object v1, Lcom/google/android/material/circularreveal/c$b;->b:Landroid/animation/TypeEvaluator;

    const/4 v8, 0x4

    const/4 v2, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-array v3, v2, [Lcom/google/android/material/circularreveal/c$e;

    const/4 v8, 0x3

    const/4 v7, 0x6

    new-instance v4, Lcom/google/android/material/circularreveal/c$e;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {v4, p1, p2, p3}, Lcom/google/android/material/circularreveal/c$e;-><init>(FFF)V

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    const/4 v5, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    aput-object v4, v3, v5

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    new-instance v4, Lcom/google/android/material/circularreveal/c$e;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {v4, p1, p2, p4}, Lcom/google/android/material/circularreveal/c$e;-><init>(FFF)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    xor-int/2addr v8, v7

    aput-object v4, v3, v6

    const/4 v8, 0x3

    const/4 v7, 0x4

    invoke-static {p0, v0, v1, v3}, Landroid/animation/ObjectAnimator;->ofObject(Ljava/lang/Object;Landroid/util/Property;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/ObjectAnimator;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x4

    check-cast p0, Landroid/view/View;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    float-to-int p1, p1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    float-to-int p2, p2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {p0, p1, p2, p3, p4}, Landroid/view/ViewAnimationUtils;->createCircularReveal(Landroid/view/View;IIFF)Landroid/animation/Animator;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    new-instance p1, Landroid/animation/AnimatorSet;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-direct {p1}, Landroid/animation/AnimatorSet;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    new-array p2, v2, [Landroid/animation/Animator;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    aput-object v0, p2, v5

    const/4 v7, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    aput-object p0, p2, v6

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p1, p2}, Landroid/animation/AnimatorSet;->playTogether([Landroid/animation/Animator;)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    return-object p1
.end method

.method public static c(Lcom/google/android/material/circularreveal/c;)Landroid/animation/Animator$AnimatorListener;
    .locals 3
    .param p0    # Lcom/google/android/material/circularreveal/c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/material/circularreveal/a$a;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/google/android/material/circularreveal/a$a;-><init>(Lcom/google/android/material/circularreveal/c;)V

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    return-object v0
.end method
