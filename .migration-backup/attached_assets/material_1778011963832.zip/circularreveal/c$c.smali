.class public Lcom/google/android/material/circularreveal/c$c;
.super Landroid/util/Property;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/circularreveal/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/util/Property<",
        "Lcom/google/android/material/circularreveal/c;",
        "Lcom/google/android/material/circularreveal/c$e;",
        ">;"
    }
.end annotation


# static fields
.field public static final a:Landroid/util/Property;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/Property<",
            "Lcom/google/android/material/circularreveal/c;",
            "Lcom/google/android/material/circularreveal/c$e;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/material/circularreveal/c$c;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string v1, "acsierauceslvr"

    const-string v1, "Rlsrraaeceucvi"

    const/4 v3, 0x5

    const-string/jumbo v1, "euvmrilcacreRl"

    const-string v1, "circularReveal"

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lcom/google/android/material/circularreveal/c$c;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    sput-object v0, Lcom/google/android/material/circularreveal/c$c;->a:Landroid/util/Property;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-class v0, Lcom/google/android/material/circularreveal/c$e;

    const-class v0, Lcom/google/android/material/circularreveal/c$e;

    const/4 v2, 0x6

    const-class v0, Lcom/google/android/material/circularreveal/c$e;

    const-class v0, Lcom/google/android/material/circularreveal/c$e;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, v0, p1}, Landroid/util/Property;-><init>(Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/material/circularreveal/c;)Lcom/google/android/material/circularreveal/c$e;
    .locals 2
    .param p1    # Lcom/google/android/material/circularreveal/c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "f o~o  ~a ~1 d vK ii@ @ @ t@@co. ~~o l@~~~/~~@@lb-oS~ @u@~~ ~@r~@4 ~of~b@bm@syt~@@~ iM~@o~@/~ @@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-interface {p1}, Lcom/google/android/material/circularreveal/c;->getRevealInfo()Lcom/google/android/material/circularreveal/c$e;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p1
.end method

.method public b(Lcom/google/android/material/circularreveal/c;Lcom/google/android/material/circularreveal/c$e;)V
    .locals 2
    .param p1    # Lcom/google/android/material/circularreveal/c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/circularreveal/c$e;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-interface {p1, p2}, Lcom/google/android/material/circularreveal/c;->setRevealInfo(Lcom/google/android/material/circularreveal/c$e;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public bridge synthetic get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    check-cast p1, Lcom/google/android/material/circularreveal/c;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/circularreveal/c$c;->a(Lcom/google/android/material/circularreveal/c;)Lcom/google/android/material/circularreveal/c$e;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p1
.end method

.method public bridge synthetic set(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x5

    check-cast p1, Lcom/google/android/material/circularreveal/c;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    check-cast p2, Lcom/google/android/material/circularreveal/c$e;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/circularreveal/c$c;->b(Lcom/google/android/material/circularreveal/c;Lcom/google/android/material/circularreveal/c$e;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method
