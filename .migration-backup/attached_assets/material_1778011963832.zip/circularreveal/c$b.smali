.class public Lcom/google/android/material/circularreveal/c$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/TypeEvaluator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/circularreveal/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/animation/TypeEvaluator<",
        "Lcom/google/android/material/circularreveal/c$e;",
        ">;"
    }
.end annotation


# static fields
.field public static final b:Landroid/animation/TypeEvaluator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/animation/TypeEvaluator<",
            "Lcom/google/android/material/circularreveal/c$e;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final a:Lcom/google/android/material/circularreveal/c$e;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lcom/google/android/material/circularreveal/c$b;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/google/android/material/circularreveal/c$b;-><init>()V

    const/4 v1, 0x1

    const/4 v1, 0x6

    sput-object v0, Lcom/google/android/material/circularreveal/c$b;->b:Landroid/animation/TypeEvaluator;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    move v3, v2

    new-instance v0, Lcom/google/android/material/circularreveal/c$e;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lcom/google/android/material/circularreveal/c$e;-><init>(Lcom/google/android/material/circularreveal/c$a;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/android/material/circularreveal/c$b;->a:Lcom/google/android/material/circularreveal/c$e;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method


# virtual methods
.method public a(FLcom/google/android/material/circularreveal/c$e;Lcom/google/android/material/circularreveal/c$e;)Lcom/google/android/material/circularreveal/c$e;
    .locals 6
    .param p2    # Lcom/google/android/material/circularreveal/c$e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/circularreveal/c$e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "o~s@-  ~@m/ lvs a dSyoo @~ fl~~ ~i~@~c~~b  t@~M~i~ ~@@~@ ~~@~f@~@ruK. 4 ~@ /@@  1i@o@n~t@~bob@@o"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/circularreveal/c$b;->a:Lcom/google/android/material/circularreveal/c$e;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget v1, p2, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget v2, p3, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v1, v2, p1}, Lu4/a;->f(FFF)F

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget v2, p2, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget v3, p3, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v2, v3, p1}, Lu4/a;->f(FFF)F

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget p2, p2, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v4, 0x6

    move v5, v4

    iget p3, p3, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p2, p3, p1}, Lu4/a;->f(FFF)F

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2, p1}, Lcom/google/android/material/circularreveal/c$e;->b(FFF)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/google/android/material/circularreveal/c$b;->a:Lcom/google/android/material/circularreveal/c$e;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-object p1
.end method

.method public bridge synthetic evaluate(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    check-cast p2, Lcom/google/android/material/circularreveal/c$e;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    check-cast p3, Lcom/google/android/material/circularreveal/c$e;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/material/circularreveal/c$b;->a(FLcom/google/android/material/circularreveal/c$e;Lcom/google/android/material/circularreveal/c$e;)Lcom/google/android/material/circularreveal/c$e;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method
