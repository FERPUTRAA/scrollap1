.class public Lcom/google/android/material/circularreveal/b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/circularreveal/b$b;,
        Lcom/google/android/material/circularreveal/b$a;
    }
.end annotation


# static fields
.field private static final k:Z = false

.field public static final l:I = 0x0

.field public static final m:I = 0x1

.field public static final n:I = 0x2

.field public static final o:I


# instance fields
.field private final a:Lcom/google/android/material/circularreveal/b$a;

.field private final b:Landroid/view/View;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final c:Landroid/graphics/Path;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final d:Landroid/graphics/Paint;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final e:Landroid/graphics/Paint;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private f:Lcom/google/android/material/circularreveal/c$e;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private g:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private h:Landroid/graphics/Paint;

.field private i:Z

.field private j:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    const/4 v0, 0x2

    move v2, v0

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    sput v0, Lcom/google/android/material/circularreveal/b;->o:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Lcom/google/android/material/circularreveal/b$a;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/google/android/material/circularreveal/b;->a:Lcom/google/android/material/circularreveal/b$a;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast p1, Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v0, 0x5

    move v3, v0

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setWillNotDraw(Z)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance p1, Landroid/graphics/Path;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/google/android/material/circularreveal/b;->c:Landroid/graphics/Path;

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    new-instance p1, Landroid/graphics/Paint;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x7

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p1, v1}, Landroid/graphics/Paint;-><init>(I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/google/android/material/circularreveal/b;->d:Landroid/graphics/Paint;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance p1, Landroid/graphics/Paint;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x1

    xor-int/2addr v3, v1

    const/4 v2, 0x3

    move v3, v2

    invoke-direct {p1, v1}, Landroid/graphics/Paint;-><init>(I)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/google/android/material/circularreveal/b;->e:Landroid/graphics/Paint;

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method private d(Landroid/graphics/Canvas;IF)V
    .locals 5
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "i~s@@  @@oos@v  1@~/oSro~~n~~@d@ ~~ob ~ ~~yf-~b~.u@lm bot@@@M i/ @~ @ ~~~@4@~l@ ~a@~  Kc ~~if@@t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->h:Landroid/graphics/Paint;

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, p2}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    iget-object p2, p0, Lcom/google/android/material/circularreveal/b;->h:Landroid/graphics/Paint;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v4, 0x4

    iget-object p2, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget v0, p2, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v4, 0x0

    const/4 v3, 0x4

    iget v1, p2, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget p2, p2, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    div-float/2addr p3, v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    sub-float/2addr p2, p3

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object p3, p0, Lcom/google/android/material/circularreveal/b;->h:Landroid/graphics/Paint;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1, p2, p3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method

.method private e(Landroid/graphics/Canvas;)V
    .locals 6
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->a:Lcom/google/android/material/circularreveal/b$a;

    const/4 v4, 0x5

    move v5, v4

    invoke-interface {v0, p1}, Lcom/google/android/material/circularreveal/b$a;->c(Landroid/graphics/Canvas;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {p0}, Lcom/google/android/material/circularreveal/b;->r()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget v1, v0, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v4, 0x0

    move v5, v4

    iget v2, v0, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget v0, v0, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v4, 0x0

    or-int/2addr v5, v4

    iget-object v3, p0, Lcom/google/android/material/circularreveal/b;->e:Landroid/graphics/Paint;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p1, v1, v2, v0, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/android/material/circularreveal/b;->p()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/high16 v0, -0x1000000

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/high16 v1, 0x41200000    # 10.0f

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {p0, p1, v0, v1}, Lcom/google/android/material/circularreveal/b;->d(Landroid/graphics/Canvas;IF)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/high16 v0, -0x10000

    const/4 v5, 0x5

    const/high16 v1, 0x40a00000    # 5.0f

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {p0, p1, v0, v1}, Lcom/google/android/material/circularreveal/b;->d(Landroid/graphics/Canvas;IF)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/circularreveal/b;->f(Landroid/graphics/Canvas;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-void
.end method

.method private f(Landroid/graphics/Canvas;)V
    .locals 6
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x0

    move v5, v4

    invoke-direct {p0}, Lcom/google/android/material/circularreveal/b;->q()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->g:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget v1, v1, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/graphics/Rect;->width()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    int-to-float v2, v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/high16 v3, 0x40000000    # 2.0f

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    div-float/2addr v2, v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    sub-float/2addr v1, v2

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget v2, v2, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/graphics/Rect;->height()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    int-to-float v0, v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    div-float/2addr v0, v3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    sub-float/2addr v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p1, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->g:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    neg-float v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    neg-float v1, v2

    const/4 v5, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->translate(FF)V

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method

.method private i(Lcom/google/android/material/circularreveal/c$e;)F
    .locals 8
    .param p1    # Lcom/google/android/material/circularreveal/c$e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x2

    const/4 v6, 0x0

    iget v0, p1, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v6, 0x7

    move v7, v6

    iget v1, p1, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 v2, 0x0

    const/4 v7, 0x0

    const/4 v3, 0x7

    const/4 v7, 0x1

    const/4 v3, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object p1, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    int-to-float v4, p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object p1, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    int-to-float v5, p1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static/range {v0 .. v5}, Lu4/a;->b(FFFFFF)F

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    return p1
.end method

.method private k()V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    sget v0, Lcom/google/android/material/circularreveal/b;->o:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-ne v0, v1, :cond_0

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->c:Landroid/graphics/Path;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/graphics/Path;->rewind()V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/android/material/circularreveal/b;->c:Landroid/graphics/Path;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget v2, v0, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget v3, v0, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v6, 0x5

    const/4 v5, 0x2

    iget v0, v0, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    sget-object v4, Landroid/graphics/Path$Direction;->CW:Landroid/graphics/Path$Direction;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v1, v2, v3, v0, v4}, Landroid/graphics/Path;->addCircle(FFFLandroid/graphics/Path$Direction;)V

    :cond_0
    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v5, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-void
.end method

.method private p()Z
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/circularreveal/c$e;->a()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    move v0, v1

    const/4 v5, 0x4

    move v0, v1

    move v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v4, 0x2

    const/4 v5, 0x2

    move v0, v2

    move v0, v2

    const/4 v5, 0x2

    move v0, v2

    move v0, v2

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget v3, Lcom/google/android/material/circularreveal/b;->o:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-nez v3, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x7

    if-nez v0, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/circularreveal/b;->j:Z

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    :cond_2
    const/4 v5, 0x7

    return v1

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    xor-int/2addr v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    return v0
.end method

.method private q()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/circularreveal/b;->i:Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->g:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method private r()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/circularreveal/b;->i:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->e:Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/graphics/Paint;->getColor()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0}, Landroid/graphics/Color;->alpha(I)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    move v2, v1

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method


# virtual methods
.method public a()V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    sget v0, Lcom/google/android/material/circularreveal/b;->o:I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-nez v0, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 v0, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput-boolean v0, p0, Lcom/google/android/material/circularreveal/b;->i:Z

    const/4 v6, 0x5

    shl-int/2addr v7, v6

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    iput-boolean v1, p0, Lcom/google/android/material/circularreveal/b;->j:Z

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v7, 0x7

    invoke-virtual {v2}, Landroid/view/View;->buildDrawingCache()V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v2}, Landroid/view/View;->getDrawingCache()Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-nez v2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v7, 0x5

    const/4 v6, 0x1

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz v3, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz v3, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget-object v4, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/4 v7, 0x7

    invoke-static {v2, v3, v4}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance v3, Landroid/graphics/Canvas;

    const/4 v7, 0x4

    invoke-direct {v3, v2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v4, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v4, v3}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v2, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v3, p0, Lcom/google/android/material/circularreveal/b;->d:Landroid/graphics/Paint;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-instance v4, Landroid/graphics/BitmapShader;

    const/4 v6, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    sget-object v5, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {v4, v2, v5, v5}, Landroid/graphics/BitmapShader;-><init>(Landroid/graphics/Bitmap;Landroid/graphics/Shader$TileMode;Landroid/graphics/Shader$TileMode;)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    :cond_1
    const/4 v7, 0x5

    iput-boolean v1, p0, Lcom/google/android/material/circularreveal/b;->i:Z

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    iput-boolean v0, p0, Lcom/google/android/material/circularreveal/b;->j:Z

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    return-void
.end method

.method public b()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/circularreveal/b;->o:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-boolean v0, p0, Lcom/google/android/material/circularreveal/b;->j:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/view/View;->destroyDrawingCache()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->d:Landroid/graphics/Paint;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method public c(Landroid/graphics/Canvas;)V
    .locals 10
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v9, 0x0

    invoke-direct {p0}, Lcom/google/android/material/circularreveal/b;->p()Z

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-eqz v0, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    sget v0, Lcom/google/android/material/circularreveal/b;->o:I

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-eqz v0, :cond_3

    const/4 v8, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v1, 0x1

    const/4 v9, 0x1

    if-eq v0, v1, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/4 v1, 0x2

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-ne v0, v1, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->a:Lcom/google/android/material/circularreveal/b$a;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-interface {v0, p1}, Lcom/google/android/material/circularreveal/b$a;->c(Landroid/graphics/Canvas;)V

    const/4 v8, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-direct {p0}, Lcom/google/android/material/circularreveal/b;->r()Z

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eqz v0, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    const/4 v3, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    int-to-float v4, v0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v8, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    int-to-float v5, v0

    const/4 v8, 0x2

    move v9, v8

    iget-object v6, p0, Lcom/google/android/material/circularreveal/b;->e:Landroid/graphics/Paint;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    goto/16 :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string v2, " tdmpng stryrptoaUese"

    const-string/jumbo v2, "rtsp aseo etnpgdyUrst"

    const/4 v9, 0x0

    const-string v2, "erp osgpaU nsdottyurt"

    const-string v2, "Unsupported strategy "

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v8, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x0

    throw p1

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/google/android/material/circularreveal/b;->c:Landroid/graphics/Path;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->clipPath(Landroid/graphics/Path;)Z

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/google/android/material/circularreveal/b;->a:Lcom/google/android/material/circularreveal/b$a;

    const/4 v9, 0x0

    invoke-interface {v1, p1}, Lcom/google/android/material/circularreveal/b$a;->c(Landroid/graphics/Canvas;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-direct {p0}, Lcom/google/android/material/circularreveal/b;->r()Z

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-eqz v1, :cond_2

    const/4 v9, 0x3

    const/4 v3, 0x0

    const/4 v9, 0x1

    move v8, v3

    move v8, v3

    const/4 v9, 0x1

    const/4 v4, 0x0

    const/4 v9, 0x4

    const/4 v4, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    int-to-float v5, v1

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    int-to-float v6, v1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object v7, p0, Lcom/google/android/material/circularreveal/b;->e:Landroid/graphics/Paint;

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->restoreToCount(I)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    goto/16 :goto_0

    :cond_3
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v8, 0x6

    move v9, v8

    iget v1, v0, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget v2, v0, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v8, 0x4

    and-int/2addr v9, v8

    iget v0, v0, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v3, p0, Lcom/google/android/material/circularreveal/b;->d:Landroid/graphics/Paint;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p1, v1, v2, v0, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-direct {p0}, Lcom/google/android/material/circularreveal/b;->r()Z

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x6

    if-eqz v0, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v9, 0x1

    iget v1, v0, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget v2, v0, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget v0, v0, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    iget-object v3, p0, Lcom/google/android/material/circularreveal/b;->e:Landroid/graphics/Paint;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {p1, v1, v2, v0, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    goto :goto_0

    :cond_4
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->a:Lcom/google/android/material/circularreveal/b$a;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-interface {v0, p1}, Lcom/google/android/material/circularreveal/b$a;->c(Landroid/graphics/Canvas;)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-direct {p0}, Lcom/google/android/material/circularreveal/b;->r()Z

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-eqz v0, :cond_5

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    const/4 v2, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 v3, 0x0

    const/4 v8, 0x2

    and-int/2addr v9, v8

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    const/4 v9, 0x0

    int-to-float v4, v0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x3

    int-to-float v5, v0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-object v6, p0, Lcom/google/android/material/circularreveal/b;->e:Landroid/graphics/Paint;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual/range {v1 .. v6}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    :cond_5
    :goto_0
    const/4 v8, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/material/circularreveal/b;->f(Landroid/graphics/Canvas;)V

    const/4 v8, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    return-void
.end method

.method public g()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->g:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public h()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->e:Landroid/graphics/Paint;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/graphics/Paint;->getColor()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public j()Lcom/google/android/material/circularreveal/c$e;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x2

    move v2, v0

    move v2, v0

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    new-instance v1, Lcom/google/android/material/circularreveal/c$e;

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-direct {v1, v0}, Lcom/google/android/material/circularreveal/c$e;-><init>(Lcom/google/android/material/circularreveal/c$e;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v1}, Lcom/google/android/material/circularreveal/c$e;->a()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0, v1}, Lcom/google/android/material/circularreveal/b;->i(Lcom/google/android/material/circularreveal/c$e;)F

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput v0, v1, Lcom/google/android/material/circularreveal/c$e;->c:F

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v1
.end method

.method public l()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->a:Lcom/google/android/material/circularreveal/b$a;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0}, Lcom/google/android/material/circularreveal/b$a;->d()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/circularreveal/b;->p()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public m(Landroid/graphics/drawable/Drawable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/google/android/material/circularreveal/b;->g:Landroid/graphics/drawable/Drawable;

    const/4 v0, 0x6

    const/4 v0, 0x5

    iget-object p1, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v0, 0x0

    move v1, v0

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public n(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->e:Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v1, 0x4

    or-int/2addr v2, v1

    iget-object p1, p0, Lcom/google/android/material/circularreveal/b;->b:Landroid/view/View;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public o(Lcom/google/android/material/circularreveal/c$e;)V
    .locals 4
    .param p1    # Lcom/google/android/material/circularreveal/c$e;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/material/circularreveal/c$e;

    const/4 v2, 0x7

    or-int/2addr v3, v2

    invoke-direct {v0, p1}, Lcom/google/android/material/circularreveal/c$e;-><init>(Lcom/google/android/material/circularreveal/c$e;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/circularreveal/c$e;->c(Lcom/google/android/material/circularreveal/c$e;)V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget v0, p1, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/circularreveal/b;->i(Lcom/google/android/material/circularreveal/c$e;)F

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    const v1, 0x38d1b717    # 1.0E-4f

    const/4 v3, 0x5

    invoke-static {v0, p1, v1}, Lu4/a;->e(FFF)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p1, :cond_2

    const/4 v2, 0x0

    move v3, v2

    iget-object p1, p0, Lcom/google/android/material/circularreveal/b;->f:Lcom/google/android/material/circularreveal/c$e;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    const v0, 0x7f7fffff    # Float.MAX_VALUE

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput v0, p1, Lcom/google/android/material/circularreveal/c$e;->c:F

    :cond_2
    :goto_1
    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/android/material/circularreveal/b;->k()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method
