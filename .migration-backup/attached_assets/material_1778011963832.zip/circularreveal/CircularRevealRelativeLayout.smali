.class public Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;
.super Landroid/widget/RelativeLayout;

# interfaces
.implements Lcom/google/android/material/circularreveal/c;


# instance fields
.field private final a:Lcom/google/android/material/circularreveal/b;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    new-instance p1, Lcom/google/android/material/circularreveal/b;

    const/4 v1, 0x4

    const/4 v0, 0x4

    invoke-direct {p1, p0}, Lcom/google/android/material/circularreveal/b;-><init>(Lcom/google/android/material/circularreveal/b$a;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;->a:Lcom/google/android/material/circularreveal/b;

    const/4 v0, 0x1

    shl-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "c~s   ~~ ~i @~@d~u@@  o ~m/~ ~o @Str  @@@1o~ i ~tM~Kb a@~@@4~@@/@yb~~@.llsf~f~o~-v@i~~@@o~@ bn@o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;->a:Lcom/google/android/material/circularreveal/b;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/circularreveal/b;->a()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public b()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;->a:Lcom/google/android/material/circularreveal/b;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/circularreveal/b;->b()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public c(Landroid/graphics/Canvas;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-super {p0, p1}, Landroid/widget/RelativeLayout;->draw(Landroid/graphics/Canvas;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public d()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-super {p0}, Landroid/widget/RelativeLayout;->isOpaque()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 3
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;->a:Lcom/google/android/material/circularreveal/b;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/circularreveal/b;->c(Landroid/graphics/Canvas;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroid/widget/RelativeLayout;->draw(Landroid/graphics/Canvas;)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public getCircularRevealOverlayDrawable()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;->a:Lcom/google/android/material/circularreveal/b;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/circularreveal/b;->g()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public getCircularRevealScrimColor()I
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;->a:Lcom/google/android/material/circularreveal/b;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/circularreveal/b;->h()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public getRevealInfo()Lcom/google/android/material/circularreveal/c$e;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;->a:Lcom/google/android/material/circularreveal/b;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/circularreveal/b;->j()Lcom/google/android/material/circularreveal/c$e;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public isOpaque()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;->a:Lcom/google/android/material/circularreveal/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/circularreveal/b;->l()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-super {p0}, Landroid/widget/RelativeLayout;->isOpaque()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public setCircularRevealOverlayDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;->a:Lcom/google/android/material/circularreveal/b;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/circularreveal/b;->m(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x1

    return-void
.end method

.method public setCircularRevealScrimColor(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;->a:Lcom/google/android/material/circularreveal/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/circularreveal/b;->n(I)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public setRevealInfo(Lcom/google/android/material/circularreveal/c$e;)V
    .locals 3
    .param p1    # Lcom/google/android/material/circularreveal/c$e;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x4

    iget-object v0, p0, Lcom/google/android/material/circularreveal/CircularRevealRelativeLayout;->a:Lcom/google/android/material/circularreveal/b;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/circularreveal/b;->o(Lcom/google/android/material/circularreveal/c$e;)V

    const/4 v2, 0x7

    return-void
.end method
