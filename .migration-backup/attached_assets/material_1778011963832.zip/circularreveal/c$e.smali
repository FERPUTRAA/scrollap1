.class public Lcom/google/android/material/circularreveal/c$e;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/circularreveal/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# static fields
.field public static final d:F = 3.4028235E38f


# instance fields
.field public a:F

.field public b:F

.field public c:F


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>(FFF)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p2, p0, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p3, p0, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/material/circularreveal/c$a;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/material/circularreveal/c$e;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    return-void
.end method

.method public constructor <init>(Lcom/google/android/material/circularreveal/c$e;)V
    .locals 4
    .param p1    # Lcom/google/android/material/circularreveal/c$e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v2, 0x1

    iget v0, p1, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v1, p1, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v3, 0x4

    const/4 v2, 0x0

    iget p1, p1, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-direct {p0, v0, v1, p1}, Lcom/google/android/material/circularreveal/c$e;-><init>(FFF)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  s@l~s @ ~~.~ 4 i~@@~~~~olb@r@1/~to- @@~ ~@~ fo~@ @~mo@n@ @ if @cy~~Kia/b~ @~ ~v@uo~d o btM@~@S"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const v1, 0x7f7fffff    # Float.MAX_VALUE

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    cmpl-float v0, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public b(FFF)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p2, p0, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v0, 0x2

    move v1, v0

    iput p3, p0, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public c(Lcom/google/android/material/circularreveal/c$e;)V
    .locals 4
    .param p1    # Lcom/google/android/material/circularreveal/c$e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v0, p1, Lcom/google/android/material/circularreveal/c$e;->a:F

    const/4 v3, 0x4

    const/4 v2, 0x7

    iget v1, p1, Lcom/google/android/material/circularreveal/c$e;->b:F

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget p1, p1, Lcom/google/android/material/circularreveal/c$e;->c:F

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/android/material/circularreveal/c$e;->b(FFF)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method
