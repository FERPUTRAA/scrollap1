.class Lcom/google/android/material/behavior/SwipeDismissBehavior$d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/behavior/SwipeDismissBehavior;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "d"
.end annotation


# instance fields
.field private final a:Landroid/view/View;

.field private final b:Z

.field final synthetic c:Lcom/google/android/material/behavior/SwipeDismissBehavior;


# direct methods
.method constructor <init>(Lcom/google/android/material/behavior/SwipeDismissBehavior;Landroid/view/View;Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$d;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$d;->a:Landroid/view/View;

    const/4 v0, 0x2

    shr-int/2addr v1, v0

    iput-boolean p3, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$d;->b:Z

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "y~sf  ~~@dr~b@ ~toum@ @b~~@i @o1 @ ~@ c  ~@.~@~i~f @~b@/So@l  /@~4 @@i ~@o-o~M ~l to@~Kn~s@~@a~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$d;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->a:Landroidx/customview/widget/d;

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, v1}, Landroidx/customview/widget/d;->o(Z)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$d;->a:Landroid/view/View;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, p0}, Landroidx/core/view/k1;->p1(Landroid/view/View;Ljava/lang/Runnable;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$d;->b:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$d;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v2, 0x3

    and-int/2addr v3, v2

    iget-object v0, v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->b:Lcom/google/android/material/behavior/SwipeDismissBehavior$c;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$d;->a:Landroid/view/View;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Lcom/google/android/material/behavior/SwipeDismissBehavior$c;->a(Landroid/view/View;)V

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method
