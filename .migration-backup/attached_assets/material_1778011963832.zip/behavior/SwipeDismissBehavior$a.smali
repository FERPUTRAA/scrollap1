.class Lcom/google/android/material/behavior/SwipeDismissBehavior$a;
.super Landroidx/customview/widget/d$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/behavior/SwipeDismissBehavior;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# static fields
.field private static final d:I = -0x1


# instance fields
.field private a:I

.field private b:I

.field final synthetic c:Lcom/google/android/material/behavior/SwipeDismissBehavior;


# direct methods
.method constructor <init>(Lcom/google/android/material/behavior/SwipeDismissBehavior;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Landroidx/customview/widget/d$c;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, -0x1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method private n(Landroid/view/View;F)Z
    .locals 8
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "a-srf ~ @b ~~ob~@Kol~@m u~ oMy~/cid~~@i@~ @s~~ i@@ @~o@/1  n @@~t@ to@@ .~~@@@  o~lfSv@4~~b~@~~ "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    cmpl-float v1, p2, v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v1, :cond_7

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {p1}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-ne p1, v3, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    move p1, v3

    move p1, v3

    const/4 v7, 0x4

    move p1, v3

    move p1, v3

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    move p1, v2

    move p1, v2

    const/4 v7, 0x6

    move p1, v2

    move p1, v2

    :goto_0
    const/4 v7, 0x6

    iget-object v4, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget v4, v4, Lcom/google/android/material/behavior/SwipeDismissBehavior;->f:I

    const/4 v7, 0x0

    const/4 v5, 0x2

    const/4 v7, 0x2

    move v6, v5

    move v6, v5

    const/4 v7, 0x1

    if-ne v4, v5, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    return v3

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-nez v4, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz p1, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    cmpg-float p1, p2, v0

    const/4 v6, 0x2

    shl-int/2addr v7, v6

    if-gez p1, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto :goto_1

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-lez v1, :cond_3

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    move v2, v3

    move v2, v3

    const/4 v7, 0x7

    move v2, v3

    move v2, v3

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    return v2

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-ne v4, v3, :cond_6

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz p1, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-lez v1, :cond_6

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto :goto_2

    :cond_5
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    cmpg-float p1, p2, v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-gez p1, :cond_6

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    move v2, v3

    move v2, v3

    :cond_6
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    return v2

    :cond_7
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    sub-int/2addr p2, v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    int-to-float p1, p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget v0, v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->g:F

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    mul-float/2addr p1, v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result p2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-lt p2, p1, :cond_8

    const/4 v6, 0x3

    move v7, v6

    move v2, v3

    const/4 v7, 0x2

    move v2, v3

    move v2, v3

    :cond_8
    const/4 v6, 0x7

    move v7, v6

    return v2
.end method


# virtual methods
.method public a(Landroid/view/View;II)I
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p1}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result p3

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne p3, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    move p3, v0

    move p3, v0

    const/4 v3, 0x4

    move p3, v0

    move p3, v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p3, 0x0

    :goto_0
    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, v1, Lcom/google/android/material/behavior/SwipeDismissBehavior;->f:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz p3, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget p3, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    sub-int/2addr p3, p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_2

    :cond_1
    const/4 v3, 0x6

    iget p3, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    add-int/2addr p1, p3

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_2

    :cond_2
    const/4 v2, 0x5

    move v3, v2

    if-ne v1, v0, :cond_4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz p3, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget p3, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_1

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget p3, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    sub-int/2addr p3, p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_2

    :cond_4
    const/4 v3, 0x3

    iget p3, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    sub-int/2addr p3, v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    add-int/2addr p1, v0

    :goto_2
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p3, p2, p1}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->c(III)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    return p1
.end method

.method public b(Landroid/view/View;II)I
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p1
.end method

.method public d(Landroid/view/View;)I
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    return p1
.end method

.method public i(Landroid/view/View;I)V
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p2, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p2, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p2, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-interface {p1, p2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public j(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->b:Lcom/google/android/material/behavior/SwipeDismissBehavior$c;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lcom/google/android/material/behavior/SwipeDismissBehavior$c;->b(I)V

    :cond_0
    const/4 v2, 0x4

    return-void
.end method

.method public k(Landroid/view/View;IIII)V
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget p3, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v3, 0x4

    int-to-float p3, p3

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    int-to-float p4, p4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object p5, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget p5, p5, Lcom/google/android/material/behavior/SwipeDismissBehavior;->h:F

    const/4 v3, 0x1

    mul-float/2addr p4, p5

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    add-float/2addr p3, p4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget p4, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    int-to-float p4, p4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p5

    const/4 v3, 0x7

    const/4 v2, 0x6

    int-to-float p5, p5

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget v0, v0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->i:F

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    mul-float/2addr p5, v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    add-float/2addr p4, p5

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    int-to-float p2, p2

    const/4 v3, 0x1

    cmpg-float p5, p2, p3

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-gtz p5, :cond_0

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/view/View;->setAlpha(F)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    cmpl-float p5, p2, p4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-ltz p5, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1, v1}, Landroid/view/View;->setAlpha(F)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p3, p4, p2}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->e(FFF)F

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    sub-float p2, v0, p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v1, p2, v0}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->b(FFF)F

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->setAlpha(F)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public l(Landroid/view/View;FF)V
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 p3, -0x1

    move v2, p3

    move v2, p3

    const/4 v3, 0x2

    iput p3, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->b:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->n(Landroid/view/View;F)Z

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p2, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getLeft()I

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    if-ge p2, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    sub-int/2addr v0, p3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    add-int/2addr v0, p3

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p2, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->a:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p2, 0x0

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object p3, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object p3, p3, Lcom/google/android/material/behavior/SwipeDismissBehavior;->a:Landroidx/customview/widget/d;

    const/4 v2, 0x6

    or-int/2addr v3, v2

    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p3, v0, v1}, Landroidx/customview/widget/d;->V(II)Z

    move-result p3

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p3, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance p3, Lcom/google/android/material/behavior/SwipeDismissBehavior$d;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p3, v0, p1, p2}, Lcom/google/android/material/behavior/SwipeDismissBehavior$d;-><init>(Lcom/google/android/material/behavior/SwipeDismissBehavior;Landroid/view/View;Z)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1, p3}, Landroidx/core/view/k1;->p1(Landroid/view/View;Ljava/lang/Runnable;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_2

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz p2, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object p2, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v3, 0x3

    const/4 v2, 0x2

    iget-object p2, p2, Lcom/google/android/material/behavior/SwipeDismissBehavior;->b:Lcom/google/android/material/behavior/SwipeDismissBehavior$c;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p2, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {p2, p1}, Lcom/google/android/material/behavior/SwipeDismissBehavior$c;->a(Landroid/view/View;)V

    :cond_3
    :goto_2
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public m(Landroid/view/View;I)Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eq v0, v1, :cond_0

    const/4 v3, 0x7

    if-ne v0, p2, :cond_1

    :cond_0
    const/4 v2, 0x7

    move v3, v2

    iget-object p2, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;->c:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p2, p1}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->a(Landroid/view/View;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 p1, 0x1

    const/4 v3, 0x6

    move v2, p1

    move v2, p1

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return p1
.end method
