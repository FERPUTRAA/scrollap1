.class Lcom/google/android/material/behavior/SwipeDismissBehavior$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/view/accessibility/s0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/behavior/SwipeDismissBehavior;->n(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/behavior/SwipeDismissBehavior;


# direct methods
.method constructor <init>(Lcom/google/android/material/behavior/SwipeDismissBehavior;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$b;->a:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public perform(Landroid/view/View;Landroidx/core/view/accessibility/s0$a;)Z
    .locals 5
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/core/view/accessibility/s0$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object p2, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$b;->a:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2, p1}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->a(Landroid/view/View;)Z

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x1

    if-eqz p2, :cond_6

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p1}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ne p2, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    move p2, v1

    move p2, v1

    const/4 v4, 0x2

    move p2, v1

    move p2, v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    move p2, v0

    move p2, v0

    const/4 v4, 0x3

    move p2, v0

    move p2, v0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$b;->a:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget v2, v2, Lcom/google/android/material/behavior/SwipeDismissBehavior;->f:I

    if-nez v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez p2, :cond_2

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-ne v2, v1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-nez p2, :cond_3

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    move v0, v1

    move v0, v1

    const/4 v4, 0x0

    move v0, v1

    move v0, v1

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    neg-int p2, p2

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-static {p1, p2}, Landroidx/core/view/k1;->e1(Landroid/view/View;I)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 p2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Landroid/view/View;->setAlpha(F)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object p2, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior$b;->a:Lcom/google/android/material/behavior/SwipeDismissBehavior;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object p2, p2, Lcom/google/android/material/behavior/SwipeDismissBehavior;->b:Lcom/google/android/material/behavior/SwipeDismissBehavior$c;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz p2, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {p2, p1}, Lcom/google/android/material/behavior/SwipeDismissBehavior$c;->a(Landroid/view/View;)V

    :cond_5
    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    return v1

    :cond_6
    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    return v0
.end method
