.class public Lcom/google/android/material/behavior/SwipeDismissBehavior;
.super Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/behavior/SwipeDismissBehavior$d;,
        Lcom/google/android/material/behavior/SwipeDismissBehavior$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "Landroid/view/View;",
        ">",
        "Landroidx/coordinatorlayout/widget/CoordinatorLayout$c<",
        "TV;>;"
    }
.end annotation


# static fields
.field public static final k:I = 0x0

.field public static final l:I = 0x1

.field public static final m:I = 0x2

.field public static final n:I = 0x0

.field public static final o:I = 0x1

.field public static final p:I = 0x2

.field private static final q:F = 0.5f

.field private static final r:F = 0.0f

.field private static final s:F = 0.5f


# instance fields
.field a:Landroidx/customview/widget/d;

.field b:Lcom/google/android/material/behavior/SwipeDismissBehavior$c;

.field private c:Z

.field private d:F

.field private e:Z

.field f:I

.field g:F

.field h:F

.field i:F

.field private final j:Landroidx/customview/widget/d$c;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;-><init>()V

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->d:F

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x2

    const/4 v3, 0x3

    iput v1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->f:I

    const/4 v2, 0x4

    move v3, v2

    const/high16 v1, 0x3f000000    # 0.5f

    const/4 v2, 0x0

    move v3, v2

    iput v1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->g:F

    const/4 v3, 0x5

    iput v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->h:F

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput v1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->i:F

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v0, p0}, Lcom/google/android/material/behavior/SwipeDismissBehavior$a;-><init>(Lcom/google/android/material/behavior/SwipeDismissBehavior;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->j:Landroidx/customview/widget/d$c;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method static b(FFF)F
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "S sl~- @.o~~b~~i~@@~@@~oio ~m~@bi~  ~u@@@1~yM~4@@@r novo~Kb  f~ @o@@@l/  c~s~  ~d@t@  ~t~@/@ ~f "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-static {p0, p1}, Ljava/lang/Math;->max(FF)F

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p0, p2}, Ljava/lang/Math;->min(FF)F

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return p0
.end method

.method static c(III)I
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p0, p1}, Ljava/lang/Math;->max(II)I

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p0, p2}, Ljava/lang/Math;->min(II)I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    return p0
.end method

.method private d(Landroid/view/ViewGroup;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->a:Landroidx/customview/widget/d;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->e:Z

    const/4 v3, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->d:F

    const/4 v2, 0x4

    move v3, v2

    iget-object v1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->j:Landroidx/customview/widget/d$c;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p1, v0, v1}, Landroidx/customview/widget/d;->p(Landroid/view/ViewGroup;FLandroidx/customview/widget/d$c;)Landroidx/customview/widget/d;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->j:Landroidx/customview/widget/d$c;

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1, v0}, Landroidx/customview/widget/d;->q(Landroid/view/ViewGroup;Landroidx/customview/widget/d$c;)Landroidx/customview/widget/d;

    move-result-object p1

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->a:Landroidx/customview/widget/d;

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method static e(FFF)F
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    sub-float/2addr p2, p0

    const/4 v1, 0x2

    sub-float/2addr p1, p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    div-float/2addr p2, p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p2
.end method

.method private n(Landroid/view/View;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/high16 v0, 0x100000

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {p1, v0}, Landroidx/core/view/k1;->r1(Landroid/view/View;I)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->a(Landroid/view/View;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    sget-object v0, Landroidx/core/view/accessibility/l0$a;->z:Landroidx/core/view/accessibility/l0$a;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v1, Lcom/google/android/material/behavior/SwipeDismissBehavior$b;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v1, p0}, Lcom/google/android/material/behavior/SwipeDismissBehavior$b;-><init>(Lcom/google/android/material/behavior/SwipeDismissBehavior;)V

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p1, v0, v2, v1}, Landroidx/core/view/k1;->u1(Landroid/view/View;Landroidx/core/view/accessibility/l0$a;Ljava/lang/CharSequence;Landroidx/core/view/accessibility/s0;)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;)Z
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x3

    return p1
.end method

.method public f()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->a:Landroidx/customview/widget/d;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroidx/customview/widget/d;->F()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public g()Lcom/google/android/material/behavior/SwipeDismissBehavior$c;
    .locals 3
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->b:Lcom/google/android/material/behavior/SwipeDismissBehavior$c;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public h(F)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0, p1, v1}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->b(FFF)F

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->g:F

    return-void
.end method

.method public i(F)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0, p1, v1}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->b(FFF)F

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->i:F

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public j(Lcom/google/android/material/behavior/SwipeDismissBehavior$c;)V
    .locals 2
    .param p1    # Lcom/google/android/material/behavior/SwipeDismissBehavior$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->b:Lcom/google/android/material/behavior/SwipeDismissBehavior$c;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public k(F)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->d:F

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->e:Z

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public l(F)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/high16 v1, 0x3f800000    # 1.0f

    const/4 v3, 0x5

    invoke-static {v0, p1, v1}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->b(FFF)F

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->h:F

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public m(I)V
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    iput p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->f:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public onInterceptTouchEvent(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 5
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/MotionEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/view/MotionEvent;",
            ")Z"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->c:Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 p2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eq v1, p2, :cond_0

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 p2, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eq v1, p2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-boolean v2, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->c:Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    float-to-int v0, v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p3}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    float-to-int v1, v1

    invoke-virtual {p1, p2, v0, v1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->A(Landroid/view/View;II)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-boolean v0, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->c:Z

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->d(Landroid/view/ViewGroup;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->a:Landroidx/customview/widget/d;

    const/4 v4, 0x2

    invoke-virtual {p1, p3}, Landroidx/customview/widget/d;->W(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    return p1

    :cond_2
    const/4 v3, 0x7

    const/4 v4, 0x3

    return v2
.end method

.method public onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;I)Z"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-super {p0, p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p2}, Landroidx/core/view/k1;->V(Landroid/view/View;)I

    move-result p3

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-nez p3, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    const/4 p3, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p2, p3}, Landroidx/core/view/k1;->R1(Landroid/view/View;I)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p2}, Lcom/google/android/material/behavior/SwipeDismissBehavior;->n(Landroid/view/View;)V

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return p1
.end method

.method public onTouchEvent(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/view/MotionEvent;",
            ")Z"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/google/android/material/behavior/SwipeDismissBehavior;->a:Landroidx/customview/widget/d;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1, p3}, Landroidx/customview/widget/d;->M(Landroid/view/MotionEvent;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v0, 0x7

    and-int/2addr v1, v0

    return p1

    :cond_0
    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    return p1
.end method
