.class public Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;
.super Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<V:",
        "Landroid/view/View;",
        ">",
        "Landroidx/coordinatorlayout/widget/CoordinatorLayout$c<",
        "TV;>;"
    }
.end annotation


# static fields
.field protected static final e:I = 0xe1

.field protected static final f:I = 0xaf

.field private static final g:I = 0x1

.field private static final h:I = 0x2


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:Landroid/view/ViewPropertyAnimator;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput v0, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->a:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput v1, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput v0, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->c:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    const/4 p2, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p2, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->b:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->c:I

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;Landroid/view/ViewPropertyAnimator;)Landroid/view/ViewPropertyAnimator;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~os t @@@@  ti~d@@~Mlb~~@@~v@s~b@@i ~@o1u ~ ~lmon  @@ 4~S.  f~~r~~@@b   ~~i/c@o  a@o~K@f-/~yo~~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->d:Landroid/view/ViewPropertyAnimator;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method private b(Landroid/view/View;IJLandroid/animation/TimeInterpolator;)V
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;IJ",
            "Landroid/animation/TimeInterpolator;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    int-to-float p2, p2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p1, p5}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p1, p3, p4}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    new-instance p2, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior$a;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p2, p0}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior$a;-><init>(Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    invoke-virtual {p1, p2}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->d:Landroid/view/ViewPropertyAnimator;

    const/4 v0, 0x5

    move v1, v0

    return-void
.end method


# virtual methods
.method public c()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return v1
.end method

.method public d()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->b:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v0
.end method

.method public e(Landroid/view/View;I)V
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;I)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput p2, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->c:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->b:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->a:I

    const/4 v3, 0x6

    add-int/2addr v0, p2

    const/4 v3, 0x0

    int-to-float p2, v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/view/View;->setTranslationY(F)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method public f(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->g(Landroid/view/View;Z)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public g(Landroid/view/View;Z)V
    .locals 10
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;Z)V"
        }
    .end annotation

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->c()Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-eqz v0, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    return-void

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->d:Landroid/view/ViewPropertyAnimator;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    if-eqz v0, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {p1}, Landroid/view/View;->clearAnimation()V

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    const/4 v0, 0x1

    const/4 v8, 0x0

    move v9, v8

    iput v0, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->b:I

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget v0, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->a:I

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget v1, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->c:I

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    add-int v4, v0, v1

    const/4 v9, 0x5

    const/4 v8, 0x6

    if-eqz p2, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-wide/16 v5, 0xaf

    const-wide/16 v5, 0xaf

    const/4 v9, 0x6

    const-wide/16 v5, 0xaf

    const-wide/16 v5, 0xaf

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    sget-object v7, Lcom/google/android/material/animation/a;->c:Landroid/animation/TimeInterpolator;

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct/range {v2 .. v7}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->b(Landroid/view/View;IJLandroid/animation/TimeInterpolator;)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    goto :goto_0

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    int-to-float p2, v4

    const/4 v8, 0x1

    xor-int/2addr v9, v8

    invoke-virtual {p1, p2}, Landroid/view/View;->setTranslationY(F)V

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    return-void
.end method

.method public h(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->i(Landroid/view/View;Z)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public i(Landroid/view/View;Z)V
    .locals 9
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;Z)V"
        }
    .end annotation

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->d()Z

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x5

    if-eqz v0, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    return-void

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->d:Landroid/view/ViewPropertyAnimator;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz v0, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p1}, Landroid/view/View;->clearAnimation()V

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    const/4 v0, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    iput v0, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->b:I

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-eqz p2, :cond_2

    const/4 v7, 0x0

    move v8, v7

    const-wide/16 v4, 0xe1

    const-wide/16 v4, 0xe1

    const/4 v8, 0x1

    const-wide/16 v4, 0xe1

    const-wide/16 v4, 0xe1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    sget-object v6, Lcom/google/android/material/animation/a;->d:Landroid/animation/TimeInterpolator;

    const/4 v8, 0x2

    const/4 v3, 0x4

    const/4 v8, 0x3

    const/4 v3, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-direct/range {v1 .. v6}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->b(Landroid/view/View;IJLandroid/animation/TimeInterpolator;)V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_0

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 p2, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    int-to-float p2, p2

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p1, p2}, Landroid/view/View;->setTranslationY(F)V

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    return-void
.end method

.method public onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z
    .locals 4
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;I)Z"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast v0, Landroid/view/ViewGroup$MarginLayoutParams;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p2}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v0, v0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    const/4 v2, 0x6

    move v3, v2

    add-int/2addr v1, v0

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->a:I

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    invoke-super {p0, p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onLayoutChild(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;I)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    return p1
.end method

.method public onNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;IIIII[I)V
    .locals 2
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p9    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/view/View;",
            "IIIII[I)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    if-lez p5, :cond_0

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p2}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->f(Landroid/view/View;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    if-gez p5, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p2}, Lcom/google/android/material/behavior/HideBottomViewOnScrollBehavior;->h(Landroid/view/View;)V

    :cond_1
    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public onStartNestedScroll(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;Landroid/view/View;II)Z
    .locals 2
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/coordinatorlayout/widget/CoordinatorLayout;",
            "TV;",
            "Landroid/view/View;",
            "Landroid/view/View;",
            "II)Z"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    const/4 p1, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    if-ne p5, p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v0, 0x3

    const/4 v1, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x5

    return p1
.end method
