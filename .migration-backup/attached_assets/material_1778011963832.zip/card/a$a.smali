.class Lcom/google/android/material/card/a$a;
.super Landroid/graphics/drawable/InsetDrawable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/card/a;->B(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/card/a;


# direct methods
.method constructor <init>(Lcom/google/android/material/card/a;Landroid/graphics/drawable/Drawable;IIII)V
    .locals 8

    const/4 v7, 0x1

    iput-object p1, p0, Lcom/google/android/material/card/a$a;->a:Lcom/google/android/material/card/a;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    move v2, p3

    move v2, p3

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    move v3, p4

    move v3, p4

    const/4 v7, 0x2

    move v3, p4

    move v3, p4

    const/4 v6, 0x0

    shl-int/2addr v7, v6

    move v4, p5

    move v4, p5

    const/4 v7, 0x0

    move v4, p5

    move v4, p5

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    move v5, p6

    const/4 v7, 0x0

    move v5, p6

    move v5, p6

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct/range {v0 .. v5}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    return-void
.end method


# virtual methods
.method public getMinimumHeight()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ss/t @M~d   @@y@o~@o@~iKt~4m@nSla~~/~~b~fbo 1o~ ~~~@~  @~i @~f@vu @@~b-@  @~  ~ir@~o@~o l@ @ @c"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v1, 0x1

    move v2, v1

    return v0
.end method

.method public getMinimumWidth()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v0, -0x1

    and-int/2addr v2, v0

    const/4 v1, 0x3

    move v2, v1

    return v0
.end method

.method public getPadding(Landroid/graphics/Rect;)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v0, 0x7

    move v1, v0

    return p1
.end method
