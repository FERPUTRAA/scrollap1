.class Lcom/google/android/material/color/i$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "c"
.end annotation


# static fields
.field private static final f:S = 0x120s

.field private static final g:I = 0x80


# instance fields
.field private final a:Lcom/google/android/material/color/i$e;

.field private final b:Lcom/google/android/material/color/i$d;

.field private final c:Lcom/google/android/material/color/i$h;

.field private final d:Lcom/google/android/material/color/i$h;

.field private final e:Lcom/google/android/material/color/i$k;


# direct methods
.method constructor <init>(Lcom/google/android/material/color/i$d;Ljava/util/List;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/android/material/color/i$d;",
            "Ljava/util/List<",
            "Lcom/google/android/material/color/i$b;",
            ">;)V"
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    iput-object p1, p0, Lcom/google/android/material/color/i$c;->b:Lcom/google/android/material/color/i$d;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-instance p1, Lcom/google/android/material/color/i$h;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string v0, "?1"

    const-string v0, "1?"

    const-string v0, "1?"

    const-string v0, "?1"

    const/4 v6, 0x5

    move v7, v6

    const-string v1, "2?"

    const-string v1, "?2"

    const/4 v7, 0x2

    const-string v1, "?2"

    const-string v1, "?2"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string v2, "3?"

    const-string v2, "?3"

    const/4 v7, 0x4

    const-string v2, "3?"

    const-string v2, "?3"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string v3, "4?"

    const-string v3, "4?"

    const/4 v7, 0x5

    const-string v3, "?4"

    const-string v3, "?4"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string v4, "?5"

    const-string v4, "5?"

    const/4 v7, 0x3

    const-string v4, "?5"

    const-string v4, "?5"

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo v5, "rssco"

    const-string/jumbo v5, "rcsol"

    const/4 v7, 0x6

    const-string/jumbo v5, "orlmo"

    const-string v5, "color"

    const/4 v7, 0x3

    filled-new-array/range {v0 .. v5}, [Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {p1, v1, v0}, Lcom/google/android/material/color/i$h;-><init>(Z[Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    iput-object p1, p0, Lcom/google/android/material/color/i$c;->c:Lcom/google/android/material/color/i$h;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    new-array p1, p1, [Ljava/lang/String;

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-ge v1, v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-interface {p2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    check-cast v0, Lcom/google/android/material/color/i$b;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/google/android/material/color/i$b;->d(Lcom/google/android/material/color/i$b;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    aput-object v0, p1, v1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    new-instance v0, Lcom/google/android/material/color/i$h;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/4 v1, 0x1

    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v0, v1, p1}, Lcom/google/android/material/color/i$h;-><init>(Z[Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    iput-object v0, p0, Lcom/google/android/material/color/i$c;->d:Lcom/google/android/material/color/i$h;

    const/4 v7, 0x2

    new-instance p1, Lcom/google/android/material/color/i$k;

    const/4 v7, 0x3

    invoke-direct {p1, p2}, Lcom/google/android/material/color/i$k;-><init>(Ljava/util/List;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    iput-object p1, p0, Lcom/google/android/material/color/i$c;->e:Lcom/google/android/material/color/i$k;

    const/4 v7, 0x6

    const/4 v6, 0x1

    new-instance p1, Lcom/google/android/material/color/i$e;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/16 p2, 0x120

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/color/i$c;->a()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/16 v1, 0x200

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {p1, v1, p2, v0}, Lcom/google/android/material/color/i$e;-><init>(SSI)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput-object p1, p0, Lcom/google/android/material/color/i$c;->a:Lcom/google/android/material/color/i$e;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-void
.end method


# virtual methods
.method a()I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/color/i$c;->c:Lcom/google/android/material/color/i$h;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/color/i$h;->a()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    add-int/lit16 v0, v0, 0x120

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/color/i$c;->d:Lcom/google/android/material/color/i$h;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v1}, Lcom/google/android/material/color/i$h;->a()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    add-int/2addr v0, v1

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/material/color/i$c;->e:Lcom/google/android/material/color/i$k;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/google/android/material/color/i$k;->b()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    add-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v0
.end method

.method b(Ljava/io/ByteArrayOutputStream;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/color/i$c;->a:Lcom/google/android/material/color/i$e;

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/i$e;->a(Ljava/io/ByteArrayOutputStream;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/android/material/color/i$c;->b:Lcom/google/android/material/color/i$d;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/google/android/material/color/i$d;->a(Lcom/google/android/material/color/i$d;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/color/i$c;->b:Lcom/google/android/material/color/i$d;

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/google/android/material/color/i$d;->b(Lcom/google/android/material/color/i$d;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    move v2, v1

    move v2, v1

    const/4 v5, 0x4

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/16 v3, 0x80

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-ge v2, v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    array-length v3, v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-ge v2, v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    aget-char v3, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v3}, Lcom/google/android/material/color/i;->a(C)[B

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p1, v3}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/google/android/material/color/i;->a(C)[B

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, v3}, Ljava/io/OutputStream;->write([B)V

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/16 v0, 0x120

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1, v2}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p1, v2}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/google/android/material/color/i$c;->c:Lcom/google/android/material/color/i$h;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/google/android/material/color/i$h;->a()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    add-int/2addr v2, v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v2}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v1}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/android/material/color/i$c;->c:Lcom/google/android/material/color/i$h;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/i$h;->c(Ljava/io/ByteArrayOutputStream;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/android/material/color/i$c;->d:Lcom/google/android/material/color/i$h;

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/i$h;->c(Ljava/io/ByteArrayOutputStream;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/color/i$c;->e:Lcom/google/android/material/color/i$k;

    const/4 v5, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/i$k;->c(Ljava/io/ByteArrayOutputStream;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-void
.end method
