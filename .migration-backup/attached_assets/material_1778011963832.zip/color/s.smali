.class public Lcom/google/android/material/color/s;
.super Ljava/lang/Object;


# static fields
.field public static final a:F = 1.0f

.field public static final b:F = 0.54f

.field public static final c:F = 0.38f

.field public static final d:F = 0.32f

.field public static final e:F = 0.12f

.field private static final f:I = 0x28

.field private static final g:I = 0x64

.field private static final h:I = 0x5a

.field private static final i:I = 0xa

.field private static final j:I = 0x50

.field private static final k:I = 0x14

.field private static final l:I = 0x1e

.field private static final m:I = 0x5a


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static a(II)I
    .locals 3
    .param p0    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
            to = 0xffL
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s~@~@  Sl~  M @. @4~o ~@@ b@@il~~1~ oo~ i@c~fs@@i@~~@oa@@n~y~u~~-rm@ d/v o~ @ ~fK@b~o~@b t t~/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-static {p0}, Landroid/graphics/Color;->alpha(I)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    mul-int/2addr v0, p1

    const/4 v2, 0x1

    div-int/lit16 v0, v0, 0xff

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p0, v0}, Landroidx/core/graphics/b0;->B(II)I

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    return p0
.end method

.method public static b(Landroid/content/Context;II)I
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/google/android/material/resources/b;->a(Landroid/content/Context;I)Landroid/util/TypedValue;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    if-eqz p0, :cond_0

    const/4 v0, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget p0, p0, Landroid/util/TypedValue;->data:I

    const/4 v1, 0x2

    return p0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x1

    return p2
.end method

.method public static c(Landroid/content/Context;ILjava/lang/String;)I
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lcom/google/android/material/resources/b;->g(Landroid/content/Context;ILjava/lang/String;)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return p0
.end method

.method public static d(Landroid/view/View;I)I
    .locals 2
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/google/android/material/resources/b;->h(Landroid/view/View;I)I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    return p0
.end method

.method public static e(Landroid/view/View;II)I
    .locals 2
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p1, p2}, Lcom/google/android/material/color/s;->b(Landroid/content/Context;II)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return p0
.end method

.method private static f(II)I
    .locals 2
    .param p0    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g0;
            from = 0x0L
            to = 0x64L
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/android/material/color/r;->c(I)Lcom/google/android/material/color/r;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    int-to-float p1, p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/color/r;->l(F)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/color/r;->m()I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p0
.end method

.method public static g(IZ)Lcom/google/android/material/color/j;
    .locals 6
    .param p0    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/16 v0, 0x5a

    const/4 v5, 0x2

    if-eqz p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-instance p1, Lcom/google/android/material/color/j;

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/16 v1, 0x28

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p0, v1}, Lcom/google/android/material/color/s;->f(II)I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/16 v2, 0x64

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {p0, v2}, Lcom/google/android/material/color/s;->f(II)I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {p0, v0}, Lcom/google/android/material/color/s;->f(II)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/16 v3, 0xa

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p0, v3}, Lcom/google/android/material/color/s;->f(II)I

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {p1, v1, v2, v0, p0}, Lcom/google/android/material/color/j;-><init>(IIII)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance p1, Lcom/google/android/material/color/j;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/16 v1, 0x50

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p0, v1}, Lcom/google/android/material/color/s;->f(II)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/16 v2, 0x14

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p0, v2}, Lcom/google/android/material/color/s;->f(II)I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/16 v3, 0x1e

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {p0, v3}, Lcom/google/android/material/color/s;->f(II)I

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p0, v0}, Lcom/google/android/material/color/s;->f(II)I

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p1, v1, v2, v3, p0}, Lcom/google/android/material/color/j;-><init>(IIII)V

    :goto_0
    const/4 v4, 0x0

    const/4 v5, 0x4

    return-object p1
.end method

.method public static h(Landroid/content/Context;I)Lcom/google/android/material/color/j;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    sget v0, Lcom/google/android/material/R$attr;->isLightTheme:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, v0, v1}, Lcom/google/android/material/resources/b;->b(Landroid/content/Context;IZ)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1, p0}, Lcom/google/android/material/color/s;->g(IZ)Lcom/google/android/material/color/j;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object p0
.end method

.method public static i(II)I
    .locals 2
    .param p0    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/google/android/material/color/a;->c(II)I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p0
.end method

.method public static j(Landroid/content/Context;I)I
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget v0, Lcom/google/android/material/R$attr;->colorPrimary:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-class v1, Lcom/google/android/material/color/s;

    const-class v1, Lcom/google/android/material/color/s;

    const/4 v3, 0x6

    const-class v1, Lcom/google/android/material/color/s;

    const-class v1, Lcom/google/android/material/color/s;

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-virtual {v1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p0, v0, v1}, Lcom/google/android/material/color/s;->c(Landroid/content/Context;ILjava/lang/String;)I

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1, p0}, Lcom/google/android/material/color/s;->i(II)I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    return p0
.end method

.method public static k(I)Z
    .locals 6
    .param p0    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v5, 0x3

    if-eqz p0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p0}, Landroidx/core/graphics/b0;->m(I)D

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    const/4 v5, 0x0

    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    const-wide/high16 v2, 0x3fe0000000000000L    # 0.5

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    cmpl-double p0, v0, v2

    const/4 v5, 0x3

    if-lez p0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 p0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 p0, 0x0

    :goto_0
    const/4 v4, 0x7

    move v5, v4

    return p0
.end method

.method public static l(II)I
    .locals 2
    .param p0    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p1, p0}, Landroidx/core/graphics/b0;->t(II)I

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p0
.end method

.method public static m(IIF)I
    .locals 3
    .param p0    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p2    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p1}, Landroid/graphics/Color;->alpha(I)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    int-to-float v0, v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    mul-float/2addr v0, p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1, p2}, Landroidx/core/graphics/b0;->B(II)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p0, p1}, Lcom/google/android/material/color/s;->l(II)I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p0
.end method

.method public static n(Landroid/view/View;II)I
    .locals 3
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p0, p1, p2, v0}, Lcom/google/android/material/color/s;->o(Landroid/view/View;IIF)I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return p0
.end method

.method public static o(Landroid/view/View;IIF)I
    .locals 2
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p3    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lcom/google/android/material/color/s;->d(Landroid/view/View;I)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p0, p2}, Lcom/google/android/material/color/s;->d(Landroid/view/View;I)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p1, p0, p3}, Lcom/google/android/material/color/s;->m(IIF)I

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p0
.end method
