.class Lcom/google/android/material/color/i$g;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "g"
.end annotation


# static fields
.field private static final e:S = 0xcs


# instance fields
.field private final a:Lcom/google/android/material/color/i$e;

.field private final b:I

.field private final c:Lcom/google/android/material/color/i$h;

.field private final d:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/android/material/color/i$c;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/util/Map;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Lcom/google/android/material/color/i$d;",
            "Ljava/util/List<",
            "Lcom/google/android/material/color/i$b;",
            ">;>;)V"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/google/android/material/color/i$g;->d:Ljava/util/List;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    iput v0, p0, Lcom/google/android/material/color/i$g;->b:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    new-instance v0, Lcom/google/android/material/color/i$h;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const/4 v5, 0x2

    invoke-direct {v0, v1}, Lcom/google/android/material/color/i$h;-><init>([Ljava/lang/String;)V

    const/4 v4, 0x7

    or-int/2addr v5, v4

    iput-object v0, p0, Lcom/google/android/material/color/i$g;->c:Lcom/google/android/material/color/i$h;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    check-cast v1, Ljava/util/List;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {}, Lcom/google/android/material/color/i;->b()Ljava/util/Comparator;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-static {v1, v2}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/google/android/material/color/i$g;->d:Ljava/util/List;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v3, Lcom/google/android/material/color/i$c;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    check-cast v0, Lcom/google/android/material/color/i$d;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {v3, v0, v1}, Lcom/google/android/material/color/i$c;-><init>(Lcom/google/android/material/color/i$d;Ljava/util/List;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance p1, Lcom/google/android/material/color/i$e;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/16 v0, 0xc

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/android/material/color/i$g;->a()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {p1, v2, v0, v1}, Lcom/google/android/material/color/i$e;-><init>(SSI)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput-object p1, p0, Lcom/google/android/material/color/i$g;->a:Lcom/google/android/material/color/i$e;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void
.end method

.method private a()I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~.s t @@ ~~o@@Mi@  @vu~~1~@/@~s@ ll@a t ~@ ~co KSi@~m@ ~4~oi @@  n@ ~/ o~bo@~~-r~~bb~@ o@ffd~~y@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/google/android/material/color/i$g;->d:Ljava/util/List;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    check-cast v2, Lcom/google/android/material/color/i$c;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v2}, Lcom/google/android/material/color/i$c;->a()I

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    add-int/2addr v1, v2

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/color/i$g;->c:Lcom/google/android/material/color/i$h;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/color/i$h;->a()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    add-int/lit8 v0, v0, 0xc

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    add-int/2addr v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    return v0
.end method


# virtual methods
.method b(Ljava/io/ByteArrayOutputStream;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/color/i$g;->a:Lcom/google/android/material/color/i$e;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/i$e;->a(Ljava/io/ByteArrayOutputStream;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/android/material/color/i$g;->b:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/color/i$g;->c:Lcom/google/android/material/color/i$h;

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/i$h;->c(Ljava/io/ByteArrayOutputStream;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/color/i$g;->d:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v1, Lcom/google/android/material/color/i$c;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v1, p1}, Lcom/google/android/material/color/i$c;->b(Ljava/io/ByteArrayOutputStream;)V

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method
