.class public final Lcom/google/android/material/color/j;
.super Ljava/lang/Object;


# instance fields
.field private final a:I

.field private final b:I

.field private final c:I

.field private final d:I


# direct methods
.method constructor <init>(IIII)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/android/material/color/j;->a:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p2, p0, Lcom/google/android/material/color/j;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    iput p3, p0, Lcom/google/android/material/color/j;->c:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p4, p0, Lcom/google/android/material/color/j;->d:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @sto-i@iK@~o~s~~o ~b@ft  @@~~o.bn@4bi~y~ l/@c~@~ ~ l@~Mo~@~~@~ m a@~@@f  S@ u@@@~o~r ~  vd 1/ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/color/j;->a:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public b()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/color/j;->c:I

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public c()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/color/j;->b:I

    const/4 v1, 0x2

    move v2, v1

    return v0
.end method

.method public d()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/color/j;->d:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method
