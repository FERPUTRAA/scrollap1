.class Lcom/google/android/material/color/i$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# instance fields
.field private final a:B

.field private final b:B

.field private final c:S

.field private final d:Ljava/lang/String;

.field private final e:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field


# direct methods
.method constructor <init>(ILjava/lang/String;I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    and-int/2addr v1, v0

    iput-object p2, p0, Lcom/google/android/material/color/i$b;->d:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p3, p0, Lcom/google/android/material/color/i$b;->e:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    const p2, 0xffff

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    and-int/2addr p2, p1

    const/4 v1, 0x6

    int-to-short p2, p2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-short p2, p0, Lcom/google/android/material/color/i$b;->c:S

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    shr-int/lit8 p2, p1, 0x10

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    and-int/lit16 p2, p2, 0xff

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    int-to-byte p2, p2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-byte p2, p0, Lcom/google/android/material/color/i$b;->b:B

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    shr-int/lit8 p1, p1, 0x18

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    and-int/lit16 p1, p1, 0xff

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    int-to-byte p1, p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-byte p1, p0, Lcom/google/android/material/color/i$b;->a:B

    const/4 v0, 0x6

    shl-int/2addr v1, v0

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/color/i$b;)S
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@msrK~@bs~ t b f1~~oun-@o @~@/~y~  @~~c~ oo~@~o@@/l~   o~  t@v~ @~~@l fi@@4@@S M b~~@~@@~dai i~."

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-short p0, p0, Lcom/google/android/material/color/i$b;->c:S

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic b(Lcom/google/android/material/color/i$b;)B
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget-byte p0, p0, Lcom/google/android/material/color/i$b;->b:B

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic c(Lcom/google/android/material/color/i$b;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget p0, p0, Lcom/google/android/material/color/i$b;->e:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p0
.end method

.method static synthetic d(Lcom/google/android/material/color/i$b;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/material/color/i$b;->d:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic e(Lcom/google/android/material/color/i$b;)B
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget-byte p0, p0, Lcom/google/android/material/color/i$b;->a:B

    const/4 v0, 0x3

    const/4 v0, 0x0

    return p0
.end method
