.class public Lcom/google/android/material/color/p;
.super Ljava/lang/Object;


# static fields
.field private static final a:Ljava/lang/String; = "p"


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method private static a(Ljava/util/Map;Landroid/content/res/TypedArray;Landroid/content/res/TypedArray;I)V
    .locals 6
    .param p0    # Ljava/util/Map;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/content/res/TypedArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/TypedArray;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        api = 0x15
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;",
            "Landroid/content/res/TypedArray;",
            "Landroid/content/res/TypedArray;",
            "I)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz p2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    move-object p2, p1

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    move v1, v0

    move v1, v0

    const/4 v5, 0x0

    move v1, v0

    move v1, v0

    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->getIndexCount()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-ge v1, v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p2, v1, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v3, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1, v1}, Landroid/content/res/TypedArray;->getType(I)I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v3}, Lcom/google/android/material/color/p;->e(I)Z

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x4

    if-eqz v3, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v3, p3}, Lcom/google/android/material/color/s;->i(II)I

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {p0, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v5, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-void
.end method

.method private static b(Landroid/content/Context;Ljava/util/Map;)Z
    .locals 5
    .annotation build Landroidx/annotation/w0;
        api = 0x1e
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;)Z"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p0, p1}, Lcom/google/android/material/color/h;->a(Landroid/content/Context;Ljava/util/Map;)Landroid/content/res/loader/ResourcesLoader;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-array v2, v1, [Landroid/content/res/loader/ResourcesLoader;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    aput-object p1, v2, v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p0, v2}, Lcom/google/android/material/color/o;->a(Landroid/content/res/Resources;[Landroid/content/res/loader/ResourcesLoader;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    return v0
.end method

.method public static c(Landroid/content/Context;Lcom/google/android/material/color/q;)V
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/material/color/q;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/android/material/color/p;->f()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x4

    invoke-static {p0, p1}, Lcom/google/android/material/color/p;->d(Landroid/content/Context;Lcom/google/android/material/color/q;)Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, v1}, Lcom/google/android/material/color/q;->e(I)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p0, v0}, Lcom/google/android/material/color/p;->b(Landroid/content/Context;Ljava/util/Map;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lcom/google/android/material/color/u;->a(Landroid/content/Context;I)V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method private static d(Landroid/content/Context;Lcom/google/android/material/color/q;)Ljava/util/Map;
    .locals 9
    .annotation build Landroidx/annotation/w0;
        api = 0x15
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Lcom/google/android/material/color/q;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/google/android/material/color/q;->b()I

    move-result v1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    sget-object v2, Lcom/google/android/material/color/p;->a:Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {p0, v1, v2}, Lcom/google/android/material/color/s;->c(Landroid/content/Context;ILjava/lang/String;)I

    move-result v1

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/color/q;->d()[I

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    array-length v3, v2

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v4, 0x0

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-ge v4, v3, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    aget v5, v2, v4

    const/4 v8, 0x3

    invoke-static {p0, v5}, Landroidx/core/content/d;->getColor(Landroid/content/Context;I)I

    move-result v6

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v6, v1}, Lcom/google/android/material/color/s;->i(II)I

    move-result v6

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-interface {v0, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto :goto_0

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/color/q;->c()Lcom/google/android/material/color/n;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    if-eqz p1, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/color/n;->d()[I

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    array-length v3, v2

    const/4 v8, 0x0

    if-lez v3, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/google/android/material/color/n;->e()I

    move-result p1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p0, v2}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz p1, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v4, Landroid/view/ContextThemeWrapper;

    const/4 v7, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {v4, p0, p1}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v4, v2}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto :goto_1

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 p0, 0x0

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {v0, v3, p0, v1}, Lcom/google/android/material/color/p;->a(Ljava/util/Map;Landroid/content/res/TypedArray;Landroid/content/res/TypedArray;I)V

    const/4 v7, 0x7

    move v8, v7

    invoke-virtual {v3}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz p0, :cond_2

    const/4 v7, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    return-object v0
.end method

.method private static e(I)Z
    .locals 3

    const/4 v2, 0x6

    const/16 v0, 0x1c

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-gt v0, p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/16 v0, 0x1f

    const/4 v2, 0x3

    const/4 v1, 0x3

    if-gt p0, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 p0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return p0
.end method

.method public static f()Z
    .locals 4
    .annotation build Landroidx/annotation/k;
        api = 0x1e
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/16 v1, 0x1e

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-lt v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public static g(Landroid/content/Context;Lcom/google/android/material/color/q;)Landroid/content/Context;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/material/color/q;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/android/material/color/p;->f()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p0, p1}, Lcom/google/android/material/color/p;->d(Landroid/content/Context;Lcom/google/android/material/color/q;)Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget v1, Lcom/google/android/material/R$style;->ThemeOverlay_Material3_HarmonizedColors_Empty:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1, v1}, Lcom/google/android/material/color/q;->e(I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v1, Landroid/view/ContextThemeWrapper;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v1, p0, p1}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance p1, Landroid/content/res/Configuration;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p1}, Landroid/content/res/Configuration;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {v1, p1}, Landroid/view/ContextThemeWrapper;->applyOverrideConfiguration(Landroid/content/res/Configuration;)V

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/google/android/material/color/p;->b(Landroid/content/Context;Ljava/util/Map;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p0
.end method
