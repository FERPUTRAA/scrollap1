.class final Lcom/google/android/material/color/t;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method static a(FFF)F
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b s@  ~@o@@ya~ c@l~o~~~~~  @@~v S~ bto~~ nf @i   u @ todf~@~~M@~@@~@@~. i/1lorK 4i~b-~@~s@o/@m~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-static {p2, p0}, Ljava/lang/Math;->max(FF)F

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    invoke-static {p0, p1}, Ljava/lang/Math;->min(FF)F

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p0
.end method

.method public static b(FF)F
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    sub-float/2addr p0, p1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0}, Ljava/lang/Math;->abs(F)F

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    const/high16 p1, 0x43340000    # 180.0f

    const/4 v1, 0x4

    const/4 v0, 0x0

    sub-float/2addr p0, p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p0}, Ljava/lang/Math;->abs(F)F

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    sub-float/2addr p1, p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p1
.end method

.method public static c(FFF)F
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/high16 v0, 0x3f800000    # 1.0f

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    sub-float/2addr v0, p2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    mul-float/2addr v0, p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    mul-float/2addr p2, p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    add-float/2addr v0, p2

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public static d(F)F
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    cmpg-float v0, p0, v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/high16 v1, 0x43b40000    # 360.0f

    const/4 v3, 0x7

    if-gez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    rem-float/2addr p0, v1

    const/4 v3, 0x4

    add-float/2addr p0, v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return p0

    :cond_0
    const/4 v3, 0x5

    cmpl-float v0, p0, v1

    const/4 v3, 0x1

    if-ltz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    rem-float/2addr p0, v1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p0
.end method

.method public static e(I)I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/16 v0, 0x168

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-gez p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    rem-int/2addr p0, v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    add-int/2addr p0, v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    return p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-lt p0, v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    rem-int/2addr p0, v0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return p0
.end method

.method static f(F)F
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/high16 v0, 0x43340000    # 180.0f

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    mul-float/2addr p0, v0

    const/4 v1, 0x5

    move v2, v1

    const v0, 0x40490fdb    # (float)Math.PI

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    div-float/2addr p0, v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return p0
.end method

.method static g(F)F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/high16 v0, 0x43340000    # 180.0f

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    div-float/2addr p0, v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    const v0, 0x40490fdb    # (float)Math.PI

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    mul-float/2addr p0, v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p0
.end method
