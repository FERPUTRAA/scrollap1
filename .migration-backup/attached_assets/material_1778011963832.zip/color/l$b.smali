.class Lcom/google/android/material/color/l$b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/android/material/color/l$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/l;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private a:Ljava/lang/Long;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public isSupported()Z
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~osb@ m@~ti/  @f~~@ o @~a@S@~@ ~@@~n@~  ~  .~d1v o ~o@~@@-ciK/o@i4~f~~r~ @ y~M~@s@o ~@b bllu~@~t"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/google/android/material/color/l$b;->a:Ljava/lang/Long;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v1, 0x0

    or-int/2addr v8, v1

    const/4 v7, 0x6

    xor-int/2addr v8, v7

    const/4 v2, 0x1

    move v8, v2

    const/4 v7, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-nez v0, :cond_0

    :try_start_0
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-class v0, Landroid/os/Build;

    const-class v0, Landroid/os/Build;

    const/4 v8, 0x1

    const-class v0, Landroid/os/Build;

    const-class v0, Landroid/os/Build;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string v3, "eggmsto"

    const-string/jumbo v3, "ogsgeLt"

    const/4 v8, 0x2

    const-string/jumbo v3, "nLegoot"

    const-string/jumbo v3, "getLong"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-array v4, v2, [Ljava/lang/Class;

    const/4 v8, 0x1

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const/4 v8, 0x5

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    aput-object v5, v4, v1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v7, 0x2

    shr-int/2addr v8, v7

    const-string/jumbo v4, "r.osebruiliben.ovdmo.n"

    const-string/jumbo v4, "oe.mirvislenobo..dirun"

    const/4 v8, 0x2

    const-string/jumbo v4, "ro.build.version.oneui"

    const/4 v7, 0x4

    shl-int/2addr v8, v7

    aput-object v4, v3, v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v4, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v0, v4, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    check-cast v0, Ljava/lang/Long;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    iput-object v0, p0, Lcom/google/android/material/color/l$b;->a:Ljava/lang/Long;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x6

    const/4 v7, 0x0

    goto :goto_0

    :catch_0
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v8, 0x3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x7

    iput-object v0, p0, Lcom/google/android/material/color/l$b;->a:Ljava/lang/Long;

    :cond_0
    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/android/material/color/l$b;->a:Ljava/lang/Long;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const-wide/32 v5, 0x9ca4

    const-wide/32 v5, 0x9ca4

    const/4 v8, 0x6

    const-wide/32 v5, 0x9ca4

    const-wide/32 v5, 0x9ca4

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    cmp-long v0, v3, v5

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-ltz v0, :cond_1

    const/4 v8, 0x6

    move v1, v2

    const/4 v8, 0x4

    move v1, v2

    move v1, v2

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    return v1
.end method
