.class final Lcom/google/android/material/color/i;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/color/i$b;,
        Lcom/google/android/material/color/i$d;,
        Lcom/google/android/material/color/i$f;,
        Lcom/google/android/material/color/i$j;,
        Lcom/google/android/material/color/i$k;,
        Lcom/google/android/material/color/i$c;,
        Lcom/google/android/material/color/i$i;,
        Lcom/google/android/material/color/i$h;,
        Lcom/google/android/material/color/i$e;,
        Lcom/google/android/material/color/i$g;
    }
.end annotation


# static fields
.field private static final a:S = 0x2s

.field private static final b:S = 0x1s

.field private static final c:S = 0x200s

.field private static final d:S = 0x201s

.field private static final e:S = 0x202s

.field private static final f:B = 0x6t

.field private static final g:B = 0x1t

.field private static final h:B = 0x7ft

.field private static final i:Lcom/google/android/material/color/i$d;

.field private static final j:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/google/android/material/color/i$b;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Lcom/google/android/material/color/i$d;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v2, "dnsaosr"

    const-string/jumbo v2, "nrsaoid"

    const/4 v4, 0x3

    const-string v2, "aidmnor"

    const-string v2, "android"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v0, v1, v2}, Lcom/google/android/material/color/i$d;-><init>(ILjava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    sput-object v0, Lcom/google/android/material/color/i;->i:Lcom/google/android/material/color/i$d;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v0, Lcom/google/android/material/color/i$a;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0}, Lcom/google/android/material/color/i$a;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    sput-object v0, Lcom/google/android/material/color/i;->j:Ljava/util/Comparator;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic a(C)[B
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~f~o~ ~/@-/~i@ @ r @@@~f@i @ @u@oSc~l~ 1b~~@bmM~~~o ~ @ @ o~d4~~yo@al ~.@it~vn ~@t@ K ob~s~o@@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/android/material/color/i;->g(C)[B

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic b()Ljava/util/Comparator;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/google/android/material/color/i;->j:Ljava/util/Comparator;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic c(I)[B
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/android/material/color/i;->i(I)[B

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic d(S)[B
    .locals 2

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/android/material/color/i;->j(S)[B

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic e(Ljava/lang/String;)[B
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/google/android/material/color/i;->l(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic f(Ljava/lang/String;)[B
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/android/material/color/i;->k(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method private static g(C)[B
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v0, 0x2

    const/4 v4, 0x7

    new-array v0, v0, [B

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    and-int/lit16 v1, p0, 0xff

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    int-to-byte v1, v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    aput-byte v1, v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    shr-int/lit8 p0, p0, 0x8

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    and-int/lit16 p0, p0, 0xff

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    int-to-byte p0, p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    aput-byte p0, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object v0
.end method

.method static h(Landroid/content/Context;Ljava/util/Map;)[B
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;)[B"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v9, 0x4

    new-instance v0, Lcom/google/android/material/color/i$d;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    const/16 v2, 0x7f

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-direct {v0, v2, v1}, Lcom/google/android/material/color/i$d;-><init>(ILjava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    new-instance v1, Ljava/util/HashMap;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-eqz v3, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    check-cast v3, Ljava/util/Map$Entry;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    new-instance v4, Lcom/google/android/material/color/i$b;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    check-cast v5, Ljava/lang/Integer;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    check-cast v7, Ljava/lang/Integer;

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v6, v7}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    check-cast v3, Ljava/lang/Integer;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {v4, v5, v6, v3}, Lcom/google/android/material/color/i$b;-><init>(ILjava/lang/String;I)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {v4}, Lcom/google/android/material/color/i$b;->b(Lcom/google/android/material/color/i$b;)B

    move-result v3

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/4 v5, 0x6

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-ne v3, v5, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {v4}, Lcom/google/android/material/color/i$b;->e(Lcom/google/android/material/color/i$b;)B

    move-result v3

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    const/4 v5, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-ne v3, v5, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x6

    sget-object v3, Lcom/google/android/material/color/i;->i:Lcom/google/android/material/color/i$d;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    goto :goto_1

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {v4}, Lcom/google/android/material/color/i$b;->e(Lcom/google/android/material/color/i$b;)B

    move-result v3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-ne v3, v2, :cond_2

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    :goto_1
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-interface {v1, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-nez v5, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    new-instance v5, Ljava/util/ArrayList;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-interface {v1, v3, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x1

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    check-cast v3, Ljava/util/List;

    const/4 v9, 0x5

    invoke-interface {v3, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    goto/16 :goto_0

    :cond_2
    const/4 v9, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-string v0, ":motkboii pdugNnaseawkppnt wcdue no   t"

    const-string/jumbo v0, "oskmtrptao  u tio  gukd niNpw:pcnawdnee"

    const/4 v9, 0x4

    const-string v0, "an  oau otcnteuNwpp  pkdnw :oghriedkstu"

    const-string v0, "Not supported with unknown package id: "

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {v4}, Lcom/google/android/material/color/i$b;->e(Lcom/google/android/material/color/i$b;)B

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    throw p0

    :cond_3
    const/4 v9, 0x3

    const/4 v8, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string/jumbo v0, "r :ofuop Ndeuo olr corncns"

    const-string/jumbo v0, "n noolfu: cr oNeu rrodocos"

    const/4 v9, 0x4

    const-string v0, ":ureuon qooor rNcscnoel d "

    const-string v0, "Non color resource found: "

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {v4}, Lcom/google/android/material/color/i$b;->d(Lcom/google/android/material/color/i$b;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    throw p0

    :cond_4
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    new-instance p0, Ljava/io/ByteArrayOutputStream;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-direct {p0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    new-instance p1, Lcom/google/android/material/color/i$g;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {p1, v1}, Lcom/google/android/material/color/i$g;-><init>(Ljava/util/Map;)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {p1, p0}, Lcom/google/android/material/color/i$g;->b(Ljava/io/ByteArrayOutputStream;)V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    return-object p0
.end method

.method private static i(I)[B
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v0, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-array v0, v0, [B

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    and-int/lit16 v1, p0, 0xff

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    int-to-byte v1, v1

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    aput-byte v1, v0, v2

    const/4 v3, 0x7

    move v4, v3

    shr-int/lit8 v1, p0, 0x8

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    and-int/lit16 v1, v1, 0xff

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    int-to-byte v1, v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    aput-byte v1, v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    shr-int/lit8 v1, p0, 0x10

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    and-int/lit16 v1, v1, 0xff

    const/4 v3, 0x2

    move v4, v3

    int-to-byte v1, v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    aput-byte v1, v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    shr-int/lit8 p0, p0, 0x18

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    and-int/lit16 p0, p0, 0xff

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    int-to-byte p0, p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    aput-byte p0, v0, v1

    const/4 v3, 0x1

    move v4, v3

    return-object v0
.end method

.method private static j(S)[B
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v0, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-array v0, v0, [B

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    and-int/lit16 v1, p0, 0xff

    const/4 v4, 0x1

    const/4 v3, 0x0

    int-to-byte v1, v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    aput-byte v1, v0, v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    shr-int/lit8 p0, p0, 0x8

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    and-int/lit16 p0, p0, 0xff

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    int-to-byte p0, p0

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    aput-byte p0, v0, v1

    const/4 v4, 0x5

    return-object v0
.end method

.method private static k(Ljava/lang/String;)[B
    .locals 11

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    array-length v0, p0

    const/4 v9, 0x6

    shr-int/2addr v10, v9

    mul-int/lit8 v0, v0, 0x2

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    add-int/lit8 v0, v0, 0x4

    const/4 v10, 0x5

    new-array v1, v0, [B

    const/4 v9, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    array-length v2, p0

    const/4 v10, 0x1

    const/4 v9, 0x3

    int-to-short v2, v2

    const/4 v10, 0x5

    const/4 v9, 0x5

    invoke-static {v2}, Lcom/google/android/material/color/i;->j(S)[B

    move-result-object v2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    const/4 v3, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    aget-byte v4, v2, v3

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    aput-byte v4, v1, v3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    const/4 v4, 0x1

    const/4 v10, 0x7

    aget-byte v2, v2, v4

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    aput-byte v2, v1, v4

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    move v2, v3

    move v2, v3

    const/4 v10, 0x0

    move v2, v3

    move v2, v3

    :goto_0
    const/4 v10, 0x6

    array-length v5, p0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-ge v2, v5, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    aget-char v5, p0, v2

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {v5}, Lcom/google/android/material/color/i;->g(C)[B

    move-result-object v5

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    mul-int/lit8 v6, v2, 0x2

    const/4 v10, 0x1

    add-int/lit8 v7, v6, 0x2

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    aget-byte v8, v5, v3

    const/4 v9, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    aput-byte v8, v1, v7

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    add-int/lit8 v6, v6, 0x3

    const/4 v10, 0x1

    aget-byte v5, v5, v4

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    aput-byte v5, v1, v6

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    goto :goto_0

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    add-int/lit8 p0, v0, -0x2

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    aput-byte v3, v1, p0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    sub-int/2addr v0, v4

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    aput-byte v3, v1, v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    return-object v1
.end method

.method private static l(Ljava/lang/String;)[B
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x0

    const-string v0, "bTsU-"

    const-string v0, "b-TFU"

    const/4 v6, 0x1

    const-string v0, "T-Fm8"

    const-string v0, "UTF-8"

    const/4 v6, 0x7

    invoke-static {v0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    array-length v0, p0

    const/4 v6, 0x7

    int-to-byte v0, v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    array-length v1, p0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    add-int/lit8 v1, v1, 0x3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    new-array v2, v1, [B

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v3, 0x2

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x4

    move v5, v4

    move v5, v4

    const/4 v6, 0x4

    invoke-static {p0, v4, v2, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 p0, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    aput-byte v0, v2, p0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    aput-byte v0, v2, v4

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    sub-int/2addr v1, p0

    const/4 v6, 0x6

    aput-byte v4, v2, v1

    const/4 v6, 0x5

    return-object v2
.end method
