.class public Lcom/google/android/material/color/m$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field private a:I
    .annotation build Landroidx/annotation/f1;
    .end annotation
.end field

.field private b:Lcom/google/android/material/color/l$f;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private c:Lcom/google/android/material/color/l$e;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/android/material/color/m;->a()Lcom/google/android/material/color/l$f;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    iput-object v0, p0, Lcom/google/android/material/color/m$c;->b:Lcom/google/android/material/color/l$f;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/android/material/color/m;->b()Lcom/google/android/material/color/l$e;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/android/material/color/m$c;->c:Lcom/google/android/material/color/l$e;

    const/4 v1, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/color/m$c;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "aSs @o~@@~K~~@4o -@~nl@yf~ @d@~b~i   @~.~t@ l~ s ~@i~oM@ ~o@t1b~ b@i @vc@r~/~   @~ ~@uo o@f~/~@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget p0, p0, Lcom/google/android/material/color/m$c;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic b(Lcom/google/android/material/color/m$c;)Lcom/google/android/material/color/l$f;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/material/color/m$c;->b:Lcom/google/android/material/color/l$f;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic c(Lcom/google/android/material/color/m$c;)Lcom/google/android/material/color/l$e;
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/android/material/color/m$c;->c:Lcom/google/android/material/color/l$e;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method


# virtual methods
.method public d()Lcom/google/android/material/color/m;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Lcom/google/android/material/color/m;

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    shr-int/2addr v2, v1

    const/4 v3, 0x0

    invoke-direct {v0, p0, v1}, Lcom/google/android/material/color/m;-><init>(Lcom/google/android/material/color/m$c;Lcom/google/android/material/color/m$a;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public e(Lcom/google/android/material/color/l$e;)Lcom/google/android/material/color/m$c;
    .locals 2
    .param p1    # Lcom/google/android/material/color/l$e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/color/m$c;->c:Lcom/google/android/material/color/l$e;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method public f(Lcom/google/android/material/color/l$f;)Lcom/google/android/material/color/m$c;
    .locals 2
    .param p1    # Lcom/google/android/material/color/l$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/color/m$c;->b:Lcom/google/android/material/color/l$f;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method public g(I)Lcom/google/android/material/color/m$c;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/material/color/m$c;->a:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0
.end method
