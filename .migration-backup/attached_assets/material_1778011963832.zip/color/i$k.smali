.class Lcom/google/android/material/color/i$k;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "k"
.end annotation


# static fields
.field private static final e:S = 0x10s

.field private static final f:I = 0x40000000


# instance fields
.field private final a:Lcom/google/android/material/color/i$e;

.field private final b:I

.field private final c:[I

.field private final d:Lcom/google/android/material/color/i$j;


# direct methods
.method constructor <init>(Ljava/util/List;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/google/android/material/color/i$b;",
            ">;)V"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    add-int/lit8 v0, v0, -0x1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    check-cast v0, Lcom/google/android/material/color/i$b;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0}, Lcom/google/android/material/color/i$b;->a(Lcom/google/android/material/color/i$b;)S

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    iput v0, p0, Lcom/google/android/material/color/i$k;->b:I

    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v0, Ljava/util/HashSet;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    if-eqz v2, :cond_0

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    check-cast v2, Lcom/google/android/material/color/i$b;

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v2}, Lcom/google/android/material/color/i$b;->a(Lcom/google/android/material/color/i$b;)S

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v2}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-interface {v0, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v6, 0x7

    iget v1, p0, Lcom/google/android/material/color/i$k;->b:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-array v1, v1, [I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput-object v1, p0, Lcom/google/android/material/color/i$k;->c:[I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v1, 0x0

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget v2, p0, Lcom/google/android/material/color/i$k;->b:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-ge v1, v2, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v1}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v0, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v2, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/google/android/material/color/i$k;->c:[I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/high16 v3, 0x40000000    # 2.0f

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    aput v3, v2, v1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    int-to-short v1, v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_1

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance v1, Lcom/google/android/material/color/i$e;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/16 v2, 0x10

    const/4 v6, 0x3

    invoke-direct {p0}, Lcom/google/android/material/color/i$k;->a()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/16 v4, 0x202

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v1, v4, v2, v3}, Lcom/google/android/material/color/i$e;-><init>(SSI)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    iput-object v1, p0, Lcom/google/android/material/color/i$k;->a:Lcom/google/android/material/color/i$e;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance v1, Lcom/google/android/material/color/i$j;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget v2, p0, Lcom/google/android/material/color/i$k;->b:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {v1, p1, v0, v2}, Lcom/google/android/material/color/i$j;-><init>(Ljava/util/List;Ljava/util/Set;I)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    iput-object v1, p0, Lcom/google/android/material/color/i$k;->d:Lcom/google/android/material/color/i$j;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-void
.end method

.method private a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s~lm~@u ~~~@@~~s  @lK~ vi/@S~@@~ -@ d~@1cr~~ @@4oo@ o @bioy.b~~a~Mi~@~@ ~ ~o@ft@ ~/t@n @o    b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/color/i$k;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    mul-int/lit8 v0, v0, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    add-int/lit8 v0, v0, 0x10

    const/4 v2, 0x4

    const/4 v1, 0x0

    return v0
.end method


# virtual methods
.method b()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/material/color/i$k;->a()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/color/i$k;->d:Lcom/google/android/material/color/i$j;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/google/android/material/color/i$j;->a()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    add-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    return v0
.end method

.method c(Ljava/io/ByteArrayOutputStream;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/android/material/color/i$k;->a:Lcom/google/android/material/color/i$e;

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/i$e;->a(Ljava/io/ByteArrayOutputStream;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v0, 0x4

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    new-array v0, v0, [B

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    fill-array-data v0, :array_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/android/material/color/i$k;->b:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v4, 0x1

    and-int/2addr v5, v4

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/color/i$k;->c:[I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    array-length v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-ge v2, v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    aget v3, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v3}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p1, v3}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/color/i$k;->d:Lcom/google/android/material/color/i$j;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/i$j;->d(Ljava/io/ByteArrayOutputStream;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-void

    :array_0
    .array-data 1
        0x6t
        0x0t
        0x0t
        0x0t
    .end array-data
.end method
