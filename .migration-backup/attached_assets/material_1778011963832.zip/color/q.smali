.class public Lcom/google/android/material/color/q;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/color/q$b;
    }
.end annotation


# instance fields
.field private final a:[I
    .annotation build Landroidx/annotation/n;
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:Lcom/google/android/material/color/n;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final c:I
    .annotation build Landroidx/annotation/f;
    .end annotation
.end field


# direct methods
.method private constructor <init>(Lcom/google/android/material/color/q$b;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/google/android/material/color/q$b;->a(Lcom/google/android/material/color/q$b;)[I

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/android/material/color/q;->a:[I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/google/android/material/color/q$b;->b(Lcom/google/android/material/color/q$b;)Lcom/google/android/material/color/n;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/color/q;->b:Lcom/google/android/material/color/n;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/google/android/material/color/q$b;->c(Lcom/google/android/material/color/q$b;)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/android/material/color/q;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/material/color/q$b;Lcom/google/android/material/color/q$a;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/color/q;-><init>(Lcom/google/android/material/color/q$b;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public static a()Lcom/google/android/material/color/q;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "f~s .~ b~ia~l@ u~o~ @ @@ s@~oK/m @~y~ t~d@@@~oot ~bM/  @ o~@1~@@@@i~i ofbS~~ @c~~@nl@v@@4 ~ -r ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    new-instance v0, Lcom/google/android/material/color/q$b;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0}, Lcom/google/android/material/color/q$b;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/android/material/color/n;->c()Lcom/google/android/material/color/n;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/material/color/q$b;->f(Lcom/google/android/material/color/n;)Lcom/google/android/material/color/q$b;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/color/q$b;->d()Lcom/google/android/material/color/q;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0
.end method


# virtual methods
.method public b()I
    .locals 3
    .annotation build Landroidx/annotation/f;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/color/q;->c:I

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public c()Lcom/google/android/material/color/n;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/color/q;->b:Lcom/google/android/material/color/n;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public d()[I
    .locals 3
    .annotation build Landroidx/annotation/n;
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/color/q;->a:[I

    const/4 v2, 0x7

    return-object v0
.end method

.method e(I)I
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/f1;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/color/q;->b:Lcom/google/android/material/color/n;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/color/n;->e()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/material/color/q;->b:Lcom/google/android/material/color/n;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/android/material/color/n;->e()I

    move-result p1

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return p1
.end method
