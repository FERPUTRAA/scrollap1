.class public final synthetic Lcom/google/android/material/color/f;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()Landroid/content/res/loader/ResourcesLoader;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    new-instance v0, Landroid/content/res/loader/ResourcesLoader;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {v0}, Landroid/content/res/loader/ResourcesLoader;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method
