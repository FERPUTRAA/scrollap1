.class public Lcom/google/android/material/color/l;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/color/l$c;,
        Lcom/google/android/material/color/l$d;,
        Lcom/google/android/material/color/l$e;,
        Lcom/google/android/material/color/l$f;
    }
.end annotation


# static fields
.field private static final a:[I

.field private static final b:Lcom/google/android/material/color/l$c;

.field private static final c:Lcom/google/android/material/color/l$c;
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "PrivateApi"
        }
    .end annotation
.end field

.field private static final d:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/google/android/material/color/l$c;",
            ">;"
        }
    .end annotation
.end field

.field private static final e:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/google/android/material/color/l$c;",
            ">;"
        }
    .end annotation
.end field

.field private static final f:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget v0, Lcom/google/android/material/R$attr;->dynamicColorThemeOverlay:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    sput-object v0, Lcom/google/android/material/color/l;->a:[I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v0, Lcom/google/android/material/color/l$a;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v0}, Lcom/google/android/material/color/l$a;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    sput-object v0, Lcom/google/android/material/color/l;->b:Lcom/google/android/material/color/l$c;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance v1, Lcom/google/android/material/color/l$b;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v1}, Lcom/google/android/material/color/l$b;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    sput-object v1, Lcom/google/android/material/color/l;->c:Lcom/google/android/material/color/l$c;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v2, Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string/jumbo v3, "ooslse"

    const-string/jumbo v3, "glseoo"

    const/4 v5, 0x5

    const-string/jumbo v3, "golmeg"

    const-string/jumbo v3, "google"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const-string v3, " lhbodolmg"

    const-string/jumbo v3, "hmd global"

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v3, "miinxbi"

    const-string/jumbo v3, "inimxin"

    const/4 v5, 0x6

    const-string/jumbo v3, "xiifnnu"

    const-string/jumbo v3, "infinix"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const-string/jumbo v3, "imtolnipot i mdixybfilie"

    const-string/jumbo v3, "o bdoinymliniftixlieti m"

    const/4 v5, 0x5

    const-string/jumbo v3, "iinxdieiqftmobtnil yii m"

    const-string/jumbo v3, "infinix mobility limited"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v3, "eilt"

    const-string/jumbo v3, "tlei"

    const/4 v5, 0x7

    const-string/jumbo v3, "itel"

    const-string/jumbo v3, "itel"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string/jumbo v3, "kyscaob"

    const-string/jumbo v3, "kcyaobe"

    const/4 v5, 0x0

    const-string v3, "akymcre"

    const-string/jumbo v3, "kyocera"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v3, "nlvuoo"

    const-string/jumbo v3, "uvlnoo"

    const/4 v5, 0x1

    const-string/jumbo v3, "vonolb"

    const-string/jumbo v3, "lenovo"

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    move v5, v4

    const-string/jumbo v3, "lge"

    const-string/jumbo v3, "gle"

    const/4 v5, 0x4

    const-string/jumbo v3, "gle"

    const-string/jumbo v3, "lge"

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string/jumbo v3, "rpmoloua"

    const-string/jumbo v3, "tlomroap"

    const/4 v5, 0x4

    const-string/jumbo v3, "lrootamp"

    const-string/jumbo v3, "motorola"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo v3, "gqqonhn"

    const-string/jumbo v3, "tqnognh"

    const/4 v5, 0x7

    const-string/jumbo v3, "ihsnntg"

    const-string/jumbo v3, "nothing"

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v3, "slnmope"

    const-string/jumbo v3, "oneplus"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    const-string/jumbo v3, "poop"

    const-string/jumbo v3, "ppoo"

    const/4 v5, 0x1

    const-string/jumbo v3, "oopp"

    const-string/jumbo v3, "oppo"

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v3, "lraeos"

    const-string/jumbo v3, "lmsera"

    const/4 v5, 0x5

    const-string/jumbo v3, "rmaeeb"

    const-string/jumbo v3, "realme"

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo v3, "oermlicortc"

    const/4 v5, 0x7

    const-string/jumbo v3, "lcerbouicot"

    const-string/jumbo v3, "robolectric"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-interface {v2, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v4, 0x6

    const-string/jumbo v3, "pgusomn"

    const-string/jumbo v3, "ngmsosu"

    const/4 v5, 0x5

    const-string/jumbo v3, "mqnsuas"

    const-string/jumbo v3, "samsung"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {v2, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    shr-int/2addr v5, v4

    const-string/jumbo v1, "pashs"

    const-string/jumbo v1, "sharp"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {v2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v1, "nosy"

    const-string/jumbo v1, "onys"

    const/4 v5, 0x6

    const-string/jumbo v1, "oyns"

    const-string/jumbo v1, "sony"

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string/jumbo v1, "ltc"

    const-string/jumbo v1, "tlc"

    const/4 v5, 0x0

    const-string v1, "clt"

    const-string/jumbo v1, "tcl"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-interface {v2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v1, "ecbmo"

    const-string v1, "beotc"

    const/4 v5, 0x5

    const-string v1, "cnteo"

    const-string/jumbo v1, "tecno"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-interface {v2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v1, "oltm bnimc loetdbeii"

    const-string/jumbo v1, "tecno mobile limited"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-interface {v2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const-string/jumbo v1, "vvio"

    const-string/jumbo v1, "vvio"

    const/4 v5, 0x3

    const-string/jumbo v1, "oivv"

    const-string/jumbo v1, "vivo"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {v2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v1, "uoaimu"

    const-string/jumbo v1, "uoxmai"

    const/4 v5, 0x7

    const-string v1, "apiiom"

    const-string/jumbo v1, "xiaomi"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-interface {v2, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    invoke-static {v2}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    sput-object v1, Lcom/google/android/material/color/l;->d:Ljava/util/Map;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v1, Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v4, 0x1

    and-int/2addr v5, v4

    const-string/jumbo v2, "ssau"

    const-string v2, "asus"

    const/4 v5, 0x5

    const-string v2, "asus"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v2, "joi"

    const-string/jumbo v2, "ioj"

    const/4 v5, 0x5

    const-string/jumbo v2, "oji"

    const-string/jumbo v2, "jio"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    sput-object v0, Lcom/google/android/material/color/l;->e:Ljava/util/Map;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic a(Landroid/app/Activity;ILcom/google/android/material/color/l$f;Lcom/google/android/material/color/l$e;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@  u@ @vq~@@~-~@@o@@   ~/Moa l~b4no~ ~ @ty/f~S ic~~~~@o@@ ~@@r~@i~@~~mb l@o dK@i@~~~~ b1s~. tfo "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-static {p0, p1, p2, p3}, Lcom/google/android/material/color/l;->k(Landroid/app/Activity;ILcom/google/android/material/color/l$f;Lcom/google/android/material/color/l$e;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public static b(Landroid/app/Activity;)V
    .locals 2
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/android/material/color/l;->j(Landroid/app/Activity;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public static c(Landroid/app/Activity;I)V
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/color/m$c;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/google/android/material/color/m$c;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/m$c;->g(I)Lcom/google/android/material/color/m$c;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/color/m$c;->d()Lcom/google/android/material/color/m;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p0, p1}, Lcom/google/android/material/color/l;->l(Landroid/app/Activity;Lcom/google/android/material/color/m;)V

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public static d(Landroid/app/Activity;Lcom/google/android/material/color/l$f;)V
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/material/color/l$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/material/color/m$c;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-direct {v0}, Lcom/google/android/material/color/m$c;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/m$c;->f(Lcom/google/android/material/color/l$f;)Lcom/google/android/material/color/m$c;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/google/android/material/color/m$c;->d()Lcom/google/android/material/color/m;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p0, p1}, Lcom/google/android/material/color/l;->l(Landroid/app/Activity;Lcom/google/android/material/color/m;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public static e(Landroid/app/Application;)V
    .locals 3
    .param p0    # Landroid/app/Application;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    new-instance v0, Lcom/google/android/material/color/m$c;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/android/material/color/m$c;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/color/m$c;->d()Lcom/google/android/material/color/m;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/android/material/color/l;->i(Landroid/app/Application;Lcom/google/android/material/color/m;)V

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method

.method public static f(Landroid/app/Application;I)V
    .locals 3
    .param p0    # Landroid/app/Application;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Lcom/google/android/material/color/m$c;

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-direct {v0}, Lcom/google/android/material/color/m$c;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/m$c;->g(I)Lcom/google/android/material/color/m$c;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/google/android/material/color/m$c;->d()Lcom/google/android/material/color/m;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/google/android/material/color/l;->i(Landroid/app/Application;Lcom/google/android/material/color/m;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public static g(Landroid/app/Application;ILcom/google/android/material/color/l$f;)V
    .locals 3
    .param p0    # Landroid/app/Application;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/color/l$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/material/color/m$c;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/google/android/material/color/m$c;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/m$c;->g(I)Lcom/google/android/material/color/m$c;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, p2}, Lcom/google/android/material/color/m$c;->f(Lcom/google/android/material/color/l$f;)Lcom/google/android/material/color/m$c;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/android/material/color/m$c;->d()Lcom/google/android/material/color/m;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, p1}, Lcom/google/android/material/color/l;->i(Landroid/app/Application;Lcom/google/android/material/color/m;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public static h(Landroid/app/Application;Lcom/google/android/material/color/l$f;)V
    .locals 3
    .param p0    # Landroid/app/Application;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/material/color/l$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/material/color/m$c;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/google/android/material/color/m$c;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/m$c;->f(Lcom/google/android/material/color/l$f;)Lcom/google/android/material/color/m$c;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/color/m$c;->d()Lcom/google/android/material/color/m;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p0, p1}, Lcom/google/android/material/color/l;->i(Landroid/app/Application;Lcom/google/android/material/color/m;)V

    const/4 v2, 0x3

    return-void
.end method

.method public static i(Landroid/app/Application;Lcom/google/android/material/color/m;)V
    .locals 3
    .param p0    # Landroid/app/Application;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/material/color/m;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Lcom/google/android/material/color/l$d;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0, p1}, Lcom/google/android/material/color/l$d;-><init>(Lcom/google/android/material/color/m;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public static j(Landroid/app/Activity;)V
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/material/color/m$c;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/google/android/material/color/m$c;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/color/m$c;->d()Lcom/google/android/material/color/m;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-static {p0, v0}, Lcom/google/android/material/color/l;->l(Landroid/app/Activity;Lcom/google/android/material/color/m;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method private static k(Landroid/app/Activity;ILcom/google/android/material/color/l$f;Lcom/google/android/material/color/l$e;)V
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .param p2    # Lcom/google/android/material/color/l$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lcom/google/android/material/color/l$e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/android/material/color/l;->n()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez p1, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/google/android/material/color/l;->m(Landroid/content/Context;)I

    move-result p1

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz p1, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-interface {p2, p0, p1}, Lcom/google/android/material/color/l$f;->a(Landroid/app/Activity;I)Z

    move-result p2

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz p2, :cond_2

    invoke-static {p0, p1}, Lcom/google/android/material/color/u;->a(Landroid/content/Context;I)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {p3, p0}, Lcom/google/android/material/color/l$e;->a(Landroid/app/Activity;)V

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public static l(Landroid/app/Activity;Lcom/google/android/material/color/m;)V
    .locals 4
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lcom/google/android/material/color/m;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/color/m;->e()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/google/android/material/color/m;->d()Lcom/google/android/material/color/l$f;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/google/android/material/color/m;->c()Lcom/google/android/material/color/l$e;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p0, v0, v1, p1}, Lcom/google/android/material/color/l;->k(Landroid/app/Activity;ILcom/google/android/material/color/l$f;Lcom/google/android/material/color/l$e;)V

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method private static m(Landroid/content/Context;)I
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/material/color/l;->a:[I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, v0, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public static n()Z
    .locals 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "DefaultLocale"
        }
    .end annotation

    .annotation build Landroidx/annotation/k;
        api = 0x1f
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/16 v1, 0x1f

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x6

    if-ge v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    return v2

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v0, Lcom/google/android/material/color/l;->d:Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    sget-object v1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    check-cast v0, Lcom/google/android/material/color/l$c;

    const/4 v4, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    sget-object v0, Lcom/google/android/material/color/l;->e:Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object v1, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    check-cast v0, Lcom/google/android/material/color/l$c;

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {v0}, Lcom/google/android/material/color/l$c;->isSupported()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    return v2
.end method

.method public static o(Landroid/content/Context;)Landroid/content/Context;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v0, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/android/material/color/l;->p(Landroid/content/Context;I)Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method public static p(Landroid/content/Context;I)Landroid/content/Context;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/android/material/color/l;->n()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-nez p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/google/android/material/color/l;->m(Landroid/content/Context;)I

    move-result p1

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez p1, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Landroid/view/ContextThemeWrapper;

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-direct {v0, p0, p1}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method
