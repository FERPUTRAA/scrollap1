.class Lcom/google/android/material/color/i$f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "f"
.end annotation


# static fields
.field private static final c:S = 0x8s

.field private static final d:S = 0x2s

.field private static final e:S = 0x8s

.field private static final f:B = 0x1ct

.field private static final g:I = 0x10


# instance fields
.field private final a:I

.field private final b:I


# direct methods
.method constructor <init>(II)V
    .locals 2
    .param p2    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/material/color/i$f;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p2, p0, Lcom/google/android/material/color/i$f;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method a(Ljava/io/ByteArrayOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "ftsa@~@~b~nu~~~v@ @@@i o~@ ~M.@/~@S@~@r4  ~s  @1~~~ ~@y~ d  im l-@/@~ o @b~ @~ fbtKlioco@ ~~~@o@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    const/16 v0, 0x8

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/android/material/color/i;->d(S)[B

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write([B)V

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v1}, Lcom/google/android/material/color/i;->d(S)[B

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, v2}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget v2, p0, Lcom/google/android/material/color/i$f;->a:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v2}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1, v2}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/android/material/color/i;->d(S)[B

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-array v0, v1, [B

    const/4 v4, 0x6

    const/4 v3, 0x6

    fill-array-data v0, :array_0

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/android/material/color/i$f;->b:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void

    :array_0
    .array-data 1
        0x0t
        0x1ct
    .end array-data
.end method
