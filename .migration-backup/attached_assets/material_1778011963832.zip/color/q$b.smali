.class public Lcom/google/android/material/color/q$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field private a:[I
    .annotation build Landroidx/annotation/n;
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private b:Lcom/google/android/material/color/n;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private c:I
    .annotation build Landroidx/annotation/f;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    new-array v0, v0, [I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/android/material/color/q$b;->a:[I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget v0, Lcom/google/android/material/R$attr;->colorPrimary:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/android/material/color/q$b;->c:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/color/q$b;)[I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  s~nio  ~@@bt~@@@/~~~~  ~i@@ b~o~l ~~@uis~@@@o~o   v1 df m~c4y@~r~KM@@@-@t /. @~ lo~fb ~oS@@@a~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/android/material/color/q$b;->a:[I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic b(Lcom/google/android/material/color/q$b;)Lcom/google/android/material/color/n;
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/google/android/material/color/q$b;->b:Lcom/google/android/material/color/n;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic c(Lcom/google/android/material/color/q$b;)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget p0, p0, Lcom/google/android/material/color/q$b;->c:I

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p0
.end method


# virtual methods
.method public d()Lcom/google/android/material/color/q;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Lcom/google/android/material/color/q;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, p0, v1}, Lcom/google/android/material/color/q;-><init>(Lcom/google/android/material/color/q$b;Lcom/google/android/material/color/q$a;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0
.end method

.method public e(I)Lcom/google/android/material/color/q$b;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/android/material/color/q$b;->c:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method public f(Lcom/google/android/material/color/n;)Lcom/google/android/material/color/q$b;
    .locals 2
    .param p1    # Lcom/google/android/material/color/n;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/color/q$b;->b:Lcom/google/android/material/color/n;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method public g([I)Lcom/google/android/material/color/q$b;
    .locals 2
    .param p1    # [I
        .annotation build Landroidx/annotation/n;
        .end annotation

        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/color/q$b;->a:[I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0
.end method
