.class public final synthetic Lcom/google/android/material/color/g;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "n@s1~l @ @~ do~~~a@ml ~~~   S~@t~r@K~@~ @/ ~i@o~b~ oi4~ @-.y@ ~@ cu@v~@ M ot of f@~b~s/~~@@@@oi@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    new-instance v0, Landroid/content/res/loader/ResourcesLoader;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method
