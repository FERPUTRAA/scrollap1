.class Lcom/google/android/material/color/i$d;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "d"
.end annotation


# instance fields
.field private final a:I

.field private final b:Ljava/lang/String;


# direct methods
.method constructor <init>(ILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/android/material/color/i$d;->a:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/google/android/material/color/i$d;->b:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/color/i$d;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s~M4 1@ t la@/@  Kom ~@b @~@.~l  ~dt~@~@@ @oc/~ui@bo-@@ f@ ~@ ~oyv~~~ @nSrbo~ @so i i~~~~@@@~f"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget p0, p0, Lcom/google/android/material/color/i$d;->a:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic b(Lcom/google/android/material/color/i$d;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/android/material/color/i$d;->b:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method
