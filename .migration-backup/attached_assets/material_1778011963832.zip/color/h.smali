.class final Lcom/google/android/material/color/h;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x1e
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "h"


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method static a(Landroid/content/Context;Ljava/util/Map;)Landroid/content/res/loader/ResourcesLoader;
    .locals 6
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/Map;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/lang/Integer;",
            ">;)",
            "Landroid/content/res/loader/ResourcesLoader;"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x7

    invoke-static {p0, p1}, Lcom/google/android/material/color/i;->h(Landroid/content/Context;Ljava/util/Map;)[B

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    sget-object p1, Lcom/google/android/material/color/h;->a:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v2, ",eshtbldnsl etagrTc  ea"

    const-string/jumbo v2, "gtsnerladlahbTec: ,t e "

    const/4 v5, 0x3

    const-string/jumbo v2, "nchmgebleT, rle:atdae  "

    const-string v2, "Table created, length: "

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    array-length v2, p0

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p1, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    array-length p1, p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x6

    if-nez p1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-object v0

    :cond_0
    :try_start_1
    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo p1, "t.reopamc"

    const-string p1, "cramepm.t"

    const/4 v5, 0x0

    const-string/jumbo p1, "temp.arsc"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p1, v1}, Lcom/google/android/material/color/c;->a(Ljava/lang/String;I)Ljava/io/FileDescriptor;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_5

    :try_start_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance v1, Ljava/io/FileOutputStream;

    const/4 v4, 0x4

    const/4 v4, 0x1

    invoke-direct {v1, p1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/FileDescriptor;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_4

    :try_start_3
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1, p0}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    invoke-static {p1}, Landroid/os/ParcelFileDescriptor;->dup(Ljava/io/FileDescriptor;)Landroid/os/ParcelFileDescriptor;

    move-result-object p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :try_start_4
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {}, Lcom/google/android/material/color/g;->a()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {}, Lcom/google/android/material/color/f;->a()Landroid/content/res/loader/ResourcesLoader;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p0, v0}, Lcom/google/android/material/color/d;->a(Landroid/os/ParcelFileDescriptor;Landroid/content/res/loader/AssetsProvider;)Landroid/content/res/loader/ResourcesProvider;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v2, v3}, Lcom/google/android/material/color/e;->a(Landroid/content/res/loader/ResourcesLoader;Landroid/content/res/loader/ResourcesProvider;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz p0, :cond_1

    :try_start_5
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :cond_1
    :try_start_6
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz p1, :cond_2

    :try_start_7
    const/4 v5, 0x5

    invoke-static {p1}, Landroid/system/Os;->close(Ljava/io/FileDescriptor;)V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-object v2

    :catchall_0
    move-exception v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz p0, :cond_3

    :try_start_8
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    const/4 v5, 0x7

    goto :goto_0

    :catchall_1
    move-exception p0

    :try_start_9
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v2, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_3
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    throw v2
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    :catchall_2
    move-exception p0

    :try_start_a
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto :goto_1

    :catchall_3
    move-exception v1

    :try_start_b
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    throw p0
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_4

    :catchall_4
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_2

    :catchall_5
    move-exception p0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :goto_2
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz p1, :cond_4

    :try_start_c
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p1}, Landroid/system/Os;->close(Ljava/io/FileDescriptor;)V

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    throw p0
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_0

    :catch_0
    move-exception p0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    sget-object p1, Lcom/google/android/material/color/h;->a:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string v1, "Troerbtrtltre to abFsohodoCer acoeCeilece ueR.la"

    const-string v1, "c  oouleba eolet.CoreoTFraisaleaerer RCottercdth"

    const/4 v5, 0x3

    const-string v1, "TrecaFud eei aCsroaeetro ohtsRtbctell.olae Corru"

    const-string v1, "Failed to create the ColorResourcesTableCreator."

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p1, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x3

    move v5, v4

    return-object v0
.end method
