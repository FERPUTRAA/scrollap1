.class Lcom/google/android/material/color/i$j;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "j"
.end annotation


# static fields
.field private static final f:I = -0x1

.field private static final g:S = 0x54s

.field private static final h:B = 0x40t


# instance fields
.field private final a:Lcom/google/android/material/color/i$e;

.field private final b:I

.field private final c:[B

.field private final d:[I

.field private final e:[Lcom/google/android/material/color/i$f;


# direct methods
.method constructor <init>(Ljava/util/List;Ljava/util/Set;I)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/google/android/material/color/i$b;",
            ">;",
            "Ljava/util/Set<",
            "Ljava/lang/Short;",
            ">;I)V"
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/16 v0, 0x40

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-array v1, v0, [B

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    iput-object v1, p0, Lcom/google/android/material/color/i$j;->c:[B

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    iput p3, p0, Lcom/google/android/material/color/i$j;->b:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    aput-byte v0, v1, v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-array v0, v0, [Lcom/google/android/material/color/i$f;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/google/android/material/color/i$j;->e:[Lcom/google/android/material/color/i$f;

    move v0, v2

    move v0, v2

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-ge v0, v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    check-cast v1, Lcom/google/android/material/color/i$b;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v3, p0, Lcom/google/android/material/color/i$j;->e:[Lcom/google/android/material/color/i$f;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-instance v4, Lcom/google/android/material/color/i$f;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v1}, Lcom/google/android/material/color/i$b;->c(Lcom/google/android/material/color/i$b;)I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct {v4, v0, v1}, Lcom/google/android/material/color/i$f;-><init>(II)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    aput-object v4, v3, v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-array p1, p3, [I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    iput-object p1, p0, Lcom/google/android/material/color/i$j;->d:[I

    const/4 v6, 0x0

    move p1, v2

    move p1, v2

    const/4 v6, 0x1

    move p1, v2

    move p1, v2

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-ge v2, p3, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v2}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {p2, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/material/color/i$j;->d:[I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    aput p1, v0, v2

    const/4 v5, 0x5

    const/4 v5, 0x4

    add-int/lit8 p1, p1, 0x10

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_2

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/color/i$j;->d:[I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v1, -0x1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    aput v1, v0, v2

    :goto_2
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    int-to-short v2, v2

    const/4 v5, 0x2

    move v6, v5

    goto :goto_1

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance p1, Lcom/google/android/material/color/i$e;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/16 p2, 0x54

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/color/i$j;->a()I

    move-result p3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/16 v0, 0x201

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {p1, v0, p2, p3}, Lcom/google/android/material/color/i$e;-><init>(SSI)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput-object p1, p0, Lcom/google/android/material/color/i$j;->a:Lcom/google/android/material/color/i$e;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-void
.end method

.method private b()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s.~bv@@/@ia@t@@ ~~~   - fo ~@ ~o bo lt4Ko@omnSi@f1~rid@  ~@o@~ ~b~~~@/c~~y~~@@ @~~@Mu~@  l s~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/color/i$j;->c()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    add-int/lit8 v0, v0, 0x54

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method private c()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/color/i$j;->d:[I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    array-length v0, v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    mul-int/lit8 v0, v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method


# virtual methods
.method a()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/android/material/color/i$j;->b()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/color/i$j;->e:[Lcom/google/android/material/color/i$f;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    array-length v1, v1

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x10

    const/4 v3, 0x4

    const/4 v2, 0x7

    add-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return v0
.end method

.method d(Ljava/io/ByteArrayOutputStream;)V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/material/color/i$j;->a:Lcom/google/android/material/color/i$e;

    const/4 v5, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/i$e;->a(Ljava/io/ByteArrayOutputStream;)V

    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v0, 0x4

    const/4 v6, 0x1

    new-array v0, v0, [B

    const/4 v6, 0x2

    const/4 v5, 0x3

    fill-array-data v0, :array_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget v0, p0, Lcom/google/android/material/color/i$j;->b:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {p0}, Lcom/google/android/material/color/i$j;->b()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/material/color/i$j;->c:[B

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/android/material/color/i$j;->d:[I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    array-length v1, v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    move v3, v2

    move v3, v2

    const/4 v6, 0x0

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-ge v3, v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    aget v4, v0, v3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v4}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p1, v4}, Ljava/io/OutputStream;->write([B)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/android/material/color/i$j;->e:[Lcom/google/android/material/color/i$f;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    array-length v1, v0

    :goto_1
    const/4 v6, 0x3

    if-ge v2, v1, :cond_1

    const/4 v5, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    aget-object v3, v0, v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v3, p1}, Lcom/google/android/material/color/i$f;->a(Ljava/io/ByteArrayOutputStream;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-void

    nop

    :array_0
    .array-data 1
        0x6t
        0x0t
        0x0t
        0x0t
    .end array-data
.end method
