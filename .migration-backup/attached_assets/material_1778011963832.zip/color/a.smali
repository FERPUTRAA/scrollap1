.class final Lcom/google/android/material/color/a;
.super Ljava/lang/Object;


# static fields
.field private static final a:F = 15.0f

.field private static final b:F = 0.5f


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public static a(IIF)I
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ds~~m M~@~ b rn@@~ b@/S@o @~@4i  -@@/ ~  @~o~v 1oa ~.~cl~~i@@ ~b oK@ootfi~@@lt~ ~~@~~y @@@@~u s"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/google/android/material/color/b;->b(I)Lcom/google/android/material/color/b;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p1}, Lcom/google/android/material/color/b;->b(I)Lcom/google/android/material/color/b;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/color/b;->n()F

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/color/b;->h()F

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/color/b;->i()F

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/color/b;->n()F

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/color/b;->h()F

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/color/b;->i()F

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    sub-float/2addr v2, v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    mul-float/2addr v2, p2

    const/4 v4, 0x5

    move v5, v4

    add-float/2addr v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    sub-float/2addr v3, v1

    const/4 v5, 0x6

    mul-float/2addr v3, p2

    const/4 v4, 0x4

    xor-int/2addr v5, v4

    add-float/2addr v1, v3

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    sub-float/2addr p1, p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    mul-float/2addr p1, p2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    add-float/2addr p0, p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v0, v1, p0}, Lcom/google/android/material/color/b;->f(FFF)Lcom/google/android/material/color/b;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/color/b;->l()I

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    return p0
.end method

.method public static b(IIF)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p0, p1, p2}, Lcom/google/android/material/color/a;->a(IIF)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/google/android/material/color/b;->b(I)Lcom/google/android/material/color/b;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/android/material/color/b;->b(I)Lcom/google/android/material/color/b;

    move-result-object p2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p1}, Lcom/google/android/material/color/b;->k()F

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p2}, Lcom/google/android/material/color/b;->j()F

    move-result p2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/google/android/material/color/k;->l(I)F

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p1, p2, p0}, Lcom/google/android/material/color/r;->b(FFF)Lcom/google/android/material/color/r;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/color/r;->m()I

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p0
.end method

.method public static c(II)I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/google/android/material/color/r;->c(I)Lcom/google/android/material/color/r;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/google/android/material/color/r;->c(I)Lcom/google/android/material/color/r;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/color/r;->g()F

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/google/android/material/color/r;->g()F

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/google/android/material/color/t;->b(FF)F

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/high16 v1, 0x3f000000    # 0.5f

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    mul-float/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/high16 v1, 0x41700000    # 15.0f

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/color/r;->g()F

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/color/r;->g()F

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/android/material/color/r;->g()F

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v2, p1}, Lcom/google/android/material/color/a;->d(FF)F

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    mul-float/2addr v0, p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    add-float/2addr v1, v0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v1}, Lcom/google/android/material/color/t;->d(F)F

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/color/r;->f()F

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/color/r;->h()F

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-static {p1, v0, p0}, Lcom/google/android/material/color/r;->b(FFF)Lcom/google/android/material/color/r;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/color/r;->m()I

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    return p0
.end method

.method private static d(FF)F
    .locals 11

    const/4 v10, 0x3

    sub-float/2addr p1, p0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    const/high16 p0, 0x43b40000    # 360.0f

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    add-float v0, p1, p0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    sub-float p0, p1, p0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v2

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static {p0}, Ljava/lang/Math;->abs(F)F

    move-result v3

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    cmpg-float v4, v1, v2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/high16 v6, -0x40800000    # -1.0f

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x4

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-gtz v4, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    cmpg-float v4, v1, v3

    const/4 v10, 0x5

    const/4 v9, 0x7

    if-gtz v4, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    float-to-double p0, p1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    cmpl-double p0, p0, v7

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-ltz p0, :cond_0

    const/4 v10, 0x7

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    move v5, v6

    move v5, v6

    const/4 v10, 0x2

    move v5, v6

    move v5, v6

    :goto_0
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    return v5

    :cond_1
    const/4 v9, 0x2

    const/4 v10, 0x2

    cmpg-float p1, v2, v1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-gtz p1, :cond_3

    const/4 v9, 0x2

    move v10, v9

    cmpg-float p1, v2, v3

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-gtz p1, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    float-to-double p0, v0

    const/4 v9, 0x1

    move v10, v9

    cmpl-double p0, p0, v7

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-ltz p0, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    goto :goto_1

    :cond_2
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    move v5, v6

    const/4 v10, 0x6

    move v5, v6

    move v5, v6

    :goto_1
    const/4 v10, 0x2

    return v5

    :cond_3
    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    float-to-double p0, p0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    cmpl-double p0, p0, v7

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-ltz p0, :cond_4

    const/4 v10, 0x3

    const/4 v9, 0x5

    goto :goto_2

    :cond_4
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    move v5, v6

    move v5, v6

    const/4 v10, 0x1

    move v5, v6

    move v5, v6

    :goto_2
    return v5
.end method
