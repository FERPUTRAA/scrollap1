.class Lcom/google/android/material/color/i$e;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "e"
.end annotation


# instance fields
.field private final a:S

.field private final b:S

.field private final c:I


# direct methods
.method constructor <init>(SSI)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-short p1, p0, Lcom/google/android/material/color/i$e;->a:S

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-short p2, p0, Lcom/google/android/material/color/i$e;->b:S

    const/4 v1, 0x5

    iput p3, p0, Lcom/google/android/material/color/i$e;->c:I

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method a(Ljava/io/ByteArrayOutputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s~ ~ /4@@o@ ffa b@olcy~@d o~t~@ @@iK@v.~~ b o@@~on~l@~~ ~~ 1 @/~tbS~~M  ~~@~~ @o u r~@is@@m~-@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-short v0, p0, Lcom/google/android/material/color/i$e;->a:S

    const/4 v1, 0x3

    move v2, v1

    invoke-static {v0}, Lcom/google/android/material/color/i;->d(S)[B

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-short v0, p0, Lcom/google/android/material/color/i$e;->b:S

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/android/material/color/i;->d(S)[B

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    iget v0, p0, Lcom/google/android/material/color/i$e;->c:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v2, 0x0

    return-void
.end method
