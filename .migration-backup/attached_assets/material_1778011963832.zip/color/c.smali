.class public final synthetic Lcom/google/android/material/color/c;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/String;I)Ljava/io/FileDescriptor;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "bss a  @oKl ~~ f@o  @~~~~S~~-~n@~@@   u o@tifo~@m @@ /@M@/~o~@o@.ib@ v@ytd@@~4 @~lcb~ ~~i ~~1@~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-static {p0, p1}, Landroid/system/Os;->memfd_create(Ljava/lang/String;I)Ljava/io/FileDescriptor;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-object p0
.end method
