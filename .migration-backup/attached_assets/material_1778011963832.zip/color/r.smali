.class final Lcom/google/android/material/color/r;
.super Ljava/lang/Object;


# static fields
.field private static final d:F = 0.4f

.field private static final e:F = 1.0f

.field private static final f:F = 0.2f

.field private static final g:F = 1.0E-9f

.field private static final h:F = 0.01f


# instance fields
.field private a:F

.field private b:F

.field private c:F


# direct methods
.method private constructor <init>(FFF)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p1, p2, p3}, Lcom/google/android/material/color/r;->d(FFF)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/color/r;->k(I)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method private static a(FFF)Lcom/google/android/material/color/b;
    .locals 12

    const/4 v0, 0x0

    const/high16 v1, 0x42c80000    # 100.0f

    const/high16 v2, 0x447a0000    # 1000.0f

    const/4 v3, 0x0

    move v5, v0

    move v5, v0

    move v5, v0

    move v5, v0

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    :goto_0
    sub-float v6, v5, v1

    invoke-static {v6}, Ljava/lang/Math;->abs(F)F

    move-result v6

    const v7, 0x3c23d70a    # 0.01f

    cmpl-float v6, v6, v7

    if-lez v6, :cond_3

    sub-float v6, v1, v5

    const/high16 v7, 0x40000000    # 2.0f

    div-float/2addr v6, v7

    add-float/2addr v6, v5

    invoke-static {v6, p1, p0}, Lcom/google/android/material/color/b;->d(FFF)Lcom/google/android/material/color/b;

    move-result-object v7

    invoke-virtual {v7}, Lcom/google/android/material/color/b;->l()I

    move-result v7

    invoke-static {v7}, Lcom/google/android/material/color/k;->l(I)F

    move-result v8

    sub-float v9, p2, v8

    invoke-static {v9}, Ljava/lang/Math;->abs(F)F

    move-result v9

    const v10, 0x3e4ccccd    # 0.2f

    cmpg-float v10, v9, v10

    if-gez v10, :cond_0

    invoke-static {v7}, Lcom/google/android/material/color/b;->b(I)Lcom/google/android/material/color/b;

    move-result-object v7

    invoke-virtual {v7}, Lcom/google/android/material/color/b;->m()F

    move-result v10

    invoke-virtual {v7}, Lcom/google/android/material/color/b;->j()F

    move-result v11

    invoke-static {v10, v11, p0}, Lcom/google/android/material/color/b;->d(FFF)Lcom/google/android/material/color/b;

    move-result-object v10

    invoke-virtual {v7, v10}, Lcom/google/android/material/color/b;->a(Lcom/google/android/material/color/b;)F

    move-result v10

    const/high16 v11, 0x3f800000    # 1.0f

    cmpg-float v11, v10, v11

    if-gtz v11, :cond_0

    cmpg-float v11, v10, v2

    if-gtz v11, :cond_0

    move-object v4, v7

    move-object v4, v7

    move v3, v9

    move v3, v9

    move v3, v9

    move v3, v9

    move v2, v10

    move v2, v10

    move v2, v10

    move v2, v10

    :cond_0
    cmpl-float v7, v3, v0

    if-nez v7, :cond_1

    const v7, 0x3089705f    # 1.0E-9f

    cmpg-float v7, v2, v7

    if-gez v7, :cond_1

    goto :goto_1

    :cond_1
    cmpg-float v7, v8, p2

    if-gez v7, :cond_2

    move v5, v6

    move v5, v6

    move v5, v6

    move v5, v6

    goto :goto_0

    :cond_2
    move v1, v6

    move v1, v6

    move v1, v6

    move v1, v6

    goto :goto_0

    :cond_3
    :goto_1
    return-object v4
.end method

.method public static b(FFF)Lcom/google/android/material/color/r;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    new-instance v0, Lcom/google/android/material/color/r;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1, p2}, Lcom/google/android/material/color/r;-><init>(FFF)V

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    return-object v0
.end method

.method public static c(I)Lcom/google/android/material/color/r;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/google/android/material/color/b;->b(I)Lcom/google/android/material/color/b;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v1, Lcom/google/android/material/color/r;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/android/material/color/b;->k()F

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/color/b;->j()F

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/google/android/material/color/k;->l(I)F

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v1, v2, v0, p0}, Lcom/google/android/material/color/r;-><init>(FFF)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object v1
.end method

.method private static d(FFF)I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/google/android/material/color/v;->k:Lcom/google/android/material/color/v;

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, p1, p2, v0}, Lcom/google/android/material/color/r;->e(FFFLcom/google/android/material/color/v;)I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return p0
.end method

.method static e(FFFLcom/google/android/material/color/v;)I
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    float-to-double v0, p1

    const/4 v7, 0x1

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    const/4 v7, 0x5

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    const-wide/high16 v2, 0x3ff0000000000000L    # 1.0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    cmpg-double v0, v0, v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-ltz v0, :cond_6

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    int-to-double v0, v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    cmpg-double v0, v0, v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-lez v0, :cond_6

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    int-to-double v0, v0

    const/4 v6, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-wide/high16 v2, 0x4059000000000000L    # 100.0

    const-wide/high16 v2, 0x4059000000000000L    # 100.0

    const/4 v7, 0x6

    const-wide/high16 v2, 0x4059000000000000L    # 100.0

    const-wide/high16 v2, 0x4059000000000000L    # 100.0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    cmpl-double v0, v0, v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-ltz v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto/16 :goto_2

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {p0}, Lcom/google/android/material/color/t;->d(F)F

    move-result p0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v1, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v2, 0x0

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    move v2, v1

    move v2, v1

    const/4 v7, 0x5

    move v2, v1

    move v2, v1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    move v1, v0

    move v1, v0

    const/4 v6, 0x3

    shr-int/2addr v7, v6

    move v0, p1

    move v0, p1

    const/4 v7, 0x7

    move v0, p1

    move v0, p1

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    sub-float v4, v1, p1

    const/4 v6, 0x0

    const/4 v6, 0x2

    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    const v5, 0x3ecccccd    # 0.4f

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    cmpl-float v4, v4, v5

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-ltz v4, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {p0, v0, p2}, Lcom/google/android/material/color/r;->a(FFF)Lcom/google/android/material/color/b;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/high16 v5, 0x40000000    # 2.0f

    const/4 v6, 0x2

    move v7, v6

    if-eqz v2, :cond_2

    if-eqz v4, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v4, p3}, Lcom/google/android/material/color/b;->r(Lcom/google/android/material/color/v;)I

    move-result p0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    return p0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    sub-float v0, p1, v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    div-float/2addr v0, v5

    const/4 v6, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    add-float/2addr v0, v1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v7, 0x3

    if-nez v4, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x3

    move p1, v0

    move p1, v0

    const/4 v7, 0x1

    move p1, v0

    move p1, v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_1

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    sub-float v0, p1, v1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    div-float/2addr v0, v5

    const/4 v6, 0x7

    shr-int/2addr v7, v6

    add-float/2addr v0, v1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_0

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-nez v3, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {p2}, Lcom/google/android/material/color/k;->f(F)I

    move-result p0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    return p0

    :cond_5
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v3, p3}, Lcom/google/android/material/color/b;->r(Lcom/google/android/material/color/v;)I

    move-result p0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    return p0

    :cond_6
    :goto_2
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {p2}, Lcom/google/android/material/color/k;->f(F)I

    move-result p0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    return p0
.end method

.method private k(I)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/android/material/color/b;->b(I)Lcom/google/android/material/color/b;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/material/color/k;->l(I)F

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/color/b;->k()F

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput v1, p0, Lcom/google/android/material/color/r;->a:F

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/color/b;->j()F

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v0, p0, Lcom/google/android/material/color/r;->b:F

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput p1, p0, Lcom/google/android/material/color/r;->c:F

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method


# virtual methods
.method public f()F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/color/r;->b:F

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public g()F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/color/r;->a:F

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public h()F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/color/r;->c:F

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public i(F)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/material/color/r;->a:F

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/android/material/color/r;->c:F

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0, p1, v1}, Lcom/google/android/material/color/r;->d(FFF)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/color/r;->k(I)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public j(F)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/google/android/material/color/t;->d(F)F

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/material/color/r;->b:F

    const/4 v3, 0x7

    const/4 v2, 0x3

    iget v1, p0, Lcom/google/android/material/color/r;->c:F

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p1, v0, v1}, Lcom/google/android/material/color/r;->d(FFF)I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/color/r;->k(I)V

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method public l(F)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/material/color/r;->a:F

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/material/color/r;->b:F

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0, v1, p1}, Lcom/google/android/material/color/r;->d(FFF)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/color/r;->k(I)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method

.method public m()I
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/material/color/r;->a:F

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/android/material/color/r;->b:F

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v2, p0, Lcom/google/android/material/color/r;->c:F

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0, v1, v2}, Lcom/google/android/material/color/r;->d(FFF)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0
.end method
