.class final Lcom/google/android/material/color/k;
.super Ljava/lang/Object;


# static fields
.field private static final a:[F


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-array v0, v0, [F

    const/4 v2, 0x5

    fill-array-data v0, :array_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput-object v0, Lcom/google/android/material/color/k;->a:[F

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void

    :array_0
    .array-data 4
        0x42be1810
        0x42c80000    # 100.0f
        0x42d9c419
    .end array-data
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public static a(I)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s~tl@@~  ~@~@ i~4@ r obd@/~bS@vofKo @ 1~@ @@. /boyl~@oMi@ ~@  c~i~t @ ~@fsu~~~m@@ o@~ -an~@~ ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    and-int/lit16 p0, p0, 0xff

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p0
.end method

.method public static b(F)F
    .locals 6

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    const v0, 0x3b4d2e1c    # 0.0031308f

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    cmpg-float v0, p0, v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-gtz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    const v0, 0x414eb852    # 12.92f

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    mul-float/2addr p0, v0

    const/4 v4, 0x2

    xor-int/2addr v5, v4

    return p0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    float-to-double v0, p0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-wide v2, 0x3fdaaaaaa0000000L    # 0.4166666567325592

    const-wide v2, 0x3fdaaaaaa0000000L    # 0.4166666567325592

    const/4 v5, 0x0

    const-wide v2, 0x3fdaaaaaa0000000L    # 0.4166666567325592

    const-wide v2, 0x3fdaaaaaa0000000L    # 0.4166666567325592

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    double-to-float p0, v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    const v0, 0x3f870a3d    # 1.055f

    const/4 v5, 0x6

    const/4 v4, 0x0

    mul-float/2addr p0, v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    const v0, 0x3d6147ae    # 0.055f

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    sub-float/2addr p0, v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    return p0
.end method

.method public static c(I)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    const v0, 0xff00

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    and-int/2addr p0, v0

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    shr-int/lit8 p0, p0, 0x8

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p0
.end method

.method public static d(I)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/google/android/material/color/k;->m(I)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/google/android/material/color/k;->a(I)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/google/android/material/color/k;->c(I)I

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v2, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    move v5, v4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    aput-object v0, v2, v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    aput-object p0, v2, v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 p0, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    aput-object v0, v2, p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo p0, "s0xm2%#%x002x"

    const-string/jumbo p0, "x0s0%2#20%x2x"

    const/4 v5, 0x0

    const-string p0, "#%x%o2x000%2x"

    const-string p0, "#%02x%02x%02x"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object p0
.end method

.method public static e(DDD)I
    .locals 17

    const-wide/high16 v0, 0x4030000000000000L    # 16.0

    const-wide/high16 v0, 0x4030000000000000L    # 16.0

    const-wide/high16 v0, 0x4030000000000000L    # 16.0

    const-wide/high16 v0, 0x4030000000000000L    # 16.0

    add-double v2, p0, v0

    const-wide/high16 v4, 0x405d000000000000L    # 116.0

    const-wide/high16 v4, 0x405d000000000000L    # 116.0

    div-double/2addr v2, v4

    const-wide v6, 0x407f400000000000L    # 500.0

    const-wide v6, 0x407f400000000000L    # 500.0

    const-wide v6, 0x407f400000000000L    # 500.0

    const-wide v6, 0x407f400000000000L    # 500.0

    div-double v6, p2, v6

    add-double/2addr v6, v2

    const-wide/high16 v8, 0x4069000000000000L    # 200.0

    const-wide/high16 v8, 0x4069000000000000L    # 200.0

    const-wide/high16 v8, 0x4069000000000000L    # 200.0

    const-wide/high16 v8, 0x4069000000000000L    # 200.0

    div-double v8, p4, v8

    sub-double v8, v2, v8

    mul-double v10, v6, v6

    mul-double/2addr v10, v6

    const-wide v12, 0x3f822354d28f7cd6L    # 0.008856451679035631

    const-wide v12, 0x3f822354d28f7cd6L    # 0.008856451679035631

    const-wide v12, 0x3f822354d28f7cd6L    # 0.008856451679035631

    const-wide v12, 0x3f822354d28f7cd6L    # 0.008856451679035631

    cmpl-double v14, v10, v12

    const-wide v15, 0x408c3a5ed097b426L    # 903.2962962962963

    const-wide v15, 0x408c3a5ed097b426L    # 903.2962962962963

    const-wide v15, 0x408c3a5ed097b426L    # 903.2962962962963

    const-wide v15, 0x408c3a5ed097b426L    # 903.2962962962963

    if-lez v14, :cond_0

    goto :goto_0

    :cond_0
    mul-double/2addr v6, v4

    sub-double/2addr v6, v0

    div-double v10, v6, v15

    :goto_0
    const-wide/high16 v6, 0x4020000000000000L    # 8.0

    const-wide/high16 v6, 0x4020000000000000L    # 8.0

    const-wide/high16 v6, 0x4020000000000000L    # 8.0

    const-wide/high16 v6, 0x4020000000000000L    # 8.0

    cmpl-double v6, p0, v6

    if-lez v6, :cond_1

    mul-double v6, v2, v2

    mul-double/2addr v6, v2

    goto :goto_1

    :cond_1
    div-double v6, p0, v15

    :goto_1
    mul-double v2, v8, v8

    mul-double/2addr v2, v8

    cmpl-double v12, v2, v12

    if-lez v12, :cond_2

    goto :goto_2

    :cond_2
    mul-double/2addr v8, v4

    sub-double/2addr v8, v0

    div-double v2, v8, v15

    :goto_2
    sget-object v0, Lcom/google/android/material/color/k;->a:[F

    const/4 v1, 0x0

    aget v1, v0, v1

    float-to-double v4, v1

    mul-double/2addr v10, v4

    const/4 v1, 0x1

    aget v1, v0, v1

    float-to-double v4, v1

    mul-double/2addr v6, v4

    const/4 v1, 0x2

    aget v0, v0, v1

    float-to-double v0, v0

    mul-double/2addr v2, v0

    double-to-float v0, v10

    double-to-float v1, v6

    double-to-float v2, v2

    invoke-static {v0, v1, v2}, Lcom/google/android/material/color/k;->i(FFF)I

    move-result v0

    return v0
.end method

.method public static f(F)I
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/high16 v0, 0x41800000    # 16.0f

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    add-float v1, p0, v0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/high16 v2, 0x42e80000    # 116.0f

    const/4 v10, 0x4

    div-float/2addr v1, v2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    mul-float v3, v1, v1

    const/4 v10, 0x6

    mul-float/2addr v3, v1

    const/4 v9, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    const v4, 0x3c111aa7

    const/4 v10, 0x4

    cmpl-float v4, v3, v4

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    const/4 v5, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    const/4 v6, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-lez v4, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    move v4, v5

    move v4, v5

    move v4, v5

    move v4, v5

    const/4 v10, 0x1

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    move v4, v6

    move v4, v6

    const/4 v10, 0x3

    move v4, v6

    move v4, v6

    :goto_0
    const/4 v10, 0x0

    const/high16 v7, 0x41000000    # 8.0f

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x3

    cmpl-float v7, p0, v7

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    if-lez v7, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x6

    move v7, v5

    move v7, v5

    const/4 v10, 0x6

    move v7, v5

    move v7, v5

    const/4 v10, 0x1

    const/4 v9, 0x4

    goto :goto_1

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    move v7, v6

    move v7, v6

    const/4 v10, 0x2

    move v7, v6

    move v7, v6

    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x1

    const v8, 0x4461d2f7

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-eqz v7, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    move p0, v3

    move p0, v3

    const/4 v10, 0x5

    move p0, v3

    move p0, v3

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto :goto_2

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    div-float/2addr p0, v8

    :goto_2
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-eqz v4, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    move v7, v3

    move v7, v3

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    goto :goto_3

    :cond_3
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    mul-float v7, v1, v2

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    sub-float/2addr v7, v0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    div-float/2addr v7, v8

    :goto_3
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-eqz v4, :cond_4

    const/4 v10, 0x3

    goto :goto_4

    :cond_4
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    mul-float/2addr v1, v2

    const/4 v10, 0x2

    sub-float/2addr v1, v0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    div-float v3, v1, v8

    :goto_4
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/4 v0, 0x3

    const/4 v10, 0x2

    new-array v0, v0, [F

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    sget-object v1, Lcom/google/android/material/color/k;->a:[F

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    aget v2, v1, v6

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    mul-float/2addr v7, v2

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    aput v7, v0, v6

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    aget v2, v1, v5

    const/4 v10, 0x6

    mul-float/2addr p0, v2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    aput p0, v0, v5

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/4 p0, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    aget v1, v1, p0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    mul-float/2addr v3, v1

    const/4 v10, 0x6

    aput v3, v0, p0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-static {v0}, Lcom/google/android/material/color/k;->h([F)I

    move-result p0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    return p0
.end method

.method public static g(III)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    and-int/lit16 p0, p0, 0xff

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    shl-int/lit8 p0, p0, 0x10

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/high16 v0, -0x1000000

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    or-int/2addr p0, v0

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    and-int/lit16 p1, p1, 0xff

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    shl-int/lit8 p1, p1, 0x8

    const/4 v2, 0x6

    or-int/2addr p0, p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    and-int/lit16 p1, p2, 0xff

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    or-int/2addr p0, p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    ushr-int/lit8 p0, p0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x4

    return p0
.end method

.method public static h([F)I
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    aget v0, p0, v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    aget v1, p0, v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    aget p0, p0, v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v0, v1, p0}, Lcom/google/android/material/color/k;->i(FFF)I

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    return p0
.end method

.method public static i(FFF)I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/high16 v0, 0x42c80000    # 100.0f

    const/4 v4, 0x4

    div-float/2addr p0, v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    div-float/2addr p1, v0

    const/4 v3, 0x0

    const/4 v3, 0x7

    div-float/2addr p2, v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    const v0, 0x404f65fe

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    mul-float/2addr v0, p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    const v1, -0x403b3d08    # -1.5372f

    const/4 v4, 0x0

    const/4 v3, 0x7

    mul-float/2addr v1, p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    add-float/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const v1, -0x4100b780    # -0.4986f

    const/4 v4, 0x7

    const/4 v3, 0x5

    mul-float/2addr v1, p2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    add-float/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    const v1, -0x4087f62b    # -0.9689f

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    mul-float/2addr v1, p0

    const/4 v3, 0x7

    const/4 v4, 0x4

    const v2, 0x3ff01a37    # 1.8758f

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    mul-float/2addr v2, p1

    const/4 v3, 0x1

    move v4, v3

    add-float/2addr v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    const v2, 0x3d29fbe7    # 0.0415f

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    mul-float/2addr v2, p2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    add-float/2addr v1, v2

    const/4 v3, 0x7

    const/4 v4, 0x4

    const v2, 0x3d6425af    # 0.0557f

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    mul-float/2addr p0, v2

    const/4 v3, 0x7

    and-int/2addr v4, v3

    const v2, -0x41af1aa0    # -0.204f

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    mul-float/2addr p1, v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    add-float/2addr p0, p1

    const/4 v3, 0x5

    move v4, v3

    const p1, 0x3f874bc7    # 1.057f

    const/4 v4, 0x7

    mul-float/2addr p2, p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    add-float/2addr p0, p2

    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/android/material/color/k;->b(F)F

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v1}, Lcom/google/android/material/color/k;->b(F)F

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/google/android/material/color/k;->b(F)F

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/high16 v0, 0x437f0000    # 255.0f

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    mul-float/2addr p1, v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/16 v1, 0xff

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v1, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1, v2}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    mul-float/2addr p2, v0

    const/4 v3, 0x6

    move v4, v3

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v1, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p2, v2}, Ljava/lang/Math;->max(II)I

    move-result p2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    mul-float/2addr p0, v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v1, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p0, v2}, Ljava/lang/Math;->max(II)I

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p1, p2, p0}, Lcom/google/android/material/color/k;->g(III)I

    move-result p0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    return p0
.end method

.method public static j(I)[D
    .locals 17

    invoke-static/range {p0 .. p0}, Lcom/google/android/material/color/k;->o(I)[F

    move-result-object v0

    const/4 v1, 0x1

    aget v2, v0, v1

    sget-object v3, Lcom/google/android/material/color/k;->a:[F

    aget v4, v3, v1

    div-float/2addr v2, v4

    float-to-double v4, v2

    const-wide v6, 0x3f822354d28f7cd6L    # 0.008856451679035631

    const-wide v6, 0x3f822354d28f7cd6L    # 0.008856451679035631

    const-wide v6, 0x3f822354d28f7cd6L    # 0.008856451679035631

    cmpl-double v2, v4, v6

    const-wide v8, 0x408c3a5ed097b426L    # 903.2962962962963

    const-wide v8, 0x408c3a5ed097b426L    # 903.2962962962963

    const-wide v8, 0x408c3a5ed097b426L    # 903.2962962962963

    const-wide v8, 0x408c3a5ed097b426L    # 903.2962962962963

    const-wide/high16 v10, 0x405d000000000000L    # 116.0

    const-wide/high16 v10, 0x405d000000000000L    # 116.0

    const-wide/high16 v10, 0x405d000000000000L    # 116.0

    const-wide/high16 v10, 0x405d000000000000L    # 116.0

    const-wide/high16 v12, 0x4030000000000000L    # 16.0

    const-wide/high16 v12, 0x4030000000000000L    # 16.0

    const-wide/high16 v12, 0x4030000000000000L    # 16.0

    if-lez v2, :cond_0

    invoke-static {v4, v5}, Ljava/lang/Math;->cbrt(D)D

    move-result-wide v4

    goto :goto_0

    :cond_0
    mul-double/2addr v4, v8

    add-double/2addr v4, v12

    div-double/2addr v4, v10

    :goto_0
    const/4 v2, 0x0

    aget v14, v0, v2

    aget v15, v3, v2

    div-float/2addr v14, v15

    float-to-double v14, v14

    cmpl-double v16, v14, v6

    if-lez v16, :cond_1

    invoke-static {v14, v15}, Ljava/lang/Math;->cbrt(D)D

    move-result-wide v14

    goto :goto_1

    :cond_1
    mul-double/2addr v14, v8

    add-double/2addr v14, v12

    div-double/2addr v14, v10

    :goto_1
    const/16 v16, 0x2

    aget v0, v0, v16

    aget v3, v3, v16

    div-float/2addr v0, v3

    float-to-double v1, v0

    cmpl-double v0, v1, v6

    if-lez v0, :cond_2

    invoke-static {v1, v2}, Ljava/lang/Math;->cbrt(D)D

    move-result-wide v0

    goto :goto_2

    :cond_2
    mul-double/2addr v1, v8

    add-double/2addr v1, v12

    div-double v0, v1, v10

    :goto_2
    mul-double/2addr v10, v4

    sub-double/2addr v10, v12

    const-wide v6, 0x407f400000000000L    # 500.0

    const-wide v6, 0x407f400000000000L    # 500.0

    sub-double/2addr v14, v4

    mul-double/2addr v14, v6

    const-wide/high16 v6, 0x4069000000000000L    # 200.0

    const-wide/high16 v6, 0x4069000000000000L    # 200.0

    const-wide/high16 v6, 0x4069000000000000L    # 200.0

    sub-double/2addr v4, v0

    mul-double/2addr v4, v6

    const/4 v0, 0x3

    new-array v0, v0, [D

    const/4 v1, 0x0

    aput-wide v10, v0, v1

    const/4 v1, 0x1

    aput-wide v14, v0, v1

    aput-wide v4, v0, v16

    return-object v0
.end method

.method public static k(F)F
    .locals 6

    const/4 v5, 0x3

    const v0, 0x3d25aee6    # 0.04045f

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    cmpg-float v0, p0, v0

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-gtz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const v0, 0x414eb852    # 12.92f

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    div-float/2addr p0, v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    return p0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    const v0, 0x3d6147ae    # 0.055f

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-float/2addr p0, v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const v0, 0x3f870a3d    # 1.055f

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    div-float/2addr p0, v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    float-to-double v0, p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-wide v2, 0x4003333340000000L    # 2.4000000953674316

    const-wide v2, 0x4003333340000000L    # 2.4000000953674316

    const/4 v5, 0x6

    const-wide v2, 0x4003333340000000L    # 2.4000000953674316

    const-wide v2, 0x4003333340000000L    # 2.4000000953674316

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    double-to-float p0, v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    return p0
.end method

.method public static l(I)F
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/google/android/material/color/k;->j(I)[D

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    aget-wide v0, p0, v0

    const/4 v2, 0x4

    double-to-float p0, v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    return p0
.end method

.method public static m(I)I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/high16 v0, 0xff0000

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    and-int/2addr p0, v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    shr-int/lit8 p0, p0, 0x10

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return p0
.end method

.method public static final n()[F
    .locals 4

    const/4 v3, 0x4

    sget-object v0, Lcom/google/android/material/color/k;->a:[F

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([FI)[F

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public static o(I)[F
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {p0}, Lcom/google/android/material/color/k;->m(I)I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    int-to-float v0, v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/high16 v1, 0x437f0000    # 255.0f

    const/4 v5, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    div-float/2addr v0, v1

    const/4 v5, 0x1

    or-int/2addr v6, v5

    invoke-static {v0}, Lcom/google/android/material/color/k;->k(F)F

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/high16 v2, 0x42c80000    # 100.0f

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    mul-float/2addr v0, v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {p0}, Lcom/google/android/material/color/k;->c(I)I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    int-to-float v3, v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    div-float/2addr v3, v1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v3}, Lcom/google/android/material/color/k;->k(F)F

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    mul-float/2addr v3, v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p0}, Lcom/google/android/material/color/k;->a(I)I

    move-result p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    int-to-float p0, p0

    const/4 v5, 0x4

    move v6, v5

    div-float/2addr p0, v1

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {p0}, Lcom/google/android/material/color/k;->k(F)F

    move-result p0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    mul-float/2addr p0, v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    const v1, 0x3ed31e17

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    mul-float/2addr v1, v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    const v2, 0x3eb71a0d

    const/4 v6, 0x2

    const/4 v5, 0x1

    mul-float/2addr v2, v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    add-float/2addr v1, v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    const v2, 0x3e38d7b9

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    mul-float/2addr v2, p0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    add-float/2addr v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    const v2, 0x3e59b3d0    # 0.2126f

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    mul-float/2addr v2, v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    const v4, 0x3f371759    # 0.7152f

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    mul-float/2addr v4, v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    add-float/2addr v2, v4

    const/4 v5, 0x6

    const/4 v6, 0x2

    const v4, 0x3d93dd98    # 0.0722f

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    mul-float/2addr v4, p0

    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    add-float/2addr v2, v4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    const v4, 0x3c9e47ef

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    mul-float/2addr v0, v4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    const v4, 0x3df40c29

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    mul-float/2addr v3, v4

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    add-float/2addr v0, v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    const v3, 0x3f7349cc

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    mul-float/2addr p0, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    add-float/2addr v0, p0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 p0, 0x3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-array p0, p0, [F

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v3, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    aput v1, p0, v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    aput v2, p0, v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v1, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    aput v0, p0, v1

    const/4 v5, 0x2

    move v6, v5

    return-object p0
.end method

.method public static p(F)F
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/high16 v0, 0x41000000    # 8.0f

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    cmpl-float v0, p0, v0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/high16 v1, 0x42c80000    # 100.0f

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-lez v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    float-to-double v2, p0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-wide/high16 v4, 0x4030000000000000L    # 16.0

    const/4 v7, 0x0

    const-wide/high16 v4, 0x4030000000000000L    # 16.0

    const-wide/high16 v4, 0x4030000000000000L    # 16.0

    const/4 v7, 0x4

    add-double/2addr v2, v4

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-wide/high16 v4, 0x405d000000000000L    # 116.0

    const-wide/high16 v4, 0x405d000000000000L    # 116.0

    const/4 v7, 0x5

    const-wide/high16 v4, 0x405d000000000000L    # 116.0

    const-wide/high16 v4, 0x405d000000000000L    # 116.0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    div-double/2addr v2, v4

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-wide/high16 v4, 0x4008000000000000L    # 3.0

    const-wide/high16 v4, 0x4008000000000000L    # 3.0

    const/4 v7, 0x7

    const-wide/high16 v4, 0x4008000000000000L    # 3.0

    const-wide/high16 v4, 0x4008000000000000L    # 3.0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    double-to-float p0, v2

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    mul-float/2addr p0, v1

    const/4 v6, 0x4

    move v7, v6

    return p0

    :cond_0
    const/4 v7, 0x6

    const v0, 0x4461d2f7

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    div-float/2addr p0, v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    goto :goto_0
.end method
