.class Lcom/google/android/material/color/i$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Lcom/google/android/material/color/i$b;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/material/color/i$b;Lcom/google/android/material/color/i$b;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "t@s/~sbo~o@~@io@@rM@~   no~y b.m~~ /1d@@@S ~@l  @~bic~~ u~@~@@~l t~K~4~f  a-o@~@f@  ~~~ @@vi~@ o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/google/android/material/color/i$b;->a(Lcom/google/android/material/color/i$b;)S

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    invoke-static {p2}, Lcom/google/android/material/color/i$b;->a(Lcom/google/android/material/color/i$b;)S

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    sub-int/2addr p1, p2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return p1
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    check-cast p1, Lcom/google/android/material/color/i$b;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    check-cast p2, Lcom/google/android/material/color/i$b;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/android/material/color/i$a;->a(Lcom/google/android/material/color/i$b;Lcom/google/android/material/color/i$b;)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return p1
.end method
