.class public Lcom/google/android/material/color/m;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/color/m$c;
    }
.end annotation


# static fields
.field private static final d:Lcom/google/android/material/color/l$f;

.field private static final e:Lcom/google/android/material/color/l$e;


# instance fields
.field private final a:I
    .annotation build Landroidx/annotation/f1;
    .end annotation
.end field

.field private final b:Lcom/google/android/material/color/l$f;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final c:Lcom/google/android/material/color/l$e;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/material/color/m$a;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/android/material/color/m$a;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    sput-object v0, Lcom/google/android/material/color/m;->d:Lcom/google/android/material/color/l$f;

    const/4 v1, 0x6

    move v2, v1

    new-instance v0, Lcom/google/android/material/color/m$b;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/google/android/material/color/m$b;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    sput-object v0, Lcom/google/android/material/color/m;->e:Lcom/google/android/material/color/l$e;

    const/4 v2, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method private constructor <init>(Lcom/google/android/material/color/m$c;)V
    .locals 3

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/google/android/material/color/m$c;->a(Lcom/google/android/material/color/m$c;)I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/android/material/color/m;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/google/android/material/color/m$c;->b(Lcom/google/android/material/color/m$c;)Lcom/google/android/material/color/l$f;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    iput-object v0, p0, Lcom/google/android/material/color/m;->b:Lcom/google/android/material/color/l$f;

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/google/android/material/color/m$c;->c(Lcom/google/android/material/color/m$c;)Lcom/google/android/material/color/l$e;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/material/color/m;->c:Lcom/google/android/material/color/l$e;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/android/material/color/m$c;Lcom/google/android/material/color/m$a;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/color/m;-><init>(Lcom/google/android/material/color/m$c;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a()Lcom/google/android/material/color/l$f;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ls@~dc@i  ~o o ~@4@@o@~~ ~~fa~bM@~b ~ @omi- f~@@@~tS~ @tu ~@n.@@K@~~@1or@   vo@ yb~is~/l  @ ~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/google/android/material/color/m;->d:Lcom/google/android/material/color/l$f;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method static synthetic b()Lcom/google/android/material/color/l$e;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/google/android/material/color/m;->e:Lcom/google/android/material/color/l$e;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public c()Lcom/google/android/material/color/l$e;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/color/m;->c:Lcom/google/android/material/color/l$e;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public d()Lcom/google/android/material/color/l$f;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/color/m;->b:Lcom/google/android/material/color/l$f;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public e()I
    .locals 3
    .annotation build Landroidx/annotation/f1;
    .end annotation

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/color/m;->a:I

    const/4 v2, 0x3

    return v0
.end method
