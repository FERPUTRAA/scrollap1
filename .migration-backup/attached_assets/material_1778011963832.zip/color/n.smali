.class public final Lcom/google/android/material/color/n;
.super Ljava/lang/Object;


# static fields
.field private static final c:[I


# instance fields
.field private final a:[I

.field private final b:I
    .annotation build Landroidx/annotation/f1;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x4

    sget v0, Lcom/google/android/material/R$attr;->colorError:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    sget v1, Lcom/google/android/material/R$attr;->colorOnError:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    sget v2, Lcom/google/android/material/R$attr;->colorErrorContainer:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget v3, Lcom/google/android/material/R$attr;->colorOnErrorContainer:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    filled-new-array {v0, v1, v2, v3}, [I

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    sput-object v0, Lcom/google/android/material/color/n;->c:[I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void
.end method

.method private constructor <init>([II)V
    .locals 3
    .param p1    # [I
        .annotation build Landroidx/annotation/f;
        .end annotation

        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p2, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x2

    array-length v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string p2, " usnishobdupealtehasr] iwhyrhttmiciess uynl[  emv cbg.tetnTad oeo te"

    const-string p2, "ccsgTlehv ot ie ieaaal e tmw ttubd][n.nybhhoiosedersyuetmtu pnhr sia"

    const/4 v2, 0x0

    const-string p2, "bhsmhe  Taus dett heo]iiawalsu varnhbtmo upyertinteec y[lmdingot. ec"

    const-string p2, "Theme overlay should be used with the accompanying int[] attributes."

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    throw p1

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/material/color/n;->a:[I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput p2, p0, Lcom/google/android/material/color/n;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public static a([I)Lcom/google/android/material/color/n;
    .locals 4
    .param p0    # [I
        .annotation build Landroidx/annotation/f;
        .end annotation

        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/material/color/n;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    and-int/2addr v3, v2

    invoke-direct {v0, p0, v1}, Lcom/google/android/material/color/n;-><init>([II)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0
.end method

.method public static b([II)Lcom/google/android/material/color/n;
    .locals 3
    .param p0    # [I
        .annotation build Landroidx/annotation/f;
        .end annotation

        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/material/color/n;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {v0, p0, p1}, Lcom/google/android/material/color/n;-><init>([II)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public static c()Lcom/google/android/material/color/n;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget-object v0, Lcom/google/android/material/color/n;->c:[I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget v1, Lcom/google/android/material/R$style;->ThemeOverlay_Material3_HarmonizedColors:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/google/android/material/color/n;->b([II)Lcom/google/android/material/color/n;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0
.end method


# virtual methods
.method public d()[I
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/color/n;->a:[I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public e()I
    .locals 3
    .annotation build Landroidx/annotation/f1;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/color/n;->b:I

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method
