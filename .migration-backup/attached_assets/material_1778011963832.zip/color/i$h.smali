.class Lcom/google/android/material/color/i$h;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/color/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "h"
.end annotation


# static fields
.field private static final m:S = 0x1cs

.field private static final n:I = 0x100

.field private static final o:I = -0x1


# instance fields
.field private final a:Lcom/google/android/material/color/i$e;

.field private final b:I

.field private final c:I

.field private final d:I

.field private final e:I

.field private final f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final h:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "[B>;"
        }
    .end annotation
.end field

.field private final i:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/util/List<",
            "Lcom/google/android/material/color/i$i;",
            ">;>;"
        }
    .end annotation
.end field

.field private final j:Z

.field private final k:I

.field private final l:I


# direct methods
.method varargs constructor <init>(Z[Ljava/lang/String;)V
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x5

    iput-object v0, p0, Lcom/google/android/material/color/i$h;->f:Ljava/util/List;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    iput-object v0, p0, Lcom/google/android/material/color/i$h;->g:Ljava/util/List;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    iput-object v0, p0, Lcom/google/android/material/color/i$h;->h:Ljava/util/List;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v8, 0x1

    or-int/2addr v9, v8

    iput-object v0, p0, Lcom/google/android/material/color/i$h;->i:Ljava/util/List;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/color/i$h;->j:Z

    const/4 v8, 0x0

    const/4 v9, 0x7

    array-length p1, p2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    const/4 v0, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x3

    move v1, v0

    move v1, v0

    const/4 v9, 0x3

    move v1, v0

    move v1, v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    move v2, v1

    move v2, v1

    const/4 v9, 0x3

    move v2, v1

    :goto_0
    const/4 v9, 0x2

    if-ge v1, p1, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    aget-object v3, p2, v1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-direct {p0, v3}, Lcom/google/android/material/color/i$h;->b(Ljava/lang/String;)Landroid/util/Pair;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v4, p0, Lcom/google/android/material/color/i$h;->f:Ljava/util/List;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-object v4, v3, Landroid/util/Pair;->first:Ljava/lang/Object;

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    check-cast v5, [B

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    array-length v5, v5

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    add-int/2addr v2, v5

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v5, p0, Lcom/google/android/material/color/i$h;->h:Ljava/util/List;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {v5, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget-object v4, p0, Lcom/google/android/material/color/i$h;->i:Ljava/util/List;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    iget-object v3, v3, Landroid/util/Pair;->second:Ljava/lang/Object;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-interface {v4, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    goto :goto_0

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-object p1, p0, Lcom/google/android/material/color/i$h;->i:Ljava/util/List;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    move v1, v0

    move v1, v0

    :goto_1
    const/4 v9, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-eqz v3, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    check-cast v3, Ljava/util/List;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-eqz v5, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    check-cast v5, Lcom/google/android/material/color/i$i;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget-object v6, p0, Lcom/google/android/material/color/i$h;->f:Ljava/util/List;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x0

    const/4 v8, 0x2

    invoke-static {v5}, Lcom/google/android/material/color/i$i;->a(Lcom/google/android/material/color/i$i;)[B

    move-result-object v6

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    array-length v6, v6

    const/4 v9, 0x3

    add-int/2addr v2, v6

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-object v6, p0, Lcom/google/android/material/color/i$h;->h:Ljava/util/List;

    const/4 v8, 0x2

    move v9, v8

    invoke-static {v5}, Lcom/google/android/material/color/i$i;->a(Lcom/google/android/material/color/i$i;)[B

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-interface {v6, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    goto :goto_2

    :cond_1
    const/4 v9, 0x0

    iget-object v4, p0, Lcom/google/android/material/color/i$h;->g:Ljava/util/List;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x4

    move v9, v8

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    mul-int/lit8 v3, v3, 0xc

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    add-int/lit8 v3, v3, 0x4

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    add-int/2addr v1, v3

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    goto/16 :goto_1

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    rem-int/lit8 p1, v2, 0x4

    const/4 v9, 0x6

    if-nez p1, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x0

    move p1, v0

    move p1, v0

    move p1, v0

    move p1, v0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    goto :goto_3

    :cond_3
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    rsub-int/lit8 p1, p1, 0x4

    :goto_3
    const/4 v9, 0x2

    const/4 v8, 0x7

    iput p1, p0, Lcom/google/android/material/color/i$h;->k:I

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v3, p0, Lcom/google/android/material/color/i$h;->h:Ljava/util/List;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    iput v3, p0, Lcom/google/android/material/color/i$h;->b:I

    const/4 v8, 0x6

    xor-int/2addr v9, v8

    iget-object v4, p0, Lcom/google/android/material/color/i$h;->h:Ljava/util/List;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    array-length v5, p2

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    sub-int/2addr v4, v5

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    iput v4, p0, Lcom/google/android/material/color/i$h;->c:I

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object v4, p0, Lcom/google/android/material/color/i$h;->h:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    array-length p2, p2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    sub-int/2addr v4, p2

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    const/4 p2, 0x1

    const/4 v8, 0x1

    move v9, v8

    if-lez v4, :cond_4

    const/4 v9, 0x4

    const/4 v8, 0x4

    move v4, p2

    move v4, p2

    const/4 v9, 0x2

    move v4, p2

    move v4, p2

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    goto :goto_4

    :cond_4
    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    move v4, v0

    move v4, v0

    const/4 v9, 0x1

    move v4, v0

    move v4, v0

    :goto_4
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-nez v4, :cond_5

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    iget-object v5, p0, Lcom/google/android/material/color/i$h;->g:Ljava/util/List;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-interface {v5}, Ljava/util/List;->clear()V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object v5, p0, Lcom/google/android/material/color/i$h;->i:Ljava/util/List;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-interface {v5}, Ljava/util/List;->clear()V

    :cond_5
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    mul-int/lit8 v3, v3, 0x4

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/16 v5, 0x1c

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    add-int/2addr v3, v5

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v6, p0, Lcom/google/android/material/color/i$h;->g:Ljava/util/List;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    mul-int/lit8 v6, v6, 0x4

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    add-int/2addr v3, v6

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    iput v3, p0, Lcom/google/android/material/color/i$h;->d:I

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x3

    add-int/2addr v2, p1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-eqz v4, :cond_6

    const/4 v8, 0x1

    move v9, v8

    add-int p1, v3, v2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    goto :goto_5

    :cond_6
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    move p1, v0

    move p1, v0

    :goto_5
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    iput p1, p0, Lcom/google/android/material/color/i$h;->e:I

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    add-int/2addr v3, v2

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eqz v4, :cond_7

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    move v0, v1

    move v0, v1

    const/4 v9, 0x3

    move v0, v1

    move v0, v1

    :cond_7
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    add-int/2addr v3, v0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    iput v3, p0, Lcom/google/android/material/color/i$h;->l:I

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance p1, Lcom/google/android/material/color/i$e;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-direct {p1, p2, v5, v3}, Lcom/google/android/material/color/i$e;-><init>(SSI)V

    const/4 v8, 0x6

    const/4 v8, 0x0

    iput-object p1, p0, Lcom/google/android/material/color/i$h;->a:Lcom/google/android/material/color/i$e;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    return-void
.end method

.method varargs constructor <init>([Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0, v0, p1}, Lcom/google/android/material/color/i$h;-><init>(Z[Ljava/lang/String;)V

    const/4 v2, 0x5

    return-void
.end method

.method private b(Ljava/lang/String;)Landroid/util/Pair;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Landroid/util/Pair<",
            "[B",
            "Ljava/util/List<",
            "Lcom/google/android/material/color/i$i;",
            ">;>;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "Kls~@@ @~  ~@b~~o@~v~@ @@c @ @~d~ @~Sb@~~i1oo@rMl @~~~tf4~@ m y@/~a s~~@/t on- o~ ~o @ ~@ib. ui@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    new-instance v0, Landroid/util/Pair;

    const/4 v3, 0x5

    iget-boolean v1, p0, Lcom/google/android/material/color/i$h;->j:Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/google/android/material/color/i;->e(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/material/color/i;->f(Ljava/lang/String;)[B

    move-result-object p1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0, p1, v1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v3, 0x7

    return-object v0
.end method


# virtual methods
.method a()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/color/i$h;->l:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method c(Ljava/io/ByteArrayOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/color/i$h;->a:Lcom/google/android/material/color/i$e;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/color/i$e;->a(Ljava/io/ByteArrayOutputStream;)V

    const/4 v4, 0x3

    iget v0, p0, Lcom/google/android/material/color/i$h;->b:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/android/material/color/i$h;->c:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/color/i$h;->j:Z

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/16 v0, 0x100

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/android/material/color/i$h;->d:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/color/i$h;->e:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/color/i$h;->f:Ljava/util/List;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    check-cast v1, Ljava/lang/Integer;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x1

    goto :goto_1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/color/i$h;->g:Ljava/util/List;

    const/4 v3, 0x0

    move v4, v3

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    check-cast v1, Ljava/lang/Integer;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v1}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_2

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/color/i$h;->h:Ljava/util/List;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    check-cast v1, [B

    const/4 v4, 0x6

    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write([B)V

    const/4 v3, 0x2

    and-int/2addr v4, v3

    goto :goto_3

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/android/material/color/i$h;->k:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-lez v0, :cond_4

    const/4 v4, 0x1

    new-array v0, v0, [B

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/android/material/color/i$h;->i:Ljava/util/List;

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_4
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v1, :cond_6

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    check-cast v1, Ljava/util/List;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_5
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    if-eqz v2, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    check-cast v2, Lcom/google/android/material/color/i$i;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v2, p1}, Lcom/google/android/material/color/i$i;->b(Ljava/io/ByteArrayOutputStream;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_5

    :cond_5
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v1, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/google/android/material/color/i;->c(I)[B

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1, v1}, Ljava/io/OutputStream;->write([B)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_4

    :cond_6
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method
