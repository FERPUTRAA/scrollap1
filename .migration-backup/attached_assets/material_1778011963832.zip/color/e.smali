.class public final synthetic Lcom/google/android/material/color/e;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/res/loader/ResourcesLoader;Landroid/content/res/loader/ResourcesProvider;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@su ~~@@~r~  ~ao ~b K/vto~@-~@ s~ @Mol.~@~~i~@  ~@ i4t~f@/i 1@om@@@@~@ ~~ d @ l~f~@S ybo ~cnbo@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Landroid/content/res/loader/ResourcesLoader;->addProvider(Landroid/content/res/loader/ResourcesProvider;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method
