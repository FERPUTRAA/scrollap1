.class public interface abstract Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButtonToggleGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "d"
.end annotation


# virtual methods
.method public abstract a(Lcom/google/android/material/button/MaterialButtonToggleGroup;IZ)V
    .param p2    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
.end method
