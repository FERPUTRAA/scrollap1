.class Lcom/google/android/material/button/MaterialButtonToggleGroup$b;
.super Landroidx/core/view/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/android/material/button/MaterialButtonToggleGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/google/android/material/button/MaterialButtonToggleGroup;


# direct methods
.method constructor <init>(Lcom/google/android/material/button/MaterialButtonToggleGroup;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$b;->a:Lcom/google/android/material/button/MaterialButtonToggleGroup;

    const/4 v1, 0x6

    invoke-direct {p0}, Landroidx/core/view/a;-><init>()V

    const/4 v0, 0x1

    and-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroidx/core/view/accessibility/l0;)V
    .locals 8
    .param p2    # Landroidx/core/view/accessibility/l0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "M~s @ilt ~@@@y/@K@oo/~o@@~1b~s-i~@u@ ~~~ n~~a~@ 4~c @@o  ~~o@ @ fo r t~~  @~@~@b@S @db~~f~. livm"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x3

    invoke-super {p0, p1, p2}, Landroidx/core/view/a;->onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroidx/core/view/accessibility/l0;)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v1, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$b;->a:Lcom/google/android/material/button/MaterialButtonToggleGroup;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v2, p1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->a(Lcom/google/android/material/button/MaterialButtonToggleGroup;Landroid/view/View;)I

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v4, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    check-cast p1, Lcom/google/android/material/button/MaterialButton;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p1}, Lcom/google/android/material/button/MaterialButton;->isChecked()Z

    move-result v5

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static/range {v0 .. v5}, Landroidx/core/view/accessibility/l0$c;->h(IIIIZZ)Landroidx/core/view/accessibility/l0$c;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p2, p1}, Landroidx/core/view/accessibility/l0;->Z0(Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    return-void
.end method
