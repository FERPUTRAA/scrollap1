.class Lcom/google/android/material/button/MaterialButtonToggleGroup$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/material/button/MaterialButtonToggleGroup;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "c"
.end annotation


# static fields
.field private static final e:Lcom/google/android/material/shape/d;


# instance fields
.field a:Lcom/google/android/material/shape/d;

.field b:Lcom/google/android/material/shape/d;

.field c:Lcom/google/android/material/shape/d;

.field d:Lcom/google/android/material/shape/d;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Lcom/google/android/material/shape/a;

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/android/material/shape/a;-><init>(F)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    sput-object v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->e:Lcom/google/android/material/shape/d;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method constructor <init>(Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->a:Lcom/google/android/material/shape/d;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p3, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->b:Lcom/google/android/material/shape/d;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p4, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->c:Lcom/google/android/material/shape/d;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->d:Lcom/google/android/material/shape/d;

    const/4 v0, 0x0

    or-int/2addr v1, v0

    return-void
.end method

.method public static a(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@osrK/o4 @ds~~bb@~ @@i @f@ v~ycml@ @@@@~ af ~1iM otn.i ~/~~o~@~b@~~~~  lt@@ -~~ o~~@ @u@ ~~~  o@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    new-instance v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget-object v1, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->e:Lcom/google/android/material/shape/d;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->d:Lcom/google/android/material/shape/d;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object p0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->c:Lcom/google/android/material/shape/d;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2, v1, p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;-><init>(Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object v0
.end method

.method public static b(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;Landroid/view/View;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p1}, Lcom/google/android/material/internal/y;->k(Landroid/view/View;)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->c(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    invoke-static {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->d(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    move-result-object p0

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public static c(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->a:Lcom/google/android/material/shape/d;

    const/4 v3, 0x1

    move v4, v3

    iget-object p0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->d:Lcom/google/android/material/shape/d;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget-object v2, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->e:Lcom/google/android/material/shape/d;

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-direct {v0, v1, p0, v2, v2}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;-><init>(Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    return-object v0
.end method

.method public static d(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object v1, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->e:Lcom/google/android/material/shape/d;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->b:Lcom/google/android/material/shape/d;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->c:Lcom/google/android/material/shape/d;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0, v1, v1, v2, p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;-><init>(Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;)V

    const/4 v4, 0x0

    return-object v0
.end method

.method public static e(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;Landroid/view/View;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p1}, Lcom/google/android/material/internal/y;->k(Landroid/view/View;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->d(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->c(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    move-result-object p0

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method

.method public static f(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->a:Lcom/google/android/material/shape/d;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    sget-object v2, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->e:Lcom/google/android/material/shape/d;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object p0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->b:Lcom/google/android/material/shape/d;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2, p0, v2}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;-><init>(Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;)V

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object v0
.end method
