.class public Lcom/google/android/material/button/MaterialButtonToggleGroup;
.super Landroid/widget/LinearLayout;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/button/MaterialButtonToggleGroup$c;,
        Lcom/google/android/material/button/MaterialButtonToggleGroup$e;,
        Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
    }
.end annotation


# static fields
.field private static final k:Ljava/lang/String; = "MaterialButtonToggleGroup"

.field private static final l:I


# instance fields
.field private final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/android/material/button/MaterialButtonToggleGroup$c;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lcom/google/android/material/button/MaterialButtonToggleGroup$e;

.field private final c:Ljava/util/LinkedHashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashSet<",
            "Lcom/google/android/material/button/MaterialButtonToggleGroup$d;",
            ">;"
        }
    .end annotation
.end field

.field private final d:Ljava/util/Comparator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Comparator<",
            "Lcom/google/android/material/button/MaterialButton;",
            ">;"
        }
    .end annotation
.end field

.field private e:[Ljava/lang/Integer;

.field private f:Z

.field private g:Z

.field private h:Z

.field private final i:I
    .annotation build Landroidx/annotation/d0;
    .end annotation
.end field

.field private j:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_MaterialButtonToggleGroup:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    sput v0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->l:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x7

    sget v0, Lcom/google/android/material/R$attr;->materialButtonToggleGroupStyle:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 8
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    sget v4, Lcom/google/android/material/button/MaterialButtonToggleGroup;->l:I

    const/4 v6, 0x1

    shl-int/2addr v7, v6

    invoke-static {p1, p2, p3, v4}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    new-instance p1, Ljava/util/ArrayList;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->a:Ljava/util/List;

    const/4 v7, 0x1

    new-instance p1, Lcom/google/android/material/button/MaterialButtonToggleGroup$e;

    const/4 v7, 0x2

    const/4 v0, 0x7

    const/4 v7, 0x6

    const/4 v0, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {p1, p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$e;-><init>(Lcom/google/android/material/button/MaterialButtonToggleGroup;Lcom/google/android/material/button/MaterialButtonToggleGroup$a;)V

    const/4 v7, 0x3

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->b:Lcom/google/android/material/button/MaterialButtonToggleGroup$e;

    const/4 v7, 0x7

    const/4 v6, 0x4

    new-instance p1, Ljava/util/LinkedHashSet;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x5

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->c:Ljava/util/LinkedHashSet;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance p1, Lcom/google/android/material/button/MaterialButtonToggleGroup$a;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {p1, p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$a;-><init>(Lcom/google/android/material/button/MaterialButtonToggleGroup;)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->d:Ljava/util/Comparator;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 p1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->f:Z

    const/4 v6, 0x3

    move v7, v6

    new-instance v0, Ljava/util/HashSet;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j:Ljava/util/Set;

    const/4 v7, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    sget-object v2, Lcom/google/android/material/R$styleable;->MaterialButtonToggleGroup:[I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-array v5, p1, [I

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    move v3, p3

    move v3, p3

    const/4 v7, 0x0

    move v3, p3

    move v3, p3

    const/4 v7, 0x0

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    sget p3, Lcom/google/android/material/R$styleable;->MaterialButtonToggleGroup_singleSelection:I

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p2, p3, p1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p3

    const/4 v7, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0, p3}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->setSingleSelection(Z)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    sget p3, Lcom/google/android/material/R$styleable;->MaterialButtonToggleGroup_checkedButton:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/4 v0, -0x1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p2, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput p3, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->i:I

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    sget p3, Lcom/google/android/material/R$styleable;->MaterialButtonToggleGroup_selectionRequired:I

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p2, p3, p1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->h:Z

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/4 p1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->setChildrenDrawingOrderEnabled(Z)V

    const/4 v6, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v7, 0x7

    const/4 v6, 0x2

    invoke-static {p0, p1}, Landroidx/core/view/k1;->R1(Landroid/view/View;I)V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-void
.end method

.method static synthetic a(Lcom/google/android/material/button/MaterialButtonToggleGroup;Landroid/view/View;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s@/@o oib@v ~ @cio4  @l~~a~l@~Mo ~@ @ @@~o ~~-~o@ Sft~f.u~n/~b~i ~@d@@~s @ mb@~@~~@  @ 1 Kyr@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->k(Landroid/view/View;)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p0
.end method

.method private c()V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->getFirstVisibleChildIndex()I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    const/4 v1, -0x1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-ne v0, v1, :cond_0

    const/4 v8, 0x5

    return-void

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    add-int/lit8 v1, v0, 0x1

    :goto_0
    const/4 v8, 0x6

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-ge v1, v2, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-direct {p0, v1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j(I)Lcom/google/android/material/button/MaterialButton;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    add-int/lit8 v3, v1, -0x1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct {p0, v3}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j(I)Lcom/google/android/material/button/MaterialButton;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v2}, Lcom/google/android/material/button/MaterialButton;->getStrokeWidth()I

    move-result v4

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v3}, Lcom/google/android/material/button/MaterialButton;->getStrokeWidth()I

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {v4, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-direct {p0, v2}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->d(Landroid/view/View;)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v4

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getOrientation()I

    move-result v5

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v6, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-nez v5, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {v4, v6}, Landroidx/core/view/g0;->g(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    neg-int v3, v3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {v4, v3}, Landroidx/core/view/g0;->h(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    iput v6, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    goto :goto_1

    :cond_1
    const/4 v7, 0x5

    iput v6, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    neg-int v3, v3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    iput v3, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v8, 0x1

    const/4 v7, 0x2

    invoke-static {v4, v6}, Landroidx/core/view/g0;->h(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x4

    invoke-virtual {v2, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    goto :goto_0

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-direct {p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->r(I)V

    const/4 v7, 0x7

    move v8, v7

    return-void
.end method

.method private d(Landroid/view/View;)Landroid/widget/LinearLayout$LayoutParams;
    .locals 4
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    instance-of v0, p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v1, p1, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget p1, p1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0, v1, p1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0
.end method

.method private f(IZ)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ne p1, v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object p2, Lcom/google/android/material/button/MaterialButtonToggleGroup;->k:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    move v3, v2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string/jumbo v1, "n  molt:IaBdD stv io tin"

    const-string/jumbo v1, "otsit  Dno  n vt:lsBaIid"

    const-string/jumbo v1, "udioov Bitn a ntto Il:sD"

    const-string v1, "Button ID is not valid: "

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    new-instance v0, Ljava/util/HashSet;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j:Ljava/util/Set;

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz p2, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-boolean p2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->g:Z

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    if-eqz p2, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez p2, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/Set;->clear()V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    goto :goto_0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez p2, :cond_5

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {v0, p2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz p2, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-boolean p2, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->h:Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz p2, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Set;->size()I

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x1

    or-int/2addr v3, v1

    const/4 v2, 0x7

    move v3, v2

    if-le p2, v1, :cond_4

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    :cond_4
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->v(Ljava/util/Set;)V

    :cond_5
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method private getFirstVisibleChildIndex()I
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-ge v1, v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {p0, v1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->m(I)Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    return v1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    move v4, v3

    const/4 v0, -0x1

    move v4, v0

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    return v0
.end method

.method private getLastVisibleChildIndex()I
    .locals 4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x1

    if-ltz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->m(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    return v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    return v0
.end method

.method private getVisibleButtonCount()I
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    move v1, v0

    move v1, v0

    const/4 v4, 0x6

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-ge v0, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    instance-of v2, v2, Lcom/google/android/material/button/MaterialButton;

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->m(I)Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    return v1
.end method

.method private i(IZ)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->c:Ljava/util/LinkedHashSet;

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v1, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-interface {v1, p0, p1, p2}, Lcom/google/android/material/button/MaterialButtonToggleGroup$d;->a(Lcom/google/android/material/button/MaterialButtonToggleGroup;IZ)V

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method private j(I)Lcom/google/android/material/button/MaterialButton;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    check-cast p1, Lcom/google/android/material/button/MaterialButton;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1
.end method

.method private k(Landroid/view/View;)I
    .locals 6
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x0

    instance-of v0, p1, Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v1, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v1

    :cond_0
    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    move v2, v0

    move v2, v0

    const/4 v5, 0x0

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x7

    if-ge v0, v3, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ne v3, p1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    return v2

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    instance-of v3, v3, Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->m(I)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    add-int/lit8 v2, v2, 0x1

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    goto :goto_0

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x3

    return v1
.end method

.method private l(III)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->a:Ljava/util/List;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ne p2, p3, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getOrientation()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-ne p1, p2, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0, p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->e(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;Landroid/view/View;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_1

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->f(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    move-result-object p1

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    return-object p1

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ne p1, p3, :cond_5

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v1, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0, p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->b(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;Landroid/view/View;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_2

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->a(Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    move-result-object p1

    :goto_2
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p1

    :cond_5
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p1
.end method

.method private m(I)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/16 v0, 0x8

    const/4 v2, 0x0

    const/4 v1, 0x6

    if-eq p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return p1
.end method

.method private r(I)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v0, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-ne p1, v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j(I)Lcom/google/android/material/button/MaterialButton;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/widget/LinearLayout;->getOrientation()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-ne v0, v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput v2, p1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v2, p1, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p1, v2}, Landroidx/core/view/g0;->g(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p1, v2}, Landroidx/core/view/g0;->h(Landroid/view/ViewGroup$MarginLayoutParams;I)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput v2, p1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput v2, p1, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    :cond_2
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method private s(IZ)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    instance-of v0, p1, Lcom/google/android/material/button/MaterialButton;

    const/4 v2, 0x5

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    shr-int/2addr v1, v0

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->f:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast p1, Lcom/google/android/material/button/MaterialButton;

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {p1, p2}, Lcom/google/android/material/button/MaterialButton;->setChecked(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->f:Z

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method private setGeneratedIdIfNeeded(Lcom/google/android/material/button/MaterialButton;)V
    .locals 4
    .param p1    # Lcom/google/android/material/button/MaterialButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {}, Landroidx/core/view/k1;->D()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/view/View;->setId(I)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method private setupButtonChild(Lcom/google/android/material/button/MaterialButton;)V
    .locals 4
    .param p1    # Lcom/google/android/material/button/MaterialButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setMaxLines(I)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v1, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Lcom/google/android/material/button/MaterialButton;->setCheckable(Z)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->b:Lcom/google/android/material/button/MaterialButtonToggleGroup$e;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1, v1}, Lcom/google/android/material/button/MaterialButton;->setOnPressedChangeListenerInternal(Lcom/google/android/material/button/MaterialButton$c;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Lcom/google/android/material/button/MaterialButton;->setShouldDrawSurfaceColorStroke(Z)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method private static u(Lcom/google/android/material/shape/o$b;Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)V
    .locals 3
    .param p1    # Lcom/google/android/material/button/MaterialButtonToggleGroup$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/shape/o$b;->o(F)Lcom/google/android/material/shape/o$b;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p1, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->a:Lcom/google/android/material/shape/d;

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/shape/o$b;->L(Lcom/google/android/material/shape/d;)Lcom/google/android/material/shape/o$b;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    iget-object v0, p1, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->d:Lcom/google/android/material/shape/d;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/shape/o$b;->y(Lcom/google/android/material/shape/d;)Lcom/google/android/material/shape/o$b;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p1, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->b:Lcom/google/android/material/shape/d;

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/android/material/shape/o$b;->Q(Lcom/google/android/material/shape/d;)Lcom/google/android/material/shape/o$b;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object p1, p1, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;->c:Lcom/google/android/material/shape/d;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/shape/o$b;->D(Lcom/google/android/material/shape/d;)Lcom/google/android/material/shape/o$b;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method private v(Ljava/util/Set;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j:Ljava/util/Set;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v1, Ljava/util/HashSet;

    const/4 v6, 0x7

    invoke-direct {v1, p1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    iput-object v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j:Ljava/util/Set;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-ge v1, v2, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {p0, v1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j(I)Lcom/google/android/material/button/MaterialButton;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v2}, Landroid/view/View;->getId()I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {p1, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {p0, v2, v3}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->s(IZ)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v0, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {p1, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eq v3, v4, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {p1, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {p0, v2, v3}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->i(IZ)V

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    return-void
.end method

.method private w()V
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    new-instance v0, Ljava/util/TreeMap;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->d:Ljava/util/Comparator;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v0, v1}, Ljava/util/TreeMap;-><init>(Ljava/util/Comparator;)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v2, 0x0

    const/4 v7, 0x4

    move v3, v2

    move v3, v2

    const/4 v7, 0x0

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-ge v3, v1, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {p0, v3}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j(I)Lcom/google/android/material/button/MaterialButton;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-interface {v0, v4, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-interface {v0}, Ljava/util/SortedMap;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-array v1, v2, [Ljava/lang/Integer;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-interface {v0, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    check-cast v0, [Ljava/lang/Integer;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    iput-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->e:[Ljava/lang/Integer;

    const/4 v7, 0x2

    return-void
.end method


# virtual methods
.method public addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    instance-of v0, p1, Lcom/google/android/material/button/MaterialButton;

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    if-nez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    sget-object p1, Lcom/google/android/material/button/MaterialButtonToggleGroup;->k:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const-string/jumbo p2, "ttemibvCtwu  eed fbopru ehiin o.maaM Byltts"

    const-string/jumbo p2, "tepmtebCt moyiuileunohlf.sa Mavi  ewrttB  d"

    const/4 v5, 0x4

    const-string/jumbo p2, "feileiuBe sl M.dbrotCvaiup h s tytnmtawo et"

    const-string p2, "Child views must be of type MaterialButton."

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-super {p0, p1, p2, p3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast p1, Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->setGeneratedIdIfNeeded(Lcom/google/android/material/button/MaterialButton;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->setupButtonChild(Lcom/google/android/material/button/MaterialButton;)V

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p2

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/button/MaterialButton;->isChecked()Z

    move-result p3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {p0, p2, p3}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->f(IZ)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/android/material/button/MaterialButton;->getShapeAppearanceModel()Lcom/google/android/material/shape/o;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object p3, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->a:Ljava/util/List;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance v0, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p2}, Lcom/google/android/material/shape/o;->r()Lcom/google/android/material/shape/d;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-virtual {p2}, Lcom/google/android/material/shape/o;->j()Lcom/google/android/material/shape/d;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p2}, Lcom/google/android/material/shape/o;->t()Lcom/google/android/material/shape/d;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p2}, Lcom/google/android/material/shape/o;->l()Lcom/google/android/material/shape/d;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v0, v1, v2, v3, p2}, Lcom/google/android/material/button/MaterialButtonToggleGroup$c;-><init>(Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;Lcom/google/android/material/shape/d;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {p3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance p2, Lcom/google/android/material/button/MaterialButtonToggleGroup$b;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p2, p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup$b;-><init>(Lcom/google/android/material/button/MaterialButtonToggleGroup;)V

    const/4 v4, 0x5

    xor-int/2addr v5, v4

    invoke-static {p1, p2}, Landroidx/core/view/k1;->B1(Landroid/view/View;Landroidx/core/view/a;)V

    const/4 v4, 0x6

    move v5, v4

    return-void
.end method

.method public b(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;)V
    .locals 3
    .param p1    # Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->c:Ljava/util/LinkedHashSet;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method protected dispatchDraw(Landroid/graphics/Canvas;)V
    .locals 2
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->w()V

    const/4 v1, 0x3

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->dispatchDraw(Landroid/graphics/Canvas;)V

    const/4 v0, 0x6

    shl-int/2addr v1, v0

    return-void
.end method

.method public e(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->f(IZ)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public g()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->v(Ljava/util/Set;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public getCheckedButtonId()I
    .locals 3
    .annotation build Landroidx/annotation/d0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->g:Z

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j:Ljava/util/Set;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j:Ljava/util/Set;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast v0, Ljava/lang/Integer;

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, -0x1

    :goto_0
    const/4 v2, 0x5

    return v0
.end method

.method public getCheckedButtonIds()Ljava/util/List;
    .locals 7
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-ge v1, v2, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-direct {p0, v1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j(I)Lcom/google/android/material/button/MaterialButton;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-virtual {v2}, Landroid/view/View;->getId()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j:Ljava/util/Set;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {v3, v4}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v3, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object v0
.end method

.method protected getChildDrawingOrder(II)I
    .locals 3

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->e:[Ljava/lang/Integer;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    array-length v0, p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-lt p2, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    aget-object p1, p1, p2

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return p1

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object p1, Lcom/google/android/material/button/MaterialButtonToggleGroup;->k:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const-string v0, " dtseCwperrpaooda// ddhl un"

    const-string/jumbo v0, "sadpo rerhdo/daduCi l/ newt"

    const/4 v2, 0x2

    const-string/jumbo v0, "etdlw idqrh aosrdptun/aeC /"

    const-string v0, "Child order wasn\'t updated"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x0

    return p2
.end method

.method public h()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->c:Ljava/util/LinkedHashSet;

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->clear()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public n()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->h:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public o()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->g:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method protected onFinishInflate()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-super {p0}, Landroid/widget/LinearLayout;->onFinishInflate()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->i:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eq v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-static {v0}, Ljava/util/Collections;->singleton(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->v(Ljava/util/Set;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method public onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 6
    .param p1    # Landroid/view/accessibility/AccessibilityNodeInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p1}, Landroidx/core/view/accessibility/l0;->X1(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroidx/core/view/accessibility/l0;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->getVisibleButtonCount()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->o()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v2, 0x1

    and-int/2addr v5, v2

    const/4 v4, 0x3

    move v5, v4

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v1, 0x2

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v2, v0, v3, v1}, Landroidx/core/view/accessibility/l0$b;->f(IIZI)Landroidx/core/view/accessibility/l0$b;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Landroidx/core/view/accessibility/l0;->Y0(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void
.end method

.method protected onMeasure(II)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->x()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->c()V

    const/4 v1, 0x6

    invoke-super {p0, p1, p2}, Landroid/widget/LinearLayout;->onMeasure(II)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public onViewRemoved(Landroid/view/View;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-super {p0, p1}, Landroid/widget/LinearLayout;->onViewRemoved(Landroid/view/View;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    instance-of v0, p1, Lcom/google/android/material/button/MaterialButton;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->setOnPressedChangeListenerInternal(Lcom/google/android/material/button/MaterialButton$c;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-ltz p1, :cond_1

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->a:Ljava/util/List;

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->x()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->c()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method p(Lcom/google/android/material/button/MaterialButton;Z)V
    .locals 3
    .param p1    # Lcom/google/android/material/button/MaterialButton;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->f:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->f(IZ)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public q(Lcom/google/android/material/button/MaterialButtonToggleGroup$d;)V
    .locals 3
    .param p1    # Lcom/google/android/material/button/MaterialButtonToggleGroup$d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->c:Ljava/util/LinkedHashSet;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public setSelectionRequired(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->h:Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public setSingleSelection(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->setSingleSelection(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public setSingleSelection(Z)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->g:Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButtonToggleGroup;->g:Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->g()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public t(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v0, 0x5

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->f(IZ)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method x()V
    .locals 9
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v8, 0x7

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->getFirstVisibleChildIndex()I

    move-result v1

    const/4 v8, 0x5

    const/4 v7, 0x7

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->getLastVisibleChildIndex()I

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v3, 0x0

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-ge v3, v0, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-direct {p0, v3}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->j(I)Lcom/google/android/material/button/MaterialButton;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v5

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/16 v6, 0x8

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-ne v5, v6, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    goto :goto_1

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v4}, Lcom/google/android/material/button/MaterialButton;->getShapeAppearanceModel()Lcom/google/android/material/shape/o;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v5}, Lcom/google/android/material/shape/o;->v()Lcom/google/android/material/shape/o$b;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-direct {p0, v3, v1, v2}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->l(III)Lcom/google/android/material/button/MaterialButtonToggleGroup$c;

    move-result-object v6

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v5, v6}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->u(Lcom/google/android/material/shape/o$b;Lcom/google/android/material/button/MaterialButtonToggleGroup$c;)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v5}, Lcom/google/android/material/shape/o$b;->m()Lcom/google/android/material/shape/o;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v4, v5}, Lcom/google/android/material/button/MaterialButton;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto :goto_0

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x0

    return-void
.end method
