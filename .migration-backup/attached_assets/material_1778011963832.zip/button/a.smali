.class Lcom/google/android/material/button/a;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field private static final t:Z
    .annotation build Landroidx/annotation/k;
        api = 0x15
    .end annotation
.end field

.field private static final u:Z


# instance fields
.field private final a:Lcom/google/android/material/button/MaterialButton;

.field private b:Lcom/google/android/material/shape/o;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:Landroid/graphics/PorterDuff$Mode;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private j:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private k:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private l:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private m:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private n:Z

.field private o:Z

.field private p:Z

.field private q:Z

.field private r:Landroid/graphics/drawable/LayerDrawable;

.field private s:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x2

    sput-boolean v0, Lcom/google/android/material/button/a;->t:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    move v2, v1

    sput-boolean v0, Lcom/google/android/material/button/a;->u:Z

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method constructor <init>(Lcom/google/android/material/button/MaterialButton;Lcom/google/android/material/shape/o;)V
    .locals 3
    .param p2    # Lcom/google/android/material/shape/o;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-boolean v0, p0, Lcom/google/android/material/button/a;->n:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/google/android/material/button/a;->o:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/google/android/material/button/a;->p:Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p2, p0, Lcom/google/android/material/button/a;->b:Lcom/google/android/material/shape/o;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method private E(II)V
    .locals 9
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, " ~sf~ ~ @/r@d~s cSoyoiu@@~~~@@ o.lb~@v~~@@   b@m t ~ @@~@~@o i~ @~~/@~i1M~bl~ otn  -ao~fK~4@~ @@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v8, 0x0

    invoke-static {v0}, Landroidx/core/view/k1;->k0(Landroid/view/View;)I

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    iget-object v1, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v8, 0x7

    invoke-virtual {v1}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v2, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v7, 0x0

    move v8, v7

    invoke-static {v2}, Landroidx/core/view/k1;->j0(Landroid/view/View;)I

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-object v3, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v3}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget v4, p0, Lcom/google/android/material/button/a;->e:I

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget v5, p0, Lcom/google/android/material/button/a;->f:I

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    iput p2, p0, Lcom/google/android/material/button/a;->f:I

    const/4 v8, 0x7

    const/4 v7, 0x3

    iput p1, p0, Lcom/google/android/material/button/a;->e:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-boolean v6, p0, Lcom/google/android/material/button/a;->o:Z

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-nez v6, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-direct {p0}, Lcom/google/android/material/button/a;->F()V

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-object v6, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    add-int/2addr v1, p1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    sub-int/2addr v1, v4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    add-int/2addr v3, p2

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    sub-int/2addr v3, v5

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {v6, v0, v1, v2, v3}, Landroidx/core/view/k1;->d2(Landroid/view/View;IIII)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    return-void
.end method

.method private F()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/button/a;->a()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->setInternalBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/android/material/button/a;->s:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    int-to-float v1, v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/material/shape/j;->n0(F)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method private G(Lcom/google/android/material/shape/o;)V
    .locals 6
    .param p1    # Lcom/google/android/material/shape/o;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-boolean v0, Lcom/google/android/material/button/a;->u:Z

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/button/a;->o:Z

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {p1}, Landroidx/core/view/k1;->k0(Landroid/view/View;)I

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getPaddingTop()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v1}, Landroidx/core/view/k1;->j0(Landroid/view/View;)I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v2}, Landroid/view/View;->getPaddingBottom()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/android/material/button/a;->F()V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v3, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v3, p1, v0, v1, v2}, Landroidx/core/view/k1;->d2(Landroid/view/View;IIII)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/google/android/material/button/a;->n()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_2

    const/4 v4, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/android/material/button/a;->n()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->e()Lcom/google/android/material/shape/s;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v0, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->e()Lcom/google/android/material/shape/s;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    invoke-interface {v0, p1}, Lcom/google/android/material/shape/s;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    :cond_3
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-void
.end method

.method private I()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/google/android/material/button/a;->n()Lcom/google/android/material/shape/j;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    move v5, v4

    iget v2, p0, Lcom/google/android/material/button/a;->h:I

    const/4 v4, 0x5

    move v5, v4

    int-to-float v2, v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/google/android/material/button/a;->k:Landroid/content/res/ColorStateList;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v2, v3}, Lcom/google/android/material/shape/j;->E0(FLandroid/content/res/ColorStateList;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/android/material/button/a;->h:I

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    int-to-float v0, v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-boolean v2, p0, Lcom/google/android/material/button/a;->n:Z

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v2, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    sget v3, Lcom/google/android/material/R$attr;->colorSurface:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v2, v3}, Lcom/google/android/material/color/s;->d(Landroid/view/View;I)I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1, v0, v2}, Lcom/google/android/material/shape/j;->D0(FI)V

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void
.end method

.method private J(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/InsetDrawable;
    .locals 9
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-instance v6, Landroid/graphics/drawable/InsetDrawable;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget v2, p0, Lcom/google/android/material/button/a;->c:I

    const/4 v8, 0x0

    iget v3, p0, Lcom/google/android/material/button/a;->e:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget v4, p0, Lcom/google/android/material/button/a;->d:I

    const/4 v7, 0x0

    move v8, v7

    iget v5, p0, Lcom/google/android/material/button/a;->f:I

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct/range {v0 .. v5}, Landroid/graphics/drawable/InsetDrawable;-><init>(Landroid/graphics/drawable/Drawable;IIII)V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    return-object v6
.end method

.method private a()Landroid/graphics/drawable/Drawable;
    .locals 10

    const/4 v8, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    new-instance v0, Lcom/google/android/material/shape/j;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/google/android/material/button/a;->b:Lcom/google/android/material/shape/o;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-direct {v0, v1}, Lcom/google/android/material/shape/j;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x2

    invoke-virtual {v0, v1}, Lcom/google/android/material/shape/j;->Z(Landroid/content/Context;)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/google/android/material/button/a;->j:Landroid/content/res/ColorStateList;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {v0, v1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/google/android/material/button/a;->i:Landroid/graphics/PorterDuff$Mode;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eqz v1, :cond_0

    const/4 v9, 0x6

    invoke-static {v0, v1}, Landroidx/core/graphics/drawable/d;->p(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget v1, p0, Lcom/google/android/material/button/a;->h:I

    int-to-float v1, v1

    const/4 v9, 0x1

    iget-object v2, p0, Lcom/google/android/material/button/a;->k:Landroid/content/res/ColorStateList;

    const/4 v9, 0x2

    const/4 v8, 0x3

    invoke-virtual {v0, v1, v2}, Lcom/google/android/material/shape/j;->E0(FLandroid/content/res/ColorStateList;)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    new-instance v1, Lcom/google/android/material/shape/j;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v2, p0, Lcom/google/android/material/button/a;->b:Lcom/google/android/material/shape/o;

    const/4 v9, 0x5

    invoke-direct {v1, v2}, Lcom/google/android/material/shape/j;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v2, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v1, v2}, Lcom/google/android/material/shape/j;->setTint(I)V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget v3, p0, Lcom/google/android/material/button/a;->h:I

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    int-to-float v3, v3

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget-boolean v4, p0, Lcom/google/android/material/button/a;->n:Z

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-eqz v4, :cond_1

    const/4 v9, 0x7

    iget-object v4, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    sget v5, Lcom/google/android/material/R$attr;->colorSurface:I

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {v4, v5}, Lcom/google/android/material/color/s;->d(Landroid/view/View;I)I

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x1

    goto :goto_0

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    move v4, v2

    move v4, v2

    move v4, v2

    move v4, v2

    :goto_0
    const/4 v9, 0x5

    invoke-virtual {v1, v3, v4}, Lcom/google/android/material/shape/j;->D0(FI)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    sget-boolean v3, Lcom/google/android/material/button/a;->t:Z

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 v4, 0x2

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v5, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-eqz v3, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    new-instance v3, Lcom/google/android/material/shape/j;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v6, p0, Lcom/google/android/material/button/a;->b:Lcom/google/android/material/shape/o;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-direct {v3, v6}, Lcom/google/android/material/shape/j;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v8, 0x4

    xor-int/2addr v9, v8

    iput-object v3, p0, Lcom/google/android/material/button/a;->m:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 v6, -0x1

    const/4 v8, 0x0

    move v9, v8

    invoke-static {v3, v6}, Landroidx/core/graphics/drawable/d;->n(Landroid/graphics/drawable/Drawable;I)V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    new-instance v3, Landroid/graphics/drawable/RippleDrawable;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    iget-object v6, p0, Lcom/google/android/material/button/a;->l:Landroid/content/res/ColorStateList;

    const/4 v9, 0x3

    invoke-static {v6}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object v6

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    new-instance v7, Landroid/graphics/drawable/LayerDrawable;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-array v4, v4, [Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    aput-object v1, v4, v2

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    aput-object v0, v4, v5

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-direct {v7, v4}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    const/4 v9, 0x4

    const/4 v8, 0x6

    invoke-direct {p0, v7}, Lcom/google/android/material/button/a;->J(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/InsetDrawable;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/google/android/material/button/a;->m:Landroid/graphics/drawable/Drawable;

    const/4 v8, 0x1

    or-int/2addr v9, v8

    invoke-direct {v3, v6, v0, v1}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v8, 0x4

    or-int/2addr v9, v8

    iput-object v3, p0, Lcom/google/android/material/button/a;->r:Landroid/graphics/drawable/LayerDrawable;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    return-object v3

    :cond_2
    const/4 v8, 0x0

    move v9, v8

    new-instance v3, Lcom/google/android/material/ripple/a;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v6, p0, Lcom/google/android/material/button/a;->b:Lcom/google/android/material/shape/o;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-direct {v3, v6}, Lcom/google/android/material/ripple/a;-><init>(Lcom/google/android/material/shape/o;)V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    iput-object v3, p0, Lcom/google/android/material/button/a;->m:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    iget-object v6, p0, Lcom/google/android/material/button/a;->l:Landroid/content/res/ColorStateList;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-static {v6}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object v6

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {v3, v6}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    new-instance v3, Landroid/graphics/drawable/LayerDrawable;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 v6, 0x3

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    new-array v6, v6, [Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    aput-object v1, v6, v2

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    aput-object v0, v6, v5

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/google/android/material/button/a;->m:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    aput-object v0, v6, v4

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-direct {v3, v6}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    iput-object v3, p0, Lcom/google/android/material/button/a;->r:Landroid/graphics/drawable/LayerDrawable;

    const/4 v9, 0x1

    invoke-direct {p0, v3}, Lcom/google/android/material/button/a;->J(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/InsetDrawable;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    return-object v0
.end method

.method private g(Z)Lcom/google/android/material/shape/j;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/button/a;->r:Landroid/graphics/drawable/LayerDrawable;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/graphics/drawable/LayerDrawable;->getNumberOfLayers()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-lez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-boolean v0, Lcom/google/android/material/button/a;->t:Z

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/a;->r:Landroid/graphics/drawable/LayerDrawable;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/LayerDrawable;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    check-cast v0, Landroid/graphics/drawable/InsetDrawable;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/graphics/drawable/DrawableWrapper;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    check-cast v0, Landroid/graphics/drawable/LayerDrawable;

    const/4 v3, 0x4

    const/4 v2, 0x0

    xor-int/lit8 p1, p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/LayerDrawable;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    check-cast p1, Lcom/google/android/material/shape/j;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/a;->r:Landroid/graphics/drawable/LayerDrawable;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    xor-int/lit8 p1, p1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/LayerDrawable;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast p1, Lcom/google/android/material/shape/j;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p1

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p1
.end method

.method private n()Lcom/google/android/material/shape/j;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/google/android/material/button/a;->g(Z)Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method A(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/a;->k:Landroid/content/res/ColorStateList;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/material/button/a;->k:Landroid/content/res/ColorStateList;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/button/a;->I()V

    :cond_0
    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method B(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/button/a;->h:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eq v0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/android/material/button/a;->h:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/button/a;->I()V

    :cond_0
    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method C(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/a;->j:Landroid/content/res/ColorStateList;

    const/4 v2, 0x7

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/material/button/a;->j:Landroid/content/res/ColorStateList;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/button/a;->j:Landroid/content/res/ColorStateList;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method D(Landroid/graphics/PorterDuff$Mode;)V
    .locals 3
    .param p1    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/button/a;->i:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x1

    const/4 v1, 0x6

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/material/button/a;->i:Landroid/graphics/PorterDuff$Mode;

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/google/android/material/button/a;->i:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/a;->i:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->p(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method H(II)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/a;->m:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget v1, p0, Lcom/google/android/material/button/a;->c:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v2, p0, Lcom/google/android/material/button/a;->e:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    iget v3, p0, Lcom/google/android/material/button/a;->d:I

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    sub-int/2addr p2, v3

    const/4 v5, 0x6

    iget v3, p0, Lcom/google/android/material/button/a;->f:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    sub-int/2addr p1, v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2, p2, p1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    :cond_0
    const/4 v5, 0x1

    return-void
.end method

.method b()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/button/a;->g:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/button/a;->f:I

    const/4 v2, 0x2

    return v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/button/a;->e:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public e()Lcom/google/android/material/shape/s;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/material/button/a;->r:Landroid/graphics/drawable/LayerDrawable;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0}, Landroid/graphics/drawable/LayerDrawable;->getNumberOfLayers()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-le v0, v1, :cond_1

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/a;->r:Landroid/graphics/drawable/LayerDrawable;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/graphics/drawable/LayerDrawable;->getNumberOfLayers()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-le v0, v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/button/a;->r:Landroid/graphics/drawable/LayerDrawable;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Landroid/graphics/drawable/LayerDrawable;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    check-cast v0, Lcom/google/android/material/shape/s;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/a;->r:Landroid/graphics/drawable/LayerDrawable;

    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/LayerDrawable;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v0, Lcom/google/android/material/shape/s;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object v0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object v0
.end method

.method f()Lcom/google/android/material/shape/j;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/material/button/a;->g(Z)Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method h()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/button/a;->l:Landroid/content/res/ColorStateList;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method i()Lcom/google/android/material/shape/o;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/button/a;->b:Lcom/google/android/material/shape/o;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method j()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/google/android/material/button/a;->k:Landroid/content/res/ColorStateList;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method k()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/button/a;->h:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method l()Landroid/content/res/ColorStateList;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/a;->j:Landroid/content/res/ColorStateList;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method m()Landroid/graphics/PorterDuff$Mode;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/button/a;->i:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method o()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/button/a;->o:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    return v0
.end method

.method p()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/button/a;->q:Z

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method q(Landroid/content/res/TypedArray;)V
    .locals 7
    .param p1    # Landroid/content/res/TypedArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    sget v0, Lcom/google/android/material/R$styleable;->MaterialButton_android_insetLeft:I

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v6, 0x6

    and-int/2addr v5, v1

    const/4 v6, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    iput v0, p0, Lcom/google/android/material/button/a;->c:I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    sget v0, Lcom/google/android/material/R$styleable;->MaterialButton_android_insetRight:I

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iput v0, p0, Lcom/google/android/material/button/a;->d:I

    const/4 v6, 0x3

    sget v0, Lcom/google/android/material/R$styleable;->MaterialButton_android_insetTop:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput v0, p0, Lcom/google/android/material/button/a;->e:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    sget v0, Lcom/google/android/material/R$styleable;->MaterialButton_android_insetBottom:I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    iput v0, p0, Lcom/google/android/material/button/a;->f:I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    sget v0, Lcom/google/android/material/R$styleable;->MaterialButton_cornerRadius:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v3, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v2, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p1, v0, v3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    iput v0, p0, Lcom/google/android/material/button/a;->g:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/google/android/material/button/a;->b:Lcom/google/android/material/shape/o;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    int-to-float v0, v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2, v0}, Lcom/google/android/material/shape/o;->w(F)Lcom/google/android/material/shape/o;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/button/a;->y(Lcom/google/android/material/shape/o;)V

    const/4 v6, 0x2

    const/4 v0, 0x1

    const/4 v6, 0x5

    shl-int/2addr v5, v0

    const/4 v6, 0x3

    iput-boolean v0, p0, Lcom/google/android/material/button/a;->p:Z

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    sget v0, Lcom/google/android/material/R$styleable;->MaterialButton_strokeWidth:I

    const/4 v5, 0x2

    shl-int/2addr v6, v5

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput v0, p0, Lcom/google/android/material/button/a;->h:I

    const/4 v6, 0x5

    const/4 v5, 0x7

    sget v0, Lcom/google/android/material/R$styleable;->MaterialButton_backgroundTintMode:I

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p1, v0, v3}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    sget-object v2, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v0, v2}, Lcom/google/android/material/internal/y;->l(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/google/android/material/button/a;->i:Landroid/graphics/PorterDuff$Mode;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    sget v2, Lcom/google/android/material/R$styleable;->MaterialButton_backgroundTint:I

    const/4 v6, 0x7

    invoke-static {v0, p1, v2}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/google/android/material/button/a;->j:Landroid/content/res/ColorStateList;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    sget v2, Lcom/google/android/material/R$styleable;->MaterialButton_strokeColor:I

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v0, p1, v2}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput-object v0, p0, Lcom/google/android/material/button/a;->k:Landroid/content/res/ColorStateList;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget v2, Lcom/google/android/material/R$styleable;->MaterialButton_rippleColor:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v0, p1, v2}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/google/android/material/button/a;->l:Landroid/content/res/ColorStateList;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    sget v0, Lcom/google/android/material/R$styleable;->MaterialButton_android_checkable:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    iput-boolean v0, p0, Lcom/google/android/material/button/a;->q:Z

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    sget v0, Lcom/google/android/material/R$styleable;->MaterialButton_elevation:I

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    iput v0, p0, Lcom/google/android/material/button/a;->s:I

    const/4 v6, 0x2

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v5, 0x4

    move v6, v5

    invoke-static {v0}, Landroidx/core/view/k1;->k0(Landroid/view/View;)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v6, 0x6

    invoke-static {v2}, Landroidx/core/view/k1;->j0(Landroid/view/View;)I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v3}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    sget v4, Lcom/google/android/material/R$styleable;->MaterialButton_android_background:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1, v4}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    if-eqz p1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->s()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/android/material/button/a;->F()V

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget v4, p0, Lcom/google/android/material/button/a;->c:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    add-int/2addr v0, v4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget v4, p0, Lcom/google/android/material/button/a;->e:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    add-int/2addr v1, v4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget v4, p0, Lcom/google/android/material/button/a;->d:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    add-int/2addr v2, v4

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget v4, p0, Lcom/google/android/material/button/a;->f:I

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    add-int/2addr v3, v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {p1, v0, v1, v2, v3}, Landroidx/core/view/k1;->d2(Landroid/view/View;IIII)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-void
.end method

.method r(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->setTint(I)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method s()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/google/android/material/button/a;->o:Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/button/a;->j:Landroid/content/res/ColorStateList;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->setSupportBackgroundTintList(Landroid/content/res/ColorStateList;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/button/a;->i:Landroid/graphics/PorterDuff$Mode;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->setSupportBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method t(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/button/a;->q:Z

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method u(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/button/a;->p:Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/button/a;->g:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eq v0, p1, :cond_1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/android/material/button/a;->g:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/google/android/material/button/a;->p:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/button/a;->b:Lcom/google/android/material/shape/o;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    int-to-float p1, p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/o;->w(F)Lcom/google/android/material/shape/o;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/a;->y(Lcom/google/android/material/shape/o;)V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public v(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/button/a;->e:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0, v0, p1}, Lcom/google/android/material/button/a;->E(II)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public w(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/button/a;->f:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/button/a;->E(II)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method x(Landroid/content/res/ColorStateList;)V
    .locals 4
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/a;->l:Landroid/content/res/ColorStateList;

    const/4 v3, 0x4

    const/4 v2, 0x6

    if-eq v0, p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/google/android/material/button/a;->l:Landroid/content/res/ColorStateList;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-boolean v0, Lcom/google/android/material/button/a;->t:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    instance-of v1, v1, Landroid/graphics/drawable/RippleDrawable;

    const/4 v3, 0x7

    const/4 v2, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Landroid/graphics/drawable/RippleDrawable;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/RippleDrawable;->setColor(Landroid/content/res/ColorStateList;)V

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    instance-of v0, v0, Lcom/google/android/material/ripple/a;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/android/material/button/a;->a:Lcom/google/android/material/button/MaterialButton;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast v0, Lcom/google/android/material/ripple/a;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/ripple/a;->setTintList(Landroid/content/res/ColorStateList;)V

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method y(Lcom/google/android/material/shape/o;)V
    .locals 2
    .param p1    # Lcom/google/android/material/shape/o;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x2

    iput-object p1, p0, Lcom/google/android/material/button/a;->b:Lcom/google/android/material/shape/o;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/android/material/button/a;->G(Lcom/google/android/material/shape/o;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method z(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/google/android/material/button/a;->n:Z

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/android/material/button/a;->I()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method
