.class public Lcom/google/android/material/button/MaterialButton;
.super Landroidx/appcompat/widget/AppCompatButton;

# interfaces
.implements Landroid/widget/Checkable;
.implements Lcom/google/android/material/shape/s;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/button/MaterialButton$SavedState;,
        Lcom/google/android/material/button/MaterialButton$a;,
        Lcom/google/android/material/button/MaterialButton$c;,
        Lcom/google/android/material/button/MaterialButton$b;
    }
.end annotation


# static fields
.field private static final n:[I

.field private static final o:[I

.field public static final p:I = 0x1

.field public static final q:I = 0x2

.field public static final r:I = 0x3

.field public static final s:I = 0x4

.field public static final t:I = 0x10

.field public static final u:I = 0x20

.field private static final v:Ljava/lang/String; = "MaterialButton"

.field private static final w:I


# instance fields
.field private final a:Lcom/google/android/material/button/a;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:Ljava/util/LinkedHashSet;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashSet<",
            "Lcom/google/android/material/button/MaterialButton$b;",
            ">;"
        }
    .end annotation
.end field

.field private c:Lcom/google/android/material/button/MaterialButton$c;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private d:Landroid/graphics/PorterDuff$Mode;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private e:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private f:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private g:I
    .annotation build Landroidx/annotation/u0;
    .end annotation
.end field

.field private h:I
    .annotation build Landroidx/annotation/u0;
    .end annotation
.end field

.field private i:I
    .annotation build Landroidx/annotation/u0;
    .end annotation
.end field

.field private j:I
    .annotation build Landroidx/annotation/u0;
    .end annotation
.end field

.field private k:Z

.field private l:Z

.field private m:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const v0, 0x101009f

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    sput-object v0, Lcom/google/android/material/button/MaterialButton;->n:[I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const v0, 0x10100a0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    sput-object v0, Lcom/google/android/material/button/MaterialButton;->o:[I

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_Button:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    sput v0, Lcom/google/android/material/button/MaterialButton;->w:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/R$attr;->materialButtonStyle:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/button/MaterialButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 10
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    sget v6, Lcom/google/android/material/button/MaterialButton;->w:I

    const/4 v9, 0x1

    const/4 v8, 0x3

    invoke-static {p1, p2, p3, v6}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/widget/AppCompatButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    new-instance p1, Ljava/util/LinkedHashSet;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    const/4 v9, 0x0

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButton;->b:Ljava/util/LinkedHashSet;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    const/4 p1, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButton;->k:Z

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButton;->l:Z

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v7

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    sget-object v2, Lcom/google/android/material/R$styleable;->MaterialButton:[I

    const/4 v8, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    new-array v5, p1, [I

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    move v3, p3

    move v3, p3

    const/4 v9, 0x4

    move v3, p3

    move v3, p3

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    move v4, v6

    move v4, v6

    move v4, v6

    move v4, v6

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    sget v1, Lcom/google/android/material/R$styleable;->MaterialButton_iconPadding:I

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v0, v1, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    iput v1, p0, Lcom/google/android/material/button/MaterialButton;->j:I

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    sget v1, Lcom/google/android/material/R$styleable;->MaterialButton_iconTintMode:I

    const/4 v9, 0x4

    const/4 v2, -0x6

    const/4 v9, 0x1

    const/4 v2, -0x1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    sget-object v2, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v1, v2}, Lcom/google/android/material/internal/y;->l(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    iput-object v1, p0, Lcom/google/android/material/button/MaterialButton;->d:Landroid/graphics/PorterDuff$Mode;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    sget v2, Lcom/google/android/material/R$styleable;->MaterialButton_iconTint:I

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-static {v1, v0, v2}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    iput-object v1, p0, Lcom/google/android/material/button/MaterialButton;->e:Landroid/content/res/ColorStateList;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x1

    sget v2, Lcom/google/android/material/R$styleable;->MaterialButton_icon:I

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {v1, v0, v2}, Lcom/google/android/material/resources/c;->e(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x7

    iput-object v1, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    sget v1, Lcom/google/android/material/R$styleable;->MaterialButton_iconGravity:I

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v2, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    iput v1, p0, Lcom/google/android/material/button/MaterialButton;->m:I

    sget v1, Lcom/google/android/material/R$styleable;->MaterialButton_iconSize:I

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v0, v1, p1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    iput v1, p0, Lcom/google/android/material/button/MaterialButton;->g:I

    const/4 v9, 0x3

    invoke-static {v7, p2, p3, v6}, Lcom/google/android/material/shape/o;->e(Landroid/content/Context;Landroid/util/AttributeSet;II)Lcom/google/android/material/shape/o$b;

    move-result-object p2

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p2}, Lcom/google/android/material/shape/o$b;->m()Lcom/google/android/material/shape/o;

    move-result-object p2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    new-instance p3, Lcom/google/android/material/button/a;

    const/4 v9, 0x0

    const/4 v8, 0x1

    invoke-direct {p3, p0, p2}, Lcom/google/android/material/button/a;-><init>(Lcom/google/android/material/button/MaterialButton;Lcom/google/android/material/shape/o;)V

    const/4 v8, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    iput-object p3, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p3, v0}, Lcom/google/android/material/button/a;->q(Landroid/content/res/TypedArray;)V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v9, 0x2

    iget p2, p0, Lcom/google/android/material/button/MaterialButton;->j:I

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {p0, p2}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget-object p2, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-eqz p2, :cond_0

    const/4 v8, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    move p1, v2

    move p1, v2

    const/4 v9, 0x5

    move p1, v2

    move p1, v2

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {p0, p1}, Lcom/google/android/material/button/MaterialButton;->k(Z)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    return-void
.end method

.method private d()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s t/ ~b ~@@~a   ~ @@o ~-msK@1n~~bS~~ob /id~ irlo@ @~o~iy@@f~@~@@l.@~@~  t~~~uf~ @ @c @Mov @4o~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->m:I

    const/4 v3, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eq v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x1

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method private e()Z
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->m:I

    const/4 v4, 0x2

    const/4 v1, 0x6

    const/4 v1, 0x1

    shl-int/2addr v4, v1

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eq v0, v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x2

    if-ne v0, v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x0

    :cond_1
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    return v1
.end method

.method private f()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->m:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/16 v1, 0x10

    if-eq v0, v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/16 v1, 0x20

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x1

    :goto_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v0
.end method

.method private g()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v1
.end method

.method private getA11yClassName()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->c()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-class v0, Landroid/widget/CompoundButton;

    const-class v0, Landroid/widget/CompoundButton;

    const/4 v2, 0x5

    const-class v0, Landroid/widget/CompoundButton;

    const-class v0, Landroid/widget/CompoundButton;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-class v0, Landroid/widget/Button;

    const-class v0, Landroid/widget/Button;

    const/4 v2, 0x0

    const-class v0, Landroid/widget/Button;

    const-class v0, Landroid/widget/Button;

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method private getActualTextAlignment()Landroid/text/Layout$Alignment;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getTextAlignment()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eq v0, v1, :cond_2

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x6

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eq v0, v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eq v0, v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x4

    const/4 v3, 0x2

    if-eq v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_OPPOSITE:Landroid/text/Layout$Alignment;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->getGravityTextAlignment()Landroid/text/Layout$Alignment;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0
.end method

.method private getGravityTextAlignment()Landroid/text/Layout$Alignment;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/widget/TextView;->getGravity()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const v1, 0x800007

    const/4 v3, 0x1

    const/4 v2, 0x3

    and-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eq v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x5

    const/4 v3, 0x0

    if-eq v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const v1, 0x800005

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eq v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_OPPOSITE:Landroid/text/Layout$Alignment;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v3, 0x1

    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0
.end method

.method private getTextHeight()I
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v2, :cond_0

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v2, v1, p0}, Landroid/text/method/TransformationMethod;->getTransformation(Ljava/lang/CharSequence;Landroid/view/View;)Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    new-instance v2, Landroid/graphics/Rect;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v4, v3, v2}, Landroid/graphics/Paint;->getTextBounds(Ljava/lang/String;IILandroid/graphics/Rect;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/widget/TextView;->getLayout()Landroid/text/Layout;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/text/Layout;->getHeight()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    return v0
.end method

.method private getTextWidth()I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {v2, v1, p0}, Landroid/text/method/TransformationMethod;->getTransformation(Ljava/lang/CharSequence;Landroid/view/View;)Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    float-to-int v0, v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/widget/TextView;->getLayout()Landroid/text/Layout;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Landroid/text/Layout;->getEllipsizedWidth()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    return v0
.end method

.method private h()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->o()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method private j()V
    .locals 4

    const/4 v2, 0x5

    move v3, v2

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p0, v0, v1, v1, v1}, Landroidx/core/widget/q;->w(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->d()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-static {p0, v1, v1, v0, v1}, Landroidx/core/widget/q;->w(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->f()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-static {p0, v1, v0, v1, v1}, Landroidx/core/widget/q;->w(Landroid/widget/TextView;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    :cond_2
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method private k(Z)V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v1, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v0, :cond_3

    const/4 v7, 0x1

    invoke-static {v0}, Landroidx/core/graphics/drawable/d;->r(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x2

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/google/android/material/button/MaterialButton;->e:Landroid/content/res/ColorStateList;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static {v0, v2}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:Landroid/graphics/PorterDuff$Mode;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v2, v0}, Landroidx/core/graphics/drawable/d;->p(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    const/4 v7, 0x3

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->g:I

    const/4 v7, 0x1

    if-eqz v0, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget v2, p0, Lcom/google/android/material/button/MaterialButton;->g:I

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v2, :cond_2

    const/4 v7, 0x0

    goto :goto_1

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x4

    const/4 v6, 0x5

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v2

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget v4, p0, Lcom/google/android/material/button/MaterialButton;->h:I

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget v5, p0, Lcom/google/android/material/button/MaterialButton;->i:I

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    add-int/2addr v0, v4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    add-int/2addr v2, v5

    const/4 v7, 0x3

    invoke-virtual {v3, v4, v5, v0, v2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_3
    const/4 v7, 0x2

    if-eqz p1, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->j()V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    return-void

    :cond_4
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {p0}, Landroidx/core/widget/q;->h(Landroid/widget/TextView;)[Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    aget-object v2, p1, v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    aget-object v3, p1, v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/4 v4, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    aget-object p1, p1, v4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    if-eqz v4, :cond_5

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v4, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-ne v2, v4, :cond_8

    :cond_5
    const/4 v6, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->d()Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v2, :cond_6

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x4

    const/4 v6, 0x5

    if-ne p1, v2, :cond_8

    :cond_6
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->f()Z

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz p1, :cond_7

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object p1, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-eq v3, p1, :cond_7

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_2

    :cond_7
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    move v1, v0

    move v1, v0

    const/4 v7, 0x4

    move v1, v0

    move v1, v0

    :cond_8
    :goto_2
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v1, :cond_9

    const/4 v7, 0x0

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->j()V

    :cond_9
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    return-void
.end method

.method private l(II)V
    .locals 7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v0, :cond_d

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/widget/TextView;->getLayout()Landroid/text/Layout;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-nez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto/16 :goto_4

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->e()Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v1, 0x2

    const/4 v5, 0x7

    move v6, v5

    const/4 v2, 0x0

    move v6, v2

    const/4 v5, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez v0, :cond_4

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->d()Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->f()Z

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz p1, :cond_b

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput v2, p0, Lcom/google/android/material/button/MaterialButton;->h:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget p1, p0, Lcom/google/android/material/button/MaterialButton;->m:I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/16 v0, 0x10

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-ne p1, v0, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput v2, p0, Lcom/google/android/material/button/MaterialButton;->i:I

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-direct {p0, v2}, Lcom/google/android/material/button/MaterialButton;->k(Z)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    return-void

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget p1, p0, Lcom/google/android/material/button/MaterialButton;->g:I

    const/4 v6, 0x2

    if-nez p1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result p1

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->getTextHeight()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    sub-int/2addr p2, v0

    const/4 v5, 0x2

    or-int/2addr v6, v5

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    sub-int/2addr p2, v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    sub-int/2addr p2, p1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget p1, p0, Lcom/google/android/material/button/MaterialButton;->j:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    sub-int/2addr p2, p1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    sub-int/2addr p2, p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    div-int/2addr p2, v1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget p1, p0, Lcom/google/android/material/button/MaterialButton;->i:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eq p1, p2, :cond_b

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput p2, p0, Lcom/google/android/material/button/MaterialButton;->i:I

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {p0, v2}, Lcom/google/android/material/button/MaterialButton;->k(Z)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto/16 :goto_2

    :cond_4
    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    iput v2, p0, Lcom/google/android/material/button/MaterialButton;->i:I

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->getActualTextAlignment()Landroid/text/Layout$Alignment;

    move-result-object p2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->m:I

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eq v0, v3, :cond_c

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v4, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eq v0, v4, :cond_c

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-ne v0, v1, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget-object v1, Landroid/text/Layout$Alignment;->ALIGN_NORMAL:Landroid/text/Layout$Alignment;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eq p2, v1, :cond_c

    :cond_5
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v1, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-ne v0, v1, :cond_6

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_OPPOSITE:Landroid/text/Layout$Alignment;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-ne p2, v0, :cond_6

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    goto/16 :goto_3

    :cond_6
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->g:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-nez v0, :cond_7

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    :cond_7
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->getTextWidth()I

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    sub-int/2addr p1, v4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {p0}, Landroidx/core/view/k1;->j0(Landroid/view/View;)I

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    sub-int/2addr p1, v4

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    sub-int/2addr p1, v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->j:I

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    sub-int/2addr p1, v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {p0}, Landroidx/core/view/k1;->k0(Landroid/view/View;)I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    sub-int/2addr p1, v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    sget-object v0, Landroid/text/Layout$Alignment;->ALIGN_CENTER:Landroid/text/Layout$Alignment;

    const/4 v6, 0x4

    if-ne p2, v0, :cond_8

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    div-int/lit8 p1, p1, 0x2

    :cond_8
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->g()Z

    move-result p2

    const/4 v6, 0x2

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->m:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-ne v0, v1, :cond_9

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto :goto_1

    :cond_9
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    move v3, v2

    move v3, v2

    const/4 v6, 0x4

    move v3, v2

    move v3, v2

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eq p2, v3, :cond_a

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    neg-int p1, p1

    :cond_a
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget p2, p0, Lcom/google/android/material/button/MaterialButton;->h:I

    const/4 v5, 0x2

    move v6, v5

    if-eq p2, p1, :cond_b

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iput p1, p0, Lcom/google/android/material/button/MaterialButton;->h:I

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {p0, v2}, Lcom/google/android/material/button/MaterialButton;->k(Z)V

    :cond_b
    :goto_2
    const/4 v6, 0x1

    return-void

    :cond_c
    :goto_3
    const/4 v6, 0x2

    const/4 v5, 0x4

    iput v2, p0, Lcom/google/android/material/button/MaterialButton;->h:I

    const/4 v5, 0x5

    move v6, v5

    invoke-direct {p0, v2}, Lcom/google/android/material/button/MaterialButton;->k(Z)V

    :cond_d
    :goto_4
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    return-void
.end method


# virtual methods
.method public a(Lcom/google/android/material/button/MaterialButton$b;)V
    .locals 3
    .param p1    # Lcom/google/android/material/button/MaterialButton$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->b:Ljava/util/LinkedHashSet;

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method

.method public b()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->b:Ljava/util/LinkedHashSet;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/AbstractCollection;->clear()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public c()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->p()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public getBackgroundTintList()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->getSupportBackgroundTintList()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public getBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->getSupportBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public getCornerRadius()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->b()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public getIcon()Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getIconGravity()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->m:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public getIconPadding()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->j:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public getIconSize()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->g:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public getIconTint()Landroid/content/res/ColorStateList;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->e:Landroid/content/res/ColorStateList;

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-object v0
.end method

.method public getIconTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public getInsetBottom()I
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->c()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public getInsetTop()I
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->d()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public getRippleColor()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->h()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public getShapeAppearanceModel()Lcom/google/android/material/shape/o;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->i()Lcom/google/android/material/shape/o;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v1, "eecmoheerapetMapuanigtoet aao etbaisnforttmm Bn tdrgrvld nwooSke hacurhe pMschtaiAtdaeAp  lntw ."

    const-string v1, " rshtlemovmte AAokdtudttnotoaii.tnewrc wha eSttlnonr ueBaaaaodgrbsecM pepahc fape h ignep  rteMa"

    const/4 v3, 0x6

    const-string/jumbo v1, "wehtoufa trachwrtcon  aivrenSAtpr.nnt o dogAohohpM mepret  asl aipmtactliredBnbae aagdetkteMuoee"

    const-string v1, "Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background."

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    throw v0
.end method

.method public getStrokeColor()Landroid/content/res/ColorStateList;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->j()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public getStrokeWidth()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->k()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    return v0
.end method

.method public getSupportBackgroundTintList()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->l()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-super {p0}, Landroidx/appcompat/widget/AppCompatButton;->getSupportBackgroundTintList()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public getSupportBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->m()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0

    :cond_0
    const/4 v1, 0x4

    move v2, v1

    invoke-super {p0}, Landroidx/appcompat/widget/AppCompatButton;->getSupportBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public i(Lcom/google/android/material/button/MaterialButton$b;)V
    .locals 3
    .param p1    # Lcom/google/android/material/button/MaterialButton$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->b:Ljava/util/LinkedHashSet;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public isChecked()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButton;->k:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method protected onAttachedToWindow()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-super {p0}, Landroid/widget/Button;->onAttachedToWindow()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/android/material/shape/k;->f(Landroid/view/View;Lcom/google/android/material/shape/j;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method protected onCreateDrawableState(I)[I
    .locals 3

    const/4 v2, 0x1

    add-int/lit8 p1, p1, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroid/widget/Button;->onCreateDrawableState(I)[I

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->c()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lcom/google/android/material/button/MaterialButton;->n:[I

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->isChecked()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/google/android/material/button/MaterialButton;->o:[I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p1
.end method

.method public onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 3
    .param p1    # Landroid/view/accessibility/AccessibilityEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-super {p0, p1}, Landroidx/appcompat/widget/AppCompatButton;->onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->getA11yClassName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setClassName(Ljava/lang/CharSequence;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->isChecked()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setChecked(Z)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 3
    .param p1    # Landroid/view/accessibility/AccessibilityNodeInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroidx/appcompat/widget/AppCompatButton;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->getA11yClassName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->c()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setCheckable(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->isChecked()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setChecked(Z)V

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->isClickable()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClickable(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-super/range {p0 .. p5}, Landroidx/appcompat/widget/AppCompatButton;->onLayout(ZIIII)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/button/MaterialButton;->l(II)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 3
    .param p1    # Landroid/os/Parcelable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    instance-of v0, p1, Lcom/google/android/material/button/MaterialButton$SavedState;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-super {p0, p1}, Landroid/widget/Button;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast p1, Lcom/google/android/material/button/MaterialButton$SavedState;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroidx/customview/view/AbsSavedState;->a()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-super {p0, v0}, Landroid/widget/Button;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-boolean p1, p1, Lcom/google/android/material/button/MaterialButton$SavedState;->c:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setChecked(Z)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public onSaveInstanceState()Landroid/os/Parcelable;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-super {p0}, Landroid/widget/Button;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v1, Lcom/google/android/material/button/MaterialButton$SavedState;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v1, v0}, Lcom/google/android/material/button/MaterialButton$SavedState;-><init>(Landroid/os/Parcelable;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButton;->k:Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-boolean v0, v1, Lcom/google/android/material/button/MaterialButton$SavedState;->c:Z

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v1
.end method

.method protected onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-super {p0, p1, p2, p3, p4}, Landroidx/appcompat/widget/AppCompatButton;->onTextChanged(Ljava/lang/CharSequence;III)V

    const/4 v0, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result p2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/android/material/button/MaterialButton;->l(II)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public performClick()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->toggle()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-super {p0}, Landroid/widget/Button;->performClick()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public refreshDrawableState()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-super {p0}, Landroid/widget/Button;->refreshDrawableState()V

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getDrawableState()[I

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public setBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public setBackgroundColor(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->r(I)V

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroid/widget/Button;->setBackgroundColor(I)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    if-eq p1, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v0, "neiBlbmttaruot"

    const-string/jumbo v0, "uBomilatrentMt"

    const/4 v3, 0x7

    const-string v0, "alaBtnuuiteMrt"

    const-string v0, "MaterialButton"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const-string v1, " sditeapbrwsu  ekt odedwni aaggsn ecepa tnh,n osburnods skdu ednbutormilavdd,   t nro iorniBc  gptua e uhobe .rncvstrglocnAeCeaeolarnhrrddeh nai daiuionsr aaMisbk ddrar eitph ancet tes nsaluttopaoaligsaalo eaotoaeh eer guhfpctatsmoi bslosoeetnshrcl.ais ydutecnen ,eTli biuAraa conn  l ctlscttnttuds,gweaniss saoe"

    const-string v1, " binoc  rdudgalnsutoe atmt wt,argauchou doacrnosdkh einleobnneogiag ndutr duvApspaseh itrwoeuaardo ne  unusttcidddmark.eaBep  Mehoni tdicaasnslarhieedicropteth   l ansssth t senbelog   tsdriarrns cr,epsbeeai tanur. itvokllaoawnaaenntiidta scloeseetCny,ubh locl  lai ss,aon sn et  cAaTeitnsorcogftabtedb  e rugsos"

    const/4 v3, 0x1

    const-string/jumbo v1, "g oaana qny  nnadhtoosktsilabeatw  me  l,he  aodioddorrnto eg nne snded.siaCoilaeit o,ldc bMrpr edTbchusrai re ,rt sldsgeenluabedegnsh tocthdotncac r nnn  o.e il ietafBaud ssrolnduncAespnrtu e ttsasainurhauounti ,luon atvregiineioaaapt o ghskkssatecblso  argaewars ceubrubirpdsatct mel swtthncutoss tA oceaipdvee"

    const-string v1, "MaterialButton manages its own background to control elevation, shape, color and states. Consider using backgroundTint, shapeAppearance and other attributes where available. A custom background will ignore these attributes and you should consider handling interaction states such as pressed, focused and disabled"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->s()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-super {p0, p1}, Landroidx/appcompat/widget/AppCompatButton;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-super {p0, p1}, Landroidx/appcompat/widget/AppCompatButton;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method public setBackgroundResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lf/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public setBackgroundTintList(Landroid/content/res/ColorStateList;)V
    .locals 2
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setSupportBackgroundTintList(Landroid/content/res/ColorStateList;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public setBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 2
    .param p1    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setSupportBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-void
.end method

.method public setCheckable(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    move v2, v1

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->t(Z)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public setChecked(Z)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->c()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButton;->k:Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eq v0, p1, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButton;->k:Z

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {p0}, Lcom/google/android/material/button/MaterialButton;->refreshDrawableState()V

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    instance-of p1, p1, Lcom/google/android/material/button/MaterialButtonToggleGroup;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast p1, Lcom/google/android/material/button/MaterialButtonToggleGroup;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButton;->k:Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1, p0, v0}, Lcom/google/android/material/button/MaterialButtonToggleGroup;->p(Lcom/google/android/material/button/MaterialButton;Z)V

    :cond_0
    const/4 v3, 0x4

    iget-boolean p1, p0, Lcom/google/android/material/button/MaterialButton;->l:Z

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButton;->l:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/google/android/material/button/MaterialButton;->b:Ljava/util/LinkedHashSet;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    check-cast v0, Lcom/google/android/material/button/MaterialButton$b;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-boolean v1, p0, Lcom/google/android/material/button/MaterialButton;->k:Z

    const/4 v3, 0x3

    invoke-interface {v0, p0, v1}, Lcom/google/android/material/button/MaterialButton$b;->a(Lcom/google/android/material/button/MaterialButton;Z)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    goto :goto_0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    iput-boolean p1, p0, Lcom/google/android/material/button/MaterialButton;->l:Z

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public setCornerRadius(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->u(I)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public setCornerRadiusResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setCornerRadius(I)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public setElevation(F)V
    .locals 3
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroid/widget/Button;->setElevation(F)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v1, 0x6

    or-int/2addr v2, v1

    invoke-virtual {v0}, Lcom/google/android/material/button/a;->f()Lcom/google/android/material/shape/j;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/j;->n0(F)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButton;->f:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/button/MaterialButton;->k(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/button/MaterialButton;->l(II)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public setIconGravity(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->m:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eq v0, p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/button/MaterialButton;->m:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/button/MaterialButton;->l(II)V

    :cond_0
    const/4 v2, 0x5

    return-void
.end method

.method public setIconPadding(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->j:I

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eq v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/android/material/button/MaterialButton;->j:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public setIconResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lf/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setIcon(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public setIconSize(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x0

    if-ltz p1, :cond_1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/button/MaterialButton;->g:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eq v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput p1, p0, Lcom/google/android/material/button/MaterialButton;->g:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/button/MaterialButton;->k(Z)V

    :cond_0
    const/4 v2, 0x0

    return-void

    :cond_1
    const/4 v2, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, "Siszosonttaice0ble c sb hna  n"

    const-string/jumbo v0, "sicneble hon zo0ctaesi S bn at"

    const/4 v2, 0x7

    const-string/jumbo v0, "teSmnczn sn0 iaslto nibeco  ea"

    const-string/jumbo v0, "iconSize cannot be less than 0"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    throw p1
.end method

.method public setIconTint(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->e:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButton;->e:Landroid/content/res/ColorStateList;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lcom/google/android/material/button/MaterialButton;->k(Z)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public setIconTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->d:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButton;->d:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/button/MaterialButton;->k(Z)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public setIconTintResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setIconTint(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public setInsetBottom(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->v(I)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public setInsetTop(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->w(I)V

    const/4 v2, 0x0

    return-void
.end method

.method setInternalBackground(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-super {p0, p1}, Landroidx/appcompat/widget/AppCompatButton;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method setOnPressedChangeListenerInternal(Lcom/google/android/material/button/MaterialButton$c;)V
    .locals 2
    .param p1    # Lcom/google/android/material/button/MaterialButton$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/android/material/button/MaterialButton;->c:Lcom/google/android/material/button/MaterialButton$c;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public setPressed(Z)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->c:Lcom/google/android/material/button/MaterialButton$c;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0, p0, p1}, Lcom/google/android/material/button/MaterialButton$c;->a(Lcom/google/android/material/button/MaterialButton;Z)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-super {p0, p1}, Landroid/widget/Button;->setPressed(Z)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public setRippleColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->x(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public setRippleColorResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setRippleColor(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V
    .locals 3
    .param p1    # Lcom/google/android/material/shape/o;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->y(Lcom/google/android/material/shape/o;)V

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string/jumbo v0, "hSnptMugcherswhu p toiapalincAt ett Mrenora iem sB.eowdnudrtae taaao eeptaclh  etvte nrnbAkdao"

    const-string/jumbo v0, "hnaiop.wt tdaordgrcreohaitttt po ltn MAusmelceee eneb havnoeud otecapeMSratan   iAst aoprBwakh"

    const-string v0, "Attempted to set ShapeAppearanceModel on a MaterialButton which has an overwritten background."

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    throw p1
.end method

.method setShouldDrawSurfaceColorStroke(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->z(Z)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public setStrokeColor(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->A(Landroid/content/res/ColorStateList;)V

    :cond_0
    return-void
.end method

.method public setStrokeColorResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0, p1}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setStrokeColor(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public setStrokeWidth(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->B(I)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public setStrokeWidthResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/button/MaterialButton;->setStrokeWidth(I)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public setSupportBackgroundTintList(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->C(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-super {p0, p1}, Landroidx/appcompat/widget/AppCompatButton;->setSupportBackgroundTintList(Landroid/content/res/ColorStateList;)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public setSupportBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 3
    .param p1    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/button/MaterialButton;->h()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/button/MaterialButton;->a:Lcom/google/android/material/button/a;

    const/4 v1, 0x6

    and-int/2addr v2, v1

    invoke-virtual {v0, p1}, Lcom/google/android/material/button/a;->D(Landroid/graphics/PorterDuff$Mode;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroidx/appcompat/widget/AppCompatButton;->setSupportBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public setTextAlignment(I)V
    .locals 3
    .annotation build Landroidx/annotation/w0;
        value = 0x11
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-super {p0, p1}, Landroid/widget/Button;->setTextAlignment(I)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/button/MaterialButton;->l(II)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public toggle()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/button/MaterialButton;->k:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/android/material/button/MaterialButton;->setChecked(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
