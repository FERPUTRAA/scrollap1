.class public Lcom/google/android/material/chip/b;
.super Lcom/google/android/material/shape/j;

# interfaces
.implements Landroidx/core/graphics/drawable/k;
.implements Landroid/graphics/drawable/Drawable$Callback;
.implements Lcom/google/android/material/internal/n$b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/chip/b$a;
    }
.end annotation


# static fields
.field private static final n1:Z = false

.field private static final o1:[I

.field private static final p1:Ljava/lang/String; = "http://schemas.android.com/apk/res-auto"

.field private static final q1:I = 0x18

.field private static final r1:Landroid/graphics/drawable/ShapeDrawable;


# instance fields
.field private A0:Lcom/google/android/material/animation/h;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private B0:Lcom/google/android/material/animation/h;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private C0:F

.field private D0:F

.field private E:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private E0:F

.field private F:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private F0:F

.field private G:F

.field private G0:F

.field private H:F

.field private H0:F

.field private I:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private I0:F

.field private J:F

.field private J0:F

.field private K:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final K0:Landroid/content/Context;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private L:Ljava/lang/CharSequence;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final L0:Landroid/graphics/Paint;

.field private M:Z

.field private final M0:Landroid/graphics/Paint;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private N:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final N0:Landroid/graphics/Paint$FontMetrics;

.field private O:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final O0:Landroid/graphics/RectF;

.field private P:F

.field private final P0:Landroid/graphics/PointF;

.field private Q:Z

.field private final Q0:Landroid/graphics/Path;

.field private R:Z

.field private final R0:Lcom/google/android/material/internal/n;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private S:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private S0:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private T:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private T0:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private U:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private U0:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private V:F

.field private V0:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private W:Ljava/lang/CharSequence;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private W0:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private X:Z

.field private X0:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private Y:Z

.field private Y0:Z

.field private Z:Landroid/graphics/drawable/Drawable;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private Z0:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private a1:I

.field private b1:Landroid/graphics/ColorFilter;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private c1:Landroid/graphics/PorterDuffColorFilter;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private d1:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private e1:Landroid/graphics/PorterDuff$Mode;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private f1:[I

.field private g1:Z

.field private h1:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private i1:Ljava/lang/ref/WeakReference;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/WeakReference<",
            "Lcom/google/android/material/chip/b$a;",
            ">;"
        }
    .end annotation
.end field

.field private j1:Landroid/text/TextUtils$TruncateAt;

.field private k0:Landroid/content/res/ColorStateList;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private k1:Z

.field private l1:I

.field private m1:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const v0, 0x101009e

    const/4 v3, 0x0

    const/4 v2, 0x5

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    sput-object v0, Lcom/google/android/material/chip/b;->o1:[I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Landroid/graphics/drawable/ShapeDrawable;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v1, Landroid/graphics/drawable/shapes/OvalShape;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v1}, Landroid/graphics/drawable/shapes/OvalShape;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Landroid/graphics/drawable/ShapeDrawable;-><init>(Landroid/graphics/drawable/shapes/Shape;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    sput-object v0, Lcom/google/android/material/chip/b;->r1:Landroid/graphics/drawable/ShapeDrawable;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/android/material/shape/j;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/high16 p2, -0x40800000    # -1.0f

    const/4 v1, 0x6

    move v2, v1

    iput p2, p0, Lcom/google/android/material/chip/b;->H:F

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance p2, Landroid/graphics/Paint;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 p3, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p2, p3}, Landroid/graphics/Paint;-><init>(I)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance p2, Landroid/graphics/Paint$FontMetrics;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p2}, Landroid/graphics/Paint$FontMetrics;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p2, p0, Lcom/google/android/material/chip/b;->N0:Landroid/graphics/Paint$FontMetrics;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance p2, Landroid/graphics/RectF;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p2}, Landroid/graphics/RectF;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p2, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance p2, Landroid/graphics/PointF;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p2}, Landroid/graphics/PointF;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object p2, p0, Lcom/google/android/material/chip/b;->P0:Landroid/graphics/PointF;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance p2, Landroid/graphics/Path;

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-direct {p2}, Landroid/graphics/Path;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object p2, p0, Lcom/google/android/material/chip/b;->Q0:Landroid/graphics/Path;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/16 p2, 0xff

    const/4 v1, 0x2

    and-int/2addr v2, v1

    iput p2, p0, Lcom/google/android/material/chip/b;->a1:I

    const/4 v2, 0x5

    sget-object p2, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p2, p0, Lcom/google/android/material/chip/b;->e1:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance p2, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 p4, 0x3

    const/4 p4, 0x0

    const/4 v2, 0x1

    invoke-direct {p2, p4}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/google/android/material/chip/b;->i1:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/shape/j;->Z(Landroid/content/Context;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x5

    new-instance p2, Lcom/google/android/material/internal/n;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-direct {p2, p0}, Lcom/google/android/material/internal/n;-><init>(Lcom/google/android/material/internal/n$b;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object p2, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/android/material/chip/b;->L:Ljava/lang/CharSequence;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p2}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput p1, p2, Landroid/text/TextPaint;->density:F

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p4, p0, Lcom/google/android/material/chip/b;->M0:Landroid/graphics/Paint;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-object p1, Lcom/google/android/material/chip/b;->o1:[I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->f3([I)Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-boolean p3, p0, Lcom/google/android/material/chip/b;->k1:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-boolean p1, Lcom/google/android/material/ripple/b;->a:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object p1, Lcom/google/android/material/chip/b;->r1:Landroid/graphics/drawable/ShapeDrawable;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p2, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method private G1()F
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " @s~ o ~@~  ~ 1t~urM@@o@oi@@@4~/@nm ~@bdf~@~~@S.~~@t@-~ ~b~~  ys@ ~lKo~~/ lifc@~  ib @@~ v@~oo a"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->Y0:Z

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/android/material/chip/b;->P:F

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    cmpg-float v2, v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-gtz v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/16 v2, 0x18

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v1, v2}, Lcom/google/android/material/internal/y;->e(Landroid/content/Context;I)F

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    float-to-double v1, v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v1, v2}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    double-to-float v1, v1

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    int-to-float v2, v2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    cmpg-float v2, v2, v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    if-gtz v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    int-to-float v0, v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    return v0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v1
.end method

.method private H1()F
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->Y0:Z

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/android/material/chip/b;->P:F

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v2, 0x0

    move v4, v2

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    cmpg-float v2, v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-gtz v2, :cond_1

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    int-to-float v0, v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    return v0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    return v1
.end method

.method private L3()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->Y:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->Y0:Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method private M3()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->M:Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method private N3()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->R:Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method private O3(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method private P0(Landroid/graphics/drawable/Drawable;)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p0}, Landroidx/core/graphics/drawable/d;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->m(Landroid/graphics/drawable/Drawable;I)Z

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getLevel()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-ne p1, v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->D1()[I

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->U:Landroid/content/res/ColorStateList;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-ne p1, v0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-boolean v1, p0, Lcom/google/android/material/chip/b;->Q:Z

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v1, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/android/material/chip/b;->O:Landroid/content/res/ColorStateList;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, v1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v0, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method private P3()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->g1:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K:Landroid/content/res/ColorStateList;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/android/material/chip/b;->h1:Landroid/content/res/ColorStateList;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method private Q0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V
    .locals 5
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/RectF;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p2}, Landroid/graphics/RectF;->setEmpty()V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->M3()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->L3()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/android/material/chip/b;->C0:F

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/android/material/chip/b;->D0:F

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    add-float/2addr v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->H1()F

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {p0}, Landroidx/core/graphics/drawable/d;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v2, p1, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    int-to-float v2, v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    add-float/2addr v2, v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput v2, p2, Landroid/graphics/RectF;->left:F

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    add-float/2addr v2, v1

    const/4 v4, 0x3

    iput v2, p2, Landroid/graphics/RectF;->right:F

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v2, p1, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    int-to-float v2, v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    sub-float/2addr v2, v0

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    iput v2, p2, Landroid/graphics/RectF;->right:F

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    sub-float/2addr v2, v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    iput v2, p2, Landroid/graphics/RectF;->left:F

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->G1()F

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/graphics/Rect;->exactCenterY()F

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/high16 v1, 0x40000000    # 2.0f

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    div-float v1, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    sub-float/2addr p1, v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput p1, p2, Landroid/graphics/RectF;->top:F

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    add-float/2addr p1, v0

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput p1, p2, Landroid/graphics/RectF;->bottom:F

    :cond_2
    const/4 v3, 0x5

    move v4, v3

    return-void
.end method

.method private Q3()V
    .locals 6
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v0, Landroid/graphics/drawable/RippleDrawable;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->N1()Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/google/android/material/ripple/b;->d(Landroid/content/res/ColorStateList;)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget-object v3, Lcom/google/android/material/chip/b;->r1:Landroid/graphics/drawable/ShapeDrawable;

    const/4 v5, 0x2

    invoke-direct {v0, v1, v2, v3}, Landroid/graphics/drawable/RippleDrawable;-><init>(Landroid/content/res/ColorStateList;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/google/android/material/chip/b;->T:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method

.method private S0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V
    .locals 4
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/RectF;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p2, p1}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    move v3, v2

    iget v0, p0, Lcom/google/android/material/chip/b;->J0:F

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v1, p0, Lcom/google/android/material/chip/b;->I0:F

    add-float/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/android/material/chip/b;->V:F

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    add-float/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/android/material/chip/b;->H0:F

    const/4 v3, 0x5

    const/4 v2, 0x6

    add-float/2addr v0, v1

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/android/material/chip/b;->G0:F

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    add-float/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0}, Landroidx/core/graphics/drawable/d;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget p1, p1, Landroid/graphics/Rect;->right:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    int-to-float p1, p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    sub-float/2addr p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput p1, p2, Landroid/graphics/RectF;->right:F

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget p1, p1, Landroid/graphics/Rect;->left:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    int-to-float p1, p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-float/2addr p1, v0

    const/4 v3, 0x4

    iput p1, p2, Landroid/graphics/RectF;->left:F

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method private T0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V
    .locals 4
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/RectF;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    invoke-virtual {p2}, Landroid/graphics/RectF;->setEmpty()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->J0:F

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/android/material/chip/b;->I0:F

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    add-float/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p0}, Landroidx/core/graphics/drawable/d;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget v1, p1, Landroid/graphics/Rect;->right:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    int-to-float v1, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    sub-float/2addr v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput v1, p2, Landroid/graphics/RectF;->right:F

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/material/chip/b;->V:F

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    sub-float/2addr v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput v1, p2, Landroid/graphics/RectF;->left:F

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v1, p1, Landroid/graphics/Rect;->left:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    int-to-float v1, v1

    const/4 v3, 0x7

    add-float/2addr v1, v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput v1, p2, Landroid/graphics/RectF;->left:F

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/android/material/chip/b;->V:F

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    add-float/2addr v1, v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput v1, p2, Landroid/graphics/RectF;->right:F

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/graphics/Rect;->exactCenterY()F

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/android/material/chip/b;->V:F

    const/4 v3, 0x6

    const/high16 v1, 0x40000000    # 2.0f

    const/4 v3, 0x3

    div-float v1, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    sub-float/2addr p1, v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput p1, p2, Landroid/graphics/RectF;->top:F

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-float/2addr p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    iput p1, p2, Landroid/graphics/RectF;->bottom:F

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method private T1()Landroid/graphics/ColorFilter;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->b1:Landroid/graphics/ColorFilter;

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->c1:Landroid/graphics/PorterDuffColorFilter;

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method private T2(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->E:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eq v0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/android/material/chip/b;->E:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->onStateChange([I)Z

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method private U0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V
    .locals 5
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/RectF;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/graphics/RectF;->setEmpty()V

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->J0:F

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v1, p0, Lcom/google/android/material/chip/b;->I0:F

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    add-float/2addr v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/android/material/chip/b;->V:F

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    add-float/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/android/material/chip/b;->H0:F

    const/4 v4, 0x2

    add-float/2addr v0, v1

    const/4 v3, 0x2

    move v4, v3

    iget v1, p0, Lcom/google/android/material/chip/b;->G0:F

    const/4 v4, 0x6

    const/4 v3, 0x6

    add-float/2addr v0, v1

    const/4 v4, 0x5

    invoke-static {p0}, Landroidx/core/graphics/drawable/d;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-nez v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v1, p1, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    int-to-float v1, v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput v1, p2, Landroid/graphics/RectF;->right:F

    const/4 v4, 0x6

    const/4 v3, 0x4

    sub-float/2addr v1, v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput v1, p2, Landroid/graphics/RectF;->left:F

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v1, p1, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    int-to-float v2, v1

    const/4 v4, 0x2

    iput v2, p2, Landroid/graphics/RectF;->left:F

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    int-to-float v1, v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    add-float/2addr v1, v0

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput v1, p2, Landroid/graphics/RectF;->right:F

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget v0, p1, Landroid/graphics/Rect;->top:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    int-to-float v0, v0

    const/4 v4, 0x4

    iput v0, p2, Landroid/graphics/RectF;->top:F

    const/4 v3, 0x3

    move v4, v3

    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    int-to-float p1, p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput p1, p2, Landroid/graphics/RectF;->bottom:F

    :cond_1
    const/4 v4, 0x1

    return-void
.end method

.method private static V1([II)Z
    .locals 6
    .param p0    # [I
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-nez p0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    return v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    array-length v1, p0

    const/4 v5, 0x4

    const/4 v4, 0x7

    move v2, v0

    move v2, v0

    const/4 v5, 0x1

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-ge v2, v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    aget v3, p0, v2

    const/4 v5, 0x2

    if-ne v3, p1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 p0, 0x1

    const/4 v4, 0x7

    or-int/2addr v5, v4

    return p0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    return v0
.end method

.method private W0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V
    .locals 5
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/RectF;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p2}, Landroid/graphics/RectF;->setEmpty()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L:Ljava/lang/CharSequence;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/android/material/chip/b;->C0:F

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    add-float/2addr v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/android/material/chip/b;->F0:F

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    add-float/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/android/material/chip/b;->J0:F

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->V0()F

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    add-float/2addr v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget v2, p0, Lcom/google/android/material/chip/b;->G0:F

    const/4 v4, 0x2

    const/4 v3, 0x2

    add-float/2addr v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {p0}, Landroidx/core/graphics/drawable/d;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-nez v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v2, p1, Landroid/graphics/Rect;->left:I

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    int-to-float v2, v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    add-float/2addr v2, v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput v2, p2, Landroid/graphics/RectF;->left:F

    const/4 v3, 0x4

    and-int/2addr v4, v3

    iget v0, p1, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    int-to-float v0, v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    sub-float/2addr v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    iput v0, p2, Landroid/graphics/RectF;->right:F

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v2, p1, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    int-to-float v2, v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    add-float/2addr v2, v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput v2, p2, Landroid/graphics/RectF;->left:F

    iget v1, p1, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    int-to-float v1, v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    sub-float/2addr v1, v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput v1, p2, Landroid/graphics/RectF;->right:F

    :goto_0
    const/4 v4, 0x6

    iget v0, p1, Landroid/graphics/Rect;->top:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    int-to-float v0, v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput v0, p2, Landroid/graphics/RectF;->top:F

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    int-to-float p1, p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput p1, p2, Landroid/graphics/RectF;->bottom:F

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void
.end method

.method private X0()F
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/chip/b;->N0:Landroid/graphics/Paint$FontMetrics;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->getFontMetrics(Landroid/graphics/Paint$FontMetrics;)F

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->N0:Landroid/graphics/Paint$FontMetrics;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget v1, v0, Landroid/graphics/Paint$FontMetrics;->descent:F

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    iget v0, v0, Landroid/graphics/Paint$FontMetrics;->ascent:F

    const/4 v3, 0x4

    add-float/2addr v1, v0

    const/4 v3, 0x6

    const/high16 v0, 0x40000000    # 2.0f

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    div-float/2addr v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v1
.end method

.method private Z0()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->Y:Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x3

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->X:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public static a1(Landroid/content/Context;Landroid/util/AttributeSet;II)Lcom/google/android/material/chip/b;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Lcom/google/android/material/chip/b;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/google/android/material/chip/b;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0, p1, p2, p3}, Lcom/google/android/material/chip/b;->i2(Landroid/util/AttributeSet;II)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public static b1(Landroid/content/Context;I)Lcom/google/android/material/chip/b;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/m1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v0, "icph"

    const-string/jumbo v0, "pich"

    const-string v0, "cphi"

    const-string v0, "chip"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p0, p1, v0}, Lr4/a;->a(Landroid/content/Context;ILjava/lang/CharSequence;)Landroid/util/AttributeSet;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {p1}, Landroid/util/AttributeSet;->getStyleAttribute()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x7

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_Chip_Entry:I

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget v1, Lcom/google/android/material/R$attr;->chipStandaloneStyle:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, p1, v1, v0}, Lcom/google/android/material/chip/b;->a1(Landroid/content/Context;Landroid/util/AttributeSet;II)Lcom/google/android/material/chip/b;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p0
.end method

.method private c1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V
    .locals 7
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->L3()Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v6, 0x2

    invoke-direct {p0, p2, v0}, Lcom/google/android/material/chip/b;->Q0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object p2, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget v0, p2, Landroid/graphics/RectF;->left:F

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget p2, p2, Landroid/graphics/RectF;->top:F

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1, v0, p2}, Landroid/graphics/Canvas;->translate(FF)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v2}, Landroid/graphics/RectF;->width()F

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    float-to-int v2, v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v3}, Landroid/graphics/RectF;->height()F

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    float-to-int v3, v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x5

    invoke-virtual {v1, v4, v4, v2, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    neg-float v0, v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    neg-float p2, p2

    const/4 v5, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p1, v0, p2}, Landroid/graphics/Canvas;->translate(FF)V

    :cond_0
    const/4 v6, 0x3

    return-void
.end method

.method private d1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V
    .locals 5
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/android/material/chip/b;->T0:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->T1()Landroid/graphics/ColorFilter;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, p2}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object p2, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->o1()F

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->o1()F

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1, p2, v0, v1, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-void
.end method

.method private e1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V
    .locals 7
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->M3()Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {p0, p2, v0}, Lcom/google/android/material/chip/b;->Q0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object p2, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget v0, p2, Landroid/graphics/RectF;->left:F

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget p2, p2, Landroid/graphics/RectF;->top:F

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1, v0, p2}, Landroid/graphics/Canvas;->translate(FF)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x7

    xor-int/2addr v6, v5

    iget-object v2, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    invoke-virtual {v2}, Landroid/graphics/RectF;->width()F

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x1

    float-to-int v2, v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v3, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v3}, Landroid/graphics/RectF;->height()F

    move-result v3

    const/4 v6, 0x5

    float-to-int v3, v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v4, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1, v4, v4, v2, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    neg-float v0, v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    neg-float p2, p2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1, v0, p2}, Landroid/graphics/Canvas;->translate(FF)V

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-void
.end method

.method private f1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V
    .locals 9
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget v0, p0, Lcom/google/android/material/chip/b;->J:F

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    cmpl-float v0, v0, v1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-lez v0, :cond_1

    const/4 v8, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-nez v0, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget v1, p0, Lcom/google/android/material/chip/b;->V0:I

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v8, 0x3

    const/4 v7, 0x0

    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v8, 0x6

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v8, 0x1

    const/4 v7, 0x0

    if-nez v0, :cond_0

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->T1()Landroid/graphics/ColorFilter;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget v1, p2, Landroid/graphics/Rect;->left:I

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    int-to-float v1, v1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget v2, p0, Lcom/google/android/material/chip/b;->J:F

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/high16 v3, 0x40000000    # 2.0f

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    div-float v4, v2, v3

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    add-float/2addr v1, v4

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget v4, p2, Landroid/graphics/Rect;->top:I

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    int-to-float v4, v4

    const/4 v8, 0x2

    const/4 v7, 0x7

    div-float v5, v2, v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    add-float/2addr v4, v5

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    iget v5, p2, Landroid/graphics/Rect;->right:I

    const/4 v8, 0x4

    int-to-float v5, v5

    const/4 v8, 0x2

    const/4 v7, 0x7

    div-float v6, v2, v3

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    sub-float/2addr v5, v6

    const/4 v8, 0x0

    const/4 v7, 0x2

    iget p2, p2, Landroid/graphics/Rect;->bottom:I

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    int-to-float p2, p2

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    div-float/2addr v2, v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    sub-float/2addr p2, v2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v0, v1, v4, v5, p2}, Landroid/graphics/RectF;->set(FFFF)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget p2, p0, Lcom/google/android/material/chip/b;->H:F

    const/4 v8, 0x6

    iget v0, p0, Lcom/google/android/material/chip/b;->J:F

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    div-float/2addr v0, v3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    sub-float/2addr p2, v0

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p1, v0, p2, p2, v1}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    return-void
.end method

.method private static f2(Landroid/content/res/ColorStateList;)Z
    .locals 2
    .param p0    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    if-eqz p0, :cond_0

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/content/res/ColorStateList;->isStateful()Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-eqz p0, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p0, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p0
.end method

.method private g1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V
    .locals 5
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/android/material/chip/b;->S0:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, p2}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    const/4 v3, 0x5

    or-int/2addr v4, v3

    iget-object p2, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->o1()F

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->o1()F

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v4, 0x2

    invoke-virtual {p1, p2, v0, v1, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method private static g2(Landroid/graphics/drawable/Drawable;)Z
    .locals 2
    .param p0    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    if-eqz p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-eqz p0, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p0, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return p0
.end method

.method private h1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V
    .locals 7
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz v0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-direct {p0, p2, v0}, Lcom/google/android/material/chip/b;->T0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object p2, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget v0, p2, Landroid/graphics/RectF;->left:F

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget p2, p2, Landroid/graphics/RectF;->top:F

    const/4 v6, 0x4

    invoke-virtual {p1, v0, p2}, Landroid/graphics/Canvas;->translate(FF)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v2}, Landroid/graphics/RectF;->width()F

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    float-to-int v2, v2

    const/4 v5, 0x3

    and-int/2addr v6, v5

    iget-object v3, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v3}, Landroid/graphics/RectF;->height()F

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    float-to-int v3, v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1, v4, v4, v2, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    sget-boolean v1, Lcom/google/android/material/ripple/b;->a:Z

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/google/android/material/chip/b;->T:Landroid/graphics/drawable/Drawable;

    iget-object v2, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/google/android/material/chip/b;->T:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->jumpToCurrentState()V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/google/android/material/chip/b;->T:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    neg-float v0, v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    neg-float p2, p2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p1, v0, p2}, Landroid/graphics/Canvas;->translate(FF)V

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-void
.end method

.method private static h2(Lcom/google/android/material/resources/d;)Z
    .locals 3
    .param p0    # Lcom/google/android/material/resources/d;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    invoke-virtual {p0}, Lcom/google/android/material/resources/d;->i()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/resources/d;->i()Landroid/content/res/ColorStateList;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/res/ColorStateList;->isStateful()Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 p0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    move v2, v1

    const/4 p0, 0x0

    shl-int/2addr v2, p0

    :goto_0
    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return p0
.end method

.method private i1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V
    .locals 5
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/android/material/chip/b;->W0:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v4, 0x6

    const/4 v3, 0x0

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v3, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, p2}, Landroid/graphics/RectF;->set(Landroid/graphics/Rect;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object p2, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->o1()F

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->o1()F

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p1, p2, v0, v1, v2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v0, Landroid/graphics/RectF;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0, p2}, Landroid/graphics/RectF;-><init>(Landroid/graphics/Rect;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object p2, p0, Lcom/google/android/material/chip/b;->Q0:Landroid/graphics/Path;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0, v0, p2}, Lcom/google/android/material/shape/j;->h(Landroid/graphics/RectF;Landroid/graphics/Path;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object p2, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->Q0:Landroid/graphics/Path;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->v()Landroid/graphics/RectF;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-super {p0, p1, p2, v0, v1}, Lcom/google/android/material/shape/j;->q(Landroid/graphics/Canvas;Landroid/graphics/Paint;Landroid/graphics/Path;Landroid/graphics/RectF;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void
.end method

.method private i2(Landroid/util/AttributeSet;II)V
    .locals 9
    .param p1    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    sget-object v2, Lcom/google/android/material/R$styleable;->Chip:[I

    const/4 v8, 0x5

    const/4 v6, 0x0

    const/4 v8, 0x6

    const/4 v6, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x0

    new-array v5, v6, [I

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    move v3, p2

    move v3, p2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    move v4, p3

    move v4, p3

    const/4 v8, 0x1

    move v4, p3

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    sget p3, Lcom/google/android/material/R$styleable;->Chip_shapeAppearance:I

    const/4 v8, 0x7

    const/4 v7, 0x3

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    iput-boolean p3, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object p3, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v7, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    sget v0, Lcom/google/android/material/R$styleable;->Chip_chipSurfaceColor:I

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {p3, p2, v0}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object p3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-direct {p0, p3}, Lcom/google/android/material/chip/b;->T2(Landroid/content/res/ColorStateList;)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object p3, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    sget v0, Lcom/google/android/material/R$styleable;->Chip_chipBackgroundColor:I

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {p3, p2, v0}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object p3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->v2(Landroid/content/res/ColorStateList;)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->Chip_chipMinHeight:I

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/4 v0, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x7

    invoke-virtual {p2, p3, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p3

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->L2(F)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    sget p3, Lcom/google/android/material/R$styleable;->Chip_chipCornerRadius:I

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz v1, :cond_0

    const/4 v8, 0x5

    invoke-virtual {p2, p3, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p3

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->x2(F)V

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget-object p3, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    sget v1, Lcom/google/android/material/R$styleable;->Chip_chipStrokeColor:I

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {p3, p2, v1}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object p3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->P2(Landroid/content/res/ColorStateList;)V

    const/4 v8, 0x4

    sget p3, Lcom/google/android/material/R$styleable;->Chip_chipStrokeWidth:I

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {p2, p3, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->R2(F)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget-object p3, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    sget v1, Lcom/google/android/material/R$styleable;->Chip_rippleColor:I

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {p3, p2, v1}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object p3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->t3(Landroid/content/res/ColorStateList;)V

    const/4 v8, 0x1

    sget p3, Lcom/google/android/material/R$styleable;->Chip_android_text:I

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {p2, p3}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object p3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->y3(Ljava/lang/CharSequence;)V

    const/4 v7, 0x1

    move v8, v7

    iget-object p3, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    sget v1, Lcom/google/android/material/R$styleable;->Chip_android_textAppearance:I

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {p3, p2, v1}, Lcom/google/android/material/resources/c;->g(Landroid/content/Context;Landroid/content/res/TypedArray;I)Lcom/google/android/material/resources/d;

    move-result-object p3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    sget v1, Lcom/google/android/material/R$styleable;->Chip_android_textSize:I

    const/4 v8, 0x1

    invoke-virtual {p3}, Lcom/google/android/material/resources/d;->j()F

    move-result v2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p2, v1, v2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p3, v1}, Lcom/google/android/material/resources/d;->l(F)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->z3(Lcom/google/android/material/resources/d;)V

    const/4 v8, 0x6

    sget p3, Lcom/google/android/material/R$styleable;->Chip_android_ellipsize:I

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p2, p3, v6}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p3

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v1, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eq p3, v1, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v1, 0x2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eq p3, v1, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v1, 0x3

    const/4 v8, 0x4

    const/4 v7, 0x3

    if-eq p3, v1, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    goto :goto_0

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    sget-object p3, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->l3(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v7, 0x7

    move v8, v7

    goto :goto_0

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    sget-object p3, Landroid/text/TextUtils$TruncateAt;->MIDDLE:Landroid/text/TextUtils$TruncateAt;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->l3(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v7, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    goto :goto_0

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    sget-object p3, Landroid/text/TextUtils$TruncateAt;->START:Landroid/text/TextUtils$TruncateAt;

    const/4 v7, 0x7

    or-int/2addr v8, v7

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->l3(Landroid/text/TextUtils$TruncateAt;)V

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    sget p3, Lcom/google/android/material/R$styleable;->Chip_chipIconVisible:I

    const/4 v8, 0x5

    invoke-virtual {p2, p3, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p3

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/b;->K2(Z)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string/jumbo p3, "sccmd-t/re/saduhktomoht..prn/si/apa:sem"

    const-string/jumbo p3, "oas/os-i.dpa.shdcoratpe:u/t/snhr/cetmmk"

    const/4 v8, 0x0

    const-string/jumbo p3, "rsu/oa/i.drpaothmmstoc:se.otepdak/n-h/a"

    const-string/jumbo p3, "http://schemas.android.com/apk/res-auto"

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eqz p1, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v1, "cnEmebIphnoilcb"

    const-string v1, "IiambonhEpelcnc"

    const/4 v8, 0x4

    const-string v1, "bdcIhEuipneonac"

    const-string v1, "chipIconEnabled"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-interface {p1, p3, v1}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz v1, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    const-string v1, "bsVoiceppcionlh"

    const-string/jumbo v1, "onspohlccViiebI"

    const/4 v8, 0x5

    const-string/jumbo v1, "iehipcilqbnoIsc"

    const-string v1, "chipIconVisible"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-interface {p1, p3, v1}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-nez v1, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    sget v1, Lcom/google/android/material/R$styleable;->Chip_chipIconEnabled:I

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p2, v1, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v7, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p0, v1}, Lcom/google/android/material/chip/b;->K2(Z)V

    :cond_4
    const/4 v8, 0x7

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v7, 0x7

    const/4 v7, 0x6

    sget v2, Lcom/google/android/material/R$styleable;->Chip_chipIcon:I

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {v1, p2, v2}, Lcom/google/android/material/resources/c;->e(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p0, v1}, Lcom/google/android/material/chip/b;->B2(Landroid/graphics/drawable/Drawable;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    sget v1, Lcom/google/android/material/R$styleable;->Chip_chipIconTint:I

    const/4 v7, 0x2

    or-int/2addr v8, v7

    invoke-virtual {p2, v1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz v2, :cond_5

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    iget-object v2, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {v2, p2, v1}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p0, v1}, Lcom/google/android/material/chip/b;->H2(Landroid/content/res/ColorStateList;)V

    :cond_5
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    sget v1, Lcom/google/android/material/R$styleable;->Chip_chipIconSize:I

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/high16 v2, -0x40800000    # -1.0f

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p2, v1, v2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p0, v1}, Lcom/google/android/material/chip/b;->F2(F)V

    const/4 v7, 0x1

    move v8, v7

    sget v1, Lcom/google/android/material/R$styleable;->Chip_closeIconVisible:I

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p2, v1, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {p0, v1}, Lcom/google/android/material/chip/b;->j3(Z)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-eqz p1, :cond_6

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-string v1, "IcscnbEdsnoaeebl"

    const-string/jumbo v1, "lconcbEbdeIaeson"

    const/4 v8, 0x7

    const-string v1, "closeIconEnabled"

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-interface {p1, p3, v1}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-eqz v1, :cond_6

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string/jumbo v1, "uismsVlIbiocceln"

    const-string/jumbo v1, "ibeVncuiolselIsc"

    const/4 v8, 0x5

    const-string/jumbo v1, "isIeoiVnboloecsc"

    const-string v1, "closeIconVisible"

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-interface {p1, p3, v1}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    if-nez v1, :cond_6

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    sget v1, Lcom/google/android/material/R$styleable;->Chip_closeIconEnabled:I

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p2, v1, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p0, v1}, Lcom/google/android/material/chip/b;->j3(Z)V

    :cond_6
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    sget v2, Lcom/google/android/material/R$styleable;->Chip_closeIcon:I

    const/4 v8, 0x2

    invoke-static {v1, p2, v2}, Lcom/google/android/material/resources/c;->e(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {p0, v1}, Lcom/google/android/material/chip/b;->U2(Landroid/graphics/drawable/Drawable;)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object v1, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    sget v2, Lcom/google/android/material/R$styleable;->Chip_closeIconTint:I

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v1, p2, v2}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p0, v1}, Lcom/google/android/material/chip/b;->g3(Landroid/content/res/ColorStateList;)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    sget v1, Lcom/google/android/material/R$styleable;->Chip_closeIconSize:I

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p2, v1, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {p0, v1}, Lcom/google/android/material/chip/b;->b3(F)V

    const/4 v8, 0x4

    sget v1, Lcom/google/android/material/R$styleable;->Chip_android_checkable:I

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p2, v1, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p0, v1}, Lcom/google/android/material/chip/b;->l2(Z)V

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    sget v1, Lcom/google/android/material/R$styleable;->Chip_checkedIconVisible:I

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p2, v1, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v8, 0x1

    const/4 v7, 0x0

    invoke-virtual {p0, v1}, Lcom/google/android/material/chip/b;->u2(Z)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-eqz p1, :cond_7

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string/jumbo v1, "oleIpbhcaEeknbcdce"

    const-string v1, "ahcneokpelebdccdIE"

    const/4 v8, 0x0

    const-string/jumbo v1, "nacddeuhokcElecebn"

    const-string v1, "checkedIconEnabled"

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {p1, p3, v1}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eqz v1, :cond_7

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string v1, "bhldcVepnkicsieIoc"

    const-string v1, "bosinIdcqekchcieVl"

    const/4 v8, 0x1

    const-string/jumbo v1, "nlsoiIekqcbdehceci"

    const-string v1, "checkedIconVisible"

    const/4 v8, 0x3

    const/4 v7, 0x1

    invoke-interface {p1, p3, v1}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-nez p1, :cond_7

    const/4 v7, 0x5

    const/4 v8, 0x7

    sget p1, Lcom/google/android/material/R$styleable;->Chip_checkedIconEnabled:I

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {p2, p1, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->u2(Z)V

    :cond_7
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object p1, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v8, 0x1

    sget p3, Lcom/google/android/material/R$styleable;->Chip_checkedIcon:I

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {p1, p2, p3}, Lcom/google/android/material/resources/c;->e(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->n2(Landroid/graphics/drawable/Drawable;)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    sget p1, Lcom/google/android/material/R$styleable;->Chip_checkedIconTint:I

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p2, p1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p3

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-eqz p3, :cond_8

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object p3, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v7, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {p3, p2, p1}, Lcom/google/android/material/resources/c;->a(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->r2(Landroid/content/res/ColorStateList;)V

    :cond_8
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    iget-object p1, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    sget p3, Lcom/google/android/material/R$styleable;->Chip_showMotionSpec:I

    const/4 v8, 0x3

    invoke-static {p1, p2, p3}, Lcom/google/android/material/animation/h;->c(Landroid/content/Context;Landroid/content/res/TypedArray;I)Lcom/google/android/material/animation/h;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->w3(Lcom/google/android/material/animation/h;)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    iget-object p1, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    sget p3, Lcom/google/android/material/R$styleable;->Chip_hideMotionSpec:I

    const/4 v8, 0x2

    invoke-static {p1, p2, p3}, Lcom/google/android/material/animation/h;->c(Landroid/content/Context;Landroid/content/res/TypedArray;I)Lcom/google/android/material/animation/h;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->m3(Lcom/google/android/material/animation/h;)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    sget p1, Lcom/google/android/material/R$styleable;->Chip_chipStartPadding:I

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p2, p1, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->N2(F)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    sget p1, Lcom/google/android/material/R$styleable;->Chip_iconStartPadding:I

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p2, p1, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->q3(F)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    sget p1, Lcom/google/android/material/R$styleable;->Chip_iconEndPadding:I

    const/4 v7, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p2, p1, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->o3(F)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    sget p1, Lcom/google/android/material/R$styleable;->Chip_textStartPadding:I

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p2, p1, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->H3(F)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    sget p1, Lcom/google/android/material/R$styleable;->Chip_textEndPadding:I

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p2, p1, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->D3(F)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    sget p1, Lcom/google/android/material/R$styleable;->Chip_closeIconStartPadding:I

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p2, p1, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->d3(F)V

    const/4 v7, 0x0

    xor-int/2addr v8, v7

    sget p1, Lcom/google/android/material/R$styleable;->Chip_closeIconEndPadding:I

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p2, p1, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->Y2(F)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    sget p1, Lcom/google/android/material/R$styleable;->Chip_chipEndPadding:I

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {p2, p1, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->z2(F)V

    const/4 v8, 0x2

    sget p1, Lcom/google/android/material/R$styleable;->Chip_android_maxWidth:I

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    const p3, 0x7fffffff

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p2, p1, p3}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->s3(I)V

    const/4 v8, 0x6

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    return-void
.end method

.method private j1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V
    .locals 11
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->M0:Landroid/graphics/Paint;

    const/4 v10, 0x7

    if-eqz v0, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/high16 v1, -0x1000000

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/16 v2, 0x7f

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-static {v1, v2}, Landroidx/core/graphics/b0;->B(II)I

    move-result v1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->M0:Landroid/graphics/Paint;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {p1, p2, v0}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/Rect;Landroid/graphics/Paint;)V

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->M3()Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-nez v0, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->L3()Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-eqz v0, :cond_1

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    invoke-direct {p0, p2, v0}, Lcom/google/android/material/chip/b;->Q0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    iget-object v1, p0, Lcom/google/android/material/chip/b;->M0:Landroid/graphics/Paint;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    :cond_1
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L:Ljava/lang/CharSequence;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eqz v0, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget v0, p2, Landroid/graphics/Rect;->left:I

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    int-to-float v4, v0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p2}, Landroid/graphics/Rect;->exactCenterY()F

    move-result v5

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget v0, p2, Landroid/graphics/Rect;->right:I

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    int-to-float v6, v0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {p2}, Landroid/graphics/Rect;->exactCenterY()F

    move-result v7

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget-object v8, p0, Lcom/google/android/material/chip/b;->M0:Landroid/graphics/Paint;

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    :cond_2
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz v0, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-direct {p0, p2, v0}, Lcom/google/android/material/chip/b;->T0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/google/android/material/chip/b;->M0:Landroid/graphics/Paint;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    :cond_3
    const/4 v10, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->M0:Landroid/graphics/Paint;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    const/high16 v1, -0x10000

    const/4 v10, 0x5

    invoke-static {v1, v2}, Landroidx/core/graphics/b0;->B(II)I

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-direct {p0, p2, v0}, Lcom/google/android/material/chip/b;->S0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object v1, p0, Lcom/google/android/material/chip/b;->M0:Landroid/graphics/Paint;

    const/4 v10, 0x5

    const/4 v9, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->M0:Landroid/graphics/Paint;

    const/4 v10, 0x7

    const v1, -0xff0100

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {v1, v2}, Landroidx/core/graphics/b0;->B(II)I

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-direct {p0, p2, v0}, Lcom/google/android/material/chip/b;->U0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object p2, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->M0:Landroid/graphics/Paint;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p1, p2, v0}, Landroid/graphics/Canvas;->drawRect(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    :cond_4
    const/4 v10, 0x1

    const/4 v9, 0x1

    return-void
.end method

.method private k1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V
    .locals 11
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L:Ljava/lang/CharSequence;

    const/4 v10, 0x7

    if-eqz v0, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->P0:Landroid/graphics/PointF;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p0, p2, v0}, Lcom/google/android/material/chip/b;->Y0(Landroid/graphics/Rect;Landroid/graphics/PointF;)Landroid/graphics/Paint$Align;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v10, 0x1

    invoke-direct {p0, p2, v1}, Lcom/google/android/material/chip/b;->W0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object p2, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p2}, Lcom/google/android/material/internal/n;->d()Lcom/google/android/material/resources/d;

    move-result-object p2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-eqz p2, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object p2, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v9, 0x5

    move v10, v9

    invoke-virtual {p2}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object p2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    iput-object v1, p2, Landroid/text/TextPaint;->drawableState:[I

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-object p2, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v10, 0x4

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p2, v1}, Lcom/google/android/material/internal/n;->k(Landroid/content/Context;)V

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x7

    iget-object p2, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p2}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object p2

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x7

    iget-object p2, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->P1()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {p2, v0}, Lcom/google/android/material/internal/n;->f(Ljava/lang/String;)F

    move-result p2

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    const/4 v10, 0x6

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v10, 0x4

    invoke-virtual {v0}, Landroid/graphics/RectF;->width()F

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/4 v1, 0x0

    const/4 v10, 0x2

    if-le p2, v0, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/4 p2, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    goto :goto_0

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    move p2, v1

    const/4 v10, 0x2

    move p2, v1

    move p2, v1

    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    if-eqz p2, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    const/4 v10, 0x2

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p1, v0}, Landroid/graphics/Canvas;->clipRect(Landroid/graphics/RectF;)Z

    :cond_2
    const/4 v10, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L:Ljava/lang/CharSequence;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eqz p2, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    iget-object v2, p0, Lcom/google/android/material/chip/b;->j1:Landroid/text/TextUtils$TruncateAt;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    if-eqz v2, :cond_3

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object v2, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v2}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-object v3, p0, Lcom/google/android/material/chip/b;->O0:Landroid/graphics/RectF;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {v3}, Landroid/graphics/RectF;->width()F

    move-result v3

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object v4, p0, Lcom/google/android/material/chip/b;->j1:Landroid/text/TextUtils$TruncateAt;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {v0, v2, v3, v4}, Landroid/text/TextUtils;->ellipsize(Ljava/lang/CharSequence;Landroid/text/TextPaint;FLandroid/text/TextUtils$TruncateAt;)Ljava/lang/CharSequence;

    move-result-object v0

    :cond_3
    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    const/4 v4, 0x0

    const/4 v10, 0x1

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v5

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->P0:Landroid/graphics/PointF;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget v6, v0, Landroid/graphics/PointF;->x:F

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget v7, v0, Landroid/graphics/PointF;->y:F

    const/4 v9, 0x4

    and-int/2addr v10, v9

    iget-object v0, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object v8

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual/range {v2 .. v8}, Landroid/graphics/Canvas;->drawText(Ljava/lang/CharSequence;IIFFLandroid/graphics/Paint;)V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-eqz p2, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_4
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    return-void
.end method

.method private k2([I[I)Z
    .locals 8
    .param p1    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-super {p0, p1}, Lcom/google/android/material/shape/j;->onStateChange([I)Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/google/android/material/chip/b;->E:Landroid/content/res/ColorStateList;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget v3, p0, Lcom/google/android/material/chip/b;->S0:I

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v1, p1, v3}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    move v7, v6

    move v1, v2

    move v1, v2

    const/4 v7, 0x0

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p0, v1}, Lcom/google/android/material/shape/j;->l(I)I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget v3, p0, Lcom/google/android/material/chip/b;->S0:I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/4 v4, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x6

    if-eq v3, v1, :cond_1

    const/4 v7, 0x5

    iput v1, p0, Lcom/google/android/material/chip/b;->S0:I

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    move v0, v4

    move v0, v4

    const/4 v7, 0x6

    move v0, v4

    move v0, v4

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/google/android/material/chip/b;->F:Landroid/content/res/ColorStateList;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v3, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget v5, p0, Lcom/google/android/material/chip/b;->T0:I

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v3, p1, v5}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_1

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    move v3, v2

    move v3, v2

    const/4 v7, 0x3

    move v3, v2

    move v3, v2

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p0, v3}, Lcom/google/android/material/shape/j;->l(I)I

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget v5, p0, Lcom/google/android/material/chip/b;->T0:I

    const/4 v6, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eq v5, v3, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    iput v3, p0, Lcom/google/android/material/chip/b;->T0:I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    move v0, v4

    move v0, v4

    :cond_3
    const/4 v6, 0x5

    move v7, v6

    invoke-static {v1, v3}, Lcom/google/android/material/color/s;->l(II)I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x5

    iget v3, p0, Lcom/google/android/material/chip/b;->U0:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eq v3, v1, :cond_4

    const/4 v7, 0x7

    move v3, v4

    move v3, v4

    const/4 v7, 0x2

    move v3, v4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    goto :goto_2

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    move v3, v2

    move v3, v2

    const/4 v7, 0x2

    move v3, v2

    move v3, v2

    :goto_2
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->y()Landroid/content/res/ColorStateList;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v6, 0x5

    if-nez v5, :cond_5

    const/4 v7, 0x1

    const/4 v6, 0x7

    move v5, v4

    move v5, v4

    const/4 v7, 0x6

    move v5, v4

    move v5, v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    goto :goto_3

    :cond_5
    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    move v5, v2

    move v5, v2

    const/4 v7, 0x4

    move v5, v2

    move v5, v2

    :goto_3
    const/4 v7, 0x3

    const/4 v6, 0x2

    or-int/2addr v3, v5

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v3, :cond_6

    const/4 v6, 0x7

    or-int/2addr v7, v6

    iput v1, p0, Lcom/google/android/material/chip/b;->U0:I

    invoke-static {v1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p0, v0}, Lcom/google/android/material/shape/j;->o0(Landroid/content/res/ColorStateList;)V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    move v0, v4

    move v0, v4

    const/4 v7, 0x7

    move v0, v4

    move v0, v4

    :cond_6
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/google/android/material/chip/b;->I:Landroid/content/res/ColorStateList;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-eqz v1, :cond_7

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget v3, p0, Lcom/google/android/material/chip/b;->V0:I

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v1, p1, v3}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto :goto_4

    :cond_7
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    move v1, v2

    move v1, v2

    const/4 v7, 0x0

    move v1, v2

    move v1, v2

    :goto_4
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget v3, p0, Lcom/google/android/material/chip/b;->V0:I

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eq v3, v1, :cond_8

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    iput v1, p0, Lcom/google/android/material/chip/b;->V0:I

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    move v0, v4

    move v0, v4

    const/4 v7, 0x3

    move v0, v4

    move v0, v4

    :cond_8
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/google/android/material/chip/b;->h1:Landroid/content/res/ColorStateList;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v1, :cond_9

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {p1}, Lcom/google/android/material/ripple/b;->e([I)Z

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v1, :cond_9

    const/4 v7, 0x2

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/google/android/material/chip/b;->h1:Landroid/content/res/ColorStateList;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget v3, p0, Lcom/google/android/material/chip/b;->W0:I

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v1, p1, v3}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    goto :goto_5

    :cond_9
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    move v1, v2

    move v1, v2

    const/4 v7, 0x0

    move v1, v2

    move v1, v2

    :goto_5
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget v3, p0, Lcom/google/android/material/chip/b;->W0:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eq v3, v1, :cond_a

    const/4 v7, 0x1

    iput v1, p0, Lcom/google/android/material/chip/b;->W0:I

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-boolean v1, p0, Lcom/google/android/material/chip/b;->g1:Z

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz v1, :cond_a

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    move v0, v4

    const/4 v7, 0x2

    move v0, v4

    move v0, v4

    :cond_a
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v1}, Lcom/google/android/material/internal/n;->d()Lcom/google/android/material/resources/d;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v1, :cond_b

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v7, 0x0

    invoke-virtual {v1}, Lcom/google/android/material/internal/n;->d()Lcom/google/android/material/resources/d;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1}, Lcom/google/android/material/resources/d;->i()Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v1, :cond_b

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v1}, Lcom/google/android/material/internal/n;->d()Lcom/google/android/material/resources/d;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v1}, Lcom/google/android/material/resources/d;->i()Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    iget v3, p0, Lcom/google/android/material/chip/b;->X0:I

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v1, p1, v3}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    goto :goto_6

    :cond_b
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    move v1, v2

    move v1, v2

    :goto_6
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget v3, p0, Lcom/google/android/material/chip/b;->X0:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    if-eq v3, v1, :cond_c

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    iput v1, p0, Lcom/google/android/material/chip/b;->X0:I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    move v0, v4

    move v0, v4

    const/4 v7, 0x6

    move v0, v4

    move v0, v4

    :cond_c
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    const v3, 0x10100a0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {v1, v3}, Lcom/google/android/material/chip/b;->V1([II)Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz v1, :cond_d

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-boolean v1, p0, Lcom/google/android/material/chip/b;->X:Z

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v1, :cond_d

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    move v1, v4

    move v1, v4

    const/4 v7, 0x2

    move v1, v4

    move v1, v4

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    goto :goto_7

    :cond_d
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    move v1, v2

    move v1, v2

    const/4 v7, 0x7

    move v1, v2

    move v1, v2

    :goto_7
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-boolean v3, p0, Lcom/google/android/material/chip/b;->Y0:Z

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eq v3, v1, :cond_f

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-eqz v3, :cond_f

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    iput-boolean v1, p0, Lcom/google/android/material/chip/b;->Y0:Z

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    cmpl-float v0, v0, v1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v0, :cond_e

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    move v0, v4

    move v0, v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    move v1, v0

    move v1, v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto :goto_8

    :cond_e
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    move v1, v2

    move v1, v2

    const/4 v7, 0x1

    move v1, v2

    move v1, v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    move v0, v4

    move v0, v4

    const/4 v7, 0x5

    move v0, v4

    move v0, v4

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    goto :goto_8

    :cond_f
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    move v1, v2

    move v1, v2

    const/4 v7, 0x3

    move v1, v2

    :goto_8
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v3, p0, Lcom/google/android/material/chip/b;->d1:Landroid/content/res/ColorStateList;

    const/4 v7, 0x4

    if-eqz v3, :cond_10

    const/4 v7, 0x0

    iget v5, p0, Lcom/google/android/material/chip/b;->Z0:I

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v3, p1, v5}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result v3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_9

    :cond_10
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    move v3, v2

    move v3, v2

    const/4 v7, 0x1

    move v3, v2

    :goto_9
    const/4 v7, 0x6

    const/4 v6, 0x6

    iget v5, p0, Lcom/google/android/material/chip/b;->Z0:I

    const/4 v7, 0x6

    if-eq v5, v3, :cond_11

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    iput v3, p0, Lcom/google/android/material/chip/b;->Z0:I

    const/4 v6, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->d1:Landroid/content/res/ColorStateList;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v3, p0, Lcom/google/android/material/chip/b;->e1:Landroid/graphics/PorterDuff$Mode;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {p0, v0, v3}, Lr4/a;->c(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    iput-object v0, p0, Lcom/google/android/material/chip/b;->c1:Landroid/graphics/PorterDuffColorFilter;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    goto :goto_a

    :cond_11
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    move v4, v0

    move v4, v0

    const/4 v7, 0x0

    move v4, v0

    move v4, v0

    :goto_a
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v0}, Lcom/google/android/material/chip/b;->g2(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    if-eqz v0, :cond_12

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    or-int/2addr v4, v0

    :cond_12
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v0}, Lcom/google/android/material/chip/b;->g2(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz v0, :cond_13

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    or-int/2addr v4, v0

    :cond_13
    const/4 v7, 0x6

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v0}, Lcom/google/android/material/chip/b;->g2(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    if-eqz v0, :cond_14

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    array-length v0, p1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    array-length v3, p2

    const/4 v7, 0x6

    add-int/2addr v0, v3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-array v0, v0, [I

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    array-length v3, p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-static {p1, v2, v0, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    array-length p1, p1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    array-length v3, p2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {p2, v2, v0, p1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x7

    shr-int/2addr v7, v6

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    or-int/2addr v4, p1

    :cond_14
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    sget-boolean p1, Lcom/google/android/material/ripple/b;->a:Z

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz p1, :cond_15

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/google/android/material/chip/b;->T:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {p1}, Lcom/google/android/material/chip/b;->g2(Landroid/graphics/drawable/Drawable;)Z

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-eqz p1, :cond_15

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object p1, p0, Lcom/google/android/material/chip/b;->T:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    or-int/2addr v4, p1

    :cond_15
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz v4, :cond_16

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_16
    if-eqz v1, :cond_17

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_17
    const/4 v6, 0x1

    const/4 v7, 0x6

    return v4
.end method


# virtual methods
.method public A1()F
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/chip/b;->I0:F

    const/4 v2, 0x0

    const/4 v1, 0x3

    return v0
.end method

.method public A2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->z2(F)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public A3(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x4

    new-instance v0, Lcom/google/android/material/resources/d;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0, v1, p1}, Lcom/google/android/material/resources/d;-><init>(Landroid/content/Context;I)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/google/android/material/chip/b;->z3(Lcom/google/android/material/resources/d;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method public B1()F
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/chip/b;->V:F

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public B2(Landroid/graphics/drawable/Drawable;)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->q1()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eq v0, p1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p1}, Landroidx/core/graphics/drawable/d;->r(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Lcom/google/android/material/chip/b;->O3(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->M3()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Lcom/google/android/material/chip/b;->P0(Landroid/graphics/drawable/Drawable;)V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    cmpl-float p1, v1, p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public B3(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->C3(Landroid/content/res/ColorStateList;)V

    const/4 v1, 0x5

    return-void
.end method

.method public C1()F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/chip/b;->H0:F

    const/4 v2, 0x2

    const/4 v1, 0x1

    return v0
.end method

.method public C2(Z)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->K2(Z)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public C3(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->Q1()Lcom/google/android/material/resources/d;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/android/material/resources/d;->k(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x4

    return-void
.end method

.method public D1()[I
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->f1:[I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public D2(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->J2(I)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public D3(F)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/chip/b;->G0:F

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    cmpl-float v0, v0, p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput p1, p0, Lcom/google/android/material/chip/b;->G0:F

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public E1()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->U:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public E2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lf/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->B2(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public E3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->D3(F)V

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    return-void
.end method

.method public F1(Landroid/graphics/RectF;)V
    .locals 3
    .param p1    # Landroid/graphics/RectF;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0, v0, p1}, Lcom/google/android/material/chip/b;->U0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public F2(F)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/chip/b;->P:F

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    cmpl-float v0, v0, p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/chip/b;->P:F

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    cmpl-float p1, v0, p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public F3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/e1;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->y3(Ljava/lang/CharSequence;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public G2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->F2(F)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public G3(F)V
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->Q1()Lcom/google/android/material/resources/d;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/android/material/resources/d;->l(F)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->e()Landroid/text/TextPaint;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setTextSize(F)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->a()V

    :cond_0
    return-void
.end method

.method public H2(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    move v2, v1

    const/4 v0, 0x1

    and-int/2addr v2, v0

    const/4 v1, 0x6

    move v2, v1

    iput-boolean v0, p0, Lcom/google/android/material/chip/b;->Q:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O:Landroid/content/res/ColorStateList;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eq v0, p1, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/material/chip/b;->O:Landroid/content/res/ColorStateList;

    const/4 v1, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->M3()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->onStateChange([I)Z

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public H3(F)V
    .locals 3

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/chip/b;->F0:F

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    cmpl-float v0, v0, p1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    move v2, v1

    iput p1, p0, Lcom/google/android/material/chip/b;->F0:F

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public I1()Landroid/text/TextUtils$TruncateAt;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->j1:Landroid/text/TextUtils$TruncateAt;

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-object v0
.end method

.method public I2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->H2(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public I3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->H3(F)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public J1()Lcom/google/android/material/animation/h;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->B0:Lcom/google/android/material/animation/h;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public J2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->K2(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public J3(Z)V
    .locals 3

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->g1:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eq v0, p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-boolean p1, p0, Lcom/google/android/material/chip/b;->g1:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->P3()V

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->onStateChange([I)Z

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public K1()F
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    iget v0, p0, Lcom/google/android/material/chip/b;->E0:F

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public K2(Z)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->M:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eq v0, p1, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->M3()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/chip/b;->M:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->M3()Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eq v0, p1, :cond_0

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x2

    if-eqz p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/google/android/material/chip/b;->P0(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_1

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/google/android/material/chip/b;->O3(Landroid/graphics/drawable/Drawable;)V

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method K3()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->k1:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method public L1()F
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/chip/b;->D0:F

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public L2(F)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/chip/b;->G:F

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    cmpl-float v0, v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/chip/b;->G:F

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public M1()I
    .locals 3
    .annotation build Landroidx/annotation/u0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->l1:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public M2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->L2(F)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public N1()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K:Landroid/content/res/ColorStateList;

    const/4 v1, 0x6

    and-int/2addr v2, v1

    return-object v0
.end method

.method public N2(F)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->C0:F

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    cmpl-float v0, v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/android/material/chip/b;->C0:F

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public O1()Lcom/google/android/material/animation/h;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->A0:Lcom/google/android/material/animation/h;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public O2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->N2(F)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public P1()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L:Ljava/lang/CharSequence;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public P2(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->I:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eq v0, p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/material/chip/b;->I:Landroid/content/res/ColorStateList;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/shape/j;->F0(Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->onStateChange([I)Z

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public Q1()Lcom/google/android/material/resources/d;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->d()Lcom/google/android/material/resources/d;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public Q2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->P2(Landroid/content/res/ColorStateList;)V

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method R0()F
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->M3()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->L3()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    return v0

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->D0:F

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->H1()F

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-float/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/android/material/chip/b;->E0:F

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    add-float/2addr v0, v1

    return v0
.end method

.method public R1()F
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->G0:F

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public R2(F)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    iget v0, p0, Lcom/google/android/material/chip/b;->J:F

    const/4 v2, 0x1

    cmpl-float v0, v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/android/material/chip/b;->J:F

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L0:Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-super {p0, p1}, Lcom/google/android/material/shape/j;->I0(F)V

    :cond_0
    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public S1()F
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/chip/b;->F0:F

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public S2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->R2(F)V

    const/4 v2, 0x0

    return-void
.end method

.method public U1()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->g1:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    return v0
.end method

.method public U2(Landroid/graphics/drawable/Drawable;)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->y1()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eq v0, p1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->V0()F

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1}, Landroidx/core/graphics/drawable/d;->r(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-boolean p1, Lcom/google/android/material/ripple/b;->a:Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->Q3()V

    :cond_1
    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->V0()F

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0, v0}, Lcom/google/android/material/chip/b;->O3(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/android/material/chip/b;->P0(Landroid/graphics/drawable/Drawable;)V

    :cond_2
    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    cmpl-float p1, v1, p1

    if-eqz p1, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method V0()F
    .locals 4

    const/4 v2, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/chip/b;->H0:F

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v1, p0, Lcom/google/android/material/chip/b;->V:F

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    add-float/2addr v0, v1

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/material/chip/b;->I0:F

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    add-float/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    return v0
.end method

.method public V2(Ljava/lang/CharSequence;)V
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->W:Ljava/lang/CharSequence;

    const/4 v2, 0x3

    if-eq v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {}, Landroidx/core/text/a;->c()Landroidx/core/text/a;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Landroidx/core/text/a;->m(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/android/material/chip/b;->W:Ljava/lang/CharSequence;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public W1()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->X:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public W2(Z)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->j3(Z)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public X1()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->Y1()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public X2(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->i3(I)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method Y0(Landroid/graphics/Rect;Landroid/graphics/PointF;)Landroid/graphics/Paint$Align;
    .locals 4
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/PointF;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p2, v0, v0}, Landroid/graphics/PointF;->set(FF)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v0, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    const/4 v3, 0x1

    const/4 v2, 0x6

    iget-object v1, p0, Lcom/google/android/material/chip/b;->L:Ljava/lang/CharSequence;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/android/material/chip/b;->C0:F

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    add-float/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/android/material/chip/b;->F0:F

    const/4 v2, 0x4

    const/4 v2, 0x4

    add-float/2addr v0, v1

    const/4 v3, 0x2

    invoke-static {p0}, Landroidx/core/graphics/drawable/d;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x5

    iget v1, p1, Landroid/graphics/Rect;->left:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    int-to-float v1, v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-float/2addr v1, v0

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput v1, p2, Landroid/graphics/PointF;->x:F

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object v0, Landroid/graphics/Paint$Align;->LEFT:Landroid/graphics/Paint$Align;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    iget v1, p1, Landroid/graphics/Rect;->right:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    int-to-float v1, v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    sub-float/2addr v1, v0

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput v1, p2, Landroid/graphics/PointF;->x:F

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget-object v0, Landroid/graphics/Paint$Align;->RIGHT:Landroid/graphics/Paint$Align;

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/graphics/Rect;->centerY()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    int-to-float p1, p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->X0()F

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    sub-float/2addr p1, v1

    const/4 v3, 0x0

    iput p1, p2, Landroid/graphics/PointF;->y:F

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0
.end method

.method public Y1()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->Y:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public Y2(F)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/android/material/chip/b;->I0:F

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    cmpl-float v0, v0, p1

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/android/material/chip/b;->I0:F

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public Z1()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->a2()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public Z2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->Y2(F)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public a()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    return-void
.end method

.method public a2()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->M:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public a3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lf/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->U2(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public b2()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->d2()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public b3(F)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->V:F

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    cmpl-float v0, v0, p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput p1, p0, Lcom/google/android/material/chip/b;->V:F

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public c2()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/android/material/chip/b;->g2(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public c3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->b3(F)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public d2()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->R:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method public d3(F)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->H0:F

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    cmpl-float v0, v0, p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/android/material/chip/b;->H0:F

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 10
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v0}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-nez v1, :cond_4

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->getAlpha()I

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-nez v1, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    goto/16 :goto_1

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    iget v7, p0, Lcom/google/android/material/chip/b;->a1:I

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    const/16 v1, 0xff

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-ge v7, v1, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget v2, v0, Landroid/graphics/Rect;->left:I

    int-to-float v3, v2

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget v2, v0, Landroid/graphics/Rect;->top:I

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    int-to-float v4, v2

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget v2, v0, Landroid/graphics/Rect;->right:I

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    int-to-float v5, v2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget v2, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    int-to-float v6, v2

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static/range {v2 .. v7}, Lp4/a;->a(Landroid/graphics/Canvas;FFFFI)I

    move-result v2

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    goto :goto_0

    :cond_1
    const/4 v9, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/b;->g1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/b;->d1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-boolean v3, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eqz v3, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-super {p0, p1}, Lcom/google/android/material/shape/j;->draw(Landroid/graphics/Canvas;)V

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/b;->f1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/b;->i1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/b;->e1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/b;->c1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V

    iget-boolean v3, p0, Lcom/google/android/material/chip/b;->k1:Z

    const/4 v8, 0x3

    shr-int/2addr v9, v8

    if-eqz v3, :cond_3

    const/4 v9, 0x4

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/b;->k1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V

    :cond_3
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/b;->h1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/b;->j1(Landroid/graphics/Canvas;Landroid/graphics/Rect;)V

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget v0, p0, Lcom/google/android/material/chip/b;->a1:I

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-ge v0, v1, :cond_4

    const/4 v9, 0x0

    const/4 v8, 0x7

    invoke-virtual {p1, v2}, Landroid/graphics/Canvas;->restoreToCount(I)V

    :cond_4
    :goto_1
    const/4 v9, 0x1

    return-void
.end method

.method e2()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public e3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->d3(F)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public f3([I)Z
    .locals 3
    .param p1    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->f1:[I

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-static {v0, p1}, Ljava/util/Arrays;->equals([I[I)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/material/chip/b;->f1:[I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0, v0, p1}, Lcom/google/android/material/chip/b;->k2([I[I)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return p1
.end method

.method public g3(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->U:Landroid/content/res/ColorStateList;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eq v0, p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/android/material/chip/b;->U:Landroid/content/res/ColorStateList;

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->onStateChange([I)Z

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public getAlpha()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->a1:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public getColorFilter()Landroid/graphics/ColorFilter;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->b1:Landroid/graphics/ColorFilter;

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public getIntrinsicHeight()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/android/material/chip/b;->G:F

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    float-to-int v0, v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public getIntrinsicWidth()I
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v0, p0, Lcom/google/android/material/chip/b;->C0:F

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    add-float/2addr v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/android/material/chip/b;->F0:F

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    add-float/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->P1()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-interface {v2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {v1, v2}, Lcom/google/android/material/internal/n;->f(Ljava/lang/String;)F

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    add-float/2addr v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/android/material/chip/b;->G0:F

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    add-float/2addr v0, v1

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->V0()F

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    add-float/2addr v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/android/material/chip/b;->J0:F

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    add-float/2addr v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/android/material/chip/b;->l1:I

    const/4 v4, 0x7

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v0
.end method

.method public getOpacity()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, -0x3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public getOutline(Landroid/graphics/Outline;)V
    .locals 10
    .param p1    # Landroid/graphics/Outline;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-eqz v0, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-super {p0, p1}, Lcom/google/android/material/shape/j;->getOutline(Landroid/graphics/Outline;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    return-void

    :cond_0
    const/4 v9, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {v0}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez v1, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget v1, p0, Lcom/google/android/material/chip/b;->H:F

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Outline;->setRoundRect(Landroid/graphics/Rect;F)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    goto :goto_0

    :cond_1
    const/4 v8, 0x5

    const/4 v9, 0x2

    const/4 v3, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    const/4 v4, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->getIntrinsicWidth()I

    move-result v5

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->getIntrinsicHeight()I

    move-result v6

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget v7, p0, Lcom/google/android/material/chip/b;->H:F

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Outline;->setRoundRect(IIIIF)V

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->getAlpha()I

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    int-to-float v0, v0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    const/high16 v1, 0x437f0000    # 255.0f

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    div-float/2addr v0, v1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p1, v0}, Landroid/graphics/Outline;->setAlpha(F)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    return-void
.end method

.method public h3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-static {v0, p1}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->g3(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x2

    return-void
.end method

.method public i3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->j3(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public invalidateDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-interface {p1, p0}, Landroid/graphics/drawable/Drawable$Callback;->invalidateDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public isStateful()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->E:Landroid/content/res/ColorStateList;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/android/material/chip/b;->f2(Landroid/content/res/ColorStateList;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->F:Landroid/content/res/ColorStateList;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/android/material/chip/b;->f2(Landroid/content/res/ColorStateList;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/android/material/chip/b;->I:Landroid/content/res/ColorStateList;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/android/material/chip/b;->f2(Landroid/content/res/ColorStateList;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x7

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->g1:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->h1:Landroid/content/res/ColorStateList;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/android/material/chip/b;->f2(Landroid/content/res/ColorStateList;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_2

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/internal/n;->d()Lcom/google/android/material/resources/d;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/android/material/chip/b;->h2(Lcom/google/android/material/resources/d;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-nez v0, :cond_2

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->Z0()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez v0, :cond_2

    const/4 v1, 0x1

    or-int/2addr v2, v1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/android/material/chip/b;->g2(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-nez v0, :cond_2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/android/material/chip/b;->g2(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->d1:Landroid/content/res/ColorStateList;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/android/material/chip/b;->f2(Landroid/content/res/ColorStateList;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x2

    const/4 v1, 0x5

    return v0
.end method

.method protected j2()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->i1:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    check-cast v0, Lcom/google/android/material/chip/b$a;

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0}, Lcom/google/android/material/chip/b$a;->a()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public j3(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->R:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eq v0, p1, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/chip/b;->R:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v2, 0x6

    if-eqz v0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz p1, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/android/material/chip/b;->P0(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/chip/b;->O3(Landroid/graphics/drawable/Drawable;)V

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_2
    const/4 v2, 0x0

    return-void
.end method

.method public k3(Lcom/google/android/material/chip/b$a;)V
    .locals 3
    .param p1    # Lcom/google/android/material/chip/b$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/ref/WeakReference;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/android/material/chip/b;->i1:Ljava/lang/ref/WeakReference;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public l1()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x7

    return-object v0
.end method

.method public l2(Z)V
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->X:Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eq v0, p1, :cond_1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-boolean p1, p0, Lcom/google/android/material/chip/b;->X:Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result v0

    const/4 v1, 0x5

    and-int/2addr v2, v1

    if-nez p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-boolean p1, p0, Lcom/google/android/material/chip/b;->Y0:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-boolean p1, p0, Lcom/google/android/material/chip/b;->Y0:Z

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    cmpl-float p1, v0, p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public l3(Landroid/text/TextUtils$TruncateAt;)V
    .locals 2
    .param p1    # Landroid/text/TextUtils$TruncateAt;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/android/material/chip/b;->j1:Landroid/text/TextUtils$TruncateAt;

    const/4 v1, 0x2

    const/4 v0, 0x4

    return-void
.end method

.method public m1()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->k0:Landroid/content/res/ColorStateList;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public m2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->l2(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public m3(Lcom/google/android/material/animation/h;)V
    .locals 2
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/android/material/chip/b;->B0:Lcom/google/android/material/animation/h;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public n1()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->F:Landroid/content/res/ColorStateList;

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public n2(Landroid/graphics/drawable/Drawable;)V
    .locals 4
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0, v1}, Lcom/google/android/material/chip/b;->O3(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x0

    const/4 v2, 0x7

    iget-object v1, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0, v1}, Lcom/google/android/material/chip/b;->P0(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v3, 0x3

    const/4 v2, 0x5

    cmpl-float p1, v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method public n3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/b;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0, p1}, Lcom/google/android/material/animation/h;->d(Landroid/content/Context;I)Lcom/google/android/material/animation/h;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->m3(Lcom/google/android/material/animation/h;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public o1()F
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->S()F

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/chip/b;->H:F

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    return v0
.end method

.method public o2(Z)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->u2(Z)V

    const/4 v0, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public o3(F)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->E0:F

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    cmpl-float v0, v0, p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput p1, p0, Lcom/google/android/material/chip/b;->E0:F

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    cmpl-float p1, v0, p1

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public onLayoutDirectionChanged(I)Z
    .locals 4

    const/4 v3, 0x7

    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->onLayoutDirectionChanged(I)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->M3()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v1, p1}, Landroidx/core/graphics/drawable/d;->m(Landroid/graphics/drawable/Drawable;I)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    or-int/2addr v0, v1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->L3()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v1, p1}, Landroidx/core/graphics/drawable/d;->m(Landroid/graphics/drawable/Drawable;I)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    or-int/2addr v0, v1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x6

    iget-object v1, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v1, p1}, Landroidx/core/graphics/drawable/d;->m(Landroid/graphics/drawable/Drawable;I)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    or-int/2addr v0, p1

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 p1, 0x1

    move v3, p1

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return p1
.end method

.method protected onLevelChange(I)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->onLevelChange(I)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->M3()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    or-int/2addr v0, v1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->L3()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    iget-object v1, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    or-int/2addr v0, v1

    :cond_1
    const/4 v2, 0x5

    move v3, v2

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    if-eqz v1, :cond_2

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x2

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    or-int/2addr v0, p1

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    return v0
.end method

.method public onStateChange([I)Z
    .locals 3
    .param p1    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->m1:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-super {p0, p1}, Lcom/google/android/material/shape/j;->onStateChange([I)Z

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->D1()[I

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/b;->k2([I[I)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return p1
.end method

.method public p1()F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/chip/b;->J0:F

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public p2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->u2(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public p3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->o3(F)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public q1()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    invoke-static {v0}, Landroidx/core/graphics/drawable/d;->q(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public q2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lf/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->n2(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    return-void
.end method

.method public q3(F)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/chip/b;->D0:F

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    cmpl-float v0, v0, p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/android/material/chip/b;->D0:F

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->R0()F

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    cmpl-float p1, v0, p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public r1()F
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->P:F

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public r2(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/b;->k0:Landroid/content/res/ColorStateList;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq v0, p1, :cond_1

    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/material/chip/b;->k0:Landroid/content/res/ColorStateList;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->Z0()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->onStateChange([I)Z

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public r3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->q3(F)V

    const/4 v2, 0x5

    return-void
.end method

.method public s1()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->O:Landroid/content/res/ColorStateList;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public s2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    invoke-static {v0, p1}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->r2(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public s3(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x3

    iput p1, p0, Lcom/google/android/material/chip/b;->l1:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-interface {p1, p0, p2, p3, p4}, Landroid/graphics/drawable/Drawable$Callback;->scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public setAlpha(I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/chip/b;->a1:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eq v0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/chip/b;->a1:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 3
    .param p1    # Landroid/graphics/ColorFilter;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/android/material/chip/b;->b1:Landroid/graphics/ColorFilter;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eq v0, p1, :cond_0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/material/chip/b;->b1:Landroid/graphics/ColorFilter;

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public setTintList(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->d1:Landroid/content/res/ColorStateList;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/chip/b;->d1:Landroid/content/res/ColorStateList;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->onStateChange([I)Z

    :cond_0
    const/4 v2, 0x5

    return-void
.end method

.method public setTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 3
    .param p1    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/b;->e1:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/android/material/chip/b;->e1:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->d1:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p0, v0, p1}, Lr4/a;->c(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuffColorFilter;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/google/android/material/chip/b;->c1:Landroid/graphics/PorterDuffColorFilter;

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public setVisible(ZZ)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-super {p0, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->M3()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/android/material/chip/b;->N:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v1, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    or-int/2addr v0, v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->L3()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v1, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    or-int/2addr v0, v1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->N3()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v1, :cond_2

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v1, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    or-int/2addr v0, p1

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v0
.end method

.method public t1()F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/chip/b;->G:F

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public t2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->u2(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public t3(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K:Landroid/content/res/ColorStateList;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eq v0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/android/material/chip/b;->K:Landroid/content/res/ColorStateList;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->P3()V

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->onStateChange([I)Z

    :cond_0
    const/4 v2, 0x3

    return-void
.end method

.method public u1()F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/android/material/chip/b;->C0:F

    const/4 v2, 0x2

    const/4 v1, 0x0

    return v0
.end method

.method public u2(Z)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/android/material/chip/b;->Y:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    if-eq v0, p1, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->L3()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-boolean p1, p0, Lcom/google/android/material/chip/b;->Y:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/android/material/chip/b;->L3()Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/google/android/material/chip/b;->P0(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x4

    move v2, v1

    goto :goto_1

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/android/material/chip/b;->Z:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x5

    and-int/2addr v2, v1

    invoke-direct {p0, p1}, Lcom/google/android/material/chip/b;->O3(Landroid/graphics/drawable/Drawable;)V

    :goto_1
    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_2
    const/4 v2, 0x2

    return-void
.end method

.method public u3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->t3(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x5

    move v1, v0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x3

    invoke-interface {p1, p0, p2}, Landroid/graphics/drawable/Drawable$Callback;->unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public v1()Landroid/content/res/ColorStateList;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->I:Landroid/content/res/ColorStateList;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public v2(Landroid/content/res/ColorStateList;)V
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/b;->F:Landroid/content/res/ColorStateList;

    const/4 v1, 0x1

    const/4 v1, 0x3

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/android/material/chip/b;->F:Landroid/content/res/ColorStateList;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->onStateChange([I)Z

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method v3(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/android/material/chip/b;->k1:Z

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public w1()F
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/android/material/chip/b;->J:F

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    return v0
.end method

.method public w2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    invoke-static {v0, p1}, Lf/a;->a(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->v2(Landroid/content/res/ColorStateList;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public w3(Lcom/google/android/material/animation/h;)V
    .locals 2
    .param p1    # Lcom/google/android/material/animation/h;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/android/material/chip/b;->A0:Lcom/google/android/material/animation/h;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public x1(Landroid/graphics/RectF;)V
    .locals 3
    .param p1    # Landroid/graphics/RectF;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, v0, p1}, Lcom/google/android/material/chip/b;->S0(Landroid/graphics/Rect;Landroid/graphics/RectF;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public x2(F)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/android/material/chip/b;->H:F

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    cmpl-float v0, v0, p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/android/material/chip/b;->H:F

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->getShapeAppearanceModel()Lcom/google/android/material/shape/o;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/android/material/shape/o;->w(F)Lcom/google/android/material/shape/o;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/shape/j;->setShapeAppearanceModel(Lcom/google/android/material/shape/o;)V

    :cond_0
    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public x3(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/b;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-static {v0, p1}, Lcom/google/android/material/animation/h;->d(Landroid/content/Context;I)Lcom/google/android/material/animation/h;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->w3(Lcom/google/android/material/animation/h;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public y1()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->S:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Landroidx/core/graphics/drawable/d;->q(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v0, 0x0

    move v2, v0

    :goto_0
    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public y2(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimension(I)F

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/b;->x2(F)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public y3(Ljava/lang/CharSequence;)V
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const-string p1, ""

    const/4 v2, 0x6

    const-string p1, ""

    const-string p1, ""

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/b;->L:Ljava/lang/CharSequence;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/google/android/material/chip/b;->L:Ljava/lang/CharSequence;

    const/4 v1, 0x6

    move v2, v1

    iget-object p1, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Lcom/google/android/material/internal/n;->j(Z)V

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public z1()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/b;->W:Ljava/lang/CharSequence;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public z2(F)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/android/material/chip/b;->J0:F

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    cmpl-float v0, v0, p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/chip/b;->J0:F

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/android/material/shape/j;->invalidateSelf()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/android/material/chip/b;->j2()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public z3(Lcom/google/android/material/resources/d;)V
    .locals 4
    .param p1    # Lcom/google/android/material/resources/d;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/android/material/chip/b;->R0:Lcom/google/android/material/internal/n;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/android/material/chip/b;->K0:Landroid/content/Context;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, p1, v1}, Lcom/google/android/material/internal/n;->i(Lcom/google/android/material/resources/d;Landroid/content/Context;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method
