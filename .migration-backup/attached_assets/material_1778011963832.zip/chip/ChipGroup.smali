.class public Lcom/google/android/material/chip/ChipGroup;
.super Lcom/google/android/material/internal/FlowLayout;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/android/material/chip/ChipGroup$f;,
        Lcom/google/android/material/chip/ChipGroup$c;,
        Lcom/google/android/material/chip/ChipGroup$e;,
        Lcom/google/android/material/chip/ChipGroup$d;
    }
.end annotation


# static fields
.field private static final k:I


# instance fields
.field private e:I
    .annotation build Landroidx/annotation/r;
    .end annotation
.end field

.field private f:I
    .annotation build Landroidx/annotation/r;
    .end annotation
.end field

.field private g:Lcom/google/android/material/chip/ChipGroup$e;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final h:Lcom/google/android/material/internal/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/android/material/internal/a<",
            "Lcom/google/android/material/chip/Chip;",
            ">;"
        }
    .end annotation
.end field

.field private final i:I

.field private final j:Lcom/google/android/material/chip/ChipGroup$f;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget v0, Lcom/google/android/material/R$style;->Widget_MaterialComponents_ChipGroup:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    sput v0, Lcom/google/android/material/chip/ChipGroup;->k:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lcom/google/android/material/chip/ChipGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget v0, Lcom/google/android/material/R$attr;->chipGroupStyle:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, v0}, Lcom/google/android/material/chip/ChipGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    sget v4, Lcom/google/android/material/chip/ChipGroup;->k:I

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {p1, p2, p3, v4}, Lw4/a;->c(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-direct {p0, p1, p2, p3}, Lcom/google/android/material/internal/FlowLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v8, 0x1

    move v9, v8

    new-instance p1, Lcom/google/android/material/internal/a;

    const/4 v9, 0x4

    invoke-direct {p1}, Lcom/google/android/material/internal/a;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    iput-object p1, p0, Lcom/google/android/material/chip/ChipGroup;->h:Lcom/google/android/material/internal/a;

    const/4 v8, 0x7

    shr-int/2addr v9, v8

    new-instance v6, Lcom/google/android/material/chip/ChipGroup$f;

    const/4 v8, 0x3

    const/4 v9, 0x5

    const/4 v0, 0x0

    invoke-direct {v6, p0, v0}, Lcom/google/android/material/chip/ChipGroup$f;-><init>(Lcom/google/android/material/chip/ChipGroup;Lcom/google/android/material/chip/ChipGroup$a;)V

    const/4 v8, 0x7

    move v9, v8

    iput-object v6, p0, Lcom/google/android/material/chip/ChipGroup;->j:Lcom/google/android/material/chip/ChipGroup$f;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    sget-object v2, Lcom/google/android/material/R$styleable;->ChipGroup:[I

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v7, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    new-array v5, v7, [I

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    move v3, p3

    move v3, p3

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static/range {v0 .. v5}, Lcom/google/android/material/internal/q;->j(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    sget p3, Lcom/google/android/material/R$styleable;->ChipGroup_chipSpacing:I

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p2, p3, v7}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result p3

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    sget v0, Lcom/google/android/material/R$styleable;->ChipGroup_chipSpacingHorizontal:I

    const/4 v9, 0x7

    invoke-virtual {p2, v0, p3}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {p0, v0}, Lcom/google/android/material/chip/ChipGroup;->setChipSpacingHorizontal(I)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    sget v0, Lcom/google/android/material/R$styleable;->ChipGroup_chipSpacingVertical:I

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {p2, v0, p3}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result p3

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/ChipGroup;->setChipSpacingVertical(I)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    sget p3, Lcom/google/android/material/R$styleable;->ChipGroup_singleLine:I

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {p2, p3, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/ChipGroup;->setSingleLine(Z)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    sget p3, Lcom/google/android/material/R$styleable;->ChipGroup_singleSelection:I

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {p2, p3, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p3

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/ChipGroup;->setSingleSelection(Z)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    sget p3, Lcom/google/android/material/R$styleable;->ChipGroup_selectionRequired:I

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p2, p3, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p3

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p0, p3}, Lcom/google/android/material/chip/ChipGroup;->setSelectionRequired(Z)V

    sget p3, Lcom/google/android/material/R$styleable;->ChipGroup_checkedChip:I

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/4 v0, -0x1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {p2, p3, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    iput p3, p0, Lcom/google/android/material/chip/ChipGroup;->i:I

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance p2, Lcom/google/android/material/chip/ChipGroup$a;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-direct {p2, p0}, Lcom/google/android/material/chip/ChipGroup$a;-><init>(Lcom/google/android/material/chip/ChipGroup;)V

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {p1, p2}, Lcom/google/android/material/internal/a;->p(Lcom/google/android/material/internal/a$b;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-super {p0, v6}, Landroid/view/ViewGroup;->setOnHierarchyChangeListener(Landroid/view/ViewGroup$OnHierarchyChangeListener;)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 p1, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {p0, p1}, Landroidx/core/view/k1;->R1(Landroid/view/View;I)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    return-void
.end method

.method static synthetic e(Lcom/google/android/material/chip/ChipGroup;)Lcom/google/android/material/chip/ChipGroup$e;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "f~s@~m~ t~~ ~ ~Kyo~o~   lof /sor~@@S@~~@b u~  c@i@~d~o@4@-.i@1~~ a@@~tbi@@ ~/o ~nb v~~@M@ @@@l@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/google/android/material/chip/ChipGroup;->g:Lcom/google/android/material/chip/ChipGroup$e;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic f(Lcom/google/android/material/chip/ChipGroup;)Lcom/google/android/material/internal/a;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/google/android/material/chip/ChipGroup;->h:Lcom/google/android/material/internal/a;

    const/4 v1, 0x3

    const/4 v0, 0x5

    return-object p0
.end method

.method private getChipCount()I
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    move v1, v0

    move v1, v0

    const/4 v4, 0x6

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-ge v0, v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    instance-of v2, v2, Lcom/google/android/material/chip/Chip;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    add-int/lit8 v1, v1, 0x1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    return v1
.end method


# virtual methods
.method public c()Z
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    invoke-super {p0}, Lcom/google/android/material/internal/FlowLayout;->c()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method protected checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    instance-of p1, p1, Lcom/google/android/material/chip/ChipGroup$c;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    or-int/2addr v2, v1

    const/4 p1, 0x1

    shl-int/2addr v2, p1

    const/4 v1, 0x1

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return p1
.end method

.method public g(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/android/material/chip/ChipGroup;->h:Lcom/google/android/material/internal/a;

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/a;->f(I)V

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method protected generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Lcom/google/android/material/chip/ChipGroup$c;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, -0x2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0, v1, v1}, Lcom/google/android/material/chip/ChipGroup$c;-><init>(II)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0
.end method

.method public generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Lcom/google/android/material/chip/ChipGroup$c;

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0, v1, p1}, Lcom/google/android/material/chip/ChipGroup$c;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method protected generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    new-instance v0, Lcom/google/android/material/chip/ChipGroup$c;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0, p1}, Lcom/google/android/material/chip/ChipGroup$c;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public getCheckedChipId()I
    .locals 3
    .annotation build Landroidx/annotation/d0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/ChipGroup;->h:Lcom/google/android/material/internal/a;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/android/material/internal/a;->k()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public getCheckedChipIds()Ljava/util/List;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/android/material/chip/ChipGroup;->h:Lcom/google/android/material/internal/a;

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Lcom/google/android/material/internal/a;->j(Landroid/view/ViewGroup;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public getChipSpacingHorizontal()I
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/android/material/chip/ChipGroup;->e:I

    const/4 v2, 0x7

    return v0
.end method

.method public getChipSpacingVertical()I
    .locals 3
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/chip/ChipGroup;->f:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    return v0
.end method

.method public h()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/ChipGroup;->h:Lcom/google/android/material/internal/a;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/android/material/internal/a;->h()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method i(Landroid/view/View;)I
    .locals 6
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x4

    const/4 v4, 0x7

    instance-of v0, p1, Lcom/google/android/material/chip/Chip;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v1, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    return v1

    :cond_0
    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    move v2, v0

    move v2, v0

    const/4 v5, 0x0

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ge v0, v3, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    instance-of v3, v3, Lcom/google/android/material/chip/Chip;

    const/4 v5, 0x0

    if-eqz v3, :cond_2

    const/4 v5, 0x0

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    check-cast v3, Lcom/google/android/material/chip/Chip;

    const/4 v5, 0x6

    if-ne v3, p1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    return v2

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto :goto_0

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    return v1
.end method

.method public j()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/android/material/chip/ChipGroup;->h:Lcom/google/android/material/internal/a;

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {v0}, Lcom/google/android/material/internal/a;->l()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public k()Z
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Lcom/google/android/material/chip/ChipGroup;->h:Lcom/google/android/material/internal/a;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/android/material/internal/a;->m()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method protected onFinishInflate()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-super {p0}, Landroid/view/ViewGroup;->onFinishInflate()V

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/android/material/chip/ChipGroup;->i:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, -0x1

    const/4 v3, 0x6

    if-eq v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/android/material/chip/ChipGroup;->h:Lcom/google/android/material/internal/a;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Lcom/google/android/material/internal/a;->f(I)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 6
    .param p1    # Landroid/view/accessibility/AccessibilityNodeInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p1}, Landroidx/core/view/accessibility/l0;->X1(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroidx/core/view/accessibility/l0;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/android/material/chip/ChipGroup;->c()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/android/material/chip/ChipGroup;->getChipCount()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v0, -0x1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/android/material/internal/FlowLayout;->getRowCount()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/android/material/chip/ChipGroup;->k()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    goto :goto_1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v2, 0x2

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v1, v0, v3, v2}, Landroidx/core/view/accessibility/l0$b;->f(IIZI)Landroidx/core/view/accessibility/l0$b;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroidx/core/view/accessibility/l0;->Y0(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-void
.end method

.method public setChipSpacing(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/ChipGroup;->setChipSpacingHorizontal(I)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/ChipGroup;->setChipSpacingVertical(I)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public setChipSpacingHorizontal(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/android/material/chip/ChipGroup;->e:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/android/material/chip/ChipGroup;->e:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/internal/FlowLayout;->setItemSpacing(I)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public setChipSpacingHorizontalResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/ChipGroup;->setChipSpacingHorizontal(I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public setChipSpacingResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/ChipGroup;->setChipSpacing(I)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public setChipSpacingVertical(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget v0, p0, Lcom/google/android/material/chip/ChipGroup;->f:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    iput p1, p0, Lcom/google/android/material/chip/ChipGroup;->f:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/android/material/internal/FlowLayout;->setLineSpacing(I)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public setChipSpacingVerticalResource(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/ChipGroup;->setChipSpacingVertical(I)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public setDividerDrawableHorizontal(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string v0, "  imouptonid ticgedaealsalscbdfh i eer.neiwavrddgGup srsn r apdedv hwa.ar  s nisigabe ooevnCh"

    const-string/jumbo v0, "pcsrhc  ho.ald  r p eaiiis.bidgseaCfdevf hn  go rnndtbaivs d ooaGp nsevdagiiaweeeudrlnaewtsur"

    const/4 v2, 0x5

    const-string v0, "b.bGoCe d iagsrae wahuida sien roehaughdei.fpnaroiod nr wpdoesl ecltndvti ve f cinrsCsga avp "

    const-string v0, "Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    throw p1
.end method

.method public setDividerDrawableVertical(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string/jumbo v0, "f odibo siwethneavcauGCgbC ad.s e tpapedi nughnolasa  ew bpcdirvrsaod .rianevnei hlrfm gds de"

    const-string v0, "db m dss ni vegersa odca.depvr   siclehnhGa oerwontCeeura hegsaipudin  dinvglfaCaa.p iwtdbfio"

    const/4 v2, 0x0

    const-string v0, " hCeh udi f letnabds va cs aoneaggdrderhnu. a iv.eusoi o svreinfioieGpingdlwsatCacbewdpda rpr"

    const-string v0, "Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    throw p1
.end method

.method public setFlexWrap(I)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string v0, "  eiGpnpp.s utexiCtslnbLdege  wlseorrwrCenteoto nlpaheaaniu oli.adgtaoxiafi gnph "

    const-string/jumbo v0, "tadroexnpl.ntireoCgssw inidfwbpsaualp tg gxeitLtai G. illeeeohnea pru  onhneos Ca"

    const/4 v2, 0x4

    const-string v0, "Changing flex wrap not allowed. ChipGroup exposes a singleLine attribute instead."

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    throw p1
.end method

.method public setOnCheckedChangeListener(Lcom/google/android/material/chip/ChipGroup$d;)V
    .locals 3
    .param p1    # Lcom/google/android/material/chip/ChipGroup$d;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/ChipGroup;->setOnCheckedStateChangeListener(Lcom/google/android/material/chip/ChipGroup$e;)V

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    new-instance v0, Lcom/google/android/material/chip/ChipGroup$b;

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-direct {v0, p0, p1}, Lcom/google/android/material/chip/ChipGroup$b;-><init>(Lcom/google/android/material/chip/ChipGroup;Lcom/google/android/material/chip/ChipGroup$d;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0, v0}, Lcom/google/android/material/chip/ChipGroup;->setOnCheckedStateChangeListener(Lcom/google/android/material/chip/ChipGroup$e;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public setOnCheckedStateChangeListener(Lcom/google/android/material/chip/ChipGroup$e;)V
    .locals 2
    .param p1    # Lcom/google/android/material/chip/ChipGroup$e;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/android/material/chip/ChipGroup;->g:Lcom/google/android/material/chip/ChipGroup$e;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public setOnHierarchyChangeListener(Landroid/view/ViewGroup$OnHierarchyChangeListener;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/android/material/chip/ChipGroup;->j:Lcom/google/android/material/chip/ChipGroup$f;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lcom/google/android/material/chip/ChipGroup$f;->a(Lcom/google/android/material/chip/ChipGroup$f;Landroid/view/ViewGroup$OnHierarchyChangeListener;)Landroid/view/ViewGroup$OnHierarchyChangeListener;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public setSelectionRequired(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/android/material/chip/ChipGroup;->h:Lcom/google/android/material/internal/a;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/a;->q(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public setShowDividerHorizontal(I)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const-string v0, " po eo sqvebwm iCn irrg  iclhdsisse ptinedsnab ae.da.op cfvgdo iroa drCedtaeshGa fuugnin"

    const-string/jumbo v0, "sa rhb .nevenmrh ir aiiodic ob  tedipsadpo nsfl eiaaef guedietCdaosCconGvnp.dsw s ugg rd"

    const/4 v2, 0x0

    const-string v0, ".tsheeudpnvi edhfdCge l auacGoop cimnsorsvio nfoCg e rswsrn h riabdsdn  at aiegs.iedi dp"

    const-string v0, "Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    throw p1
.end method

.method public setShowDividerVertical(I)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const-string v0, "Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing."

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    throw p1
.end method

.method public setSingleLine(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/ChipGroup;->setSingleLine(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public setSingleLine(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-super {p0, p1}, Lcom/google/android/material/internal/FlowLayout;->setSingleLine(Z)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public setSingleSelection(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/h;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/android/material/chip/ChipGroup;->setSingleSelection(Z)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public setSingleSelection(Z)V
    .locals 3

    iget-object v0, p0, Lcom/google/android/material/chip/ChipGroup;->h:Lcom/google/android/material/internal/a;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/google/android/material/internal/a;->r(Z)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method
